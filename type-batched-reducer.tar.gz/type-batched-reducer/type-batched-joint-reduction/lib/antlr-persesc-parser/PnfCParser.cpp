
// Generated from PnfC.g4 by ANTLR 4.7.2


#include "PnfCListener.h"
#include "PnfCVisitor.h"

#include "PnfCParser.h"


using namespace antlrcpp;
using namespace antlr_C_perses;
using namespace antlr4;

PnfCParser::PnfCParser(TokenStream *input) : Parser(input) {
  _interpreter = new atn::ParserATNSimulator(this, _atn, _decisionToDFA, _sharedContextCache);
}

PnfCParser::~PnfCParser() {
  delete _interpreter;
}

std::string PnfCParser::getGrammarFileName() const {
  return "PnfC.g4";
}

const std::vector<std::string>& PnfCParser::getRuleNames() const {
  return _ruleNames;
}

dfa::Vocabulary& PnfCParser::getVocabulary() const {
  return _vocabulary;
}


//----------------- GenericSelectionContext ------------------------------------------------------------------

PnfCParser::GenericSelectionContext::GenericSelectionContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::GenericSelectionContext::Generic() {
  return getToken(PnfCParser::Generic, 0);
}

tree::TerminalNode* PnfCParser::GenericSelectionContext::LeftParen() {
  return getToken(PnfCParser::LeftParen, 0);
}

PnfCParser::AssignmentExpressionContext* PnfCParser::GenericSelectionContext::assignmentExpression() {
  return getRuleContext<PnfCParser::AssignmentExpressionContext>(0);
}

tree::TerminalNode* PnfCParser::GenericSelectionContext::Comma() {
  return getToken(PnfCParser::Comma, 0);
}

PnfCParser::GenericAssocListContext* PnfCParser::GenericSelectionContext::genericAssocList() {
  return getRuleContext<PnfCParser::GenericAssocListContext>(0);
}

tree::TerminalNode* PnfCParser::GenericSelectionContext::RightParen() {
  return getToken(PnfCParser::RightParen, 0);
}


size_t PnfCParser::GenericSelectionContext::getRuleIndex() const {
  return PnfCParser::RuleGenericSelection;
}

void PnfCParser::GenericSelectionContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterGenericSelection(this);
}

void PnfCParser::GenericSelectionContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitGenericSelection(this);
}


antlrcpp::Any PnfCParser::GenericSelectionContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitGenericSelection(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::GenericSelectionContext* PnfCParser::genericSelection() {
  GenericSelectionContext *_localctx = _tracker.createInstance<GenericSelectionContext>(_ctx, getState());
  enterRule(_localctx, 0, PnfCParser::RuleGenericSelection);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(532);
    match(PnfCParser::Generic);
    setState(533);
    match(PnfCParser::LeftParen);
    setState(534);
    assignmentExpression();
    setState(535);
    match(PnfCParser::Comma);
    setState(536);
    genericAssocList();
    setState(537);
    match(PnfCParser::RightParen);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- GenericAssociationContext ------------------------------------------------------------------

PnfCParser::GenericAssociationContext::GenericAssociationContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Altnt_block__genericAssociation_1Context* PnfCParser::GenericAssociationContext::altnt_block__genericAssociation_1() {
  return getRuleContext<PnfCParser::Altnt_block__genericAssociation_1Context>(0);
}

tree::TerminalNode* PnfCParser::GenericAssociationContext::Colon() {
  return getToken(PnfCParser::Colon, 0);
}

PnfCParser::AssignmentExpressionContext* PnfCParser::GenericAssociationContext::assignmentExpression() {
  return getRuleContext<PnfCParser::AssignmentExpressionContext>(0);
}


size_t PnfCParser::GenericAssociationContext::getRuleIndex() const {
  return PnfCParser::RuleGenericAssociation;
}

void PnfCParser::GenericAssociationContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterGenericAssociation(this);
}

void PnfCParser::GenericAssociationContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitGenericAssociation(this);
}


antlrcpp::Any PnfCParser::GenericAssociationContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitGenericAssociation(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::GenericAssociationContext* PnfCParser::genericAssociation() {
  GenericAssociationContext *_localctx = _tracker.createInstance<GenericAssociationContext>(_ctx, getState());
  enterRule(_localctx, 2, PnfCParser::RuleGenericAssociation);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(539);
    altnt_block__genericAssociation_1();
    setState(540);
    match(PnfCParser::Colon);
    setState(541);
    assignmentExpression();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- UnaryExpressionContext ------------------------------------------------------------------

PnfCParser::UnaryExpressionContext::UnaryExpressionContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::PostfixExpressionContext* PnfCParser::UnaryExpressionContext::postfixExpression() {
  return getRuleContext<PnfCParser::PostfixExpressionContext>(0);
}

PnfCParser::Aux_rule__unaryExpression_5Context* PnfCParser::UnaryExpressionContext::aux_rule__unaryExpression_5() {
  return getRuleContext<PnfCParser::Aux_rule__unaryExpression_5Context>(0);
}

PnfCParser::Aux_rule__unaryExpression_6Context* PnfCParser::UnaryExpressionContext::aux_rule__unaryExpression_6() {
  return getRuleContext<PnfCParser::Aux_rule__unaryExpression_6Context>(0);
}

PnfCParser::Aux_rule__unaryExpression_7Context* PnfCParser::UnaryExpressionContext::aux_rule__unaryExpression_7() {
  return getRuleContext<PnfCParser::Aux_rule__unaryExpression_7Context>(0);
}

PnfCParser::Aux_rule__unaryExpression_8Context* PnfCParser::UnaryExpressionContext::aux_rule__unaryExpression_8() {
  return getRuleContext<PnfCParser::Aux_rule__unaryExpression_8Context>(0);
}


size_t PnfCParser::UnaryExpressionContext::getRuleIndex() const {
  return PnfCParser::RuleUnaryExpression;
}

void PnfCParser::UnaryExpressionContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterUnaryExpression(this);
}

void PnfCParser::UnaryExpressionContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitUnaryExpression(this);
}


antlrcpp::Any PnfCParser::UnaryExpressionContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitUnaryExpression(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::UnaryExpressionContext* PnfCParser::unaryExpression() {
  UnaryExpressionContext *_localctx = _tracker.createInstance<UnaryExpressionContext>(_ctx, getState());
  enterRule(_localctx, 4, PnfCParser::RuleUnaryExpression);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(548);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 0, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(543);
      postfixExpression();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(544);
      aux_rule__unaryExpression_5();
      break;
    }

    case 3: {
      enterOuterAlt(_localctx, 3);
      setState(545);
      aux_rule__unaryExpression_6();
      break;
    }

    case 4: {
      enterOuterAlt(_localctx, 4);
      setState(546);
      aux_rule__unaryExpression_7();
      break;
    }

    case 5: {
      enterOuterAlt(_localctx, 5);
      setState(547);
      aux_rule__unaryExpression_8();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- UnaryOperatorContext ------------------------------------------------------------------

PnfCParser::UnaryOperatorContext::UnaryOperatorContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::UnaryOperatorContext::And() {
  return getToken(PnfCParser::And, 0);
}

tree::TerminalNode* PnfCParser::UnaryOperatorContext::Star() {
  return getToken(PnfCParser::Star, 0);
}

tree::TerminalNode* PnfCParser::UnaryOperatorContext::Plus() {
  return getToken(PnfCParser::Plus, 0);
}

tree::TerminalNode* PnfCParser::UnaryOperatorContext::Minus() {
  return getToken(PnfCParser::Minus, 0);
}

tree::TerminalNode* PnfCParser::UnaryOperatorContext::Tilde() {
  return getToken(PnfCParser::Tilde, 0);
}

tree::TerminalNode* PnfCParser::UnaryOperatorContext::Not() {
  return getToken(PnfCParser::Not, 0);
}


size_t PnfCParser::UnaryOperatorContext::getRuleIndex() const {
  return PnfCParser::RuleUnaryOperator;
}

void PnfCParser::UnaryOperatorContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterUnaryOperator(this);
}

void PnfCParser::UnaryOperatorContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitUnaryOperator(this);
}


antlrcpp::Any PnfCParser::UnaryOperatorContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitUnaryOperator(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::UnaryOperatorContext* PnfCParser::unaryOperator() {
  UnaryOperatorContext *_localctx = _tracker.createInstance<UnaryOperatorContext>(_ctx, getState());
  enterRule(_localctx, 6, PnfCParser::RuleUnaryOperator);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(550);
    _la = _input->LA(1);
    if (!(((((_la - 78) & ~ 0x3fULL) == 0) &&
      ((1ULL << (_la - 78)) & ((1ULL << (PnfCParser::Plus - 78))
      | (1ULL << (PnfCParser::Minus - 78))
      | (1ULL << (PnfCParser::Star - 78))
      | (1ULL << (PnfCParser::And - 78))
      | (1ULL << (PnfCParser::Not - 78))
      | (1ULL << (PnfCParser::Tilde - 78)))) != 0))) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- CastExpressionContext ------------------------------------------------------------------

PnfCParser::CastExpressionContext::CastExpressionContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::UnaryExpressionContext* PnfCParser::CastExpressionContext::unaryExpression() {
  return getRuleContext<PnfCParser::UnaryExpressionContext>(0);
}

PnfCParser::Aux_rule__castExpression_2Context* PnfCParser::CastExpressionContext::aux_rule__castExpression_2() {
  return getRuleContext<PnfCParser::Aux_rule__castExpression_2Context>(0);
}


size_t PnfCParser::CastExpressionContext::getRuleIndex() const {
  return PnfCParser::RuleCastExpression;
}

void PnfCParser::CastExpressionContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterCastExpression(this);
}

void PnfCParser::CastExpressionContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitCastExpression(this);
}


antlrcpp::Any PnfCParser::CastExpressionContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitCastExpression(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::CastExpressionContext* PnfCParser::castExpression() {
  CastExpressionContext *_localctx = _tracker.createInstance<CastExpressionContext>(_ctx, getState());
  enterRule(_localctx, 8, PnfCParser::RuleCastExpression);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(554);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 1, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(552);
      unaryExpression();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(553);
      aux_rule__castExpression_2();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ConditionalExpressionContext ------------------------------------------------------------------

PnfCParser::ConditionalExpressionContext::ConditionalExpressionContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::LogicalOrExpressionContext* PnfCParser::ConditionalExpressionContext::logicalOrExpression() {
  return getRuleContext<PnfCParser::LogicalOrExpressionContext>(0);
}

PnfCParser::Optional__conditionalExpression_2Context* PnfCParser::ConditionalExpressionContext::optional__conditionalExpression_2() {
  return getRuleContext<PnfCParser::Optional__conditionalExpression_2Context>(0);
}


size_t PnfCParser::ConditionalExpressionContext::getRuleIndex() const {
  return PnfCParser::RuleConditionalExpression;
}

void PnfCParser::ConditionalExpressionContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterConditionalExpression(this);
}

void PnfCParser::ConditionalExpressionContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitConditionalExpression(this);
}


antlrcpp::Any PnfCParser::ConditionalExpressionContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitConditionalExpression(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::ConditionalExpressionContext* PnfCParser::conditionalExpression() {
  ConditionalExpressionContext *_localctx = _tracker.createInstance<ConditionalExpressionContext>(_ctx, getState());
  enterRule(_localctx, 10, PnfCParser::RuleConditionalExpression);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(556);
    logicalOrExpression();
    setState(557);
    optional__conditionalExpression_2();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- AssignmentExpressionContext ------------------------------------------------------------------

PnfCParser::AssignmentExpressionContext::AssignmentExpressionContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::ConditionalExpressionContext* PnfCParser::AssignmentExpressionContext::conditionalExpression() {
  return getRuleContext<PnfCParser::ConditionalExpressionContext>(0);
}

PnfCParser::Aux_rule__assignmentExpression_1Context* PnfCParser::AssignmentExpressionContext::aux_rule__assignmentExpression_1() {
  return getRuleContext<PnfCParser::Aux_rule__assignmentExpression_1Context>(0);
}


size_t PnfCParser::AssignmentExpressionContext::getRuleIndex() const {
  return PnfCParser::RuleAssignmentExpression;
}

void PnfCParser::AssignmentExpressionContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAssignmentExpression(this);
}

void PnfCParser::AssignmentExpressionContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAssignmentExpression(this);
}


antlrcpp::Any PnfCParser::AssignmentExpressionContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAssignmentExpression(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::AssignmentExpressionContext* PnfCParser::assignmentExpression() {
  AssignmentExpressionContext *_localctx = _tracker.createInstance<AssignmentExpressionContext>(_ctx, getState());
  enterRule(_localctx, 12, PnfCParser::RuleAssignmentExpression);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(561);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 2, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(559);
      conditionalExpression();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(560);
      aux_rule__assignmentExpression_1();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- AssignmentOperatorContext ------------------------------------------------------------------

PnfCParser::AssignmentOperatorContext::AssignmentOperatorContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::AssignmentOperatorContext::Assign() {
  return getToken(PnfCParser::Assign, 0);
}

tree::TerminalNode* PnfCParser::AssignmentOperatorContext::StarAssign() {
  return getToken(PnfCParser::StarAssign, 0);
}

tree::TerminalNode* PnfCParser::AssignmentOperatorContext::DivAssign() {
  return getToken(PnfCParser::DivAssign, 0);
}

tree::TerminalNode* PnfCParser::AssignmentOperatorContext::ModAssign() {
  return getToken(PnfCParser::ModAssign, 0);
}

tree::TerminalNode* PnfCParser::AssignmentOperatorContext::PlusAssign() {
  return getToken(PnfCParser::PlusAssign, 0);
}

tree::TerminalNode* PnfCParser::AssignmentOperatorContext::MinusAssign() {
  return getToken(PnfCParser::MinusAssign, 0);
}

tree::TerminalNode* PnfCParser::AssignmentOperatorContext::LeftShiftAssign() {
  return getToken(PnfCParser::LeftShiftAssign, 0);
}

tree::TerminalNode* PnfCParser::AssignmentOperatorContext::RightShiftAssign() {
  return getToken(PnfCParser::RightShiftAssign, 0);
}

tree::TerminalNode* PnfCParser::AssignmentOperatorContext::AndAssign() {
  return getToken(PnfCParser::AndAssign, 0);
}

tree::TerminalNode* PnfCParser::AssignmentOperatorContext::XorAssign() {
  return getToken(PnfCParser::XorAssign, 0);
}

tree::TerminalNode* PnfCParser::AssignmentOperatorContext::OrAssign() {
  return getToken(PnfCParser::OrAssign, 0);
}


size_t PnfCParser::AssignmentOperatorContext::getRuleIndex() const {
  return PnfCParser::RuleAssignmentOperator;
}

void PnfCParser::AssignmentOperatorContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAssignmentOperator(this);
}

void PnfCParser::AssignmentOperatorContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAssignmentOperator(this);
}


antlrcpp::Any PnfCParser::AssignmentOperatorContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAssignmentOperator(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::AssignmentOperatorContext* PnfCParser::assignmentOperator() {
  AssignmentOperatorContext *_localctx = _tracker.createInstance<AssignmentOperatorContext>(_ctx, getState());
  enterRule(_localctx, 14, PnfCParser::RuleAssignmentOperator);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(563);
    _la = _input->LA(1);
    if (!(((((_la - 96) & ~ 0x3fULL) == 0) &&
      ((1ULL << (_la - 96)) & ((1ULL << (PnfCParser::Assign - 96))
      | (1ULL << (PnfCParser::StarAssign - 96))
      | (1ULL << (PnfCParser::DivAssign - 96))
      | (1ULL << (PnfCParser::ModAssign - 96))
      | (1ULL << (PnfCParser::PlusAssign - 96))
      | (1ULL << (PnfCParser::MinusAssign - 96))
      | (1ULL << (PnfCParser::LeftShiftAssign - 96))
      | (1ULL << (PnfCParser::RightShiftAssign - 96))
      | (1ULL << (PnfCParser::AndAssign - 96))
      | (1ULL << (PnfCParser::XorAssign - 96))
      | (1ULL << (PnfCParser::OrAssign - 96)))) != 0))) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ConstantExpressionContext ------------------------------------------------------------------

PnfCParser::ConstantExpressionContext::ConstantExpressionContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::ConditionalExpressionContext* PnfCParser::ConstantExpressionContext::conditionalExpression() {
  return getRuleContext<PnfCParser::ConditionalExpressionContext>(0);
}


size_t PnfCParser::ConstantExpressionContext::getRuleIndex() const {
  return PnfCParser::RuleConstantExpression;
}

void PnfCParser::ConstantExpressionContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterConstantExpression(this);
}

void PnfCParser::ConstantExpressionContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitConstantExpression(this);
}


antlrcpp::Any PnfCParser::ConstantExpressionContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitConstantExpression(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::ConstantExpressionContext* PnfCParser::constantExpression() {
  ConstantExpressionContext *_localctx = _tracker.createInstance<ConstantExpressionContext>(_ctx, getState());
  enterRule(_localctx, 16, PnfCParser::RuleConstantExpression);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(565);
    conditionalExpression();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- DeclarationContext ------------------------------------------------------------------

PnfCParser::DeclarationContext::DeclarationContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Aux_rule__declaration_3Context* PnfCParser::DeclarationContext::aux_rule__declaration_3() {
  return getRuleContext<PnfCParser::Aux_rule__declaration_3Context>(0);
}

PnfCParser::StaticAssertDeclarationContext* PnfCParser::DeclarationContext::staticAssertDeclaration() {
  return getRuleContext<PnfCParser::StaticAssertDeclarationContext>(0);
}

PnfCParser::AsmStatementContext* PnfCParser::DeclarationContext::asmStatement() {
  return getRuleContext<PnfCParser::AsmStatementContext>(0);
}


size_t PnfCParser::DeclarationContext::getRuleIndex() const {
  return PnfCParser::RuleDeclaration;
}

void PnfCParser::DeclarationContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterDeclaration(this);
}

void PnfCParser::DeclarationContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitDeclaration(this);
}


antlrcpp::Any PnfCParser::DeclarationContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitDeclaration(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::DeclarationContext* PnfCParser::declaration() {
  DeclarationContext *_localctx = _tracker.createInstance<DeclarationContext>(_ctx, getState());
  enterRule(_localctx, 18, PnfCParser::RuleDeclaration);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(570);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case PnfCParser::T__0:
      case PnfCParser::T__1:
      case PnfCParser::T__2:
      case PnfCParser::T__6:
      case PnfCParser::T__8:
      case PnfCParser::T__9:
      case PnfCParser::T__12:
      case PnfCParser::T__13:
      case PnfCParser::Auto:
      case PnfCParser::Char:
      case PnfCParser::Const:
      case PnfCParser::Nonnull:
      case PnfCParser::Nullable:
      case PnfCParser::Double:
      case PnfCParser::Enum:
      case PnfCParser::Extern:
      case PnfCParser::Float:
      case PnfCParser::Inline:
      case PnfCParser::Int:
      case PnfCParser::Long:
      case PnfCParser::Register:
      case PnfCParser::Restrict:
      case PnfCParser::Restrict_gcc:
      case PnfCParser::Restrict_gcc2:
      case PnfCParser::Extension_gcc:
      case PnfCParser::Short:
      case PnfCParser::Signed:
      case PnfCParser::Static:
      case PnfCParser::Struct:
      case PnfCParser::Typedef:
      case PnfCParser::Union:
      case PnfCParser::Unsigned:
      case PnfCParser::Void:
      case PnfCParser::Volatile:
      case PnfCParser::Alignas:
      case PnfCParser::Atomic:
      case PnfCParser::Bool:
      case PnfCParser::Complex:
      case PnfCParser::Noreturn:
      case PnfCParser::ThreadLocal:
      case PnfCParser::Identifier: {
        enterOuterAlt(_localctx, 1);
        setState(567);
        aux_rule__declaration_3();
        break;
      }

      case PnfCParser::StaticAssert: {
        enterOuterAlt(_localctx, 2);
        setState(568);
        staticAssertDeclaration();
        break;
      }

      case PnfCParser::T__3:
      case PnfCParser::T__4:
      case PnfCParser::T__5: {
        enterOuterAlt(_localctx, 3);
        setState(569);
        asmStatement();
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- DeclarationSpecifiersContext ------------------------------------------------------------------

PnfCParser::DeclarationSpecifiersContext::DeclarationSpecifiersContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfCParser::DeclarationSpecifierContext *> PnfCParser::DeclarationSpecifiersContext::declarationSpecifier() {
  return getRuleContexts<PnfCParser::DeclarationSpecifierContext>();
}

PnfCParser::DeclarationSpecifierContext* PnfCParser::DeclarationSpecifiersContext::declarationSpecifier(size_t i) {
  return getRuleContext<PnfCParser::DeclarationSpecifierContext>(i);
}


size_t PnfCParser::DeclarationSpecifiersContext::getRuleIndex() const {
  return PnfCParser::RuleDeclarationSpecifiers;
}

void PnfCParser::DeclarationSpecifiersContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterDeclarationSpecifiers(this);
}

void PnfCParser::DeclarationSpecifiersContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitDeclarationSpecifiers(this);
}


antlrcpp::Any PnfCParser::DeclarationSpecifiersContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitDeclarationSpecifiers(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::DeclarationSpecifiersContext* PnfCParser::declarationSpecifiers() {
  DeclarationSpecifiersContext *_localctx = _tracker.createInstance<DeclarationSpecifiersContext>(_ctx, getState());
  enterRule(_localctx, 20, PnfCParser::RuleDeclarationSpecifiers);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    size_t alt;
    enterOuterAlt(_localctx, 1);
    setState(573); 
    _errHandler->sync(this);
    alt = 1;
    do {
      switch (alt) {
        case 1: {
              setState(572);
              declarationSpecifier();
              break;
            }

      default:
        throw NoViableAltException(this);
      }
      setState(575); 
      _errHandler->sync(this);
      alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 4, _ctx);
    } while (alt != 2 && alt != atn::ATN::INVALID_ALT_NUMBER);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- InitDeclaratorContext ------------------------------------------------------------------

PnfCParser::InitDeclaratorContext::InitDeclaratorContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::DeclaratorContext* PnfCParser::InitDeclaratorContext::declarator() {
  return getRuleContext<PnfCParser::DeclaratorContext>(0);
}

PnfCParser::Optional__initDeclarator_2Context* PnfCParser::InitDeclaratorContext::optional__initDeclarator_2() {
  return getRuleContext<PnfCParser::Optional__initDeclarator_2Context>(0);
}


size_t PnfCParser::InitDeclaratorContext::getRuleIndex() const {
  return PnfCParser::RuleInitDeclarator;
}

void PnfCParser::InitDeclaratorContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterInitDeclarator(this);
}

void PnfCParser::InitDeclaratorContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitInitDeclarator(this);
}


antlrcpp::Any PnfCParser::InitDeclaratorContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitInitDeclarator(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::InitDeclaratorContext* PnfCParser::initDeclarator() {
  InitDeclaratorContext *_localctx = _tracker.createInstance<InitDeclaratorContext>(_ctx, getState());
  enterRule(_localctx, 22, PnfCParser::RuleInitDeclarator);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(577);
    declarator();
    setState(578);
    optional__initDeclarator_2();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- TypeSpecifierContext ------------------------------------------------------------------

PnfCParser::TypeSpecifierContext::TypeSpecifierContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::TypeSpecifierContext::Void() {
  return getToken(PnfCParser::Void, 0);
}

tree::TerminalNode* PnfCParser::TypeSpecifierContext::Char() {
  return getToken(PnfCParser::Char, 0);
}

tree::TerminalNode* PnfCParser::TypeSpecifierContext::Short() {
  return getToken(PnfCParser::Short, 0);
}

tree::TerminalNode* PnfCParser::TypeSpecifierContext::Int() {
  return getToken(PnfCParser::Int, 0);
}

tree::TerminalNode* PnfCParser::TypeSpecifierContext::Long() {
  return getToken(PnfCParser::Long, 0);
}

tree::TerminalNode* PnfCParser::TypeSpecifierContext::Float() {
  return getToken(PnfCParser::Float, 0);
}

tree::TerminalNode* PnfCParser::TypeSpecifierContext::Double() {
  return getToken(PnfCParser::Double, 0);
}

tree::TerminalNode* PnfCParser::TypeSpecifierContext::Signed() {
  return getToken(PnfCParser::Signed, 0);
}

tree::TerminalNode* PnfCParser::TypeSpecifierContext::Unsigned() {
  return getToken(PnfCParser::Unsigned, 0);
}

tree::TerminalNode* PnfCParser::TypeSpecifierContext::Bool() {
  return getToken(PnfCParser::Bool, 0);
}

tree::TerminalNode* PnfCParser::TypeSpecifierContext::Complex() {
  return getToken(PnfCParser::Complex, 0);
}

PnfCParser::AtomicTypeSpecifierContext* PnfCParser::TypeSpecifierContext::atomicTypeSpecifier() {
  return getRuleContext<PnfCParser::AtomicTypeSpecifierContext>(0);
}

PnfCParser::StructOrUnionSpecifierContext* PnfCParser::TypeSpecifierContext::structOrUnionSpecifier() {
  return getRuleContext<PnfCParser::StructOrUnionSpecifierContext>(0);
}

PnfCParser::EnumSpecifierContext* PnfCParser::TypeSpecifierContext::enumSpecifier() {
  return getRuleContext<PnfCParser::EnumSpecifierContext>(0);
}

PnfCParser::TypedefNameContext* PnfCParser::TypeSpecifierContext::typedefName() {
  return getRuleContext<PnfCParser::TypedefNameContext>(0);
}

PnfCParser::Aux_rule__typeSpecifier_3Context* PnfCParser::TypeSpecifierContext::aux_rule__typeSpecifier_3() {
  return getRuleContext<PnfCParser::Aux_rule__typeSpecifier_3Context>(0);
}


size_t PnfCParser::TypeSpecifierContext::getRuleIndex() const {
  return PnfCParser::RuleTypeSpecifier;
}

void PnfCParser::TypeSpecifierContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterTypeSpecifier(this);
}

void PnfCParser::TypeSpecifierContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitTypeSpecifier(this);
}


antlrcpp::Any PnfCParser::TypeSpecifierContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitTypeSpecifier(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::TypeSpecifierContext* PnfCParser::typeSpecifier() {
  TypeSpecifierContext *_localctx = _tracker.createInstance<TypeSpecifierContext>(_ctx, getState());
  enterRule(_localctx, 24, PnfCParser::RuleTypeSpecifier);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(599);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case PnfCParser::Void: {
        enterOuterAlt(_localctx, 1);
        setState(580);
        match(PnfCParser::Void);
        break;
      }

      case PnfCParser::Char: {
        enterOuterAlt(_localctx, 2);
        setState(581);
        match(PnfCParser::Char);
        break;
      }

      case PnfCParser::Short: {
        enterOuterAlt(_localctx, 3);
        setState(582);
        match(PnfCParser::Short);
        break;
      }

      case PnfCParser::Int: {
        enterOuterAlt(_localctx, 4);
        setState(583);
        match(PnfCParser::Int);
        break;
      }

      case PnfCParser::Long: {
        enterOuterAlt(_localctx, 5);
        setState(584);
        match(PnfCParser::Long);
        break;
      }

      case PnfCParser::Float: {
        enterOuterAlt(_localctx, 6);
        setState(585);
        match(PnfCParser::Float);
        break;
      }

      case PnfCParser::Double: {
        enterOuterAlt(_localctx, 7);
        setState(586);
        match(PnfCParser::Double);
        break;
      }

      case PnfCParser::Signed: {
        enterOuterAlt(_localctx, 8);
        setState(587);
        match(PnfCParser::Signed);
        break;
      }

      case PnfCParser::Unsigned: {
        enterOuterAlt(_localctx, 9);
        setState(588);
        match(PnfCParser::Unsigned);
        break;
      }

      case PnfCParser::Bool: {
        enterOuterAlt(_localctx, 10);
        setState(589);
        match(PnfCParser::Bool);
        break;
      }

      case PnfCParser::Complex: {
        enterOuterAlt(_localctx, 11);
        setState(590);
        match(PnfCParser::Complex);
        break;
      }

      case PnfCParser::T__0: {
        enterOuterAlt(_localctx, 12);
        setState(591);
        match(PnfCParser::T__0);
        break;
      }

      case PnfCParser::T__1: {
        enterOuterAlt(_localctx, 13);
        setState(592);
        match(PnfCParser::T__1);
        break;
      }

      case PnfCParser::T__2: {
        enterOuterAlt(_localctx, 14);
        setState(593);
        match(PnfCParser::T__2);
        break;
      }

      case PnfCParser::Atomic: {
        enterOuterAlt(_localctx, 15);
        setState(594);
        atomicTypeSpecifier();
        break;
      }

      case PnfCParser::Struct:
      case PnfCParser::Union: {
        enterOuterAlt(_localctx, 16);
        setState(595);
        structOrUnionSpecifier();
        break;
      }

      case PnfCParser::Enum: {
        enterOuterAlt(_localctx, 17);
        setState(596);
        enumSpecifier();
        break;
      }

      case PnfCParser::Identifier: {
        enterOuterAlt(_localctx, 18);
        setState(597);
        typedefName();
        break;
      }

      case PnfCParser::T__12:
      case PnfCParser::Extension_gcc: {
        enterOuterAlt(_localctx, 19);
        setState(598);
        aux_rule__typeSpecifier_3();
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- StructOrUnionSpecifierContext ------------------------------------------------------------------

PnfCParser::StructOrUnionSpecifierContext::StructOrUnionSpecifierContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::StructOrUnionContext* PnfCParser::StructOrUnionSpecifierContext::structOrUnion() {
  return getRuleContext<PnfCParser::StructOrUnionContext>(0);
}

PnfCParser::Altnt_block__structOrUnionSpecifier_2Context* PnfCParser::StructOrUnionSpecifierContext::altnt_block__structOrUnionSpecifier_2() {
  return getRuleContext<PnfCParser::Altnt_block__structOrUnionSpecifier_2Context>(0);
}


size_t PnfCParser::StructOrUnionSpecifierContext::getRuleIndex() const {
  return PnfCParser::RuleStructOrUnionSpecifier;
}

void PnfCParser::StructOrUnionSpecifierContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterStructOrUnionSpecifier(this);
}

void PnfCParser::StructOrUnionSpecifierContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitStructOrUnionSpecifier(this);
}


antlrcpp::Any PnfCParser::StructOrUnionSpecifierContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitStructOrUnionSpecifier(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::StructOrUnionSpecifierContext* PnfCParser::structOrUnionSpecifier() {
  StructOrUnionSpecifierContext *_localctx = _tracker.createInstance<StructOrUnionSpecifierContext>(_ctx, getState());
  enterRule(_localctx, 26, PnfCParser::RuleStructOrUnionSpecifier);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(601);
    structOrUnion();
    setState(602);
    altnt_block__structOrUnionSpecifier_2();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- StructOrUnionContext ------------------------------------------------------------------

PnfCParser::StructOrUnionContext::StructOrUnionContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::StructOrUnionContext::Struct() {
  return getToken(PnfCParser::Struct, 0);
}

tree::TerminalNode* PnfCParser::StructOrUnionContext::Union() {
  return getToken(PnfCParser::Union, 0);
}


size_t PnfCParser::StructOrUnionContext::getRuleIndex() const {
  return PnfCParser::RuleStructOrUnion;
}

void PnfCParser::StructOrUnionContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterStructOrUnion(this);
}

void PnfCParser::StructOrUnionContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitStructOrUnion(this);
}


antlrcpp::Any PnfCParser::StructOrUnionContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitStructOrUnion(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::StructOrUnionContext* PnfCParser::structOrUnion() {
  StructOrUnionContext *_localctx = _tracker.createInstance<StructOrUnionContext>(_ctx, getState());
  enterRule(_localctx, 28, PnfCParser::RuleStructOrUnion);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(604);
    _la = _input->LA(1);
    if (!(_la == PnfCParser::Struct

    || _la == PnfCParser::Union)) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- SpecifierQualifierListContext ------------------------------------------------------------------

PnfCParser::SpecifierQualifierListContext::SpecifierQualifierListContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Altnt_block__specifierQualifierList_3Context* PnfCParser::SpecifierQualifierListContext::altnt_block__specifierQualifierList_3() {
  return getRuleContext<PnfCParser::Altnt_block__specifierQualifierList_3Context>(0);
}

PnfCParser::Optional__specifierQualifierList_1Context* PnfCParser::SpecifierQualifierListContext::optional__specifierQualifierList_1() {
  return getRuleContext<PnfCParser::Optional__specifierQualifierList_1Context>(0);
}


size_t PnfCParser::SpecifierQualifierListContext::getRuleIndex() const {
  return PnfCParser::RuleSpecifierQualifierList;
}

void PnfCParser::SpecifierQualifierListContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterSpecifierQualifierList(this);
}

void PnfCParser::SpecifierQualifierListContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitSpecifierQualifierList(this);
}


antlrcpp::Any PnfCParser::SpecifierQualifierListContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitSpecifierQualifierList(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::SpecifierQualifierListContext* PnfCParser::specifierQualifierList() {
  SpecifierQualifierListContext *_localctx = _tracker.createInstance<SpecifierQualifierListContext>(_ctx, getState());
  enterRule(_localctx, 30, PnfCParser::RuleSpecifierQualifierList);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(606);
    altnt_block__specifierQualifierList_3();
    setState(607);
    optional__specifierQualifierList_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- StructDeclaratorContext ------------------------------------------------------------------

PnfCParser::StructDeclaratorContext::StructDeclaratorContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::DeclaratorContext* PnfCParser::StructDeclaratorContext::declarator() {
  return getRuleContext<PnfCParser::DeclaratorContext>(0);
}

PnfCParser::Aux_rule__structDeclarator_2Context* PnfCParser::StructDeclaratorContext::aux_rule__structDeclarator_2() {
  return getRuleContext<PnfCParser::Aux_rule__structDeclarator_2Context>(0);
}


size_t PnfCParser::StructDeclaratorContext::getRuleIndex() const {
  return PnfCParser::RuleStructDeclarator;
}

void PnfCParser::StructDeclaratorContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterStructDeclarator(this);
}

void PnfCParser::StructDeclaratorContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitStructDeclarator(this);
}


antlrcpp::Any PnfCParser::StructDeclaratorContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitStructDeclarator(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::StructDeclaratorContext* PnfCParser::structDeclarator() {
  StructDeclaratorContext *_localctx = _tracker.createInstance<StructDeclaratorContext>(_ctx, getState());
  enterRule(_localctx, 32, PnfCParser::RuleStructDeclarator);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(611);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 6, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(609);
      declarator();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(610);
      aux_rule__structDeclarator_2();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- EnumSpecifierContext ------------------------------------------------------------------

PnfCParser::EnumSpecifierContext::EnumSpecifierContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::EnumSpecifierContext::Enum() {
  return getToken(PnfCParser::Enum, 0);
}

PnfCParser::Altnt_block__enumSpecifier_3Context* PnfCParser::EnumSpecifierContext::altnt_block__enumSpecifier_3() {
  return getRuleContext<PnfCParser::Altnt_block__enumSpecifier_3Context>(0);
}


size_t PnfCParser::EnumSpecifierContext::getRuleIndex() const {
  return PnfCParser::RuleEnumSpecifier;
}

void PnfCParser::EnumSpecifierContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterEnumSpecifier(this);
}

void PnfCParser::EnumSpecifierContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitEnumSpecifier(this);
}


antlrcpp::Any PnfCParser::EnumSpecifierContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitEnumSpecifier(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::EnumSpecifierContext* PnfCParser::enumSpecifier() {
  EnumSpecifierContext *_localctx = _tracker.createInstance<EnumSpecifierContext>(_ctx, getState());
  enterRule(_localctx, 34, PnfCParser::RuleEnumSpecifier);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(613);
    match(PnfCParser::Enum);
    setState(614);
    altnt_block__enumSpecifier_3();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- EnumeratorContext ------------------------------------------------------------------

PnfCParser::EnumeratorContext::EnumeratorContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::TypedefNameContext* PnfCParser::EnumeratorContext::typedefName() {
  return getRuleContext<PnfCParser::TypedefNameContext>(0);
}

PnfCParser::Optional__enumerator_2Context* PnfCParser::EnumeratorContext::optional__enumerator_2() {
  return getRuleContext<PnfCParser::Optional__enumerator_2Context>(0);
}


size_t PnfCParser::EnumeratorContext::getRuleIndex() const {
  return PnfCParser::RuleEnumerator;
}

void PnfCParser::EnumeratorContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterEnumerator(this);
}

void PnfCParser::EnumeratorContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitEnumerator(this);
}


antlrcpp::Any PnfCParser::EnumeratorContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitEnumerator(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::EnumeratorContext* PnfCParser::enumerator() {
  EnumeratorContext *_localctx = _tracker.createInstance<EnumeratorContext>(_ctx, getState());
  enterRule(_localctx, 36, PnfCParser::RuleEnumerator);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(616);
    typedefName();
    setState(617);
    optional__enumerator_2();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- AtomicTypeSpecifierContext ------------------------------------------------------------------

PnfCParser::AtomicTypeSpecifierContext::AtomicTypeSpecifierContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::AtomicTypeSpecifierContext::Atomic() {
  return getToken(PnfCParser::Atomic, 0);
}

tree::TerminalNode* PnfCParser::AtomicTypeSpecifierContext::LeftParen() {
  return getToken(PnfCParser::LeftParen, 0);
}

PnfCParser::TypeNameContext* PnfCParser::AtomicTypeSpecifierContext::typeName() {
  return getRuleContext<PnfCParser::TypeNameContext>(0);
}

tree::TerminalNode* PnfCParser::AtomicTypeSpecifierContext::RightParen() {
  return getToken(PnfCParser::RightParen, 0);
}


size_t PnfCParser::AtomicTypeSpecifierContext::getRuleIndex() const {
  return PnfCParser::RuleAtomicTypeSpecifier;
}

void PnfCParser::AtomicTypeSpecifierContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAtomicTypeSpecifier(this);
}

void PnfCParser::AtomicTypeSpecifierContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAtomicTypeSpecifier(this);
}


antlrcpp::Any PnfCParser::AtomicTypeSpecifierContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAtomicTypeSpecifier(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::AtomicTypeSpecifierContext* PnfCParser::atomicTypeSpecifier() {
  AtomicTypeSpecifierContext *_localctx = _tracker.createInstance<AtomicTypeSpecifierContext>(_ctx, getState());
  enterRule(_localctx, 38, PnfCParser::RuleAtomicTypeSpecifier);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(619);
    match(PnfCParser::Atomic);
    setState(620);
    match(PnfCParser::LeftParen);
    setState(621);
    typeName();
    setState(622);
    match(PnfCParser::RightParen);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- TypeQualifierContext ------------------------------------------------------------------

PnfCParser::TypeQualifierContext::TypeQualifierContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::TypeQualifierContext::Const() {
  return getToken(PnfCParser::Const, 0);
}

tree::TerminalNode* PnfCParser::TypeQualifierContext::Restrict() {
  return getToken(PnfCParser::Restrict, 0);
}

tree::TerminalNode* PnfCParser::TypeQualifierContext::Restrict_gcc() {
  return getToken(PnfCParser::Restrict_gcc, 0);
}

tree::TerminalNode* PnfCParser::TypeQualifierContext::Restrict_gcc2() {
  return getToken(PnfCParser::Restrict_gcc2, 0);
}

tree::TerminalNode* PnfCParser::TypeQualifierContext::Volatile() {
  return getToken(PnfCParser::Volatile, 0);
}

tree::TerminalNode* PnfCParser::TypeQualifierContext::Atomic() {
  return getToken(PnfCParser::Atomic, 0);
}

tree::TerminalNode* PnfCParser::TypeQualifierContext::Nonnull() {
  return getToken(PnfCParser::Nonnull, 0);
}

tree::TerminalNode* PnfCParser::TypeQualifierContext::Nullable() {
  return getToken(PnfCParser::Nullable, 0);
}


size_t PnfCParser::TypeQualifierContext::getRuleIndex() const {
  return PnfCParser::RuleTypeQualifier;
}

void PnfCParser::TypeQualifierContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterTypeQualifier(this);
}

void PnfCParser::TypeQualifierContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitTypeQualifier(this);
}


antlrcpp::Any PnfCParser::TypeQualifierContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitTypeQualifier(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::TypeQualifierContext* PnfCParser::typeQualifier() {
  TypeQualifierContext *_localctx = _tracker.createInstance<TypeQualifierContext>(_ctx, getState());
  enterRule(_localctx, 40, PnfCParser::RuleTypeQualifier);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(624);
    _la = _input->LA(1);
    if (!((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << PnfCParser::Const)
      | (1ULL << PnfCParser::Nonnull)
      | (1ULL << PnfCParser::Nullable)
      | (1ULL << PnfCParser::Restrict)
      | (1ULL << PnfCParser::Restrict_gcc)
      | (1ULL << PnfCParser::Restrict_gcc2)
      | (1ULL << PnfCParser::Volatile)
      | (1ULL << PnfCParser::Atomic))) != 0))) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- AlignmentSpecifierContext ------------------------------------------------------------------

PnfCParser::AlignmentSpecifierContext::AlignmentSpecifierContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::AlignmentSpecifierContext::Alignas() {
  return getToken(PnfCParser::Alignas, 0);
}

tree::TerminalNode* PnfCParser::AlignmentSpecifierContext::LeftParen() {
  return getToken(PnfCParser::LeftParen, 0);
}

PnfCParser::Altnt_block__alignmentSpecifier_1Context* PnfCParser::AlignmentSpecifierContext::altnt_block__alignmentSpecifier_1() {
  return getRuleContext<PnfCParser::Altnt_block__alignmentSpecifier_1Context>(0);
}

tree::TerminalNode* PnfCParser::AlignmentSpecifierContext::RightParen() {
  return getToken(PnfCParser::RightParen, 0);
}


size_t PnfCParser::AlignmentSpecifierContext::getRuleIndex() const {
  return PnfCParser::RuleAlignmentSpecifier;
}

void PnfCParser::AlignmentSpecifierContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAlignmentSpecifier(this);
}

void PnfCParser::AlignmentSpecifierContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAlignmentSpecifier(this);
}


antlrcpp::Any PnfCParser::AlignmentSpecifierContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAlignmentSpecifier(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::AlignmentSpecifierContext* PnfCParser::alignmentSpecifier() {
  AlignmentSpecifierContext *_localctx = _tracker.createInstance<AlignmentSpecifierContext>(_ctx, getState());
  enterRule(_localctx, 42, PnfCParser::RuleAlignmentSpecifier);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(626);
    match(PnfCParser::Alignas);
    setState(627);
    match(PnfCParser::LeftParen);
    setState(628);
    altnt_block__alignmentSpecifier_1();
    setState(629);
    match(PnfCParser::RightParen);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- DeclaratorContext ------------------------------------------------------------------

PnfCParser::DeclaratorContext::DeclaratorContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Optional__declarator_1Context* PnfCParser::DeclaratorContext::optional__declarator_1() {
  return getRuleContext<PnfCParser::Optional__declarator_1Context>(0);
}

PnfCParser::DirectDeclaratorContext* PnfCParser::DeclaratorContext::directDeclarator() {
  return getRuleContext<PnfCParser::DirectDeclaratorContext>(0);
}

PnfCParser::Kleene_star__declarator_2Context* PnfCParser::DeclaratorContext::kleene_star__declarator_2() {
  return getRuleContext<PnfCParser::Kleene_star__declarator_2Context>(0);
}


size_t PnfCParser::DeclaratorContext::getRuleIndex() const {
  return PnfCParser::RuleDeclarator;
}

void PnfCParser::DeclaratorContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterDeclarator(this);
}

void PnfCParser::DeclaratorContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitDeclarator(this);
}


antlrcpp::Any PnfCParser::DeclaratorContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitDeclarator(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::DeclaratorContext* PnfCParser::declarator() {
  DeclaratorContext *_localctx = _tracker.createInstance<DeclaratorContext>(_ctx, getState());
  enterRule(_localctx, 44, PnfCParser::RuleDeclarator);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(631);
    optional__declarator_1();
    setState(632);
    directDeclarator();
    setState(633);
    kleene_star__declarator_2();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- GccDeclaratorExtensionContext ------------------------------------------------------------------

PnfCParser::GccDeclaratorExtensionContext::GccDeclaratorExtensionContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Aux_rule__gccDeclaratorExtension_2Context* PnfCParser::GccDeclaratorExtensionContext::aux_rule__gccDeclaratorExtension_2() {
  return getRuleContext<PnfCParser::Aux_rule__gccDeclaratorExtension_2Context>(0);
}

PnfCParser::GccAttributeSpecifierContext* PnfCParser::GccDeclaratorExtensionContext::gccAttributeSpecifier() {
  return getRuleContext<PnfCParser::GccAttributeSpecifierContext>(0);
}


size_t PnfCParser::GccDeclaratorExtensionContext::getRuleIndex() const {
  return PnfCParser::RuleGccDeclaratorExtension;
}

void PnfCParser::GccDeclaratorExtensionContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterGccDeclaratorExtension(this);
}

void PnfCParser::GccDeclaratorExtensionContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitGccDeclaratorExtension(this);
}


antlrcpp::Any PnfCParser::GccDeclaratorExtensionContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitGccDeclaratorExtension(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::GccDeclaratorExtensionContext* PnfCParser::gccDeclaratorExtension() {
  GccDeclaratorExtensionContext *_localctx = _tracker.createInstance<GccDeclaratorExtensionContext>(_ctx, getState());
  enterRule(_localctx, 46, PnfCParser::RuleGccDeclaratorExtension);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(637);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case PnfCParser::T__3:
      case PnfCParser::T__4:
      case PnfCParser::T__5: {
        enterOuterAlt(_localctx, 1);
        setState(635);
        aux_rule__gccDeclaratorExtension_2();
        break;
      }

      case PnfCParser::T__6: {
        enterOuterAlt(_localctx, 2);
        setState(636);
        gccAttributeSpecifier();
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- AsmKeywordContext ------------------------------------------------------------------

PnfCParser::AsmKeywordContext::AsmKeywordContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t PnfCParser::AsmKeywordContext::getRuleIndex() const {
  return PnfCParser::RuleAsmKeyword;
}

void PnfCParser::AsmKeywordContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAsmKeyword(this);
}

void PnfCParser::AsmKeywordContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAsmKeyword(this);
}


antlrcpp::Any PnfCParser::AsmKeywordContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAsmKeyword(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::AsmKeywordContext* PnfCParser::asmKeyword() {
  AsmKeywordContext *_localctx = _tracker.createInstance<AsmKeywordContext>(_ctx, getState());
  enterRule(_localctx, 48, PnfCParser::RuleAsmKeyword);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(639);
    _la = _input->LA(1);
    if (!((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << PnfCParser::T__3)
      | (1ULL << PnfCParser::T__4)
      | (1ULL << PnfCParser::T__5))) != 0))) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- GccAttributeSpecifierContext ------------------------------------------------------------------

PnfCParser::GccAttributeSpecifierContext::GccAttributeSpecifierContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<tree::TerminalNode *> PnfCParser::GccAttributeSpecifierContext::LeftParen() {
  return getTokens(PnfCParser::LeftParen);
}

tree::TerminalNode* PnfCParser::GccAttributeSpecifierContext::LeftParen(size_t i) {
  return getToken(PnfCParser::LeftParen, i);
}

PnfCParser::GccAttributeListContext* PnfCParser::GccAttributeSpecifierContext::gccAttributeList() {
  return getRuleContext<PnfCParser::GccAttributeListContext>(0);
}

std::vector<tree::TerminalNode *> PnfCParser::GccAttributeSpecifierContext::RightParen() {
  return getTokens(PnfCParser::RightParen);
}

tree::TerminalNode* PnfCParser::GccAttributeSpecifierContext::RightParen(size_t i) {
  return getToken(PnfCParser::RightParen, i);
}


size_t PnfCParser::GccAttributeSpecifierContext::getRuleIndex() const {
  return PnfCParser::RuleGccAttributeSpecifier;
}

void PnfCParser::GccAttributeSpecifierContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterGccAttributeSpecifier(this);
}

void PnfCParser::GccAttributeSpecifierContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitGccAttributeSpecifier(this);
}


antlrcpp::Any PnfCParser::GccAttributeSpecifierContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitGccAttributeSpecifier(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::GccAttributeSpecifierContext* PnfCParser::gccAttributeSpecifier() {
  GccAttributeSpecifierContext *_localctx = _tracker.createInstance<GccAttributeSpecifierContext>(_ctx, getState());
  enterRule(_localctx, 50, PnfCParser::RuleGccAttributeSpecifier);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(641);
    match(PnfCParser::T__6);
    setState(642);
    match(PnfCParser::LeftParen);
    setState(643);
    match(PnfCParser::LeftParen);
    setState(644);
    gccAttributeList();
    setState(645);
    match(PnfCParser::RightParen);
    setState(646);
    match(PnfCParser::RightParen);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- GccAttributeListContext ------------------------------------------------------------------

PnfCParser::GccAttributeListContext::GccAttributeListContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Aux_rule__gccAttributeList_3Context* PnfCParser::GccAttributeListContext::aux_rule__gccAttributeList_3() {
  return getRuleContext<PnfCParser::Aux_rule__gccAttributeList_3Context>(0);
}


size_t PnfCParser::GccAttributeListContext::getRuleIndex() const {
  return PnfCParser::RuleGccAttributeList;
}

void PnfCParser::GccAttributeListContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterGccAttributeList(this);
}

void PnfCParser::GccAttributeListContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitGccAttributeList(this);
}


antlrcpp::Any PnfCParser::GccAttributeListContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitGccAttributeList(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::GccAttributeListContext* PnfCParser::gccAttributeList() {
  GccAttributeListContext *_localctx = _tracker.createInstance<GccAttributeListContext>(_ctx, getState());
  enterRule(_localctx, 52, PnfCParser::RuleGccAttributeList);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(649);
    _errHandler->sync(this);

    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 8, _ctx)) {
    case 1: {
      setState(648);
      aux_rule__gccAttributeList_3();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- GccAttributeContext ------------------------------------------------------------------

PnfCParser::GccAttributeContext::GccAttributeContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Aux_rule__gccAttribute_4Context* PnfCParser::GccAttributeContext::aux_rule__gccAttribute_4() {
  return getRuleContext<PnfCParser::Aux_rule__gccAttribute_4Context>(0);
}


size_t PnfCParser::GccAttributeContext::getRuleIndex() const {
  return PnfCParser::RuleGccAttribute;
}

void PnfCParser::GccAttributeContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterGccAttribute(this);
}

void PnfCParser::GccAttributeContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitGccAttribute(this);
}


antlrcpp::Any PnfCParser::GccAttributeContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitGccAttribute(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::GccAttributeContext* PnfCParser::gccAttribute() {
  GccAttributeContext *_localctx = _tracker.createInstance<GccAttributeContext>(_ctx, getState());
  enterRule(_localctx, 54, PnfCParser::RuleGccAttribute);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(652);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if ((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << PnfCParser::T__0)
      | (1ULL << PnfCParser::T__1)
      | (1ULL << PnfCParser::T__2)
      | (1ULL << PnfCParser::T__3)
      | (1ULL << PnfCParser::T__4)
      | (1ULL << PnfCParser::T__5)
      | (1ULL << PnfCParser::T__6)
      | (1ULL << PnfCParser::T__7)
      | (1ULL << PnfCParser::T__8)
      | (1ULL << PnfCParser::T__9)
      | (1ULL << PnfCParser::T__10)
      | (1ULL << PnfCParser::T__11)
      | (1ULL << PnfCParser::T__12)
      | (1ULL << PnfCParser::T__13)
      | (1ULL << PnfCParser::IncludeDirective)
      | (1ULL << PnfCParser::Auto)
      | (1ULL << PnfCParser::Break)
      | (1ULL << PnfCParser::Case)
      | (1ULL << PnfCParser::Char)
      | (1ULL << PnfCParser::Const)
      | (1ULL << PnfCParser::Nonnull)
      | (1ULL << PnfCParser::Nullable)
      | (1ULL << PnfCParser::Continue)
      | (1ULL << PnfCParser::Default)
      | (1ULL << PnfCParser::Do)
      | (1ULL << PnfCParser::Double)
      | (1ULL << PnfCParser::Else)
      | (1ULL << PnfCParser::Enum)
      | (1ULL << PnfCParser::Extern)
      | (1ULL << PnfCParser::Float)
      | (1ULL << PnfCParser::For)
      | (1ULL << PnfCParser::Goto)
      | (1ULL << PnfCParser::If)
      | (1ULL << PnfCParser::Inline)
      | (1ULL << PnfCParser::Int)
      | (1ULL << PnfCParser::Long)
      | (1ULL << PnfCParser::Register)
      | (1ULL << PnfCParser::Restrict)
      | (1ULL << PnfCParser::Restrict_gcc)
      | (1ULL << PnfCParser::Restrict_gcc2)
      | (1ULL << PnfCParser::Extension_gcc)
      | (1ULL << PnfCParser::Return)
      | (1ULL << PnfCParser::Short)
      | (1ULL << PnfCParser::Signed)
      | (1ULL << PnfCParser::Sizeof)
      | (1ULL << PnfCParser::Static)
      | (1ULL << PnfCParser::Struct)
      | (1ULL << PnfCParser::Switch)
      | (1ULL << PnfCParser::Typedef)
      | (1ULL << PnfCParser::Union)
      | (1ULL << PnfCParser::Unsigned)
      | (1ULL << PnfCParser::Void)
      | (1ULL << PnfCParser::Volatile)
      | (1ULL << PnfCParser::While)
      | (1ULL << PnfCParser::Alignas)
      | (1ULL << PnfCParser::Alignof)
      | (1ULL << PnfCParser::Alignof_gcc)
      | (1ULL << PnfCParser::Atomic)
      | (1ULL << PnfCParser::Bool)
      | (1ULL << PnfCParser::Complex)
      | (1ULL << PnfCParser::Generic)
      | (1ULL << PnfCParser::Imaginary)
      | (1ULL << PnfCParser::Noreturn))) != 0) || ((((_la - 64) & ~ 0x3fULL) == 0) &&
      ((1ULL << (_la - 64)) & ((1ULL << (PnfCParser::StaticAssert - 64))
      | (1ULL << (PnfCParser::ThreadLocal - 64))
      | (1ULL << (PnfCParser::LeftBracket - 64))
      | (1ULL << (PnfCParser::RightBracket - 64))
      | (1ULL << (PnfCParser::LeftBrace - 64))
      | (1ULL << (PnfCParser::RightBrace - 64))
      | (1ULL << (PnfCParser::Less - 64))
      | (1ULL << (PnfCParser::LessEqual - 64))
      | (1ULL << (PnfCParser::Greater - 64))
      | (1ULL << (PnfCParser::GreaterEqual - 64))
      | (1ULL << (PnfCParser::LeftShift - 64))
      | (1ULL << (PnfCParser::RightShift - 64))
      | (1ULL << (PnfCParser::Plus - 64))
      | (1ULL << (PnfCParser::PlusPlus - 64))
      | (1ULL << (PnfCParser::Minus - 64))
      | (1ULL << (PnfCParser::MinusMinus - 64))
      | (1ULL << (PnfCParser::Star - 64))
      | (1ULL << (PnfCParser::Div - 64))
      | (1ULL << (PnfCParser::Mod - 64))
      | (1ULL << (PnfCParser::And - 64))
      | (1ULL << (PnfCParser::Or - 64))
      | (1ULL << (PnfCParser::AndAnd - 64))
      | (1ULL << (PnfCParser::OrOr - 64))
      | (1ULL << (PnfCParser::Caret - 64))
      | (1ULL << (PnfCParser::Not - 64))
      | (1ULL << (PnfCParser::Tilde - 64))
      | (1ULL << (PnfCParser::Question - 64))
      | (1ULL << (PnfCParser::Colon - 64))
      | (1ULL << (PnfCParser::Semi - 64))
      | (1ULL << (PnfCParser::Assign - 64))
      | (1ULL << (PnfCParser::StarAssign - 64))
      | (1ULL << (PnfCParser::DivAssign - 64))
      | (1ULL << (PnfCParser::ModAssign - 64))
      | (1ULL << (PnfCParser::PlusAssign - 64))
      | (1ULL << (PnfCParser::MinusAssign - 64))
      | (1ULL << (PnfCParser::LeftShiftAssign - 64))
      | (1ULL << (PnfCParser::RightShiftAssign - 64))
      | (1ULL << (PnfCParser::AndAssign - 64))
      | (1ULL << (PnfCParser::XorAssign - 64))
      | (1ULL << (PnfCParser::OrAssign - 64))
      | (1ULL << (PnfCParser::Equal - 64))
      | (1ULL << (PnfCParser::NotEqual - 64))
      | (1ULL << (PnfCParser::Arrow - 64))
      | (1ULL << (PnfCParser::Dot - 64))
      | (1ULL << (PnfCParser::Ellipsis - 64))
      | (1ULL << (PnfCParser::Identifier - 64))
      | (1ULL << (PnfCParser::Constant - 64))
      | (1ULL << (PnfCParser::StringLiteral - 64))
      | (1ULL << (PnfCParser::ComplexDefine - 64))
      | (1ULL << (PnfCParser::AsmBlock - 64))
      | (1ULL << (PnfCParser::LineAfterPreprocessing - 64))
      | (1ULL << (PnfCParser::LineDirective - 64))
      | (1ULL << (PnfCParser::PragmaDirective - 64))
      | (1ULL << (PnfCParser::Whitespace - 64))
      | (1ULL << (PnfCParser::Newline - 64))
      | (1ULL << (PnfCParser::BlockComment - 64))
      | (1ULL << (PnfCParser::LineComment - 64)))) != 0)) {
      setState(651);
      aux_rule__gccAttribute_4();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- PointerContext ------------------------------------------------------------------

PnfCParser::PointerContext::PointerContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Altnt_block__pointer_8Context* PnfCParser::PointerContext::altnt_block__pointer_8() {
  return getRuleContext<PnfCParser::Altnt_block__pointer_8Context>(0);
}

PnfCParser::Altnt_block__pointer_5Context* PnfCParser::PointerContext::altnt_block__pointer_5() {
  return getRuleContext<PnfCParser::Altnt_block__pointer_5Context>(0);
}


size_t PnfCParser::PointerContext::getRuleIndex() const {
  return PnfCParser::RulePointer;
}

void PnfCParser::PointerContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterPointer(this);
}

void PnfCParser::PointerContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitPointer(this);
}


antlrcpp::Any PnfCParser::PointerContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitPointer(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::PointerContext* PnfCParser::pointer() {
  PointerContext *_localctx = _tracker.createInstance<PointerContext>(_ctx, getState());
  enterRule(_localctx, 56, PnfCParser::RulePointer);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(654);
    altnt_block__pointer_8();
    setState(655);
    altnt_block__pointer_5();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ParameterTypeListContext ------------------------------------------------------------------

PnfCParser::ParameterTypeListContext::ParameterTypeListContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::ParameterListContext* PnfCParser::ParameterTypeListContext::parameterList() {
  return getRuleContext<PnfCParser::ParameterListContext>(0);
}

PnfCParser::Optional__parameterTypeList_2Context* PnfCParser::ParameterTypeListContext::optional__parameterTypeList_2() {
  return getRuleContext<PnfCParser::Optional__parameterTypeList_2Context>(0);
}


size_t PnfCParser::ParameterTypeListContext::getRuleIndex() const {
  return PnfCParser::RuleParameterTypeList;
}

void PnfCParser::ParameterTypeListContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterParameterTypeList(this);
}

void PnfCParser::ParameterTypeListContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitParameterTypeList(this);
}


antlrcpp::Any PnfCParser::ParameterTypeListContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitParameterTypeList(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::ParameterTypeListContext* PnfCParser::parameterTypeList() {
  ParameterTypeListContext *_localctx = _tracker.createInstance<ParameterTypeListContext>(_ctx, getState());
  enterRule(_localctx, 58, PnfCParser::RuleParameterTypeList);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(657);
    parameterList();
    setState(658);
    optional__parameterTypeList_2();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ParameterDeclarationContext ------------------------------------------------------------------

PnfCParser::ParameterDeclarationContext::ParameterDeclarationContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::DeclarationSpecifiersContext* PnfCParser::ParameterDeclarationContext::declarationSpecifiers() {
  return getRuleContext<PnfCParser::DeclarationSpecifiersContext>(0);
}

PnfCParser::Altnt_block__parameterDeclaration_2Context* PnfCParser::ParameterDeclarationContext::altnt_block__parameterDeclaration_2() {
  return getRuleContext<PnfCParser::Altnt_block__parameterDeclaration_2Context>(0);
}


size_t PnfCParser::ParameterDeclarationContext::getRuleIndex() const {
  return PnfCParser::RuleParameterDeclaration;
}

void PnfCParser::ParameterDeclarationContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterParameterDeclaration(this);
}

void PnfCParser::ParameterDeclarationContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitParameterDeclaration(this);
}


antlrcpp::Any PnfCParser::ParameterDeclarationContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitParameterDeclaration(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::ParameterDeclarationContext* PnfCParser::parameterDeclaration() {
  ParameterDeclarationContext *_localctx = _tracker.createInstance<ParameterDeclarationContext>(_ctx, getState());
  enterRule(_localctx, 60, PnfCParser::RuleParameterDeclaration);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(660);
    declarationSpecifiers();
    setState(661);
    altnt_block__parameterDeclaration_2();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- TypeNameContext ------------------------------------------------------------------

PnfCParser::TypeNameContext::TypeNameContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::SpecifierQualifierListContext* PnfCParser::TypeNameContext::specifierQualifierList() {
  return getRuleContext<PnfCParser::SpecifierQualifierListContext>(0);
}

PnfCParser::Optional__typeName_1Context* PnfCParser::TypeNameContext::optional__typeName_1() {
  return getRuleContext<PnfCParser::Optional__typeName_1Context>(0);
}


size_t PnfCParser::TypeNameContext::getRuleIndex() const {
  return PnfCParser::RuleTypeName;
}

void PnfCParser::TypeNameContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterTypeName(this);
}

void PnfCParser::TypeNameContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitTypeName(this);
}


antlrcpp::Any PnfCParser::TypeNameContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitTypeName(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::TypeNameContext* PnfCParser::typeName() {
  TypeNameContext *_localctx = _tracker.createInstance<TypeNameContext>(_ctx, getState());
  enterRule(_localctx, 62, PnfCParser::RuleTypeName);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(663);
    specifierQualifierList();
    setState(664);
    optional__typeName_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- AbstractDeclaratorContext ------------------------------------------------------------------

PnfCParser::AbstractDeclaratorContext::AbstractDeclaratorContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::PointerContext* PnfCParser::AbstractDeclaratorContext::pointer() {
  return getRuleContext<PnfCParser::PointerContext>(0);
}

PnfCParser::Aux_rule__abstractDeclarator_3Context* PnfCParser::AbstractDeclaratorContext::aux_rule__abstractDeclarator_3() {
  return getRuleContext<PnfCParser::Aux_rule__abstractDeclarator_3Context>(0);
}


size_t PnfCParser::AbstractDeclaratorContext::getRuleIndex() const {
  return PnfCParser::RuleAbstractDeclarator;
}

void PnfCParser::AbstractDeclaratorContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAbstractDeclarator(this);
}

void PnfCParser::AbstractDeclaratorContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAbstractDeclarator(this);
}


antlrcpp::Any PnfCParser::AbstractDeclaratorContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAbstractDeclarator(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::AbstractDeclaratorContext* PnfCParser::abstractDeclarator() {
  AbstractDeclaratorContext *_localctx = _tracker.createInstance<AbstractDeclaratorContext>(_ctx, getState());
  enterRule(_localctx, 64, PnfCParser::RuleAbstractDeclarator);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(668);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 10, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(666);
      pointer();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(667);
      aux_rule__abstractDeclarator_3();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- TypedefNameContext ------------------------------------------------------------------

PnfCParser::TypedefNameContext::TypedefNameContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::TypedefNameContext::Identifier() {
  return getToken(PnfCParser::Identifier, 0);
}


size_t PnfCParser::TypedefNameContext::getRuleIndex() const {
  return PnfCParser::RuleTypedefName;
}

void PnfCParser::TypedefNameContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterTypedefName(this);
}

void PnfCParser::TypedefNameContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitTypedefName(this);
}


antlrcpp::Any PnfCParser::TypedefNameContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitTypedefName(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::TypedefNameContext* PnfCParser::typedefName() {
  TypedefNameContext *_localctx = _tracker.createInstance<TypedefNameContext>(_ctx, getState());
  enterRule(_localctx, 66, PnfCParser::RuleTypedefName);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(670);
    match(PnfCParser::Identifier);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- InitializerContext ------------------------------------------------------------------

PnfCParser::InitializerContext::InitializerContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::AssignmentExpressionContext* PnfCParser::InitializerContext::assignmentExpression() {
  return getRuleContext<PnfCParser::AssignmentExpressionContext>(0);
}

PnfCParser::Aux_rule__initializer_2Context* PnfCParser::InitializerContext::aux_rule__initializer_2() {
  return getRuleContext<PnfCParser::Aux_rule__initializer_2Context>(0);
}


size_t PnfCParser::InitializerContext::getRuleIndex() const {
  return PnfCParser::RuleInitializer;
}

void PnfCParser::InitializerContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterInitializer(this);
}

void PnfCParser::InitializerContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitInitializer(this);
}


antlrcpp::Any PnfCParser::InitializerContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitInitializer(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::InitializerContext* PnfCParser::initializer() {
  InitializerContext *_localctx = _tracker.createInstance<InitializerContext>(_ctx, getState());
  enterRule(_localctx, 68, PnfCParser::RuleInitializer);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(674);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case PnfCParser::T__10:
      case PnfCParser::T__11:
      case PnfCParser::Extension_gcc:
      case PnfCParser::Sizeof:
      case PnfCParser::Alignof:
      case PnfCParser::Alignof_gcc:
      case PnfCParser::Generic:
      case PnfCParser::LeftParen:
      case PnfCParser::Plus:
      case PnfCParser::PlusPlus:
      case PnfCParser::Minus:
      case PnfCParser::MinusMinus:
      case PnfCParser::Star:
      case PnfCParser::And:
      case PnfCParser::AndAnd:
      case PnfCParser::Not:
      case PnfCParser::Tilde:
      case PnfCParser::Identifier:
      case PnfCParser::Constant:
      case PnfCParser::StringLiteral: {
        enterOuterAlt(_localctx, 1);
        setState(672);
        assignmentExpression();
        break;
      }

      case PnfCParser::LeftBrace: {
        enterOuterAlt(_localctx, 2);
        setState(673);
        aux_rule__initializer_2();
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- DesignationContext ------------------------------------------------------------------

PnfCParser::DesignationContext::DesignationContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::DesignatorListContext* PnfCParser::DesignationContext::designatorList() {
  return getRuleContext<PnfCParser::DesignatorListContext>(0);
}

tree::TerminalNode* PnfCParser::DesignationContext::Assign() {
  return getToken(PnfCParser::Assign, 0);
}


size_t PnfCParser::DesignationContext::getRuleIndex() const {
  return PnfCParser::RuleDesignation;
}

void PnfCParser::DesignationContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterDesignation(this);
}

void PnfCParser::DesignationContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitDesignation(this);
}


antlrcpp::Any PnfCParser::DesignationContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitDesignation(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::DesignationContext* PnfCParser::designation() {
  DesignationContext *_localctx = _tracker.createInstance<DesignationContext>(_ctx, getState());
  enterRule(_localctx, 70, PnfCParser::RuleDesignation);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(676);
    designatorList();
    setState(677);
    match(PnfCParser::Assign);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- StaticAssertDeclarationContext ------------------------------------------------------------------

PnfCParser::StaticAssertDeclarationContext::StaticAssertDeclarationContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::StaticAssertDeclarationContext::StaticAssert() {
  return getToken(PnfCParser::StaticAssert, 0);
}

tree::TerminalNode* PnfCParser::StaticAssertDeclarationContext::LeftParen() {
  return getToken(PnfCParser::LeftParen, 0);
}

PnfCParser::ConstantExpressionContext* PnfCParser::StaticAssertDeclarationContext::constantExpression() {
  return getRuleContext<PnfCParser::ConstantExpressionContext>(0);
}

tree::TerminalNode* PnfCParser::StaticAssertDeclarationContext::Comma() {
  return getToken(PnfCParser::Comma, 0);
}

PnfCParser::Kleene_plus__primaryExpression_1Context* PnfCParser::StaticAssertDeclarationContext::kleene_plus__primaryExpression_1() {
  return getRuleContext<PnfCParser::Kleene_plus__primaryExpression_1Context>(0);
}

tree::TerminalNode* PnfCParser::StaticAssertDeclarationContext::RightParen() {
  return getToken(PnfCParser::RightParen, 0);
}

tree::TerminalNode* PnfCParser::StaticAssertDeclarationContext::Semi() {
  return getToken(PnfCParser::Semi, 0);
}


size_t PnfCParser::StaticAssertDeclarationContext::getRuleIndex() const {
  return PnfCParser::RuleStaticAssertDeclaration;
}

void PnfCParser::StaticAssertDeclarationContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterStaticAssertDeclaration(this);
}

void PnfCParser::StaticAssertDeclarationContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitStaticAssertDeclaration(this);
}


antlrcpp::Any PnfCParser::StaticAssertDeclarationContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitStaticAssertDeclaration(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::StaticAssertDeclarationContext* PnfCParser::staticAssertDeclaration() {
  StaticAssertDeclarationContext *_localctx = _tracker.createInstance<StaticAssertDeclarationContext>(_ctx, getState());
  enterRule(_localctx, 72, PnfCParser::RuleStaticAssertDeclaration);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(679);
    match(PnfCParser::StaticAssert);
    setState(680);
    match(PnfCParser::LeftParen);
    setState(681);
    constantExpression();
    setState(682);
    match(PnfCParser::Comma);
    setState(683);
    kleene_plus__primaryExpression_1();
    setState(684);
    match(PnfCParser::RightParen);
    setState(685);
    match(PnfCParser::Semi);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- AsmStatementContext ------------------------------------------------------------------

PnfCParser::AsmStatementContext::AsmStatementContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::AsmKeywordContext* PnfCParser::AsmStatementContext::asmKeyword() {
  return getRuleContext<PnfCParser::AsmKeywordContext>(0);
}

PnfCParser::Optional__asmStatement_2Context* PnfCParser::AsmStatementContext::optional__asmStatement_2() {
  return getRuleContext<PnfCParser::Optional__asmStatement_2Context>(0);
}

tree::TerminalNode* PnfCParser::AsmStatementContext::LeftParen() {
  return getToken(PnfCParser::LeftParen, 0);
}

PnfCParser::Optional__asmStatement_6Context* PnfCParser::AsmStatementContext::optional__asmStatement_6() {
  return getRuleContext<PnfCParser::Optional__asmStatement_6Context>(0);
}

PnfCParser::Kleene_star__asmStatement_12Context* PnfCParser::AsmStatementContext::kleene_star__asmStatement_12() {
  return getRuleContext<PnfCParser::Kleene_star__asmStatement_12Context>(0);
}

tree::TerminalNode* PnfCParser::AsmStatementContext::RightParen() {
  return getToken(PnfCParser::RightParen, 0);
}

tree::TerminalNode* PnfCParser::AsmStatementContext::Semi() {
  return getToken(PnfCParser::Semi, 0);
}


size_t PnfCParser::AsmStatementContext::getRuleIndex() const {
  return PnfCParser::RuleAsmStatement;
}

void PnfCParser::AsmStatementContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAsmStatement(this);
}

void PnfCParser::AsmStatementContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAsmStatement(this);
}


antlrcpp::Any PnfCParser::AsmStatementContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAsmStatement(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::AsmStatementContext* PnfCParser::asmStatement() {
  AsmStatementContext *_localctx = _tracker.createInstance<AsmStatementContext>(_ctx, getState());
  enterRule(_localctx, 74, PnfCParser::RuleAsmStatement);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(687);
    asmKeyword();
    setState(688);
    optional__asmStatement_2();
    setState(689);
    match(PnfCParser::LeftParen);
    setState(690);
    optional__asmStatement_6();
    setState(691);
    kleene_star__asmStatement_12();
    setState(692);
    match(PnfCParser::RightParen);
    setState(693);
    match(PnfCParser::Semi);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- LabeledStatementContext ------------------------------------------------------------------

PnfCParser::LabeledStatementContext::LabeledStatementContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Altnt_block__labeledStatement_1Context* PnfCParser::LabeledStatementContext::altnt_block__labeledStatement_1() {
  return getRuleContext<PnfCParser::Altnt_block__labeledStatement_1Context>(0);
}

tree::TerminalNode* PnfCParser::LabeledStatementContext::Colon() {
  return getToken(PnfCParser::Colon, 0);
}

PnfCParser::StatementContext* PnfCParser::LabeledStatementContext::statement() {
  return getRuleContext<PnfCParser::StatementContext>(0);
}


size_t PnfCParser::LabeledStatementContext::getRuleIndex() const {
  return PnfCParser::RuleLabeledStatement;
}

void PnfCParser::LabeledStatementContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterLabeledStatement(this);
}

void PnfCParser::LabeledStatementContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitLabeledStatement(this);
}


antlrcpp::Any PnfCParser::LabeledStatementContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitLabeledStatement(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::LabeledStatementContext* PnfCParser::labeledStatement() {
  LabeledStatementContext *_localctx = _tracker.createInstance<LabeledStatementContext>(_ctx, getState());
  enterRule(_localctx, 76, PnfCParser::RuleLabeledStatement);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(695);
    altnt_block__labeledStatement_1();
    setState(696);
    match(PnfCParser::Colon);
    setState(697);
    statement();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- CompoundStatementContext ------------------------------------------------------------------

PnfCParser::CompoundStatementContext::CompoundStatementContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::CompoundStatementContext::LeftBrace() {
  return getToken(PnfCParser::LeftBrace, 0);
}

PnfCParser::Optional__compoundStatement_1Context* PnfCParser::CompoundStatementContext::optional__compoundStatement_1() {
  return getRuleContext<PnfCParser::Optional__compoundStatement_1Context>(0);
}

tree::TerminalNode* PnfCParser::CompoundStatementContext::RightBrace() {
  return getToken(PnfCParser::RightBrace, 0);
}


size_t PnfCParser::CompoundStatementContext::getRuleIndex() const {
  return PnfCParser::RuleCompoundStatement;
}

void PnfCParser::CompoundStatementContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterCompoundStatement(this);
}

void PnfCParser::CompoundStatementContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitCompoundStatement(this);
}


antlrcpp::Any PnfCParser::CompoundStatementContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitCompoundStatement(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::CompoundStatementContext* PnfCParser::compoundStatement() {
  CompoundStatementContext *_localctx = _tracker.createInstance<CompoundStatementContext>(_ctx, getState());
  enterRule(_localctx, 78, PnfCParser::RuleCompoundStatement);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(699);
    match(PnfCParser::LeftBrace);
    setState(700);
    optional__compoundStatement_1();
    setState(701);
    match(PnfCParser::RightBrace);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ExpressionStatementContext ------------------------------------------------------------------

PnfCParser::ExpressionStatementContext::ExpressionStatementContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Optional__postfixExpression_1Context* PnfCParser::ExpressionStatementContext::optional__postfixExpression_1() {
  return getRuleContext<PnfCParser::Optional__postfixExpression_1Context>(0);
}

tree::TerminalNode* PnfCParser::ExpressionStatementContext::Semi() {
  return getToken(PnfCParser::Semi, 0);
}


size_t PnfCParser::ExpressionStatementContext::getRuleIndex() const {
  return PnfCParser::RuleExpressionStatement;
}

void PnfCParser::ExpressionStatementContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterExpressionStatement(this);
}

void PnfCParser::ExpressionStatementContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitExpressionStatement(this);
}


antlrcpp::Any PnfCParser::ExpressionStatementContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitExpressionStatement(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::ExpressionStatementContext* PnfCParser::expressionStatement() {
  ExpressionStatementContext *_localctx = _tracker.createInstance<ExpressionStatementContext>(_ctx, getState());
  enterRule(_localctx, 80, PnfCParser::RuleExpressionStatement);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(703);
    optional__postfixExpression_1();
    setState(704);
    match(PnfCParser::Semi);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- JumpStatementContext ------------------------------------------------------------------

PnfCParser::JumpStatementContext::JumpStatementContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Altnt_block__jumpStatement_2Context* PnfCParser::JumpStatementContext::altnt_block__jumpStatement_2() {
  return getRuleContext<PnfCParser::Altnt_block__jumpStatement_2Context>(0);
}

tree::TerminalNode* PnfCParser::JumpStatementContext::Semi() {
  return getToken(PnfCParser::Semi, 0);
}


size_t PnfCParser::JumpStatementContext::getRuleIndex() const {
  return PnfCParser::RuleJumpStatement;
}

void PnfCParser::JumpStatementContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterJumpStatement(this);
}

void PnfCParser::JumpStatementContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitJumpStatement(this);
}


antlrcpp::Any PnfCParser::JumpStatementContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitJumpStatement(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::JumpStatementContext* PnfCParser::jumpStatement() {
  JumpStatementContext *_localctx = _tracker.createInstance<JumpStatementContext>(_ctx, getState());
  enterRule(_localctx, 82, PnfCParser::RuleJumpStatement);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(706);
    altnt_block__jumpStatement_2();
    setState(707);
    match(PnfCParser::Semi);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- CompilationUnitContext ------------------------------------------------------------------

PnfCParser::CompilationUnitContext::CompilationUnitContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Optional__compilationUnit_1Context* PnfCParser::CompilationUnitContext::optional__compilationUnit_1() {
  return getRuleContext<PnfCParser::Optional__compilationUnit_1Context>(0);
}

tree::TerminalNode* PnfCParser::CompilationUnitContext::EOF() {
  return getToken(PnfCParser::EOF, 0);
}


size_t PnfCParser::CompilationUnitContext::getRuleIndex() const {
  return PnfCParser::RuleCompilationUnit;
}

void PnfCParser::CompilationUnitContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterCompilationUnit(this);
}

void PnfCParser::CompilationUnitContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitCompilationUnit(this);
}


antlrcpp::Any PnfCParser::CompilationUnitContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitCompilationUnit(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::CompilationUnitContext* PnfCParser::compilationUnit() {
  CompilationUnitContext *_localctx = _tracker.createInstance<CompilationUnitContext>(_ctx, getState());
  enterRule(_localctx, 84, PnfCParser::RuleCompilationUnit);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(709);
    optional__compilationUnit_1();
    setState(710);
    match(PnfCParser::EOF);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- FunctionDefinitionContext ------------------------------------------------------------------

PnfCParser::FunctionDefinitionContext::FunctionDefinitionContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Optional__declaration_1Context* PnfCParser::FunctionDefinitionContext::optional__declaration_1() {
  return getRuleContext<PnfCParser::Optional__declaration_1Context>(0);
}

PnfCParser::Optional__functionDefinition_2Context* PnfCParser::FunctionDefinitionContext::optional__functionDefinition_2() {
  return getRuleContext<PnfCParser::Optional__functionDefinition_2Context>(0);
}

PnfCParser::DeclaratorContext* PnfCParser::FunctionDefinitionContext::declarator() {
  return getRuleContext<PnfCParser::DeclaratorContext>(0);
}

PnfCParser::Optional__functionDefinition_3Context* PnfCParser::FunctionDefinitionContext::optional__functionDefinition_3() {
  return getRuleContext<PnfCParser::Optional__functionDefinition_3Context>(0);
}

PnfCParser::CompoundStatementContext* PnfCParser::FunctionDefinitionContext::compoundStatement() {
  return getRuleContext<PnfCParser::CompoundStatementContext>(0);
}


size_t PnfCParser::FunctionDefinitionContext::getRuleIndex() const {
  return PnfCParser::RuleFunctionDefinition;
}

void PnfCParser::FunctionDefinitionContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterFunctionDefinition(this);
}

void PnfCParser::FunctionDefinitionContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitFunctionDefinition(this);
}


antlrcpp::Any PnfCParser::FunctionDefinitionContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitFunctionDefinition(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::FunctionDefinitionContext* PnfCParser::functionDefinition() {
  FunctionDefinitionContext *_localctx = _tracker.createInstance<FunctionDefinitionContext>(_ctx, getState());
  enterRule(_localctx, 86, PnfCParser::RuleFunctionDefinition);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(712);
    optional__declaration_1();
    setState(713);
    optional__functionDefinition_2();
    setState(714);
    declarator();
    setState(715);
    optional__functionDefinition_3();
    setState(716);
    compoundStatement();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_plus__primaryExpression_1Context ------------------------------------------------------------------

PnfCParser::Kleene_plus__primaryExpression_1Context::Kleene_plus__primaryExpression_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<tree::TerminalNode *> PnfCParser::Kleene_plus__primaryExpression_1Context::StringLiteral() {
  return getTokens(PnfCParser::StringLiteral);
}

tree::TerminalNode* PnfCParser::Kleene_plus__primaryExpression_1Context::StringLiteral(size_t i) {
  return getToken(PnfCParser::StringLiteral, i);
}


size_t PnfCParser::Kleene_plus__primaryExpression_1Context::getRuleIndex() const {
  return PnfCParser::RuleKleene_plus__primaryExpression_1;
}

void PnfCParser::Kleene_plus__primaryExpression_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_plus__primaryExpression_1(this);
}

void PnfCParser::Kleene_plus__primaryExpression_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_plus__primaryExpression_1(this);
}


antlrcpp::Any PnfCParser::Kleene_plus__primaryExpression_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitKleene_plus__primaryExpression_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Kleene_plus__primaryExpression_1Context* PnfCParser::kleene_plus__primaryExpression_1() {
  Kleene_plus__primaryExpression_1Context *_localctx = _tracker.createInstance<Kleene_plus__primaryExpression_1Context>(_ctx, getState());
  enterRule(_localctx, 88, PnfCParser::RuleKleene_plus__primaryExpression_1);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(719); 
    _errHandler->sync(this);
    _la = _input->LA(1);
    do {
      setState(718);
      match(PnfCParser::StringLiteral);
      setState(721); 
      _errHandler->sync(this);
      _la = _input->LA(1);
    } while (_la == PnfCParser::StringLiteral);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__primaryExpression_2Context ------------------------------------------------------------------

PnfCParser::Optional__primaryExpression_2Context::Optional__primaryExpression_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Optional__primaryExpression_2Context::Extension_gcc() {
  return getToken(PnfCParser::Extension_gcc, 0);
}


size_t PnfCParser::Optional__primaryExpression_2Context::getRuleIndex() const {
  return PnfCParser::RuleOptional__primaryExpression_2;
}

void PnfCParser::Optional__primaryExpression_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__primaryExpression_2(this);
}

void PnfCParser::Optional__primaryExpression_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__primaryExpression_2(this);
}


antlrcpp::Any PnfCParser::Optional__primaryExpression_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitOptional__primaryExpression_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Optional__primaryExpression_2Context* PnfCParser::optional__primaryExpression_2() {
  Optional__primaryExpression_2Context *_localctx = _tracker.createInstance<Optional__primaryExpression_2Context>(_ctx, getState());
  enterRule(_localctx, 90, PnfCParser::RuleOptional__primaryExpression_2);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(724);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if (_la == PnfCParser::Extension_gcc) {
      setState(723);
      match(PnfCParser::Extension_gcc);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__postfixExpression_1Context ------------------------------------------------------------------

PnfCParser::Optional__postfixExpression_1Context::Optional__postfixExpression_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::ExpressionContext* PnfCParser::Optional__postfixExpression_1Context::expression() {
  return getRuleContext<PnfCParser::ExpressionContext>(0);
}


size_t PnfCParser::Optional__postfixExpression_1Context::getRuleIndex() const {
  return PnfCParser::RuleOptional__postfixExpression_1;
}

void PnfCParser::Optional__postfixExpression_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__postfixExpression_1(this);
}

void PnfCParser::Optional__postfixExpression_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__postfixExpression_1(this);
}


antlrcpp::Any PnfCParser::Optional__postfixExpression_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitOptional__postfixExpression_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Optional__postfixExpression_1Context* PnfCParser::optional__postfixExpression_1() {
  Optional__postfixExpression_1Context *_localctx = _tracker.createInstance<Optional__postfixExpression_1Context>(_ctx, getState());
  enterRule(_localctx, 92, PnfCParser::RuleOptional__postfixExpression_1);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(727);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if ((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << PnfCParser::T__10)
      | (1ULL << PnfCParser::T__11)
      | (1ULL << PnfCParser::Extension_gcc)
      | (1ULL << PnfCParser::Sizeof)
      | (1ULL << PnfCParser::Alignof)
      | (1ULL << PnfCParser::Alignof_gcc)
      | (1ULL << PnfCParser::Generic))) != 0) || ((((_la - 66) & ~ 0x3fULL) == 0) &&
      ((1ULL << (_la - 66)) & ((1ULL << (PnfCParser::LeftParen - 66))
      | (1ULL << (PnfCParser::Plus - 66))
      | (1ULL << (PnfCParser::PlusPlus - 66))
      | (1ULL << (PnfCParser::Minus - 66))
      | (1ULL << (PnfCParser::MinusMinus - 66))
      | (1ULL << (PnfCParser::Star - 66))
      | (1ULL << (PnfCParser::And - 66))
      | (1ULL << (PnfCParser::AndAnd - 66))
      | (1ULL << (PnfCParser::Not - 66))
      | (1ULL << (PnfCParser::Tilde - 66))
      | (1ULL << (PnfCParser::Identifier - 66))
      | (1ULL << (PnfCParser::Constant - 66))
      | (1ULL << (PnfCParser::StringLiteral - 66)))) != 0)) {
      setState(726);
      expression();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__conditionalExpression_1Context ------------------------------------------------------------------

PnfCParser::Aux_rule__conditionalExpression_1Context::Aux_rule__conditionalExpression_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__conditionalExpression_1Context::Question() {
  return getToken(PnfCParser::Question, 0);
}

PnfCParser::ExpressionContext* PnfCParser::Aux_rule__conditionalExpression_1Context::expression() {
  return getRuleContext<PnfCParser::ExpressionContext>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__conditionalExpression_1Context::Colon() {
  return getToken(PnfCParser::Colon, 0);
}

PnfCParser::ConditionalExpressionContext* PnfCParser::Aux_rule__conditionalExpression_1Context::conditionalExpression() {
  return getRuleContext<PnfCParser::ConditionalExpressionContext>(0);
}


size_t PnfCParser::Aux_rule__conditionalExpression_1Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__conditionalExpression_1;
}

void PnfCParser::Aux_rule__conditionalExpression_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__conditionalExpression_1(this);
}

void PnfCParser::Aux_rule__conditionalExpression_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__conditionalExpression_1(this);
}


antlrcpp::Any PnfCParser::Aux_rule__conditionalExpression_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__conditionalExpression_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__conditionalExpression_1Context* PnfCParser::aux_rule__conditionalExpression_1() {
  Aux_rule__conditionalExpression_1Context *_localctx = _tracker.createInstance<Aux_rule__conditionalExpression_1Context>(_ctx, getState());
  enterRule(_localctx, 94, PnfCParser::RuleAux_rule__conditionalExpression_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(729);
    match(PnfCParser::Question);
    setState(730);
    expression();
    setState(731);
    match(PnfCParser::Colon);
    setState(732);
    conditionalExpression();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__conditionalExpression_2Context ------------------------------------------------------------------

PnfCParser::Optional__conditionalExpression_2Context::Optional__conditionalExpression_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Aux_rule__conditionalExpression_1Context* PnfCParser::Optional__conditionalExpression_2Context::aux_rule__conditionalExpression_1() {
  return getRuleContext<PnfCParser::Aux_rule__conditionalExpression_1Context>(0);
}


size_t PnfCParser::Optional__conditionalExpression_2Context::getRuleIndex() const {
  return PnfCParser::RuleOptional__conditionalExpression_2;
}

void PnfCParser::Optional__conditionalExpression_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__conditionalExpression_2(this);
}

void PnfCParser::Optional__conditionalExpression_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__conditionalExpression_2(this);
}


antlrcpp::Any PnfCParser::Optional__conditionalExpression_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitOptional__conditionalExpression_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Optional__conditionalExpression_2Context* PnfCParser::optional__conditionalExpression_2() {
  Optional__conditionalExpression_2Context *_localctx = _tracker.createInstance<Optional__conditionalExpression_2Context>(_ctx, getState());
  enterRule(_localctx, 96, PnfCParser::RuleOptional__conditionalExpression_2);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(735);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if (_la == PnfCParser::Question) {
      setState(734);
      aux_rule__conditionalExpression_1();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__declaration_1Context ------------------------------------------------------------------

PnfCParser::Optional__declaration_1Context::Optional__declaration_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Optional__declaration_1Context::Extension_gcc() {
  return getToken(PnfCParser::Extension_gcc, 0);
}


size_t PnfCParser::Optional__declaration_1Context::getRuleIndex() const {
  return PnfCParser::RuleOptional__declaration_1;
}

void PnfCParser::Optional__declaration_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__declaration_1(this);
}

void PnfCParser::Optional__declaration_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__declaration_1(this);
}


antlrcpp::Any PnfCParser::Optional__declaration_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitOptional__declaration_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Optional__declaration_1Context* PnfCParser::optional__declaration_1() {
  Optional__declaration_1Context *_localctx = _tracker.createInstance<Optional__declaration_1Context>(_ctx, getState());
  enterRule(_localctx, 98, PnfCParser::RuleOptional__declaration_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(738);
    _errHandler->sync(this);

    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 16, _ctx)) {
    case 1: {
      setState(737);
      match(PnfCParser::Extension_gcc);
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__declaration_2Context ------------------------------------------------------------------

PnfCParser::Optional__declaration_2Context::Optional__declaration_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::InitDeclaratorListContext* PnfCParser::Optional__declaration_2Context::initDeclaratorList() {
  return getRuleContext<PnfCParser::InitDeclaratorListContext>(0);
}


size_t PnfCParser::Optional__declaration_2Context::getRuleIndex() const {
  return PnfCParser::RuleOptional__declaration_2;
}

void PnfCParser::Optional__declaration_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__declaration_2(this);
}

void PnfCParser::Optional__declaration_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__declaration_2(this);
}


antlrcpp::Any PnfCParser::Optional__declaration_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitOptional__declaration_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Optional__declaration_2Context* PnfCParser::optional__declaration_2() {
  Optional__declaration_2Context *_localctx = _tracker.createInstance<Optional__declaration_2Context>(_ctx, getState());
  enterRule(_localctx, 100, PnfCParser::RuleOptional__declaration_2);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(741);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if (((((_la - 66) & ~ 0x3fULL) == 0) &&
      ((1ULL << (_la - 66)) & ((1ULL << (PnfCParser::LeftParen - 66))
      | (1ULL << (PnfCParser::Star - 66))
      | (1ULL << (PnfCParser::Caret - 66))
      | (1ULL << (PnfCParser::Identifier - 66)))) != 0)) {
      setState(740);
      initDeclaratorList();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__structOrUnionSpecifier_1Context ------------------------------------------------------------------

PnfCParser::Optional__structOrUnionSpecifier_1Context::Optional__structOrUnionSpecifier_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Optional__structOrUnionSpecifier_1Context::Identifier() {
  return getToken(PnfCParser::Identifier, 0);
}


size_t PnfCParser::Optional__structOrUnionSpecifier_1Context::getRuleIndex() const {
  return PnfCParser::RuleOptional__structOrUnionSpecifier_1;
}

void PnfCParser::Optional__structOrUnionSpecifier_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__structOrUnionSpecifier_1(this);
}

void PnfCParser::Optional__structOrUnionSpecifier_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__structOrUnionSpecifier_1(this);
}


antlrcpp::Any PnfCParser::Optional__structOrUnionSpecifier_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitOptional__structOrUnionSpecifier_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Optional__structOrUnionSpecifier_1Context* PnfCParser::optional__structOrUnionSpecifier_1() {
  Optional__structOrUnionSpecifier_1Context *_localctx = _tracker.createInstance<Optional__structOrUnionSpecifier_1Context>(_ctx, getState());
  enterRule(_localctx, 102, PnfCParser::RuleOptional__structOrUnionSpecifier_1);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(744);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if (_la == PnfCParser::Identifier) {
      setState(743);
      match(PnfCParser::Identifier);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__structDeclaration_2Context ------------------------------------------------------------------

PnfCParser::Optional__structDeclaration_2Context::Optional__structDeclaration_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::StructDeclaratorListContext* PnfCParser::Optional__structDeclaration_2Context::structDeclaratorList() {
  return getRuleContext<PnfCParser::StructDeclaratorListContext>(0);
}


size_t PnfCParser::Optional__structDeclaration_2Context::getRuleIndex() const {
  return PnfCParser::RuleOptional__structDeclaration_2;
}

void PnfCParser::Optional__structDeclaration_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__structDeclaration_2(this);
}

void PnfCParser::Optional__structDeclaration_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__structDeclaration_2(this);
}


antlrcpp::Any PnfCParser::Optional__structDeclaration_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitOptional__structDeclaration_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Optional__structDeclaration_2Context* PnfCParser::optional__structDeclaration_2() {
  Optional__structDeclaration_2Context *_localctx = _tracker.createInstance<Optional__structDeclaration_2Context>(_ctx, getState());
  enterRule(_localctx, 104, PnfCParser::RuleOptional__structDeclaration_2);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(747);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if (((((_la - 66) & ~ 0x3fULL) == 0) &&
      ((1ULL << (_la - 66)) & ((1ULL << (PnfCParser::LeftParen - 66))
      | (1ULL << (PnfCParser::Star - 66))
      | (1ULL << (PnfCParser::Caret - 66))
      | (1ULL << (PnfCParser::Colon - 66))
      | (1ULL << (PnfCParser::Identifier - 66)))) != 0)) {
      setState(746);
      structDeclaratorList();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__specifierQualifierList_1Context ------------------------------------------------------------------

PnfCParser::Optional__specifierQualifierList_1Context::Optional__specifierQualifierList_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::SpecifierQualifierListContext* PnfCParser::Optional__specifierQualifierList_1Context::specifierQualifierList() {
  return getRuleContext<PnfCParser::SpecifierQualifierListContext>(0);
}


size_t PnfCParser::Optional__specifierQualifierList_1Context::getRuleIndex() const {
  return PnfCParser::RuleOptional__specifierQualifierList_1;
}

void PnfCParser::Optional__specifierQualifierList_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__specifierQualifierList_1(this);
}

void PnfCParser::Optional__specifierQualifierList_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__specifierQualifierList_1(this);
}


antlrcpp::Any PnfCParser::Optional__specifierQualifierList_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitOptional__specifierQualifierList_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Optional__specifierQualifierList_1Context* PnfCParser::optional__specifierQualifierList_1() {
  Optional__specifierQualifierList_1Context *_localctx = _tracker.createInstance<Optional__specifierQualifierList_1Context>(_ctx, getState());
  enterRule(_localctx, 106, PnfCParser::RuleOptional__specifierQualifierList_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(750);
    _errHandler->sync(this);

    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 20, _ctx)) {
    case 1: {
      setState(749);
      specifierQualifierList();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__structDeclarator_1Context ------------------------------------------------------------------

PnfCParser::Optional__structDeclarator_1Context::Optional__structDeclarator_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::DeclaratorContext* PnfCParser::Optional__structDeclarator_1Context::declarator() {
  return getRuleContext<PnfCParser::DeclaratorContext>(0);
}


size_t PnfCParser::Optional__structDeclarator_1Context::getRuleIndex() const {
  return PnfCParser::RuleOptional__structDeclarator_1;
}

void PnfCParser::Optional__structDeclarator_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__structDeclarator_1(this);
}

void PnfCParser::Optional__structDeclarator_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__structDeclarator_1(this);
}


antlrcpp::Any PnfCParser::Optional__structDeclarator_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitOptional__structDeclarator_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Optional__structDeclarator_1Context* PnfCParser::optional__structDeclarator_1() {
  Optional__structDeclarator_1Context *_localctx = _tracker.createInstance<Optional__structDeclarator_1Context>(_ctx, getState());
  enterRule(_localctx, 108, PnfCParser::RuleOptional__structDeclarator_1);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(753);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if (((((_la - 66) & ~ 0x3fULL) == 0) &&
      ((1ULL << (_la - 66)) & ((1ULL << (PnfCParser::LeftParen - 66))
      | (1ULL << (PnfCParser::Star - 66))
      | (1ULL << (PnfCParser::Caret - 66))
      | (1ULL << (PnfCParser::Identifier - 66)))) != 0)) {
      setState(752);
      declarator();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__declarator_1Context ------------------------------------------------------------------

PnfCParser::Optional__declarator_1Context::Optional__declarator_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::PointerContext* PnfCParser::Optional__declarator_1Context::pointer() {
  return getRuleContext<PnfCParser::PointerContext>(0);
}


size_t PnfCParser::Optional__declarator_1Context::getRuleIndex() const {
  return PnfCParser::RuleOptional__declarator_1;
}

void PnfCParser::Optional__declarator_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__declarator_1(this);
}

void PnfCParser::Optional__declarator_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__declarator_1(this);
}


antlrcpp::Any PnfCParser::Optional__declarator_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitOptional__declarator_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Optional__declarator_1Context* PnfCParser::optional__declarator_1() {
  Optional__declarator_1Context *_localctx = _tracker.createInstance<Optional__declarator_1Context>(_ctx, getState());
  enterRule(_localctx, 110, PnfCParser::RuleOptional__declarator_1);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(756);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if (_la == PnfCParser::Star

    || _la == PnfCParser::Caret) {
      setState(755);
      pointer();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__declarator_2Context ------------------------------------------------------------------

PnfCParser::Kleene_star__declarator_2Context::Kleene_star__declarator_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfCParser::GccDeclaratorExtensionContext *> PnfCParser::Kleene_star__declarator_2Context::gccDeclaratorExtension() {
  return getRuleContexts<PnfCParser::GccDeclaratorExtensionContext>();
}

PnfCParser::GccDeclaratorExtensionContext* PnfCParser::Kleene_star__declarator_2Context::gccDeclaratorExtension(size_t i) {
  return getRuleContext<PnfCParser::GccDeclaratorExtensionContext>(i);
}


size_t PnfCParser::Kleene_star__declarator_2Context::getRuleIndex() const {
  return PnfCParser::RuleKleene_star__declarator_2;
}

void PnfCParser::Kleene_star__declarator_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__declarator_2(this);
}

void PnfCParser::Kleene_star__declarator_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__declarator_2(this);
}


antlrcpp::Any PnfCParser::Kleene_star__declarator_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitKleene_star__declarator_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Kleene_star__declarator_2Context* PnfCParser::kleene_star__declarator_2() {
  Kleene_star__declarator_2Context *_localctx = _tracker.createInstance<Kleene_star__declarator_2Context>(_ctx, getState());
  enterRule(_localctx, 112, PnfCParser::RuleKleene_star__declarator_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    size_t alt;
    enterOuterAlt(_localctx, 1);
    setState(761);
    _errHandler->sync(this);
    alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 23, _ctx);
    while (alt != 2 && alt != atn::ATN::INVALID_ALT_NUMBER) {
      if (alt == 1) {
        setState(758);
        gccDeclaratorExtension(); 
      }
      setState(763);
      _errHandler->sync(this);
      alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 23, _ctx);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__directDeclarator_2Context ------------------------------------------------------------------

PnfCParser::Optional__directDeclarator_2Context::Optional__directDeclarator_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::AssignmentExpressionContext* PnfCParser::Optional__directDeclarator_2Context::assignmentExpression() {
  return getRuleContext<PnfCParser::AssignmentExpressionContext>(0);
}


size_t PnfCParser::Optional__directDeclarator_2Context::getRuleIndex() const {
  return PnfCParser::RuleOptional__directDeclarator_2;
}

void PnfCParser::Optional__directDeclarator_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__directDeclarator_2(this);
}

void PnfCParser::Optional__directDeclarator_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__directDeclarator_2(this);
}


antlrcpp::Any PnfCParser::Optional__directDeclarator_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitOptional__directDeclarator_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Optional__directDeclarator_2Context* PnfCParser::optional__directDeclarator_2() {
  Optional__directDeclarator_2Context *_localctx = _tracker.createInstance<Optional__directDeclarator_2Context>(_ctx, getState());
  enterRule(_localctx, 114, PnfCParser::RuleOptional__directDeclarator_2);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(765);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if ((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << PnfCParser::T__10)
      | (1ULL << PnfCParser::T__11)
      | (1ULL << PnfCParser::Extension_gcc)
      | (1ULL << PnfCParser::Sizeof)
      | (1ULL << PnfCParser::Alignof)
      | (1ULL << PnfCParser::Alignof_gcc)
      | (1ULL << PnfCParser::Generic))) != 0) || ((((_la - 66) & ~ 0x3fULL) == 0) &&
      ((1ULL << (_la - 66)) & ((1ULL << (PnfCParser::LeftParen - 66))
      | (1ULL << (PnfCParser::Plus - 66))
      | (1ULL << (PnfCParser::PlusPlus - 66))
      | (1ULL << (PnfCParser::Minus - 66))
      | (1ULL << (PnfCParser::MinusMinus - 66))
      | (1ULL << (PnfCParser::Star - 66))
      | (1ULL << (PnfCParser::And - 66))
      | (1ULL << (PnfCParser::AndAnd - 66))
      | (1ULL << (PnfCParser::Not - 66))
      | (1ULL << (PnfCParser::Tilde - 66))
      | (1ULL << (PnfCParser::Identifier - 66))
      | (1ULL << (PnfCParser::Constant - 66))
      | (1ULL << (PnfCParser::StringLiteral - 66)))) != 0)) {
      setState(764);
      assignmentExpression();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__directDeclarator_5Context ------------------------------------------------------------------

PnfCParser::Optional__directDeclarator_5Context::Optional__directDeclarator_5Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::IdentifierListContext* PnfCParser::Optional__directDeclarator_5Context::identifierList() {
  return getRuleContext<PnfCParser::IdentifierListContext>(0);
}


size_t PnfCParser::Optional__directDeclarator_5Context::getRuleIndex() const {
  return PnfCParser::RuleOptional__directDeclarator_5;
}

void PnfCParser::Optional__directDeclarator_5Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__directDeclarator_5(this);
}

void PnfCParser::Optional__directDeclarator_5Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__directDeclarator_5(this);
}


antlrcpp::Any PnfCParser::Optional__directDeclarator_5Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitOptional__directDeclarator_5(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Optional__directDeclarator_5Context* PnfCParser::optional__directDeclarator_5() {
  Optional__directDeclarator_5Context *_localctx = _tracker.createInstance<Optional__directDeclarator_5Context>(_ctx, getState());
  enterRule(_localctx, 116, PnfCParser::RuleOptional__directDeclarator_5);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(768);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if (_la == PnfCParser::Identifier) {
      setState(767);
      identifierList();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__gccAttributeList_1Context ------------------------------------------------------------------

PnfCParser::Aux_rule__gccAttributeList_1Context::Aux_rule__gccAttributeList_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__gccAttributeList_1Context::Comma() {
  return getToken(PnfCParser::Comma, 0);
}

PnfCParser::GccAttributeContext* PnfCParser::Aux_rule__gccAttributeList_1Context::gccAttribute() {
  return getRuleContext<PnfCParser::GccAttributeContext>(0);
}


size_t PnfCParser::Aux_rule__gccAttributeList_1Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__gccAttributeList_1;
}

void PnfCParser::Aux_rule__gccAttributeList_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__gccAttributeList_1(this);
}

void PnfCParser::Aux_rule__gccAttributeList_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__gccAttributeList_1(this);
}


antlrcpp::Any PnfCParser::Aux_rule__gccAttributeList_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__gccAttributeList_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__gccAttributeList_1Context* PnfCParser::aux_rule__gccAttributeList_1() {
  Aux_rule__gccAttributeList_1Context *_localctx = _tracker.createInstance<Aux_rule__gccAttributeList_1Context>(_ctx, getState());
  enterRule(_localctx, 118, PnfCParser::RuleAux_rule__gccAttributeList_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(770);
    match(PnfCParser::Comma);
    setState(771);
    gccAttribute();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__gccAttributeList_2Context ------------------------------------------------------------------

PnfCParser::Kleene_star__gccAttributeList_2Context::Kleene_star__gccAttributeList_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfCParser::Aux_rule__gccAttributeList_1Context *> PnfCParser::Kleene_star__gccAttributeList_2Context::aux_rule__gccAttributeList_1() {
  return getRuleContexts<PnfCParser::Aux_rule__gccAttributeList_1Context>();
}

PnfCParser::Aux_rule__gccAttributeList_1Context* PnfCParser::Kleene_star__gccAttributeList_2Context::aux_rule__gccAttributeList_1(size_t i) {
  return getRuleContext<PnfCParser::Aux_rule__gccAttributeList_1Context>(i);
}


size_t PnfCParser::Kleene_star__gccAttributeList_2Context::getRuleIndex() const {
  return PnfCParser::RuleKleene_star__gccAttributeList_2;
}

void PnfCParser::Kleene_star__gccAttributeList_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__gccAttributeList_2(this);
}

void PnfCParser::Kleene_star__gccAttributeList_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__gccAttributeList_2(this);
}


antlrcpp::Any PnfCParser::Kleene_star__gccAttributeList_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitKleene_star__gccAttributeList_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Kleene_star__gccAttributeList_2Context* PnfCParser::kleene_star__gccAttributeList_2() {
  Kleene_star__gccAttributeList_2Context *_localctx = _tracker.createInstance<Kleene_star__gccAttributeList_2Context>(_ctx, getState());
  enterRule(_localctx, 120, PnfCParser::RuleKleene_star__gccAttributeList_2);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(776);
    _errHandler->sync(this);
    _la = _input->LA(1);
    while (_la == PnfCParser::Comma) {
      setState(773);
      aux_rule__gccAttributeList_1();
      setState(778);
      _errHandler->sync(this);
      _la = _input->LA(1);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__gccAttributeList_3Context ------------------------------------------------------------------

PnfCParser::Aux_rule__gccAttributeList_3Context::Aux_rule__gccAttributeList_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::GccAttributeContext* PnfCParser::Aux_rule__gccAttributeList_3Context::gccAttribute() {
  return getRuleContext<PnfCParser::GccAttributeContext>(0);
}

PnfCParser::Kleene_star__gccAttributeList_2Context* PnfCParser::Aux_rule__gccAttributeList_3Context::kleene_star__gccAttributeList_2() {
  return getRuleContext<PnfCParser::Kleene_star__gccAttributeList_2Context>(0);
}


size_t PnfCParser::Aux_rule__gccAttributeList_3Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__gccAttributeList_3;
}

void PnfCParser::Aux_rule__gccAttributeList_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__gccAttributeList_3(this);
}

void PnfCParser::Aux_rule__gccAttributeList_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__gccAttributeList_3(this);
}


antlrcpp::Any PnfCParser::Aux_rule__gccAttributeList_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__gccAttributeList_3(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__gccAttributeList_3Context* PnfCParser::aux_rule__gccAttributeList_3() {
  Aux_rule__gccAttributeList_3Context *_localctx = _tracker.createInstance<Aux_rule__gccAttributeList_3Context>(_ctx, getState());
  enterRule(_localctx, 122, PnfCParser::RuleAux_rule__gccAttributeList_3);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(779);
    gccAttribute();
    setState(780);
    kleene_star__gccAttributeList_2();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__gccAttribute_2Context ------------------------------------------------------------------

PnfCParser::Aux_rule__gccAttribute_2Context::Aux_rule__gccAttribute_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__gccAttribute_2Context::LeftParen() {
  return getToken(PnfCParser::LeftParen, 0);
}

PnfCParser::Optional__postfixExpression_1Context* PnfCParser::Aux_rule__gccAttribute_2Context::optional__postfixExpression_1() {
  return getRuleContext<PnfCParser::Optional__postfixExpression_1Context>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__gccAttribute_2Context::RightParen() {
  return getToken(PnfCParser::RightParen, 0);
}


size_t PnfCParser::Aux_rule__gccAttribute_2Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__gccAttribute_2;
}

void PnfCParser::Aux_rule__gccAttribute_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__gccAttribute_2(this);
}

void PnfCParser::Aux_rule__gccAttribute_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__gccAttribute_2(this);
}


antlrcpp::Any PnfCParser::Aux_rule__gccAttribute_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__gccAttribute_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__gccAttribute_2Context* PnfCParser::aux_rule__gccAttribute_2() {
  Aux_rule__gccAttribute_2Context *_localctx = _tracker.createInstance<Aux_rule__gccAttribute_2Context>(_ctx, getState());
  enterRule(_localctx, 124, PnfCParser::RuleAux_rule__gccAttribute_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(782);
    match(PnfCParser::LeftParen);
    setState(783);
    optional__postfixExpression_1();
    setState(784);
    match(PnfCParser::RightParen);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__gccAttribute_3Context ------------------------------------------------------------------

PnfCParser::Optional__gccAttribute_3Context::Optional__gccAttribute_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Aux_rule__gccAttribute_2Context* PnfCParser::Optional__gccAttribute_3Context::aux_rule__gccAttribute_2() {
  return getRuleContext<PnfCParser::Aux_rule__gccAttribute_2Context>(0);
}


size_t PnfCParser::Optional__gccAttribute_3Context::getRuleIndex() const {
  return PnfCParser::RuleOptional__gccAttribute_3;
}

void PnfCParser::Optional__gccAttribute_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__gccAttribute_3(this);
}

void PnfCParser::Optional__gccAttribute_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__gccAttribute_3(this);
}


antlrcpp::Any PnfCParser::Optional__gccAttribute_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitOptional__gccAttribute_3(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Optional__gccAttribute_3Context* PnfCParser::optional__gccAttribute_3() {
  Optional__gccAttribute_3Context *_localctx = _tracker.createInstance<Optional__gccAttribute_3Context>(_ctx, getState());
  enterRule(_localctx, 126, PnfCParser::RuleOptional__gccAttribute_3);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(787);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if (_la == PnfCParser::LeftParen) {
      setState(786);
      aux_rule__gccAttribute_2();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__gccAttribute_4Context ------------------------------------------------------------------

PnfCParser::Aux_rule__gccAttribute_4Context::Aux_rule__gccAttribute_4Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Optional__gccAttribute_3Context* PnfCParser::Aux_rule__gccAttribute_4Context::optional__gccAttribute_3() {
  return getRuleContext<PnfCParser::Optional__gccAttribute_3Context>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__gccAttribute_4Context::Comma() {
  return getToken(PnfCParser::Comma, 0);
}

tree::TerminalNode* PnfCParser::Aux_rule__gccAttribute_4Context::LeftParen() {
  return getToken(PnfCParser::LeftParen, 0);
}

tree::TerminalNode* PnfCParser::Aux_rule__gccAttribute_4Context::RightParen() {
  return getToken(PnfCParser::RightParen, 0);
}


size_t PnfCParser::Aux_rule__gccAttribute_4Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__gccAttribute_4;
}

void PnfCParser::Aux_rule__gccAttribute_4Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__gccAttribute_4(this);
}

void PnfCParser::Aux_rule__gccAttribute_4Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__gccAttribute_4(this);
}


antlrcpp::Any PnfCParser::Aux_rule__gccAttribute_4Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__gccAttribute_4(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__gccAttribute_4Context* PnfCParser::aux_rule__gccAttribute_4() {
  Aux_rule__gccAttribute_4Context *_localctx = _tracker.createInstance<Aux_rule__gccAttribute_4Context>(_ctx, getState());
  enterRule(_localctx, 128, PnfCParser::RuleAux_rule__gccAttribute_4);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(789);
    _la = _input->LA(1);
    if (_la == 0 || _la == Token::EOF || (((((_la - 66) & ~ 0x3fULL) == 0) &&
      ((1ULL << (_la - 66)) & ((1ULL << (PnfCParser::LeftParen - 66))
      | (1ULL << (PnfCParser::RightParen - 66))
      | (1ULL << (PnfCParser::Comma - 66)))) != 0))) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
    setState(790);
    optional__gccAttribute_3();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__pointer_1Context ------------------------------------------------------------------

PnfCParser::Optional__pointer_1Context::Optional__pointer_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::TypeQualifierListContext* PnfCParser::Optional__pointer_1Context::typeQualifierList() {
  return getRuleContext<PnfCParser::TypeQualifierListContext>(0);
}


size_t PnfCParser::Optional__pointer_1Context::getRuleIndex() const {
  return PnfCParser::RuleOptional__pointer_1;
}

void PnfCParser::Optional__pointer_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__pointer_1(this);
}

void PnfCParser::Optional__pointer_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__pointer_1(this);
}


antlrcpp::Any PnfCParser::Optional__pointer_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitOptional__pointer_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Optional__pointer_1Context* PnfCParser::optional__pointer_1() {
  Optional__pointer_1Context *_localctx = _tracker.createInstance<Optional__pointer_1Context>(_ctx, getState());
  enterRule(_localctx, 130, PnfCParser::RuleOptional__pointer_1);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(793);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if ((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << PnfCParser::Const)
      | (1ULL << PnfCParser::Nonnull)
      | (1ULL << PnfCParser::Nullable)
      | (1ULL << PnfCParser::Restrict)
      | (1ULL << PnfCParser::Restrict_gcc)
      | (1ULL << PnfCParser::Restrict_gcc2)
      | (1ULL << PnfCParser::Volatile)
      | (1ULL << PnfCParser::Atomic))) != 0)) {
      setState(792);
      typeQualifierList();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__typeName_1Context ------------------------------------------------------------------

PnfCParser::Optional__typeName_1Context::Optional__typeName_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::AbstractDeclaratorContext* PnfCParser::Optional__typeName_1Context::abstractDeclarator() {
  return getRuleContext<PnfCParser::AbstractDeclaratorContext>(0);
}


size_t PnfCParser::Optional__typeName_1Context::getRuleIndex() const {
  return PnfCParser::RuleOptional__typeName_1;
}

void PnfCParser::Optional__typeName_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__typeName_1(this);
}

void PnfCParser::Optional__typeName_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__typeName_1(this);
}


antlrcpp::Any PnfCParser::Optional__typeName_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitOptional__typeName_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Optional__typeName_1Context* PnfCParser::optional__typeName_1() {
  Optional__typeName_1Context *_localctx = _tracker.createInstance<Optional__typeName_1Context>(_ctx, getState());
  enterRule(_localctx, 132, PnfCParser::RuleOptional__typeName_1);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(796);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if (((((_la - 66) & ~ 0x3fULL) == 0) &&
      ((1ULL << (_la - 66)) & ((1ULL << (PnfCParser::LeftParen - 66))
      | (1ULL << (PnfCParser::LeftBracket - 66))
      | (1ULL << (PnfCParser::Star - 66))
      | (1ULL << (PnfCParser::Caret - 66)))) != 0)) {
      setState(795);
      abstractDeclarator();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__directAbstractDeclarator_5Context ------------------------------------------------------------------

PnfCParser::Optional__directAbstractDeclarator_5Context::Optional__directAbstractDeclarator_5Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::ParameterTypeListContext* PnfCParser::Optional__directAbstractDeclarator_5Context::parameterTypeList() {
  return getRuleContext<PnfCParser::ParameterTypeListContext>(0);
}


size_t PnfCParser::Optional__directAbstractDeclarator_5Context::getRuleIndex() const {
  return PnfCParser::RuleOptional__directAbstractDeclarator_5;
}

void PnfCParser::Optional__directAbstractDeclarator_5Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__directAbstractDeclarator_5(this);
}

void PnfCParser::Optional__directAbstractDeclarator_5Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__directAbstractDeclarator_5(this);
}


antlrcpp::Any PnfCParser::Optional__directAbstractDeclarator_5Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitOptional__directAbstractDeclarator_5(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Optional__directAbstractDeclarator_5Context* PnfCParser::optional__directAbstractDeclarator_5() {
  Optional__directAbstractDeclarator_5Context *_localctx = _tracker.createInstance<Optional__directAbstractDeclarator_5Context>(_ctx, getState());
  enterRule(_localctx, 134, PnfCParser::RuleOptional__directAbstractDeclarator_5);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(799);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if ((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << PnfCParser::T__0)
      | (1ULL << PnfCParser::T__1)
      | (1ULL << PnfCParser::T__2)
      | (1ULL << PnfCParser::T__6)
      | (1ULL << PnfCParser::T__8)
      | (1ULL << PnfCParser::T__9)
      | (1ULL << PnfCParser::T__12)
      | (1ULL << PnfCParser::T__13)
      | (1ULL << PnfCParser::Auto)
      | (1ULL << PnfCParser::Char)
      | (1ULL << PnfCParser::Const)
      | (1ULL << PnfCParser::Nonnull)
      | (1ULL << PnfCParser::Nullable)
      | (1ULL << PnfCParser::Double)
      | (1ULL << PnfCParser::Enum)
      | (1ULL << PnfCParser::Extern)
      | (1ULL << PnfCParser::Float)
      | (1ULL << PnfCParser::Inline)
      | (1ULL << PnfCParser::Int)
      | (1ULL << PnfCParser::Long)
      | (1ULL << PnfCParser::Register)
      | (1ULL << PnfCParser::Restrict)
      | (1ULL << PnfCParser::Restrict_gcc)
      | (1ULL << PnfCParser::Restrict_gcc2)
      | (1ULL << PnfCParser::Extension_gcc)
      | (1ULL << PnfCParser::Short)
      | (1ULL << PnfCParser::Signed)
      | (1ULL << PnfCParser::Static)
      | (1ULL << PnfCParser::Struct)
      | (1ULL << PnfCParser::Typedef)
      | (1ULL << PnfCParser::Union)
      | (1ULL << PnfCParser::Unsigned)
      | (1ULL << PnfCParser::Void)
      | (1ULL << PnfCParser::Volatile)
      | (1ULL << PnfCParser::Alignas)
      | (1ULL << PnfCParser::Atomic)
      | (1ULL << PnfCParser::Bool)
      | (1ULL << PnfCParser::Complex)
      | (1ULL << PnfCParser::Noreturn))) != 0) || _la == PnfCParser::ThreadLocal

    || _la == PnfCParser::Identifier) {
      setState(798);
      parameterTypeList();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__initializerList_1Context ------------------------------------------------------------------

PnfCParser::Optional__initializerList_1Context::Optional__initializerList_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::DesignationContext* PnfCParser::Optional__initializerList_1Context::designation() {
  return getRuleContext<PnfCParser::DesignationContext>(0);
}


size_t PnfCParser::Optional__initializerList_1Context::getRuleIndex() const {
  return PnfCParser::RuleOptional__initializerList_1;
}

void PnfCParser::Optional__initializerList_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__initializerList_1(this);
}

void PnfCParser::Optional__initializerList_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__initializerList_1(this);
}


antlrcpp::Any PnfCParser::Optional__initializerList_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitOptional__initializerList_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Optional__initializerList_1Context* PnfCParser::optional__initializerList_1() {
  Optional__initializerList_1Context *_localctx = _tracker.createInstance<Optional__initializerList_1Context>(_ctx, getState());
  enterRule(_localctx, 136, PnfCParser::RuleOptional__initializerList_1);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(802);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if (_la == PnfCParser::LeftBracket

    || _la == PnfCParser::Dot) {
      setState(801);
      designation();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__asmStatement_1Context ------------------------------------------------------------------

PnfCParser::Aux_rule__asmStatement_1Context::Aux_rule__asmStatement_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__asmStatement_1Context::Volatile() {
  return getToken(PnfCParser::Volatile, 0);
}


size_t PnfCParser::Aux_rule__asmStatement_1Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__asmStatement_1;
}

void PnfCParser::Aux_rule__asmStatement_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__asmStatement_1(this);
}

void PnfCParser::Aux_rule__asmStatement_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__asmStatement_1(this);
}


antlrcpp::Any PnfCParser::Aux_rule__asmStatement_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__asmStatement_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__asmStatement_1Context* PnfCParser::aux_rule__asmStatement_1() {
  Aux_rule__asmStatement_1Context *_localctx = _tracker.createInstance<Aux_rule__asmStatement_1Context>(_ctx, getState());
  enterRule(_localctx, 138, PnfCParser::RuleAux_rule__asmStatement_1);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(804);
    _la = _input->LA(1);
    if (!(_la == PnfCParser::T__7

    || _la == PnfCParser::Volatile)) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__asmStatement_2Context ------------------------------------------------------------------

PnfCParser::Optional__asmStatement_2Context::Optional__asmStatement_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Aux_rule__asmStatement_1Context* PnfCParser::Optional__asmStatement_2Context::aux_rule__asmStatement_1() {
  return getRuleContext<PnfCParser::Aux_rule__asmStatement_1Context>(0);
}


size_t PnfCParser::Optional__asmStatement_2Context::getRuleIndex() const {
  return PnfCParser::RuleOptional__asmStatement_2;
}

void PnfCParser::Optional__asmStatement_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__asmStatement_2(this);
}

void PnfCParser::Optional__asmStatement_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__asmStatement_2(this);
}


antlrcpp::Any PnfCParser::Optional__asmStatement_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitOptional__asmStatement_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Optional__asmStatement_2Context* PnfCParser::optional__asmStatement_2() {
  Optional__asmStatement_2Context *_localctx = _tracker.createInstance<Optional__asmStatement_2Context>(_ctx, getState());
  enterRule(_localctx, 140, PnfCParser::RuleOptional__asmStatement_2);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(807);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if (_la == PnfCParser::T__7

    || _la == PnfCParser::Volatile) {
      setState(806);
      aux_rule__asmStatement_1();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__asmStatement_3Context ------------------------------------------------------------------

PnfCParser::Aux_rule__asmStatement_3Context::Aux_rule__asmStatement_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__asmStatement_3Context::Comma() {
  return getToken(PnfCParser::Comma, 0);
}

PnfCParser::LogicalOrExpressionContext* PnfCParser::Aux_rule__asmStatement_3Context::logicalOrExpression() {
  return getRuleContext<PnfCParser::LogicalOrExpressionContext>(0);
}


size_t PnfCParser::Aux_rule__asmStatement_3Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__asmStatement_3;
}

void PnfCParser::Aux_rule__asmStatement_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__asmStatement_3(this);
}

void PnfCParser::Aux_rule__asmStatement_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__asmStatement_3(this);
}


antlrcpp::Any PnfCParser::Aux_rule__asmStatement_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__asmStatement_3(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__asmStatement_3Context* PnfCParser::aux_rule__asmStatement_3() {
  Aux_rule__asmStatement_3Context *_localctx = _tracker.createInstance<Aux_rule__asmStatement_3Context>(_ctx, getState());
  enterRule(_localctx, 142, PnfCParser::RuleAux_rule__asmStatement_3);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(809);
    match(PnfCParser::Comma);
    setState(810);
    logicalOrExpression();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__asmStatement_4Context ------------------------------------------------------------------

PnfCParser::Kleene_star__asmStatement_4Context::Kleene_star__asmStatement_4Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfCParser::Aux_rule__asmStatement_3Context *> PnfCParser::Kleene_star__asmStatement_4Context::aux_rule__asmStatement_3() {
  return getRuleContexts<PnfCParser::Aux_rule__asmStatement_3Context>();
}

PnfCParser::Aux_rule__asmStatement_3Context* PnfCParser::Kleene_star__asmStatement_4Context::aux_rule__asmStatement_3(size_t i) {
  return getRuleContext<PnfCParser::Aux_rule__asmStatement_3Context>(i);
}


size_t PnfCParser::Kleene_star__asmStatement_4Context::getRuleIndex() const {
  return PnfCParser::RuleKleene_star__asmStatement_4;
}

void PnfCParser::Kleene_star__asmStatement_4Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__asmStatement_4(this);
}

void PnfCParser::Kleene_star__asmStatement_4Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__asmStatement_4(this);
}


antlrcpp::Any PnfCParser::Kleene_star__asmStatement_4Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitKleene_star__asmStatement_4(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Kleene_star__asmStatement_4Context* PnfCParser::kleene_star__asmStatement_4() {
  Kleene_star__asmStatement_4Context *_localctx = _tracker.createInstance<Kleene_star__asmStatement_4Context>(_ctx, getState());
  enterRule(_localctx, 144, PnfCParser::RuleKleene_star__asmStatement_4);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(815);
    _errHandler->sync(this);
    _la = _input->LA(1);
    while (_la == PnfCParser::Comma) {
      setState(812);
      aux_rule__asmStatement_3();
      setState(817);
      _errHandler->sync(this);
      _la = _input->LA(1);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__asmStatement_5Context ------------------------------------------------------------------

PnfCParser::Aux_rule__asmStatement_5Context::Aux_rule__asmStatement_5Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::LogicalOrExpressionContext* PnfCParser::Aux_rule__asmStatement_5Context::logicalOrExpression() {
  return getRuleContext<PnfCParser::LogicalOrExpressionContext>(0);
}

PnfCParser::Kleene_star__asmStatement_4Context* PnfCParser::Aux_rule__asmStatement_5Context::kleene_star__asmStatement_4() {
  return getRuleContext<PnfCParser::Kleene_star__asmStatement_4Context>(0);
}


size_t PnfCParser::Aux_rule__asmStatement_5Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__asmStatement_5;
}

void PnfCParser::Aux_rule__asmStatement_5Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__asmStatement_5(this);
}

void PnfCParser::Aux_rule__asmStatement_5Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__asmStatement_5(this);
}


antlrcpp::Any PnfCParser::Aux_rule__asmStatement_5Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__asmStatement_5(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__asmStatement_5Context* PnfCParser::aux_rule__asmStatement_5() {
  Aux_rule__asmStatement_5Context *_localctx = _tracker.createInstance<Aux_rule__asmStatement_5Context>(_ctx, getState());
  enterRule(_localctx, 146, PnfCParser::RuleAux_rule__asmStatement_5);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(818);
    logicalOrExpression();
    setState(819);
    kleene_star__asmStatement_4();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__asmStatement_6Context ------------------------------------------------------------------

PnfCParser::Optional__asmStatement_6Context::Optional__asmStatement_6Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Aux_rule__asmStatement_5Context* PnfCParser::Optional__asmStatement_6Context::aux_rule__asmStatement_5() {
  return getRuleContext<PnfCParser::Aux_rule__asmStatement_5Context>(0);
}


size_t PnfCParser::Optional__asmStatement_6Context::getRuleIndex() const {
  return PnfCParser::RuleOptional__asmStatement_6;
}

void PnfCParser::Optional__asmStatement_6Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__asmStatement_6(this);
}

void PnfCParser::Optional__asmStatement_6Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__asmStatement_6(this);
}


antlrcpp::Any PnfCParser::Optional__asmStatement_6Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitOptional__asmStatement_6(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Optional__asmStatement_6Context* PnfCParser::optional__asmStatement_6() {
  Optional__asmStatement_6Context *_localctx = _tracker.createInstance<Optional__asmStatement_6Context>(_ctx, getState());
  enterRule(_localctx, 148, PnfCParser::RuleOptional__asmStatement_6);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(822);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if ((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << PnfCParser::T__10)
      | (1ULL << PnfCParser::T__11)
      | (1ULL << PnfCParser::Extension_gcc)
      | (1ULL << PnfCParser::Sizeof)
      | (1ULL << PnfCParser::Alignof)
      | (1ULL << PnfCParser::Alignof_gcc)
      | (1ULL << PnfCParser::Generic))) != 0) || ((((_la - 66) & ~ 0x3fULL) == 0) &&
      ((1ULL << (_la - 66)) & ((1ULL << (PnfCParser::LeftParen - 66))
      | (1ULL << (PnfCParser::Plus - 66))
      | (1ULL << (PnfCParser::PlusPlus - 66))
      | (1ULL << (PnfCParser::Minus - 66))
      | (1ULL << (PnfCParser::MinusMinus - 66))
      | (1ULL << (PnfCParser::Star - 66))
      | (1ULL << (PnfCParser::And - 66))
      | (1ULL << (PnfCParser::AndAnd - 66))
      | (1ULL << (PnfCParser::Not - 66))
      | (1ULL << (PnfCParser::Tilde - 66))
      | (1ULL << (PnfCParser::Identifier - 66))
      | (1ULL << (PnfCParser::Constant - 66))
      | (1ULL << (PnfCParser::StringLiteral - 66)))) != 0)) {
      setState(821);
      aux_rule__asmStatement_5();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__asmStatement_11Context ------------------------------------------------------------------

PnfCParser::Aux_rule__asmStatement_11Context::Aux_rule__asmStatement_11Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__asmStatement_11Context::Colon() {
  return getToken(PnfCParser::Colon, 0);
}

PnfCParser::Optional__asmStatement_6Context* PnfCParser::Aux_rule__asmStatement_11Context::optional__asmStatement_6() {
  return getRuleContext<PnfCParser::Optional__asmStatement_6Context>(0);
}


size_t PnfCParser::Aux_rule__asmStatement_11Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__asmStatement_11;
}

void PnfCParser::Aux_rule__asmStatement_11Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__asmStatement_11(this);
}

void PnfCParser::Aux_rule__asmStatement_11Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__asmStatement_11(this);
}


antlrcpp::Any PnfCParser::Aux_rule__asmStatement_11Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__asmStatement_11(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__asmStatement_11Context* PnfCParser::aux_rule__asmStatement_11() {
  Aux_rule__asmStatement_11Context *_localctx = _tracker.createInstance<Aux_rule__asmStatement_11Context>(_ctx, getState());
  enterRule(_localctx, 150, PnfCParser::RuleAux_rule__asmStatement_11);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(824);
    match(PnfCParser::Colon);
    setState(825);
    optional__asmStatement_6();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__asmStatement_12Context ------------------------------------------------------------------

PnfCParser::Kleene_star__asmStatement_12Context::Kleene_star__asmStatement_12Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfCParser::Aux_rule__asmStatement_11Context *> PnfCParser::Kleene_star__asmStatement_12Context::aux_rule__asmStatement_11() {
  return getRuleContexts<PnfCParser::Aux_rule__asmStatement_11Context>();
}

PnfCParser::Aux_rule__asmStatement_11Context* PnfCParser::Kleene_star__asmStatement_12Context::aux_rule__asmStatement_11(size_t i) {
  return getRuleContext<PnfCParser::Aux_rule__asmStatement_11Context>(i);
}


size_t PnfCParser::Kleene_star__asmStatement_12Context::getRuleIndex() const {
  return PnfCParser::RuleKleene_star__asmStatement_12;
}

void PnfCParser::Kleene_star__asmStatement_12Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__asmStatement_12(this);
}

void PnfCParser::Kleene_star__asmStatement_12Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__asmStatement_12(this);
}


antlrcpp::Any PnfCParser::Kleene_star__asmStatement_12Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitKleene_star__asmStatement_12(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Kleene_star__asmStatement_12Context* PnfCParser::kleene_star__asmStatement_12() {
  Kleene_star__asmStatement_12Context *_localctx = _tracker.createInstance<Kleene_star__asmStatement_12Context>(_ctx, getState());
  enterRule(_localctx, 152, PnfCParser::RuleKleene_star__asmStatement_12);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(830);
    _errHandler->sync(this);
    _la = _input->LA(1);
    while (_la == PnfCParser::Colon) {
      setState(827);
      aux_rule__asmStatement_11();
      setState(832);
      _errHandler->sync(this);
      _la = _input->LA(1);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__compoundStatement_1Context ------------------------------------------------------------------

PnfCParser::Optional__compoundStatement_1Context::Optional__compoundStatement_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::BlockItemListContext* PnfCParser::Optional__compoundStatement_1Context::blockItemList() {
  return getRuleContext<PnfCParser::BlockItemListContext>(0);
}


size_t PnfCParser::Optional__compoundStatement_1Context::getRuleIndex() const {
  return PnfCParser::RuleOptional__compoundStatement_1;
}

void PnfCParser::Optional__compoundStatement_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__compoundStatement_1(this);
}

void PnfCParser::Optional__compoundStatement_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__compoundStatement_1(this);
}


antlrcpp::Any PnfCParser::Optional__compoundStatement_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitOptional__compoundStatement_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Optional__compoundStatement_1Context* PnfCParser::optional__compoundStatement_1() {
  Optional__compoundStatement_1Context *_localctx = _tracker.createInstance<Optional__compoundStatement_1Context>(_ctx, getState());
  enterRule(_localctx, 154, PnfCParser::RuleOptional__compoundStatement_1);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(834);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if ((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << PnfCParser::T__0)
      | (1ULL << PnfCParser::T__1)
      | (1ULL << PnfCParser::T__2)
      | (1ULL << PnfCParser::T__3)
      | (1ULL << PnfCParser::T__4)
      | (1ULL << PnfCParser::T__5)
      | (1ULL << PnfCParser::T__6)
      | (1ULL << PnfCParser::T__8)
      | (1ULL << PnfCParser::T__9)
      | (1ULL << PnfCParser::T__10)
      | (1ULL << PnfCParser::T__11)
      | (1ULL << PnfCParser::T__12)
      | (1ULL << PnfCParser::T__13)
      | (1ULL << PnfCParser::Auto)
      | (1ULL << PnfCParser::Break)
      | (1ULL << PnfCParser::Case)
      | (1ULL << PnfCParser::Char)
      | (1ULL << PnfCParser::Const)
      | (1ULL << PnfCParser::Nonnull)
      | (1ULL << PnfCParser::Nullable)
      | (1ULL << PnfCParser::Continue)
      | (1ULL << PnfCParser::Default)
      | (1ULL << PnfCParser::Do)
      | (1ULL << PnfCParser::Double)
      | (1ULL << PnfCParser::Enum)
      | (1ULL << PnfCParser::Extern)
      | (1ULL << PnfCParser::Float)
      | (1ULL << PnfCParser::For)
      | (1ULL << PnfCParser::Goto)
      | (1ULL << PnfCParser::If)
      | (1ULL << PnfCParser::Inline)
      | (1ULL << PnfCParser::Int)
      | (1ULL << PnfCParser::Long)
      | (1ULL << PnfCParser::Register)
      | (1ULL << PnfCParser::Restrict)
      | (1ULL << PnfCParser::Restrict_gcc)
      | (1ULL << PnfCParser::Restrict_gcc2)
      | (1ULL << PnfCParser::Extension_gcc)
      | (1ULL << PnfCParser::Return)
      | (1ULL << PnfCParser::Short)
      | (1ULL << PnfCParser::Signed)
      | (1ULL << PnfCParser::Sizeof)
      | (1ULL << PnfCParser::Static)
      | (1ULL << PnfCParser::Struct)
      | (1ULL << PnfCParser::Switch)
      | (1ULL << PnfCParser::Typedef)
      | (1ULL << PnfCParser::Union)
      | (1ULL << PnfCParser::Unsigned)
      | (1ULL << PnfCParser::Void)
      | (1ULL << PnfCParser::Volatile)
      | (1ULL << PnfCParser::While)
      | (1ULL << PnfCParser::Alignas)
      | (1ULL << PnfCParser::Alignof)
      | (1ULL << PnfCParser::Alignof_gcc)
      | (1ULL << PnfCParser::Atomic)
      | (1ULL << PnfCParser::Bool)
      | (1ULL << PnfCParser::Complex)
      | (1ULL << PnfCParser::Generic)
      | (1ULL << PnfCParser::Noreturn))) != 0) || ((((_la - 64) & ~ 0x3fULL) == 0) &&
      ((1ULL << (_la - 64)) & ((1ULL << (PnfCParser::StaticAssert - 64))
      | (1ULL << (PnfCParser::ThreadLocal - 64))
      | (1ULL << (PnfCParser::LeftParen - 64))
      | (1ULL << (PnfCParser::LeftBrace - 64))
      | (1ULL << (PnfCParser::Plus - 64))
      | (1ULL << (PnfCParser::PlusPlus - 64))
      | (1ULL << (PnfCParser::Minus - 64))
      | (1ULL << (PnfCParser::MinusMinus - 64))
      | (1ULL << (PnfCParser::Star - 64))
      | (1ULL << (PnfCParser::And - 64))
      | (1ULL << (PnfCParser::AndAnd - 64))
      | (1ULL << (PnfCParser::Not - 64))
      | (1ULL << (PnfCParser::Tilde - 64))
      | (1ULL << (PnfCParser::Semi - 64))
      | (1ULL << (PnfCParser::Identifier - 64))
      | (1ULL << (PnfCParser::Constant - 64))
      | (1ULL << (PnfCParser::StringLiteral - 64)))) != 0)) {
      setState(833);
      blockItemList();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__selectionStatement_1Context ------------------------------------------------------------------

PnfCParser::Aux_rule__selectionStatement_1Context::Aux_rule__selectionStatement_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__selectionStatement_1Context::Else() {
  return getToken(PnfCParser::Else, 0);
}

PnfCParser::StatementContext* PnfCParser::Aux_rule__selectionStatement_1Context::statement() {
  return getRuleContext<PnfCParser::StatementContext>(0);
}


size_t PnfCParser::Aux_rule__selectionStatement_1Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__selectionStatement_1;
}

void PnfCParser::Aux_rule__selectionStatement_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__selectionStatement_1(this);
}

void PnfCParser::Aux_rule__selectionStatement_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__selectionStatement_1(this);
}


antlrcpp::Any PnfCParser::Aux_rule__selectionStatement_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__selectionStatement_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__selectionStatement_1Context* PnfCParser::aux_rule__selectionStatement_1() {
  Aux_rule__selectionStatement_1Context *_localctx = _tracker.createInstance<Aux_rule__selectionStatement_1Context>(_ctx, getState());
  enterRule(_localctx, 156, PnfCParser::RuleAux_rule__selectionStatement_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(836);
    match(PnfCParser::Else);
    setState(837);
    statement();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__selectionStatement_2Context ------------------------------------------------------------------

PnfCParser::Optional__selectionStatement_2Context::Optional__selectionStatement_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Aux_rule__selectionStatement_1Context* PnfCParser::Optional__selectionStatement_2Context::aux_rule__selectionStatement_1() {
  return getRuleContext<PnfCParser::Aux_rule__selectionStatement_1Context>(0);
}


size_t PnfCParser::Optional__selectionStatement_2Context::getRuleIndex() const {
  return PnfCParser::RuleOptional__selectionStatement_2;
}

void PnfCParser::Optional__selectionStatement_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__selectionStatement_2(this);
}

void PnfCParser::Optional__selectionStatement_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__selectionStatement_2(this);
}


antlrcpp::Any PnfCParser::Optional__selectionStatement_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitOptional__selectionStatement_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Optional__selectionStatement_2Context* PnfCParser::optional__selectionStatement_2() {
  Optional__selectionStatement_2Context *_localctx = _tracker.createInstance<Optional__selectionStatement_2Context>(_ctx, getState());
  enterRule(_localctx, 158, PnfCParser::RuleOptional__selectionStatement_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(840);
    _errHandler->sync(this);

    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 37, _ctx)) {
    case 1: {
      setState(839);
      aux_rule__selectionStatement_1();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__compilationUnit_1Context ------------------------------------------------------------------

PnfCParser::Optional__compilationUnit_1Context::Optional__compilationUnit_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::TranslationUnitContext* PnfCParser::Optional__compilationUnit_1Context::translationUnit() {
  return getRuleContext<PnfCParser::TranslationUnitContext>(0);
}


size_t PnfCParser::Optional__compilationUnit_1Context::getRuleIndex() const {
  return PnfCParser::RuleOptional__compilationUnit_1;
}

void PnfCParser::Optional__compilationUnit_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__compilationUnit_1(this);
}

void PnfCParser::Optional__compilationUnit_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__compilationUnit_1(this);
}


antlrcpp::Any PnfCParser::Optional__compilationUnit_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitOptional__compilationUnit_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Optional__compilationUnit_1Context* PnfCParser::optional__compilationUnit_1() {
  Optional__compilationUnit_1Context *_localctx = _tracker.createInstance<Optional__compilationUnit_1Context>(_ctx, getState());
  enterRule(_localctx, 160, PnfCParser::RuleOptional__compilationUnit_1);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(843);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if ((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << PnfCParser::T__0)
      | (1ULL << PnfCParser::T__1)
      | (1ULL << PnfCParser::T__2)
      | (1ULL << PnfCParser::T__3)
      | (1ULL << PnfCParser::T__4)
      | (1ULL << PnfCParser::T__5)
      | (1ULL << PnfCParser::T__6)
      | (1ULL << PnfCParser::T__8)
      | (1ULL << PnfCParser::T__9)
      | (1ULL << PnfCParser::T__12)
      | (1ULL << PnfCParser::T__13)
      | (1ULL << PnfCParser::IncludeDirective)
      | (1ULL << PnfCParser::Auto)
      | (1ULL << PnfCParser::Char)
      | (1ULL << PnfCParser::Const)
      | (1ULL << PnfCParser::Nonnull)
      | (1ULL << PnfCParser::Nullable)
      | (1ULL << PnfCParser::Double)
      | (1ULL << PnfCParser::Enum)
      | (1ULL << PnfCParser::Extern)
      | (1ULL << PnfCParser::Float)
      | (1ULL << PnfCParser::Inline)
      | (1ULL << PnfCParser::Int)
      | (1ULL << PnfCParser::Long)
      | (1ULL << PnfCParser::Register)
      | (1ULL << PnfCParser::Restrict)
      | (1ULL << PnfCParser::Restrict_gcc)
      | (1ULL << PnfCParser::Restrict_gcc2)
      | (1ULL << PnfCParser::Extension_gcc)
      | (1ULL << PnfCParser::Short)
      | (1ULL << PnfCParser::Signed)
      | (1ULL << PnfCParser::Static)
      | (1ULL << PnfCParser::Struct)
      | (1ULL << PnfCParser::Typedef)
      | (1ULL << PnfCParser::Union)
      | (1ULL << PnfCParser::Unsigned)
      | (1ULL << PnfCParser::Void)
      | (1ULL << PnfCParser::Volatile)
      | (1ULL << PnfCParser::Alignas)
      | (1ULL << PnfCParser::Atomic)
      | (1ULL << PnfCParser::Bool)
      | (1ULL << PnfCParser::Complex)
      | (1ULL << PnfCParser::Noreturn))) != 0) || ((((_la - 64) & ~ 0x3fULL) == 0) &&
      ((1ULL << (_la - 64)) & ((1ULL << (PnfCParser::StaticAssert - 64))
      | (1ULL << (PnfCParser::ThreadLocal - 64))
      | (1ULL << (PnfCParser::LeftParen - 64))
      | (1ULL << (PnfCParser::Star - 64))
      | (1ULL << (PnfCParser::Caret - 64))
      | (1ULL << (PnfCParser::Semi - 64))
      | (1ULL << (PnfCParser::Identifier - 64)))) != 0)) {
      setState(842);
      translationUnit();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__functionDefinition_2Context ------------------------------------------------------------------

PnfCParser::Optional__functionDefinition_2Context::Optional__functionDefinition_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::DeclarationSpecifiersContext* PnfCParser::Optional__functionDefinition_2Context::declarationSpecifiers() {
  return getRuleContext<PnfCParser::DeclarationSpecifiersContext>(0);
}


size_t PnfCParser::Optional__functionDefinition_2Context::getRuleIndex() const {
  return PnfCParser::RuleOptional__functionDefinition_2;
}

void PnfCParser::Optional__functionDefinition_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__functionDefinition_2(this);
}

void PnfCParser::Optional__functionDefinition_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__functionDefinition_2(this);
}


antlrcpp::Any PnfCParser::Optional__functionDefinition_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitOptional__functionDefinition_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Optional__functionDefinition_2Context* PnfCParser::optional__functionDefinition_2() {
  Optional__functionDefinition_2Context *_localctx = _tracker.createInstance<Optional__functionDefinition_2Context>(_ctx, getState());
  enterRule(_localctx, 162, PnfCParser::RuleOptional__functionDefinition_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(846);
    _errHandler->sync(this);

    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 39, _ctx)) {
    case 1: {
      setState(845);
      declarationSpecifiers();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__functionDefinition_3Context ------------------------------------------------------------------

PnfCParser::Optional__functionDefinition_3Context::Optional__functionDefinition_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::DeclarationListContext* PnfCParser::Optional__functionDefinition_3Context::declarationList() {
  return getRuleContext<PnfCParser::DeclarationListContext>(0);
}


size_t PnfCParser::Optional__functionDefinition_3Context::getRuleIndex() const {
  return PnfCParser::RuleOptional__functionDefinition_3;
}

void PnfCParser::Optional__functionDefinition_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__functionDefinition_3(this);
}

void PnfCParser::Optional__functionDefinition_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__functionDefinition_3(this);
}


antlrcpp::Any PnfCParser::Optional__functionDefinition_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitOptional__functionDefinition_3(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Optional__functionDefinition_3Context* PnfCParser::optional__functionDefinition_3() {
  Optional__functionDefinition_3Context *_localctx = _tracker.createInstance<Optional__functionDefinition_3Context>(_ctx, getState());
  enterRule(_localctx, 164, PnfCParser::RuleOptional__functionDefinition_3);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(849);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if ((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << PnfCParser::T__0)
      | (1ULL << PnfCParser::T__1)
      | (1ULL << PnfCParser::T__2)
      | (1ULL << PnfCParser::T__3)
      | (1ULL << PnfCParser::T__4)
      | (1ULL << PnfCParser::T__5)
      | (1ULL << PnfCParser::T__6)
      | (1ULL << PnfCParser::T__8)
      | (1ULL << PnfCParser::T__9)
      | (1ULL << PnfCParser::T__12)
      | (1ULL << PnfCParser::T__13)
      | (1ULL << PnfCParser::Auto)
      | (1ULL << PnfCParser::Char)
      | (1ULL << PnfCParser::Const)
      | (1ULL << PnfCParser::Nonnull)
      | (1ULL << PnfCParser::Nullable)
      | (1ULL << PnfCParser::Double)
      | (1ULL << PnfCParser::Enum)
      | (1ULL << PnfCParser::Extern)
      | (1ULL << PnfCParser::Float)
      | (1ULL << PnfCParser::Inline)
      | (1ULL << PnfCParser::Int)
      | (1ULL << PnfCParser::Long)
      | (1ULL << PnfCParser::Register)
      | (1ULL << PnfCParser::Restrict)
      | (1ULL << PnfCParser::Restrict_gcc)
      | (1ULL << PnfCParser::Restrict_gcc2)
      | (1ULL << PnfCParser::Extension_gcc)
      | (1ULL << PnfCParser::Short)
      | (1ULL << PnfCParser::Signed)
      | (1ULL << PnfCParser::Static)
      | (1ULL << PnfCParser::Struct)
      | (1ULL << PnfCParser::Typedef)
      | (1ULL << PnfCParser::Union)
      | (1ULL << PnfCParser::Unsigned)
      | (1ULL << PnfCParser::Void)
      | (1ULL << PnfCParser::Volatile)
      | (1ULL << PnfCParser::Alignas)
      | (1ULL << PnfCParser::Atomic)
      | (1ULL << PnfCParser::Bool)
      | (1ULL << PnfCParser::Complex)
      | (1ULL << PnfCParser::Noreturn))) != 0) || ((((_la - 64) & ~ 0x3fULL) == 0) &&
      ((1ULL << (_la - 64)) & ((1ULL << (PnfCParser::StaticAssert - 64))
      | (1ULL << (PnfCParser::ThreadLocal - 64))
      | (1ULL << (PnfCParser::Identifier - 64)))) != 0)) {
      setState(848);
      declarationList();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__expression_2Context ------------------------------------------------------------------

PnfCParser::Aux_rule__expression_2Context::Aux_rule__expression_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__expression_2Context::Comma() {
  return getToken(PnfCParser::Comma, 0);
}

PnfCParser::AssignmentExpressionContext* PnfCParser::Aux_rule__expression_2Context::assignmentExpression() {
  return getRuleContext<PnfCParser::AssignmentExpressionContext>(0);
}


size_t PnfCParser::Aux_rule__expression_2Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__expression_2;
}

void PnfCParser::Aux_rule__expression_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__expression_2(this);
}

void PnfCParser::Aux_rule__expression_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__expression_2(this);
}


antlrcpp::Any PnfCParser::Aux_rule__expression_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__expression_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__expression_2Context* PnfCParser::aux_rule__expression_2() {
  Aux_rule__expression_2Context *_localctx = _tracker.createInstance<Aux_rule__expression_2Context>(_ctx, getState());
  enterRule(_localctx, 166, PnfCParser::RuleAux_rule__expression_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(851);
    match(PnfCParser::Comma);
    setState(852);
    assignmentExpression();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__expression_1Context ------------------------------------------------------------------

PnfCParser::Kleene_star__expression_1Context::Kleene_star__expression_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfCParser::Aux_rule__expression_2Context *> PnfCParser::Kleene_star__expression_1Context::aux_rule__expression_2() {
  return getRuleContexts<PnfCParser::Aux_rule__expression_2Context>();
}

PnfCParser::Aux_rule__expression_2Context* PnfCParser::Kleene_star__expression_1Context::aux_rule__expression_2(size_t i) {
  return getRuleContext<PnfCParser::Aux_rule__expression_2Context>(i);
}


size_t PnfCParser::Kleene_star__expression_1Context::getRuleIndex() const {
  return PnfCParser::RuleKleene_star__expression_1;
}

void PnfCParser::Kleene_star__expression_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__expression_1(this);
}

void PnfCParser::Kleene_star__expression_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__expression_1(this);
}


antlrcpp::Any PnfCParser::Kleene_star__expression_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitKleene_star__expression_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Kleene_star__expression_1Context* PnfCParser::kleene_star__expression_1() {
  Kleene_star__expression_1Context *_localctx = _tracker.createInstance<Kleene_star__expression_1Context>(_ctx, getState());
  enterRule(_localctx, 168, PnfCParser::RuleKleene_star__expression_1);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(857);
    _errHandler->sync(this);
    _la = _input->LA(1);
    while (_la == PnfCParser::Comma) {
      setState(854);
      aux_rule__expression_2();
      setState(859);
      _errHandler->sync(this);
      _la = _input->LA(1);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ExpressionContext ------------------------------------------------------------------

PnfCParser::ExpressionContext::ExpressionContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::AssignmentExpressionContext* PnfCParser::ExpressionContext::assignmentExpression() {
  return getRuleContext<PnfCParser::AssignmentExpressionContext>(0);
}

PnfCParser::Kleene_star__expression_1Context* PnfCParser::ExpressionContext::kleene_star__expression_1() {
  return getRuleContext<PnfCParser::Kleene_star__expression_1Context>(0);
}


size_t PnfCParser::ExpressionContext::getRuleIndex() const {
  return PnfCParser::RuleExpression;
}

void PnfCParser::ExpressionContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterExpression(this);
}

void PnfCParser::ExpressionContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitExpression(this);
}


antlrcpp::Any PnfCParser::ExpressionContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitExpression(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::ExpressionContext* PnfCParser::expression() {
  ExpressionContext *_localctx = _tracker.createInstance<ExpressionContext>(_ctx, getState());
  enterRule(_localctx, 170, PnfCParser::RuleExpression);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(860);
    assignmentExpression();
    setState(861);
    kleene_star__expression_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__genericAssocList_2Context ------------------------------------------------------------------

PnfCParser::Aux_rule__genericAssocList_2Context::Aux_rule__genericAssocList_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__genericAssocList_2Context::Comma() {
  return getToken(PnfCParser::Comma, 0);
}

PnfCParser::GenericAssociationContext* PnfCParser::Aux_rule__genericAssocList_2Context::genericAssociation() {
  return getRuleContext<PnfCParser::GenericAssociationContext>(0);
}


size_t PnfCParser::Aux_rule__genericAssocList_2Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__genericAssocList_2;
}

void PnfCParser::Aux_rule__genericAssocList_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__genericAssocList_2(this);
}

void PnfCParser::Aux_rule__genericAssocList_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__genericAssocList_2(this);
}


antlrcpp::Any PnfCParser::Aux_rule__genericAssocList_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__genericAssocList_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__genericAssocList_2Context* PnfCParser::aux_rule__genericAssocList_2() {
  Aux_rule__genericAssocList_2Context *_localctx = _tracker.createInstance<Aux_rule__genericAssocList_2Context>(_ctx, getState());
  enterRule(_localctx, 172, PnfCParser::RuleAux_rule__genericAssocList_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(863);
    match(PnfCParser::Comma);
    setState(864);
    genericAssociation();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__genericAssocList_1Context ------------------------------------------------------------------

PnfCParser::Kleene_star__genericAssocList_1Context::Kleene_star__genericAssocList_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfCParser::Aux_rule__genericAssocList_2Context *> PnfCParser::Kleene_star__genericAssocList_1Context::aux_rule__genericAssocList_2() {
  return getRuleContexts<PnfCParser::Aux_rule__genericAssocList_2Context>();
}

PnfCParser::Aux_rule__genericAssocList_2Context* PnfCParser::Kleene_star__genericAssocList_1Context::aux_rule__genericAssocList_2(size_t i) {
  return getRuleContext<PnfCParser::Aux_rule__genericAssocList_2Context>(i);
}


size_t PnfCParser::Kleene_star__genericAssocList_1Context::getRuleIndex() const {
  return PnfCParser::RuleKleene_star__genericAssocList_1;
}

void PnfCParser::Kleene_star__genericAssocList_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__genericAssocList_1(this);
}

void PnfCParser::Kleene_star__genericAssocList_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__genericAssocList_1(this);
}


antlrcpp::Any PnfCParser::Kleene_star__genericAssocList_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitKleene_star__genericAssocList_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Kleene_star__genericAssocList_1Context* PnfCParser::kleene_star__genericAssocList_1() {
  Kleene_star__genericAssocList_1Context *_localctx = _tracker.createInstance<Kleene_star__genericAssocList_1Context>(_ctx, getState());
  enterRule(_localctx, 174, PnfCParser::RuleKleene_star__genericAssocList_1);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(869);
    _errHandler->sync(this);
    _la = _input->LA(1);
    while (_la == PnfCParser::Comma) {
      setState(866);
      aux_rule__genericAssocList_2();
      setState(871);
      _errHandler->sync(this);
      _la = _input->LA(1);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- GenericAssocListContext ------------------------------------------------------------------

PnfCParser::GenericAssocListContext::GenericAssocListContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::GenericAssociationContext* PnfCParser::GenericAssocListContext::genericAssociation() {
  return getRuleContext<PnfCParser::GenericAssociationContext>(0);
}

PnfCParser::Kleene_star__genericAssocList_1Context* PnfCParser::GenericAssocListContext::kleene_star__genericAssocList_1() {
  return getRuleContext<PnfCParser::Kleene_star__genericAssocList_1Context>(0);
}


size_t PnfCParser::GenericAssocListContext::getRuleIndex() const {
  return PnfCParser::RuleGenericAssocList;
}

void PnfCParser::GenericAssocListContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterGenericAssocList(this);
}

void PnfCParser::GenericAssocListContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitGenericAssocList(this);
}


antlrcpp::Any PnfCParser::GenericAssocListContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitGenericAssocList(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::GenericAssocListContext* PnfCParser::genericAssocList() {
  GenericAssocListContext *_localctx = _tracker.createInstance<GenericAssocListContext>(_ctx, getState());
  enterRule(_localctx, 176, PnfCParser::RuleGenericAssocList);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(872);
    genericAssociation();
    setState(873);
    kleene_star__genericAssocList_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__postfixExpression_3Context ------------------------------------------------------------------

PnfCParser::Aux_rule__postfixExpression_3Context::Aux_rule__postfixExpression_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Aux_rule__postfixExpression_10Context* PnfCParser::Aux_rule__postfixExpression_3Context::aux_rule__postfixExpression_10() {
  return getRuleContext<PnfCParser::Aux_rule__postfixExpression_10Context>(0);
}

PnfCParser::Aux_rule__postfixExpression_11Context* PnfCParser::Aux_rule__postfixExpression_3Context::aux_rule__postfixExpression_11() {
  return getRuleContext<PnfCParser::Aux_rule__postfixExpression_11Context>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__postfixExpression_3Context::PlusPlus() {
  return getToken(PnfCParser::PlusPlus, 0);
}

tree::TerminalNode* PnfCParser::Aux_rule__postfixExpression_3Context::MinusMinus() {
  return getToken(PnfCParser::MinusMinus, 0);
}

PnfCParser::Aux_rule__postfixExpression_12Context* PnfCParser::Aux_rule__postfixExpression_3Context::aux_rule__postfixExpression_12() {
  return getRuleContext<PnfCParser::Aux_rule__postfixExpression_12Context>(0);
}


size_t PnfCParser::Aux_rule__postfixExpression_3Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__postfixExpression_3;
}

void PnfCParser::Aux_rule__postfixExpression_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__postfixExpression_3(this);
}

void PnfCParser::Aux_rule__postfixExpression_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__postfixExpression_3(this);
}


antlrcpp::Any PnfCParser::Aux_rule__postfixExpression_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__postfixExpression_3(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__postfixExpression_3Context* PnfCParser::aux_rule__postfixExpression_3() {
  Aux_rule__postfixExpression_3Context *_localctx = _tracker.createInstance<Aux_rule__postfixExpression_3Context>(_ctx, getState());
  enterRule(_localctx, 178, PnfCParser::RuleAux_rule__postfixExpression_3);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(880);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case PnfCParser::LeftBracket: {
        enterOuterAlt(_localctx, 1);
        setState(875);
        aux_rule__postfixExpression_10();
        break;
      }

      case PnfCParser::LeftParen: {
        enterOuterAlt(_localctx, 2);
        setState(876);
        aux_rule__postfixExpression_11();
        break;
      }

      case PnfCParser::PlusPlus: {
        enterOuterAlt(_localctx, 3);
        setState(877);
        match(PnfCParser::PlusPlus);
        break;
      }

      case PnfCParser::MinusMinus: {
        enterOuterAlt(_localctx, 4);
        setState(878);
        match(PnfCParser::MinusMinus);
        break;
      }

      case PnfCParser::Arrow:
      case PnfCParser::Dot: {
        enterOuterAlt(_localctx, 5);
        setState(879);
        aux_rule__postfixExpression_12();
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__postfixExpression_2Context ------------------------------------------------------------------

PnfCParser::Kleene_star__postfixExpression_2Context::Kleene_star__postfixExpression_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfCParser::Aux_rule__postfixExpression_3Context *> PnfCParser::Kleene_star__postfixExpression_2Context::aux_rule__postfixExpression_3() {
  return getRuleContexts<PnfCParser::Aux_rule__postfixExpression_3Context>();
}

PnfCParser::Aux_rule__postfixExpression_3Context* PnfCParser::Kleene_star__postfixExpression_2Context::aux_rule__postfixExpression_3(size_t i) {
  return getRuleContext<PnfCParser::Aux_rule__postfixExpression_3Context>(i);
}


size_t PnfCParser::Kleene_star__postfixExpression_2Context::getRuleIndex() const {
  return PnfCParser::RuleKleene_star__postfixExpression_2;
}

void PnfCParser::Kleene_star__postfixExpression_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__postfixExpression_2(this);
}

void PnfCParser::Kleene_star__postfixExpression_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__postfixExpression_2(this);
}


antlrcpp::Any PnfCParser::Kleene_star__postfixExpression_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitKleene_star__postfixExpression_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Kleene_star__postfixExpression_2Context* PnfCParser::kleene_star__postfixExpression_2() {
  Kleene_star__postfixExpression_2Context *_localctx = _tracker.createInstance<Kleene_star__postfixExpression_2Context>(_ctx, getState());
  enterRule(_localctx, 180, PnfCParser::RuleKleene_star__postfixExpression_2);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(885);
    _errHandler->sync(this);
    _la = _input->LA(1);
    while (((((_la - 66) & ~ 0x3fULL) == 0) &&
      ((1ULL << (_la - 66)) & ((1ULL << (PnfCParser::LeftParen - 66))
      | (1ULL << (PnfCParser::LeftBracket - 66))
      | (1ULL << (PnfCParser::PlusPlus - 66))
      | (1ULL << (PnfCParser::MinusMinus - 66))
      | (1ULL << (PnfCParser::Arrow - 66))
      | (1ULL << (PnfCParser::Dot - 66)))) != 0)) {
      setState(882);
      aux_rule__postfixExpression_3();
      setState(887);
      _errHandler->sync(this);
      _la = _input->LA(1);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- PostfixExpressionContext ------------------------------------------------------------------

PnfCParser::PostfixExpressionContext::PostfixExpressionContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Aux_rule__postfixExpression_4Context* PnfCParser::PostfixExpressionContext::aux_rule__postfixExpression_4() {
  return getRuleContext<PnfCParser::Aux_rule__postfixExpression_4Context>(0);
}

PnfCParser::Kleene_star__postfixExpression_2Context* PnfCParser::PostfixExpressionContext::kleene_star__postfixExpression_2() {
  return getRuleContext<PnfCParser::Kleene_star__postfixExpression_2Context>(0);
}


size_t PnfCParser::PostfixExpressionContext::getRuleIndex() const {
  return PnfCParser::RulePostfixExpression;
}

void PnfCParser::PostfixExpressionContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterPostfixExpression(this);
}

void PnfCParser::PostfixExpressionContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitPostfixExpression(this);
}


antlrcpp::Any PnfCParser::PostfixExpressionContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitPostfixExpression(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::PostfixExpressionContext* PnfCParser::postfixExpression() {
  PostfixExpressionContext *_localctx = _tracker.createInstance<PostfixExpressionContext>(_ctx, getState());
  enterRule(_localctx, 182, PnfCParser::RulePostfixExpression);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(888);
    aux_rule__postfixExpression_4();
    setState(889);
    kleene_star__postfixExpression_2();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__initializerList_4Context ------------------------------------------------------------------

PnfCParser::Aux_rule__initializerList_4Context::Aux_rule__initializerList_4Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__initializerList_4Context::Comma() {
  return getToken(PnfCParser::Comma, 0);
}

PnfCParser::Optional__initializerList_1Context* PnfCParser::Aux_rule__initializerList_4Context::optional__initializerList_1() {
  return getRuleContext<PnfCParser::Optional__initializerList_1Context>(0);
}

PnfCParser::InitializerContext* PnfCParser::Aux_rule__initializerList_4Context::initializer() {
  return getRuleContext<PnfCParser::InitializerContext>(0);
}


size_t PnfCParser::Aux_rule__initializerList_4Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__initializerList_4;
}

void PnfCParser::Aux_rule__initializerList_4Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__initializerList_4(this);
}

void PnfCParser::Aux_rule__initializerList_4Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__initializerList_4(this);
}


antlrcpp::Any PnfCParser::Aux_rule__initializerList_4Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__initializerList_4(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__initializerList_4Context* PnfCParser::aux_rule__initializerList_4() {
  Aux_rule__initializerList_4Context *_localctx = _tracker.createInstance<Aux_rule__initializerList_4Context>(_ctx, getState());
  enterRule(_localctx, 184, PnfCParser::RuleAux_rule__initializerList_4);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(891);
    match(PnfCParser::Comma);
    setState(892);
    optional__initializerList_1();
    setState(893);
    initializer();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__initializerList_3Context ------------------------------------------------------------------

PnfCParser::Kleene_star__initializerList_3Context::Kleene_star__initializerList_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfCParser::Aux_rule__initializerList_4Context *> PnfCParser::Kleene_star__initializerList_3Context::aux_rule__initializerList_4() {
  return getRuleContexts<PnfCParser::Aux_rule__initializerList_4Context>();
}

PnfCParser::Aux_rule__initializerList_4Context* PnfCParser::Kleene_star__initializerList_3Context::aux_rule__initializerList_4(size_t i) {
  return getRuleContext<PnfCParser::Aux_rule__initializerList_4Context>(i);
}


size_t PnfCParser::Kleene_star__initializerList_3Context::getRuleIndex() const {
  return PnfCParser::RuleKleene_star__initializerList_3;
}

void PnfCParser::Kleene_star__initializerList_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__initializerList_3(this);
}

void PnfCParser::Kleene_star__initializerList_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__initializerList_3(this);
}


antlrcpp::Any PnfCParser::Kleene_star__initializerList_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitKleene_star__initializerList_3(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Kleene_star__initializerList_3Context* PnfCParser::kleene_star__initializerList_3() {
  Kleene_star__initializerList_3Context *_localctx = _tracker.createInstance<Kleene_star__initializerList_3Context>(_ctx, getState());
  enterRule(_localctx, 186, PnfCParser::RuleKleene_star__initializerList_3);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    size_t alt;
    enterOuterAlt(_localctx, 1);
    setState(898);
    _errHandler->sync(this);
    alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 45, _ctx);
    while (alt != 2 && alt != atn::ATN::INVALID_ALT_NUMBER) {
      if (alt == 1) {
        setState(895);
        aux_rule__initializerList_4(); 
      }
      setState(900);
      _errHandler->sync(this);
      alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 45, _ctx);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- InitializerListContext ------------------------------------------------------------------

PnfCParser::InitializerListContext::InitializerListContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Optional__initializerList_1Context* PnfCParser::InitializerListContext::optional__initializerList_1() {
  return getRuleContext<PnfCParser::Optional__initializerList_1Context>(0);
}

PnfCParser::InitializerContext* PnfCParser::InitializerListContext::initializer() {
  return getRuleContext<PnfCParser::InitializerContext>(0);
}

PnfCParser::Kleene_star__initializerList_3Context* PnfCParser::InitializerListContext::kleene_star__initializerList_3() {
  return getRuleContext<PnfCParser::Kleene_star__initializerList_3Context>(0);
}


size_t PnfCParser::InitializerListContext::getRuleIndex() const {
  return PnfCParser::RuleInitializerList;
}

void PnfCParser::InitializerListContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterInitializerList(this);
}

void PnfCParser::InitializerListContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitInitializerList(this);
}


antlrcpp::Any PnfCParser::InitializerListContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitInitializerList(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::InitializerListContext* PnfCParser::initializerList() {
  InitializerListContext *_localctx = _tracker.createInstance<InitializerListContext>(_ctx, getState());
  enterRule(_localctx, 188, PnfCParser::RuleInitializerList);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(901);
    optional__initializerList_1();
    setState(902);
    initializer();
    setState(903);
    kleene_star__initializerList_3();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__multiplicativeExpression_2Context ------------------------------------------------------------------

PnfCParser::Aux_rule__multiplicativeExpression_2Context::Aux_rule__multiplicativeExpression_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Altnt_block__multiplicativeExpression_3Context* PnfCParser::Aux_rule__multiplicativeExpression_2Context::altnt_block__multiplicativeExpression_3() {
  return getRuleContext<PnfCParser::Altnt_block__multiplicativeExpression_3Context>(0);
}

PnfCParser::CastExpressionContext* PnfCParser::Aux_rule__multiplicativeExpression_2Context::castExpression() {
  return getRuleContext<PnfCParser::CastExpressionContext>(0);
}


size_t PnfCParser::Aux_rule__multiplicativeExpression_2Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__multiplicativeExpression_2;
}

void PnfCParser::Aux_rule__multiplicativeExpression_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__multiplicativeExpression_2(this);
}

void PnfCParser::Aux_rule__multiplicativeExpression_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__multiplicativeExpression_2(this);
}


antlrcpp::Any PnfCParser::Aux_rule__multiplicativeExpression_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__multiplicativeExpression_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__multiplicativeExpression_2Context* PnfCParser::aux_rule__multiplicativeExpression_2() {
  Aux_rule__multiplicativeExpression_2Context *_localctx = _tracker.createInstance<Aux_rule__multiplicativeExpression_2Context>(_ctx, getState());
  enterRule(_localctx, 190, PnfCParser::RuleAux_rule__multiplicativeExpression_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(905);
    altnt_block__multiplicativeExpression_3();
    setState(906);
    castExpression();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__multiplicativeExpression_1Context ------------------------------------------------------------------

PnfCParser::Kleene_star__multiplicativeExpression_1Context::Kleene_star__multiplicativeExpression_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfCParser::Aux_rule__multiplicativeExpression_2Context *> PnfCParser::Kleene_star__multiplicativeExpression_1Context::aux_rule__multiplicativeExpression_2() {
  return getRuleContexts<PnfCParser::Aux_rule__multiplicativeExpression_2Context>();
}

PnfCParser::Aux_rule__multiplicativeExpression_2Context* PnfCParser::Kleene_star__multiplicativeExpression_1Context::aux_rule__multiplicativeExpression_2(size_t i) {
  return getRuleContext<PnfCParser::Aux_rule__multiplicativeExpression_2Context>(i);
}


size_t PnfCParser::Kleene_star__multiplicativeExpression_1Context::getRuleIndex() const {
  return PnfCParser::RuleKleene_star__multiplicativeExpression_1;
}

void PnfCParser::Kleene_star__multiplicativeExpression_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__multiplicativeExpression_1(this);
}

void PnfCParser::Kleene_star__multiplicativeExpression_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__multiplicativeExpression_1(this);
}


antlrcpp::Any PnfCParser::Kleene_star__multiplicativeExpression_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitKleene_star__multiplicativeExpression_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Kleene_star__multiplicativeExpression_1Context* PnfCParser::kleene_star__multiplicativeExpression_1() {
  Kleene_star__multiplicativeExpression_1Context *_localctx = _tracker.createInstance<Kleene_star__multiplicativeExpression_1Context>(_ctx, getState());
  enterRule(_localctx, 192, PnfCParser::RuleKleene_star__multiplicativeExpression_1);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(911);
    _errHandler->sync(this);
    _la = _input->LA(1);
    while (((((_la - 82) & ~ 0x3fULL) == 0) &&
      ((1ULL << (_la - 82)) & ((1ULL << (PnfCParser::Star - 82))
      | (1ULL << (PnfCParser::Div - 82))
      | (1ULL << (PnfCParser::Mod - 82)))) != 0)) {
      setState(908);
      aux_rule__multiplicativeExpression_2();
      setState(913);
      _errHandler->sync(this);
      _la = _input->LA(1);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- MultiplicativeExpressionContext ------------------------------------------------------------------

PnfCParser::MultiplicativeExpressionContext::MultiplicativeExpressionContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::CastExpressionContext* PnfCParser::MultiplicativeExpressionContext::castExpression() {
  return getRuleContext<PnfCParser::CastExpressionContext>(0);
}

PnfCParser::Kleene_star__multiplicativeExpression_1Context* PnfCParser::MultiplicativeExpressionContext::kleene_star__multiplicativeExpression_1() {
  return getRuleContext<PnfCParser::Kleene_star__multiplicativeExpression_1Context>(0);
}


size_t PnfCParser::MultiplicativeExpressionContext::getRuleIndex() const {
  return PnfCParser::RuleMultiplicativeExpression;
}

void PnfCParser::MultiplicativeExpressionContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterMultiplicativeExpression(this);
}

void PnfCParser::MultiplicativeExpressionContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitMultiplicativeExpression(this);
}


antlrcpp::Any PnfCParser::MultiplicativeExpressionContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitMultiplicativeExpression(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::MultiplicativeExpressionContext* PnfCParser::multiplicativeExpression() {
  MultiplicativeExpressionContext *_localctx = _tracker.createInstance<MultiplicativeExpressionContext>(_ctx, getState());
  enterRule(_localctx, 194, PnfCParser::RuleMultiplicativeExpression);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(914);
    castExpression();
    setState(915);
    kleene_star__multiplicativeExpression_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__additiveExpression_2Context ------------------------------------------------------------------

PnfCParser::Aux_rule__additiveExpression_2Context::Aux_rule__additiveExpression_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Altnt_block__additiveExpression_3Context* PnfCParser::Aux_rule__additiveExpression_2Context::altnt_block__additiveExpression_3() {
  return getRuleContext<PnfCParser::Altnt_block__additiveExpression_3Context>(0);
}

PnfCParser::MultiplicativeExpressionContext* PnfCParser::Aux_rule__additiveExpression_2Context::multiplicativeExpression() {
  return getRuleContext<PnfCParser::MultiplicativeExpressionContext>(0);
}


size_t PnfCParser::Aux_rule__additiveExpression_2Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__additiveExpression_2;
}

void PnfCParser::Aux_rule__additiveExpression_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__additiveExpression_2(this);
}

void PnfCParser::Aux_rule__additiveExpression_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__additiveExpression_2(this);
}


antlrcpp::Any PnfCParser::Aux_rule__additiveExpression_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__additiveExpression_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__additiveExpression_2Context* PnfCParser::aux_rule__additiveExpression_2() {
  Aux_rule__additiveExpression_2Context *_localctx = _tracker.createInstance<Aux_rule__additiveExpression_2Context>(_ctx, getState());
  enterRule(_localctx, 196, PnfCParser::RuleAux_rule__additiveExpression_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(917);
    altnt_block__additiveExpression_3();
    setState(918);
    multiplicativeExpression();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__additiveExpression_1Context ------------------------------------------------------------------

PnfCParser::Kleene_star__additiveExpression_1Context::Kleene_star__additiveExpression_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfCParser::Aux_rule__additiveExpression_2Context *> PnfCParser::Kleene_star__additiveExpression_1Context::aux_rule__additiveExpression_2() {
  return getRuleContexts<PnfCParser::Aux_rule__additiveExpression_2Context>();
}

PnfCParser::Aux_rule__additiveExpression_2Context* PnfCParser::Kleene_star__additiveExpression_1Context::aux_rule__additiveExpression_2(size_t i) {
  return getRuleContext<PnfCParser::Aux_rule__additiveExpression_2Context>(i);
}


size_t PnfCParser::Kleene_star__additiveExpression_1Context::getRuleIndex() const {
  return PnfCParser::RuleKleene_star__additiveExpression_1;
}

void PnfCParser::Kleene_star__additiveExpression_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__additiveExpression_1(this);
}

void PnfCParser::Kleene_star__additiveExpression_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__additiveExpression_1(this);
}


antlrcpp::Any PnfCParser::Kleene_star__additiveExpression_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitKleene_star__additiveExpression_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Kleene_star__additiveExpression_1Context* PnfCParser::kleene_star__additiveExpression_1() {
  Kleene_star__additiveExpression_1Context *_localctx = _tracker.createInstance<Kleene_star__additiveExpression_1Context>(_ctx, getState());
  enterRule(_localctx, 198, PnfCParser::RuleKleene_star__additiveExpression_1);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(923);
    _errHandler->sync(this);
    _la = _input->LA(1);
    while (_la == PnfCParser::Plus

    || _la == PnfCParser::Minus) {
      setState(920);
      aux_rule__additiveExpression_2();
      setState(925);
      _errHandler->sync(this);
      _la = _input->LA(1);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- AdditiveExpressionContext ------------------------------------------------------------------

PnfCParser::AdditiveExpressionContext::AdditiveExpressionContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::MultiplicativeExpressionContext* PnfCParser::AdditiveExpressionContext::multiplicativeExpression() {
  return getRuleContext<PnfCParser::MultiplicativeExpressionContext>(0);
}

PnfCParser::Kleene_star__additiveExpression_1Context* PnfCParser::AdditiveExpressionContext::kleene_star__additiveExpression_1() {
  return getRuleContext<PnfCParser::Kleene_star__additiveExpression_1Context>(0);
}


size_t PnfCParser::AdditiveExpressionContext::getRuleIndex() const {
  return PnfCParser::RuleAdditiveExpression;
}

void PnfCParser::AdditiveExpressionContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAdditiveExpression(this);
}

void PnfCParser::AdditiveExpressionContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAdditiveExpression(this);
}


antlrcpp::Any PnfCParser::AdditiveExpressionContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAdditiveExpression(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::AdditiveExpressionContext* PnfCParser::additiveExpression() {
  AdditiveExpressionContext *_localctx = _tracker.createInstance<AdditiveExpressionContext>(_ctx, getState());
  enterRule(_localctx, 200, PnfCParser::RuleAdditiveExpression);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(926);
    multiplicativeExpression();
    setState(927);
    kleene_star__additiveExpression_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__shiftExpression_2Context ------------------------------------------------------------------

PnfCParser::Aux_rule__shiftExpression_2Context::Aux_rule__shiftExpression_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Altnt_block__shiftExpression_3Context* PnfCParser::Aux_rule__shiftExpression_2Context::altnt_block__shiftExpression_3() {
  return getRuleContext<PnfCParser::Altnt_block__shiftExpression_3Context>(0);
}

PnfCParser::AdditiveExpressionContext* PnfCParser::Aux_rule__shiftExpression_2Context::additiveExpression() {
  return getRuleContext<PnfCParser::AdditiveExpressionContext>(0);
}


size_t PnfCParser::Aux_rule__shiftExpression_2Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__shiftExpression_2;
}

void PnfCParser::Aux_rule__shiftExpression_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__shiftExpression_2(this);
}

void PnfCParser::Aux_rule__shiftExpression_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__shiftExpression_2(this);
}


antlrcpp::Any PnfCParser::Aux_rule__shiftExpression_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__shiftExpression_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__shiftExpression_2Context* PnfCParser::aux_rule__shiftExpression_2() {
  Aux_rule__shiftExpression_2Context *_localctx = _tracker.createInstance<Aux_rule__shiftExpression_2Context>(_ctx, getState());
  enterRule(_localctx, 202, PnfCParser::RuleAux_rule__shiftExpression_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(929);
    altnt_block__shiftExpression_3();
    setState(930);
    additiveExpression();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__shiftExpression_1Context ------------------------------------------------------------------

PnfCParser::Kleene_star__shiftExpression_1Context::Kleene_star__shiftExpression_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfCParser::Aux_rule__shiftExpression_2Context *> PnfCParser::Kleene_star__shiftExpression_1Context::aux_rule__shiftExpression_2() {
  return getRuleContexts<PnfCParser::Aux_rule__shiftExpression_2Context>();
}

PnfCParser::Aux_rule__shiftExpression_2Context* PnfCParser::Kleene_star__shiftExpression_1Context::aux_rule__shiftExpression_2(size_t i) {
  return getRuleContext<PnfCParser::Aux_rule__shiftExpression_2Context>(i);
}


size_t PnfCParser::Kleene_star__shiftExpression_1Context::getRuleIndex() const {
  return PnfCParser::RuleKleene_star__shiftExpression_1;
}

void PnfCParser::Kleene_star__shiftExpression_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__shiftExpression_1(this);
}

void PnfCParser::Kleene_star__shiftExpression_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__shiftExpression_1(this);
}


antlrcpp::Any PnfCParser::Kleene_star__shiftExpression_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitKleene_star__shiftExpression_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Kleene_star__shiftExpression_1Context* PnfCParser::kleene_star__shiftExpression_1() {
  Kleene_star__shiftExpression_1Context *_localctx = _tracker.createInstance<Kleene_star__shiftExpression_1Context>(_ctx, getState());
  enterRule(_localctx, 204, PnfCParser::RuleKleene_star__shiftExpression_1);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(935);
    _errHandler->sync(this);
    _la = _input->LA(1);
    while (_la == PnfCParser::LeftShift

    || _la == PnfCParser::RightShift) {
      setState(932);
      aux_rule__shiftExpression_2();
      setState(937);
      _errHandler->sync(this);
      _la = _input->LA(1);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ShiftExpressionContext ------------------------------------------------------------------

PnfCParser::ShiftExpressionContext::ShiftExpressionContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::AdditiveExpressionContext* PnfCParser::ShiftExpressionContext::additiveExpression() {
  return getRuleContext<PnfCParser::AdditiveExpressionContext>(0);
}

PnfCParser::Kleene_star__shiftExpression_1Context* PnfCParser::ShiftExpressionContext::kleene_star__shiftExpression_1() {
  return getRuleContext<PnfCParser::Kleene_star__shiftExpression_1Context>(0);
}


size_t PnfCParser::ShiftExpressionContext::getRuleIndex() const {
  return PnfCParser::RuleShiftExpression;
}

void PnfCParser::ShiftExpressionContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterShiftExpression(this);
}

void PnfCParser::ShiftExpressionContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitShiftExpression(this);
}


antlrcpp::Any PnfCParser::ShiftExpressionContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitShiftExpression(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::ShiftExpressionContext* PnfCParser::shiftExpression() {
  ShiftExpressionContext *_localctx = _tracker.createInstance<ShiftExpressionContext>(_ctx, getState());
  enterRule(_localctx, 206, PnfCParser::RuleShiftExpression);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(938);
    additiveExpression();
    setState(939);
    kleene_star__shiftExpression_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__relationalExpression_2Context ------------------------------------------------------------------

PnfCParser::Aux_rule__relationalExpression_2Context::Aux_rule__relationalExpression_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Altnt_block__relationalExpression_3Context* PnfCParser::Aux_rule__relationalExpression_2Context::altnt_block__relationalExpression_3() {
  return getRuleContext<PnfCParser::Altnt_block__relationalExpression_3Context>(0);
}

PnfCParser::ShiftExpressionContext* PnfCParser::Aux_rule__relationalExpression_2Context::shiftExpression() {
  return getRuleContext<PnfCParser::ShiftExpressionContext>(0);
}


size_t PnfCParser::Aux_rule__relationalExpression_2Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__relationalExpression_2;
}

void PnfCParser::Aux_rule__relationalExpression_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__relationalExpression_2(this);
}

void PnfCParser::Aux_rule__relationalExpression_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__relationalExpression_2(this);
}


antlrcpp::Any PnfCParser::Aux_rule__relationalExpression_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__relationalExpression_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__relationalExpression_2Context* PnfCParser::aux_rule__relationalExpression_2() {
  Aux_rule__relationalExpression_2Context *_localctx = _tracker.createInstance<Aux_rule__relationalExpression_2Context>(_ctx, getState());
  enterRule(_localctx, 208, PnfCParser::RuleAux_rule__relationalExpression_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(941);
    altnt_block__relationalExpression_3();
    setState(942);
    shiftExpression();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__relationalExpression_1Context ------------------------------------------------------------------

PnfCParser::Kleene_star__relationalExpression_1Context::Kleene_star__relationalExpression_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfCParser::Aux_rule__relationalExpression_2Context *> PnfCParser::Kleene_star__relationalExpression_1Context::aux_rule__relationalExpression_2() {
  return getRuleContexts<PnfCParser::Aux_rule__relationalExpression_2Context>();
}

PnfCParser::Aux_rule__relationalExpression_2Context* PnfCParser::Kleene_star__relationalExpression_1Context::aux_rule__relationalExpression_2(size_t i) {
  return getRuleContext<PnfCParser::Aux_rule__relationalExpression_2Context>(i);
}


size_t PnfCParser::Kleene_star__relationalExpression_1Context::getRuleIndex() const {
  return PnfCParser::RuleKleene_star__relationalExpression_1;
}

void PnfCParser::Kleene_star__relationalExpression_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__relationalExpression_1(this);
}

void PnfCParser::Kleene_star__relationalExpression_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__relationalExpression_1(this);
}


antlrcpp::Any PnfCParser::Kleene_star__relationalExpression_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitKleene_star__relationalExpression_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Kleene_star__relationalExpression_1Context* PnfCParser::kleene_star__relationalExpression_1() {
  Kleene_star__relationalExpression_1Context *_localctx = _tracker.createInstance<Kleene_star__relationalExpression_1Context>(_ctx, getState());
  enterRule(_localctx, 210, PnfCParser::RuleKleene_star__relationalExpression_1);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(947);
    _errHandler->sync(this);
    _la = _input->LA(1);
    while (((((_la - 72) & ~ 0x3fULL) == 0) &&
      ((1ULL << (_la - 72)) & ((1ULL << (PnfCParser::Less - 72))
      | (1ULL << (PnfCParser::LessEqual - 72))
      | (1ULL << (PnfCParser::Greater - 72))
      | (1ULL << (PnfCParser::GreaterEqual - 72)))) != 0)) {
      setState(944);
      aux_rule__relationalExpression_2();
      setState(949);
      _errHandler->sync(this);
      _la = _input->LA(1);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- RelationalExpressionContext ------------------------------------------------------------------

PnfCParser::RelationalExpressionContext::RelationalExpressionContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::ShiftExpressionContext* PnfCParser::RelationalExpressionContext::shiftExpression() {
  return getRuleContext<PnfCParser::ShiftExpressionContext>(0);
}

PnfCParser::Kleene_star__relationalExpression_1Context* PnfCParser::RelationalExpressionContext::kleene_star__relationalExpression_1() {
  return getRuleContext<PnfCParser::Kleene_star__relationalExpression_1Context>(0);
}


size_t PnfCParser::RelationalExpressionContext::getRuleIndex() const {
  return PnfCParser::RuleRelationalExpression;
}

void PnfCParser::RelationalExpressionContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterRelationalExpression(this);
}

void PnfCParser::RelationalExpressionContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitRelationalExpression(this);
}


antlrcpp::Any PnfCParser::RelationalExpressionContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitRelationalExpression(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::RelationalExpressionContext* PnfCParser::relationalExpression() {
  RelationalExpressionContext *_localctx = _tracker.createInstance<RelationalExpressionContext>(_ctx, getState());
  enterRule(_localctx, 212, PnfCParser::RuleRelationalExpression);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(950);
    shiftExpression();
    setState(951);
    kleene_star__relationalExpression_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__equalityExpression_2Context ------------------------------------------------------------------

PnfCParser::Aux_rule__equalityExpression_2Context::Aux_rule__equalityExpression_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Altnt_block__equalityExpression_3Context* PnfCParser::Aux_rule__equalityExpression_2Context::altnt_block__equalityExpression_3() {
  return getRuleContext<PnfCParser::Altnt_block__equalityExpression_3Context>(0);
}

PnfCParser::RelationalExpressionContext* PnfCParser::Aux_rule__equalityExpression_2Context::relationalExpression() {
  return getRuleContext<PnfCParser::RelationalExpressionContext>(0);
}


size_t PnfCParser::Aux_rule__equalityExpression_2Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__equalityExpression_2;
}

void PnfCParser::Aux_rule__equalityExpression_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__equalityExpression_2(this);
}

void PnfCParser::Aux_rule__equalityExpression_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__equalityExpression_2(this);
}


antlrcpp::Any PnfCParser::Aux_rule__equalityExpression_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__equalityExpression_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__equalityExpression_2Context* PnfCParser::aux_rule__equalityExpression_2() {
  Aux_rule__equalityExpression_2Context *_localctx = _tracker.createInstance<Aux_rule__equalityExpression_2Context>(_ctx, getState());
  enterRule(_localctx, 214, PnfCParser::RuleAux_rule__equalityExpression_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(953);
    altnt_block__equalityExpression_3();
    setState(954);
    relationalExpression();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__equalityExpression_1Context ------------------------------------------------------------------

PnfCParser::Kleene_star__equalityExpression_1Context::Kleene_star__equalityExpression_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfCParser::Aux_rule__equalityExpression_2Context *> PnfCParser::Kleene_star__equalityExpression_1Context::aux_rule__equalityExpression_2() {
  return getRuleContexts<PnfCParser::Aux_rule__equalityExpression_2Context>();
}

PnfCParser::Aux_rule__equalityExpression_2Context* PnfCParser::Kleene_star__equalityExpression_1Context::aux_rule__equalityExpression_2(size_t i) {
  return getRuleContext<PnfCParser::Aux_rule__equalityExpression_2Context>(i);
}


size_t PnfCParser::Kleene_star__equalityExpression_1Context::getRuleIndex() const {
  return PnfCParser::RuleKleene_star__equalityExpression_1;
}

void PnfCParser::Kleene_star__equalityExpression_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__equalityExpression_1(this);
}

void PnfCParser::Kleene_star__equalityExpression_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__equalityExpression_1(this);
}


antlrcpp::Any PnfCParser::Kleene_star__equalityExpression_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitKleene_star__equalityExpression_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Kleene_star__equalityExpression_1Context* PnfCParser::kleene_star__equalityExpression_1() {
  Kleene_star__equalityExpression_1Context *_localctx = _tracker.createInstance<Kleene_star__equalityExpression_1Context>(_ctx, getState());
  enterRule(_localctx, 216, PnfCParser::RuleKleene_star__equalityExpression_1);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(959);
    _errHandler->sync(this);
    _la = _input->LA(1);
    while (_la == PnfCParser::Equal

    || _la == PnfCParser::NotEqual) {
      setState(956);
      aux_rule__equalityExpression_2();
      setState(961);
      _errHandler->sync(this);
      _la = _input->LA(1);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- EqualityExpressionContext ------------------------------------------------------------------

PnfCParser::EqualityExpressionContext::EqualityExpressionContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::RelationalExpressionContext* PnfCParser::EqualityExpressionContext::relationalExpression() {
  return getRuleContext<PnfCParser::RelationalExpressionContext>(0);
}

PnfCParser::Kleene_star__equalityExpression_1Context* PnfCParser::EqualityExpressionContext::kleene_star__equalityExpression_1() {
  return getRuleContext<PnfCParser::Kleene_star__equalityExpression_1Context>(0);
}


size_t PnfCParser::EqualityExpressionContext::getRuleIndex() const {
  return PnfCParser::RuleEqualityExpression;
}

void PnfCParser::EqualityExpressionContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterEqualityExpression(this);
}

void PnfCParser::EqualityExpressionContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitEqualityExpression(this);
}


antlrcpp::Any PnfCParser::EqualityExpressionContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitEqualityExpression(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::EqualityExpressionContext* PnfCParser::equalityExpression() {
  EqualityExpressionContext *_localctx = _tracker.createInstance<EqualityExpressionContext>(_ctx, getState());
  enterRule(_localctx, 218, PnfCParser::RuleEqualityExpression);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(962);
    relationalExpression();
    setState(963);
    kleene_star__equalityExpression_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__andExpression_2Context ------------------------------------------------------------------

PnfCParser::Aux_rule__andExpression_2Context::Aux_rule__andExpression_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__andExpression_2Context::And() {
  return getToken(PnfCParser::And, 0);
}

PnfCParser::EqualityExpressionContext* PnfCParser::Aux_rule__andExpression_2Context::equalityExpression() {
  return getRuleContext<PnfCParser::EqualityExpressionContext>(0);
}


size_t PnfCParser::Aux_rule__andExpression_2Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__andExpression_2;
}

void PnfCParser::Aux_rule__andExpression_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__andExpression_2(this);
}

void PnfCParser::Aux_rule__andExpression_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__andExpression_2(this);
}


antlrcpp::Any PnfCParser::Aux_rule__andExpression_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__andExpression_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__andExpression_2Context* PnfCParser::aux_rule__andExpression_2() {
  Aux_rule__andExpression_2Context *_localctx = _tracker.createInstance<Aux_rule__andExpression_2Context>(_ctx, getState());
  enterRule(_localctx, 220, PnfCParser::RuleAux_rule__andExpression_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(965);
    match(PnfCParser::And);
    setState(966);
    equalityExpression();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__andExpression_1Context ------------------------------------------------------------------

PnfCParser::Kleene_star__andExpression_1Context::Kleene_star__andExpression_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfCParser::Aux_rule__andExpression_2Context *> PnfCParser::Kleene_star__andExpression_1Context::aux_rule__andExpression_2() {
  return getRuleContexts<PnfCParser::Aux_rule__andExpression_2Context>();
}

PnfCParser::Aux_rule__andExpression_2Context* PnfCParser::Kleene_star__andExpression_1Context::aux_rule__andExpression_2(size_t i) {
  return getRuleContext<PnfCParser::Aux_rule__andExpression_2Context>(i);
}


size_t PnfCParser::Kleene_star__andExpression_1Context::getRuleIndex() const {
  return PnfCParser::RuleKleene_star__andExpression_1;
}

void PnfCParser::Kleene_star__andExpression_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__andExpression_1(this);
}

void PnfCParser::Kleene_star__andExpression_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__andExpression_1(this);
}


antlrcpp::Any PnfCParser::Kleene_star__andExpression_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitKleene_star__andExpression_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Kleene_star__andExpression_1Context* PnfCParser::kleene_star__andExpression_1() {
  Kleene_star__andExpression_1Context *_localctx = _tracker.createInstance<Kleene_star__andExpression_1Context>(_ctx, getState());
  enterRule(_localctx, 222, PnfCParser::RuleKleene_star__andExpression_1);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(971);
    _errHandler->sync(this);
    _la = _input->LA(1);
    while (_la == PnfCParser::And) {
      setState(968);
      aux_rule__andExpression_2();
      setState(973);
      _errHandler->sync(this);
      _la = _input->LA(1);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- AndExpressionContext ------------------------------------------------------------------

PnfCParser::AndExpressionContext::AndExpressionContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::EqualityExpressionContext* PnfCParser::AndExpressionContext::equalityExpression() {
  return getRuleContext<PnfCParser::EqualityExpressionContext>(0);
}

PnfCParser::Kleene_star__andExpression_1Context* PnfCParser::AndExpressionContext::kleene_star__andExpression_1() {
  return getRuleContext<PnfCParser::Kleene_star__andExpression_1Context>(0);
}


size_t PnfCParser::AndExpressionContext::getRuleIndex() const {
  return PnfCParser::RuleAndExpression;
}

void PnfCParser::AndExpressionContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAndExpression(this);
}

void PnfCParser::AndExpressionContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAndExpression(this);
}


antlrcpp::Any PnfCParser::AndExpressionContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAndExpression(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::AndExpressionContext* PnfCParser::andExpression() {
  AndExpressionContext *_localctx = _tracker.createInstance<AndExpressionContext>(_ctx, getState());
  enterRule(_localctx, 224, PnfCParser::RuleAndExpression);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(974);
    equalityExpression();
    setState(975);
    kleene_star__andExpression_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__exclusiveOrExpression_2Context ------------------------------------------------------------------

PnfCParser::Aux_rule__exclusiveOrExpression_2Context::Aux_rule__exclusiveOrExpression_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__exclusiveOrExpression_2Context::Caret() {
  return getToken(PnfCParser::Caret, 0);
}

PnfCParser::AndExpressionContext* PnfCParser::Aux_rule__exclusiveOrExpression_2Context::andExpression() {
  return getRuleContext<PnfCParser::AndExpressionContext>(0);
}


size_t PnfCParser::Aux_rule__exclusiveOrExpression_2Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__exclusiveOrExpression_2;
}

void PnfCParser::Aux_rule__exclusiveOrExpression_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__exclusiveOrExpression_2(this);
}

void PnfCParser::Aux_rule__exclusiveOrExpression_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__exclusiveOrExpression_2(this);
}


antlrcpp::Any PnfCParser::Aux_rule__exclusiveOrExpression_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__exclusiveOrExpression_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__exclusiveOrExpression_2Context* PnfCParser::aux_rule__exclusiveOrExpression_2() {
  Aux_rule__exclusiveOrExpression_2Context *_localctx = _tracker.createInstance<Aux_rule__exclusiveOrExpression_2Context>(_ctx, getState());
  enterRule(_localctx, 226, PnfCParser::RuleAux_rule__exclusiveOrExpression_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(977);
    match(PnfCParser::Caret);
    setState(978);
    andExpression();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__exclusiveOrExpression_1Context ------------------------------------------------------------------

PnfCParser::Kleene_star__exclusiveOrExpression_1Context::Kleene_star__exclusiveOrExpression_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfCParser::Aux_rule__exclusiveOrExpression_2Context *> PnfCParser::Kleene_star__exclusiveOrExpression_1Context::aux_rule__exclusiveOrExpression_2() {
  return getRuleContexts<PnfCParser::Aux_rule__exclusiveOrExpression_2Context>();
}

PnfCParser::Aux_rule__exclusiveOrExpression_2Context* PnfCParser::Kleene_star__exclusiveOrExpression_1Context::aux_rule__exclusiveOrExpression_2(size_t i) {
  return getRuleContext<PnfCParser::Aux_rule__exclusiveOrExpression_2Context>(i);
}


size_t PnfCParser::Kleene_star__exclusiveOrExpression_1Context::getRuleIndex() const {
  return PnfCParser::RuleKleene_star__exclusiveOrExpression_1;
}

void PnfCParser::Kleene_star__exclusiveOrExpression_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__exclusiveOrExpression_1(this);
}

void PnfCParser::Kleene_star__exclusiveOrExpression_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__exclusiveOrExpression_1(this);
}


antlrcpp::Any PnfCParser::Kleene_star__exclusiveOrExpression_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitKleene_star__exclusiveOrExpression_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Kleene_star__exclusiveOrExpression_1Context* PnfCParser::kleene_star__exclusiveOrExpression_1() {
  Kleene_star__exclusiveOrExpression_1Context *_localctx = _tracker.createInstance<Kleene_star__exclusiveOrExpression_1Context>(_ctx, getState());
  enterRule(_localctx, 228, PnfCParser::RuleKleene_star__exclusiveOrExpression_1);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(983);
    _errHandler->sync(this);
    _la = _input->LA(1);
    while (_la == PnfCParser::Caret) {
      setState(980);
      aux_rule__exclusiveOrExpression_2();
      setState(985);
      _errHandler->sync(this);
      _la = _input->LA(1);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ExclusiveOrExpressionContext ------------------------------------------------------------------

PnfCParser::ExclusiveOrExpressionContext::ExclusiveOrExpressionContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::AndExpressionContext* PnfCParser::ExclusiveOrExpressionContext::andExpression() {
  return getRuleContext<PnfCParser::AndExpressionContext>(0);
}

PnfCParser::Kleene_star__exclusiveOrExpression_1Context* PnfCParser::ExclusiveOrExpressionContext::kleene_star__exclusiveOrExpression_1() {
  return getRuleContext<PnfCParser::Kleene_star__exclusiveOrExpression_1Context>(0);
}


size_t PnfCParser::ExclusiveOrExpressionContext::getRuleIndex() const {
  return PnfCParser::RuleExclusiveOrExpression;
}

void PnfCParser::ExclusiveOrExpressionContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterExclusiveOrExpression(this);
}

void PnfCParser::ExclusiveOrExpressionContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitExclusiveOrExpression(this);
}


antlrcpp::Any PnfCParser::ExclusiveOrExpressionContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitExclusiveOrExpression(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::ExclusiveOrExpressionContext* PnfCParser::exclusiveOrExpression() {
  ExclusiveOrExpressionContext *_localctx = _tracker.createInstance<ExclusiveOrExpressionContext>(_ctx, getState());
  enterRule(_localctx, 230, PnfCParser::RuleExclusiveOrExpression);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(986);
    andExpression();
    setState(987);
    kleene_star__exclusiveOrExpression_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__inclusiveOrExpression_2Context ------------------------------------------------------------------

PnfCParser::Aux_rule__inclusiveOrExpression_2Context::Aux_rule__inclusiveOrExpression_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__inclusiveOrExpression_2Context::Or() {
  return getToken(PnfCParser::Or, 0);
}

PnfCParser::ExclusiveOrExpressionContext* PnfCParser::Aux_rule__inclusiveOrExpression_2Context::exclusiveOrExpression() {
  return getRuleContext<PnfCParser::ExclusiveOrExpressionContext>(0);
}


size_t PnfCParser::Aux_rule__inclusiveOrExpression_2Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__inclusiveOrExpression_2;
}

void PnfCParser::Aux_rule__inclusiveOrExpression_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__inclusiveOrExpression_2(this);
}

void PnfCParser::Aux_rule__inclusiveOrExpression_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__inclusiveOrExpression_2(this);
}


antlrcpp::Any PnfCParser::Aux_rule__inclusiveOrExpression_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__inclusiveOrExpression_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__inclusiveOrExpression_2Context* PnfCParser::aux_rule__inclusiveOrExpression_2() {
  Aux_rule__inclusiveOrExpression_2Context *_localctx = _tracker.createInstance<Aux_rule__inclusiveOrExpression_2Context>(_ctx, getState());
  enterRule(_localctx, 232, PnfCParser::RuleAux_rule__inclusiveOrExpression_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(989);
    match(PnfCParser::Or);
    setState(990);
    exclusiveOrExpression();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__inclusiveOrExpression_1Context ------------------------------------------------------------------

PnfCParser::Kleene_star__inclusiveOrExpression_1Context::Kleene_star__inclusiveOrExpression_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfCParser::Aux_rule__inclusiveOrExpression_2Context *> PnfCParser::Kleene_star__inclusiveOrExpression_1Context::aux_rule__inclusiveOrExpression_2() {
  return getRuleContexts<PnfCParser::Aux_rule__inclusiveOrExpression_2Context>();
}

PnfCParser::Aux_rule__inclusiveOrExpression_2Context* PnfCParser::Kleene_star__inclusiveOrExpression_1Context::aux_rule__inclusiveOrExpression_2(size_t i) {
  return getRuleContext<PnfCParser::Aux_rule__inclusiveOrExpression_2Context>(i);
}


size_t PnfCParser::Kleene_star__inclusiveOrExpression_1Context::getRuleIndex() const {
  return PnfCParser::RuleKleene_star__inclusiveOrExpression_1;
}

void PnfCParser::Kleene_star__inclusiveOrExpression_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__inclusiveOrExpression_1(this);
}

void PnfCParser::Kleene_star__inclusiveOrExpression_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__inclusiveOrExpression_1(this);
}


antlrcpp::Any PnfCParser::Kleene_star__inclusiveOrExpression_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitKleene_star__inclusiveOrExpression_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Kleene_star__inclusiveOrExpression_1Context* PnfCParser::kleene_star__inclusiveOrExpression_1() {
  Kleene_star__inclusiveOrExpression_1Context *_localctx = _tracker.createInstance<Kleene_star__inclusiveOrExpression_1Context>(_ctx, getState());
  enterRule(_localctx, 234, PnfCParser::RuleKleene_star__inclusiveOrExpression_1);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(995);
    _errHandler->sync(this);
    _la = _input->LA(1);
    while (_la == PnfCParser::Or) {
      setState(992);
      aux_rule__inclusiveOrExpression_2();
      setState(997);
      _errHandler->sync(this);
      _la = _input->LA(1);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- InclusiveOrExpressionContext ------------------------------------------------------------------

PnfCParser::InclusiveOrExpressionContext::InclusiveOrExpressionContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::ExclusiveOrExpressionContext* PnfCParser::InclusiveOrExpressionContext::exclusiveOrExpression() {
  return getRuleContext<PnfCParser::ExclusiveOrExpressionContext>(0);
}

PnfCParser::Kleene_star__inclusiveOrExpression_1Context* PnfCParser::InclusiveOrExpressionContext::kleene_star__inclusiveOrExpression_1() {
  return getRuleContext<PnfCParser::Kleene_star__inclusiveOrExpression_1Context>(0);
}


size_t PnfCParser::InclusiveOrExpressionContext::getRuleIndex() const {
  return PnfCParser::RuleInclusiveOrExpression;
}

void PnfCParser::InclusiveOrExpressionContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterInclusiveOrExpression(this);
}

void PnfCParser::InclusiveOrExpressionContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitInclusiveOrExpression(this);
}


antlrcpp::Any PnfCParser::InclusiveOrExpressionContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitInclusiveOrExpression(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::InclusiveOrExpressionContext* PnfCParser::inclusiveOrExpression() {
  InclusiveOrExpressionContext *_localctx = _tracker.createInstance<InclusiveOrExpressionContext>(_ctx, getState());
  enterRule(_localctx, 236, PnfCParser::RuleInclusiveOrExpression);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(998);
    exclusiveOrExpression();
    setState(999);
    kleene_star__inclusiveOrExpression_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__logicalAndExpression_2Context ------------------------------------------------------------------

PnfCParser::Aux_rule__logicalAndExpression_2Context::Aux_rule__logicalAndExpression_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__logicalAndExpression_2Context::AndAnd() {
  return getToken(PnfCParser::AndAnd, 0);
}

PnfCParser::InclusiveOrExpressionContext* PnfCParser::Aux_rule__logicalAndExpression_2Context::inclusiveOrExpression() {
  return getRuleContext<PnfCParser::InclusiveOrExpressionContext>(0);
}


size_t PnfCParser::Aux_rule__logicalAndExpression_2Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__logicalAndExpression_2;
}

void PnfCParser::Aux_rule__logicalAndExpression_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__logicalAndExpression_2(this);
}

void PnfCParser::Aux_rule__logicalAndExpression_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__logicalAndExpression_2(this);
}


antlrcpp::Any PnfCParser::Aux_rule__logicalAndExpression_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__logicalAndExpression_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__logicalAndExpression_2Context* PnfCParser::aux_rule__logicalAndExpression_2() {
  Aux_rule__logicalAndExpression_2Context *_localctx = _tracker.createInstance<Aux_rule__logicalAndExpression_2Context>(_ctx, getState());
  enterRule(_localctx, 238, PnfCParser::RuleAux_rule__logicalAndExpression_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1001);
    match(PnfCParser::AndAnd);
    setState(1002);
    inclusiveOrExpression();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__logicalAndExpression_1Context ------------------------------------------------------------------

PnfCParser::Kleene_star__logicalAndExpression_1Context::Kleene_star__logicalAndExpression_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfCParser::Aux_rule__logicalAndExpression_2Context *> PnfCParser::Kleene_star__logicalAndExpression_1Context::aux_rule__logicalAndExpression_2() {
  return getRuleContexts<PnfCParser::Aux_rule__logicalAndExpression_2Context>();
}

PnfCParser::Aux_rule__logicalAndExpression_2Context* PnfCParser::Kleene_star__logicalAndExpression_1Context::aux_rule__logicalAndExpression_2(size_t i) {
  return getRuleContext<PnfCParser::Aux_rule__logicalAndExpression_2Context>(i);
}


size_t PnfCParser::Kleene_star__logicalAndExpression_1Context::getRuleIndex() const {
  return PnfCParser::RuleKleene_star__logicalAndExpression_1;
}

void PnfCParser::Kleene_star__logicalAndExpression_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__logicalAndExpression_1(this);
}

void PnfCParser::Kleene_star__logicalAndExpression_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__logicalAndExpression_1(this);
}


antlrcpp::Any PnfCParser::Kleene_star__logicalAndExpression_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitKleene_star__logicalAndExpression_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Kleene_star__logicalAndExpression_1Context* PnfCParser::kleene_star__logicalAndExpression_1() {
  Kleene_star__logicalAndExpression_1Context *_localctx = _tracker.createInstance<Kleene_star__logicalAndExpression_1Context>(_ctx, getState());
  enterRule(_localctx, 240, PnfCParser::RuleKleene_star__logicalAndExpression_1);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1007);
    _errHandler->sync(this);
    _la = _input->LA(1);
    while (_la == PnfCParser::AndAnd) {
      setState(1004);
      aux_rule__logicalAndExpression_2();
      setState(1009);
      _errHandler->sync(this);
      _la = _input->LA(1);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- LogicalAndExpressionContext ------------------------------------------------------------------

PnfCParser::LogicalAndExpressionContext::LogicalAndExpressionContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::InclusiveOrExpressionContext* PnfCParser::LogicalAndExpressionContext::inclusiveOrExpression() {
  return getRuleContext<PnfCParser::InclusiveOrExpressionContext>(0);
}

PnfCParser::Kleene_star__logicalAndExpression_1Context* PnfCParser::LogicalAndExpressionContext::kleene_star__logicalAndExpression_1() {
  return getRuleContext<PnfCParser::Kleene_star__logicalAndExpression_1Context>(0);
}


size_t PnfCParser::LogicalAndExpressionContext::getRuleIndex() const {
  return PnfCParser::RuleLogicalAndExpression;
}

void PnfCParser::LogicalAndExpressionContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterLogicalAndExpression(this);
}

void PnfCParser::LogicalAndExpressionContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitLogicalAndExpression(this);
}


antlrcpp::Any PnfCParser::LogicalAndExpressionContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitLogicalAndExpression(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::LogicalAndExpressionContext* PnfCParser::logicalAndExpression() {
  LogicalAndExpressionContext *_localctx = _tracker.createInstance<LogicalAndExpressionContext>(_ctx, getState());
  enterRule(_localctx, 242, PnfCParser::RuleLogicalAndExpression);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1010);
    inclusiveOrExpression();
    setState(1011);
    kleene_star__logicalAndExpression_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__logicalOrExpression_2Context ------------------------------------------------------------------

PnfCParser::Aux_rule__logicalOrExpression_2Context::Aux_rule__logicalOrExpression_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__logicalOrExpression_2Context::OrOr() {
  return getToken(PnfCParser::OrOr, 0);
}

PnfCParser::LogicalAndExpressionContext* PnfCParser::Aux_rule__logicalOrExpression_2Context::logicalAndExpression() {
  return getRuleContext<PnfCParser::LogicalAndExpressionContext>(0);
}


size_t PnfCParser::Aux_rule__logicalOrExpression_2Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__logicalOrExpression_2;
}

void PnfCParser::Aux_rule__logicalOrExpression_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__logicalOrExpression_2(this);
}

void PnfCParser::Aux_rule__logicalOrExpression_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__logicalOrExpression_2(this);
}


antlrcpp::Any PnfCParser::Aux_rule__logicalOrExpression_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__logicalOrExpression_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__logicalOrExpression_2Context* PnfCParser::aux_rule__logicalOrExpression_2() {
  Aux_rule__logicalOrExpression_2Context *_localctx = _tracker.createInstance<Aux_rule__logicalOrExpression_2Context>(_ctx, getState());
  enterRule(_localctx, 244, PnfCParser::RuleAux_rule__logicalOrExpression_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1013);
    match(PnfCParser::OrOr);
    setState(1014);
    logicalAndExpression();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__logicalOrExpression_1Context ------------------------------------------------------------------

PnfCParser::Kleene_star__logicalOrExpression_1Context::Kleene_star__logicalOrExpression_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfCParser::Aux_rule__logicalOrExpression_2Context *> PnfCParser::Kleene_star__logicalOrExpression_1Context::aux_rule__logicalOrExpression_2() {
  return getRuleContexts<PnfCParser::Aux_rule__logicalOrExpression_2Context>();
}

PnfCParser::Aux_rule__logicalOrExpression_2Context* PnfCParser::Kleene_star__logicalOrExpression_1Context::aux_rule__logicalOrExpression_2(size_t i) {
  return getRuleContext<PnfCParser::Aux_rule__logicalOrExpression_2Context>(i);
}


size_t PnfCParser::Kleene_star__logicalOrExpression_1Context::getRuleIndex() const {
  return PnfCParser::RuleKleene_star__logicalOrExpression_1;
}

void PnfCParser::Kleene_star__logicalOrExpression_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__logicalOrExpression_1(this);
}

void PnfCParser::Kleene_star__logicalOrExpression_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__logicalOrExpression_1(this);
}


antlrcpp::Any PnfCParser::Kleene_star__logicalOrExpression_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitKleene_star__logicalOrExpression_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Kleene_star__logicalOrExpression_1Context* PnfCParser::kleene_star__logicalOrExpression_1() {
  Kleene_star__logicalOrExpression_1Context *_localctx = _tracker.createInstance<Kleene_star__logicalOrExpression_1Context>(_ctx, getState());
  enterRule(_localctx, 246, PnfCParser::RuleKleene_star__logicalOrExpression_1);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1019);
    _errHandler->sync(this);
    _la = _input->LA(1);
    while (_la == PnfCParser::OrOr) {
      setState(1016);
      aux_rule__logicalOrExpression_2();
      setState(1021);
      _errHandler->sync(this);
      _la = _input->LA(1);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- LogicalOrExpressionContext ------------------------------------------------------------------

PnfCParser::LogicalOrExpressionContext::LogicalOrExpressionContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::LogicalAndExpressionContext* PnfCParser::LogicalOrExpressionContext::logicalAndExpression() {
  return getRuleContext<PnfCParser::LogicalAndExpressionContext>(0);
}

PnfCParser::Kleene_star__logicalOrExpression_1Context* PnfCParser::LogicalOrExpressionContext::kleene_star__logicalOrExpression_1() {
  return getRuleContext<PnfCParser::Kleene_star__logicalOrExpression_1Context>(0);
}


size_t PnfCParser::LogicalOrExpressionContext::getRuleIndex() const {
  return PnfCParser::RuleLogicalOrExpression;
}

void PnfCParser::LogicalOrExpressionContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterLogicalOrExpression(this);
}

void PnfCParser::LogicalOrExpressionContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitLogicalOrExpression(this);
}


antlrcpp::Any PnfCParser::LogicalOrExpressionContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitLogicalOrExpression(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::LogicalOrExpressionContext* PnfCParser::logicalOrExpression() {
  LogicalOrExpressionContext *_localctx = _tracker.createInstance<LogicalOrExpressionContext>(_ctx, getState());
  enterRule(_localctx, 248, PnfCParser::RuleLogicalOrExpression);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1022);
    logicalAndExpression();
    setState(1023);
    kleene_star__logicalOrExpression_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__initDeclaratorList_2Context ------------------------------------------------------------------

PnfCParser::Aux_rule__initDeclaratorList_2Context::Aux_rule__initDeclaratorList_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__initDeclaratorList_2Context::Comma() {
  return getToken(PnfCParser::Comma, 0);
}

PnfCParser::InitDeclaratorContext* PnfCParser::Aux_rule__initDeclaratorList_2Context::initDeclarator() {
  return getRuleContext<PnfCParser::InitDeclaratorContext>(0);
}


size_t PnfCParser::Aux_rule__initDeclaratorList_2Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__initDeclaratorList_2;
}

void PnfCParser::Aux_rule__initDeclaratorList_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__initDeclaratorList_2(this);
}

void PnfCParser::Aux_rule__initDeclaratorList_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__initDeclaratorList_2(this);
}


antlrcpp::Any PnfCParser::Aux_rule__initDeclaratorList_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__initDeclaratorList_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__initDeclaratorList_2Context* PnfCParser::aux_rule__initDeclaratorList_2() {
  Aux_rule__initDeclaratorList_2Context *_localctx = _tracker.createInstance<Aux_rule__initDeclaratorList_2Context>(_ctx, getState());
  enterRule(_localctx, 250, PnfCParser::RuleAux_rule__initDeclaratorList_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1025);
    match(PnfCParser::Comma);
    setState(1026);
    initDeclarator();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__initDeclaratorList_1Context ------------------------------------------------------------------

PnfCParser::Kleene_star__initDeclaratorList_1Context::Kleene_star__initDeclaratorList_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfCParser::Aux_rule__initDeclaratorList_2Context *> PnfCParser::Kleene_star__initDeclaratorList_1Context::aux_rule__initDeclaratorList_2() {
  return getRuleContexts<PnfCParser::Aux_rule__initDeclaratorList_2Context>();
}

PnfCParser::Aux_rule__initDeclaratorList_2Context* PnfCParser::Kleene_star__initDeclaratorList_1Context::aux_rule__initDeclaratorList_2(size_t i) {
  return getRuleContext<PnfCParser::Aux_rule__initDeclaratorList_2Context>(i);
}


size_t PnfCParser::Kleene_star__initDeclaratorList_1Context::getRuleIndex() const {
  return PnfCParser::RuleKleene_star__initDeclaratorList_1;
}

void PnfCParser::Kleene_star__initDeclaratorList_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__initDeclaratorList_1(this);
}

void PnfCParser::Kleene_star__initDeclaratorList_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__initDeclaratorList_1(this);
}


antlrcpp::Any PnfCParser::Kleene_star__initDeclaratorList_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitKleene_star__initDeclaratorList_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Kleene_star__initDeclaratorList_1Context* PnfCParser::kleene_star__initDeclaratorList_1() {
  Kleene_star__initDeclaratorList_1Context *_localctx = _tracker.createInstance<Kleene_star__initDeclaratorList_1Context>(_ctx, getState());
  enterRule(_localctx, 252, PnfCParser::RuleKleene_star__initDeclaratorList_1);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1031);
    _errHandler->sync(this);
    _la = _input->LA(1);
    while (_la == PnfCParser::Comma) {
      setState(1028);
      aux_rule__initDeclaratorList_2();
      setState(1033);
      _errHandler->sync(this);
      _la = _input->LA(1);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- InitDeclaratorListContext ------------------------------------------------------------------

PnfCParser::InitDeclaratorListContext::InitDeclaratorListContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::InitDeclaratorContext* PnfCParser::InitDeclaratorListContext::initDeclarator() {
  return getRuleContext<PnfCParser::InitDeclaratorContext>(0);
}

PnfCParser::Kleene_star__initDeclaratorList_1Context* PnfCParser::InitDeclaratorListContext::kleene_star__initDeclaratorList_1() {
  return getRuleContext<PnfCParser::Kleene_star__initDeclaratorList_1Context>(0);
}


size_t PnfCParser::InitDeclaratorListContext::getRuleIndex() const {
  return PnfCParser::RuleInitDeclaratorList;
}

void PnfCParser::InitDeclaratorListContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterInitDeclaratorList(this);
}

void PnfCParser::InitDeclaratorListContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitInitDeclaratorList(this);
}


antlrcpp::Any PnfCParser::InitDeclaratorListContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitInitDeclaratorList(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::InitDeclaratorListContext* PnfCParser::initDeclaratorList() {
  InitDeclaratorListContext *_localctx = _tracker.createInstance<InitDeclaratorListContext>(_ctx, getState());
  enterRule(_localctx, 254, PnfCParser::RuleInitDeclaratorList);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1034);
    initDeclarator();
    setState(1035);
    kleene_star__initDeclaratorList_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- StructDeclarationListContext ------------------------------------------------------------------

PnfCParser::StructDeclarationListContext::StructDeclarationListContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Kleene_plus__structDeclarationList_3Context* PnfCParser::StructDeclarationListContext::kleene_plus__structDeclarationList_3() {
  return getRuleContext<PnfCParser::Kleene_plus__structDeclarationList_3Context>(0);
}


size_t PnfCParser::StructDeclarationListContext::getRuleIndex() const {
  return PnfCParser::RuleStructDeclarationList;
}

void PnfCParser::StructDeclarationListContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterStructDeclarationList(this);
}

void PnfCParser::StructDeclarationListContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitStructDeclarationList(this);
}


antlrcpp::Any PnfCParser::StructDeclarationListContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitStructDeclarationList(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::StructDeclarationListContext* PnfCParser::structDeclarationList() {
  StructDeclarationListContext *_localctx = _tracker.createInstance<StructDeclarationListContext>(_ctx, getState());
  enterRule(_localctx, 256, PnfCParser::RuleStructDeclarationList);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1037);
    kleene_plus__structDeclarationList_3();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__structDeclaratorList_2Context ------------------------------------------------------------------

PnfCParser::Aux_rule__structDeclaratorList_2Context::Aux_rule__structDeclaratorList_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__structDeclaratorList_2Context::Comma() {
  return getToken(PnfCParser::Comma, 0);
}

PnfCParser::StructDeclaratorContext* PnfCParser::Aux_rule__structDeclaratorList_2Context::structDeclarator() {
  return getRuleContext<PnfCParser::StructDeclaratorContext>(0);
}


size_t PnfCParser::Aux_rule__structDeclaratorList_2Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__structDeclaratorList_2;
}

void PnfCParser::Aux_rule__structDeclaratorList_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__structDeclaratorList_2(this);
}

void PnfCParser::Aux_rule__structDeclaratorList_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__structDeclaratorList_2(this);
}


antlrcpp::Any PnfCParser::Aux_rule__structDeclaratorList_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__structDeclaratorList_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__structDeclaratorList_2Context* PnfCParser::aux_rule__structDeclaratorList_2() {
  Aux_rule__structDeclaratorList_2Context *_localctx = _tracker.createInstance<Aux_rule__structDeclaratorList_2Context>(_ctx, getState());
  enterRule(_localctx, 258, PnfCParser::RuleAux_rule__structDeclaratorList_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1039);
    match(PnfCParser::Comma);
    setState(1040);
    structDeclarator();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__structDeclaratorList_1Context ------------------------------------------------------------------

PnfCParser::Kleene_star__structDeclaratorList_1Context::Kleene_star__structDeclaratorList_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfCParser::Aux_rule__structDeclaratorList_2Context *> PnfCParser::Kleene_star__structDeclaratorList_1Context::aux_rule__structDeclaratorList_2() {
  return getRuleContexts<PnfCParser::Aux_rule__structDeclaratorList_2Context>();
}

PnfCParser::Aux_rule__structDeclaratorList_2Context* PnfCParser::Kleene_star__structDeclaratorList_1Context::aux_rule__structDeclaratorList_2(size_t i) {
  return getRuleContext<PnfCParser::Aux_rule__structDeclaratorList_2Context>(i);
}


size_t PnfCParser::Kleene_star__structDeclaratorList_1Context::getRuleIndex() const {
  return PnfCParser::RuleKleene_star__structDeclaratorList_1;
}

void PnfCParser::Kleene_star__structDeclaratorList_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__structDeclaratorList_1(this);
}

void PnfCParser::Kleene_star__structDeclaratorList_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__structDeclaratorList_1(this);
}


antlrcpp::Any PnfCParser::Kleene_star__structDeclaratorList_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitKleene_star__structDeclaratorList_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Kleene_star__structDeclaratorList_1Context* PnfCParser::kleene_star__structDeclaratorList_1() {
  Kleene_star__structDeclaratorList_1Context *_localctx = _tracker.createInstance<Kleene_star__structDeclaratorList_1Context>(_ctx, getState());
  enterRule(_localctx, 260, PnfCParser::RuleKleene_star__structDeclaratorList_1);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1045);
    _errHandler->sync(this);
    _la = _input->LA(1);
    while (_la == PnfCParser::Comma) {
      setState(1042);
      aux_rule__structDeclaratorList_2();
      setState(1047);
      _errHandler->sync(this);
      _la = _input->LA(1);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- StructDeclaratorListContext ------------------------------------------------------------------

PnfCParser::StructDeclaratorListContext::StructDeclaratorListContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::StructDeclaratorContext* PnfCParser::StructDeclaratorListContext::structDeclarator() {
  return getRuleContext<PnfCParser::StructDeclaratorContext>(0);
}

PnfCParser::Kleene_star__structDeclaratorList_1Context* PnfCParser::StructDeclaratorListContext::kleene_star__structDeclaratorList_1() {
  return getRuleContext<PnfCParser::Kleene_star__structDeclaratorList_1Context>(0);
}


size_t PnfCParser::StructDeclaratorListContext::getRuleIndex() const {
  return PnfCParser::RuleStructDeclaratorList;
}

void PnfCParser::StructDeclaratorListContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterStructDeclaratorList(this);
}

void PnfCParser::StructDeclaratorListContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitStructDeclaratorList(this);
}


antlrcpp::Any PnfCParser::StructDeclaratorListContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitStructDeclaratorList(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::StructDeclaratorListContext* PnfCParser::structDeclaratorList() {
  StructDeclaratorListContext *_localctx = _tracker.createInstance<StructDeclaratorListContext>(_ctx, getState());
  enterRule(_localctx, 262, PnfCParser::RuleStructDeclaratorList);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1048);
    structDeclarator();
    setState(1049);
    kleene_star__structDeclaratorList_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__enumeratorList_2Context ------------------------------------------------------------------

PnfCParser::Aux_rule__enumeratorList_2Context::Aux_rule__enumeratorList_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__enumeratorList_2Context::Comma() {
  return getToken(PnfCParser::Comma, 0);
}

PnfCParser::EnumeratorContext* PnfCParser::Aux_rule__enumeratorList_2Context::enumerator() {
  return getRuleContext<PnfCParser::EnumeratorContext>(0);
}


size_t PnfCParser::Aux_rule__enumeratorList_2Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__enumeratorList_2;
}

void PnfCParser::Aux_rule__enumeratorList_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__enumeratorList_2(this);
}

void PnfCParser::Aux_rule__enumeratorList_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__enumeratorList_2(this);
}


antlrcpp::Any PnfCParser::Aux_rule__enumeratorList_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__enumeratorList_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__enumeratorList_2Context* PnfCParser::aux_rule__enumeratorList_2() {
  Aux_rule__enumeratorList_2Context *_localctx = _tracker.createInstance<Aux_rule__enumeratorList_2Context>(_ctx, getState());
  enterRule(_localctx, 264, PnfCParser::RuleAux_rule__enumeratorList_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1051);
    match(PnfCParser::Comma);
    setState(1052);
    enumerator();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__enumeratorList_1Context ------------------------------------------------------------------

PnfCParser::Kleene_star__enumeratorList_1Context::Kleene_star__enumeratorList_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfCParser::Aux_rule__enumeratorList_2Context *> PnfCParser::Kleene_star__enumeratorList_1Context::aux_rule__enumeratorList_2() {
  return getRuleContexts<PnfCParser::Aux_rule__enumeratorList_2Context>();
}

PnfCParser::Aux_rule__enumeratorList_2Context* PnfCParser::Kleene_star__enumeratorList_1Context::aux_rule__enumeratorList_2(size_t i) {
  return getRuleContext<PnfCParser::Aux_rule__enumeratorList_2Context>(i);
}


size_t PnfCParser::Kleene_star__enumeratorList_1Context::getRuleIndex() const {
  return PnfCParser::RuleKleene_star__enumeratorList_1;
}

void PnfCParser::Kleene_star__enumeratorList_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__enumeratorList_1(this);
}

void PnfCParser::Kleene_star__enumeratorList_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__enumeratorList_1(this);
}


antlrcpp::Any PnfCParser::Kleene_star__enumeratorList_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitKleene_star__enumeratorList_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Kleene_star__enumeratorList_1Context* PnfCParser::kleene_star__enumeratorList_1() {
  Kleene_star__enumeratorList_1Context *_localctx = _tracker.createInstance<Kleene_star__enumeratorList_1Context>(_ctx, getState());
  enterRule(_localctx, 266, PnfCParser::RuleKleene_star__enumeratorList_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    size_t alt;
    enterOuterAlt(_localctx, 1);
    setState(1057);
    _errHandler->sync(this);
    alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 58, _ctx);
    while (alt != 2 && alt != atn::ATN::INVALID_ALT_NUMBER) {
      if (alt == 1) {
        setState(1054);
        aux_rule__enumeratorList_2(); 
      }
      setState(1059);
      _errHandler->sync(this);
      alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 58, _ctx);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- EnumeratorListContext ------------------------------------------------------------------

PnfCParser::EnumeratorListContext::EnumeratorListContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::EnumeratorContext* PnfCParser::EnumeratorListContext::enumerator() {
  return getRuleContext<PnfCParser::EnumeratorContext>(0);
}

PnfCParser::Kleene_star__enumeratorList_1Context* PnfCParser::EnumeratorListContext::kleene_star__enumeratorList_1() {
  return getRuleContext<PnfCParser::Kleene_star__enumeratorList_1Context>(0);
}


size_t PnfCParser::EnumeratorListContext::getRuleIndex() const {
  return PnfCParser::RuleEnumeratorList;
}

void PnfCParser::EnumeratorListContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterEnumeratorList(this);
}

void PnfCParser::EnumeratorListContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitEnumeratorList(this);
}


antlrcpp::Any PnfCParser::EnumeratorListContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitEnumeratorList(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::EnumeratorListContext* PnfCParser::enumeratorList() {
  EnumeratorListContext *_localctx = _tracker.createInstance<EnumeratorListContext>(_ctx, getState());
  enterRule(_localctx, 268, PnfCParser::RuleEnumeratorList);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1060);
    enumerator();
    setState(1061);
    kleene_star__enumeratorList_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__directDeclarator_7Context ------------------------------------------------------------------

PnfCParser::Aux_rule__directDeclarator_7Context::Aux_rule__directDeclarator_7Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Aux_rule__directDeclarator_13Context* PnfCParser::Aux_rule__directDeclarator_7Context::aux_rule__directDeclarator_13() {
  return getRuleContext<PnfCParser::Aux_rule__directDeclarator_13Context>(0);
}

PnfCParser::Aux_rule__directDeclarator_14Context* PnfCParser::Aux_rule__directDeclarator_7Context::aux_rule__directDeclarator_14() {
  return getRuleContext<PnfCParser::Aux_rule__directDeclarator_14Context>(0);
}


size_t PnfCParser::Aux_rule__directDeclarator_7Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__directDeclarator_7;
}

void PnfCParser::Aux_rule__directDeclarator_7Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__directDeclarator_7(this);
}

void PnfCParser::Aux_rule__directDeclarator_7Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__directDeclarator_7(this);
}


antlrcpp::Any PnfCParser::Aux_rule__directDeclarator_7Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__directDeclarator_7(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__directDeclarator_7Context* PnfCParser::aux_rule__directDeclarator_7() {
  Aux_rule__directDeclarator_7Context *_localctx = _tracker.createInstance<Aux_rule__directDeclarator_7Context>(_ctx, getState());
  enterRule(_localctx, 270, PnfCParser::RuleAux_rule__directDeclarator_7);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1065);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case PnfCParser::LeftBracket: {
        enterOuterAlt(_localctx, 1);
        setState(1063);
        aux_rule__directDeclarator_13();
        break;
      }

      case PnfCParser::LeftParen: {
        enterOuterAlt(_localctx, 2);
        setState(1064);
        aux_rule__directDeclarator_14();
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__directDeclarator_6Context ------------------------------------------------------------------

PnfCParser::Kleene_star__directDeclarator_6Context::Kleene_star__directDeclarator_6Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfCParser::Aux_rule__directDeclarator_7Context *> PnfCParser::Kleene_star__directDeclarator_6Context::aux_rule__directDeclarator_7() {
  return getRuleContexts<PnfCParser::Aux_rule__directDeclarator_7Context>();
}

PnfCParser::Aux_rule__directDeclarator_7Context* PnfCParser::Kleene_star__directDeclarator_6Context::aux_rule__directDeclarator_7(size_t i) {
  return getRuleContext<PnfCParser::Aux_rule__directDeclarator_7Context>(i);
}


size_t PnfCParser::Kleene_star__directDeclarator_6Context::getRuleIndex() const {
  return PnfCParser::RuleKleene_star__directDeclarator_6;
}

void PnfCParser::Kleene_star__directDeclarator_6Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__directDeclarator_6(this);
}

void PnfCParser::Kleene_star__directDeclarator_6Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__directDeclarator_6(this);
}


antlrcpp::Any PnfCParser::Kleene_star__directDeclarator_6Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitKleene_star__directDeclarator_6(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Kleene_star__directDeclarator_6Context* PnfCParser::kleene_star__directDeclarator_6() {
  Kleene_star__directDeclarator_6Context *_localctx = _tracker.createInstance<Kleene_star__directDeclarator_6Context>(_ctx, getState());
  enterRule(_localctx, 272, PnfCParser::RuleKleene_star__directDeclarator_6);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1070);
    _errHandler->sync(this);
    _la = _input->LA(1);
    while (_la == PnfCParser::LeftParen

    || _la == PnfCParser::LeftBracket) {
      setState(1067);
      aux_rule__directDeclarator_7();
      setState(1072);
      _errHandler->sync(this);
      _la = _input->LA(1);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__directDeclarator_8Context ------------------------------------------------------------------

PnfCParser::Aux_rule__directDeclarator_8Context::Aux_rule__directDeclarator_8Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__directDeclarator_8Context::Identifier() {
  return getToken(PnfCParser::Identifier, 0);
}

PnfCParser::Aux_rule__directDeclarator_15Context* PnfCParser::Aux_rule__directDeclarator_8Context::aux_rule__directDeclarator_15() {
  return getRuleContext<PnfCParser::Aux_rule__directDeclarator_15Context>(0);
}


size_t PnfCParser::Aux_rule__directDeclarator_8Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__directDeclarator_8;
}

void PnfCParser::Aux_rule__directDeclarator_8Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__directDeclarator_8(this);
}

void PnfCParser::Aux_rule__directDeclarator_8Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__directDeclarator_8(this);
}


antlrcpp::Any PnfCParser::Aux_rule__directDeclarator_8Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__directDeclarator_8(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__directDeclarator_8Context* PnfCParser::aux_rule__directDeclarator_8() {
  Aux_rule__directDeclarator_8Context *_localctx = _tracker.createInstance<Aux_rule__directDeclarator_8Context>(_ctx, getState());
  enterRule(_localctx, 274, PnfCParser::RuleAux_rule__directDeclarator_8);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1075);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case PnfCParser::Identifier: {
        enterOuterAlt(_localctx, 1);
        setState(1073);
        match(PnfCParser::Identifier);
        break;
      }

      case PnfCParser::LeftParen: {
        enterOuterAlt(_localctx, 2);
        setState(1074);
        aux_rule__directDeclarator_15();
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- DirectDeclaratorContext ------------------------------------------------------------------

PnfCParser::DirectDeclaratorContext::DirectDeclaratorContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Aux_rule__directDeclarator_8Context* PnfCParser::DirectDeclaratorContext::aux_rule__directDeclarator_8() {
  return getRuleContext<PnfCParser::Aux_rule__directDeclarator_8Context>(0);
}

PnfCParser::Kleene_star__directDeclarator_6Context* PnfCParser::DirectDeclaratorContext::kleene_star__directDeclarator_6() {
  return getRuleContext<PnfCParser::Kleene_star__directDeclarator_6Context>(0);
}


size_t PnfCParser::DirectDeclaratorContext::getRuleIndex() const {
  return PnfCParser::RuleDirectDeclarator;
}

void PnfCParser::DirectDeclaratorContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterDirectDeclarator(this);
}

void PnfCParser::DirectDeclaratorContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitDirectDeclarator(this);
}


antlrcpp::Any PnfCParser::DirectDeclaratorContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitDirectDeclarator(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::DirectDeclaratorContext* PnfCParser::directDeclarator() {
  DirectDeclaratorContext *_localctx = _tracker.createInstance<DirectDeclaratorContext>(_ctx, getState());
  enterRule(_localctx, 276, PnfCParser::RuleDirectDeclarator);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1077);
    aux_rule__directDeclarator_8();
    setState(1078);
    kleene_star__directDeclarator_6();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__typeQualifierList_2Context ------------------------------------------------------------------

PnfCParser::Aux_rule__typeQualifierList_2Context::Aux_rule__typeQualifierList_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::TypeQualifierContext* PnfCParser::Aux_rule__typeQualifierList_2Context::typeQualifier() {
  return getRuleContext<PnfCParser::TypeQualifierContext>(0);
}


size_t PnfCParser::Aux_rule__typeQualifierList_2Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__typeQualifierList_2;
}

void PnfCParser::Aux_rule__typeQualifierList_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__typeQualifierList_2(this);
}

void PnfCParser::Aux_rule__typeQualifierList_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__typeQualifierList_2(this);
}


antlrcpp::Any PnfCParser::Aux_rule__typeQualifierList_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__typeQualifierList_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__typeQualifierList_2Context* PnfCParser::aux_rule__typeQualifierList_2() {
  Aux_rule__typeQualifierList_2Context *_localctx = _tracker.createInstance<Aux_rule__typeQualifierList_2Context>(_ctx, getState());
  enterRule(_localctx, 278, PnfCParser::RuleAux_rule__typeQualifierList_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1080);
    typeQualifier();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- TypeQualifierListContext ------------------------------------------------------------------

PnfCParser::TypeQualifierListContext::TypeQualifierListContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Kleene_plus__typeQualifierList_3Context* PnfCParser::TypeQualifierListContext::kleene_plus__typeQualifierList_3() {
  return getRuleContext<PnfCParser::Kleene_plus__typeQualifierList_3Context>(0);
}


size_t PnfCParser::TypeQualifierListContext::getRuleIndex() const {
  return PnfCParser::RuleTypeQualifierList;
}

void PnfCParser::TypeQualifierListContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterTypeQualifierList(this);
}

void PnfCParser::TypeQualifierListContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitTypeQualifierList(this);
}


antlrcpp::Any PnfCParser::TypeQualifierListContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitTypeQualifierList(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::TypeQualifierListContext* PnfCParser::typeQualifierList() {
  TypeQualifierListContext *_localctx = _tracker.createInstance<TypeQualifierListContext>(_ctx, getState());
  enterRule(_localctx, 280, PnfCParser::RuleTypeQualifierList);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1082);
    kleene_plus__typeQualifierList_3();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__identifierList_2Context ------------------------------------------------------------------

PnfCParser::Aux_rule__identifierList_2Context::Aux_rule__identifierList_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__identifierList_2Context::Comma() {
  return getToken(PnfCParser::Comma, 0);
}

tree::TerminalNode* PnfCParser::Aux_rule__identifierList_2Context::Identifier() {
  return getToken(PnfCParser::Identifier, 0);
}


size_t PnfCParser::Aux_rule__identifierList_2Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__identifierList_2;
}

void PnfCParser::Aux_rule__identifierList_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__identifierList_2(this);
}

void PnfCParser::Aux_rule__identifierList_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__identifierList_2(this);
}


antlrcpp::Any PnfCParser::Aux_rule__identifierList_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__identifierList_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__identifierList_2Context* PnfCParser::aux_rule__identifierList_2() {
  Aux_rule__identifierList_2Context *_localctx = _tracker.createInstance<Aux_rule__identifierList_2Context>(_ctx, getState());
  enterRule(_localctx, 282, PnfCParser::RuleAux_rule__identifierList_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1084);
    match(PnfCParser::Comma);
    setState(1085);
    match(PnfCParser::Identifier);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__identifierList_1Context ------------------------------------------------------------------

PnfCParser::Kleene_star__identifierList_1Context::Kleene_star__identifierList_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfCParser::Aux_rule__identifierList_2Context *> PnfCParser::Kleene_star__identifierList_1Context::aux_rule__identifierList_2() {
  return getRuleContexts<PnfCParser::Aux_rule__identifierList_2Context>();
}

PnfCParser::Aux_rule__identifierList_2Context* PnfCParser::Kleene_star__identifierList_1Context::aux_rule__identifierList_2(size_t i) {
  return getRuleContext<PnfCParser::Aux_rule__identifierList_2Context>(i);
}


size_t PnfCParser::Kleene_star__identifierList_1Context::getRuleIndex() const {
  return PnfCParser::RuleKleene_star__identifierList_1;
}

void PnfCParser::Kleene_star__identifierList_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__identifierList_1(this);
}

void PnfCParser::Kleene_star__identifierList_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__identifierList_1(this);
}


antlrcpp::Any PnfCParser::Kleene_star__identifierList_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitKleene_star__identifierList_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Kleene_star__identifierList_1Context* PnfCParser::kleene_star__identifierList_1() {
  Kleene_star__identifierList_1Context *_localctx = _tracker.createInstance<Kleene_star__identifierList_1Context>(_ctx, getState());
  enterRule(_localctx, 284, PnfCParser::RuleKleene_star__identifierList_1);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1090);
    _errHandler->sync(this);
    _la = _input->LA(1);
    while (_la == PnfCParser::Comma) {
      setState(1087);
      aux_rule__identifierList_2();
      setState(1092);
      _errHandler->sync(this);
      _la = _input->LA(1);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- IdentifierListContext ------------------------------------------------------------------

PnfCParser::IdentifierListContext::IdentifierListContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::IdentifierListContext::Identifier() {
  return getToken(PnfCParser::Identifier, 0);
}

PnfCParser::Kleene_star__identifierList_1Context* PnfCParser::IdentifierListContext::kleene_star__identifierList_1() {
  return getRuleContext<PnfCParser::Kleene_star__identifierList_1Context>(0);
}


size_t PnfCParser::IdentifierListContext::getRuleIndex() const {
  return PnfCParser::RuleIdentifierList;
}

void PnfCParser::IdentifierListContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterIdentifierList(this);
}

void PnfCParser::IdentifierListContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitIdentifierList(this);
}


antlrcpp::Any PnfCParser::IdentifierListContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitIdentifierList(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::IdentifierListContext* PnfCParser::identifierList() {
  IdentifierListContext *_localctx = _tracker.createInstance<IdentifierListContext>(_ctx, getState());
  enterRule(_localctx, 286, PnfCParser::RuleIdentifierList);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1093);
    match(PnfCParser::Identifier);
    setState(1094);
    kleene_star__identifierList_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__parameterList_2Context ------------------------------------------------------------------

PnfCParser::Aux_rule__parameterList_2Context::Aux_rule__parameterList_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__parameterList_2Context::Comma() {
  return getToken(PnfCParser::Comma, 0);
}

PnfCParser::ParameterDeclarationContext* PnfCParser::Aux_rule__parameterList_2Context::parameterDeclaration() {
  return getRuleContext<PnfCParser::ParameterDeclarationContext>(0);
}


size_t PnfCParser::Aux_rule__parameterList_2Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__parameterList_2;
}

void PnfCParser::Aux_rule__parameterList_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__parameterList_2(this);
}

void PnfCParser::Aux_rule__parameterList_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__parameterList_2(this);
}


antlrcpp::Any PnfCParser::Aux_rule__parameterList_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__parameterList_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__parameterList_2Context* PnfCParser::aux_rule__parameterList_2() {
  Aux_rule__parameterList_2Context *_localctx = _tracker.createInstance<Aux_rule__parameterList_2Context>(_ctx, getState());
  enterRule(_localctx, 288, PnfCParser::RuleAux_rule__parameterList_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1096);
    match(PnfCParser::Comma);
    setState(1097);
    parameterDeclaration();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__parameterList_1Context ------------------------------------------------------------------

PnfCParser::Kleene_star__parameterList_1Context::Kleene_star__parameterList_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfCParser::Aux_rule__parameterList_2Context *> PnfCParser::Kleene_star__parameterList_1Context::aux_rule__parameterList_2() {
  return getRuleContexts<PnfCParser::Aux_rule__parameterList_2Context>();
}

PnfCParser::Aux_rule__parameterList_2Context* PnfCParser::Kleene_star__parameterList_1Context::aux_rule__parameterList_2(size_t i) {
  return getRuleContext<PnfCParser::Aux_rule__parameterList_2Context>(i);
}


size_t PnfCParser::Kleene_star__parameterList_1Context::getRuleIndex() const {
  return PnfCParser::RuleKleene_star__parameterList_1;
}

void PnfCParser::Kleene_star__parameterList_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__parameterList_1(this);
}

void PnfCParser::Kleene_star__parameterList_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__parameterList_1(this);
}


antlrcpp::Any PnfCParser::Kleene_star__parameterList_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitKleene_star__parameterList_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Kleene_star__parameterList_1Context* PnfCParser::kleene_star__parameterList_1() {
  Kleene_star__parameterList_1Context *_localctx = _tracker.createInstance<Kleene_star__parameterList_1Context>(_ctx, getState());
  enterRule(_localctx, 290, PnfCParser::RuleKleene_star__parameterList_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    size_t alt;
    enterOuterAlt(_localctx, 1);
    setState(1102);
    _errHandler->sync(this);
    alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 63, _ctx);
    while (alt != 2 && alt != atn::ATN::INVALID_ALT_NUMBER) {
      if (alt == 1) {
        setState(1099);
        aux_rule__parameterList_2(); 
      }
      setState(1104);
      _errHandler->sync(this);
      alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 63, _ctx);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ParameterListContext ------------------------------------------------------------------

PnfCParser::ParameterListContext::ParameterListContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::ParameterDeclarationContext* PnfCParser::ParameterListContext::parameterDeclaration() {
  return getRuleContext<PnfCParser::ParameterDeclarationContext>(0);
}

PnfCParser::Kleene_star__parameterList_1Context* PnfCParser::ParameterListContext::kleene_star__parameterList_1() {
  return getRuleContext<PnfCParser::Kleene_star__parameterList_1Context>(0);
}


size_t PnfCParser::ParameterListContext::getRuleIndex() const {
  return PnfCParser::RuleParameterList;
}

void PnfCParser::ParameterListContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterParameterList(this);
}

void PnfCParser::ParameterListContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitParameterList(this);
}


antlrcpp::Any PnfCParser::ParameterListContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitParameterList(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::ParameterListContext* PnfCParser::parameterList() {
  ParameterListContext *_localctx = _tracker.createInstance<ParameterListContext>(_ctx, getState());
  enterRule(_localctx, 292, PnfCParser::RuleParameterList);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1105);
    parameterDeclaration();
    setState(1106);
    kleene_star__parameterList_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__directAbstractDeclarator_13Context ------------------------------------------------------------------

PnfCParser::Aux_rule__directAbstractDeclarator_13Context::Aux_rule__directAbstractDeclarator_13Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Aux_rule__directAbstractDeclarator_21Context* PnfCParser::Aux_rule__directAbstractDeclarator_13Context::aux_rule__directAbstractDeclarator_21() {
  return getRuleContext<PnfCParser::Aux_rule__directAbstractDeclarator_21Context>(0);
}

PnfCParser::Aux_rule__directAbstractDeclarator_22Context* PnfCParser::Aux_rule__directAbstractDeclarator_13Context::aux_rule__directAbstractDeclarator_22() {
  return getRuleContext<PnfCParser::Aux_rule__directAbstractDeclarator_22Context>(0);
}


size_t PnfCParser::Aux_rule__directAbstractDeclarator_13Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__directAbstractDeclarator_13;
}

void PnfCParser::Aux_rule__directAbstractDeclarator_13Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__directAbstractDeclarator_13(this);
}

void PnfCParser::Aux_rule__directAbstractDeclarator_13Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__directAbstractDeclarator_13(this);
}


antlrcpp::Any PnfCParser::Aux_rule__directAbstractDeclarator_13Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__directAbstractDeclarator_13(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__directAbstractDeclarator_13Context* PnfCParser::aux_rule__directAbstractDeclarator_13() {
  Aux_rule__directAbstractDeclarator_13Context *_localctx = _tracker.createInstance<Aux_rule__directAbstractDeclarator_13Context>(_ctx, getState());
  enterRule(_localctx, 294, PnfCParser::RuleAux_rule__directAbstractDeclarator_13);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1110);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case PnfCParser::LeftParen: {
        enterOuterAlt(_localctx, 1);
        setState(1108);
        aux_rule__directAbstractDeclarator_21();
        break;
      }

      case PnfCParser::LeftBracket: {
        enterOuterAlt(_localctx, 2);
        setState(1109);
        aux_rule__directAbstractDeclarator_22();
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__directAbstractDeclarator_12Context ------------------------------------------------------------------

PnfCParser::Kleene_star__directAbstractDeclarator_12Context::Kleene_star__directAbstractDeclarator_12Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfCParser::Aux_rule__directAbstractDeclarator_13Context *> PnfCParser::Kleene_star__directAbstractDeclarator_12Context::aux_rule__directAbstractDeclarator_13() {
  return getRuleContexts<PnfCParser::Aux_rule__directAbstractDeclarator_13Context>();
}

PnfCParser::Aux_rule__directAbstractDeclarator_13Context* PnfCParser::Kleene_star__directAbstractDeclarator_12Context::aux_rule__directAbstractDeclarator_13(size_t i) {
  return getRuleContext<PnfCParser::Aux_rule__directAbstractDeclarator_13Context>(i);
}


size_t PnfCParser::Kleene_star__directAbstractDeclarator_12Context::getRuleIndex() const {
  return PnfCParser::RuleKleene_star__directAbstractDeclarator_12;
}

void PnfCParser::Kleene_star__directAbstractDeclarator_12Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__directAbstractDeclarator_12(this);
}

void PnfCParser::Kleene_star__directAbstractDeclarator_12Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__directAbstractDeclarator_12(this);
}


antlrcpp::Any PnfCParser::Kleene_star__directAbstractDeclarator_12Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitKleene_star__directAbstractDeclarator_12(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Kleene_star__directAbstractDeclarator_12Context* PnfCParser::kleene_star__directAbstractDeclarator_12() {
  Kleene_star__directAbstractDeclarator_12Context *_localctx = _tracker.createInstance<Kleene_star__directAbstractDeclarator_12Context>(_ctx, getState());
  enterRule(_localctx, 296, PnfCParser::RuleKleene_star__directAbstractDeclarator_12);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1115);
    _errHandler->sync(this);
    _la = _input->LA(1);
    while (_la == PnfCParser::LeftParen

    || _la == PnfCParser::LeftBracket) {
      setState(1112);
      aux_rule__directAbstractDeclarator_13();
      setState(1117);
      _errHandler->sync(this);
      _la = _input->LA(1);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__directAbstractDeclarator_14Context ------------------------------------------------------------------

PnfCParser::Aux_rule__directAbstractDeclarator_14Context::Aux_rule__directAbstractDeclarator_14Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Aux_rule__directAbstractDeclarator_23Context* PnfCParser::Aux_rule__directAbstractDeclarator_14Context::aux_rule__directAbstractDeclarator_23() {
  return getRuleContext<PnfCParser::Aux_rule__directAbstractDeclarator_23Context>(0);
}

PnfCParser::Aux_rule__directAbstractDeclarator_24Context* PnfCParser::Aux_rule__directAbstractDeclarator_14Context::aux_rule__directAbstractDeclarator_24() {
  return getRuleContext<PnfCParser::Aux_rule__directAbstractDeclarator_24Context>(0);
}


size_t PnfCParser::Aux_rule__directAbstractDeclarator_14Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__directAbstractDeclarator_14;
}

void PnfCParser::Aux_rule__directAbstractDeclarator_14Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__directAbstractDeclarator_14(this);
}

void PnfCParser::Aux_rule__directAbstractDeclarator_14Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__directAbstractDeclarator_14(this);
}


antlrcpp::Any PnfCParser::Aux_rule__directAbstractDeclarator_14Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__directAbstractDeclarator_14(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__directAbstractDeclarator_14Context* PnfCParser::aux_rule__directAbstractDeclarator_14() {
  Aux_rule__directAbstractDeclarator_14Context *_localctx = _tracker.createInstance<Aux_rule__directAbstractDeclarator_14Context>(_ctx, getState());
  enterRule(_localctx, 298, PnfCParser::RuleAux_rule__directAbstractDeclarator_14);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1120);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case PnfCParser::LeftBracket: {
        enterOuterAlt(_localctx, 1);
        setState(1118);
        aux_rule__directAbstractDeclarator_23();
        break;
      }

      case PnfCParser::LeftParen: {
        enterOuterAlt(_localctx, 2);
        setState(1119);
        aux_rule__directAbstractDeclarator_24();
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- DirectAbstractDeclaratorContext ------------------------------------------------------------------

PnfCParser::DirectAbstractDeclaratorContext::DirectAbstractDeclaratorContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Aux_rule__directAbstractDeclarator_14Context* PnfCParser::DirectAbstractDeclaratorContext::aux_rule__directAbstractDeclarator_14() {
  return getRuleContext<PnfCParser::Aux_rule__directAbstractDeclarator_14Context>(0);
}

PnfCParser::Kleene_star__directAbstractDeclarator_12Context* PnfCParser::DirectAbstractDeclaratorContext::kleene_star__directAbstractDeclarator_12() {
  return getRuleContext<PnfCParser::Kleene_star__directAbstractDeclarator_12Context>(0);
}


size_t PnfCParser::DirectAbstractDeclaratorContext::getRuleIndex() const {
  return PnfCParser::RuleDirectAbstractDeclarator;
}

void PnfCParser::DirectAbstractDeclaratorContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterDirectAbstractDeclarator(this);
}

void PnfCParser::DirectAbstractDeclaratorContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitDirectAbstractDeclarator(this);
}


antlrcpp::Any PnfCParser::DirectAbstractDeclaratorContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitDirectAbstractDeclarator(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::DirectAbstractDeclaratorContext* PnfCParser::directAbstractDeclarator() {
  DirectAbstractDeclaratorContext *_localctx = _tracker.createInstance<DirectAbstractDeclaratorContext>(_ctx, getState());
  enterRule(_localctx, 300, PnfCParser::RuleDirectAbstractDeclarator);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1122);
    aux_rule__directAbstractDeclarator_14();
    setState(1123);
    kleene_star__directAbstractDeclarator_12();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- DesignatorListContext ------------------------------------------------------------------

PnfCParser::DesignatorListContext::DesignatorListContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Kleene_plus__designatorList_3Context* PnfCParser::DesignatorListContext::kleene_plus__designatorList_3() {
  return getRuleContext<PnfCParser::Kleene_plus__designatorList_3Context>(0);
}


size_t PnfCParser::DesignatorListContext::getRuleIndex() const {
  return PnfCParser::RuleDesignatorList;
}

void PnfCParser::DesignatorListContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterDesignatorList(this);
}

void PnfCParser::DesignatorListContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitDesignatorList(this);
}


antlrcpp::Any PnfCParser::DesignatorListContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitDesignatorList(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::DesignatorListContext* PnfCParser::designatorList() {
  DesignatorListContext *_localctx = _tracker.createInstance<DesignatorListContext>(_ctx, getState());
  enterRule(_localctx, 302, PnfCParser::RuleDesignatorList);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1125);
    kleene_plus__designatorList_3();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- BlockItemListContext ------------------------------------------------------------------

PnfCParser::BlockItemListContext::BlockItemListContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Kleene_plus__blockItemList_3Context* PnfCParser::BlockItemListContext::kleene_plus__blockItemList_3() {
  return getRuleContext<PnfCParser::Kleene_plus__blockItemList_3Context>(0);
}


size_t PnfCParser::BlockItemListContext::getRuleIndex() const {
  return PnfCParser::RuleBlockItemList;
}

void PnfCParser::BlockItemListContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterBlockItemList(this);
}

void PnfCParser::BlockItemListContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitBlockItemList(this);
}


antlrcpp::Any PnfCParser::BlockItemListContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitBlockItemList(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::BlockItemListContext* PnfCParser::blockItemList() {
  BlockItemListContext *_localctx = _tracker.createInstance<BlockItemListContext>(_ctx, getState());
  enterRule(_localctx, 304, PnfCParser::RuleBlockItemList);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1127);
    kleene_plus__blockItemList_3();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- TranslationUnitContext ------------------------------------------------------------------

PnfCParser::TranslationUnitContext::TranslationUnitContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Kleene_plus__translationUnit_3Context* PnfCParser::TranslationUnitContext::kleene_plus__translationUnit_3() {
  return getRuleContext<PnfCParser::Kleene_plus__translationUnit_3Context>(0);
}


size_t PnfCParser::TranslationUnitContext::getRuleIndex() const {
  return PnfCParser::RuleTranslationUnit;
}

void PnfCParser::TranslationUnitContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterTranslationUnit(this);
}

void PnfCParser::TranslationUnitContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitTranslationUnit(this);
}


antlrcpp::Any PnfCParser::TranslationUnitContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitTranslationUnit(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::TranslationUnitContext* PnfCParser::translationUnit() {
  TranslationUnitContext *_localctx = _tracker.createInstance<TranslationUnitContext>(_ctx, getState());
  enterRule(_localctx, 306, PnfCParser::RuleTranslationUnit);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1129);
    kleene_plus__translationUnit_3();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__declarationList_2Context ------------------------------------------------------------------

PnfCParser::Aux_rule__declarationList_2Context::Aux_rule__declarationList_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::DeclarationContext* PnfCParser::Aux_rule__declarationList_2Context::declaration() {
  return getRuleContext<PnfCParser::DeclarationContext>(0);
}


size_t PnfCParser::Aux_rule__declarationList_2Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__declarationList_2;
}

void PnfCParser::Aux_rule__declarationList_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__declarationList_2(this);
}

void PnfCParser::Aux_rule__declarationList_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__declarationList_2(this);
}


antlrcpp::Any PnfCParser::Aux_rule__declarationList_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__declarationList_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__declarationList_2Context* PnfCParser::aux_rule__declarationList_2() {
  Aux_rule__declarationList_2Context *_localctx = _tracker.createInstance<Aux_rule__declarationList_2Context>(_ctx, getState());
  enterRule(_localctx, 308, PnfCParser::RuleAux_rule__declarationList_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1131);
    declaration();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- DeclarationListContext ------------------------------------------------------------------

PnfCParser::DeclarationListContext::DeclarationListContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Kleene_plus__declarationList_3Context* PnfCParser::DeclarationListContext::kleene_plus__declarationList_3() {
  return getRuleContext<PnfCParser::Kleene_plus__declarationList_3Context>(0);
}


size_t PnfCParser::DeclarationListContext::getRuleIndex() const {
  return PnfCParser::RuleDeclarationList;
}

void PnfCParser::DeclarationListContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterDeclarationList(this);
}

void PnfCParser::DeclarationListContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitDeclarationList(this);
}


antlrcpp::Any PnfCParser::DeclarationListContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitDeclarationList(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::DeclarationListContext* PnfCParser::declarationList() {
  DeclarationListContext *_localctx = _tracker.createInstance<DeclarationListContext>(_ctx, getState());
  enterRule(_localctx, 310, PnfCParser::RuleDeclarationList);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1133);
    kleene_plus__declarationList_3();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_plus__structDeclarationList_3Context ------------------------------------------------------------------

PnfCParser::Kleene_plus__structDeclarationList_3Context::Kleene_plus__structDeclarationList_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfCParser::Aux_rule__structDeclarationList_2Context *> PnfCParser::Kleene_plus__structDeclarationList_3Context::aux_rule__structDeclarationList_2() {
  return getRuleContexts<PnfCParser::Aux_rule__structDeclarationList_2Context>();
}

PnfCParser::Aux_rule__structDeclarationList_2Context* PnfCParser::Kleene_plus__structDeclarationList_3Context::aux_rule__structDeclarationList_2(size_t i) {
  return getRuleContext<PnfCParser::Aux_rule__structDeclarationList_2Context>(i);
}


size_t PnfCParser::Kleene_plus__structDeclarationList_3Context::getRuleIndex() const {
  return PnfCParser::RuleKleene_plus__structDeclarationList_3;
}

void PnfCParser::Kleene_plus__structDeclarationList_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_plus__structDeclarationList_3(this);
}

void PnfCParser::Kleene_plus__structDeclarationList_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_plus__structDeclarationList_3(this);
}


antlrcpp::Any PnfCParser::Kleene_plus__structDeclarationList_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitKleene_plus__structDeclarationList_3(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Kleene_plus__structDeclarationList_3Context* PnfCParser::kleene_plus__structDeclarationList_3() {
  Kleene_plus__structDeclarationList_3Context *_localctx = _tracker.createInstance<Kleene_plus__structDeclarationList_3Context>(_ctx, getState());
  enterRule(_localctx, 312, PnfCParser::RuleKleene_plus__structDeclarationList_3);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1136); 
    _errHandler->sync(this);
    _la = _input->LA(1);
    do {
      setState(1135);
      aux_rule__structDeclarationList_2();
      setState(1138); 
      _errHandler->sync(this);
      _la = _input->LA(1);
    } while ((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << PnfCParser::T__0)
      | (1ULL << PnfCParser::T__1)
      | (1ULL << PnfCParser::T__2)
      | (1ULL << PnfCParser::T__12)
      | (1ULL << PnfCParser::Char)
      | (1ULL << PnfCParser::Const)
      | (1ULL << PnfCParser::Nonnull)
      | (1ULL << PnfCParser::Nullable)
      | (1ULL << PnfCParser::Double)
      | (1ULL << PnfCParser::Enum)
      | (1ULL << PnfCParser::Float)
      | (1ULL << PnfCParser::Int)
      | (1ULL << PnfCParser::Long)
      | (1ULL << PnfCParser::Restrict)
      | (1ULL << PnfCParser::Restrict_gcc)
      | (1ULL << PnfCParser::Restrict_gcc2)
      | (1ULL << PnfCParser::Extension_gcc)
      | (1ULL << PnfCParser::Short)
      | (1ULL << PnfCParser::Signed)
      | (1ULL << PnfCParser::Struct)
      | (1ULL << PnfCParser::Union)
      | (1ULL << PnfCParser::Unsigned)
      | (1ULL << PnfCParser::Void)
      | (1ULL << PnfCParser::Volatile)
      | (1ULL << PnfCParser::Atomic)
      | (1ULL << PnfCParser::Bool)
      | (1ULL << PnfCParser::Complex))) != 0) || _la == PnfCParser::StaticAssert

    || _la == PnfCParser::Identifier);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_plus__typeQualifierList_3Context ------------------------------------------------------------------

PnfCParser::Kleene_plus__typeQualifierList_3Context::Kleene_plus__typeQualifierList_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfCParser::Aux_rule__typeQualifierList_2Context *> PnfCParser::Kleene_plus__typeQualifierList_3Context::aux_rule__typeQualifierList_2() {
  return getRuleContexts<PnfCParser::Aux_rule__typeQualifierList_2Context>();
}

PnfCParser::Aux_rule__typeQualifierList_2Context* PnfCParser::Kleene_plus__typeQualifierList_3Context::aux_rule__typeQualifierList_2(size_t i) {
  return getRuleContext<PnfCParser::Aux_rule__typeQualifierList_2Context>(i);
}


size_t PnfCParser::Kleene_plus__typeQualifierList_3Context::getRuleIndex() const {
  return PnfCParser::RuleKleene_plus__typeQualifierList_3;
}

void PnfCParser::Kleene_plus__typeQualifierList_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_plus__typeQualifierList_3(this);
}

void PnfCParser::Kleene_plus__typeQualifierList_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_plus__typeQualifierList_3(this);
}


antlrcpp::Any PnfCParser::Kleene_plus__typeQualifierList_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitKleene_plus__typeQualifierList_3(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Kleene_plus__typeQualifierList_3Context* PnfCParser::kleene_plus__typeQualifierList_3() {
  Kleene_plus__typeQualifierList_3Context *_localctx = _tracker.createInstance<Kleene_plus__typeQualifierList_3Context>(_ctx, getState());
  enterRule(_localctx, 314, PnfCParser::RuleKleene_plus__typeQualifierList_3);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1141); 
    _errHandler->sync(this);
    _la = _input->LA(1);
    do {
      setState(1140);
      aux_rule__typeQualifierList_2();
      setState(1143); 
      _errHandler->sync(this);
      _la = _input->LA(1);
    } while ((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << PnfCParser::Const)
      | (1ULL << PnfCParser::Nonnull)
      | (1ULL << PnfCParser::Nullable)
      | (1ULL << PnfCParser::Restrict)
      | (1ULL << PnfCParser::Restrict_gcc)
      | (1ULL << PnfCParser::Restrict_gcc2)
      | (1ULL << PnfCParser::Volatile)
      | (1ULL << PnfCParser::Atomic))) != 0));
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_plus__designatorList_3Context ------------------------------------------------------------------

PnfCParser::Kleene_plus__designatorList_3Context::Kleene_plus__designatorList_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfCParser::Aux_rule__designatorList_2Context *> PnfCParser::Kleene_plus__designatorList_3Context::aux_rule__designatorList_2() {
  return getRuleContexts<PnfCParser::Aux_rule__designatorList_2Context>();
}

PnfCParser::Aux_rule__designatorList_2Context* PnfCParser::Kleene_plus__designatorList_3Context::aux_rule__designatorList_2(size_t i) {
  return getRuleContext<PnfCParser::Aux_rule__designatorList_2Context>(i);
}


size_t PnfCParser::Kleene_plus__designatorList_3Context::getRuleIndex() const {
  return PnfCParser::RuleKleene_plus__designatorList_3;
}

void PnfCParser::Kleene_plus__designatorList_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_plus__designatorList_3(this);
}

void PnfCParser::Kleene_plus__designatorList_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_plus__designatorList_3(this);
}


antlrcpp::Any PnfCParser::Kleene_plus__designatorList_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitKleene_plus__designatorList_3(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Kleene_plus__designatorList_3Context* PnfCParser::kleene_plus__designatorList_3() {
  Kleene_plus__designatorList_3Context *_localctx = _tracker.createInstance<Kleene_plus__designatorList_3Context>(_ctx, getState());
  enterRule(_localctx, 316, PnfCParser::RuleKleene_plus__designatorList_3);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1146); 
    _errHandler->sync(this);
    _la = _input->LA(1);
    do {
      setState(1145);
      aux_rule__designatorList_2();
      setState(1148); 
      _errHandler->sync(this);
      _la = _input->LA(1);
    } while (_la == PnfCParser::LeftBracket

    || _la == PnfCParser::Dot);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_plus__blockItemList_3Context ------------------------------------------------------------------

PnfCParser::Kleene_plus__blockItemList_3Context::Kleene_plus__blockItemList_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfCParser::Aux_rule__blockItemList_2Context *> PnfCParser::Kleene_plus__blockItemList_3Context::aux_rule__blockItemList_2() {
  return getRuleContexts<PnfCParser::Aux_rule__blockItemList_2Context>();
}

PnfCParser::Aux_rule__blockItemList_2Context* PnfCParser::Kleene_plus__blockItemList_3Context::aux_rule__blockItemList_2(size_t i) {
  return getRuleContext<PnfCParser::Aux_rule__blockItemList_2Context>(i);
}


size_t PnfCParser::Kleene_plus__blockItemList_3Context::getRuleIndex() const {
  return PnfCParser::RuleKleene_plus__blockItemList_3;
}

void PnfCParser::Kleene_plus__blockItemList_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_plus__blockItemList_3(this);
}

void PnfCParser::Kleene_plus__blockItemList_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_plus__blockItemList_3(this);
}


antlrcpp::Any PnfCParser::Kleene_plus__blockItemList_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitKleene_plus__blockItemList_3(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Kleene_plus__blockItemList_3Context* PnfCParser::kleene_plus__blockItemList_3() {
  Kleene_plus__blockItemList_3Context *_localctx = _tracker.createInstance<Kleene_plus__blockItemList_3Context>(_ctx, getState());
  enterRule(_localctx, 318, PnfCParser::RuleKleene_plus__blockItemList_3);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1151); 
    _errHandler->sync(this);
    _la = _input->LA(1);
    do {
      setState(1150);
      aux_rule__blockItemList_2();
      setState(1153); 
      _errHandler->sync(this);
      _la = _input->LA(1);
    } while ((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << PnfCParser::T__0)
      | (1ULL << PnfCParser::T__1)
      | (1ULL << PnfCParser::T__2)
      | (1ULL << PnfCParser::T__3)
      | (1ULL << PnfCParser::T__4)
      | (1ULL << PnfCParser::T__5)
      | (1ULL << PnfCParser::T__6)
      | (1ULL << PnfCParser::T__8)
      | (1ULL << PnfCParser::T__9)
      | (1ULL << PnfCParser::T__10)
      | (1ULL << PnfCParser::T__11)
      | (1ULL << PnfCParser::T__12)
      | (1ULL << PnfCParser::T__13)
      | (1ULL << PnfCParser::Auto)
      | (1ULL << PnfCParser::Break)
      | (1ULL << PnfCParser::Case)
      | (1ULL << PnfCParser::Char)
      | (1ULL << PnfCParser::Const)
      | (1ULL << PnfCParser::Nonnull)
      | (1ULL << PnfCParser::Nullable)
      | (1ULL << PnfCParser::Continue)
      | (1ULL << PnfCParser::Default)
      | (1ULL << PnfCParser::Do)
      | (1ULL << PnfCParser::Double)
      | (1ULL << PnfCParser::Enum)
      | (1ULL << PnfCParser::Extern)
      | (1ULL << PnfCParser::Float)
      | (1ULL << PnfCParser::For)
      | (1ULL << PnfCParser::Goto)
      | (1ULL << PnfCParser::If)
      | (1ULL << PnfCParser::Inline)
      | (1ULL << PnfCParser::Int)
      | (1ULL << PnfCParser::Long)
      | (1ULL << PnfCParser::Register)
      | (1ULL << PnfCParser::Restrict)
      | (1ULL << PnfCParser::Restrict_gcc)
      | (1ULL << PnfCParser::Restrict_gcc2)
      | (1ULL << PnfCParser::Extension_gcc)
      | (1ULL << PnfCParser::Return)
      | (1ULL << PnfCParser::Short)
      | (1ULL << PnfCParser::Signed)
      | (1ULL << PnfCParser::Sizeof)
      | (1ULL << PnfCParser::Static)
      | (1ULL << PnfCParser::Struct)
      | (1ULL << PnfCParser::Switch)
      | (1ULL << PnfCParser::Typedef)
      | (1ULL << PnfCParser::Union)
      | (1ULL << PnfCParser::Unsigned)
      | (1ULL << PnfCParser::Void)
      | (1ULL << PnfCParser::Volatile)
      | (1ULL << PnfCParser::While)
      | (1ULL << PnfCParser::Alignas)
      | (1ULL << PnfCParser::Alignof)
      | (1ULL << PnfCParser::Alignof_gcc)
      | (1ULL << PnfCParser::Atomic)
      | (1ULL << PnfCParser::Bool)
      | (1ULL << PnfCParser::Complex)
      | (1ULL << PnfCParser::Generic)
      | (1ULL << PnfCParser::Noreturn))) != 0) || ((((_la - 64) & ~ 0x3fULL) == 0) &&
      ((1ULL << (_la - 64)) & ((1ULL << (PnfCParser::StaticAssert - 64))
      | (1ULL << (PnfCParser::ThreadLocal - 64))
      | (1ULL << (PnfCParser::LeftParen - 64))
      | (1ULL << (PnfCParser::LeftBrace - 64))
      | (1ULL << (PnfCParser::Plus - 64))
      | (1ULL << (PnfCParser::PlusPlus - 64))
      | (1ULL << (PnfCParser::Minus - 64))
      | (1ULL << (PnfCParser::MinusMinus - 64))
      | (1ULL << (PnfCParser::Star - 64))
      | (1ULL << (PnfCParser::And - 64))
      | (1ULL << (PnfCParser::AndAnd - 64))
      | (1ULL << (PnfCParser::Not - 64))
      | (1ULL << (PnfCParser::Tilde - 64))
      | (1ULL << (PnfCParser::Semi - 64))
      | (1ULL << (PnfCParser::Identifier - 64))
      | (1ULL << (PnfCParser::Constant - 64))
      | (1ULL << (PnfCParser::StringLiteral - 64)))) != 0));
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_plus__translationUnit_3Context ------------------------------------------------------------------

PnfCParser::Kleene_plus__translationUnit_3Context::Kleene_plus__translationUnit_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfCParser::Aux_rule__translationUnit_2Context *> PnfCParser::Kleene_plus__translationUnit_3Context::aux_rule__translationUnit_2() {
  return getRuleContexts<PnfCParser::Aux_rule__translationUnit_2Context>();
}

PnfCParser::Aux_rule__translationUnit_2Context* PnfCParser::Kleene_plus__translationUnit_3Context::aux_rule__translationUnit_2(size_t i) {
  return getRuleContext<PnfCParser::Aux_rule__translationUnit_2Context>(i);
}


size_t PnfCParser::Kleene_plus__translationUnit_3Context::getRuleIndex() const {
  return PnfCParser::RuleKleene_plus__translationUnit_3;
}

void PnfCParser::Kleene_plus__translationUnit_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_plus__translationUnit_3(this);
}

void PnfCParser::Kleene_plus__translationUnit_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_plus__translationUnit_3(this);
}


antlrcpp::Any PnfCParser::Kleene_plus__translationUnit_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitKleene_plus__translationUnit_3(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Kleene_plus__translationUnit_3Context* PnfCParser::kleene_plus__translationUnit_3() {
  Kleene_plus__translationUnit_3Context *_localctx = _tracker.createInstance<Kleene_plus__translationUnit_3Context>(_ctx, getState());
  enterRule(_localctx, 320, PnfCParser::RuleKleene_plus__translationUnit_3);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1156); 
    _errHandler->sync(this);
    _la = _input->LA(1);
    do {
      setState(1155);
      aux_rule__translationUnit_2();
      setState(1158); 
      _errHandler->sync(this);
      _la = _input->LA(1);
    } while ((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << PnfCParser::T__0)
      | (1ULL << PnfCParser::T__1)
      | (1ULL << PnfCParser::T__2)
      | (1ULL << PnfCParser::T__3)
      | (1ULL << PnfCParser::T__4)
      | (1ULL << PnfCParser::T__5)
      | (1ULL << PnfCParser::T__6)
      | (1ULL << PnfCParser::T__8)
      | (1ULL << PnfCParser::T__9)
      | (1ULL << PnfCParser::T__12)
      | (1ULL << PnfCParser::T__13)
      | (1ULL << PnfCParser::IncludeDirective)
      | (1ULL << PnfCParser::Auto)
      | (1ULL << PnfCParser::Char)
      | (1ULL << PnfCParser::Const)
      | (1ULL << PnfCParser::Nonnull)
      | (1ULL << PnfCParser::Nullable)
      | (1ULL << PnfCParser::Double)
      | (1ULL << PnfCParser::Enum)
      | (1ULL << PnfCParser::Extern)
      | (1ULL << PnfCParser::Float)
      | (1ULL << PnfCParser::Inline)
      | (1ULL << PnfCParser::Int)
      | (1ULL << PnfCParser::Long)
      | (1ULL << PnfCParser::Register)
      | (1ULL << PnfCParser::Restrict)
      | (1ULL << PnfCParser::Restrict_gcc)
      | (1ULL << PnfCParser::Restrict_gcc2)
      | (1ULL << PnfCParser::Extension_gcc)
      | (1ULL << PnfCParser::Short)
      | (1ULL << PnfCParser::Signed)
      | (1ULL << PnfCParser::Static)
      | (1ULL << PnfCParser::Struct)
      | (1ULL << PnfCParser::Typedef)
      | (1ULL << PnfCParser::Union)
      | (1ULL << PnfCParser::Unsigned)
      | (1ULL << PnfCParser::Void)
      | (1ULL << PnfCParser::Volatile)
      | (1ULL << PnfCParser::Alignas)
      | (1ULL << PnfCParser::Atomic)
      | (1ULL << PnfCParser::Bool)
      | (1ULL << PnfCParser::Complex)
      | (1ULL << PnfCParser::Noreturn))) != 0) || ((((_la - 64) & ~ 0x3fULL) == 0) &&
      ((1ULL << (_la - 64)) & ((1ULL << (PnfCParser::StaticAssert - 64))
      | (1ULL << (PnfCParser::ThreadLocal - 64))
      | (1ULL << (PnfCParser::LeftParen - 64))
      | (1ULL << (PnfCParser::Star - 64))
      | (1ULL << (PnfCParser::Caret - 64))
      | (1ULL << (PnfCParser::Semi - 64))
      | (1ULL << (PnfCParser::Identifier - 64)))) != 0));
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_plus__declarationList_3Context ------------------------------------------------------------------

PnfCParser::Kleene_plus__declarationList_3Context::Kleene_plus__declarationList_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfCParser::Aux_rule__declarationList_2Context *> PnfCParser::Kleene_plus__declarationList_3Context::aux_rule__declarationList_2() {
  return getRuleContexts<PnfCParser::Aux_rule__declarationList_2Context>();
}

PnfCParser::Aux_rule__declarationList_2Context* PnfCParser::Kleene_plus__declarationList_3Context::aux_rule__declarationList_2(size_t i) {
  return getRuleContext<PnfCParser::Aux_rule__declarationList_2Context>(i);
}


size_t PnfCParser::Kleene_plus__declarationList_3Context::getRuleIndex() const {
  return PnfCParser::RuleKleene_plus__declarationList_3;
}

void PnfCParser::Kleene_plus__declarationList_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_plus__declarationList_3(this);
}

void PnfCParser::Kleene_plus__declarationList_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_plus__declarationList_3(this);
}


antlrcpp::Any PnfCParser::Kleene_plus__declarationList_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitKleene_plus__declarationList_3(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Kleene_plus__declarationList_3Context* PnfCParser::kleene_plus__declarationList_3() {
  Kleene_plus__declarationList_3Context *_localctx = _tracker.createInstance<Kleene_plus__declarationList_3Context>(_ctx, getState());
  enterRule(_localctx, 322, PnfCParser::RuleKleene_plus__declarationList_3);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1161); 
    _errHandler->sync(this);
    _la = _input->LA(1);
    do {
      setState(1160);
      aux_rule__declarationList_2();
      setState(1163); 
      _errHandler->sync(this);
      _la = _input->LA(1);
    } while ((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << PnfCParser::T__0)
      | (1ULL << PnfCParser::T__1)
      | (1ULL << PnfCParser::T__2)
      | (1ULL << PnfCParser::T__3)
      | (1ULL << PnfCParser::T__4)
      | (1ULL << PnfCParser::T__5)
      | (1ULL << PnfCParser::T__6)
      | (1ULL << PnfCParser::T__8)
      | (1ULL << PnfCParser::T__9)
      | (1ULL << PnfCParser::T__12)
      | (1ULL << PnfCParser::T__13)
      | (1ULL << PnfCParser::Auto)
      | (1ULL << PnfCParser::Char)
      | (1ULL << PnfCParser::Const)
      | (1ULL << PnfCParser::Nonnull)
      | (1ULL << PnfCParser::Nullable)
      | (1ULL << PnfCParser::Double)
      | (1ULL << PnfCParser::Enum)
      | (1ULL << PnfCParser::Extern)
      | (1ULL << PnfCParser::Float)
      | (1ULL << PnfCParser::Inline)
      | (1ULL << PnfCParser::Int)
      | (1ULL << PnfCParser::Long)
      | (1ULL << PnfCParser::Register)
      | (1ULL << PnfCParser::Restrict)
      | (1ULL << PnfCParser::Restrict_gcc)
      | (1ULL << PnfCParser::Restrict_gcc2)
      | (1ULL << PnfCParser::Extension_gcc)
      | (1ULL << PnfCParser::Short)
      | (1ULL << PnfCParser::Signed)
      | (1ULL << PnfCParser::Static)
      | (1ULL << PnfCParser::Struct)
      | (1ULL << PnfCParser::Typedef)
      | (1ULL << PnfCParser::Union)
      | (1ULL << PnfCParser::Unsigned)
      | (1ULL << PnfCParser::Void)
      | (1ULL << PnfCParser::Volatile)
      | (1ULL << PnfCParser::Alignas)
      | (1ULL << PnfCParser::Atomic)
      | (1ULL << PnfCParser::Bool)
      | (1ULL << PnfCParser::Complex)
      | (1ULL << PnfCParser::Noreturn))) != 0) || ((((_la - 64) & ~ 0x3fULL) == 0) &&
      ((1ULL << (_la - 64)) & ((1ULL << (PnfCParser::StaticAssert - 64))
      | (1ULL << (PnfCParser::ThreadLocal - 64))
      | (1ULL << (PnfCParser::Identifier - 64)))) != 0));
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__postfixExpression_5Context ------------------------------------------------------------------

PnfCParser::Optional__postfixExpression_5Context::Optional__postfixExpression_5Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Optional__postfixExpression_5Context::Comma() {
  return getToken(PnfCParser::Comma, 0);
}


size_t PnfCParser::Optional__postfixExpression_5Context::getRuleIndex() const {
  return PnfCParser::RuleOptional__postfixExpression_5;
}

void PnfCParser::Optional__postfixExpression_5Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__postfixExpression_5(this);
}

void PnfCParser::Optional__postfixExpression_5Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__postfixExpression_5(this);
}


antlrcpp::Any PnfCParser::Optional__postfixExpression_5Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitOptional__postfixExpression_5(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Optional__postfixExpression_5Context* PnfCParser::optional__postfixExpression_5() {
  Optional__postfixExpression_5Context *_localctx = _tracker.createInstance<Optional__postfixExpression_5Context>(_ctx, getState());
  enterRule(_localctx, 324, PnfCParser::RuleOptional__postfixExpression_5);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1166);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if (_la == PnfCParser::Comma) {
      setState(1165);
      match(PnfCParser::Comma);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__initDeclarator_1Context ------------------------------------------------------------------

PnfCParser::Aux_rule__initDeclarator_1Context::Aux_rule__initDeclarator_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__initDeclarator_1Context::Assign() {
  return getToken(PnfCParser::Assign, 0);
}

PnfCParser::InitializerContext* PnfCParser::Aux_rule__initDeclarator_1Context::initializer() {
  return getRuleContext<PnfCParser::InitializerContext>(0);
}


size_t PnfCParser::Aux_rule__initDeclarator_1Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__initDeclarator_1;
}

void PnfCParser::Aux_rule__initDeclarator_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__initDeclarator_1(this);
}

void PnfCParser::Aux_rule__initDeclarator_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__initDeclarator_1(this);
}


antlrcpp::Any PnfCParser::Aux_rule__initDeclarator_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__initDeclarator_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__initDeclarator_1Context* PnfCParser::aux_rule__initDeclarator_1() {
  Aux_rule__initDeclarator_1Context *_localctx = _tracker.createInstance<Aux_rule__initDeclarator_1Context>(_ctx, getState());
  enterRule(_localctx, 326, PnfCParser::RuleAux_rule__initDeclarator_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1168);
    match(PnfCParser::Assign);
    setState(1169);
    initializer();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__initDeclarator_2Context ------------------------------------------------------------------

PnfCParser::Optional__initDeclarator_2Context::Optional__initDeclarator_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Aux_rule__initDeclarator_1Context* PnfCParser::Optional__initDeclarator_2Context::aux_rule__initDeclarator_1() {
  return getRuleContext<PnfCParser::Aux_rule__initDeclarator_1Context>(0);
}


size_t PnfCParser::Optional__initDeclarator_2Context::getRuleIndex() const {
  return PnfCParser::RuleOptional__initDeclarator_2;
}

void PnfCParser::Optional__initDeclarator_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__initDeclarator_2(this);
}

void PnfCParser::Optional__initDeclarator_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__initDeclarator_2(this);
}


antlrcpp::Any PnfCParser::Optional__initDeclarator_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitOptional__initDeclarator_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Optional__initDeclarator_2Context* PnfCParser::optional__initDeclarator_2() {
  Optional__initDeclarator_2Context *_localctx = _tracker.createInstance<Optional__initDeclarator_2Context>(_ctx, getState());
  enterRule(_localctx, 328, PnfCParser::RuleOptional__initDeclarator_2);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1172);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if (_la == PnfCParser::Assign) {
      setState(1171);
      aux_rule__initDeclarator_1();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__enumerator_1Context ------------------------------------------------------------------

PnfCParser::Aux_rule__enumerator_1Context::Aux_rule__enumerator_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__enumerator_1Context::Assign() {
  return getToken(PnfCParser::Assign, 0);
}

PnfCParser::ConstantExpressionContext* PnfCParser::Aux_rule__enumerator_1Context::constantExpression() {
  return getRuleContext<PnfCParser::ConstantExpressionContext>(0);
}


size_t PnfCParser::Aux_rule__enumerator_1Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__enumerator_1;
}

void PnfCParser::Aux_rule__enumerator_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__enumerator_1(this);
}

void PnfCParser::Aux_rule__enumerator_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__enumerator_1(this);
}


antlrcpp::Any PnfCParser::Aux_rule__enumerator_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__enumerator_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__enumerator_1Context* PnfCParser::aux_rule__enumerator_1() {
  Aux_rule__enumerator_1Context *_localctx = _tracker.createInstance<Aux_rule__enumerator_1Context>(_ctx, getState());
  enterRule(_localctx, 330, PnfCParser::RuleAux_rule__enumerator_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1174);
    match(PnfCParser::Assign);
    setState(1175);
    constantExpression();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__enumerator_2Context ------------------------------------------------------------------

PnfCParser::Optional__enumerator_2Context::Optional__enumerator_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Aux_rule__enumerator_1Context* PnfCParser::Optional__enumerator_2Context::aux_rule__enumerator_1() {
  return getRuleContext<PnfCParser::Aux_rule__enumerator_1Context>(0);
}


size_t PnfCParser::Optional__enumerator_2Context::getRuleIndex() const {
  return PnfCParser::RuleOptional__enumerator_2;
}

void PnfCParser::Optional__enumerator_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__enumerator_2(this);
}

void PnfCParser::Optional__enumerator_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__enumerator_2(this);
}


antlrcpp::Any PnfCParser::Optional__enumerator_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitOptional__enumerator_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Optional__enumerator_2Context* PnfCParser::optional__enumerator_2() {
  Optional__enumerator_2Context *_localctx = _tracker.createInstance<Optional__enumerator_2Context>(_ctx, getState());
  enterRule(_localctx, 332, PnfCParser::RuleOptional__enumerator_2);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1178);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if (_la == PnfCParser::Assign) {
      setState(1177);
      aux_rule__enumerator_1();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__parameterTypeList_1Context ------------------------------------------------------------------

PnfCParser::Aux_rule__parameterTypeList_1Context::Aux_rule__parameterTypeList_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__parameterTypeList_1Context::Comma() {
  return getToken(PnfCParser::Comma, 0);
}

tree::TerminalNode* PnfCParser::Aux_rule__parameterTypeList_1Context::Ellipsis() {
  return getToken(PnfCParser::Ellipsis, 0);
}


size_t PnfCParser::Aux_rule__parameterTypeList_1Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__parameterTypeList_1;
}

void PnfCParser::Aux_rule__parameterTypeList_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__parameterTypeList_1(this);
}

void PnfCParser::Aux_rule__parameterTypeList_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__parameterTypeList_1(this);
}


antlrcpp::Any PnfCParser::Aux_rule__parameterTypeList_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__parameterTypeList_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__parameterTypeList_1Context* PnfCParser::aux_rule__parameterTypeList_1() {
  Aux_rule__parameterTypeList_1Context *_localctx = _tracker.createInstance<Aux_rule__parameterTypeList_1Context>(_ctx, getState());
  enterRule(_localctx, 334, PnfCParser::RuleAux_rule__parameterTypeList_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1180);
    match(PnfCParser::Comma);
    setState(1181);
    match(PnfCParser::Ellipsis);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__parameterTypeList_2Context ------------------------------------------------------------------

PnfCParser::Optional__parameterTypeList_2Context::Optional__parameterTypeList_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Aux_rule__parameterTypeList_1Context* PnfCParser::Optional__parameterTypeList_2Context::aux_rule__parameterTypeList_1() {
  return getRuleContext<PnfCParser::Aux_rule__parameterTypeList_1Context>(0);
}


size_t PnfCParser::Optional__parameterTypeList_2Context::getRuleIndex() const {
  return PnfCParser::RuleOptional__parameterTypeList_2;
}

void PnfCParser::Optional__parameterTypeList_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__parameterTypeList_2(this);
}

void PnfCParser::Optional__parameterTypeList_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__parameterTypeList_2(this);
}


antlrcpp::Any PnfCParser::Optional__parameterTypeList_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitOptional__parameterTypeList_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Optional__parameterTypeList_2Context* PnfCParser::optional__parameterTypeList_2() {
  Optional__parameterTypeList_2Context *_localctx = _tracker.createInstance<Optional__parameterTypeList_2Context>(_ctx, getState());
  enterRule(_localctx, 336, PnfCParser::RuleOptional__parameterTypeList_2);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1184);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if (_la == PnfCParser::Comma) {
      setState(1183);
      aux_rule__parameterTypeList_1();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__primaryExpression_3Context ------------------------------------------------------------------

PnfCParser::Altnt_block__primaryExpression_3Context::Altnt_block__primaryExpression_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Aux_rule__primaryExpression_4Context* PnfCParser::Altnt_block__primaryExpression_3Context::aux_rule__primaryExpression_4() {
  return getRuleContext<PnfCParser::Aux_rule__primaryExpression_4Context>(0);
}

PnfCParser::Aux_rule__primaryExpression_5Context* PnfCParser::Altnt_block__primaryExpression_3Context::aux_rule__primaryExpression_5() {
  return getRuleContext<PnfCParser::Aux_rule__primaryExpression_5Context>(0);
}

PnfCParser::Aux_rule__primaryExpression_6Context* PnfCParser::Altnt_block__primaryExpression_3Context::aux_rule__primaryExpression_6() {
  return getRuleContext<PnfCParser::Aux_rule__primaryExpression_6Context>(0);
}

PnfCParser::Aux_rule__primaryExpression_7Context* PnfCParser::Altnt_block__primaryExpression_3Context::aux_rule__primaryExpression_7() {
  return getRuleContext<PnfCParser::Aux_rule__primaryExpression_7Context>(0);
}


size_t PnfCParser::Altnt_block__primaryExpression_3Context::getRuleIndex() const {
  return PnfCParser::RuleAltnt_block__primaryExpression_3;
}

void PnfCParser::Altnt_block__primaryExpression_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__primaryExpression_3(this);
}

void PnfCParser::Altnt_block__primaryExpression_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__primaryExpression_3(this);
}


antlrcpp::Any PnfCParser::Altnt_block__primaryExpression_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__primaryExpression_3(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Altnt_block__primaryExpression_3Context* PnfCParser::altnt_block__primaryExpression_3() {
  Altnt_block__primaryExpression_3Context *_localctx = _tracker.createInstance<Altnt_block__primaryExpression_3Context>(_ctx, getState());
  enterRule(_localctx, 338, PnfCParser::RuleAltnt_block__primaryExpression_3);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1190);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 77, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(1186);
      aux_rule__primaryExpression_4();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(1187);
      aux_rule__primaryExpression_5();
      break;
    }

    case 3: {
      enterOuterAlt(_localctx, 3);
      setState(1188);
      aux_rule__primaryExpression_6();
      break;
    }

    case 4: {
      enterOuterAlt(_localctx, 4);
      setState(1189);
      aux_rule__primaryExpression_7();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__unaryExpression_1Context ------------------------------------------------------------------

PnfCParser::Altnt_block__unaryExpression_1Context::Altnt_block__unaryExpression_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Altnt_block__unaryExpression_1Context::PlusPlus() {
  return getToken(PnfCParser::PlusPlus, 0);
}

tree::TerminalNode* PnfCParser::Altnt_block__unaryExpression_1Context::MinusMinus() {
  return getToken(PnfCParser::MinusMinus, 0);
}

tree::TerminalNode* PnfCParser::Altnt_block__unaryExpression_1Context::Sizeof() {
  return getToken(PnfCParser::Sizeof, 0);
}


size_t PnfCParser::Altnt_block__unaryExpression_1Context::getRuleIndex() const {
  return PnfCParser::RuleAltnt_block__unaryExpression_1;
}

void PnfCParser::Altnt_block__unaryExpression_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__unaryExpression_1(this);
}

void PnfCParser::Altnt_block__unaryExpression_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__unaryExpression_1(this);
}


antlrcpp::Any PnfCParser::Altnt_block__unaryExpression_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__unaryExpression_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Altnt_block__unaryExpression_1Context* PnfCParser::altnt_block__unaryExpression_1() {
  Altnt_block__unaryExpression_1Context *_localctx = _tracker.createInstance<Altnt_block__unaryExpression_1Context>(_ctx, getState());
  enterRule(_localctx, 340, PnfCParser::RuleAltnt_block__unaryExpression_1);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1192);
    _la = _input->LA(1);
    if (!(((((_la - 45) & ~ 0x3fULL) == 0) &&
      ((1ULL << (_la - 45)) & ((1ULL << (PnfCParser::Sizeof - 45))
      | (1ULL << (PnfCParser::PlusPlus - 45))
      | (1ULL << (PnfCParser::MinusMinus - 45)))) != 0))) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__unaryExpression_2Context ------------------------------------------------------------------

PnfCParser::Altnt_block__unaryExpression_2Context::Altnt_block__unaryExpression_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Aux_rule__unaryExpression_9Context* PnfCParser::Altnt_block__unaryExpression_2Context::aux_rule__unaryExpression_9() {
  return getRuleContext<PnfCParser::Aux_rule__unaryExpression_9Context>(0);
}

PnfCParser::Aux_rule__unaryExpression_10Context* PnfCParser::Altnt_block__unaryExpression_2Context::aux_rule__unaryExpression_10() {
  return getRuleContext<PnfCParser::Aux_rule__unaryExpression_10Context>(0);
}


size_t PnfCParser::Altnt_block__unaryExpression_2Context::getRuleIndex() const {
  return PnfCParser::RuleAltnt_block__unaryExpression_2;
}

void PnfCParser::Altnt_block__unaryExpression_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__unaryExpression_2(this);
}

void PnfCParser::Altnt_block__unaryExpression_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__unaryExpression_2(this);
}


antlrcpp::Any PnfCParser::Altnt_block__unaryExpression_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__unaryExpression_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Altnt_block__unaryExpression_2Context* PnfCParser::altnt_block__unaryExpression_2() {
  Altnt_block__unaryExpression_2Context *_localctx = _tracker.createInstance<Altnt_block__unaryExpression_2Context>(_ctx, getState());
  enterRule(_localctx, 342, PnfCParser::RuleAltnt_block__unaryExpression_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1196);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case PnfCParser::Sizeof: {
        enterOuterAlt(_localctx, 1);
        setState(1194);
        aux_rule__unaryExpression_9();
        break;
      }

      case PnfCParser::Alignof:
      case PnfCParser::Alignof_gcc: {
        enterOuterAlt(_localctx, 2);
        setState(1195);
        aux_rule__unaryExpression_10();
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__genericAssociation_1Context ------------------------------------------------------------------

PnfCParser::Altnt_block__genericAssociation_1Context::Altnt_block__genericAssociation_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::TypeNameContext* PnfCParser::Altnt_block__genericAssociation_1Context::typeName() {
  return getRuleContext<PnfCParser::TypeNameContext>(0);
}

tree::TerminalNode* PnfCParser::Altnt_block__genericAssociation_1Context::Default() {
  return getToken(PnfCParser::Default, 0);
}


size_t PnfCParser::Altnt_block__genericAssociation_1Context::getRuleIndex() const {
  return PnfCParser::RuleAltnt_block__genericAssociation_1;
}

void PnfCParser::Altnt_block__genericAssociation_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__genericAssociation_1(this);
}

void PnfCParser::Altnt_block__genericAssociation_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__genericAssociation_1(this);
}


antlrcpp::Any PnfCParser::Altnt_block__genericAssociation_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__genericAssociation_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Altnt_block__genericAssociation_1Context* PnfCParser::altnt_block__genericAssociation_1() {
  Altnt_block__genericAssociation_1Context *_localctx = _tracker.createInstance<Altnt_block__genericAssociation_1Context>(_ctx, getState());
  enterRule(_localctx, 344, PnfCParser::RuleAltnt_block__genericAssociation_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1200);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case PnfCParser::T__0:
      case PnfCParser::T__1:
      case PnfCParser::T__2:
      case PnfCParser::T__12:
      case PnfCParser::Char:
      case PnfCParser::Const:
      case PnfCParser::Nonnull:
      case PnfCParser::Nullable:
      case PnfCParser::Double:
      case PnfCParser::Enum:
      case PnfCParser::Float:
      case PnfCParser::Int:
      case PnfCParser::Long:
      case PnfCParser::Restrict:
      case PnfCParser::Restrict_gcc:
      case PnfCParser::Restrict_gcc2:
      case PnfCParser::Extension_gcc:
      case PnfCParser::Short:
      case PnfCParser::Signed:
      case PnfCParser::Struct:
      case PnfCParser::Union:
      case PnfCParser::Unsigned:
      case PnfCParser::Void:
      case PnfCParser::Volatile:
      case PnfCParser::Atomic:
      case PnfCParser::Bool:
      case PnfCParser::Complex:
      case PnfCParser::Identifier: {
        enterOuterAlt(_localctx, 1);
        setState(1198);
        typeName();
        break;
      }

      case PnfCParser::Default: {
        enterOuterAlt(_localctx, 2);
        setState(1199);
        match(PnfCParser::Default);
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__postfixExpression_7Context ------------------------------------------------------------------

PnfCParser::Altnt_block__postfixExpression_7Context::Altnt_block__postfixExpression_7Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Altnt_block__postfixExpression_7Context::Dot() {
  return getToken(PnfCParser::Dot, 0);
}

tree::TerminalNode* PnfCParser::Altnt_block__postfixExpression_7Context::Arrow() {
  return getToken(PnfCParser::Arrow, 0);
}


size_t PnfCParser::Altnt_block__postfixExpression_7Context::getRuleIndex() const {
  return PnfCParser::RuleAltnt_block__postfixExpression_7;
}

void PnfCParser::Altnt_block__postfixExpression_7Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__postfixExpression_7(this);
}

void PnfCParser::Altnt_block__postfixExpression_7Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__postfixExpression_7(this);
}


antlrcpp::Any PnfCParser::Altnt_block__postfixExpression_7Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__postfixExpression_7(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Altnt_block__postfixExpression_7Context* PnfCParser::altnt_block__postfixExpression_7() {
  Altnt_block__postfixExpression_7Context *_localctx = _tracker.createInstance<Altnt_block__postfixExpression_7Context>(_ctx, getState());
  enterRule(_localctx, 346, PnfCParser::RuleAltnt_block__postfixExpression_7);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1202);
    _la = _input->LA(1);
    if (!(_la == PnfCParser::Arrow

    || _la == PnfCParser::Dot)) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__postfixExpression_8Context ------------------------------------------------------------------

PnfCParser::Altnt_block__postfixExpression_8Context::Altnt_block__postfixExpression_8Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Optional__primaryExpression_2Context* PnfCParser::Altnt_block__postfixExpression_8Context::optional__primaryExpression_2() {
  return getRuleContext<PnfCParser::Optional__primaryExpression_2Context>(0);
}

tree::TerminalNode* PnfCParser::Altnt_block__postfixExpression_8Context::LeftParen() {
  return getToken(PnfCParser::LeftParen, 0);
}

PnfCParser::TypeNameContext* PnfCParser::Altnt_block__postfixExpression_8Context::typeName() {
  return getRuleContext<PnfCParser::TypeNameContext>(0);
}

tree::TerminalNode* PnfCParser::Altnt_block__postfixExpression_8Context::RightParen() {
  return getToken(PnfCParser::RightParen, 0);
}

tree::TerminalNode* PnfCParser::Altnt_block__postfixExpression_8Context::LeftBrace() {
  return getToken(PnfCParser::LeftBrace, 0);
}

PnfCParser::InitializerListContext* PnfCParser::Altnt_block__postfixExpression_8Context::initializerList() {
  return getRuleContext<PnfCParser::InitializerListContext>(0);
}

PnfCParser::Optional__postfixExpression_5Context* PnfCParser::Altnt_block__postfixExpression_8Context::optional__postfixExpression_5() {
  return getRuleContext<PnfCParser::Optional__postfixExpression_5Context>(0);
}


size_t PnfCParser::Altnt_block__postfixExpression_8Context::getRuleIndex() const {
  return PnfCParser::RuleAltnt_block__postfixExpression_8;
}

void PnfCParser::Altnt_block__postfixExpression_8Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__postfixExpression_8(this);
}

void PnfCParser::Altnt_block__postfixExpression_8Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__postfixExpression_8(this);
}


antlrcpp::Any PnfCParser::Altnt_block__postfixExpression_8Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__postfixExpression_8(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Altnt_block__postfixExpression_8Context* PnfCParser::altnt_block__postfixExpression_8() {
  Altnt_block__postfixExpression_8Context *_localctx = _tracker.createInstance<Altnt_block__postfixExpression_8Context>(_ctx, getState());
  enterRule(_localctx, 348, PnfCParser::RuleAltnt_block__postfixExpression_8);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1204);
    optional__primaryExpression_2();
    setState(1205);
    match(PnfCParser::LeftParen);
    setState(1206);
    typeName();
    setState(1207);
    match(PnfCParser::RightParen);
    setState(1208);
    match(PnfCParser::LeftBrace);
    setState(1209);
    initializerList();
    setState(1210);
    optional__postfixExpression_5();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__multiplicativeExpression_3Context ------------------------------------------------------------------

PnfCParser::Altnt_block__multiplicativeExpression_3Context::Altnt_block__multiplicativeExpression_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Altnt_block__multiplicativeExpression_3Context::Star() {
  return getToken(PnfCParser::Star, 0);
}

tree::TerminalNode* PnfCParser::Altnt_block__multiplicativeExpression_3Context::Div() {
  return getToken(PnfCParser::Div, 0);
}

tree::TerminalNode* PnfCParser::Altnt_block__multiplicativeExpression_3Context::Mod() {
  return getToken(PnfCParser::Mod, 0);
}


size_t PnfCParser::Altnt_block__multiplicativeExpression_3Context::getRuleIndex() const {
  return PnfCParser::RuleAltnt_block__multiplicativeExpression_3;
}

void PnfCParser::Altnt_block__multiplicativeExpression_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__multiplicativeExpression_3(this);
}

void PnfCParser::Altnt_block__multiplicativeExpression_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__multiplicativeExpression_3(this);
}


antlrcpp::Any PnfCParser::Altnt_block__multiplicativeExpression_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__multiplicativeExpression_3(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Altnt_block__multiplicativeExpression_3Context* PnfCParser::altnt_block__multiplicativeExpression_3() {
  Altnt_block__multiplicativeExpression_3Context *_localctx = _tracker.createInstance<Altnt_block__multiplicativeExpression_3Context>(_ctx, getState());
  enterRule(_localctx, 350, PnfCParser::RuleAltnt_block__multiplicativeExpression_3);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1212);
    _la = _input->LA(1);
    if (!(((((_la - 82) & ~ 0x3fULL) == 0) &&
      ((1ULL << (_la - 82)) & ((1ULL << (PnfCParser::Star - 82))
      | (1ULL << (PnfCParser::Div - 82))
      | (1ULL << (PnfCParser::Mod - 82)))) != 0))) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__additiveExpression_3Context ------------------------------------------------------------------

PnfCParser::Altnt_block__additiveExpression_3Context::Altnt_block__additiveExpression_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Altnt_block__additiveExpression_3Context::Plus() {
  return getToken(PnfCParser::Plus, 0);
}

tree::TerminalNode* PnfCParser::Altnt_block__additiveExpression_3Context::Minus() {
  return getToken(PnfCParser::Minus, 0);
}


size_t PnfCParser::Altnt_block__additiveExpression_3Context::getRuleIndex() const {
  return PnfCParser::RuleAltnt_block__additiveExpression_3;
}

void PnfCParser::Altnt_block__additiveExpression_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__additiveExpression_3(this);
}

void PnfCParser::Altnt_block__additiveExpression_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__additiveExpression_3(this);
}


antlrcpp::Any PnfCParser::Altnt_block__additiveExpression_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__additiveExpression_3(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Altnt_block__additiveExpression_3Context* PnfCParser::altnt_block__additiveExpression_3() {
  Altnt_block__additiveExpression_3Context *_localctx = _tracker.createInstance<Altnt_block__additiveExpression_3Context>(_ctx, getState());
  enterRule(_localctx, 352, PnfCParser::RuleAltnt_block__additiveExpression_3);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1214);
    _la = _input->LA(1);
    if (!(_la == PnfCParser::Plus

    || _la == PnfCParser::Minus)) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__shiftExpression_3Context ------------------------------------------------------------------

PnfCParser::Altnt_block__shiftExpression_3Context::Altnt_block__shiftExpression_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Altnt_block__shiftExpression_3Context::LeftShift() {
  return getToken(PnfCParser::LeftShift, 0);
}

tree::TerminalNode* PnfCParser::Altnt_block__shiftExpression_3Context::RightShift() {
  return getToken(PnfCParser::RightShift, 0);
}


size_t PnfCParser::Altnt_block__shiftExpression_3Context::getRuleIndex() const {
  return PnfCParser::RuleAltnt_block__shiftExpression_3;
}

void PnfCParser::Altnt_block__shiftExpression_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__shiftExpression_3(this);
}

void PnfCParser::Altnt_block__shiftExpression_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__shiftExpression_3(this);
}


antlrcpp::Any PnfCParser::Altnt_block__shiftExpression_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__shiftExpression_3(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Altnt_block__shiftExpression_3Context* PnfCParser::altnt_block__shiftExpression_3() {
  Altnt_block__shiftExpression_3Context *_localctx = _tracker.createInstance<Altnt_block__shiftExpression_3Context>(_ctx, getState());
  enterRule(_localctx, 354, PnfCParser::RuleAltnt_block__shiftExpression_3);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1216);
    _la = _input->LA(1);
    if (!(_la == PnfCParser::LeftShift

    || _la == PnfCParser::RightShift)) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__relationalExpression_3Context ------------------------------------------------------------------

PnfCParser::Altnt_block__relationalExpression_3Context::Altnt_block__relationalExpression_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Altnt_block__relationalExpression_3Context::Less() {
  return getToken(PnfCParser::Less, 0);
}

tree::TerminalNode* PnfCParser::Altnt_block__relationalExpression_3Context::Greater() {
  return getToken(PnfCParser::Greater, 0);
}

tree::TerminalNode* PnfCParser::Altnt_block__relationalExpression_3Context::LessEqual() {
  return getToken(PnfCParser::LessEqual, 0);
}

tree::TerminalNode* PnfCParser::Altnt_block__relationalExpression_3Context::GreaterEqual() {
  return getToken(PnfCParser::GreaterEqual, 0);
}


size_t PnfCParser::Altnt_block__relationalExpression_3Context::getRuleIndex() const {
  return PnfCParser::RuleAltnt_block__relationalExpression_3;
}

void PnfCParser::Altnt_block__relationalExpression_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__relationalExpression_3(this);
}

void PnfCParser::Altnt_block__relationalExpression_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__relationalExpression_3(this);
}


antlrcpp::Any PnfCParser::Altnt_block__relationalExpression_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__relationalExpression_3(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Altnt_block__relationalExpression_3Context* PnfCParser::altnt_block__relationalExpression_3() {
  Altnt_block__relationalExpression_3Context *_localctx = _tracker.createInstance<Altnt_block__relationalExpression_3Context>(_ctx, getState());
  enterRule(_localctx, 356, PnfCParser::RuleAltnt_block__relationalExpression_3);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1218);
    _la = _input->LA(1);
    if (!(((((_la - 72) & ~ 0x3fULL) == 0) &&
      ((1ULL << (_la - 72)) & ((1ULL << (PnfCParser::Less - 72))
      | (1ULL << (PnfCParser::LessEqual - 72))
      | (1ULL << (PnfCParser::Greater - 72))
      | (1ULL << (PnfCParser::GreaterEqual - 72)))) != 0))) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__equalityExpression_3Context ------------------------------------------------------------------

PnfCParser::Altnt_block__equalityExpression_3Context::Altnt_block__equalityExpression_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Altnt_block__equalityExpression_3Context::Equal() {
  return getToken(PnfCParser::Equal, 0);
}

tree::TerminalNode* PnfCParser::Altnt_block__equalityExpression_3Context::NotEqual() {
  return getToken(PnfCParser::NotEqual, 0);
}


size_t PnfCParser::Altnt_block__equalityExpression_3Context::getRuleIndex() const {
  return PnfCParser::RuleAltnt_block__equalityExpression_3;
}

void PnfCParser::Altnt_block__equalityExpression_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__equalityExpression_3(this);
}

void PnfCParser::Altnt_block__equalityExpression_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__equalityExpression_3(this);
}


antlrcpp::Any PnfCParser::Altnt_block__equalityExpression_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__equalityExpression_3(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Altnt_block__equalityExpression_3Context* PnfCParser::altnt_block__equalityExpression_3() {
  Altnt_block__equalityExpression_3Context *_localctx = _tracker.createInstance<Altnt_block__equalityExpression_3Context>(_ctx, getState());
  enterRule(_localctx, 358, PnfCParser::RuleAltnt_block__equalityExpression_3);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1220);
    _la = _input->LA(1);
    if (!(_la == PnfCParser::Equal

    || _la == PnfCParser::NotEqual)) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__typeSpecifier_1Context ------------------------------------------------------------------

PnfCParser::Altnt_block__typeSpecifier_1Context::Altnt_block__typeSpecifier_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Aux_rule__typeSpecifier_4Context* PnfCParser::Altnt_block__typeSpecifier_1Context::aux_rule__typeSpecifier_4() {
  return getRuleContext<PnfCParser::Aux_rule__typeSpecifier_4Context>(0);
}

PnfCParser::Aux_rule__typeSpecifier_5Context* PnfCParser::Altnt_block__typeSpecifier_1Context::aux_rule__typeSpecifier_5() {
  return getRuleContext<PnfCParser::Aux_rule__typeSpecifier_5Context>(0);
}


size_t PnfCParser::Altnt_block__typeSpecifier_1Context::getRuleIndex() const {
  return PnfCParser::RuleAltnt_block__typeSpecifier_1;
}

void PnfCParser::Altnt_block__typeSpecifier_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__typeSpecifier_1(this);
}

void PnfCParser::Altnt_block__typeSpecifier_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__typeSpecifier_1(this);
}


antlrcpp::Any PnfCParser::Altnt_block__typeSpecifier_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__typeSpecifier_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Altnt_block__typeSpecifier_1Context* PnfCParser::altnt_block__typeSpecifier_1() {
  Altnt_block__typeSpecifier_1Context *_localctx = _tracker.createInstance<Altnt_block__typeSpecifier_1Context>(_ctx, getState());
  enterRule(_localctx, 360, PnfCParser::RuleAltnt_block__typeSpecifier_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1224);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case PnfCParser::Extension_gcc: {
        enterOuterAlt(_localctx, 1);
        setState(1222);
        aux_rule__typeSpecifier_4();
        break;
      }

      case PnfCParser::T__12: {
        enterOuterAlt(_localctx, 2);
        setState(1223);
        aux_rule__typeSpecifier_5();
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__alignmentSpecifier_1Context ------------------------------------------------------------------

PnfCParser::Altnt_block__alignmentSpecifier_1Context::Altnt_block__alignmentSpecifier_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::TypeNameContext* PnfCParser::Altnt_block__alignmentSpecifier_1Context::typeName() {
  return getRuleContext<PnfCParser::TypeNameContext>(0);
}

PnfCParser::ConstantExpressionContext* PnfCParser::Altnt_block__alignmentSpecifier_1Context::constantExpression() {
  return getRuleContext<PnfCParser::ConstantExpressionContext>(0);
}


size_t PnfCParser::Altnt_block__alignmentSpecifier_1Context::getRuleIndex() const {
  return PnfCParser::RuleAltnt_block__alignmentSpecifier_1;
}

void PnfCParser::Altnt_block__alignmentSpecifier_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__alignmentSpecifier_1(this);
}

void PnfCParser::Altnt_block__alignmentSpecifier_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__alignmentSpecifier_1(this);
}


antlrcpp::Any PnfCParser::Altnt_block__alignmentSpecifier_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__alignmentSpecifier_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Altnt_block__alignmentSpecifier_1Context* PnfCParser::altnt_block__alignmentSpecifier_1() {
  Altnt_block__alignmentSpecifier_1Context *_localctx = _tracker.createInstance<Altnt_block__alignmentSpecifier_1Context>(_ctx, getState());
  enterRule(_localctx, 362, PnfCParser::RuleAltnt_block__alignmentSpecifier_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1228);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 81, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(1226);
      typeName();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(1227);
      constantExpression();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__structOrUnionSpecifier_2Context ------------------------------------------------------------------

PnfCParser::Altnt_block__structOrUnionSpecifier_2Context::Altnt_block__structOrUnionSpecifier_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Aux_rule__structOrUnionSpecifier_3Context* PnfCParser::Altnt_block__structOrUnionSpecifier_2Context::aux_rule__structOrUnionSpecifier_3() {
  return getRuleContext<PnfCParser::Aux_rule__structOrUnionSpecifier_3Context>(0);
}

tree::TerminalNode* PnfCParser::Altnt_block__structOrUnionSpecifier_2Context::Identifier() {
  return getToken(PnfCParser::Identifier, 0);
}


size_t PnfCParser::Altnt_block__structOrUnionSpecifier_2Context::getRuleIndex() const {
  return PnfCParser::RuleAltnt_block__structOrUnionSpecifier_2;
}

void PnfCParser::Altnt_block__structOrUnionSpecifier_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__structOrUnionSpecifier_2(this);
}

void PnfCParser::Altnt_block__structOrUnionSpecifier_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__structOrUnionSpecifier_2(this);
}


antlrcpp::Any PnfCParser::Altnt_block__structOrUnionSpecifier_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__structOrUnionSpecifier_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Altnt_block__structOrUnionSpecifier_2Context* PnfCParser::altnt_block__structOrUnionSpecifier_2() {
  Altnt_block__structOrUnionSpecifier_2Context *_localctx = _tracker.createInstance<Altnt_block__structOrUnionSpecifier_2Context>(_ctx, getState());
  enterRule(_localctx, 364, PnfCParser::RuleAltnt_block__structOrUnionSpecifier_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1232);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 82, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(1230);
      aux_rule__structOrUnionSpecifier_3();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(1231);
      match(PnfCParser::Identifier);
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__enumSpecifier_3Context ------------------------------------------------------------------

PnfCParser::Altnt_block__enumSpecifier_3Context::Altnt_block__enumSpecifier_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Altnt_block__enumSpecifier_3Context::Identifier() {
  return getToken(PnfCParser::Identifier, 0);
}

PnfCParser::Aux_rule__enumSpecifier_6Context* PnfCParser::Altnt_block__enumSpecifier_3Context::aux_rule__enumSpecifier_6() {
  return getRuleContext<PnfCParser::Aux_rule__enumSpecifier_6Context>(0);
}


size_t PnfCParser::Altnt_block__enumSpecifier_3Context::getRuleIndex() const {
  return PnfCParser::RuleAltnt_block__enumSpecifier_3;
}

void PnfCParser::Altnt_block__enumSpecifier_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__enumSpecifier_3(this);
}

void PnfCParser::Altnt_block__enumSpecifier_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__enumSpecifier_3(this);
}


antlrcpp::Any PnfCParser::Altnt_block__enumSpecifier_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__enumSpecifier_3(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Altnt_block__enumSpecifier_3Context* PnfCParser::altnt_block__enumSpecifier_3() {
  Altnt_block__enumSpecifier_3Context *_localctx = _tracker.createInstance<Altnt_block__enumSpecifier_3Context>(_ctx, getState());
  enterRule(_localctx, 366, PnfCParser::RuleAltnt_block__enumSpecifier_3);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1236);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 83, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(1234);
      match(PnfCParser::Identifier);
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(1235);
      aux_rule__enumSpecifier_6();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__pointer_5Context ------------------------------------------------------------------

PnfCParser::Altnt_block__pointer_5Context::Altnt_block__pointer_5Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Optional__pointer_1Context* PnfCParser::Altnt_block__pointer_5Context::optional__pointer_1() {
  return getRuleContext<PnfCParser::Optional__pointer_1Context>(0);
}

PnfCParser::Optional__declarator_1Context* PnfCParser::Altnt_block__pointer_5Context::optional__declarator_1() {
  return getRuleContext<PnfCParser::Optional__declarator_1Context>(0);
}


size_t PnfCParser::Altnt_block__pointer_5Context::getRuleIndex() const {
  return PnfCParser::RuleAltnt_block__pointer_5;
}

void PnfCParser::Altnt_block__pointer_5Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__pointer_5(this);
}

void PnfCParser::Altnt_block__pointer_5Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__pointer_5(this);
}


antlrcpp::Any PnfCParser::Altnt_block__pointer_5Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__pointer_5(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Altnt_block__pointer_5Context* PnfCParser::altnt_block__pointer_5() {
  Altnt_block__pointer_5Context *_localctx = _tracker.createInstance<Altnt_block__pointer_5Context>(_ctx, getState());
  enterRule(_localctx, 368, PnfCParser::RuleAltnt_block__pointer_5);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1238);
    optional__pointer_1();
    setState(1239);
    optional__declarator_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__directDeclarator_9Context ------------------------------------------------------------------

PnfCParser::Altnt_block__directDeclarator_9Context::Altnt_block__directDeclarator_9Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Aux_rule__directDeclarator_16Context* PnfCParser::Altnt_block__directDeclarator_9Context::aux_rule__directDeclarator_16() {
  return getRuleContext<PnfCParser::Aux_rule__directDeclarator_16Context>(0);
}

PnfCParser::Aux_rule__directDeclarator_17Context* PnfCParser::Altnt_block__directDeclarator_9Context::aux_rule__directDeclarator_17() {
  return getRuleContext<PnfCParser::Aux_rule__directDeclarator_17Context>(0);
}


size_t PnfCParser::Altnt_block__directDeclarator_9Context::getRuleIndex() const {
  return PnfCParser::RuleAltnt_block__directDeclarator_9;
}

void PnfCParser::Altnt_block__directDeclarator_9Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__directDeclarator_9(this);
}

void PnfCParser::Altnt_block__directDeclarator_9Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__directDeclarator_9(this);
}


antlrcpp::Any PnfCParser::Altnt_block__directDeclarator_9Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__directDeclarator_9(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Altnt_block__directDeclarator_9Context* PnfCParser::altnt_block__directDeclarator_9() {
  Altnt_block__directDeclarator_9Context *_localctx = _tracker.createInstance<Altnt_block__directDeclarator_9Context>(_ctx, getState());
  enterRule(_localctx, 370, PnfCParser::RuleAltnt_block__directDeclarator_9);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1243);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 84, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(1241);
      aux_rule__directDeclarator_16();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(1242);
      aux_rule__directDeclarator_17();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__directDeclarator_10Context ------------------------------------------------------------------

PnfCParser::Altnt_block__directDeclarator_10Context::Altnt_block__directDeclarator_10Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::ParameterTypeListContext* PnfCParser::Altnt_block__directDeclarator_10Context::parameterTypeList() {
  return getRuleContext<PnfCParser::ParameterTypeListContext>(0);
}

PnfCParser::Optional__directDeclarator_5Context* PnfCParser::Altnt_block__directDeclarator_10Context::optional__directDeclarator_5() {
  return getRuleContext<PnfCParser::Optional__directDeclarator_5Context>(0);
}


size_t PnfCParser::Altnt_block__directDeclarator_10Context::getRuleIndex() const {
  return PnfCParser::RuleAltnt_block__directDeclarator_10;
}

void PnfCParser::Altnt_block__directDeclarator_10Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__directDeclarator_10(this);
}

void PnfCParser::Altnt_block__directDeclarator_10Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__directDeclarator_10(this);
}


antlrcpp::Any PnfCParser::Altnt_block__directDeclarator_10Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__directDeclarator_10(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Altnt_block__directDeclarator_10Context* PnfCParser::altnt_block__directDeclarator_10() {
  Altnt_block__directDeclarator_10Context *_localctx = _tracker.createInstance<Altnt_block__directDeclarator_10Context>(_ctx, getState());
  enterRule(_localctx, 372, PnfCParser::RuleAltnt_block__directDeclarator_10);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1247);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 85, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(1245);
      parameterTypeList();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(1246);
      optional__directDeclarator_5();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__directAbstractDeclarator_15Context ------------------------------------------------------------------

PnfCParser::Altnt_block__directAbstractDeclarator_15Context::Altnt_block__directAbstractDeclarator_15Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Aux_rule__directAbstractDeclarator_25Context* PnfCParser::Altnt_block__directAbstractDeclarator_15Context::aux_rule__directAbstractDeclarator_25() {
  return getRuleContext<PnfCParser::Aux_rule__directAbstractDeclarator_25Context>(0);
}

tree::TerminalNode* PnfCParser::Altnt_block__directAbstractDeclarator_15Context::Star() {
  return getToken(PnfCParser::Star, 0);
}

PnfCParser::Aux_rule__directAbstractDeclarator_26Context* PnfCParser::Altnt_block__directAbstractDeclarator_15Context::aux_rule__directAbstractDeclarator_26() {
  return getRuleContext<PnfCParser::Aux_rule__directAbstractDeclarator_26Context>(0);
}


size_t PnfCParser::Altnt_block__directAbstractDeclarator_15Context::getRuleIndex() const {
  return PnfCParser::RuleAltnt_block__directAbstractDeclarator_15;
}

void PnfCParser::Altnt_block__directAbstractDeclarator_15Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__directAbstractDeclarator_15(this);
}

void PnfCParser::Altnt_block__directAbstractDeclarator_15Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__directAbstractDeclarator_15(this);
}


antlrcpp::Any PnfCParser::Altnt_block__directAbstractDeclarator_15Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__directAbstractDeclarator_15(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Altnt_block__directAbstractDeclarator_15Context* PnfCParser::altnt_block__directAbstractDeclarator_15() {
  Altnt_block__directAbstractDeclarator_15Context *_localctx = _tracker.createInstance<Altnt_block__directAbstractDeclarator_15Context>(_ctx, getState());
  enterRule(_localctx, 374, PnfCParser::RuleAltnt_block__directAbstractDeclarator_15);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1252);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 86, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(1249);
      aux_rule__directAbstractDeclarator_25();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(1250);
      match(PnfCParser::Star);
      break;
    }

    case 3: {
      enterOuterAlt(_localctx, 3);
      setState(1251);
      aux_rule__directAbstractDeclarator_26();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__directAbstractDeclarator_17Context ------------------------------------------------------------------

PnfCParser::Altnt_block__directAbstractDeclarator_17Context::Altnt_block__directAbstractDeclarator_17Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Altnt_block__directAbstractDeclarator_20Context* PnfCParser::Altnt_block__directAbstractDeclarator_17Context::altnt_block__directAbstractDeclarator_20() {
  return getRuleContext<PnfCParser::Altnt_block__directAbstractDeclarator_20Context>(0);
}

tree::TerminalNode* PnfCParser::Altnt_block__directAbstractDeclarator_17Context::RightParen() {
  return getToken(PnfCParser::RightParen, 0);
}

PnfCParser::Kleene_star__declarator_2Context* PnfCParser::Altnt_block__directAbstractDeclarator_17Context::kleene_star__declarator_2() {
  return getRuleContext<PnfCParser::Kleene_star__declarator_2Context>(0);
}


size_t PnfCParser::Altnt_block__directAbstractDeclarator_17Context::getRuleIndex() const {
  return PnfCParser::RuleAltnt_block__directAbstractDeclarator_17;
}

void PnfCParser::Altnt_block__directAbstractDeclarator_17Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__directAbstractDeclarator_17(this);
}

void PnfCParser::Altnt_block__directAbstractDeclarator_17Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__directAbstractDeclarator_17(this);
}


antlrcpp::Any PnfCParser::Altnt_block__directAbstractDeclarator_17Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__directAbstractDeclarator_17(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Altnt_block__directAbstractDeclarator_17Context* PnfCParser::altnt_block__directAbstractDeclarator_17() {
  Altnt_block__directAbstractDeclarator_17Context *_localctx = _tracker.createInstance<Altnt_block__directAbstractDeclarator_17Context>(_ctx, getState());
  enterRule(_localctx, 376, PnfCParser::RuleAltnt_block__directAbstractDeclarator_17);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1254);
    altnt_block__directAbstractDeclarator_20();
    setState(1255);
    match(PnfCParser::RightParen);
    setState(1256);
    kleene_star__declarator_2();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__labeledStatement_1Context ------------------------------------------------------------------

PnfCParser::Altnt_block__labeledStatement_1Context::Altnt_block__labeledStatement_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Altnt_block__labeledStatement_1Context::Identifier() {
  return getToken(PnfCParser::Identifier, 0);
}

PnfCParser::Aux_rule__labeledStatement_2Context* PnfCParser::Altnt_block__labeledStatement_1Context::aux_rule__labeledStatement_2() {
  return getRuleContext<PnfCParser::Aux_rule__labeledStatement_2Context>(0);
}

tree::TerminalNode* PnfCParser::Altnt_block__labeledStatement_1Context::Default() {
  return getToken(PnfCParser::Default, 0);
}


size_t PnfCParser::Altnt_block__labeledStatement_1Context::getRuleIndex() const {
  return PnfCParser::RuleAltnt_block__labeledStatement_1;
}

void PnfCParser::Altnt_block__labeledStatement_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__labeledStatement_1(this);
}

void PnfCParser::Altnt_block__labeledStatement_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__labeledStatement_1(this);
}


antlrcpp::Any PnfCParser::Altnt_block__labeledStatement_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__labeledStatement_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Altnt_block__labeledStatement_1Context* PnfCParser::altnt_block__labeledStatement_1() {
  Altnt_block__labeledStatement_1Context *_localctx = _tracker.createInstance<Altnt_block__labeledStatement_1Context>(_ctx, getState());
  enterRule(_localctx, 378, PnfCParser::RuleAltnt_block__labeledStatement_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1261);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case PnfCParser::Identifier: {
        enterOuterAlt(_localctx, 1);
        setState(1258);
        match(PnfCParser::Identifier);
        break;
      }

      case PnfCParser::Case: {
        enterOuterAlt(_localctx, 2);
        setState(1259);
        aux_rule__labeledStatement_2();
        break;
      }

      case PnfCParser::Default: {
        enterOuterAlt(_localctx, 3);
        setState(1260);
        match(PnfCParser::Default);
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__jumpStatement_2Context ------------------------------------------------------------------

PnfCParser::Altnt_block__jumpStatement_2Context::Altnt_block__jumpStatement_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Altnt_block__jumpStatement_2Context::Continue() {
  return getToken(PnfCParser::Continue, 0);
}

tree::TerminalNode* PnfCParser::Altnt_block__jumpStatement_2Context::Break() {
  return getToken(PnfCParser::Break, 0);
}

PnfCParser::Aux_rule__jumpStatement_4Context* PnfCParser::Altnt_block__jumpStatement_2Context::aux_rule__jumpStatement_4() {
  return getRuleContext<PnfCParser::Aux_rule__jumpStatement_4Context>(0);
}

PnfCParser::Aux_rule__jumpStatement_5Context* PnfCParser::Altnt_block__jumpStatement_2Context::aux_rule__jumpStatement_5() {
  return getRuleContext<PnfCParser::Aux_rule__jumpStatement_5Context>(0);
}


size_t PnfCParser::Altnt_block__jumpStatement_2Context::getRuleIndex() const {
  return PnfCParser::RuleAltnt_block__jumpStatement_2;
}

void PnfCParser::Altnt_block__jumpStatement_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__jumpStatement_2(this);
}

void PnfCParser::Altnt_block__jumpStatement_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__jumpStatement_2(this);
}


antlrcpp::Any PnfCParser::Altnt_block__jumpStatement_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__jumpStatement_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Altnt_block__jumpStatement_2Context* PnfCParser::altnt_block__jumpStatement_2() {
  Altnt_block__jumpStatement_2Context *_localctx = _tracker.createInstance<Altnt_block__jumpStatement_2Context>(_ctx, getState());
  enterRule(_localctx, 380, PnfCParser::RuleAltnt_block__jumpStatement_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1267);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case PnfCParser::Continue: {
        enterOuterAlt(_localctx, 1);
        setState(1263);
        match(PnfCParser::Continue);
        break;
      }

      case PnfCParser::Break: {
        enterOuterAlt(_localctx, 2);
        setState(1264);
        match(PnfCParser::Break);
        break;
      }

      case PnfCParser::Return: {
        enterOuterAlt(_localctx, 3);
        setState(1265);
        aux_rule__jumpStatement_4();
        break;
      }

      case PnfCParser::Goto: {
        enterOuterAlt(_localctx, 4);
        setState(1266);
        aux_rule__jumpStatement_5();
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__enumSpecifier_4Context ------------------------------------------------------------------

PnfCParser::Altnt_block__enumSpecifier_4Context::Altnt_block__enumSpecifier_4Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Optional__structOrUnionSpecifier_1Context* PnfCParser::Altnt_block__enumSpecifier_4Context::optional__structOrUnionSpecifier_1() {
  return getRuleContext<PnfCParser::Optional__structOrUnionSpecifier_1Context>(0);
}

tree::TerminalNode* PnfCParser::Altnt_block__enumSpecifier_4Context::LeftBrace() {
  return getToken(PnfCParser::LeftBrace, 0);
}

PnfCParser::EnumeratorListContext* PnfCParser::Altnt_block__enumSpecifier_4Context::enumeratorList() {
  return getRuleContext<PnfCParser::EnumeratorListContext>(0);
}

PnfCParser::Optional__postfixExpression_5Context* PnfCParser::Altnt_block__enumSpecifier_4Context::optional__postfixExpression_5() {
  return getRuleContext<PnfCParser::Optional__postfixExpression_5Context>(0);
}


size_t PnfCParser::Altnt_block__enumSpecifier_4Context::getRuleIndex() const {
  return PnfCParser::RuleAltnt_block__enumSpecifier_4;
}

void PnfCParser::Altnt_block__enumSpecifier_4Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__enumSpecifier_4(this);
}

void PnfCParser::Altnt_block__enumSpecifier_4Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__enumSpecifier_4(this);
}


antlrcpp::Any PnfCParser::Altnt_block__enumSpecifier_4Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__enumSpecifier_4(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Altnt_block__enumSpecifier_4Context* PnfCParser::altnt_block__enumSpecifier_4() {
  Altnt_block__enumSpecifier_4Context *_localctx = _tracker.createInstance<Altnt_block__enumSpecifier_4Context>(_ctx, getState());
  enterRule(_localctx, 382, PnfCParser::RuleAltnt_block__enumSpecifier_4);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1269);
    optional__structOrUnionSpecifier_1();
    setState(1270);
    match(PnfCParser::LeftBrace);
    setState(1271);
    enumeratorList();
    setState(1272);
    optional__postfixExpression_5();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__directDeclarator_11Context ------------------------------------------------------------------

PnfCParser::Altnt_block__directDeclarator_11Context::Altnt_block__directDeclarator_11Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Aux_rule__directDeclarator_18Context* PnfCParser::Altnt_block__directDeclarator_11Context::aux_rule__directDeclarator_18() {
  return getRuleContext<PnfCParser::Aux_rule__directDeclarator_18Context>(0);
}

PnfCParser::Aux_rule__directDeclarator_19Context* PnfCParser::Altnt_block__directDeclarator_11Context::aux_rule__directDeclarator_19() {
  return getRuleContext<PnfCParser::Aux_rule__directDeclarator_19Context>(0);
}


size_t PnfCParser::Altnt_block__directDeclarator_11Context::getRuleIndex() const {
  return PnfCParser::RuleAltnt_block__directDeclarator_11;
}

void PnfCParser::Altnt_block__directDeclarator_11Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__directDeclarator_11(this);
}

void PnfCParser::Altnt_block__directDeclarator_11Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__directDeclarator_11(this);
}


antlrcpp::Any PnfCParser::Altnt_block__directDeclarator_11Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__directDeclarator_11(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Altnt_block__directDeclarator_11Context* PnfCParser::altnt_block__directDeclarator_11() {
  Altnt_block__directDeclarator_11Context *_localctx = _tracker.createInstance<Altnt_block__directDeclarator_11Context>(_ctx, getState());
  enterRule(_localctx, 384, PnfCParser::RuleAltnt_block__directDeclarator_11);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1276);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case PnfCParser::Static: {
        enterOuterAlt(_localctx, 1);
        setState(1274);
        aux_rule__directDeclarator_18();
        break;
      }

      case PnfCParser::Const:
      case PnfCParser::Nonnull:
      case PnfCParser::Nullable:
      case PnfCParser::Restrict:
      case PnfCParser::Restrict_gcc:
      case PnfCParser::Restrict_gcc2:
      case PnfCParser::Volatile:
      case PnfCParser::Atomic: {
        enterOuterAlt(_localctx, 2);
        setState(1275);
        aux_rule__directDeclarator_19();
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__iterationStatement_7Context ------------------------------------------------------------------

PnfCParser::Altnt_block__iterationStatement_7Context::Altnt_block__iterationStatement_7Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Altnt_block__iterationStatement_8Context* PnfCParser::Altnt_block__iterationStatement_7Context::altnt_block__iterationStatement_8() {
  return getRuleContext<PnfCParser::Altnt_block__iterationStatement_8Context>(0);
}

std::vector<PnfCParser::Optional__postfixExpression_1Context *> PnfCParser::Altnt_block__iterationStatement_7Context::optional__postfixExpression_1() {
  return getRuleContexts<PnfCParser::Optional__postfixExpression_1Context>();
}

PnfCParser::Optional__postfixExpression_1Context* PnfCParser::Altnt_block__iterationStatement_7Context::optional__postfixExpression_1(size_t i) {
  return getRuleContext<PnfCParser::Optional__postfixExpression_1Context>(i);
}

tree::TerminalNode* PnfCParser::Altnt_block__iterationStatement_7Context::Semi() {
  return getToken(PnfCParser::Semi, 0);
}


size_t PnfCParser::Altnt_block__iterationStatement_7Context::getRuleIndex() const {
  return PnfCParser::RuleAltnt_block__iterationStatement_7;
}

void PnfCParser::Altnt_block__iterationStatement_7Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__iterationStatement_7(this);
}

void PnfCParser::Altnt_block__iterationStatement_7Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__iterationStatement_7(this);
}


antlrcpp::Any PnfCParser::Altnt_block__iterationStatement_7Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__iterationStatement_7(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Altnt_block__iterationStatement_7Context* PnfCParser::altnt_block__iterationStatement_7() {
  Altnt_block__iterationStatement_7Context *_localctx = _tracker.createInstance<Altnt_block__iterationStatement_7Context>(_ctx, getState());
  enterRule(_localctx, 386, PnfCParser::RuleAltnt_block__iterationStatement_7);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1278);
    altnt_block__iterationStatement_8();
    setState(1279);
    optional__postfixExpression_1();
    setState(1280);
    match(PnfCParser::Semi);
    setState(1281);
    optional__postfixExpression_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__jumpStatement_3Context ------------------------------------------------------------------

PnfCParser::Altnt_block__jumpStatement_3Context::Altnt_block__jumpStatement_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Altnt_block__jumpStatement_3Context::Identifier() {
  return getToken(PnfCParser::Identifier, 0);
}

PnfCParser::UnaryExpressionContext* PnfCParser::Altnt_block__jumpStatement_3Context::unaryExpression() {
  return getRuleContext<PnfCParser::UnaryExpressionContext>(0);
}


size_t PnfCParser::Altnt_block__jumpStatement_3Context::getRuleIndex() const {
  return PnfCParser::RuleAltnt_block__jumpStatement_3;
}

void PnfCParser::Altnt_block__jumpStatement_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__jumpStatement_3(this);
}

void PnfCParser::Altnt_block__jumpStatement_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__jumpStatement_3(this);
}


antlrcpp::Any PnfCParser::Altnt_block__jumpStatement_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__jumpStatement_3(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Altnt_block__jumpStatement_3Context* PnfCParser::altnt_block__jumpStatement_3() {
  Altnt_block__jumpStatement_3Context *_localctx = _tracker.createInstance<Altnt_block__jumpStatement_3Context>(_ctx, getState());
  enterRule(_localctx, 388, PnfCParser::RuleAltnt_block__jumpStatement_3);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1285);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 90, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(1283);
      match(PnfCParser::Identifier);
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(1284);
      unaryExpression();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__postfixExpression_4Context ------------------------------------------------------------------

PnfCParser::Aux_rule__postfixExpression_4Context::Aux_rule__postfixExpression_4Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__postfixExpression_4Context::Identifier() {
  return getToken(PnfCParser::Identifier, 0);
}

tree::TerminalNode* PnfCParser::Aux_rule__postfixExpression_4Context::Constant() {
  return getToken(PnfCParser::Constant, 0);
}

PnfCParser::Kleene_plus__primaryExpression_1Context* PnfCParser::Aux_rule__postfixExpression_4Context::kleene_plus__primaryExpression_1() {
  return getRuleContext<PnfCParser::Kleene_plus__primaryExpression_1Context>(0);
}

PnfCParser::GenericSelectionContext* PnfCParser::Aux_rule__postfixExpression_4Context::genericSelection() {
  return getRuleContext<PnfCParser::GenericSelectionContext>(0);
}

PnfCParser::Aux_rule__postfixExpression_13Context* PnfCParser::Aux_rule__postfixExpression_4Context::aux_rule__postfixExpression_13() {
  return getRuleContext<PnfCParser::Aux_rule__postfixExpression_13Context>(0);
}

PnfCParser::Aux_rule__postfixExpression_14Context* PnfCParser::Aux_rule__postfixExpression_4Context::aux_rule__postfixExpression_14() {
  return getRuleContext<PnfCParser::Aux_rule__postfixExpression_14Context>(0);
}


size_t PnfCParser::Aux_rule__postfixExpression_4Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__postfixExpression_4;
}

void PnfCParser::Aux_rule__postfixExpression_4Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__postfixExpression_4(this);
}

void PnfCParser::Aux_rule__postfixExpression_4Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__postfixExpression_4(this);
}


antlrcpp::Any PnfCParser::Aux_rule__postfixExpression_4Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__postfixExpression_4(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__postfixExpression_4Context* PnfCParser::aux_rule__postfixExpression_4() {
  Aux_rule__postfixExpression_4Context *_localctx = _tracker.createInstance<Aux_rule__postfixExpression_4Context>(_ctx, getState());
  enterRule(_localctx, 390, PnfCParser::RuleAux_rule__postfixExpression_4);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1293);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 91, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(1287);
      match(PnfCParser::Identifier);
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(1288);
      match(PnfCParser::Constant);
      break;
    }

    case 3: {
      enterOuterAlt(_localctx, 3);
      setState(1289);
      kleene_plus__primaryExpression_1();
      break;
    }

    case 4: {
      enterOuterAlt(_localctx, 4);
      setState(1290);
      genericSelection();
      break;
    }

    case 5: {
      enterOuterAlt(_localctx, 5);
      setState(1291);
      aux_rule__postfixExpression_13();
      break;
    }

    case 6: {
      enterOuterAlt(_localctx, 6);
      setState(1292);
      aux_rule__postfixExpression_14();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- DeclarationSpecifierContext ------------------------------------------------------------------

PnfCParser::DeclarationSpecifierContext::DeclarationSpecifierContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::DeclarationSpecifierContext::Typedef() {
  return getToken(PnfCParser::Typedef, 0);
}

tree::TerminalNode* PnfCParser::DeclarationSpecifierContext::Extern() {
  return getToken(PnfCParser::Extern, 0);
}

tree::TerminalNode* PnfCParser::DeclarationSpecifierContext::Static() {
  return getToken(PnfCParser::Static, 0);
}

tree::TerminalNode* PnfCParser::DeclarationSpecifierContext::ThreadLocal() {
  return getToken(PnfCParser::ThreadLocal, 0);
}

tree::TerminalNode* PnfCParser::DeclarationSpecifierContext::Auto() {
  return getToken(PnfCParser::Auto, 0);
}

tree::TerminalNode* PnfCParser::DeclarationSpecifierContext::Register() {
  return getToken(PnfCParser::Register, 0);
}

PnfCParser::TypeSpecifierContext* PnfCParser::DeclarationSpecifierContext::typeSpecifier() {
  return getRuleContext<PnfCParser::TypeSpecifierContext>(0);
}

PnfCParser::TypeQualifierContext* PnfCParser::DeclarationSpecifierContext::typeQualifier() {
  return getRuleContext<PnfCParser::TypeQualifierContext>(0);
}

tree::TerminalNode* PnfCParser::DeclarationSpecifierContext::Inline() {
  return getToken(PnfCParser::Inline, 0);
}

tree::TerminalNode* PnfCParser::DeclarationSpecifierContext::Noreturn() {
  return getToken(PnfCParser::Noreturn, 0);
}

PnfCParser::GccAttributeSpecifierContext* PnfCParser::DeclarationSpecifierContext::gccAttributeSpecifier() {
  return getRuleContext<PnfCParser::GccAttributeSpecifierContext>(0);
}

PnfCParser::Aux_rule__declarationSpecifier_1Context* PnfCParser::DeclarationSpecifierContext::aux_rule__declarationSpecifier_1() {
  return getRuleContext<PnfCParser::Aux_rule__declarationSpecifier_1Context>(0);
}

PnfCParser::AlignmentSpecifierContext* PnfCParser::DeclarationSpecifierContext::alignmentSpecifier() {
  return getRuleContext<PnfCParser::AlignmentSpecifierContext>(0);
}


size_t PnfCParser::DeclarationSpecifierContext::getRuleIndex() const {
  return PnfCParser::RuleDeclarationSpecifier;
}

void PnfCParser::DeclarationSpecifierContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterDeclarationSpecifier(this);
}

void PnfCParser::DeclarationSpecifierContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitDeclarationSpecifier(this);
}


antlrcpp::Any PnfCParser::DeclarationSpecifierContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitDeclarationSpecifier(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::DeclarationSpecifierContext* PnfCParser::declarationSpecifier() {
  DeclarationSpecifierContext *_localctx = _tracker.createInstance<DeclarationSpecifierContext>(_ctx, getState());
  enterRule(_localctx, 392, PnfCParser::RuleDeclarationSpecifier);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1310);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 92, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(1295);
      match(PnfCParser::Typedef);
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(1296);
      match(PnfCParser::Extern);
      break;
    }

    case 3: {
      enterOuterAlt(_localctx, 3);
      setState(1297);
      match(PnfCParser::Static);
      break;
    }

    case 4: {
      enterOuterAlt(_localctx, 4);
      setState(1298);
      match(PnfCParser::ThreadLocal);
      break;
    }

    case 5: {
      enterOuterAlt(_localctx, 5);
      setState(1299);
      match(PnfCParser::Auto);
      break;
    }

    case 6: {
      enterOuterAlt(_localctx, 6);
      setState(1300);
      match(PnfCParser::Register);
      break;
    }

    case 7: {
      enterOuterAlt(_localctx, 7);
      setState(1301);
      typeSpecifier();
      break;
    }

    case 8: {
      enterOuterAlt(_localctx, 8);
      setState(1302);
      typeQualifier();
      break;
    }

    case 9: {
      enterOuterAlt(_localctx, 9);
      setState(1303);
      match(PnfCParser::Inline);
      break;
    }

    case 10: {
      enterOuterAlt(_localctx, 10);
      setState(1304);
      match(PnfCParser::Noreturn);
      break;
    }

    case 11: {
      enterOuterAlt(_localctx, 11);
      setState(1305);
      match(PnfCParser::T__8);
      break;
    }

    case 12: {
      enterOuterAlt(_localctx, 12);
      setState(1306);
      match(PnfCParser::T__9);
      break;
    }

    case 13: {
      enterOuterAlt(_localctx, 13);
      setState(1307);
      gccAttributeSpecifier();
      break;
    }

    case 14: {
      enterOuterAlt(_localctx, 14);
      setState(1308);
      aux_rule__declarationSpecifier_1();
      break;
    }

    case 15: {
      enterOuterAlt(_localctx, 15);
      setState(1309);
      alignmentSpecifier();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__structDeclarationList_2Context ------------------------------------------------------------------

PnfCParser::Aux_rule__structDeclarationList_2Context::Aux_rule__structDeclarationList_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Aux_rule__structDeclarationList_4Context* PnfCParser::Aux_rule__structDeclarationList_2Context::aux_rule__structDeclarationList_4() {
  return getRuleContext<PnfCParser::Aux_rule__structDeclarationList_4Context>(0);
}

PnfCParser::StaticAssertDeclarationContext* PnfCParser::Aux_rule__structDeclarationList_2Context::staticAssertDeclaration() {
  return getRuleContext<PnfCParser::StaticAssertDeclarationContext>(0);
}


size_t PnfCParser::Aux_rule__structDeclarationList_2Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__structDeclarationList_2;
}

void PnfCParser::Aux_rule__structDeclarationList_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__structDeclarationList_2(this);
}

void PnfCParser::Aux_rule__structDeclarationList_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__structDeclarationList_2(this);
}


antlrcpp::Any PnfCParser::Aux_rule__structDeclarationList_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__structDeclarationList_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__structDeclarationList_2Context* PnfCParser::aux_rule__structDeclarationList_2() {
  Aux_rule__structDeclarationList_2Context *_localctx = _tracker.createInstance<Aux_rule__structDeclarationList_2Context>(_ctx, getState());
  enterRule(_localctx, 394, PnfCParser::RuleAux_rule__structDeclarationList_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1314);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case PnfCParser::T__0:
      case PnfCParser::T__1:
      case PnfCParser::T__2:
      case PnfCParser::T__12:
      case PnfCParser::Char:
      case PnfCParser::Const:
      case PnfCParser::Nonnull:
      case PnfCParser::Nullable:
      case PnfCParser::Double:
      case PnfCParser::Enum:
      case PnfCParser::Float:
      case PnfCParser::Int:
      case PnfCParser::Long:
      case PnfCParser::Restrict:
      case PnfCParser::Restrict_gcc:
      case PnfCParser::Restrict_gcc2:
      case PnfCParser::Extension_gcc:
      case PnfCParser::Short:
      case PnfCParser::Signed:
      case PnfCParser::Struct:
      case PnfCParser::Union:
      case PnfCParser::Unsigned:
      case PnfCParser::Void:
      case PnfCParser::Volatile:
      case PnfCParser::Atomic:
      case PnfCParser::Bool:
      case PnfCParser::Complex:
      case PnfCParser::Identifier: {
        enterOuterAlt(_localctx, 1);
        setState(1312);
        aux_rule__structDeclarationList_4();
        break;
      }

      case PnfCParser::StaticAssert: {
        enterOuterAlt(_localctx, 2);
        setState(1313);
        staticAssertDeclaration();
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__designatorList_2Context ------------------------------------------------------------------

PnfCParser::Aux_rule__designatorList_2Context::Aux_rule__designatorList_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Aux_rule__designatorList_4Context* PnfCParser::Aux_rule__designatorList_2Context::aux_rule__designatorList_4() {
  return getRuleContext<PnfCParser::Aux_rule__designatorList_4Context>(0);
}

PnfCParser::Aux_rule__designatorList_5Context* PnfCParser::Aux_rule__designatorList_2Context::aux_rule__designatorList_5() {
  return getRuleContext<PnfCParser::Aux_rule__designatorList_5Context>(0);
}


size_t PnfCParser::Aux_rule__designatorList_2Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__designatorList_2;
}

void PnfCParser::Aux_rule__designatorList_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__designatorList_2(this);
}

void PnfCParser::Aux_rule__designatorList_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__designatorList_2(this);
}


antlrcpp::Any PnfCParser::Aux_rule__designatorList_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__designatorList_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__designatorList_2Context* PnfCParser::aux_rule__designatorList_2() {
  Aux_rule__designatorList_2Context *_localctx = _tracker.createInstance<Aux_rule__designatorList_2Context>(_ctx, getState());
  enterRule(_localctx, 396, PnfCParser::RuleAux_rule__designatorList_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1318);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case PnfCParser::LeftBracket: {
        enterOuterAlt(_localctx, 1);
        setState(1316);
        aux_rule__designatorList_4();
        break;
      }

      case PnfCParser::Dot: {
        enterOuterAlt(_localctx, 2);
        setState(1317);
        aux_rule__designatorList_5();
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- StatementContext ------------------------------------------------------------------

PnfCParser::StatementContext::StatementContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::LabeledStatementContext* PnfCParser::StatementContext::labeledStatement() {
  return getRuleContext<PnfCParser::LabeledStatementContext>(0);
}

PnfCParser::CompoundStatementContext* PnfCParser::StatementContext::compoundStatement() {
  return getRuleContext<PnfCParser::CompoundStatementContext>(0);
}

PnfCParser::ExpressionStatementContext* PnfCParser::StatementContext::expressionStatement() {
  return getRuleContext<PnfCParser::ExpressionStatementContext>(0);
}

PnfCParser::Aux_rule__statement_3Context* PnfCParser::StatementContext::aux_rule__statement_3() {
  return getRuleContext<PnfCParser::Aux_rule__statement_3Context>(0);
}

PnfCParser::Aux_rule__statement_4Context* PnfCParser::StatementContext::aux_rule__statement_4() {
  return getRuleContext<PnfCParser::Aux_rule__statement_4Context>(0);
}

PnfCParser::JumpStatementContext* PnfCParser::StatementContext::jumpStatement() {
  return getRuleContext<PnfCParser::JumpStatementContext>(0);
}

PnfCParser::AsmStatementContext* PnfCParser::StatementContext::asmStatement() {
  return getRuleContext<PnfCParser::AsmStatementContext>(0);
}

PnfCParser::Aux_rule__statement_5Context* PnfCParser::StatementContext::aux_rule__statement_5() {
  return getRuleContext<PnfCParser::Aux_rule__statement_5Context>(0);
}


size_t PnfCParser::StatementContext::getRuleIndex() const {
  return PnfCParser::RuleStatement;
}

void PnfCParser::StatementContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterStatement(this);
}

void PnfCParser::StatementContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitStatement(this);
}


antlrcpp::Any PnfCParser::StatementContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitStatement(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::StatementContext* PnfCParser::statement() {
  StatementContext *_localctx = _tracker.createInstance<StatementContext>(_ctx, getState());
  enterRule(_localctx, 398, PnfCParser::RuleStatement);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1328);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 95, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(1320);
      labeledStatement();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(1321);
      compoundStatement();
      break;
    }

    case 3: {
      enterOuterAlt(_localctx, 3);
      setState(1322);
      expressionStatement();
      break;
    }

    case 4: {
      enterOuterAlt(_localctx, 4);
      setState(1323);
      aux_rule__statement_3();
      break;
    }

    case 5: {
      enterOuterAlt(_localctx, 5);
      setState(1324);
      aux_rule__statement_4();
      break;
    }

    case 6: {
      enterOuterAlt(_localctx, 6);
      setState(1325);
      jumpStatement();
      break;
    }

    case 7: {
      enterOuterAlt(_localctx, 7);
      setState(1326);
      asmStatement();
      break;
    }

    case 8: {
      enterOuterAlt(_localctx, 8);
      setState(1327);
      aux_rule__statement_5();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__blockItemList_2Context ------------------------------------------------------------------

PnfCParser::Aux_rule__blockItemList_2Context::Aux_rule__blockItemList_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::DeclarationContext* PnfCParser::Aux_rule__blockItemList_2Context::declaration() {
  return getRuleContext<PnfCParser::DeclarationContext>(0);
}

PnfCParser::StatementContext* PnfCParser::Aux_rule__blockItemList_2Context::statement() {
  return getRuleContext<PnfCParser::StatementContext>(0);
}


size_t PnfCParser::Aux_rule__blockItemList_2Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__blockItemList_2;
}

void PnfCParser::Aux_rule__blockItemList_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__blockItemList_2(this);
}

void PnfCParser::Aux_rule__blockItemList_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__blockItemList_2(this);
}


antlrcpp::Any PnfCParser::Aux_rule__blockItemList_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__blockItemList_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__blockItemList_2Context* PnfCParser::aux_rule__blockItemList_2() {
  Aux_rule__blockItemList_2Context *_localctx = _tracker.createInstance<Aux_rule__blockItemList_2Context>(_ctx, getState());
  enterRule(_localctx, 400, PnfCParser::RuleAux_rule__blockItemList_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1332);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 96, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(1330);
      declaration();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(1331);
      statement();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__translationUnit_2Context ------------------------------------------------------------------

PnfCParser::Aux_rule__translationUnit_2Context::Aux_rule__translationUnit_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::FunctionDefinitionContext* PnfCParser::Aux_rule__translationUnit_2Context::functionDefinition() {
  return getRuleContext<PnfCParser::FunctionDefinitionContext>(0);
}

PnfCParser::DeclarationContext* PnfCParser::Aux_rule__translationUnit_2Context::declaration() {
  return getRuleContext<PnfCParser::DeclarationContext>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__translationUnit_2Context::IncludeDirective() {
  return getToken(PnfCParser::IncludeDirective, 0);
}

tree::TerminalNode* PnfCParser::Aux_rule__translationUnit_2Context::Semi() {
  return getToken(PnfCParser::Semi, 0);
}


size_t PnfCParser::Aux_rule__translationUnit_2Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__translationUnit_2;
}

void PnfCParser::Aux_rule__translationUnit_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__translationUnit_2(this);
}

void PnfCParser::Aux_rule__translationUnit_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__translationUnit_2(this);
}


antlrcpp::Any PnfCParser::Aux_rule__translationUnit_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__translationUnit_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__translationUnit_2Context* PnfCParser::aux_rule__translationUnit_2() {
  Aux_rule__translationUnit_2Context *_localctx = _tracker.createInstance<Aux_rule__translationUnit_2Context>(_ctx, getState());
  enterRule(_localctx, 402, PnfCParser::RuleAux_rule__translationUnit_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1338);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 97, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(1334);
      functionDefinition();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(1335);
      declaration();
      break;
    }

    case 3: {
      enterOuterAlt(_localctx, 3);
      setState(1336);
      match(PnfCParser::IncludeDirective);
      break;
    }

    case 4: {
      enterOuterAlt(_localctx, 4);
      setState(1337);
      match(PnfCParser::Semi);
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__unaryExpression_3Context ------------------------------------------------------------------

PnfCParser::Altnt_block__unaryExpression_3Context::Altnt_block__unaryExpression_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Altnt_block__unaryExpression_3Context::Alignof() {
  return getToken(PnfCParser::Alignof, 0);
}

tree::TerminalNode* PnfCParser::Altnt_block__unaryExpression_3Context::Alignof_gcc() {
  return getToken(PnfCParser::Alignof_gcc, 0);
}


size_t PnfCParser::Altnt_block__unaryExpression_3Context::getRuleIndex() const {
  return PnfCParser::RuleAltnt_block__unaryExpression_3;
}

void PnfCParser::Altnt_block__unaryExpression_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__unaryExpression_3(this);
}

void PnfCParser::Altnt_block__unaryExpression_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__unaryExpression_3(this);
}


antlrcpp::Any PnfCParser::Altnt_block__unaryExpression_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__unaryExpression_3(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Altnt_block__unaryExpression_3Context* PnfCParser::altnt_block__unaryExpression_3() {
  Altnt_block__unaryExpression_3Context *_localctx = _tracker.createInstance<Altnt_block__unaryExpression_3Context>(_ctx, getState());
  enterRule(_localctx, 404, PnfCParser::RuleAltnt_block__unaryExpression_3);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1340);
    _la = _input->LA(1);
    if (!(_la == PnfCParser::Alignof

    || _la == PnfCParser::Alignof_gcc)) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__unaryExpression_4Context ------------------------------------------------------------------

PnfCParser::Altnt_block__unaryExpression_4Context::Altnt_block__unaryExpression_4Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::TypeNameContext* PnfCParser::Altnt_block__unaryExpression_4Context::typeName() {
  return getRuleContext<PnfCParser::TypeNameContext>(0);
}

PnfCParser::UnaryExpressionContext* PnfCParser::Altnt_block__unaryExpression_4Context::unaryExpression() {
  return getRuleContext<PnfCParser::UnaryExpressionContext>(0);
}


size_t PnfCParser::Altnt_block__unaryExpression_4Context::getRuleIndex() const {
  return PnfCParser::RuleAltnt_block__unaryExpression_4;
}

void PnfCParser::Altnt_block__unaryExpression_4Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__unaryExpression_4(this);
}

void PnfCParser::Altnt_block__unaryExpression_4Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__unaryExpression_4(this);
}


antlrcpp::Any PnfCParser::Altnt_block__unaryExpression_4Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__unaryExpression_4(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Altnt_block__unaryExpression_4Context* PnfCParser::altnt_block__unaryExpression_4() {
  Altnt_block__unaryExpression_4Context *_localctx = _tracker.createInstance<Altnt_block__unaryExpression_4Context>(_ctx, getState());
  enterRule(_localctx, 406, PnfCParser::RuleAltnt_block__unaryExpression_4);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1344);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 98, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(1342);
      typeName();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(1343);
      unaryExpression();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__typeSpecifier_2Context ------------------------------------------------------------------

PnfCParser::Altnt_block__typeSpecifier_2Context::Altnt_block__typeSpecifier_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t PnfCParser::Altnt_block__typeSpecifier_2Context::getRuleIndex() const {
  return PnfCParser::RuleAltnt_block__typeSpecifier_2;
}

void PnfCParser::Altnt_block__typeSpecifier_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__typeSpecifier_2(this);
}

void PnfCParser::Altnt_block__typeSpecifier_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__typeSpecifier_2(this);
}


antlrcpp::Any PnfCParser::Altnt_block__typeSpecifier_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__typeSpecifier_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Altnt_block__typeSpecifier_2Context* PnfCParser::altnt_block__typeSpecifier_2() {
  Altnt_block__typeSpecifier_2Context *_localctx = _tracker.createInstance<Altnt_block__typeSpecifier_2Context>(_ctx, getState());
  enterRule(_localctx, 408, PnfCParser::RuleAltnt_block__typeSpecifier_2);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1346);
    _la = _input->LA(1);
    if (!((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << PnfCParser::T__0)
      | (1ULL << PnfCParser::T__1)
      | (1ULL << PnfCParser::T__2))) != 0))) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__specifierQualifierList_3Context ------------------------------------------------------------------

PnfCParser::Altnt_block__specifierQualifierList_3Context::Altnt_block__specifierQualifierList_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::TypeSpecifierContext* PnfCParser::Altnt_block__specifierQualifierList_3Context::typeSpecifier() {
  return getRuleContext<PnfCParser::TypeSpecifierContext>(0);
}

PnfCParser::TypeQualifierContext* PnfCParser::Altnt_block__specifierQualifierList_3Context::typeQualifier() {
  return getRuleContext<PnfCParser::TypeQualifierContext>(0);
}


size_t PnfCParser::Altnt_block__specifierQualifierList_3Context::getRuleIndex() const {
  return PnfCParser::RuleAltnt_block__specifierQualifierList_3;
}

void PnfCParser::Altnt_block__specifierQualifierList_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__specifierQualifierList_3(this);
}

void PnfCParser::Altnt_block__specifierQualifierList_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__specifierQualifierList_3(this);
}


antlrcpp::Any PnfCParser::Altnt_block__specifierQualifierList_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__specifierQualifierList_3(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Altnt_block__specifierQualifierList_3Context* PnfCParser::altnt_block__specifierQualifierList_3() {
  Altnt_block__specifierQualifierList_3Context *_localctx = _tracker.createInstance<Altnt_block__specifierQualifierList_3Context>(_ctx, getState());
  enterRule(_localctx, 410, PnfCParser::RuleAltnt_block__specifierQualifierList_3);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1350);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 99, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(1348);
      typeSpecifier();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(1349);
      typeQualifier();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__pointer_8Context ------------------------------------------------------------------

PnfCParser::Altnt_block__pointer_8Context::Altnt_block__pointer_8Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Altnt_block__pointer_8Context::Star() {
  return getToken(PnfCParser::Star, 0);
}

tree::TerminalNode* PnfCParser::Altnt_block__pointer_8Context::Caret() {
  return getToken(PnfCParser::Caret, 0);
}


size_t PnfCParser::Altnt_block__pointer_8Context::getRuleIndex() const {
  return PnfCParser::RuleAltnt_block__pointer_8;
}

void PnfCParser::Altnt_block__pointer_8Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__pointer_8(this);
}

void PnfCParser::Altnt_block__pointer_8Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__pointer_8(this);
}


antlrcpp::Any PnfCParser::Altnt_block__pointer_8Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__pointer_8(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Altnt_block__pointer_8Context* PnfCParser::altnt_block__pointer_8() {
  Altnt_block__pointer_8Context *_localctx = _tracker.createInstance<Altnt_block__pointer_8Context>(_ctx, getState());
  enterRule(_localctx, 412, PnfCParser::RuleAltnt_block__pointer_8);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1352);
    _la = _input->LA(1);
    if (!(_la == PnfCParser::Star

    || _la == PnfCParser::Caret)) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__directDeclarator_12Context ------------------------------------------------------------------

PnfCParser::Altnt_block__directDeclarator_12Context::Altnt_block__directDeclarator_12Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Optional__directDeclarator_2Context* PnfCParser::Altnt_block__directDeclarator_12Context::optional__directDeclarator_2() {
  return getRuleContext<PnfCParser::Optional__directDeclarator_2Context>(0);
}

tree::TerminalNode* PnfCParser::Altnt_block__directDeclarator_12Context::Star() {
  return getToken(PnfCParser::Star, 0);
}


size_t PnfCParser::Altnt_block__directDeclarator_12Context::getRuleIndex() const {
  return PnfCParser::RuleAltnt_block__directDeclarator_12;
}

void PnfCParser::Altnt_block__directDeclarator_12Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__directDeclarator_12(this);
}

void PnfCParser::Altnt_block__directDeclarator_12Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__directDeclarator_12(this);
}


antlrcpp::Any PnfCParser::Altnt_block__directDeclarator_12Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__directDeclarator_12(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Altnt_block__directDeclarator_12Context* PnfCParser::altnt_block__directDeclarator_12() {
  Altnt_block__directDeclarator_12Context *_localctx = _tracker.createInstance<Altnt_block__directDeclarator_12Context>(_ctx, getState());
  enterRule(_localctx, 414, PnfCParser::RuleAltnt_block__directDeclarator_12);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1356);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 100, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(1354);
      optional__directDeclarator_2();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(1355);
      match(PnfCParser::Star);
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__parameterDeclaration_2Context ------------------------------------------------------------------

PnfCParser::Altnt_block__parameterDeclaration_2Context::Altnt_block__parameterDeclaration_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::DeclaratorContext* PnfCParser::Altnt_block__parameterDeclaration_2Context::declarator() {
  return getRuleContext<PnfCParser::DeclaratorContext>(0);
}

PnfCParser::Optional__typeName_1Context* PnfCParser::Altnt_block__parameterDeclaration_2Context::optional__typeName_1() {
  return getRuleContext<PnfCParser::Optional__typeName_1Context>(0);
}


size_t PnfCParser::Altnt_block__parameterDeclaration_2Context::getRuleIndex() const {
  return PnfCParser::RuleAltnt_block__parameterDeclaration_2;
}

void PnfCParser::Altnt_block__parameterDeclaration_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__parameterDeclaration_2(this);
}

void PnfCParser::Altnt_block__parameterDeclaration_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__parameterDeclaration_2(this);
}


antlrcpp::Any PnfCParser::Altnt_block__parameterDeclaration_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__parameterDeclaration_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Altnt_block__parameterDeclaration_2Context* PnfCParser::altnt_block__parameterDeclaration_2() {
  Altnt_block__parameterDeclaration_2Context *_localctx = _tracker.createInstance<Altnt_block__parameterDeclaration_2Context>(_ctx, getState());
  enterRule(_localctx, 416, PnfCParser::RuleAltnt_block__parameterDeclaration_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1360);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 101, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(1358);
      declarator();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(1359);
      optional__typeName_1();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__directAbstractDeclarator_20Context ------------------------------------------------------------------

PnfCParser::Altnt_block__directAbstractDeclarator_20Context::Altnt_block__directAbstractDeclarator_20Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::AbstractDeclaratorContext* PnfCParser::Altnt_block__directAbstractDeclarator_20Context::abstractDeclarator() {
  return getRuleContext<PnfCParser::AbstractDeclaratorContext>(0);
}

PnfCParser::Optional__directAbstractDeclarator_5Context* PnfCParser::Altnt_block__directAbstractDeclarator_20Context::optional__directAbstractDeclarator_5() {
  return getRuleContext<PnfCParser::Optional__directAbstractDeclarator_5Context>(0);
}


size_t PnfCParser::Altnt_block__directAbstractDeclarator_20Context::getRuleIndex() const {
  return PnfCParser::RuleAltnt_block__directAbstractDeclarator_20;
}

void PnfCParser::Altnt_block__directAbstractDeclarator_20Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__directAbstractDeclarator_20(this);
}

void PnfCParser::Altnt_block__directAbstractDeclarator_20Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__directAbstractDeclarator_20(this);
}


antlrcpp::Any PnfCParser::Altnt_block__directAbstractDeclarator_20Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__directAbstractDeclarator_20(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Altnt_block__directAbstractDeclarator_20Context* PnfCParser::altnt_block__directAbstractDeclarator_20() {
  Altnt_block__directAbstractDeclarator_20Context *_localctx = _tracker.createInstance<Altnt_block__directAbstractDeclarator_20Context>(_ctx, getState());
  enterRule(_localctx, 418, PnfCParser::RuleAltnt_block__directAbstractDeclarator_20);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1364);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case PnfCParser::LeftParen:
      case PnfCParser::LeftBracket:
      case PnfCParser::Star:
      case PnfCParser::Caret: {
        enterOuterAlt(_localctx, 1);
        setState(1362);
        abstractDeclarator();
        break;
      }

      case PnfCParser::T__0:
      case PnfCParser::T__1:
      case PnfCParser::T__2:
      case PnfCParser::T__6:
      case PnfCParser::T__8:
      case PnfCParser::T__9:
      case PnfCParser::T__12:
      case PnfCParser::T__13:
      case PnfCParser::Auto:
      case PnfCParser::Char:
      case PnfCParser::Const:
      case PnfCParser::Nonnull:
      case PnfCParser::Nullable:
      case PnfCParser::Double:
      case PnfCParser::Enum:
      case PnfCParser::Extern:
      case PnfCParser::Float:
      case PnfCParser::Inline:
      case PnfCParser::Int:
      case PnfCParser::Long:
      case PnfCParser::Register:
      case PnfCParser::Restrict:
      case PnfCParser::Restrict_gcc:
      case PnfCParser::Restrict_gcc2:
      case PnfCParser::Extension_gcc:
      case PnfCParser::Short:
      case PnfCParser::Signed:
      case PnfCParser::Static:
      case PnfCParser::Struct:
      case PnfCParser::Typedef:
      case PnfCParser::Union:
      case PnfCParser::Unsigned:
      case PnfCParser::Void:
      case PnfCParser::Volatile:
      case PnfCParser::Alignas:
      case PnfCParser::Atomic:
      case PnfCParser::Bool:
      case PnfCParser::Complex:
      case PnfCParser::Noreturn:
      case PnfCParser::ThreadLocal:
      case PnfCParser::RightParen:
      case PnfCParser::Identifier: {
        enterOuterAlt(_localctx, 2);
        setState(1363);
        optional__directAbstractDeclarator_5();
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__iterationStatement_8Context ------------------------------------------------------------------

PnfCParser::Altnt_block__iterationStatement_8Context::Altnt_block__iterationStatement_8Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Aux_rule__iterationStatement_9Context* PnfCParser::Altnt_block__iterationStatement_8Context::aux_rule__iterationStatement_9() {
  return getRuleContext<PnfCParser::Aux_rule__iterationStatement_9Context>(0);
}

PnfCParser::DeclarationContext* PnfCParser::Altnt_block__iterationStatement_8Context::declaration() {
  return getRuleContext<PnfCParser::DeclarationContext>(0);
}


size_t PnfCParser::Altnt_block__iterationStatement_8Context::getRuleIndex() const {
  return PnfCParser::RuleAltnt_block__iterationStatement_8;
}

void PnfCParser::Altnt_block__iterationStatement_8Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__iterationStatement_8(this);
}

void PnfCParser::Altnt_block__iterationStatement_8Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__iterationStatement_8(this);
}


antlrcpp::Any PnfCParser::Altnt_block__iterationStatement_8Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__iterationStatement_8(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Altnt_block__iterationStatement_8Context* PnfCParser::altnt_block__iterationStatement_8() {
  Altnt_block__iterationStatement_8Context *_localctx = _tracker.createInstance<Altnt_block__iterationStatement_8Context>(_ctx, getState());
  enterRule(_localctx, 420, PnfCParser::RuleAltnt_block__iterationStatement_8);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1368);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 103, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(1366);
      aux_rule__iterationStatement_9();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(1367);
      declaration();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__statement_1Context ------------------------------------------------------------------

PnfCParser::Altnt_block__statement_1Context::Altnt_block__statement_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Aux_rule__statement_6Context* PnfCParser::Altnt_block__statement_1Context::aux_rule__statement_6() {
  return getRuleContext<PnfCParser::Aux_rule__statement_6Context>(0);
}

PnfCParser::Aux_rule__statement_7Context* PnfCParser::Altnt_block__statement_1Context::aux_rule__statement_7() {
  return getRuleContext<PnfCParser::Aux_rule__statement_7Context>(0);
}


size_t PnfCParser::Altnt_block__statement_1Context::getRuleIndex() const {
  return PnfCParser::RuleAltnt_block__statement_1;
}

void PnfCParser::Altnt_block__statement_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__statement_1(this);
}

void PnfCParser::Altnt_block__statement_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__statement_1(this);
}


antlrcpp::Any PnfCParser::Altnt_block__statement_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__statement_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Altnt_block__statement_1Context* PnfCParser::altnt_block__statement_1() {
  Altnt_block__statement_1Context *_localctx = _tracker.createInstance<Altnt_block__statement_1Context>(_ctx, getState());
  enterRule(_localctx, 422, PnfCParser::RuleAltnt_block__statement_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1372);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case PnfCParser::For: {
        enterOuterAlt(_localctx, 1);
        setState(1370);
        aux_rule__statement_6();
        break;
      }

      case PnfCParser::Switch:
      case PnfCParser::While: {
        enterOuterAlt(_localctx, 2);
        setState(1371);
        aux_rule__statement_7();
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__statement_2Context ------------------------------------------------------------------

PnfCParser::Altnt_block__statement_2Context::Altnt_block__statement_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Altnt_block__statement_2Context::Switch() {
  return getToken(PnfCParser::Switch, 0);
}

tree::TerminalNode* PnfCParser::Altnt_block__statement_2Context::While() {
  return getToken(PnfCParser::While, 0);
}


size_t PnfCParser::Altnt_block__statement_2Context::getRuleIndex() const {
  return PnfCParser::RuleAltnt_block__statement_2;
}

void PnfCParser::Altnt_block__statement_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__statement_2(this);
}

void PnfCParser::Altnt_block__statement_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__statement_2(this);
}


antlrcpp::Any PnfCParser::Altnt_block__statement_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__statement_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Altnt_block__statement_2Context* PnfCParser::altnt_block__statement_2() {
  Altnt_block__statement_2Context *_localctx = _tracker.createInstance<Altnt_block__statement_2Context>(_ctx, getState());
  enterRule(_localctx, 424, PnfCParser::RuleAltnt_block__statement_2);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1374);
    _la = _input->LA(1);
    if (!(_la == PnfCParser::Switch

    || _la == PnfCParser::While)) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__unaryExpression_5Context ------------------------------------------------------------------

PnfCParser::Aux_rule__unaryExpression_5Context::Aux_rule__unaryExpression_5Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::UnaryOperatorContext* PnfCParser::Aux_rule__unaryExpression_5Context::unaryOperator() {
  return getRuleContext<PnfCParser::UnaryOperatorContext>(0);
}

PnfCParser::CastExpressionContext* PnfCParser::Aux_rule__unaryExpression_5Context::castExpression() {
  return getRuleContext<PnfCParser::CastExpressionContext>(0);
}


size_t PnfCParser::Aux_rule__unaryExpression_5Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__unaryExpression_5;
}

void PnfCParser::Aux_rule__unaryExpression_5Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__unaryExpression_5(this);
}

void PnfCParser::Aux_rule__unaryExpression_5Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__unaryExpression_5(this);
}


antlrcpp::Any PnfCParser::Aux_rule__unaryExpression_5Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__unaryExpression_5(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__unaryExpression_5Context* PnfCParser::aux_rule__unaryExpression_5() {
  Aux_rule__unaryExpression_5Context *_localctx = _tracker.createInstance<Aux_rule__unaryExpression_5Context>(_ctx, getState());
  enterRule(_localctx, 426, PnfCParser::RuleAux_rule__unaryExpression_5);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1376);
    unaryOperator();
    setState(1377);
    castExpression();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__unaryExpression_6Context ------------------------------------------------------------------

PnfCParser::Aux_rule__unaryExpression_6Context::Aux_rule__unaryExpression_6Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__unaryExpression_6Context::AndAnd() {
  return getToken(PnfCParser::AndAnd, 0);
}

tree::TerminalNode* PnfCParser::Aux_rule__unaryExpression_6Context::Identifier() {
  return getToken(PnfCParser::Identifier, 0);
}


size_t PnfCParser::Aux_rule__unaryExpression_6Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__unaryExpression_6;
}

void PnfCParser::Aux_rule__unaryExpression_6Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__unaryExpression_6(this);
}

void PnfCParser::Aux_rule__unaryExpression_6Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__unaryExpression_6(this);
}


antlrcpp::Any PnfCParser::Aux_rule__unaryExpression_6Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__unaryExpression_6(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__unaryExpression_6Context* PnfCParser::aux_rule__unaryExpression_6() {
  Aux_rule__unaryExpression_6Context *_localctx = _tracker.createInstance<Aux_rule__unaryExpression_6Context>(_ctx, getState());
  enterRule(_localctx, 428, PnfCParser::RuleAux_rule__unaryExpression_6);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1379);
    match(PnfCParser::AndAnd);
    setState(1380);
    match(PnfCParser::Identifier);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__unaryExpression_7Context ------------------------------------------------------------------

PnfCParser::Aux_rule__unaryExpression_7Context::Aux_rule__unaryExpression_7Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Altnt_block__unaryExpression_1Context* PnfCParser::Aux_rule__unaryExpression_7Context::altnt_block__unaryExpression_1() {
  return getRuleContext<PnfCParser::Altnt_block__unaryExpression_1Context>(0);
}

PnfCParser::UnaryExpressionContext* PnfCParser::Aux_rule__unaryExpression_7Context::unaryExpression() {
  return getRuleContext<PnfCParser::UnaryExpressionContext>(0);
}


size_t PnfCParser::Aux_rule__unaryExpression_7Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__unaryExpression_7;
}

void PnfCParser::Aux_rule__unaryExpression_7Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__unaryExpression_7(this);
}

void PnfCParser::Aux_rule__unaryExpression_7Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__unaryExpression_7(this);
}


antlrcpp::Any PnfCParser::Aux_rule__unaryExpression_7Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__unaryExpression_7(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__unaryExpression_7Context* PnfCParser::aux_rule__unaryExpression_7() {
  Aux_rule__unaryExpression_7Context *_localctx = _tracker.createInstance<Aux_rule__unaryExpression_7Context>(_ctx, getState());
  enterRule(_localctx, 430, PnfCParser::RuleAux_rule__unaryExpression_7);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1382);
    altnt_block__unaryExpression_1();
    setState(1383);
    unaryExpression();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__unaryExpression_8Context ------------------------------------------------------------------

PnfCParser::Aux_rule__unaryExpression_8Context::Aux_rule__unaryExpression_8Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Altnt_block__unaryExpression_2Context* PnfCParser::Aux_rule__unaryExpression_8Context::altnt_block__unaryExpression_2() {
  return getRuleContext<PnfCParser::Altnt_block__unaryExpression_2Context>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__unaryExpression_8Context::RightParen() {
  return getToken(PnfCParser::RightParen, 0);
}


size_t PnfCParser::Aux_rule__unaryExpression_8Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__unaryExpression_8;
}

void PnfCParser::Aux_rule__unaryExpression_8Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__unaryExpression_8(this);
}

void PnfCParser::Aux_rule__unaryExpression_8Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__unaryExpression_8(this);
}


antlrcpp::Any PnfCParser::Aux_rule__unaryExpression_8Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__unaryExpression_8(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__unaryExpression_8Context* PnfCParser::aux_rule__unaryExpression_8() {
  Aux_rule__unaryExpression_8Context *_localctx = _tracker.createInstance<Aux_rule__unaryExpression_8Context>(_ctx, getState());
  enterRule(_localctx, 432, PnfCParser::RuleAux_rule__unaryExpression_8);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1385);
    altnt_block__unaryExpression_2();
    setState(1386);
    match(PnfCParser::RightParen);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__castExpression_2Context ------------------------------------------------------------------

PnfCParser::Aux_rule__castExpression_2Context::Aux_rule__castExpression_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Optional__primaryExpression_2Context* PnfCParser::Aux_rule__castExpression_2Context::optional__primaryExpression_2() {
  return getRuleContext<PnfCParser::Optional__primaryExpression_2Context>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__castExpression_2Context::LeftParen() {
  return getToken(PnfCParser::LeftParen, 0);
}

PnfCParser::TypeNameContext* PnfCParser::Aux_rule__castExpression_2Context::typeName() {
  return getRuleContext<PnfCParser::TypeNameContext>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__castExpression_2Context::RightParen() {
  return getToken(PnfCParser::RightParen, 0);
}

PnfCParser::CastExpressionContext* PnfCParser::Aux_rule__castExpression_2Context::castExpression() {
  return getRuleContext<PnfCParser::CastExpressionContext>(0);
}


size_t PnfCParser::Aux_rule__castExpression_2Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__castExpression_2;
}

void PnfCParser::Aux_rule__castExpression_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__castExpression_2(this);
}

void PnfCParser::Aux_rule__castExpression_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__castExpression_2(this);
}


antlrcpp::Any PnfCParser::Aux_rule__castExpression_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__castExpression_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__castExpression_2Context* PnfCParser::aux_rule__castExpression_2() {
  Aux_rule__castExpression_2Context *_localctx = _tracker.createInstance<Aux_rule__castExpression_2Context>(_ctx, getState());
  enterRule(_localctx, 434, PnfCParser::RuleAux_rule__castExpression_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1388);
    optional__primaryExpression_2();
    setState(1389);
    match(PnfCParser::LeftParen);
    setState(1390);
    typeName();
    setState(1391);
    match(PnfCParser::RightParen);
    setState(1392);
    castExpression();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__assignmentExpression_1Context ------------------------------------------------------------------

PnfCParser::Aux_rule__assignmentExpression_1Context::Aux_rule__assignmentExpression_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::UnaryExpressionContext* PnfCParser::Aux_rule__assignmentExpression_1Context::unaryExpression() {
  return getRuleContext<PnfCParser::UnaryExpressionContext>(0);
}

PnfCParser::AssignmentOperatorContext* PnfCParser::Aux_rule__assignmentExpression_1Context::assignmentOperator() {
  return getRuleContext<PnfCParser::AssignmentOperatorContext>(0);
}

PnfCParser::AssignmentExpressionContext* PnfCParser::Aux_rule__assignmentExpression_1Context::assignmentExpression() {
  return getRuleContext<PnfCParser::AssignmentExpressionContext>(0);
}


size_t PnfCParser::Aux_rule__assignmentExpression_1Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__assignmentExpression_1;
}

void PnfCParser::Aux_rule__assignmentExpression_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__assignmentExpression_1(this);
}

void PnfCParser::Aux_rule__assignmentExpression_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__assignmentExpression_1(this);
}


antlrcpp::Any PnfCParser::Aux_rule__assignmentExpression_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__assignmentExpression_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__assignmentExpression_1Context* PnfCParser::aux_rule__assignmentExpression_1() {
  Aux_rule__assignmentExpression_1Context *_localctx = _tracker.createInstance<Aux_rule__assignmentExpression_1Context>(_ctx, getState());
  enterRule(_localctx, 436, PnfCParser::RuleAux_rule__assignmentExpression_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1394);
    unaryExpression();
    setState(1395);
    assignmentOperator();
    setState(1396);
    assignmentExpression();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__declaration_3Context ------------------------------------------------------------------

PnfCParser::Aux_rule__declaration_3Context::Aux_rule__declaration_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Optional__declaration_1Context* PnfCParser::Aux_rule__declaration_3Context::optional__declaration_1() {
  return getRuleContext<PnfCParser::Optional__declaration_1Context>(0);
}

PnfCParser::DeclarationSpecifiersContext* PnfCParser::Aux_rule__declaration_3Context::declarationSpecifiers() {
  return getRuleContext<PnfCParser::DeclarationSpecifiersContext>(0);
}

PnfCParser::Optional__declaration_2Context* PnfCParser::Aux_rule__declaration_3Context::optional__declaration_2() {
  return getRuleContext<PnfCParser::Optional__declaration_2Context>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__declaration_3Context::Semi() {
  return getToken(PnfCParser::Semi, 0);
}


size_t PnfCParser::Aux_rule__declaration_3Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__declaration_3;
}

void PnfCParser::Aux_rule__declaration_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__declaration_3(this);
}

void PnfCParser::Aux_rule__declaration_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__declaration_3(this);
}


antlrcpp::Any PnfCParser::Aux_rule__declaration_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__declaration_3(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__declaration_3Context* PnfCParser::aux_rule__declaration_3() {
  Aux_rule__declaration_3Context *_localctx = _tracker.createInstance<Aux_rule__declaration_3Context>(_ctx, getState());
  enterRule(_localctx, 438, PnfCParser::RuleAux_rule__declaration_3);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1398);
    optional__declaration_1();
    setState(1399);
    declarationSpecifiers();
    setState(1400);
    optional__declaration_2();
    setState(1401);
    match(PnfCParser::Semi);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__typeSpecifier_3Context ------------------------------------------------------------------

PnfCParser::Aux_rule__typeSpecifier_3Context::Aux_rule__typeSpecifier_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Altnt_block__typeSpecifier_1Context* PnfCParser::Aux_rule__typeSpecifier_3Context::altnt_block__typeSpecifier_1() {
  return getRuleContext<PnfCParser::Altnt_block__typeSpecifier_1Context>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__typeSpecifier_3Context::RightParen() {
  return getToken(PnfCParser::RightParen, 0);
}


size_t PnfCParser::Aux_rule__typeSpecifier_3Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__typeSpecifier_3;
}

void PnfCParser::Aux_rule__typeSpecifier_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__typeSpecifier_3(this);
}

void PnfCParser::Aux_rule__typeSpecifier_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__typeSpecifier_3(this);
}


antlrcpp::Any PnfCParser::Aux_rule__typeSpecifier_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__typeSpecifier_3(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__typeSpecifier_3Context* PnfCParser::aux_rule__typeSpecifier_3() {
  Aux_rule__typeSpecifier_3Context *_localctx = _tracker.createInstance<Aux_rule__typeSpecifier_3Context>(_ctx, getState());
  enterRule(_localctx, 440, PnfCParser::RuleAux_rule__typeSpecifier_3);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1403);
    altnt_block__typeSpecifier_1();
    setState(1404);
    match(PnfCParser::RightParen);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__structDeclarator_2Context ------------------------------------------------------------------

PnfCParser::Aux_rule__structDeclarator_2Context::Aux_rule__structDeclarator_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Optional__structDeclarator_1Context* PnfCParser::Aux_rule__structDeclarator_2Context::optional__structDeclarator_1() {
  return getRuleContext<PnfCParser::Optional__structDeclarator_1Context>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__structDeclarator_2Context::Colon() {
  return getToken(PnfCParser::Colon, 0);
}

PnfCParser::ConstantExpressionContext* PnfCParser::Aux_rule__structDeclarator_2Context::constantExpression() {
  return getRuleContext<PnfCParser::ConstantExpressionContext>(0);
}


size_t PnfCParser::Aux_rule__structDeclarator_2Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__structDeclarator_2;
}

void PnfCParser::Aux_rule__structDeclarator_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__structDeclarator_2(this);
}

void PnfCParser::Aux_rule__structDeclarator_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__structDeclarator_2(this);
}


antlrcpp::Any PnfCParser::Aux_rule__structDeclarator_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__structDeclarator_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__structDeclarator_2Context* PnfCParser::aux_rule__structDeclarator_2() {
  Aux_rule__structDeclarator_2Context *_localctx = _tracker.createInstance<Aux_rule__structDeclarator_2Context>(_ctx, getState());
  enterRule(_localctx, 442, PnfCParser::RuleAux_rule__structDeclarator_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1406);
    optional__structDeclarator_1();
    setState(1407);
    match(PnfCParser::Colon);
    setState(1408);
    constantExpression();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__gccDeclaratorExtension_2Context ------------------------------------------------------------------

PnfCParser::Aux_rule__gccDeclaratorExtension_2Context::Aux_rule__gccDeclaratorExtension_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::AsmKeywordContext* PnfCParser::Aux_rule__gccDeclaratorExtension_2Context::asmKeyword() {
  return getRuleContext<PnfCParser::AsmKeywordContext>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__gccDeclaratorExtension_2Context::LeftParen() {
  return getToken(PnfCParser::LeftParen, 0);
}

PnfCParser::Kleene_plus__primaryExpression_1Context* PnfCParser::Aux_rule__gccDeclaratorExtension_2Context::kleene_plus__primaryExpression_1() {
  return getRuleContext<PnfCParser::Kleene_plus__primaryExpression_1Context>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__gccDeclaratorExtension_2Context::RightParen() {
  return getToken(PnfCParser::RightParen, 0);
}


size_t PnfCParser::Aux_rule__gccDeclaratorExtension_2Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__gccDeclaratorExtension_2;
}

void PnfCParser::Aux_rule__gccDeclaratorExtension_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__gccDeclaratorExtension_2(this);
}

void PnfCParser::Aux_rule__gccDeclaratorExtension_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__gccDeclaratorExtension_2(this);
}


antlrcpp::Any PnfCParser::Aux_rule__gccDeclaratorExtension_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__gccDeclaratorExtension_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__gccDeclaratorExtension_2Context* PnfCParser::aux_rule__gccDeclaratorExtension_2() {
  Aux_rule__gccDeclaratorExtension_2Context *_localctx = _tracker.createInstance<Aux_rule__gccDeclaratorExtension_2Context>(_ctx, getState());
  enterRule(_localctx, 444, PnfCParser::RuleAux_rule__gccDeclaratorExtension_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1410);
    asmKeyword();
    setState(1411);
    match(PnfCParser::LeftParen);
    setState(1412);
    kleene_plus__primaryExpression_1();
    setState(1413);
    match(PnfCParser::RightParen);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__abstractDeclarator_3Context ------------------------------------------------------------------

PnfCParser::Aux_rule__abstractDeclarator_3Context::Aux_rule__abstractDeclarator_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Optional__declarator_1Context* PnfCParser::Aux_rule__abstractDeclarator_3Context::optional__declarator_1() {
  return getRuleContext<PnfCParser::Optional__declarator_1Context>(0);
}

PnfCParser::DirectAbstractDeclaratorContext* PnfCParser::Aux_rule__abstractDeclarator_3Context::directAbstractDeclarator() {
  return getRuleContext<PnfCParser::DirectAbstractDeclaratorContext>(0);
}

PnfCParser::Kleene_star__declarator_2Context* PnfCParser::Aux_rule__abstractDeclarator_3Context::kleene_star__declarator_2() {
  return getRuleContext<PnfCParser::Kleene_star__declarator_2Context>(0);
}


size_t PnfCParser::Aux_rule__abstractDeclarator_3Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__abstractDeclarator_3;
}

void PnfCParser::Aux_rule__abstractDeclarator_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__abstractDeclarator_3(this);
}

void PnfCParser::Aux_rule__abstractDeclarator_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__abstractDeclarator_3(this);
}


antlrcpp::Any PnfCParser::Aux_rule__abstractDeclarator_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__abstractDeclarator_3(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__abstractDeclarator_3Context* PnfCParser::aux_rule__abstractDeclarator_3() {
  Aux_rule__abstractDeclarator_3Context *_localctx = _tracker.createInstance<Aux_rule__abstractDeclarator_3Context>(_ctx, getState());
  enterRule(_localctx, 446, PnfCParser::RuleAux_rule__abstractDeclarator_3);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1415);
    optional__declarator_1();
    setState(1416);
    directAbstractDeclarator();
    setState(1417);
    kleene_star__declarator_2();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__initializer_2Context ------------------------------------------------------------------

PnfCParser::Aux_rule__initializer_2Context::Aux_rule__initializer_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__initializer_2Context::LeftBrace() {
  return getToken(PnfCParser::LeftBrace, 0);
}

PnfCParser::InitializerListContext* PnfCParser::Aux_rule__initializer_2Context::initializerList() {
  return getRuleContext<PnfCParser::InitializerListContext>(0);
}

PnfCParser::Optional__postfixExpression_5Context* PnfCParser::Aux_rule__initializer_2Context::optional__postfixExpression_5() {
  return getRuleContext<PnfCParser::Optional__postfixExpression_5Context>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__initializer_2Context::RightBrace() {
  return getToken(PnfCParser::RightBrace, 0);
}


size_t PnfCParser::Aux_rule__initializer_2Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__initializer_2;
}

void PnfCParser::Aux_rule__initializer_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__initializer_2(this);
}

void PnfCParser::Aux_rule__initializer_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__initializer_2(this);
}


antlrcpp::Any PnfCParser::Aux_rule__initializer_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__initializer_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__initializer_2Context* PnfCParser::aux_rule__initializer_2() {
  Aux_rule__initializer_2Context *_localctx = _tracker.createInstance<Aux_rule__initializer_2Context>(_ctx, getState());
  enterRule(_localctx, 448, PnfCParser::RuleAux_rule__initializer_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1419);
    match(PnfCParser::LeftBrace);
    setState(1420);
    initializerList();
    setState(1421);
    optional__postfixExpression_5();
    setState(1422);
    match(PnfCParser::RightBrace);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__postfixExpression_10Context ------------------------------------------------------------------

PnfCParser::Aux_rule__postfixExpression_10Context::Aux_rule__postfixExpression_10Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__postfixExpression_10Context::LeftBracket() {
  return getToken(PnfCParser::LeftBracket, 0);
}

PnfCParser::ExpressionContext* PnfCParser::Aux_rule__postfixExpression_10Context::expression() {
  return getRuleContext<PnfCParser::ExpressionContext>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__postfixExpression_10Context::RightBracket() {
  return getToken(PnfCParser::RightBracket, 0);
}


size_t PnfCParser::Aux_rule__postfixExpression_10Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__postfixExpression_10;
}

void PnfCParser::Aux_rule__postfixExpression_10Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__postfixExpression_10(this);
}

void PnfCParser::Aux_rule__postfixExpression_10Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__postfixExpression_10(this);
}


antlrcpp::Any PnfCParser::Aux_rule__postfixExpression_10Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__postfixExpression_10(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__postfixExpression_10Context* PnfCParser::aux_rule__postfixExpression_10() {
  Aux_rule__postfixExpression_10Context *_localctx = _tracker.createInstance<Aux_rule__postfixExpression_10Context>(_ctx, getState());
  enterRule(_localctx, 450, PnfCParser::RuleAux_rule__postfixExpression_10);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1424);
    match(PnfCParser::LeftBracket);
    setState(1425);
    expression();
    setState(1426);
    match(PnfCParser::RightBracket);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__postfixExpression_11Context ------------------------------------------------------------------

PnfCParser::Aux_rule__postfixExpression_11Context::Aux_rule__postfixExpression_11Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__postfixExpression_11Context::LeftParen() {
  return getToken(PnfCParser::LeftParen, 0);
}

PnfCParser::Optional__postfixExpression_1Context* PnfCParser::Aux_rule__postfixExpression_11Context::optional__postfixExpression_1() {
  return getRuleContext<PnfCParser::Optional__postfixExpression_1Context>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__postfixExpression_11Context::RightParen() {
  return getToken(PnfCParser::RightParen, 0);
}


size_t PnfCParser::Aux_rule__postfixExpression_11Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__postfixExpression_11;
}

void PnfCParser::Aux_rule__postfixExpression_11Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__postfixExpression_11(this);
}

void PnfCParser::Aux_rule__postfixExpression_11Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__postfixExpression_11(this);
}


antlrcpp::Any PnfCParser::Aux_rule__postfixExpression_11Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__postfixExpression_11(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__postfixExpression_11Context* PnfCParser::aux_rule__postfixExpression_11() {
  Aux_rule__postfixExpression_11Context *_localctx = _tracker.createInstance<Aux_rule__postfixExpression_11Context>(_ctx, getState());
  enterRule(_localctx, 452, PnfCParser::RuleAux_rule__postfixExpression_11);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1428);
    match(PnfCParser::LeftParen);
    setState(1429);
    optional__postfixExpression_1();
    setState(1430);
    match(PnfCParser::RightParen);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__postfixExpression_12Context ------------------------------------------------------------------

PnfCParser::Aux_rule__postfixExpression_12Context::Aux_rule__postfixExpression_12Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Altnt_block__postfixExpression_7Context* PnfCParser::Aux_rule__postfixExpression_12Context::altnt_block__postfixExpression_7() {
  return getRuleContext<PnfCParser::Altnt_block__postfixExpression_7Context>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__postfixExpression_12Context::Identifier() {
  return getToken(PnfCParser::Identifier, 0);
}


size_t PnfCParser::Aux_rule__postfixExpression_12Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__postfixExpression_12;
}

void PnfCParser::Aux_rule__postfixExpression_12Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__postfixExpression_12(this);
}

void PnfCParser::Aux_rule__postfixExpression_12Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__postfixExpression_12(this);
}


antlrcpp::Any PnfCParser::Aux_rule__postfixExpression_12Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__postfixExpression_12(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__postfixExpression_12Context* PnfCParser::aux_rule__postfixExpression_12() {
  Aux_rule__postfixExpression_12Context *_localctx = _tracker.createInstance<Aux_rule__postfixExpression_12Context>(_ctx, getState());
  enterRule(_localctx, 454, PnfCParser::RuleAux_rule__postfixExpression_12);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1432);
    altnt_block__postfixExpression_7();
    setState(1433);
    match(PnfCParser::Identifier);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__directDeclarator_13Context ------------------------------------------------------------------

PnfCParser::Aux_rule__directDeclarator_13Context::Aux_rule__directDeclarator_13Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__directDeclarator_13Context::LeftBracket() {
  return getToken(PnfCParser::LeftBracket, 0);
}

PnfCParser::Altnt_block__directDeclarator_9Context* PnfCParser::Aux_rule__directDeclarator_13Context::altnt_block__directDeclarator_9() {
  return getRuleContext<PnfCParser::Altnt_block__directDeclarator_9Context>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__directDeclarator_13Context::RightBracket() {
  return getToken(PnfCParser::RightBracket, 0);
}


size_t PnfCParser::Aux_rule__directDeclarator_13Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__directDeclarator_13;
}

void PnfCParser::Aux_rule__directDeclarator_13Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__directDeclarator_13(this);
}

void PnfCParser::Aux_rule__directDeclarator_13Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__directDeclarator_13(this);
}


antlrcpp::Any PnfCParser::Aux_rule__directDeclarator_13Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__directDeclarator_13(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__directDeclarator_13Context* PnfCParser::aux_rule__directDeclarator_13() {
  Aux_rule__directDeclarator_13Context *_localctx = _tracker.createInstance<Aux_rule__directDeclarator_13Context>(_ctx, getState());
  enterRule(_localctx, 456, PnfCParser::RuleAux_rule__directDeclarator_13);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1435);
    match(PnfCParser::LeftBracket);
    setState(1436);
    altnt_block__directDeclarator_9();
    setState(1437);
    match(PnfCParser::RightBracket);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__directDeclarator_14Context ------------------------------------------------------------------

PnfCParser::Aux_rule__directDeclarator_14Context::Aux_rule__directDeclarator_14Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__directDeclarator_14Context::LeftParen() {
  return getToken(PnfCParser::LeftParen, 0);
}

PnfCParser::Altnt_block__directDeclarator_10Context* PnfCParser::Aux_rule__directDeclarator_14Context::altnt_block__directDeclarator_10() {
  return getRuleContext<PnfCParser::Altnt_block__directDeclarator_10Context>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__directDeclarator_14Context::RightParen() {
  return getToken(PnfCParser::RightParen, 0);
}


size_t PnfCParser::Aux_rule__directDeclarator_14Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__directDeclarator_14;
}

void PnfCParser::Aux_rule__directDeclarator_14Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__directDeclarator_14(this);
}

void PnfCParser::Aux_rule__directDeclarator_14Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__directDeclarator_14(this);
}


antlrcpp::Any PnfCParser::Aux_rule__directDeclarator_14Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__directDeclarator_14(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__directDeclarator_14Context* PnfCParser::aux_rule__directDeclarator_14() {
  Aux_rule__directDeclarator_14Context *_localctx = _tracker.createInstance<Aux_rule__directDeclarator_14Context>(_ctx, getState());
  enterRule(_localctx, 458, PnfCParser::RuleAux_rule__directDeclarator_14);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1439);
    match(PnfCParser::LeftParen);
    setState(1440);
    altnt_block__directDeclarator_10();
    setState(1441);
    match(PnfCParser::RightParen);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__directDeclarator_15Context ------------------------------------------------------------------

PnfCParser::Aux_rule__directDeclarator_15Context::Aux_rule__directDeclarator_15Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__directDeclarator_15Context::LeftParen() {
  return getToken(PnfCParser::LeftParen, 0);
}

PnfCParser::DeclaratorContext* PnfCParser::Aux_rule__directDeclarator_15Context::declarator() {
  return getRuleContext<PnfCParser::DeclaratorContext>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__directDeclarator_15Context::RightParen() {
  return getToken(PnfCParser::RightParen, 0);
}


size_t PnfCParser::Aux_rule__directDeclarator_15Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__directDeclarator_15;
}

void PnfCParser::Aux_rule__directDeclarator_15Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__directDeclarator_15(this);
}

void PnfCParser::Aux_rule__directDeclarator_15Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__directDeclarator_15(this);
}


antlrcpp::Any PnfCParser::Aux_rule__directDeclarator_15Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__directDeclarator_15(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__directDeclarator_15Context* PnfCParser::aux_rule__directDeclarator_15() {
  Aux_rule__directDeclarator_15Context *_localctx = _tracker.createInstance<Aux_rule__directDeclarator_15Context>(_ctx, getState());
  enterRule(_localctx, 460, PnfCParser::RuleAux_rule__directDeclarator_15);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1443);
    match(PnfCParser::LeftParen);
    setState(1444);
    declarator();
    setState(1445);
    match(PnfCParser::RightParen);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__directAbstractDeclarator_21Context ------------------------------------------------------------------

PnfCParser::Aux_rule__directAbstractDeclarator_21Context::Aux_rule__directAbstractDeclarator_21Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__directAbstractDeclarator_21Context::LeftParen() {
  return getToken(PnfCParser::LeftParen, 0);
}

PnfCParser::Optional__directAbstractDeclarator_5Context* PnfCParser::Aux_rule__directAbstractDeclarator_21Context::optional__directAbstractDeclarator_5() {
  return getRuleContext<PnfCParser::Optional__directAbstractDeclarator_5Context>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__directAbstractDeclarator_21Context::RightParen() {
  return getToken(PnfCParser::RightParen, 0);
}

PnfCParser::Kleene_star__declarator_2Context* PnfCParser::Aux_rule__directAbstractDeclarator_21Context::kleene_star__declarator_2() {
  return getRuleContext<PnfCParser::Kleene_star__declarator_2Context>(0);
}


size_t PnfCParser::Aux_rule__directAbstractDeclarator_21Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__directAbstractDeclarator_21;
}

void PnfCParser::Aux_rule__directAbstractDeclarator_21Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__directAbstractDeclarator_21(this);
}

void PnfCParser::Aux_rule__directAbstractDeclarator_21Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__directAbstractDeclarator_21(this);
}


antlrcpp::Any PnfCParser::Aux_rule__directAbstractDeclarator_21Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__directAbstractDeclarator_21(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__directAbstractDeclarator_21Context* PnfCParser::aux_rule__directAbstractDeclarator_21() {
  Aux_rule__directAbstractDeclarator_21Context *_localctx = _tracker.createInstance<Aux_rule__directAbstractDeclarator_21Context>(_ctx, getState());
  enterRule(_localctx, 462, PnfCParser::RuleAux_rule__directAbstractDeclarator_21);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1447);
    match(PnfCParser::LeftParen);
    setState(1448);
    optional__directAbstractDeclarator_5();
    setState(1449);
    match(PnfCParser::RightParen);
    setState(1450);
    kleene_star__declarator_2();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__directAbstractDeclarator_22Context ------------------------------------------------------------------

PnfCParser::Aux_rule__directAbstractDeclarator_22Context::Aux_rule__directAbstractDeclarator_22Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__directAbstractDeclarator_22Context::LeftBracket() {
  return getToken(PnfCParser::LeftBracket, 0);
}

PnfCParser::Altnt_block__directAbstractDeclarator_15Context* PnfCParser::Aux_rule__directAbstractDeclarator_22Context::altnt_block__directAbstractDeclarator_15() {
  return getRuleContext<PnfCParser::Altnt_block__directAbstractDeclarator_15Context>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__directAbstractDeclarator_22Context::RightBracket() {
  return getToken(PnfCParser::RightBracket, 0);
}


size_t PnfCParser::Aux_rule__directAbstractDeclarator_22Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__directAbstractDeclarator_22;
}

void PnfCParser::Aux_rule__directAbstractDeclarator_22Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__directAbstractDeclarator_22(this);
}

void PnfCParser::Aux_rule__directAbstractDeclarator_22Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__directAbstractDeclarator_22(this);
}


antlrcpp::Any PnfCParser::Aux_rule__directAbstractDeclarator_22Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__directAbstractDeclarator_22(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__directAbstractDeclarator_22Context* PnfCParser::aux_rule__directAbstractDeclarator_22() {
  Aux_rule__directAbstractDeclarator_22Context *_localctx = _tracker.createInstance<Aux_rule__directAbstractDeclarator_22Context>(_ctx, getState());
  enterRule(_localctx, 464, PnfCParser::RuleAux_rule__directAbstractDeclarator_22);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1452);
    match(PnfCParser::LeftBracket);
    setState(1453);
    altnt_block__directAbstractDeclarator_15();
    setState(1454);
    match(PnfCParser::RightBracket);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__directAbstractDeclarator_23Context ------------------------------------------------------------------

PnfCParser::Aux_rule__directAbstractDeclarator_23Context::Aux_rule__directAbstractDeclarator_23Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__directAbstractDeclarator_23Context::LeftBracket() {
  return getToken(PnfCParser::LeftBracket, 0);
}

PnfCParser::Altnt_block__directAbstractDeclarator_15Context* PnfCParser::Aux_rule__directAbstractDeclarator_23Context::altnt_block__directAbstractDeclarator_15() {
  return getRuleContext<PnfCParser::Altnt_block__directAbstractDeclarator_15Context>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__directAbstractDeclarator_23Context::RightBracket() {
  return getToken(PnfCParser::RightBracket, 0);
}


size_t PnfCParser::Aux_rule__directAbstractDeclarator_23Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__directAbstractDeclarator_23;
}

void PnfCParser::Aux_rule__directAbstractDeclarator_23Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__directAbstractDeclarator_23(this);
}

void PnfCParser::Aux_rule__directAbstractDeclarator_23Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__directAbstractDeclarator_23(this);
}


antlrcpp::Any PnfCParser::Aux_rule__directAbstractDeclarator_23Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__directAbstractDeclarator_23(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__directAbstractDeclarator_23Context* PnfCParser::aux_rule__directAbstractDeclarator_23() {
  Aux_rule__directAbstractDeclarator_23Context *_localctx = _tracker.createInstance<Aux_rule__directAbstractDeclarator_23Context>(_ctx, getState());
  enterRule(_localctx, 466, PnfCParser::RuleAux_rule__directAbstractDeclarator_23);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1456);
    match(PnfCParser::LeftBracket);
    setState(1457);
    altnt_block__directAbstractDeclarator_15();
    setState(1458);
    match(PnfCParser::RightBracket);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__directAbstractDeclarator_24Context ------------------------------------------------------------------

PnfCParser::Aux_rule__directAbstractDeclarator_24Context::Aux_rule__directAbstractDeclarator_24Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__directAbstractDeclarator_24Context::LeftParen() {
  return getToken(PnfCParser::LeftParen, 0);
}

PnfCParser::Altnt_block__directAbstractDeclarator_17Context* PnfCParser::Aux_rule__directAbstractDeclarator_24Context::altnt_block__directAbstractDeclarator_17() {
  return getRuleContext<PnfCParser::Altnt_block__directAbstractDeclarator_17Context>(0);
}


size_t PnfCParser::Aux_rule__directAbstractDeclarator_24Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__directAbstractDeclarator_24;
}

void PnfCParser::Aux_rule__directAbstractDeclarator_24Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__directAbstractDeclarator_24(this);
}

void PnfCParser::Aux_rule__directAbstractDeclarator_24Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__directAbstractDeclarator_24(this);
}


antlrcpp::Any PnfCParser::Aux_rule__directAbstractDeclarator_24Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__directAbstractDeclarator_24(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__directAbstractDeclarator_24Context* PnfCParser::aux_rule__directAbstractDeclarator_24() {
  Aux_rule__directAbstractDeclarator_24Context *_localctx = _tracker.createInstance<Aux_rule__directAbstractDeclarator_24Context>(_ctx, getState());
  enterRule(_localctx, 468, PnfCParser::RuleAux_rule__directAbstractDeclarator_24);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1460);
    match(PnfCParser::LeftParen);
    setState(1461);
    altnt_block__directAbstractDeclarator_17();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__primaryExpression_4Context ------------------------------------------------------------------

PnfCParser::Aux_rule__primaryExpression_4Context::Aux_rule__primaryExpression_4Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__primaryExpression_4Context::LeftParen() {
  return getToken(PnfCParser::LeftParen, 0);
}

PnfCParser::ExpressionContext* PnfCParser::Aux_rule__primaryExpression_4Context::expression() {
  return getRuleContext<PnfCParser::ExpressionContext>(0);
}


size_t PnfCParser::Aux_rule__primaryExpression_4Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__primaryExpression_4;
}

void PnfCParser::Aux_rule__primaryExpression_4Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__primaryExpression_4(this);
}

void PnfCParser::Aux_rule__primaryExpression_4Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__primaryExpression_4(this);
}


antlrcpp::Any PnfCParser::Aux_rule__primaryExpression_4Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__primaryExpression_4(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__primaryExpression_4Context* PnfCParser::aux_rule__primaryExpression_4() {
  Aux_rule__primaryExpression_4Context *_localctx = _tracker.createInstance<Aux_rule__primaryExpression_4Context>(_ctx, getState());
  enterRule(_localctx, 470, PnfCParser::RuleAux_rule__primaryExpression_4);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1463);
    match(PnfCParser::LeftParen);
    setState(1464);
    expression();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__primaryExpression_5Context ------------------------------------------------------------------

PnfCParser::Aux_rule__primaryExpression_5Context::Aux_rule__primaryExpression_5Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Optional__primaryExpression_2Context* PnfCParser::Aux_rule__primaryExpression_5Context::optional__primaryExpression_2() {
  return getRuleContext<PnfCParser::Optional__primaryExpression_2Context>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__primaryExpression_5Context::LeftParen() {
  return getToken(PnfCParser::LeftParen, 0);
}

PnfCParser::CompoundStatementContext* PnfCParser::Aux_rule__primaryExpression_5Context::compoundStatement() {
  return getRuleContext<PnfCParser::CompoundStatementContext>(0);
}


size_t PnfCParser::Aux_rule__primaryExpression_5Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__primaryExpression_5;
}

void PnfCParser::Aux_rule__primaryExpression_5Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__primaryExpression_5(this);
}

void PnfCParser::Aux_rule__primaryExpression_5Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__primaryExpression_5(this);
}


antlrcpp::Any PnfCParser::Aux_rule__primaryExpression_5Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__primaryExpression_5(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__primaryExpression_5Context* PnfCParser::aux_rule__primaryExpression_5() {
  Aux_rule__primaryExpression_5Context *_localctx = _tracker.createInstance<Aux_rule__primaryExpression_5Context>(_ctx, getState());
  enterRule(_localctx, 472, PnfCParser::RuleAux_rule__primaryExpression_5);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1466);
    optional__primaryExpression_2();
    setState(1467);
    match(PnfCParser::LeftParen);
    setState(1468);
    compoundStatement();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__primaryExpression_6Context ------------------------------------------------------------------

PnfCParser::Aux_rule__primaryExpression_6Context::Aux_rule__primaryExpression_6Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__primaryExpression_6Context::LeftParen() {
  return getToken(PnfCParser::LeftParen, 0);
}

PnfCParser::UnaryExpressionContext* PnfCParser::Aux_rule__primaryExpression_6Context::unaryExpression() {
  return getRuleContext<PnfCParser::UnaryExpressionContext>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__primaryExpression_6Context::Comma() {
  return getToken(PnfCParser::Comma, 0);
}

PnfCParser::TypeNameContext* PnfCParser::Aux_rule__primaryExpression_6Context::typeName() {
  return getRuleContext<PnfCParser::TypeNameContext>(0);
}


size_t PnfCParser::Aux_rule__primaryExpression_6Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__primaryExpression_6;
}

void PnfCParser::Aux_rule__primaryExpression_6Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__primaryExpression_6(this);
}

void PnfCParser::Aux_rule__primaryExpression_6Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__primaryExpression_6(this);
}


antlrcpp::Any PnfCParser::Aux_rule__primaryExpression_6Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__primaryExpression_6(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__primaryExpression_6Context* PnfCParser::aux_rule__primaryExpression_6() {
  Aux_rule__primaryExpression_6Context *_localctx = _tracker.createInstance<Aux_rule__primaryExpression_6Context>(_ctx, getState());
  enterRule(_localctx, 474, PnfCParser::RuleAux_rule__primaryExpression_6);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1470);
    match(PnfCParser::T__10);
    setState(1471);
    match(PnfCParser::LeftParen);
    setState(1472);
    unaryExpression();
    setState(1473);
    match(PnfCParser::Comma);
    setState(1474);
    typeName();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__primaryExpression_7Context ------------------------------------------------------------------

PnfCParser::Aux_rule__primaryExpression_7Context::Aux_rule__primaryExpression_7Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__primaryExpression_7Context::LeftParen() {
  return getToken(PnfCParser::LeftParen, 0);
}

PnfCParser::TypeNameContext* PnfCParser::Aux_rule__primaryExpression_7Context::typeName() {
  return getRuleContext<PnfCParser::TypeNameContext>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__primaryExpression_7Context::Comma() {
  return getToken(PnfCParser::Comma, 0);
}

PnfCParser::UnaryExpressionContext* PnfCParser::Aux_rule__primaryExpression_7Context::unaryExpression() {
  return getRuleContext<PnfCParser::UnaryExpressionContext>(0);
}


size_t PnfCParser::Aux_rule__primaryExpression_7Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__primaryExpression_7;
}

void PnfCParser::Aux_rule__primaryExpression_7Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__primaryExpression_7(this);
}

void PnfCParser::Aux_rule__primaryExpression_7Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__primaryExpression_7(this);
}


antlrcpp::Any PnfCParser::Aux_rule__primaryExpression_7Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__primaryExpression_7(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__primaryExpression_7Context* PnfCParser::aux_rule__primaryExpression_7() {
  Aux_rule__primaryExpression_7Context *_localctx = _tracker.createInstance<Aux_rule__primaryExpression_7Context>(_ctx, getState());
  enterRule(_localctx, 476, PnfCParser::RuleAux_rule__primaryExpression_7);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1476);
    match(PnfCParser::T__11);
    setState(1477);
    match(PnfCParser::LeftParen);
    setState(1478);
    typeName();
    setState(1479);
    match(PnfCParser::Comma);
    setState(1480);
    unaryExpression();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__unaryExpression_9Context ------------------------------------------------------------------

PnfCParser::Aux_rule__unaryExpression_9Context::Aux_rule__unaryExpression_9Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__unaryExpression_9Context::Sizeof() {
  return getToken(PnfCParser::Sizeof, 0);
}

tree::TerminalNode* PnfCParser::Aux_rule__unaryExpression_9Context::LeftParen() {
  return getToken(PnfCParser::LeftParen, 0);
}

PnfCParser::TypeNameContext* PnfCParser::Aux_rule__unaryExpression_9Context::typeName() {
  return getRuleContext<PnfCParser::TypeNameContext>(0);
}


size_t PnfCParser::Aux_rule__unaryExpression_9Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__unaryExpression_9;
}

void PnfCParser::Aux_rule__unaryExpression_9Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__unaryExpression_9(this);
}

void PnfCParser::Aux_rule__unaryExpression_9Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__unaryExpression_9(this);
}


antlrcpp::Any PnfCParser::Aux_rule__unaryExpression_9Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__unaryExpression_9(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__unaryExpression_9Context* PnfCParser::aux_rule__unaryExpression_9() {
  Aux_rule__unaryExpression_9Context *_localctx = _tracker.createInstance<Aux_rule__unaryExpression_9Context>(_ctx, getState());
  enterRule(_localctx, 478, PnfCParser::RuleAux_rule__unaryExpression_9);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1482);
    match(PnfCParser::Sizeof);
    setState(1483);
    match(PnfCParser::LeftParen);
    setState(1484);
    typeName();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__unaryExpression_10Context ------------------------------------------------------------------

PnfCParser::Aux_rule__unaryExpression_10Context::Aux_rule__unaryExpression_10Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Altnt_block__unaryExpression_3Context* PnfCParser::Aux_rule__unaryExpression_10Context::altnt_block__unaryExpression_3() {
  return getRuleContext<PnfCParser::Altnt_block__unaryExpression_3Context>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__unaryExpression_10Context::LeftParen() {
  return getToken(PnfCParser::LeftParen, 0);
}

PnfCParser::Altnt_block__unaryExpression_4Context* PnfCParser::Aux_rule__unaryExpression_10Context::altnt_block__unaryExpression_4() {
  return getRuleContext<PnfCParser::Altnt_block__unaryExpression_4Context>(0);
}


size_t PnfCParser::Aux_rule__unaryExpression_10Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__unaryExpression_10;
}

void PnfCParser::Aux_rule__unaryExpression_10Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__unaryExpression_10(this);
}

void PnfCParser::Aux_rule__unaryExpression_10Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__unaryExpression_10(this);
}


antlrcpp::Any PnfCParser::Aux_rule__unaryExpression_10Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__unaryExpression_10(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__unaryExpression_10Context* PnfCParser::aux_rule__unaryExpression_10() {
  Aux_rule__unaryExpression_10Context *_localctx = _tracker.createInstance<Aux_rule__unaryExpression_10Context>(_ctx, getState());
  enterRule(_localctx, 480, PnfCParser::RuleAux_rule__unaryExpression_10);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1486);
    altnt_block__unaryExpression_3();
    setState(1487);
    match(PnfCParser::LeftParen);
    setState(1488);
    altnt_block__unaryExpression_4();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__typeSpecifier_4Context ------------------------------------------------------------------

PnfCParser::Aux_rule__typeSpecifier_4Context::Aux_rule__typeSpecifier_4Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__typeSpecifier_4Context::Extension_gcc() {
  return getToken(PnfCParser::Extension_gcc, 0);
}

tree::TerminalNode* PnfCParser::Aux_rule__typeSpecifier_4Context::LeftParen() {
  return getToken(PnfCParser::LeftParen, 0);
}

PnfCParser::Altnt_block__typeSpecifier_2Context* PnfCParser::Aux_rule__typeSpecifier_4Context::altnt_block__typeSpecifier_2() {
  return getRuleContext<PnfCParser::Altnt_block__typeSpecifier_2Context>(0);
}


size_t PnfCParser::Aux_rule__typeSpecifier_4Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__typeSpecifier_4;
}

void PnfCParser::Aux_rule__typeSpecifier_4Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__typeSpecifier_4(this);
}

void PnfCParser::Aux_rule__typeSpecifier_4Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__typeSpecifier_4(this);
}


antlrcpp::Any PnfCParser::Aux_rule__typeSpecifier_4Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__typeSpecifier_4(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__typeSpecifier_4Context* PnfCParser::aux_rule__typeSpecifier_4() {
  Aux_rule__typeSpecifier_4Context *_localctx = _tracker.createInstance<Aux_rule__typeSpecifier_4Context>(_ctx, getState());
  enterRule(_localctx, 482, PnfCParser::RuleAux_rule__typeSpecifier_4);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1490);
    match(PnfCParser::Extension_gcc);
    setState(1491);
    match(PnfCParser::LeftParen);
    setState(1492);
    altnt_block__typeSpecifier_2();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__typeSpecifier_5Context ------------------------------------------------------------------

PnfCParser::Aux_rule__typeSpecifier_5Context::Aux_rule__typeSpecifier_5Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__typeSpecifier_5Context::LeftParen() {
  return getToken(PnfCParser::LeftParen, 0);
}

PnfCParser::ConstantExpressionContext* PnfCParser::Aux_rule__typeSpecifier_5Context::constantExpression() {
  return getRuleContext<PnfCParser::ConstantExpressionContext>(0);
}


size_t PnfCParser::Aux_rule__typeSpecifier_5Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__typeSpecifier_5;
}

void PnfCParser::Aux_rule__typeSpecifier_5Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__typeSpecifier_5(this);
}

void PnfCParser::Aux_rule__typeSpecifier_5Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__typeSpecifier_5(this);
}


antlrcpp::Any PnfCParser::Aux_rule__typeSpecifier_5Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__typeSpecifier_5(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__typeSpecifier_5Context* PnfCParser::aux_rule__typeSpecifier_5() {
  Aux_rule__typeSpecifier_5Context *_localctx = _tracker.createInstance<Aux_rule__typeSpecifier_5Context>(_ctx, getState());
  enterRule(_localctx, 484, PnfCParser::RuleAux_rule__typeSpecifier_5);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1494);
    match(PnfCParser::T__12);
    setState(1495);
    match(PnfCParser::LeftParen);
    setState(1496);
    constantExpression();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__structOrUnionSpecifier_3Context ------------------------------------------------------------------

PnfCParser::Aux_rule__structOrUnionSpecifier_3Context::Aux_rule__structOrUnionSpecifier_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Optional__structOrUnionSpecifier_1Context* PnfCParser::Aux_rule__structOrUnionSpecifier_3Context::optional__structOrUnionSpecifier_1() {
  return getRuleContext<PnfCParser::Optional__structOrUnionSpecifier_1Context>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__structOrUnionSpecifier_3Context::LeftBrace() {
  return getToken(PnfCParser::LeftBrace, 0);
}

PnfCParser::StructDeclarationListContext* PnfCParser::Aux_rule__structOrUnionSpecifier_3Context::structDeclarationList() {
  return getRuleContext<PnfCParser::StructDeclarationListContext>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__structOrUnionSpecifier_3Context::RightBrace() {
  return getToken(PnfCParser::RightBrace, 0);
}


size_t PnfCParser::Aux_rule__structOrUnionSpecifier_3Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__structOrUnionSpecifier_3;
}

void PnfCParser::Aux_rule__structOrUnionSpecifier_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__structOrUnionSpecifier_3(this);
}

void PnfCParser::Aux_rule__structOrUnionSpecifier_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__structOrUnionSpecifier_3(this);
}


antlrcpp::Any PnfCParser::Aux_rule__structOrUnionSpecifier_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__structOrUnionSpecifier_3(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__structOrUnionSpecifier_3Context* PnfCParser::aux_rule__structOrUnionSpecifier_3() {
  Aux_rule__structOrUnionSpecifier_3Context *_localctx = _tracker.createInstance<Aux_rule__structOrUnionSpecifier_3Context>(_ctx, getState());
  enterRule(_localctx, 486, PnfCParser::RuleAux_rule__structOrUnionSpecifier_3);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1498);
    optional__structOrUnionSpecifier_1();
    setState(1499);
    match(PnfCParser::LeftBrace);
    setState(1500);
    structDeclarationList();
    setState(1501);
    match(PnfCParser::RightBrace);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__enumSpecifier_6Context ------------------------------------------------------------------

PnfCParser::Aux_rule__enumSpecifier_6Context::Aux_rule__enumSpecifier_6Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Altnt_block__enumSpecifier_4Context* PnfCParser::Aux_rule__enumSpecifier_6Context::altnt_block__enumSpecifier_4() {
  return getRuleContext<PnfCParser::Altnt_block__enumSpecifier_4Context>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__enumSpecifier_6Context::RightBrace() {
  return getToken(PnfCParser::RightBrace, 0);
}


size_t PnfCParser::Aux_rule__enumSpecifier_6Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__enumSpecifier_6;
}

void PnfCParser::Aux_rule__enumSpecifier_6Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__enumSpecifier_6(this);
}

void PnfCParser::Aux_rule__enumSpecifier_6Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__enumSpecifier_6(this);
}


antlrcpp::Any PnfCParser::Aux_rule__enumSpecifier_6Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__enumSpecifier_6(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__enumSpecifier_6Context* PnfCParser::aux_rule__enumSpecifier_6() {
  Aux_rule__enumSpecifier_6Context *_localctx = _tracker.createInstance<Aux_rule__enumSpecifier_6Context>(_ctx, getState());
  enterRule(_localctx, 488, PnfCParser::RuleAux_rule__enumSpecifier_6);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1503);
    altnt_block__enumSpecifier_4();
    setState(1504);
    match(PnfCParser::RightBrace);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__directDeclarator_16Context ------------------------------------------------------------------

PnfCParser::Aux_rule__directDeclarator_16Context::Aux_rule__directDeclarator_16Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Altnt_block__directDeclarator_11Context* PnfCParser::Aux_rule__directDeclarator_16Context::altnt_block__directDeclarator_11() {
  return getRuleContext<PnfCParser::Altnt_block__directDeclarator_11Context>(0);
}

PnfCParser::AssignmentExpressionContext* PnfCParser::Aux_rule__directDeclarator_16Context::assignmentExpression() {
  return getRuleContext<PnfCParser::AssignmentExpressionContext>(0);
}


size_t PnfCParser::Aux_rule__directDeclarator_16Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__directDeclarator_16;
}

void PnfCParser::Aux_rule__directDeclarator_16Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__directDeclarator_16(this);
}

void PnfCParser::Aux_rule__directDeclarator_16Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__directDeclarator_16(this);
}


antlrcpp::Any PnfCParser::Aux_rule__directDeclarator_16Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__directDeclarator_16(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__directDeclarator_16Context* PnfCParser::aux_rule__directDeclarator_16() {
  Aux_rule__directDeclarator_16Context *_localctx = _tracker.createInstance<Aux_rule__directDeclarator_16Context>(_ctx, getState());
  enterRule(_localctx, 490, PnfCParser::RuleAux_rule__directDeclarator_16);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1506);
    altnt_block__directDeclarator_11();
    setState(1507);
    assignmentExpression();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__directDeclarator_17Context ------------------------------------------------------------------

PnfCParser::Aux_rule__directDeclarator_17Context::Aux_rule__directDeclarator_17Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Optional__pointer_1Context* PnfCParser::Aux_rule__directDeclarator_17Context::optional__pointer_1() {
  return getRuleContext<PnfCParser::Optional__pointer_1Context>(0);
}

PnfCParser::Altnt_block__directDeclarator_12Context* PnfCParser::Aux_rule__directDeclarator_17Context::altnt_block__directDeclarator_12() {
  return getRuleContext<PnfCParser::Altnt_block__directDeclarator_12Context>(0);
}


size_t PnfCParser::Aux_rule__directDeclarator_17Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__directDeclarator_17;
}

void PnfCParser::Aux_rule__directDeclarator_17Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__directDeclarator_17(this);
}

void PnfCParser::Aux_rule__directDeclarator_17Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__directDeclarator_17(this);
}


antlrcpp::Any PnfCParser::Aux_rule__directDeclarator_17Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__directDeclarator_17(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__directDeclarator_17Context* PnfCParser::aux_rule__directDeclarator_17() {
  Aux_rule__directDeclarator_17Context *_localctx = _tracker.createInstance<Aux_rule__directDeclarator_17Context>(_ctx, getState());
  enterRule(_localctx, 492, PnfCParser::RuleAux_rule__directDeclarator_17);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1509);
    optional__pointer_1();
    setState(1510);
    altnt_block__directDeclarator_12();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__directAbstractDeclarator_25Context ------------------------------------------------------------------

PnfCParser::Aux_rule__directAbstractDeclarator_25Context::Aux_rule__directAbstractDeclarator_25Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Optional__pointer_1Context* PnfCParser::Aux_rule__directAbstractDeclarator_25Context::optional__pointer_1() {
  return getRuleContext<PnfCParser::Optional__pointer_1Context>(0);
}

PnfCParser::Optional__directDeclarator_2Context* PnfCParser::Aux_rule__directAbstractDeclarator_25Context::optional__directDeclarator_2() {
  return getRuleContext<PnfCParser::Optional__directDeclarator_2Context>(0);
}


size_t PnfCParser::Aux_rule__directAbstractDeclarator_25Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__directAbstractDeclarator_25;
}

void PnfCParser::Aux_rule__directAbstractDeclarator_25Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__directAbstractDeclarator_25(this);
}

void PnfCParser::Aux_rule__directAbstractDeclarator_25Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__directAbstractDeclarator_25(this);
}


antlrcpp::Any PnfCParser::Aux_rule__directAbstractDeclarator_25Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__directAbstractDeclarator_25(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__directAbstractDeclarator_25Context* PnfCParser::aux_rule__directAbstractDeclarator_25() {
  Aux_rule__directAbstractDeclarator_25Context *_localctx = _tracker.createInstance<Aux_rule__directAbstractDeclarator_25Context>(_ctx, getState());
  enterRule(_localctx, 494, PnfCParser::RuleAux_rule__directAbstractDeclarator_25);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1512);
    optional__pointer_1();
    setState(1513);
    optional__directDeclarator_2();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__directAbstractDeclarator_26Context ------------------------------------------------------------------

PnfCParser::Aux_rule__directAbstractDeclarator_26Context::Aux_rule__directAbstractDeclarator_26Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Altnt_block__directDeclarator_11Context* PnfCParser::Aux_rule__directAbstractDeclarator_26Context::altnt_block__directDeclarator_11() {
  return getRuleContext<PnfCParser::Altnt_block__directDeclarator_11Context>(0);
}

PnfCParser::AssignmentExpressionContext* PnfCParser::Aux_rule__directAbstractDeclarator_26Context::assignmentExpression() {
  return getRuleContext<PnfCParser::AssignmentExpressionContext>(0);
}


size_t PnfCParser::Aux_rule__directAbstractDeclarator_26Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__directAbstractDeclarator_26;
}

void PnfCParser::Aux_rule__directAbstractDeclarator_26Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__directAbstractDeclarator_26(this);
}

void PnfCParser::Aux_rule__directAbstractDeclarator_26Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__directAbstractDeclarator_26(this);
}


antlrcpp::Any PnfCParser::Aux_rule__directAbstractDeclarator_26Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__directAbstractDeclarator_26(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__directAbstractDeclarator_26Context* PnfCParser::aux_rule__directAbstractDeclarator_26() {
  Aux_rule__directAbstractDeclarator_26Context *_localctx = _tracker.createInstance<Aux_rule__directAbstractDeclarator_26Context>(_ctx, getState());
  enterRule(_localctx, 496, PnfCParser::RuleAux_rule__directAbstractDeclarator_26);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1515);
    altnt_block__directDeclarator_11();
    setState(1516);
    assignmentExpression();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__labeledStatement_2Context ------------------------------------------------------------------

PnfCParser::Aux_rule__labeledStatement_2Context::Aux_rule__labeledStatement_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__labeledStatement_2Context::Case() {
  return getToken(PnfCParser::Case, 0);
}

PnfCParser::ConstantExpressionContext* PnfCParser::Aux_rule__labeledStatement_2Context::constantExpression() {
  return getRuleContext<PnfCParser::ConstantExpressionContext>(0);
}


size_t PnfCParser::Aux_rule__labeledStatement_2Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__labeledStatement_2;
}

void PnfCParser::Aux_rule__labeledStatement_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__labeledStatement_2(this);
}

void PnfCParser::Aux_rule__labeledStatement_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__labeledStatement_2(this);
}


antlrcpp::Any PnfCParser::Aux_rule__labeledStatement_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__labeledStatement_2(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__labeledStatement_2Context* PnfCParser::aux_rule__labeledStatement_2() {
  Aux_rule__labeledStatement_2Context *_localctx = _tracker.createInstance<Aux_rule__labeledStatement_2Context>(_ctx, getState());
  enterRule(_localctx, 498, PnfCParser::RuleAux_rule__labeledStatement_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1518);
    match(PnfCParser::Case);
    setState(1519);
    constantExpression();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__jumpStatement_4Context ------------------------------------------------------------------

PnfCParser::Aux_rule__jumpStatement_4Context::Aux_rule__jumpStatement_4Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__jumpStatement_4Context::Return() {
  return getToken(PnfCParser::Return, 0);
}

PnfCParser::Optional__postfixExpression_1Context* PnfCParser::Aux_rule__jumpStatement_4Context::optional__postfixExpression_1() {
  return getRuleContext<PnfCParser::Optional__postfixExpression_1Context>(0);
}


size_t PnfCParser::Aux_rule__jumpStatement_4Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__jumpStatement_4;
}

void PnfCParser::Aux_rule__jumpStatement_4Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__jumpStatement_4(this);
}

void PnfCParser::Aux_rule__jumpStatement_4Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__jumpStatement_4(this);
}


antlrcpp::Any PnfCParser::Aux_rule__jumpStatement_4Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__jumpStatement_4(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__jumpStatement_4Context* PnfCParser::aux_rule__jumpStatement_4() {
  Aux_rule__jumpStatement_4Context *_localctx = _tracker.createInstance<Aux_rule__jumpStatement_4Context>(_ctx, getState());
  enterRule(_localctx, 500, PnfCParser::RuleAux_rule__jumpStatement_4);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1521);
    match(PnfCParser::Return);
    setState(1522);
    optional__postfixExpression_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__jumpStatement_5Context ------------------------------------------------------------------

PnfCParser::Aux_rule__jumpStatement_5Context::Aux_rule__jumpStatement_5Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__jumpStatement_5Context::Goto() {
  return getToken(PnfCParser::Goto, 0);
}

PnfCParser::Altnt_block__jumpStatement_3Context* PnfCParser::Aux_rule__jumpStatement_5Context::altnt_block__jumpStatement_3() {
  return getRuleContext<PnfCParser::Altnt_block__jumpStatement_3Context>(0);
}


size_t PnfCParser::Aux_rule__jumpStatement_5Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__jumpStatement_5;
}

void PnfCParser::Aux_rule__jumpStatement_5Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__jumpStatement_5(this);
}

void PnfCParser::Aux_rule__jumpStatement_5Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__jumpStatement_5(this);
}


antlrcpp::Any PnfCParser::Aux_rule__jumpStatement_5Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__jumpStatement_5(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__jumpStatement_5Context* PnfCParser::aux_rule__jumpStatement_5() {
  Aux_rule__jumpStatement_5Context *_localctx = _tracker.createInstance<Aux_rule__jumpStatement_5Context>(_ctx, getState());
  enterRule(_localctx, 502, PnfCParser::RuleAux_rule__jumpStatement_5);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1524);
    match(PnfCParser::Goto);
    setState(1525);
    altnt_block__jumpStatement_3();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__directDeclarator_18Context ------------------------------------------------------------------

PnfCParser::Aux_rule__directDeclarator_18Context::Aux_rule__directDeclarator_18Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__directDeclarator_18Context::Static() {
  return getToken(PnfCParser::Static, 0);
}

PnfCParser::Optional__pointer_1Context* PnfCParser::Aux_rule__directDeclarator_18Context::optional__pointer_1() {
  return getRuleContext<PnfCParser::Optional__pointer_1Context>(0);
}


size_t PnfCParser::Aux_rule__directDeclarator_18Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__directDeclarator_18;
}

void PnfCParser::Aux_rule__directDeclarator_18Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__directDeclarator_18(this);
}

void PnfCParser::Aux_rule__directDeclarator_18Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__directDeclarator_18(this);
}


antlrcpp::Any PnfCParser::Aux_rule__directDeclarator_18Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__directDeclarator_18(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__directDeclarator_18Context* PnfCParser::aux_rule__directDeclarator_18() {
  Aux_rule__directDeclarator_18Context *_localctx = _tracker.createInstance<Aux_rule__directDeclarator_18Context>(_ctx, getState());
  enterRule(_localctx, 504, PnfCParser::RuleAux_rule__directDeclarator_18);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1527);
    match(PnfCParser::Static);
    setState(1528);
    optional__pointer_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__directDeclarator_19Context ------------------------------------------------------------------

PnfCParser::Aux_rule__directDeclarator_19Context::Aux_rule__directDeclarator_19Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::TypeQualifierListContext* PnfCParser::Aux_rule__directDeclarator_19Context::typeQualifierList() {
  return getRuleContext<PnfCParser::TypeQualifierListContext>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__directDeclarator_19Context::Static() {
  return getToken(PnfCParser::Static, 0);
}


size_t PnfCParser::Aux_rule__directDeclarator_19Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__directDeclarator_19;
}

void PnfCParser::Aux_rule__directDeclarator_19Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__directDeclarator_19(this);
}

void PnfCParser::Aux_rule__directDeclarator_19Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__directDeclarator_19(this);
}


antlrcpp::Any PnfCParser::Aux_rule__directDeclarator_19Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__directDeclarator_19(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__directDeclarator_19Context* PnfCParser::aux_rule__directDeclarator_19() {
  Aux_rule__directDeclarator_19Context *_localctx = _tracker.createInstance<Aux_rule__directDeclarator_19Context>(_ctx, getState());
  enterRule(_localctx, 506, PnfCParser::RuleAux_rule__directDeclarator_19);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1530);
    typeQualifierList();
    setState(1531);
    match(PnfCParser::Static);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__postfixExpression_13Context ------------------------------------------------------------------

PnfCParser::Aux_rule__postfixExpression_13Context::Aux_rule__postfixExpression_13Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Altnt_block__primaryExpression_3Context* PnfCParser::Aux_rule__postfixExpression_13Context::altnt_block__primaryExpression_3() {
  return getRuleContext<PnfCParser::Altnt_block__primaryExpression_3Context>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__postfixExpression_13Context::RightParen() {
  return getToken(PnfCParser::RightParen, 0);
}


size_t PnfCParser::Aux_rule__postfixExpression_13Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__postfixExpression_13;
}

void PnfCParser::Aux_rule__postfixExpression_13Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__postfixExpression_13(this);
}

void PnfCParser::Aux_rule__postfixExpression_13Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__postfixExpression_13(this);
}


antlrcpp::Any PnfCParser::Aux_rule__postfixExpression_13Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__postfixExpression_13(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__postfixExpression_13Context* PnfCParser::aux_rule__postfixExpression_13() {
  Aux_rule__postfixExpression_13Context *_localctx = _tracker.createInstance<Aux_rule__postfixExpression_13Context>(_ctx, getState());
  enterRule(_localctx, 508, PnfCParser::RuleAux_rule__postfixExpression_13);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1533);
    altnt_block__primaryExpression_3();
    setState(1534);
    match(PnfCParser::RightParen);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__postfixExpression_14Context ------------------------------------------------------------------

PnfCParser::Aux_rule__postfixExpression_14Context::Aux_rule__postfixExpression_14Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Altnt_block__postfixExpression_8Context* PnfCParser::Aux_rule__postfixExpression_14Context::altnt_block__postfixExpression_8() {
  return getRuleContext<PnfCParser::Altnt_block__postfixExpression_8Context>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__postfixExpression_14Context::RightBrace() {
  return getToken(PnfCParser::RightBrace, 0);
}


size_t PnfCParser::Aux_rule__postfixExpression_14Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__postfixExpression_14;
}

void PnfCParser::Aux_rule__postfixExpression_14Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__postfixExpression_14(this);
}

void PnfCParser::Aux_rule__postfixExpression_14Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__postfixExpression_14(this);
}


antlrcpp::Any PnfCParser::Aux_rule__postfixExpression_14Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__postfixExpression_14(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__postfixExpression_14Context* PnfCParser::aux_rule__postfixExpression_14() {
  Aux_rule__postfixExpression_14Context *_localctx = _tracker.createInstance<Aux_rule__postfixExpression_14Context>(_ctx, getState());
  enterRule(_localctx, 510, PnfCParser::RuleAux_rule__postfixExpression_14);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1536);
    altnt_block__postfixExpression_8();
    setState(1537);
    match(PnfCParser::RightBrace);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__declarationSpecifier_1Context ------------------------------------------------------------------

PnfCParser::Aux_rule__declarationSpecifier_1Context::Aux_rule__declarationSpecifier_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__declarationSpecifier_1Context::LeftParen() {
  return getToken(PnfCParser::LeftParen, 0);
}

tree::TerminalNode* PnfCParser::Aux_rule__declarationSpecifier_1Context::Identifier() {
  return getToken(PnfCParser::Identifier, 0);
}

tree::TerminalNode* PnfCParser::Aux_rule__declarationSpecifier_1Context::RightParen() {
  return getToken(PnfCParser::RightParen, 0);
}


size_t PnfCParser::Aux_rule__declarationSpecifier_1Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__declarationSpecifier_1;
}

void PnfCParser::Aux_rule__declarationSpecifier_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__declarationSpecifier_1(this);
}

void PnfCParser::Aux_rule__declarationSpecifier_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__declarationSpecifier_1(this);
}


antlrcpp::Any PnfCParser::Aux_rule__declarationSpecifier_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__declarationSpecifier_1(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__declarationSpecifier_1Context* PnfCParser::aux_rule__declarationSpecifier_1() {
  Aux_rule__declarationSpecifier_1Context *_localctx = _tracker.createInstance<Aux_rule__declarationSpecifier_1Context>(_ctx, getState());
  enterRule(_localctx, 512, PnfCParser::RuleAux_rule__declarationSpecifier_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1539);
    match(PnfCParser::T__13);
    setState(1540);
    match(PnfCParser::LeftParen);
    setState(1541);
    match(PnfCParser::Identifier);
    setState(1542);
    match(PnfCParser::RightParen);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__structDeclarationList_4Context ------------------------------------------------------------------

PnfCParser::Aux_rule__structDeclarationList_4Context::Aux_rule__structDeclarationList_4Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Optional__declaration_1Context* PnfCParser::Aux_rule__structDeclarationList_4Context::optional__declaration_1() {
  return getRuleContext<PnfCParser::Optional__declaration_1Context>(0);
}

PnfCParser::SpecifierQualifierListContext* PnfCParser::Aux_rule__structDeclarationList_4Context::specifierQualifierList() {
  return getRuleContext<PnfCParser::SpecifierQualifierListContext>(0);
}

PnfCParser::Optional__structDeclaration_2Context* PnfCParser::Aux_rule__structDeclarationList_4Context::optional__structDeclaration_2() {
  return getRuleContext<PnfCParser::Optional__structDeclaration_2Context>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__structDeclarationList_4Context::Semi() {
  return getToken(PnfCParser::Semi, 0);
}


size_t PnfCParser::Aux_rule__structDeclarationList_4Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__structDeclarationList_4;
}

void PnfCParser::Aux_rule__structDeclarationList_4Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__structDeclarationList_4(this);
}

void PnfCParser::Aux_rule__structDeclarationList_4Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__structDeclarationList_4(this);
}


antlrcpp::Any PnfCParser::Aux_rule__structDeclarationList_4Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__structDeclarationList_4(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__structDeclarationList_4Context* PnfCParser::aux_rule__structDeclarationList_4() {
  Aux_rule__structDeclarationList_4Context *_localctx = _tracker.createInstance<Aux_rule__structDeclarationList_4Context>(_ctx, getState());
  enterRule(_localctx, 514, PnfCParser::RuleAux_rule__structDeclarationList_4);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1544);
    optional__declaration_1();
    setState(1545);
    specifierQualifierList();
    setState(1546);
    optional__structDeclaration_2();
    setState(1547);
    match(PnfCParser::Semi);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__designatorList_4Context ------------------------------------------------------------------

PnfCParser::Aux_rule__designatorList_4Context::Aux_rule__designatorList_4Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__designatorList_4Context::LeftBracket() {
  return getToken(PnfCParser::LeftBracket, 0);
}

PnfCParser::ConstantExpressionContext* PnfCParser::Aux_rule__designatorList_4Context::constantExpression() {
  return getRuleContext<PnfCParser::ConstantExpressionContext>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__designatorList_4Context::RightBracket() {
  return getToken(PnfCParser::RightBracket, 0);
}


size_t PnfCParser::Aux_rule__designatorList_4Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__designatorList_4;
}

void PnfCParser::Aux_rule__designatorList_4Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__designatorList_4(this);
}

void PnfCParser::Aux_rule__designatorList_4Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__designatorList_4(this);
}


antlrcpp::Any PnfCParser::Aux_rule__designatorList_4Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__designatorList_4(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__designatorList_4Context* PnfCParser::aux_rule__designatorList_4() {
  Aux_rule__designatorList_4Context *_localctx = _tracker.createInstance<Aux_rule__designatorList_4Context>(_ctx, getState());
  enterRule(_localctx, 516, PnfCParser::RuleAux_rule__designatorList_4);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1549);
    match(PnfCParser::LeftBracket);
    setState(1550);
    constantExpression();
    setState(1551);
    match(PnfCParser::RightBracket);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__designatorList_5Context ------------------------------------------------------------------

PnfCParser::Aux_rule__designatorList_5Context::Aux_rule__designatorList_5Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__designatorList_5Context::Dot() {
  return getToken(PnfCParser::Dot, 0);
}

tree::TerminalNode* PnfCParser::Aux_rule__designatorList_5Context::Identifier() {
  return getToken(PnfCParser::Identifier, 0);
}


size_t PnfCParser::Aux_rule__designatorList_5Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__designatorList_5;
}

void PnfCParser::Aux_rule__designatorList_5Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__designatorList_5(this);
}

void PnfCParser::Aux_rule__designatorList_5Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__designatorList_5(this);
}


antlrcpp::Any PnfCParser::Aux_rule__designatorList_5Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__designatorList_5(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__designatorList_5Context* PnfCParser::aux_rule__designatorList_5() {
  Aux_rule__designatorList_5Context *_localctx = _tracker.createInstance<Aux_rule__designatorList_5Context>(_ctx, getState());
  enterRule(_localctx, 518, PnfCParser::RuleAux_rule__designatorList_5);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1553);
    match(PnfCParser::Dot);
    setState(1554);
    match(PnfCParser::Identifier);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__statement_3Context ------------------------------------------------------------------

PnfCParser::Aux_rule__statement_3Context::Aux_rule__statement_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__statement_3Context::If() {
  return getToken(PnfCParser::If, 0);
}

tree::TerminalNode* PnfCParser::Aux_rule__statement_3Context::LeftParen() {
  return getToken(PnfCParser::LeftParen, 0);
}

PnfCParser::ExpressionContext* PnfCParser::Aux_rule__statement_3Context::expression() {
  return getRuleContext<PnfCParser::ExpressionContext>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__statement_3Context::RightParen() {
  return getToken(PnfCParser::RightParen, 0);
}

PnfCParser::StatementContext* PnfCParser::Aux_rule__statement_3Context::statement() {
  return getRuleContext<PnfCParser::StatementContext>(0);
}

PnfCParser::Optional__selectionStatement_2Context* PnfCParser::Aux_rule__statement_3Context::optional__selectionStatement_2() {
  return getRuleContext<PnfCParser::Optional__selectionStatement_2Context>(0);
}


size_t PnfCParser::Aux_rule__statement_3Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__statement_3;
}

void PnfCParser::Aux_rule__statement_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__statement_3(this);
}

void PnfCParser::Aux_rule__statement_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__statement_3(this);
}


antlrcpp::Any PnfCParser::Aux_rule__statement_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__statement_3(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__statement_3Context* PnfCParser::aux_rule__statement_3() {
  Aux_rule__statement_3Context *_localctx = _tracker.createInstance<Aux_rule__statement_3Context>(_ctx, getState());
  enterRule(_localctx, 520, PnfCParser::RuleAux_rule__statement_3);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1556);
    match(PnfCParser::If);
    setState(1557);
    match(PnfCParser::LeftParen);
    setState(1558);
    expression();
    setState(1559);
    match(PnfCParser::RightParen);
    setState(1560);
    statement();
    setState(1561);
    optional__selectionStatement_2();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__statement_4Context ------------------------------------------------------------------

PnfCParser::Aux_rule__statement_4Context::Aux_rule__statement_4Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__statement_4Context::Do() {
  return getToken(PnfCParser::Do, 0);
}

PnfCParser::StatementContext* PnfCParser::Aux_rule__statement_4Context::statement() {
  return getRuleContext<PnfCParser::StatementContext>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__statement_4Context::While() {
  return getToken(PnfCParser::While, 0);
}

tree::TerminalNode* PnfCParser::Aux_rule__statement_4Context::LeftParen() {
  return getToken(PnfCParser::LeftParen, 0);
}

PnfCParser::ExpressionContext* PnfCParser::Aux_rule__statement_4Context::expression() {
  return getRuleContext<PnfCParser::ExpressionContext>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__statement_4Context::RightParen() {
  return getToken(PnfCParser::RightParen, 0);
}

tree::TerminalNode* PnfCParser::Aux_rule__statement_4Context::Semi() {
  return getToken(PnfCParser::Semi, 0);
}


size_t PnfCParser::Aux_rule__statement_4Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__statement_4;
}

void PnfCParser::Aux_rule__statement_4Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__statement_4(this);
}

void PnfCParser::Aux_rule__statement_4Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__statement_4(this);
}


antlrcpp::Any PnfCParser::Aux_rule__statement_4Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__statement_4(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__statement_4Context* PnfCParser::aux_rule__statement_4() {
  Aux_rule__statement_4Context *_localctx = _tracker.createInstance<Aux_rule__statement_4Context>(_ctx, getState());
  enterRule(_localctx, 522, PnfCParser::RuleAux_rule__statement_4);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1563);
    match(PnfCParser::Do);
    setState(1564);
    statement();
    setState(1565);
    match(PnfCParser::While);
    setState(1566);
    match(PnfCParser::LeftParen);
    setState(1567);
    expression();
    setState(1568);
    match(PnfCParser::RightParen);
    setState(1569);
    match(PnfCParser::Semi);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__statement_5Context ------------------------------------------------------------------

PnfCParser::Aux_rule__statement_5Context::Aux_rule__statement_5Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Altnt_block__statement_1Context* PnfCParser::Aux_rule__statement_5Context::altnt_block__statement_1() {
  return getRuleContext<PnfCParser::Altnt_block__statement_1Context>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__statement_5Context::RightParen() {
  return getToken(PnfCParser::RightParen, 0);
}

PnfCParser::StatementContext* PnfCParser::Aux_rule__statement_5Context::statement() {
  return getRuleContext<PnfCParser::StatementContext>(0);
}


size_t PnfCParser::Aux_rule__statement_5Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__statement_5;
}

void PnfCParser::Aux_rule__statement_5Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__statement_5(this);
}

void PnfCParser::Aux_rule__statement_5Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__statement_5(this);
}


antlrcpp::Any PnfCParser::Aux_rule__statement_5Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__statement_5(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__statement_5Context* PnfCParser::aux_rule__statement_5() {
  Aux_rule__statement_5Context *_localctx = _tracker.createInstance<Aux_rule__statement_5Context>(_ctx, getState());
  enterRule(_localctx, 524, PnfCParser::RuleAux_rule__statement_5);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1571);
    altnt_block__statement_1();
    setState(1572);
    match(PnfCParser::RightParen);
    setState(1573);
    statement();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__iterationStatement_9Context ------------------------------------------------------------------

PnfCParser::Aux_rule__iterationStatement_9Context::Aux_rule__iterationStatement_9Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Optional__postfixExpression_1Context* PnfCParser::Aux_rule__iterationStatement_9Context::optional__postfixExpression_1() {
  return getRuleContext<PnfCParser::Optional__postfixExpression_1Context>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__iterationStatement_9Context::Semi() {
  return getToken(PnfCParser::Semi, 0);
}


size_t PnfCParser::Aux_rule__iterationStatement_9Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__iterationStatement_9;
}

void PnfCParser::Aux_rule__iterationStatement_9Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__iterationStatement_9(this);
}

void PnfCParser::Aux_rule__iterationStatement_9Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__iterationStatement_9(this);
}


antlrcpp::Any PnfCParser::Aux_rule__iterationStatement_9Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__iterationStatement_9(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__iterationStatement_9Context* PnfCParser::aux_rule__iterationStatement_9() {
  Aux_rule__iterationStatement_9Context *_localctx = _tracker.createInstance<Aux_rule__iterationStatement_9Context>(_ctx, getState());
  enterRule(_localctx, 526, PnfCParser::RuleAux_rule__iterationStatement_9);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1575);
    optional__postfixExpression_1();
    setState(1576);
    match(PnfCParser::Semi);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__statement_6Context ------------------------------------------------------------------

PnfCParser::Aux_rule__statement_6Context::Aux_rule__statement_6Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfCParser::Aux_rule__statement_6Context::For() {
  return getToken(PnfCParser::For, 0);
}

tree::TerminalNode* PnfCParser::Aux_rule__statement_6Context::LeftParen() {
  return getToken(PnfCParser::LeftParen, 0);
}

PnfCParser::Altnt_block__iterationStatement_7Context* PnfCParser::Aux_rule__statement_6Context::altnt_block__iterationStatement_7() {
  return getRuleContext<PnfCParser::Altnt_block__iterationStatement_7Context>(0);
}


size_t PnfCParser::Aux_rule__statement_6Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__statement_6;
}

void PnfCParser::Aux_rule__statement_6Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__statement_6(this);
}

void PnfCParser::Aux_rule__statement_6Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__statement_6(this);
}


antlrcpp::Any PnfCParser::Aux_rule__statement_6Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__statement_6(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__statement_6Context* PnfCParser::aux_rule__statement_6() {
  Aux_rule__statement_6Context *_localctx = _tracker.createInstance<Aux_rule__statement_6Context>(_ctx, getState());
  enterRule(_localctx, 528, PnfCParser::RuleAux_rule__statement_6);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1578);
    match(PnfCParser::For);
    setState(1579);
    match(PnfCParser::LeftParen);
    setState(1580);
    altnt_block__iterationStatement_7();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__statement_7Context ------------------------------------------------------------------

PnfCParser::Aux_rule__statement_7Context::Aux_rule__statement_7Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfCParser::Altnt_block__statement_2Context* PnfCParser::Aux_rule__statement_7Context::altnt_block__statement_2() {
  return getRuleContext<PnfCParser::Altnt_block__statement_2Context>(0);
}

tree::TerminalNode* PnfCParser::Aux_rule__statement_7Context::LeftParen() {
  return getToken(PnfCParser::LeftParen, 0);
}

PnfCParser::ExpressionContext* PnfCParser::Aux_rule__statement_7Context::expression() {
  return getRuleContext<PnfCParser::ExpressionContext>(0);
}


size_t PnfCParser::Aux_rule__statement_7Context::getRuleIndex() const {
  return PnfCParser::RuleAux_rule__statement_7;
}

void PnfCParser::Aux_rule__statement_7Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__statement_7(this);
}

void PnfCParser::Aux_rule__statement_7Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfCListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__statement_7(this);
}


antlrcpp::Any PnfCParser::Aux_rule__statement_7Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfCVisitor*>(visitor))
    return parserVisitor->visitAux_rule__statement_7(this);
  else
    return visitor->visitChildren(this);
}

PnfCParser::Aux_rule__statement_7Context* PnfCParser::aux_rule__statement_7() {
  Aux_rule__statement_7Context *_localctx = _tracker.createInstance<Aux_rule__statement_7Context>(_ctx, getState());
  enterRule(_localctx, 530, PnfCParser::RuleAux_rule__statement_7);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1582);
    altnt_block__statement_2();
    setState(1583);
    match(PnfCParser::LeftParen);
    setState(1584);
    expression();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

// Static vars and initialization.
std::vector<dfa::DFA> PnfCParser::_decisionToDFA;
atn::PredictionContextCache PnfCParser::_sharedContextCache;

// We own the ATN which in turn owns the ATN states.
atn::ATN PnfCParser::_atn;
std::vector<uint16_t> PnfCParser::_serializedATN;

std::vector<std::string> PnfCParser::_ruleNames = {
  "genericSelection", "genericAssociation", "unaryExpression", "unaryOperator", 
  "castExpression", "conditionalExpression", "assignmentExpression", "assignmentOperator", 
  "constantExpression", "declaration", "declarationSpecifiers", "initDeclarator", 
  "typeSpecifier", "structOrUnionSpecifier", "structOrUnion", "specifierQualifierList", 
  "structDeclarator", "enumSpecifier", "enumerator", "atomicTypeSpecifier", 
  "typeQualifier", "alignmentSpecifier", "declarator", "gccDeclaratorExtension", 
  "asmKeyword", "gccAttributeSpecifier", "gccAttributeList", "gccAttribute", 
  "pointer", "parameterTypeList", "parameterDeclaration", "typeName", "abstractDeclarator", 
  "typedefName", "initializer", "designation", "staticAssertDeclaration", 
  "asmStatement", "labeledStatement", "compoundStatement", "expressionStatement", 
  "jumpStatement", "compilationUnit", "functionDefinition", "kleene_plus__primaryExpression_1", 
  "optional__primaryExpression_2", "optional__postfixExpression_1", "aux_rule__conditionalExpression_1", 
  "optional__conditionalExpression_2", "optional__declaration_1", "optional__declaration_2", 
  "optional__structOrUnionSpecifier_1", "optional__structDeclaration_2", 
  "optional__specifierQualifierList_1", "optional__structDeclarator_1", 
  "optional__declarator_1", "kleene_star__declarator_2", "optional__directDeclarator_2", 
  "optional__directDeclarator_5", "aux_rule__gccAttributeList_1", "kleene_star__gccAttributeList_2", 
  "aux_rule__gccAttributeList_3", "aux_rule__gccAttribute_2", "optional__gccAttribute_3", 
  "aux_rule__gccAttribute_4", "optional__pointer_1", "optional__typeName_1", 
  "optional__directAbstractDeclarator_5", "optional__initializerList_1", 
  "aux_rule__asmStatement_1", "optional__asmStatement_2", "aux_rule__asmStatement_3", 
  "kleene_star__asmStatement_4", "aux_rule__asmStatement_5", "optional__asmStatement_6", 
  "aux_rule__asmStatement_11", "kleene_star__asmStatement_12", "optional__compoundStatement_1", 
  "aux_rule__selectionStatement_1", "optional__selectionStatement_2", "optional__compilationUnit_1", 
  "optional__functionDefinition_2", "optional__functionDefinition_3", "aux_rule__expression_2", 
  "kleene_star__expression_1", "expression", "aux_rule__genericAssocList_2", 
  "kleene_star__genericAssocList_1", "genericAssocList", "aux_rule__postfixExpression_3", 
  "kleene_star__postfixExpression_2", "postfixExpression", "aux_rule__initializerList_4", 
  "kleene_star__initializerList_3", "initializerList", "aux_rule__multiplicativeExpression_2", 
  "kleene_star__multiplicativeExpression_1", "multiplicativeExpression", 
  "aux_rule__additiveExpression_2", "kleene_star__additiveExpression_1", 
  "additiveExpression", "aux_rule__shiftExpression_2", "kleene_star__shiftExpression_1", 
  "shiftExpression", "aux_rule__relationalExpression_2", "kleene_star__relationalExpression_1", 
  "relationalExpression", "aux_rule__equalityExpression_2", "kleene_star__equalityExpression_1", 
  "equalityExpression", "aux_rule__andExpression_2", "kleene_star__andExpression_1", 
  "andExpression", "aux_rule__exclusiveOrExpression_2", "kleene_star__exclusiveOrExpression_1", 
  "exclusiveOrExpression", "aux_rule__inclusiveOrExpression_2", "kleene_star__inclusiveOrExpression_1", 
  "inclusiveOrExpression", "aux_rule__logicalAndExpression_2", "kleene_star__logicalAndExpression_1", 
  "logicalAndExpression", "aux_rule__logicalOrExpression_2", "kleene_star__logicalOrExpression_1", 
  "logicalOrExpression", "aux_rule__initDeclaratorList_2", "kleene_star__initDeclaratorList_1", 
  "initDeclaratorList", "structDeclarationList", "aux_rule__structDeclaratorList_2", 
  "kleene_star__structDeclaratorList_1", "structDeclaratorList", "aux_rule__enumeratorList_2", 
  "kleene_star__enumeratorList_1", "enumeratorList", "aux_rule__directDeclarator_7", 
  "kleene_star__directDeclarator_6", "aux_rule__directDeclarator_8", "directDeclarator", 
  "aux_rule__typeQualifierList_2", "typeQualifierList", "aux_rule__identifierList_2", 
  "kleene_star__identifierList_1", "identifierList", "aux_rule__parameterList_2", 
  "kleene_star__parameterList_1", "parameterList", "aux_rule__directAbstractDeclarator_13", 
  "kleene_star__directAbstractDeclarator_12", "aux_rule__directAbstractDeclarator_14", 
  "directAbstractDeclarator", "designatorList", "blockItemList", "translationUnit", 
  "aux_rule__declarationList_2", "declarationList", "kleene_plus__structDeclarationList_3", 
  "kleene_plus__typeQualifierList_3", "kleene_plus__designatorList_3", "kleene_plus__blockItemList_3", 
  "kleene_plus__translationUnit_3", "kleene_plus__declarationList_3", "optional__postfixExpression_5", 
  "aux_rule__initDeclarator_1", "optional__initDeclarator_2", "aux_rule__enumerator_1", 
  "optional__enumerator_2", "aux_rule__parameterTypeList_1", "optional__parameterTypeList_2", 
  "altnt_block__primaryExpression_3", "altnt_block__unaryExpression_1", 
  "altnt_block__unaryExpression_2", "altnt_block__genericAssociation_1", 
  "altnt_block__postfixExpression_7", "altnt_block__postfixExpression_8", 
  "altnt_block__multiplicativeExpression_3", "altnt_block__additiveExpression_3", 
  "altnt_block__shiftExpression_3", "altnt_block__relationalExpression_3", 
  "altnt_block__equalityExpression_3", "altnt_block__typeSpecifier_1", "altnt_block__alignmentSpecifier_1", 
  "altnt_block__structOrUnionSpecifier_2", "altnt_block__enumSpecifier_3", 
  "altnt_block__pointer_5", "altnt_block__directDeclarator_9", "altnt_block__directDeclarator_10", 
  "altnt_block__directAbstractDeclarator_15", "altnt_block__directAbstractDeclarator_17", 
  "altnt_block__labeledStatement_1", "altnt_block__jumpStatement_2", "altnt_block__enumSpecifier_4", 
  "altnt_block__directDeclarator_11", "altnt_block__iterationStatement_7", 
  "altnt_block__jumpStatement_3", "aux_rule__postfixExpression_4", "declarationSpecifier", 
  "aux_rule__structDeclarationList_2", "aux_rule__designatorList_2", "statement", 
  "aux_rule__blockItemList_2", "aux_rule__translationUnit_2", "altnt_block__unaryExpression_3", 
  "altnt_block__unaryExpression_4", "altnt_block__typeSpecifier_2", "altnt_block__specifierQualifierList_3", 
  "altnt_block__pointer_8", "altnt_block__directDeclarator_12", "altnt_block__parameterDeclaration_2", 
  "altnt_block__directAbstractDeclarator_20", "altnt_block__iterationStatement_8", 
  "altnt_block__statement_1", "altnt_block__statement_2", "aux_rule__unaryExpression_5", 
  "aux_rule__unaryExpression_6", "aux_rule__unaryExpression_7", "aux_rule__unaryExpression_8", 
  "aux_rule__castExpression_2", "aux_rule__assignmentExpression_1", "aux_rule__declaration_3", 
  "aux_rule__typeSpecifier_3", "aux_rule__structDeclarator_2", "aux_rule__gccDeclaratorExtension_2", 
  "aux_rule__abstractDeclarator_3", "aux_rule__initializer_2", "aux_rule__postfixExpression_10", 
  "aux_rule__postfixExpression_11", "aux_rule__postfixExpression_12", "aux_rule__directDeclarator_13", 
  "aux_rule__directDeclarator_14", "aux_rule__directDeclarator_15", "aux_rule__directAbstractDeclarator_21", 
  "aux_rule__directAbstractDeclarator_22", "aux_rule__directAbstractDeclarator_23", 
  "aux_rule__directAbstractDeclarator_24", "aux_rule__primaryExpression_4", 
  "aux_rule__primaryExpression_5", "aux_rule__primaryExpression_6", "aux_rule__primaryExpression_7", 
  "aux_rule__unaryExpression_9", "aux_rule__unaryExpression_10", "aux_rule__typeSpecifier_4", 
  "aux_rule__typeSpecifier_5", "aux_rule__structOrUnionSpecifier_3", "aux_rule__enumSpecifier_6", 
  "aux_rule__directDeclarator_16", "aux_rule__directDeclarator_17", "aux_rule__directAbstractDeclarator_25", 
  "aux_rule__directAbstractDeclarator_26", "aux_rule__labeledStatement_2", 
  "aux_rule__jumpStatement_4", "aux_rule__jumpStatement_5", "aux_rule__directDeclarator_18", 
  "aux_rule__directDeclarator_19", "aux_rule__postfixExpression_13", "aux_rule__postfixExpression_14", 
  "aux_rule__declarationSpecifier_1", "aux_rule__structDeclarationList_4", 
  "aux_rule__designatorList_4", "aux_rule__designatorList_5", "aux_rule__statement_3", 
  "aux_rule__statement_4", "aux_rule__statement_5", "aux_rule__iterationStatement_9", 
  "aux_rule__statement_6", "aux_rule__statement_7"
};

std::vector<std::string> PnfCParser::_literalNames = {
  "", "'__m128'", "'__m128d'", "'__m128i'", "'asm'", "'__asm__'", "'__asm'", 
  "'__attribute__'", "'__volatile__'", "'__inline__'", "'__stdcall'", "'__builtin_va_arg'", 
  "'__builtin_offsetof'", "'__typeof__'", "'__declspec'", "", "'auto'", 
  "'break'", "'case'", "'char'", "'const'", "'_Nonnull'", "'_Nullable'", 
  "'continue'", "'default'", "'do'", "'double'", "'else'", "'enum'", "'extern'", 
  "'float'", "'for'", "'goto'", "'if'", "'inline'", "'int'", "'long'", "'register'", 
  "'restrict'", "'__restrict__'", "'__restrict'", "'__extension__'", "'return'", 
  "'short'", "'signed'", "'sizeof'", "'static'", "'struct'", "'switch'", 
  "'typedef'", "'union'", "'unsigned'", "'void'", "'volatile'", "'while'", 
  "'_Alignas'", "'_Alignof'", "'__alignof__'", "'_Atomic'", "'_Bool'", "'_Complex'", 
  "'_Generic'", "'_Imaginary'", "'_Noreturn'", "'_Static_assert'", "'_Thread_local'", 
  "'('", "')'", "'['", "']'", "'{'", "'}'", "'<'", "'<='", "'>'", "'>='", 
  "'<<'", "'>>'", "'+'", "'++'", "'-'", "'--'", "'*'", "'/'", "'%'", "'&'", 
  "'|'", "'&&'", "'||'", "'^'", "'!'", "'~'", "'?'", "':'", "';'", "','", 
  "'='", "'*='", "'/='", "'%='", "'+='", "'-='", "'<<='", "'>>='", "'&='", 
  "'^='", "'|='", "'=='", "'!='", "'->'", "'.'", "'...'"
};

std::vector<std::string> PnfCParser::_symbolicNames = {
  "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "IncludeDirective", 
  "Auto", "Break", "Case", "Char", "Const", "Nonnull", "Nullable", "Continue", 
  "Default", "Do", "Double", "Else", "Enum", "Extern", "Float", "For", "Goto", 
  "If", "Inline", "Int", "Long", "Register", "Restrict", "Restrict_gcc", 
  "Restrict_gcc2", "Extension_gcc", "Return", "Short", "Signed", "Sizeof", 
  "Static", "Struct", "Switch", "Typedef", "Union", "Unsigned", "Void", 
  "Volatile", "While", "Alignas", "Alignof", "Alignof_gcc", "Atomic", "Bool", 
  "Complex", "Generic", "Imaginary", "Noreturn", "StaticAssert", "ThreadLocal", 
  "LeftParen", "RightParen", "LeftBracket", "RightBracket", "LeftBrace", 
  "RightBrace", "Less", "LessEqual", "Greater", "GreaterEqual", "LeftShift", 
  "RightShift", "Plus", "PlusPlus", "Minus", "MinusMinus", "Star", "Div", 
  "Mod", "And", "Or", "AndAnd", "OrOr", "Caret", "Not", "Tilde", "Question", 
  "Colon", "Semi", "Comma", "Assign", "StarAssign", "DivAssign", "ModAssign", 
  "PlusAssign", "MinusAssign", "LeftShiftAssign", "RightShiftAssign", "AndAssign", 
  "XorAssign", "OrAssign", "Equal", "NotEqual", "Arrow", "Dot", "Ellipsis", 
  "Identifier", "Constant", "StringLiteral", "ComplexDefine", "AsmBlock", 
  "LineAfterPreprocessing", "LineDirective", "PragmaDirective", "Whitespace", 
  "Newline", "BlockComment", "LineComment"
};

dfa::Vocabulary PnfCParser::_vocabulary(_literalNames, _symbolicNames);

std::vector<std::string> PnfCParser::_tokenNames;

PnfCParser::Initializer::Initializer() {
	for (size_t i = 0; i < _symbolicNames.size(); ++i) {
		std::string name = _vocabulary.getLiteralName(i);
		if (name.empty()) {
			name = _vocabulary.getSymbolicName(i);
		}

		if (name.empty()) {
			_tokenNames.push_back("<INVALID>");
		} else {
      _tokenNames.push_back(name);
    }
	}

  _serializedATN = {
    0x3, 0x608b, 0xa72a, 0x8133, 0xb9ed, 0x417c, 0x3be7, 0x7786, 0x5964, 
    0x3, 0x7d, 0x635, 0x4, 0x2, 0x9, 0x2, 0x4, 0x3, 0x9, 0x3, 0x4, 0x4, 
    0x9, 0x4, 0x4, 0x5, 0x9, 0x5, 0x4, 0x6, 0x9, 0x6, 0x4, 0x7, 0x9, 0x7, 
    0x4, 0x8, 0x9, 0x8, 0x4, 0x9, 0x9, 0x9, 0x4, 0xa, 0x9, 0xa, 0x4, 0xb, 
    0x9, 0xb, 0x4, 0xc, 0x9, 0xc, 0x4, 0xd, 0x9, 0xd, 0x4, 0xe, 0x9, 0xe, 
    0x4, 0xf, 0x9, 0xf, 0x4, 0x10, 0x9, 0x10, 0x4, 0x11, 0x9, 0x11, 0x4, 
    0x12, 0x9, 0x12, 0x4, 0x13, 0x9, 0x13, 0x4, 0x14, 0x9, 0x14, 0x4, 0x15, 
    0x9, 0x15, 0x4, 0x16, 0x9, 0x16, 0x4, 0x17, 0x9, 0x17, 0x4, 0x18, 0x9, 
    0x18, 0x4, 0x19, 0x9, 0x19, 0x4, 0x1a, 0x9, 0x1a, 0x4, 0x1b, 0x9, 0x1b, 
    0x4, 0x1c, 0x9, 0x1c, 0x4, 0x1d, 0x9, 0x1d, 0x4, 0x1e, 0x9, 0x1e, 0x4, 
    0x1f, 0x9, 0x1f, 0x4, 0x20, 0x9, 0x20, 0x4, 0x21, 0x9, 0x21, 0x4, 0x22, 
    0x9, 0x22, 0x4, 0x23, 0x9, 0x23, 0x4, 0x24, 0x9, 0x24, 0x4, 0x25, 0x9, 
    0x25, 0x4, 0x26, 0x9, 0x26, 0x4, 0x27, 0x9, 0x27, 0x4, 0x28, 0x9, 0x28, 
    0x4, 0x29, 0x9, 0x29, 0x4, 0x2a, 0x9, 0x2a, 0x4, 0x2b, 0x9, 0x2b, 0x4, 
    0x2c, 0x9, 0x2c, 0x4, 0x2d, 0x9, 0x2d, 0x4, 0x2e, 0x9, 0x2e, 0x4, 0x2f, 
    0x9, 0x2f, 0x4, 0x30, 0x9, 0x30, 0x4, 0x31, 0x9, 0x31, 0x4, 0x32, 0x9, 
    0x32, 0x4, 0x33, 0x9, 0x33, 0x4, 0x34, 0x9, 0x34, 0x4, 0x35, 0x9, 0x35, 
    0x4, 0x36, 0x9, 0x36, 0x4, 0x37, 0x9, 0x37, 0x4, 0x38, 0x9, 0x38, 0x4, 
    0x39, 0x9, 0x39, 0x4, 0x3a, 0x9, 0x3a, 0x4, 0x3b, 0x9, 0x3b, 0x4, 0x3c, 
    0x9, 0x3c, 0x4, 0x3d, 0x9, 0x3d, 0x4, 0x3e, 0x9, 0x3e, 0x4, 0x3f, 0x9, 
    0x3f, 0x4, 0x40, 0x9, 0x40, 0x4, 0x41, 0x9, 0x41, 0x4, 0x42, 0x9, 0x42, 
    0x4, 0x43, 0x9, 0x43, 0x4, 0x44, 0x9, 0x44, 0x4, 0x45, 0x9, 0x45, 0x4, 
    0x46, 0x9, 0x46, 0x4, 0x47, 0x9, 0x47, 0x4, 0x48, 0x9, 0x48, 0x4, 0x49, 
    0x9, 0x49, 0x4, 0x4a, 0x9, 0x4a, 0x4, 0x4b, 0x9, 0x4b, 0x4, 0x4c, 0x9, 
    0x4c, 0x4, 0x4d, 0x9, 0x4d, 0x4, 0x4e, 0x9, 0x4e, 0x4, 0x4f, 0x9, 0x4f, 
    0x4, 0x50, 0x9, 0x50, 0x4, 0x51, 0x9, 0x51, 0x4, 0x52, 0x9, 0x52, 0x4, 
    0x53, 0x9, 0x53, 0x4, 0x54, 0x9, 0x54, 0x4, 0x55, 0x9, 0x55, 0x4, 0x56, 
    0x9, 0x56, 0x4, 0x57, 0x9, 0x57, 0x4, 0x58, 0x9, 0x58, 0x4, 0x59, 0x9, 
    0x59, 0x4, 0x5a, 0x9, 0x5a, 0x4, 0x5b, 0x9, 0x5b, 0x4, 0x5c, 0x9, 0x5c, 
    0x4, 0x5d, 0x9, 0x5d, 0x4, 0x5e, 0x9, 0x5e, 0x4, 0x5f, 0x9, 0x5f, 0x4, 
    0x60, 0x9, 0x60, 0x4, 0x61, 0x9, 0x61, 0x4, 0x62, 0x9, 0x62, 0x4, 0x63, 
    0x9, 0x63, 0x4, 0x64, 0x9, 0x64, 0x4, 0x65, 0x9, 0x65, 0x4, 0x66, 0x9, 
    0x66, 0x4, 0x67, 0x9, 0x67, 0x4, 0x68, 0x9, 0x68, 0x4, 0x69, 0x9, 0x69, 
    0x4, 0x6a, 0x9, 0x6a, 0x4, 0x6b, 0x9, 0x6b, 0x4, 0x6c, 0x9, 0x6c, 0x4, 
    0x6d, 0x9, 0x6d, 0x4, 0x6e, 0x9, 0x6e, 0x4, 0x6f, 0x9, 0x6f, 0x4, 0x70, 
    0x9, 0x70, 0x4, 0x71, 0x9, 0x71, 0x4, 0x72, 0x9, 0x72, 0x4, 0x73, 0x9, 
    0x73, 0x4, 0x74, 0x9, 0x74, 0x4, 0x75, 0x9, 0x75, 0x4, 0x76, 0x9, 0x76, 
    0x4, 0x77, 0x9, 0x77, 0x4, 0x78, 0x9, 0x78, 0x4, 0x79, 0x9, 0x79, 0x4, 
    0x7a, 0x9, 0x7a, 0x4, 0x7b, 0x9, 0x7b, 0x4, 0x7c, 0x9, 0x7c, 0x4, 0x7d, 
    0x9, 0x7d, 0x4, 0x7e, 0x9, 0x7e, 0x4, 0x7f, 0x9, 0x7f, 0x4, 0x80, 0x9, 
    0x80, 0x4, 0x81, 0x9, 0x81, 0x4, 0x82, 0x9, 0x82, 0x4, 0x83, 0x9, 0x83, 
    0x4, 0x84, 0x9, 0x84, 0x4, 0x85, 0x9, 0x85, 0x4, 0x86, 0x9, 0x86, 0x4, 
    0x87, 0x9, 0x87, 0x4, 0x88, 0x9, 0x88, 0x4, 0x89, 0x9, 0x89, 0x4, 0x8a, 
    0x9, 0x8a, 0x4, 0x8b, 0x9, 0x8b, 0x4, 0x8c, 0x9, 0x8c, 0x4, 0x8d, 0x9, 
    0x8d, 0x4, 0x8e, 0x9, 0x8e, 0x4, 0x8f, 0x9, 0x8f, 0x4, 0x90, 0x9, 0x90, 
    0x4, 0x91, 0x9, 0x91, 0x4, 0x92, 0x9, 0x92, 0x4, 0x93, 0x9, 0x93, 0x4, 
    0x94, 0x9, 0x94, 0x4, 0x95, 0x9, 0x95, 0x4, 0x96, 0x9, 0x96, 0x4, 0x97, 
    0x9, 0x97, 0x4, 0x98, 0x9, 0x98, 0x4, 0x99, 0x9, 0x99, 0x4, 0x9a, 0x9, 
    0x9a, 0x4, 0x9b, 0x9, 0x9b, 0x4, 0x9c, 0x9, 0x9c, 0x4, 0x9d, 0x9, 0x9d, 
    0x4, 0x9e, 0x9, 0x9e, 0x4, 0x9f, 0x9, 0x9f, 0x4, 0xa0, 0x9, 0xa0, 0x4, 
    0xa1, 0x9, 0xa1, 0x4, 0xa2, 0x9, 0xa2, 0x4, 0xa3, 0x9, 0xa3, 0x4, 0xa4, 
    0x9, 0xa4, 0x4, 0xa5, 0x9, 0xa5, 0x4, 0xa6, 0x9, 0xa6, 0x4, 0xa7, 0x9, 
    0xa7, 0x4, 0xa8, 0x9, 0xa8, 0x4, 0xa9, 0x9, 0xa9, 0x4, 0xaa, 0x9, 0xaa, 
    0x4, 0xab, 0x9, 0xab, 0x4, 0xac, 0x9, 0xac, 0x4, 0xad, 0x9, 0xad, 0x4, 
    0xae, 0x9, 0xae, 0x4, 0xaf, 0x9, 0xaf, 0x4, 0xb0, 0x9, 0xb0, 0x4, 0xb1, 
    0x9, 0xb1, 0x4, 0xb2, 0x9, 0xb2, 0x4, 0xb3, 0x9, 0xb3, 0x4, 0xb4, 0x9, 
    0xb4, 0x4, 0xb5, 0x9, 0xb5, 0x4, 0xb6, 0x9, 0xb6, 0x4, 0xb7, 0x9, 0xb7, 
    0x4, 0xb8, 0x9, 0xb8, 0x4, 0xb9, 0x9, 0xb9, 0x4, 0xba, 0x9, 0xba, 0x4, 
    0xbb, 0x9, 0xbb, 0x4, 0xbc, 0x9, 0xbc, 0x4, 0xbd, 0x9, 0xbd, 0x4, 0xbe, 
    0x9, 0xbe, 0x4, 0xbf, 0x9, 0xbf, 0x4, 0xc0, 0x9, 0xc0, 0x4, 0xc1, 0x9, 
    0xc1, 0x4, 0xc2, 0x9, 0xc2, 0x4, 0xc3, 0x9, 0xc3, 0x4, 0xc4, 0x9, 0xc4, 
    0x4, 0xc5, 0x9, 0xc5, 0x4, 0xc6, 0x9, 0xc6, 0x4, 0xc7, 0x9, 0xc7, 0x4, 
    0xc8, 0x9, 0xc8, 0x4, 0xc9, 0x9, 0xc9, 0x4, 0xca, 0x9, 0xca, 0x4, 0xcb, 
    0x9, 0xcb, 0x4, 0xcc, 0x9, 0xcc, 0x4, 0xcd, 0x9, 0xcd, 0x4, 0xce, 0x9, 
    0xce, 0x4, 0xcf, 0x9, 0xcf, 0x4, 0xd0, 0x9, 0xd0, 0x4, 0xd1, 0x9, 0xd1, 
    0x4, 0xd2, 0x9, 0xd2, 0x4, 0xd3, 0x9, 0xd3, 0x4, 0xd4, 0x9, 0xd4, 0x4, 
    0xd5, 0x9, 0xd5, 0x4, 0xd6, 0x9, 0xd6, 0x4, 0xd7, 0x9, 0xd7, 0x4, 0xd8, 
    0x9, 0xd8, 0x4, 0xd9, 0x9, 0xd9, 0x4, 0xda, 0x9, 0xda, 0x4, 0xdb, 0x9, 
    0xdb, 0x4, 0xdc, 0x9, 0xdc, 0x4, 0xdd, 0x9, 0xdd, 0x4, 0xde, 0x9, 0xde, 
    0x4, 0xdf, 0x9, 0xdf, 0x4, 0xe0, 0x9, 0xe0, 0x4, 0xe1, 0x9, 0xe1, 0x4, 
    0xe2, 0x9, 0xe2, 0x4, 0xe3, 0x9, 0xe3, 0x4, 0xe4, 0x9, 0xe4, 0x4, 0xe5, 
    0x9, 0xe5, 0x4, 0xe6, 0x9, 0xe6, 0x4, 0xe7, 0x9, 0xe7, 0x4, 0xe8, 0x9, 
    0xe8, 0x4, 0xe9, 0x9, 0xe9, 0x4, 0xea, 0x9, 0xea, 0x4, 0xeb, 0x9, 0xeb, 
    0x4, 0xec, 0x9, 0xec, 0x4, 0xed, 0x9, 0xed, 0x4, 0xee, 0x9, 0xee, 0x4, 
    0xef, 0x9, 0xef, 0x4, 0xf0, 0x9, 0xf0, 0x4, 0xf1, 0x9, 0xf1, 0x4, 0xf2, 
    0x9, 0xf2, 0x4, 0xf3, 0x9, 0xf3, 0x4, 0xf4, 0x9, 0xf4, 0x4, 0xf5, 0x9, 
    0xf5, 0x4, 0xf6, 0x9, 0xf6, 0x4, 0xf7, 0x9, 0xf7, 0x4, 0xf8, 0x9, 0xf8, 
    0x4, 0xf9, 0x9, 0xf9, 0x4, 0xfa, 0x9, 0xfa, 0x4, 0xfb, 0x9, 0xfb, 0x4, 
    0xfc, 0x9, 0xfc, 0x4, 0xfd, 0x9, 0xfd, 0x4, 0xfe, 0x9, 0xfe, 0x4, 0xff, 
    0x9, 0xff, 0x4, 0x100, 0x9, 0x100, 0x4, 0x101, 0x9, 0x101, 0x4, 0x102, 
    0x9, 0x102, 0x4, 0x103, 0x9, 0x103, 0x4, 0x104, 0x9, 0x104, 0x4, 0x105, 
    0x9, 0x105, 0x4, 0x106, 0x9, 0x106, 0x4, 0x107, 0x9, 0x107, 0x4, 0x108, 
    0x9, 0x108, 0x4, 0x109, 0x9, 0x109, 0x4, 0x10a, 0x9, 0x10a, 0x4, 0x10b, 
    0x9, 0x10b, 0x3, 0x2, 0x3, 0x2, 0x3, 0x2, 0x3, 0x2, 0x3, 0x2, 0x3, 0x2, 
    0x3, 0x2, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x4, 0x3, 0x4, 
    0x3, 0x4, 0x3, 0x4, 0x3, 0x4, 0x5, 0x4, 0x227, 0xa, 0x4, 0x3, 0x5, 0x3, 
    0x5, 0x3, 0x6, 0x3, 0x6, 0x5, 0x6, 0x22d, 0xa, 0x6, 0x3, 0x7, 0x3, 0x7, 
    0x3, 0x7, 0x3, 0x8, 0x3, 0x8, 0x5, 0x8, 0x234, 0xa, 0x8, 0x3, 0x9, 0x3, 
    0x9, 0x3, 0xa, 0x3, 0xa, 0x3, 0xb, 0x3, 0xb, 0x3, 0xb, 0x5, 0xb, 0x23d, 
    0xa, 0xb, 0x3, 0xc, 0x6, 0xc, 0x240, 0xa, 0xc, 0xd, 0xc, 0xe, 0xc, 0x241, 
    0x3, 0xd, 0x3, 0xd, 0x3, 0xd, 0x3, 0xe, 0x3, 0xe, 0x3, 0xe, 0x3, 0xe, 
    0x3, 0xe, 0x3, 0xe, 0x3, 0xe, 0x3, 0xe, 0x3, 0xe, 0x3, 0xe, 0x3, 0xe, 
    0x3, 0xe, 0x3, 0xe, 0x3, 0xe, 0x3, 0xe, 0x3, 0xe, 0x3, 0xe, 0x3, 0xe, 
    0x3, 0xe, 0x5, 0xe, 0x25a, 0xa, 0xe, 0x3, 0xf, 0x3, 0xf, 0x3, 0xf, 0x3, 
    0x10, 0x3, 0x10, 0x3, 0x11, 0x3, 0x11, 0x3, 0x11, 0x3, 0x12, 0x3, 0x12, 
    0x5, 0x12, 0x266, 0xa, 0x12, 0x3, 0x13, 0x3, 0x13, 0x3, 0x13, 0x3, 0x14, 
    0x3, 0x14, 0x3, 0x14, 0x3, 0x15, 0x3, 0x15, 0x3, 0x15, 0x3, 0x15, 0x3, 
    0x15, 0x3, 0x16, 0x3, 0x16, 0x3, 0x17, 0x3, 0x17, 0x3, 0x17, 0x3, 0x17, 
    0x3, 0x17, 0x3, 0x18, 0x3, 0x18, 0x3, 0x18, 0x3, 0x18, 0x3, 0x19, 0x3, 
    0x19, 0x5, 0x19, 0x280, 0xa, 0x19, 0x3, 0x1a, 0x3, 0x1a, 0x3, 0x1b, 
    0x3, 0x1b, 0x3, 0x1b, 0x3, 0x1b, 0x3, 0x1b, 0x3, 0x1b, 0x3, 0x1b, 0x3, 
    0x1c, 0x5, 0x1c, 0x28c, 0xa, 0x1c, 0x3, 0x1d, 0x5, 0x1d, 0x28f, 0xa, 
    0x1d, 0x3, 0x1e, 0x3, 0x1e, 0x3, 0x1e, 0x3, 0x1f, 0x3, 0x1f, 0x3, 0x1f, 
    0x3, 0x20, 0x3, 0x20, 0x3, 0x20, 0x3, 0x21, 0x3, 0x21, 0x3, 0x21, 0x3, 
    0x22, 0x3, 0x22, 0x5, 0x22, 0x29f, 0xa, 0x22, 0x3, 0x23, 0x3, 0x23, 
    0x3, 0x24, 0x3, 0x24, 0x5, 0x24, 0x2a5, 0xa, 0x24, 0x3, 0x25, 0x3, 0x25, 
    0x3, 0x25, 0x3, 0x26, 0x3, 0x26, 0x3, 0x26, 0x3, 0x26, 0x3, 0x26, 0x3, 
    0x26, 0x3, 0x26, 0x3, 0x26, 0x3, 0x27, 0x3, 0x27, 0x3, 0x27, 0x3, 0x27, 
    0x3, 0x27, 0x3, 0x27, 0x3, 0x27, 0x3, 0x27, 0x3, 0x28, 0x3, 0x28, 0x3, 
    0x28, 0x3, 0x28, 0x3, 0x29, 0x3, 0x29, 0x3, 0x29, 0x3, 0x29, 0x3, 0x2a, 
    0x3, 0x2a, 0x3, 0x2a, 0x3, 0x2b, 0x3, 0x2b, 0x3, 0x2b, 0x3, 0x2c, 0x3, 
    0x2c, 0x3, 0x2c, 0x3, 0x2d, 0x3, 0x2d, 0x3, 0x2d, 0x3, 0x2d, 0x3, 0x2d, 
    0x3, 0x2d, 0x3, 0x2e, 0x6, 0x2e, 0x2d2, 0xa, 0x2e, 0xd, 0x2e, 0xe, 0x2e, 
    0x2d3, 0x3, 0x2f, 0x5, 0x2f, 0x2d7, 0xa, 0x2f, 0x3, 0x30, 0x5, 0x30, 
    0x2da, 0xa, 0x30, 0x3, 0x31, 0x3, 0x31, 0x3, 0x31, 0x3, 0x31, 0x3, 0x31, 
    0x3, 0x32, 0x5, 0x32, 0x2e2, 0xa, 0x32, 0x3, 0x33, 0x5, 0x33, 0x2e5, 
    0xa, 0x33, 0x3, 0x34, 0x5, 0x34, 0x2e8, 0xa, 0x34, 0x3, 0x35, 0x5, 0x35, 
    0x2eb, 0xa, 0x35, 0x3, 0x36, 0x5, 0x36, 0x2ee, 0xa, 0x36, 0x3, 0x37, 
    0x5, 0x37, 0x2f1, 0xa, 0x37, 0x3, 0x38, 0x5, 0x38, 0x2f4, 0xa, 0x38, 
    0x3, 0x39, 0x5, 0x39, 0x2f7, 0xa, 0x39, 0x3, 0x3a, 0x7, 0x3a, 0x2fa, 
    0xa, 0x3a, 0xc, 0x3a, 0xe, 0x3a, 0x2fd, 0xb, 0x3a, 0x3, 0x3b, 0x5, 0x3b, 
    0x300, 0xa, 0x3b, 0x3, 0x3c, 0x5, 0x3c, 0x303, 0xa, 0x3c, 0x3, 0x3d, 
    0x3, 0x3d, 0x3, 0x3d, 0x3, 0x3e, 0x7, 0x3e, 0x309, 0xa, 0x3e, 0xc, 0x3e, 
    0xe, 0x3e, 0x30c, 0xb, 0x3e, 0x3, 0x3f, 0x3, 0x3f, 0x3, 0x3f, 0x3, 0x40, 
    0x3, 0x40, 0x3, 0x40, 0x3, 0x40, 0x3, 0x41, 0x5, 0x41, 0x316, 0xa, 0x41, 
    0x3, 0x42, 0x3, 0x42, 0x3, 0x42, 0x3, 0x43, 0x5, 0x43, 0x31c, 0xa, 0x43, 
    0x3, 0x44, 0x5, 0x44, 0x31f, 0xa, 0x44, 0x3, 0x45, 0x5, 0x45, 0x322, 
    0xa, 0x45, 0x3, 0x46, 0x5, 0x46, 0x325, 0xa, 0x46, 0x3, 0x47, 0x3, 0x47, 
    0x3, 0x48, 0x5, 0x48, 0x32a, 0xa, 0x48, 0x3, 0x49, 0x3, 0x49, 0x3, 0x49, 
    0x3, 0x4a, 0x7, 0x4a, 0x330, 0xa, 0x4a, 0xc, 0x4a, 0xe, 0x4a, 0x333, 
    0xb, 0x4a, 0x3, 0x4b, 0x3, 0x4b, 0x3, 0x4b, 0x3, 0x4c, 0x5, 0x4c, 0x339, 
    0xa, 0x4c, 0x3, 0x4d, 0x3, 0x4d, 0x3, 0x4d, 0x3, 0x4e, 0x7, 0x4e, 0x33f, 
    0xa, 0x4e, 0xc, 0x4e, 0xe, 0x4e, 0x342, 0xb, 0x4e, 0x3, 0x4f, 0x5, 0x4f, 
    0x345, 0xa, 0x4f, 0x3, 0x50, 0x3, 0x50, 0x3, 0x50, 0x3, 0x51, 0x5, 0x51, 
    0x34b, 0xa, 0x51, 0x3, 0x52, 0x5, 0x52, 0x34e, 0xa, 0x52, 0x3, 0x53, 
    0x5, 0x53, 0x351, 0xa, 0x53, 0x3, 0x54, 0x5, 0x54, 0x354, 0xa, 0x54, 
    0x3, 0x55, 0x3, 0x55, 0x3, 0x55, 0x3, 0x56, 0x7, 0x56, 0x35a, 0xa, 0x56, 
    0xc, 0x56, 0xe, 0x56, 0x35d, 0xb, 0x56, 0x3, 0x57, 0x3, 0x57, 0x3, 0x57, 
    0x3, 0x58, 0x3, 0x58, 0x3, 0x58, 0x3, 0x59, 0x7, 0x59, 0x366, 0xa, 0x59, 
    0xc, 0x59, 0xe, 0x59, 0x369, 0xb, 0x59, 0x3, 0x5a, 0x3, 0x5a, 0x3, 0x5a, 
    0x3, 0x5b, 0x3, 0x5b, 0x3, 0x5b, 0x3, 0x5b, 0x3, 0x5b, 0x5, 0x5b, 0x373, 
    0xa, 0x5b, 0x3, 0x5c, 0x7, 0x5c, 0x376, 0xa, 0x5c, 0xc, 0x5c, 0xe, 0x5c, 
    0x379, 0xb, 0x5c, 0x3, 0x5d, 0x3, 0x5d, 0x3, 0x5d, 0x3, 0x5e, 0x3, 0x5e, 
    0x3, 0x5e, 0x3, 0x5e, 0x3, 0x5f, 0x7, 0x5f, 0x383, 0xa, 0x5f, 0xc, 0x5f, 
    0xe, 0x5f, 0x386, 0xb, 0x5f, 0x3, 0x60, 0x3, 0x60, 0x3, 0x60, 0x3, 0x60, 
    0x3, 0x61, 0x3, 0x61, 0x3, 0x61, 0x3, 0x62, 0x7, 0x62, 0x390, 0xa, 0x62, 
    0xc, 0x62, 0xe, 0x62, 0x393, 0xb, 0x62, 0x3, 0x63, 0x3, 0x63, 0x3, 0x63, 
    0x3, 0x64, 0x3, 0x64, 0x3, 0x64, 0x3, 0x65, 0x7, 0x65, 0x39c, 0xa, 0x65, 
    0xc, 0x65, 0xe, 0x65, 0x39f, 0xb, 0x65, 0x3, 0x66, 0x3, 0x66, 0x3, 0x66, 
    0x3, 0x67, 0x3, 0x67, 0x3, 0x67, 0x3, 0x68, 0x7, 0x68, 0x3a8, 0xa, 0x68, 
    0xc, 0x68, 0xe, 0x68, 0x3ab, 0xb, 0x68, 0x3, 0x69, 0x3, 0x69, 0x3, 0x69, 
    0x3, 0x6a, 0x3, 0x6a, 0x3, 0x6a, 0x3, 0x6b, 0x7, 0x6b, 0x3b4, 0xa, 0x6b, 
    0xc, 0x6b, 0xe, 0x6b, 0x3b7, 0xb, 0x6b, 0x3, 0x6c, 0x3, 0x6c, 0x3, 0x6c, 
    0x3, 0x6d, 0x3, 0x6d, 0x3, 0x6d, 0x3, 0x6e, 0x7, 0x6e, 0x3c0, 0xa, 0x6e, 
    0xc, 0x6e, 0xe, 0x6e, 0x3c3, 0xb, 0x6e, 0x3, 0x6f, 0x3, 0x6f, 0x3, 0x6f, 
    0x3, 0x70, 0x3, 0x70, 0x3, 0x70, 0x3, 0x71, 0x7, 0x71, 0x3cc, 0xa, 0x71, 
    0xc, 0x71, 0xe, 0x71, 0x3cf, 0xb, 0x71, 0x3, 0x72, 0x3, 0x72, 0x3, 0x72, 
    0x3, 0x73, 0x3, 0x73, 0x3, 0x73, 0x3, 0x74, 0x7, 0x74, 0x3d8, 0xa, 0x74, 
    0xc, 0x74, 0xe, 0x74, 0x3db, 0xb, 0x74, 0x3, 0x75, 0x3, 0x75, 0x3, 0x75, 
    0x3, 0x76, 0x3, 0x76, 0x3, 0x76, 0x3, 0x77, 0x7, 0x77, 0x3e4, 0xa, 0x77, 
    0xc, 0x77, 0xe, 0x77, 0x3e7, 0xb, 0x77, 0x3, 0x78, 0x3, 0x78, 0x3, 0x78, 
    0x3, 0x79, 0x3, 0x79, 0x3, 0x79, 0x3, 0x7a, 0x7, 0x7a, 0x3f0, 0xa, 0x7a, 
    0xc, 0x7a, 0xe, 0x7a, 0x3f3, 0xb, 0x7a, 0x3, 0x7b, 0x3, 0x7b, 0x3, 0x7b, 
    0x3, 0x7c, 0x3, 0x7c, 0x3, 0x7c, 0x3, 0x7d, 0x7, 0x7d, 0x3fc, 0xa, 0x7d, 
    0xc, 0x7d, 0xe, 0x7d, 0x3ff, 0xb, 0x7d, 0x3, 0x7e, 0x3, 0x7e, 0x3, 0x7e, 
    0x3, 0x7f, 0x3, 0x7f, 0x3, 0x7f, 0x3, 0x80, 0x7, 0x80, 0x408, 0xa, 0x80, 
    0xc, 0x80, 0xe, 0x80, 0x40b, 0xb, 0x80, 0x3, 0x81, 0x3, 0x81, 0x3, 0x81, 
    0x3, 0x82, 0x3, 0x82, 0x3, 0x83, 0x3, 0x83, 0x3, 0x83, 0x3, 0x84, 0x7, 
    0x84, 0x416, 0xa, 0x84, 0xc, 0x84, 0xe, 0x84, 0x419, 0xb, 0x84, 0x3, 
    0x85, 0x3, 0x85, 0x3, 0x85, 0x3, 0x86, 0x3, 0x86, 0x3, 0x86, 0x3, 0x87, 
    0x7, 0x87, 0x422, 0xa, 0x87, 0xc, 0x87, 0xe, 0x87, 0x425, 0xb, 0x87, 
    0x3, 0x88, 0x3, 0x88, 0x3, 0x88, 0x3, 0x89, 0x3, 0x89, 0x5, 0x89, 0x42c, 
    0xa, 0x89, 0x3, 0x8a, 0x7, 0x8a, 0x42f, 0xa, 0x8a, 0xc, 0x8a, 0xe, 0x8a, 
    0x432, 0xb, 0x8a, 0x3, 0x8b, 0x3, 0x8b, 0x5, 0x8b, 0x436, 0xa, 0x8b, 
    0x3, 0x8c, 0x3, 0x8c, 0x3, 0x8c, 0x3, 0x8d, 0x3, 0x8d, 0x3, 0x8e, 0x3, 
    0x8e, 0x3, 0x8f, 0x3, 0x8f, 0x3, 0x8f, 0x3, 0x90, 0x7, 0x90, 0x443, 
    0xa, 0x90, 0xc, 0x90, 0xe, 0x90, 0x446, 0xb, 0x90, 0x3, 0x91, 0x3, 0x91, 
    0x3, 0x91, 0x3, 0x92, 0x3, 0x92, 0x3, 0x92, 0x3, 0x93, 0x7, 0x93, 0x44f, 
    0xa, 0x93, 0xc, 0x93, 0xe, 0x93, 0x452, 0xb, 0x93, 0x3, 0x94, 0x3, 0x94, 
    0x3, 0x94, 0x3, 0x95, 0x3, 0x95, 0x5, 0x95, 0x459, 0xa, 0x95, 0x3, 0x96, 
    0x7, 0x96, 0x45c, 0xa, 0x96, 0xc, 0x96, 0xe, 0x96, 0x45f, 0xb, 0x96, 
    0x3, 0x97, 0x3, 0x97, 0x5, 0x97, 0x463, 0xa, 0x97, 0x3, 0x98, 0x3, 0x98, 
    0x3, 0x98, 0x3, 0x99, 0x3, 0x99, 0x3, 0x9a, 0x3, 0x9a, 0x3, 0x9b, 0x3, 
    0x9b, 0x3, 0x9c, 0x3, 0x9c, 0x3, 0x9d, 0x3, 0x9d, 0x3, 0x9e, 0x6, 0x9e, 
    0x473, 0xa, 0x9e, 0xd, 0x9e, 0xe, 0x9e, 0x474, 0x3, 0x9f, 0x6, 0x9f, 
    0x478, 0xa, 0x9f, 0xd, 0x9f, 0xe, 0x9f, 0x479, 0x3, 0xa0, 0x6, 0xa0, 
    0x47d, 0xa, 0xa0, 0xd, 0xa0, 0xe, 0xa0, 0x47e, 0x3, 0xa1, 0x6, 0xa1, 
    0x482, 0xa, 0xa1, 0xd, 0xa1, 0xe, 0xa1, 0x483, 0x3, 0xa2, 0x6, 0xa2, 
    0x487, 0xa, 0xa2, 0xd, 0xa2, 0xe, 0xa2, 0x488, 0x3, 0xa3, 0x6, 0xa3, 
    0x48c, 0xa, 0xa3, 0xd, 0xa3, 0xe, 0xa3, 0x48d, 0x3, 0xa4, 0x5, 0xa4, 
    0x491, 0xa, 0xa4, 0x3, 0xa5, 0x3, 0xa5, 0x3, 0xa5, 0x3, 0xa6, 0x5, 0xa6, 
    0x497, 0xa, 0xa6, 0x3, 0xa7, 0x3, 0xa7, 0x3, 0xa7, 0x3, 0xa8, 0x5, 0xa8, 
    0x49d, 0xa, 0xa8, 0x3, 0xa9, 0x3, 0xa9, 0x3, 0xa9, 0x3, 0xaa, 0x5, 0xaa, 
    0x4a3, 0xa, 0xaa, 0x3, 0xab, 0x3, 0xab, 0x3, 0xab, 0x3, 0xab, 0x5, 0xab, 
    0x4a9, 0xa, 0xab, 0x3, 0xac, 0x3, 0xac, 0x3, 0xad, 0x3, 0xad, 0x5, 0xad, 
    0x4af, 0xa, 0xad, 0x3, 0xae, 0x3, 0xae, 0x5, 0xae, 0x4b3, 0xa, 0xae, 
    0x3, 0xaf, 0x3, 0xaf, 0x3, 0xb0, 0x3, 0xb0, 0x3, 0xb0, 0x3, 0xb0, 0x3, 
    0xb0, 0x3, 0xb0, 0x3, 0xb0, 0x3, 0xb0, 0x3, 0xb1, 0x3, 0xb1, 0x3, 0xb2, 
    0x3, 0xb2, 0x3, 0xb3, 0x3, 0xb3, 0x3, 0xb4, 0x3, 0xb4, 0x3, 0xb5, 0x3, 
    0xb5, 0x3, 0xb6, 0x3, 0xb6, 0x5, 0xb6, 0x4cb, 0xa, 0xb6, 0x3, 0xb7, 
    0x3, 0xb7, 0x5, 0xb7, 0x4cf, 0xa, 0xb7, 0x3, 0xb8, 0x3, 0xb8, 0x5, 0xb8, 
    0x4d3, 0xa, 0xb8, 0x3, 0xb9, 0x3, 0xb9, 0x5, 0xb9, 0x4d7, 0xa, 0xb9, 
    0x3, 0xba, 0x3, 0xba, 0x3, 0xba, 0x3, 0xbb, 0x3, 0xbb, 0x5, 0xbb, 0x4de, 
    0xa, 0xbb, 0x3, 0xbc, 0x3, 0xbc, 0x5, 0xbc, 0x4e2, 0xa, 0xbc, 0x3, 0xbd, 
    0x3, 0xbd, 0x3, 0xbd, 0x5, 0xbd, 0x4e7, 0xa, 0xbd, 0x3, 0xbe, 0x3, 0xbe, 
    0x3, 0xbe, 0x3, 0xbe, 0x3, 0xbf, 0x3, 0xbf, 0x3, 0xbf, 0x5, 0xbf, 0x4f0, 
    0xa, 0xbf, 0x3, 0xc0, 0x3, 0xc0, 0x3, 0xc0, 0x3, 0xc0, 0x5, 0xc0, 0x4f6, 
    0xa, 0xc0, 0x3, 0xc1, 0x3, 0xc1, 0x3, 0xc1, 0x3, 0xc1, 0x3, 0xc1, 0x3, 
    0xc2, 0x3, 0xc2, 0x5, 0xc2, 0x4ff, 0xa, 0xc2, 0x3, 0xc3, 0x3, 0xc3, 
    0x3, 0xc3, 0x3, 0xc3, 0x3, 0xc3, 0x3, 0xc4, 0x3, 0xc4, 0x5, 0xc4, 0x508, 
    0xa, 0xc4, 0x3, 0xc5, 0x3, 0xc5, 0x3, 0xc5, 0x3, 0xc5, 0x3, 0xc5, 0x3, 
    0xc5, 0x5, 0xc5, 0x510, 0xa, 0xc5, 0x3, 0xc6, 0x3, 0xc6, 0x3, 0xc6, 
    0x3, 0xc6, 0x3, 0xc6, 0x3, 0xc6, 0x3, 0xc6, 0x3, 0xc6, 0x3, 0xc6, 0x3, 
    0xc6, 0x3, 0xc6, 0x3, 0xc6, 0x3, 0xc6, 0x3, 0xc6, 0x3, 0xc6, 0x5, 0xc6, 
    0x521, 0xa, 0xc6, 0x3, 0xc7, 0x3, 0xc7, 0x5, 0xc7, 0x525, 0xa, 0xc7, 
    0x3, 0xc8, 0x3, 0xc8, 0x5, 0xc8, 0x529, 0xa, 0xc8, 0x3, 0xc9, 0x3, 0xc9, 
    0x3, 0xc9, 0x3, 0xc9, 0x3, 0xc9, 0x3, 0xc9, 0x3, 0xc9, 0x3, 0xc9, 0x5, 
    0xc9, 0x533, 0xa, 0xc9, 0x3, 0xca, 0x3, 0xca, 0x5, 0xca, 0x537, 0xa, 
    0xca, 0x3, 0xcb, 0x3, 0xcb, 0x3, 0xcb, 0x3, 0xcb, 0x5, 0xcb, 0x53d, 
    0xa, 0xcb, 0x3, 0xcc, 0x3, 0xcc, 0x3, 0xcd, 0x3, 0xcd, 0x5, 0xcd, 0x543, 
    0xa, 0xcd, 0x3, 0xce, 0x3, 0xce, 0x3, 0xcf, 0x3, 0xcf, 0x5, 0xcf, 0x549, 
    0xa, 0xcf, 0x3, 0xd0, 0x3, 0xd0, 0x3, 0xd1, 0x3, 0xd1, 0x5, 0xd1, 0x54f, 
    0xa, 0xd1, 0x3, 0xd2, 0x3, 0xd2, 0x5, 0xd2, 0x553, 0xa, 0xd2, 0x3, 0xd3, 
    0x3, 0xd3, 0x5, 0xd3, 0x557, 0xa, 0xd3, 0x3, 0xd4, 0x3, 0xd4, 0x5, 0xd4, 
    0x55b, 0xa, 0xd4, 0x3, 0xd5, 0x3, 0xd5, 0x5, 0xd5, 0x55f, 0xa, 0xd5, 
    0x3, 0xd6, 0x3, 0xd6, 0x3, 0xd7, 0x3, 0xd7, 0x3, 0xd7, 0x3, 0xd8, 0x3, 
    0xd8, 0x3, 0xd8, 0x3, 0xd9, 0x3, 0xd9, 0x3, 0xd9, 0x3, 0xda, 0x3, 0xda, 
    0x3, 0xda, 0x3, 0xdb, 0x3, 0xdb, 0x3, 0xdb, 0x3, 0xdb, 0x3, 0xdb, 0x3, 
    0xdb, 0x3, 0xdc, 0x3, 0xdc, 0x3, 0xdc, 0x3, 0xdc, 0x3, 0xdd, 0x3, 0xdd, 
    0x3, 0xdd, 0x3, 0xdd, 0x3, 0xdd, 0x3, 0xde, 0x3, 0xde, 0x3, 0xde, 0x3, 
    0xdf, 0x3, 0xdf, 0x3, 0xdf, 0x3, 0xdf, 0x3, 0xe0, 0x3, 0xe0, 0x3, 0xe0, 
    0x3, 0xe0, 0x3, 0xe0, 0x3, 0xe1, 0x3, 0xe1, 0x3, 0xe1, 0x3, 0xe1, 0x3, 
    0xe2, 0x3, 0xe2, 0x3, 0xe2, 0x3, 0xe2, 0x3, 0xe2, 0x3, 0xe3, 0x3, 0xe3, 
    0x3, 0xe3, 0x3, 0xe3, 0x3, 0xe4, 0x3, 0xe4, 0x3, 0xe4, 0x3, 0xe4, 0x3, 
    0xe5, 0x3, 0xe5, 0x3, 0xe5, 0x3, 0xe6, 0x3, 0xe6, 0x3, 0xe6, 0x3, 0xe6, 
    0x3, 0xe7, 0x3, 0xe7, 0x3, 0xe7, 0x3, 0xe7, 0x3, 0xe8, 0x3, 0xe8, 0x3, 
    0xe8, 0x3, 0xe8, 0x3, 0xe9, 0x3, 0xe9, 0x3, 0xe9, 0x3, 0xe9, 0x3, 0xe9, 
    0x3, 0xea, 0x3, 0xea, 0x3, 0xea, 0x3, 0xea, 0x3, 0xeb, 0x3, 0xeb, 0x3, 
    0xeb, 0x3, 0xeb, 0x3, 0xec, 0x3, 0xec, 0x3, 0xec, 0x3, 0xed, 0x3, 0xed, 
    0x3, 0xed, 0x3, 0xee, 0x3, 0xee, 0x3, 0xee, 0x3, 0xee, 0x3, 0xef, 0x3, 
    0xef, 0x3, 0xef, 0x3, 0xef, 0x3, 0xef, 0x3, 0xef, 0x3, 0xf0, 0x3, 0xf0, 
    0x3, 0xf0, 0x3, 0xf0, 0x3, 0xf0, 0x3, 0xf0, 0x3, 0xf1, 0x3, 0xf1, 0x3, 
    0xf1, 0x3, 0xf1, 0x3, 0xf2, 0x3, 0xf2, 0x3, 0xf2, 0x3, 0xf2, 0x3, 0xf3, 
    0x3, 0xf3, 0x3, 0xf3, 0x3, 0xf3, 0x3, 0xf4, 0x3, 0xf4, 0x3, 0xf4, 0x3, 
    0xf4, 0x3, 0xf5, 0x3, 0xf5, 0x3, 0xf5, 0x3, 0xf5, 0x3, 0xf5, 0x3, 0xf6, 
    0x3, 0xf6, 0x3, 0xf6, 0x3, 0xf7, 0x3, 0xf7, 0x3, 0xf7, 0x3, 0xf8, 0x3, 
    0xf8, 0x3, 0xf8, 0x3, 0xf9, 0x3, 0xf9, 0x3, 0xf9, 0x3, 0xfa, 0x3, 0xfa, 
    0x3, 0xfa, 0x3, 0xfb, 0x3, 0xfb, 0x3, 0xfb, 0x3, 0xfc, 0x3, 0xfc, 0x3, 
    0xfc, 0x3, 0xfd, 0x3, 0xfd, 0x3, 0xfd, 0x3, 0xfe, 0x3, 0xfe, 0x3, 0xfe, 
    0x3, 0xff, 0x3, 0xff, 0x3, 0xff, 0x3, 0x100, 0x3, 0x100, 0x3, 0x100, 
    0x3, 0x101, 0x3, 0x101, 0x3, 0x101, 0x3, 0x102, 0x3, 0x102, 0x3, 0x102, 
    0x3, 0x102, 0x3, 0x102, 0x3, 0x103, 0x3, 0x103, 0x3, 0x103, 0x3, 0x103, 
    0x3, 0x103, 0x3, 0x104, 0x3, 0x104, 0x3, 0x104, 0x3, 0x104, 0x3, 0x105, 
    0x3, 0x105, 0x3, 0x105, 0x3, 0x106, 0x3, 0x106, 0x3, 0x106, 0x3, 0x106, 
    0x3, 0x106, 0x3, 0x106, 0x3, 0x106, 0x3, 0x107, 0x3, 0x107, 0x3, 0x107, 
    0x3, 0x107, 0x3, 0x107, 0x3, 0x107, 0x3, 0x107, 0x3, 0x107, 0x3, 0x108, 
    0x3, 0x108, 0x3, 0x108, 0x3, 0x108, 0x3, 0x109, 0x3, 0x109, 0x3, 0x109, 
    0x3, 0x10a, 0x3, 0x10a, 0x3, 0x10a, 0x3, 0x10a, 0x3, 0x10b, 0x3, 0x10b, 
    0x3, 0x10b, 0x3, 0x10b, 0x3, 0x10b, 0x2, 0x2, 0x10c, 0x2, 0x4, 0x6, 
    0x8, 0xa, 0xc, 0xe, 0x10, 0x12, 0x14, 0x16, 0x18, 0x1a, 0x1c, 0x1e, 
    0x20, 0x22, 0x24, 0x26, 0x28, 0x2a, 0x2c, 0x2e, 0x30, 0x32, 0x34, 0x36, 
    0x38, 0x3a, 0x3c, 0x3e, 0x40, 0x42, 0x44, 0x46, 0x48, 0x4a, 0x4c, 0x4e, 
    0x50, 0x52, 0x54, 0x56, 0x58, 0x5a, 0x5c, 0x5e, 0x60, 0x62, 0x64, 0x66, 
    0x68, 0x6a, 0x6c, 0x6e, 0x70, 0x72, 0x74, 0x76, 0x78, 0x7a, 0x7c, 0x7e, 
    0x80, 0x82, 0x84, 0x86, 0x88, 0x8a, 0x8c, 0x8e, 0x90, 0x92, 0x94, 0x96, 
    0x98, 0x9a, 0x9c, 0x9e, 0xa0, 0xa2, 0xa4, 0xa6, 0xa8, 0xaa, 0xac, 0xae, 
    0xb0, 0xb2, 0xb4, 0xb6, 0xb8, 0xba, 0xbc, 0xbe, 0xc0, 0xc2, 0xc4, 0xc6, 
    0xc8, 0xca, 0xcc, 0xce, 0xd0, 0xd2, 0xd4, 0xd6, 0xd8, 0xda, 0xdc, 0xde, 
    0xe0, 0xe2, 0xe4, 0xe6, 0xe8, 0xea, 0xec, 0xee, 0xf0, 0xf2, 0xf4, 0xf6, 
    0xf8, 0xfa, 0xfc, 0xfe, 0x100, 0x102, 0x104, 0x106, 0x108, 0x10a, 0x10c, 
    0x10e, 0x110, 0x112, 0x114, 0x116, 0x118, 0x11a, 0x11c, 0x11e, 0x120, 
    0x122, 0x124, 0x126, 0x128, 0x12a, 0x12c, 0x12e, 0x130, 0x132, 0x134, 
    0x136, 0x138, 0x13a, 0x13c, 0x13e, 0x140, 0x142, 0x144, 0x146, 0x148, 
    0x14a, 0x14c, 0x14e, 0x150, 0x152, 0x154, 0x156, 0x158, 0x15a, 0x15c, 
    0x15e, 0x160, 0x162, 0x164, 0x166, 0x168, 0x16a, 0x16c, 0x16e, 0x170, 
    0x172, 0x174, 0x176, 0x178, 0x17a, 0x17c, 0x17e, 0x180, 0x182, 0x184, 
    0x186, 0x188, 0x18a, 0x18c, 0x18e, 0x190, 0x192, 0x194, 0x196, 0x198, 
    0x19a, 0x19c, 0x19e, 0x1a0, 0x1a2, 0x1a4, 0x1a6, 0x1a8, 0x1aa, 0x1ac, 
    0x1ae, 0x1b0, 0x1b2, 0x1b4, 0x1b6, 0x1b8, 0x1ba, 0x1bc, 0x1be, 0x1c0, 
    0x1c2, 0x1c4, 0x1c6, 0x1c8, 0x1ca, 0x1cc, 0x1ce, 0x1d0, 0x1d2, 0x1d4, 
    0x1d6, 0x1d8, 0x1da, 0x1dc, 0x1de, 0x1e0, 0x1e2, 0x1e4, 0x1e6, 0x1e8, 
    0x1ea, 0x1ec, 0x1ee, 0x1f0, 0x1f2, 0x1f4, 0x1f6, 0x1f8, 0x1fa, 0x1fc, 
    0x1fe, 0x200, 0x202, 0x204, 0x206, 0x208, 0x20a, 0x20c, 0x20e, 0x210, 
    0x212, 0x214, 0x2, 0x14, 0x7, 0x2, 0x50, 0x50, 0x52, 0x52, 0x54, 0x54, 
    0x57, 0x57, 0x5c, 0x5d, 0x3, 0x2, 0x62, 0x6c, 0x4, 0x2, 0x31, 0x31, 
    0x34, 0x34, 0x6, 0x2, 0x16, 0x18, 0x28, 0x2a, 0x37, 0x37, 0x3c, 0x3c, 
    0x3, 0x2, 0x6, 0x8, 0x4, 0x2, 0x44, 0x45, 0x61, 0x61, 0x4, 0x2, 0xa, 
    0xa, 0x37, 0x37, 0x5, 0x2, 0x2f, 0x2f, 0x51, 0x51, 0x53, 0x53, 0x3, 
    0x2, 0x6f, 0x70, 0x3, 0x2, 0x54, 0x56, 0x4, 0x2, 0x50, 0x50, 0x52, 0x52, 
    0x3, 0x2, 0x4e, 0x4f, 0x3, 0x2, 0x4a, 0x4d, 0x3, 0x2, 0x6d, 0x6e, 0x3, 
    0x2, 0x3a, 0x3b, 0x3, 0x2, 0x3, 0x5, 0x4, 0x2, 0x54, 0x54, 0x5b, 0x5b, 
    0x4, 0x2, 0x32, 0x32, 0x38, 0x38, 0x2, 0x5ca, 0x2, 0x216, 0x3, 0x2, 
    0x2, 0x2, 0x4, 0x21d, 0x3, 0x2, 0x2, 0x2, 0x6, 0x226, 0x3, 0x2, 0x2, 
    0x2, 0x8, 0x228, 0x3, 0x2, 0x2, 0x2, 0xa, 0x22c, 0x3, 0x2, 0x2, 0x2, 
    0xc, 0x22e, 0x3, 0x2, 0x2, 0x2, 0xe, 0x233, 0x3, 0x2, 0x2, 0x2, 0x10, 
    0x235, 0x3, 0x2, 0x2, 0x2, 0x12, 0x237, 0x3, 0x2, 0x2, 0x2, 0x14, 0x23c, 
    0x3, 0x2, 0x2, 0x2, 0x16, 0x23f, 0x3, 0x2, 0x2, 0x2, 0x18, 0x243, 0x3, 
    0x2, 0x2, 0x2, 0x1a, 0x259, 0x3, 0x2, 0x2, 0x2, 0x1c, 0x25b, 0x3, 0x2, 
    0x2, 0x2, 0x1e, 0x25e, 0x3, 0x2, 0x2, 0x2, 0x20, 0x260, 0x3, 0x2, 0x2, 
    0x2, 0x22, 0x265, 0x3, 0x2, 0x2, 0x2, 0x24, 0x267, 0x3, 0x2, 0x2, 0x2, 
    0x26, 0x26a, 0x3, 0x2, 0x2, 0x2, 0x28, 0x26d, 0x3, 0x2, 0x2, 0x2, 0x2a, 
    0x272, 0x3, 0x2, 0x2, 0x2, 0x2c, 0x274, 0x3, 0x2, 0x2, 0x2, 0x2e, 0x279, 
    0x3, 0x2, 0x2, 0x2, 0x30, 0x27f, 0x3, 0x2, 0x2, 0x2, 0x32, 0x281, 0x3, 
    0x2, 0x2, 0x2, 0x34, 0x283, 0x3, 0x2, 0x2, 0x2, 0x36, 0x28b, 0x3, 0x2, 
    0x2, 0x2, 0x38, 0x28e, 0x3, 0x2, 0x2, 0x2, 0x3a, 0x290, 0x3, 0x2, 0x2, 
    0x2, 0x3c, 0x293, 0x3, 0x2, 0x2, 0x2, 0x3e, 0x296, 0x3, 0x2, 0x2, 0x2, 
    0x40, 0x299, 0x3, 0x2, 0x2, 0x2, 0x42, 0x29e, 0x3, 0x2, 0x2, 0x2, 0x44, 
    0x2a0, 0x3, 0x2, 0x2, 0x2, 0x46, 0x2a4, 0x3, 0x2, 0x2, 0x2, 0x48, 0x2a6, 
    0x3, 0x2, 0x2, 0x2, 0x4a, 0x2a9, 0x3, 0x2, 0x2, 0x2, 0x4c, 0x2b1, 0x3, 
    0x2, 0x2, 0x2, 0x4e, 0x2b9, 0x3, 0x2, 0x2, 0x2, 0x50, 0x2bd, 0x3, 0x2, 
    0x2, 0x2, 0x52, 0x2c1, 0x3, 0x2, 0x2, 0x2, 0x54, 0x2c4, 0x3, 0x2, 0x2, 
    0x2, 0x56, 0x2c7, 0x3, 0x2, 0x2, 0x2, 0x58, 0x2ca, 0x3, 0x2, 0x2, 0x2, 
    0x5a, 0x2d1, 0x3, 0x2, 0x2, 0x2, 0x5c, 0x2d6, 0x3, 0x2, 0x2, 0x2, 0x5e, 
    0x2d9, 0x3, 0x2, 0x2, 0x2, 0x60, 0x2db, 0x3, 0x2, 0x2, 0x2, 0x62, 0x2e1, 
    0x3, 0x2, 0x2, 0x2, 0x64, 0x2e4, 0x3, 0x2, 0x2, 0x2, 0x66, 0x2e7, 0x3, 
    0x2, 0x2, 0x2, 0x68, 0x2ea, 0x3, 0x2, 0x2, 0x2, 0x6a, 0x2ed, 0x3, 0x2, 
    0x2, 0x2, 0x6c, 0x2f0, 0x3, 0x2, 0x2, 0x2, 0x6e, 0x2f3, 0x3, 0x2, 0x2, 
    0x2, 0x70, 0x2f6, 0x3, 0x2, 0x2, 0x2, 0x72, 0x2fb, 0x3, 0x2, 0x2, 0x2, 
    0x74, 0x2ff, 0x3, 0x2, 0x2, 0x2, 0x76, 0x302, 0x3, 0x2, 0x2, 0x2, 0x78, 
    0x304, 0x3, 0x2, 0x2, 0x2, 0x7a, 0x30a, 0x3, 0x2, 0x2, 0x2, 0x7c, 0x30d, 
    0x3, 0x2, 0x2, 0x2, 0x7e, 0x310, 0x3, 0x2, 0x2, 0x2, 0x80, 0x315, 0x3, 
    0x2, 0x2, 0x2, 0x82, 0x317, 0x3, 0x2, 0x2, 0x2, 0x84, 0x31b, 0x3, 0x2, 
    0x2, 0x2, 0x86, 0x31e, 0x3, 0x2, 0x2, 0x2, 0x88, 0x321, 0x3, 0x2, 0x2, 
    0x2, 0x8a, 0x324, 0x3, 0x2, 0x2, 0x2, 0x8c, 0x326, 0x3, 0x2, 0x2, 0x2, 
    0x8e, 0x329, 0x3, 0x2, 0x2, 0x2, 0x90, 0x32b, 0x3, 0x2, 0x2, 0x2, 0x92, 
    0x331, 0x3, 0x2, 0x2, 0x2, 0x94, 0x334, 0x3, 0x2, 0x2, 0x2, 0x96, 0x338, 
    0x3, 0x2, 0x2, 0x2, 0x98, 0x33a, 0x3, 0x2, 0x2, 0x2, 0x9a, 0x340, 0x3, 
    0x2, 0x2, 0x2, 0x9c, 0x344, 0x3, 0x2, 0x2, 0x2, 0x9e, 0x346, 0x3, 0x2, 
    0x2, 0x2, 0xa0, 0x34a, 0x3, 0x2, 0x2, 0x2, 0xa2, 0x34d, 0x3, 0x2, 0x2, 
    0x2, 0xa4, 0x350, 0x3, 0x2, 0x2, 0x2, 0xa6, 0x353, 0x3, 0x2, 0x2, 0x2, 
    0xa8, 0x355, 0x3, 0x2, 0x2, 0x2, 0xaa, 0x35b, 0x3, 0x2, 0x2, 0x2, 0xac, 
    0x35e, 0x3, 0x2, 0x2, 0x2, 0xae, 0x361, 0x3, 0x2, 0x2, 0x2, 0xb0, 0x367, 
    0x3, 0x2, 0x2, 0x2, 0xb2, 0x36a, 0x3, 0x2, 0x2, 0x2, 0xb4, 0x372, 0x3, 
    0x2, 0x2, 0x2, 0xb6, 0x377, 0x3, 0x2, 0x2, 0x2, 0xb8, 0x37a, 0x3, 0x2, 
    0x2, 0x2, 0xba, 0x37d, 0x3, 0x2, 0x2, 0x2, 0xbc, 0x384, 0x3, 0x2, 0x2, 
    0x2, 0xbe, 0x387, 0x3, 0x2, 0x2, 0x2, 0xc0, 0x38b, 0x3, 0x2, 0x2, 0x2, 
    0xc2, 0x391, 0x3, 0x2, 0x2, 0x2, 0xc4, 0x394, 0x3, 0x2, 0x2, 0x2, 0xc6, 
    0x397, 0x3, 0x2, 0x2, 0x2, 0xc8, 0x39d, 0x3, 0x2, 0x2, 0x2, 0xca, 0x3a0, 
    0x3, 0x2, 0x2, 0x2, 0xcc, 0x3a3, 0x3, 0x2, 0x2, 0x2, 0xce, 0x3a9, 0x3, 
    0x2, 0x2, 0x2, 0xd0, 0x3ac, 0x3, 0x2, 0x2, 0x2, 0xd2, 0x3af, 0x3, 0x2, 
    0x2, 0x2, 0xd4, 0x3b5, 0x3, 0x2, 0x2, 0x2, 0xd6, 0x3b8, 0x3, 0x2, 0x2, 
    0x2, 0xd8, 0x3bb, 0x3, 0x2, 0x2, 0x2, 0xda, 0x3c1, 0x3, 0x2, 0x2, 0x2, 
    0xdc, 0x3c4, 0x3, 0x2, 0x2, 0x2, 0xde, 0x3c7, 0x3, 0x2, 0x2, 0x2, 0xe0, 
    0x3cd, 0x3, 0x2, 0x2, 0x2, 0xe2, 0x3d0, 0x3, 0x2, 0x2, 0x2, 0xe4, 0x3d3, 
    0x3, 0x2, 0x2, 0x2, 0xe6, 0x3d9, 0x3, 0x2, 0x2, 0x2, 0xe8, 0x3dc, 0x3, 
    0x2, 0x2, 0x2, 0xea, 0x3df, 0x3, 0x2, 0x2, 0x2, 0xec, 0x3e5, 0x3, 0x2, 
    0x2, 0x2, 0xee, 0x3e8, 0x3, 0x2, 0x2, 0x2, 0xf0, 0x3eb, 0x3, 0x2, 0x2, 
    0x2, 0xf2, 0x3f1, 0x3, 0x2, 0x2, 0x2, 0xf4, 0x3f4, 0x3, 0x2, 0x2, 0x2, 
    0xf6, 0x3f7, 0x3, 0x2, 0x2, 0x2, 0xf8, 0x3fd, 0x3, 0x2, 0x2, 0x2, 0xfa, 
    0x400, 0x3, 0x2, 0x2, 0x2, 0xfc, 0x403, 0x3, 0x2, 0x2, 0x2, 0xfe, 0x409, 
    0x3, 0x2, 0x2, 0x2, 0x100, 0x40c, 0x3, 0x2, 0x2, 0x2, 0x102, 0x40f, 
    0x3, 0x2, 0x2, 0x2, 0x104, 0x411, 0x3, 0x2, 0x2, 0x2, 0x106, 0x417, 
    0x3, 0x2, 0x2, 0x2, 0x108, 0x41a, 0x3, 0x2, 0x2, 0x2, 0x10a, 0x41d, 
    0x3, 0x2, 0x2, 0x2, 0x10c, 0x423, 0x3, 0x2, 0x2, 0x2, 0x10e, 0x426, 
    0x3, 0x2, 0x2, 0x2, 0x110, 0x42b, 0x3, 0x2, 0x2, 0x2, 0x112, 0x430, 
    0x3, 0x2, 0x2, 0x2, 0x114, 0x435, 0x3, 0x2, 0x2, 0x2, 0x116, 0x437, 
    0x3, 0x2, 0x2, 0x2, 0x118, 0x43a, 0x3, 0x2, 0x2, 0x2, 0x11a, 0x43c, 
    0x3, 0x2, 0x2, 0x2, 0x11c, 0x43e, 0x3, 0x2, 0x2, 0x2, 0x11e, 0x444, 
    0x3, 0x2, 0x2, 0x2, 0x120, 0x447, 0x3, 0x2, 0x2, 0x2, 0x122, 0x44a, 
    0x3, 0x2, 0x2, 0x2, 0x124, 0x450, 0x3, 0x2, 0x2, 0x2, 0x126, 0x453, 
    0x3, 0x2, 0x2, 0x2, 0x128, 0x458, 0x3, 0x2, 0x2, 0x2, 0x12a, 0x45d, 
    0x3, 0x2, 0x2, 0x2, 0x12c, 0x462, 0x3, 0x2, 0x2, 0x2, 0x12e, 0x464, 
    0x3, 0x2, 0x2, 0x2, 0x130, 0x467, 0x3, 0x2, 0x2, 0x2, 0x132, 0x469, 
    0x3, 0x2, 0x2, 0x2, 0x134, 0x46b, 0x3, 0x2, 0x2, 0x2, 0x136, 0x46d, 
    0x3, 0x2, 0x2, 0x2, 0x138, 0x46f, 0x3, 0x2, 0x2, 0x2, 0x13a, 0x472, 
    0x3, 0x2, 0x2, 0x2, 0x13c, 0x477, 0x3, 0x2, 0x2, 0x2, 0x13e, 0x47c, 
    0x3, 0x2, 0x2, 0x2, 0x140, 0x481, 0x3, 0x2, 0x2, 0x2, 0x142, 0x486, 
    0x3, 0x2, 0x2, 0x2, 0x144, 0x48b, 0x3, 0x2, 0x2, 0x2, 0x146, 0x490, 
    0x3, 0x2, 0x2, 0x2, 0x148, 0x492, 0x3, 0x2, 0x2, 0x2, 0x14a, 0x496, 
    0x3, 0x2, 0x2, 0x2, 0x14c, 0x498, 0x3, 0x2, 0x2, 0x2, 0x14e, 0x49c, 
    0x3, 0x2, 0x2, 0x2, 0x150, 0x49e, 0x3, 0x2, 0x2, 0x2, 0x152, 0x4a2, 
    0x3, 0x2, 0x2, 0x2, 0x154, 0x4a8, 0x3, 0x2, 0x2, 0x2, 0x156, 0x4aa, 
    0x3, 0x2, 0x2, 0x2, 0x158, 0x4ae, 0x3, 0x2, 0x2, 0x2, 0x15a, 0x4b2, 
    0x3, 0x2, 0x2, 0x2, 0x15c, 0x4b4, 0x3, 0x2, 0x2, 0x2, 0x15e, 0x4b6, 
    0x3, 0x2, 0x2, 0x2, 0x160, 0x4be, 0x3, 0x2, 0x2, 0x2, 0x162, 0x4c0, 
    0x3, 0x2, 0x2, 0x2, 0x164, 0x4c2, 0x3, 0x2, 0x2, 0x2, 0x166, 0x4c4, 
    0x3, 0x2, 0x2, 0x2, 0x168, 0x4c6, 0x3, 0x2, 0x2, 0x2, 0x16a, 0x4ca, 
    0x3, 0x2, 0x2, 0x2, 0x16c, 0x4ce, 0x3, 0x2, 0x2, 0x2, 0x16e, 0x4d2, 
    0x3, 0x2, 0x2, 0x2, 0x170, 0x4d6, 0x3, 0x2, 0x2, 0x2, 0x172, 0x4d8, 
    0x3, 0x2, 0x2, 0x2, 0x174, 0x4dd, 0x3, 0x2, 0x2, 0x2, 0x176, 0x4e1, 
    0x3, 0x2, 0x2, 0x2, 0x178, 0x4e6, 0x3, 0x2, 0x2, 0x2, 0x17a, 0x4e8, 
    0x3, 0x2, 0x2, 0x2, 0x17c, 0x4ef, 0x3, 0x2, 0x2, 0x2, 0x17e, 0x4f5, 
    0x3, 0x2, 0x2, 0x2, 0x180, 0x4f7, 0x3, 0x2, 0x2, 0x2, 0x182, 0x4fe, 
    0x3, 0x2, 0x2, 0x2, 0x184, 0x500, 0x3, 0x2, 0x2, 0x2, 0x186, 0x507, 
    0x3, 0x2, 0x2, 0x2, 0x188, 0x50f, 0x3, 0x2, 0x2, 0x2, 0x18a, 0x520, 
    0x3, 0x2, 0x2, 0x2, 0x18c, 0x524, 0x3, 0x2, 0x2, 0x2, 0x18e, 0x528, 
    0x3, 0x2, 0x2, 0x2, 0x190, 0x532, 0x3, 0x2, 0x2, 0x2, 0x192, 0x536, 
    0x3, 0x2, 0x2, 0x2, 0x194, 0x53c, 0x3, 0x2, 0x2, 0x2, 0x196, 0x53e, 
    0x3, 0x2, 0x2, 0x2, 0x198, 0x542, 0x3, 0x2, 0x2, 0x2, 0x19a, 0x544, 
    0x3, 0x2, 0x2, 0x2, 0x19c, 0x548, 0x3, 0x2, 0x2, 0x2, 0x19e, 0x54a, 
    0x3, 0x2, 0x2, 0x2, 0x1a0, 0x54e, 0x3, 0x2, 0x2, 0x2, 0x1a2, 0x552, 
    0x3, 0x2, 0x2, 0x2, 0x1a4, 0x556, 0x3, 0x2, 0x2, 0x2, 0x1a6, 0x55a, 
    0x3, 0x2, 0x2, 0x2, 0x1a8, 0x55e, 0x3, 0x2, 0x2, 0x2, 0x1aa, 0x560, 
    0x3, 0x2, 0x2, 0x2, 0x1ac, 0x562, 0x3, 0x2, 0x2, 0x2, 0x1ae, 0x565, 
    0x3, 0x2, 0x2, 0x2, 0x1b0, 0x568, 0x3, 0x2, 0x2, 0x2, 0x1b2, 0x56b, 
    0x3, 0x2, 0x2, 0x2, 0x1b4, 0x56e, 0x3, 0x2, 0x2, 0x2, 0x1b6, 0x574, 
    0x3, 0x2, 0x2, 0x2, 0x1b8, 0x578, 0x3, 0x2, 0x2, 0x2, 0x1ba, 0x57d, 
    0x3, 0x2, 0x2, 0x2, 0x1bc, 0x580, 0x3, 0x2, 0x2, 0x2, 0x1be, 0x584, 
    0x3, 0x2, 0x2, 0x2, 0x1c0, 0x589, 0x3, 0x2, 0x2, 0x2, 0x1c2, 0x58d, 
    0x3, 0x2, 0x2, 0x2, 0x1c4, 0x592, 0x3, 0x2, 0x2, 0x2, 0x1c6, 0x596, 
    0x3, 0x2, 0x2, 0x2, 0x1c8, 0x59a, 0x3, 0x2, 0x2, 0x2, 0x1ca, 0x59d, 
    0x3, 0x2, 0x2, 0x2, 0x1cc, 0x5a1, 0x3, 0x2, 0x2, 0x2, 0x1ce, 0x5a5, 
    0x3, 0x2, 0x2, 0x2, 0x1d0, 0x5a9, 0x3, 0x2, 0x2, 0x2, 0x1d2, 0x5ae, 
    0x3, 0x2, 0x2, 0x2, 0x1d4, 0x5b2, 0x3, 0x2, 0x2, 0x2, 0x1d6, 0x5b6, 
    0x3, 0x2, 0x2, 0x2, 0x1d8, 0x5b9, 0x3, 0x2, 0x2, 0x2, 0x1da, 0x5bc, 
    0x3, 0x2, 0x2, 0x2, 0x1dc, 0x5c0, 0x3, 0x2, 0x2, 0x2, 0x1de, 0x5c6, 
    0x3, 0x2, 0x2, 0x2, 0x1e0, 0x5cc, 0x3, 0x2, 0x2, 0x2, 0x1e2, 0x5d0, 
    0x3, 0x2, 0x2, 0x2, 0x1e4, 0x5d4, 0x3, 0x2, 0x2, 0x2, 0x1e6, 0x5d8, 
    0x3, 0x2, 0x2, 0x2, 0x1e8, 0x5dc, 0x3, 0x2, 0x2, 0x2, 0x1ea, 0x5e1, 
    0x3, 0x2, 0x2, 0x2, 0x1ec, 0x5e4, 0x3, 0x2, 0x2, 0x2, 0x1ee, 0x5e7, 
    0x3, 0x2, 0x2, 0x2, 0x1f0, 0x5ea, 0x3, 0x2, 0x2, 0x2, 0x1f2, 0x5ed, 
    0x3, 0x2, 0x2, 0x2, 0x1f4, 0x5f0, 0x3, 0x2, 0x2, 0x2, 0x1f6, 0x5f3, 
    0x3, 0x2, 0x2, 0x2, 0x1f8, 0x5f6, 0x3, 0x2, 0x2, 0x2, 0x1fa, 0x5f9, 
    0x3, 0x2, 0x2, 0x2, 0x1fc, 0x5fc, 0x3, 0x2, 0x2, 0x2, 0x1fe, 0x5ff, 
    0x3, 0x2, 0x2, 0x2, 0x200, 0x602, 0x3, 0x2, 0x2, 0x2, 0x202, 0x605, 
    0x3, 0x2, 0x2, 0x2, 0x204, 0x60a, 0x3, 0x2, 0x2, 0x2, 0x206, 0x60f, 
    0x3, 0x2, 0x2, 0x2, 0x208, 0x613, 0x3, 0x2, 0x2, 0x2, 0x20a, 0x616, 
    0x3, 0x2, 0x2, 0x2, 0x20c, 0x61d, 0x3, 0x2, 0x2, 0x2, 0x20e, 0x625, 
    0x3, 0x2, 0x2, 0x2, 0x210, 0x629, 0x3, 0x2, 0x2, 0x2, 0x212, 0x62c, 
    0x3, 0x2, 0x2, 0x2, 0x214, 0x630, 0x3, 0x2, 0x2, 0x2, 0x216, 0x217, 
    0x7, 0x3f, 0x2, 0x2, 0x217, 0x218, 0x7, 0x44, 0x2, 0x2, 0x218, 0x219, 
    0x5, 0xe, 0x8, 0x2, 0x219, 0x21a, 0x7, 0x61, 0x2, 0x2, 0x21a, 0x21b, 
    0x5, 0xb2, 0x5a, 0x2, 0x21b, 0x21c, 0x7, 0x45, 0x2, 0x2, 0x21c, 0x3, 
    0x3, 0x2, 0x2, 0x2, 0x21d, 0x21e, 0x5, 0x15a, 0xae, 0x2, 0x21e, 0x21f, 
    0x7, 0x5f, 0x2, 0x2, 0x21f, 0x220, 0x5, 0xe, 0x8, 0x2, 0x220, 0x5, 0x3, 
    0x2, 0x2, 0x2, 0x221, 0x227, 0x5, 0xb8, 0x5d, 0x2, 0x222, 0x227, 0x5, 
    0x1ac, 0xd7, 0x2, 0x223, 0x227, 0x5, 0x1ae, 0xd8, 0x2, 0x224, 0x227, 
    0x5, 0x1b0, 0xd9, 0x2, 0x225, 0x227, 0x5, 0x1b2, 0xda, 0x2, 0x226, 0x221, 
    0x3, 0x2, 0x2, 0x2, 0x226, 0x222, 0x3, 0x2, 0x2, 0x2, 0x226, 0x223, 
    0x3, 0x2, 0x2, 0x2, 0x226, 0x224, 0x3, 0x2, 0x2, 0x2, 0x226, 0x225, 
    0x3, 0x2, 0x2, 0x2, 0x227, 0x7, 0x3, 0x2, 0x2, 0x2, 0x228, 0x229, 0x9, 
    0x2, 0x2, 0x2, 0x229, 0x9, 0x3, 0x2, 0x2, 0x2, 0x22a, 0x22d, 0x5, 0x6, 
    0x4, 0x2, 0x22b, 0x22d, 0x5, 0x1b4, 0xdb, 0x2, 0x22c, 0x22a, 0x3, 0x2, 
    0x2, 0x2, 0x22c, 0x22b, 0x3, 0x2, 0x2, 0x2, 0x22d, 0xb, 0x3, 0x2, 0x2, 
    0x2, 0x22e, 0x22f, 0x5, 0xfa, 0x7e, 0x2, 0x22f, 0x230, 0x5, 0x62, 0x32, 
    0x2, 0x230, 0xd, 0x3, 0x2, 0x2, 0x2, 0x231, 0x234, 0x5, 0xc, 0x7, 0x2, 
    0x232, 0x234, 0x5, 0x1b6, 0xdc, 0x2, 0x233, 0x231, 0x3, 0x2, 0x2, 0x2, 
    0x233, 0x232, 0x3, 0x2, 0x2, 0x2, 0x234, 0xf, 0x3, 0x2, 0x2, 0x2, 0x235, 
    0x236, 0x9, 0x3, 0x2, 0x2, 0x236, 0x11, 0x3, 0x2, 0x2, 0x2, 0x237, 0x238, 
    0x5, 0xc, 0x7, 0x2, 0x238, 0x13, 0x3, 0x2, 0x2, 0x2, 0x239, 0x23d, 0x5, 
    0x1b8, 0xdd, 0x2, 0x23a, 0x23d, 0x5, 0x4a, 0x26, 0x2, 0x23b, 0x23d, 
    0x5, 0x4c, 0x27, 0x2, 0x23c, 0x239, 0x3, 0x2, 0x2, 0x2, 0x23c, 0x23a, 
    0x3, 0x2, 0x2, 0x2, 0x23c, 0x23b, 0x3, 0x2, 0x2, 0x2, 0x23d, 0x15, 0x3, 
    0x2, 0x2, 0x2, 0x23e, 0x240, 0x5, 0x18a, 0xc6, 0x2, 0x23f, 0x23e, 0x3, 
    0x2, 0x2, 0x2, 0x240, 0x241, 0x3, 0x2, 0x2, 0x2, 0x241, 0x23f, 0x3, 
    0x2, 0x2, 0x2, 0x241, 0x242, 0x3, 0x2, 0x2, 0x2, 0x242, 0x17, 0x3, 0x2, 
    0x2, 0x2, 0x243, 0x244, 0x5, 0x2e, 0x18, 0x2, 0x244, 0x245, 0x5, 0x14a, 
    0xa6, 0x2, 0x245, 0x19, 0x3, 0x2, 0x2, 0x2, 0x246, 0x25a, 0x7, 0x36, 
    0x2, 0x2, 0x247, 0x25a, 0x7, 0x15, 0x2, 0x2, 0x248, 0x25a, 0x7, 0x2d, 
    0x2, 0x2, 0x249, 0x25a, 0x7, 0x25, 0x2, 0x2, 0x24a, 0x25a, 0x7, 0x26, 
    0x2, 0x2, 0x24b, 0x25a, 0x7, 0x20, 0x2, 0x2, 0x24c, 0x25a, 0x7, 0x1c, 
    0x2, 0x2, 0x24d, 0x25a, 0x7, 0x2e, 0x2, 0x2, 0x24e, 0x25a, 0x7, 0x35, 
    0x2, 0x2, 0x24f, 0x25a, 0x7, 0x3d, 0x2, 0x2, 0x250, 0x25a, 0x7, 0x3e, 
    0x2, 0x2, 0x251, 0x25a, 0x7, 0x3, 0x2, 0x2, 0x252, 0x25a, 0x7, 0x4, 
    0x2, 0x2, 0x253, 0x25a, 0x7, 0x5, 0x2, 0x2, 0x254, 0x25a, 0x5, 0x28, 
    0x15, 0x2, 0x255, 0x25a, 0x5, 0x1c, 0xf, 0x2, 0x256, 0x25a, 0x5, 0x24, 
    0x13, 0x2, 0x257, 0x25a, 0x5, 0x44, 0x23, 0x2, 0x258, 0x25a, 0x5, 0x1ba, 
    0xde, 0x2, 0x259, 0x246, 0x3, 0x2, 0x2, 0x2, 0x259, 0x247, 0x3, 0x2, 
    0x2, 0x2, 0x259, 0x248, 0x3, 0x2, 0x2, 0x2, 0x259, 0x249, 0x3, 0x2, 
    0x2, 0x2, 0x259, 0x24a, 0x3, 0x2, 0x2, 0x2, 0x259, 0x24b, 0x3, 0x2, 
    0x2, 0x2, 0x259, 0x24c, 0x3, 0x2, 0x2, 0x2, 0x259, 0x24d, 0x3, 0x2, 
    0x2, 0x2, 0x259, 0x24e, 0x3, 0x2, 0x2, 0x2, 0x259, 0x24f, 0x3, 0x2, 
    0x2, 0x2, 0x259, 0x250, 0x3, 0x2, 0x2, 0x2, 0x259, 0x251, 0x3, 0x2, 
    0x2, 0x2, 0x259, 0x252, 0x3, 0x2, 0x2, 0x2, 0x259, 0x253, 0x3, 0x2, 
    0x2, 0x2, 0x259, 0x254, 0x3, 0x2, 0x2, 0x2, 0x259, 0x255, 0x3, 0x2, 
    0x2, 0x2, 0x259, 0x256, 0x3, 0x2, 0x2, 0x2, 0x259, 0x257, 0x3, 0x2, 
    0x2, 0x2, 0x259, 0x258, 0x3, 0x2, 0x2, 0x2, 0x25a, 0x1b, 0x3, 0x2, 0x2, 
    0x2, 0x25b, 0x25c, 0x5, 0x1e, 0x10, 0x2, 0x25c, 0x25d, 0x5, 0x16e, 0xb8, 
    0x2, 0x25d, 0x1d, 0x3, 0x2, 0x2, 0x2, 0x25e, 0x25f, 0x9, 0x4, 0x2, 0x2, 
    0x25f, 0x1f, 0x3, 0x2, 0x2, 0x2, 0x260, 0x261, 0x5, 0x19c, 0xcf, 0x2, 
    0x261, 0x262, 0x5, 0x6c, 0x37, 0x2, 0x262, 0x21, 0x3, 0x2, 0x2, 0x2, 
    0x263, 0x266, 0x5, 0x2e, 0x18, 0x2, 0x264, 0x266, 0x5, 0x1bc, 0xdf, 
    0x2, 0x265, 0x263, 0x3, 0x2, 0x2, 0x2, 0x265, 0x264, 0x3, 0x2, 0x2, 
    0x2, 0x266, 0x23, 0x3, 0x2, 0x2, 0x2, 0x267, 0x268, 0x7, 0x1e, 0x2, 
    0x2, 0x268, 0x269, 0x5, 0x170, 0xb9, 0x2, 0x269, 0x25, 0x3, 0x2, 0x2, 
    0x2, 0x26a, 0x26b, 0x5, 0x44, 0x23, 0x2, 0x26b, 0x26c, 0x5, 0x14e, 0xa8, 
    0x2, 0x26c, 0x27, 0x3, 0x2, 0x2, 0x2, 0x26d, 0x26e, 0x7, 0x3c, 0x2, 
    0x2, 0x26e, 0x26f, 0x7, 0x44, 0x2, 0x2, 0x26f, 0x270, 0x5, 0x40, 0x21, 
    0x2, 0x270, 0x271, 0x7, 0x45, 0x2, 0x2, 0x271, 0x29, 0x3, 0x2, 0x2, 
    0x2, 0x272, 0x273, 0x9, 0x5, 0x2, 0x2, 0x273, 0x2b, 0x3, 0x2, 0x2, 0x2, 
    0x274, 0x275, 0x7, 0x39, 0x2, 0x2, 0x275, 0x276, 0x7, 0x44, 0x2, 0x2, 
    0x276, 0x277, 0x5, 0x16c, 0xb7, 0x2, 0x277, 0x278, 0x7, 0x45, 0x2, 0x2, 
    0x278, 0x2d, 0x3, 0x2, 0x2, 0x2, 0x279, 0x27a, 0x5, 0x70, 0x39, 0x2, 
    0x27a, 0x27b, 0x5, 0x116, 0x8c, 0x2, 0x27b, 0x27c, 0x5, 0x72, 0x3a, 
    0x2, 0x27c, 0x2f, 0x3, 0x2, 0x2, 0x2, 0x27d, 0x280, 0x5, 0x1be, 0xe0, 
    0x2, 0x27e, 0x280, 0x5, 0x34, 0x1b, 0x2, 0x27f, 0x27d, 0x3, 0x2, 0x2, 
    0x2, 0x27f, 0x27e, 0x3, 0x2, 0x2, 0x2, 0x280, 0x31, 0x3, 0x2, 0x2, 0x2, 
    0x281, 0x282, 0x9, 0x6, 0x2, 0x2, 0x282, 0x33, 0x3, 0x2, 0x2, 0x2, 0x283, 
    0x284, 0x7, 0x9, 0x2, 0x2, 0x284, 0x285, 0x7, 0x44, 0x2, 0x2, 0x285, 
    0x286, 0x7, 0x44, 0x2, 0x2, 0x286, 0x287, 0x5, 0x36, 0x1c, 0x2, 0x287, 
    0x288, 0x7, 0x45, 0x2, 0x2, 0x288, 0x289, 0x7, 0x45, 0x2, 0x2, 0x289, 
    0x35, 0x3, 0x2, 0x2, 0x2, 0x28a, 0x28c, 0x5, 0x7c, 0x3f, 0x2, 0x28b, 
    0x28a, 0x3, 0x2, 0x2, 0x2, 0x28b, 0x28c, 0x3, 0x2, 0x2, 0x2, 0x28c, 
    0x37, 0x3, 0x2, 0x2, 0x2, 0x28d, 0x28f, 0x5, 0x82, 0x42, 0x2, 0x28e, 
    0x28d, 0x3, 0x2, 0x2, 0x2, 0x28e, 0x28f, 0x3, 0x2, 0x2, 0x2, 0x28f, 
    0x39, 0x3, 0x2, 0x2, 0x2, 0x290, 0x291, 0x5, 0x19e, 0xd0, 0x2, 0x291, 
    0x292, 0x5, 0x172, 0xba, 0x2, 0x292, 0x3b, 0x3, 0x2, 0x2, 0x2, 0x293, 
    0x294, 0x5, 0x126, 0x94, 0x2, 0x294, 0x295, 0x5, 0x152, 0xaa, 0x2, 0x295, 
    0x3d, 0x3, 0x2, 0x2, 0x2, 0x296, 0x297, 0x5, 0x16, 0xc, 0x2, 0x297, 
    0x298, 0x5, 0x1a2, 0xd2, 0x2, 0x298, 0x3f, 0x3, 0x2, 0x2, 0x2, 0x299, 
    0x29a, 0x5, 0x20, 0x11, 0x2, 0x29a, 0x29b, 0x5, 0x86, 0x44, 0x2, 0x29b, 
    0x41, 0x3, 0x2, 0x2, 0x2, 0x29c, 0x29f, 0x5, 0x3a, 0x1e, 0x2, 0x29d, 
    0x29f, 0x5, 0x1c0, 0xe1, 0x2, 0x29e, 0x29c, 0x3, 0x2, 0x2, 0x2, 0x29e, 
    0x29d, 0x3, 0x2, 0x2, 0x2, 0x29f, 0x43, 0x3, 0x2, 0x2, 0x2, 0x2a0, 0x2a1, 
    0x7, 0x72, 0x2, 0x2, 0x2a1, 0x45, 0x3, 0x2, 0x2, 0x2, 0x2a2, 0x2a5, 
    0x5, 0xe, 0x8, 0x2, 0x2a3, 0x2a5, 0x5, 0x1c2, 0xe2, 0x2, 0x2a4, 0x2a2, 
    0x3, 0x2, 0x2, 0x2, 0x2a4, 0x2a3, 0x3, 0x2, 0x2, 0x2, 0x2a5, 0x47, 0x3, 
    0x2, 0x2, 0x2, 0x2a6, 0x2a7, 0x5, 0x130, 0x99, 0x2, 0x2a7, 0x2a8, 0x7, 
    0x62, 0x2, 0x2, 0x2a8, 0x49, 0x3, 0x2, 0x2, 0x2, 0x2a9, 0x2aa, 0x7, 
    0x42, 0x2, 0x2, 0x2aa, 0x2ab, 0x7, 0x44, 0x2, 0x2, 0x2ab, 0x2ac, 0x5, 
    0x12, 0xa, 0x2, 0x2ac, 0x2ad, 0x7, 0x61, 0x2, 0x2, 0x2ad, 0x2ae, 0x5, 
    0x5a, 0x2e, 0x2, 0x2ae, 0x2af, 0x7, 0x45, 0x2, 0x2, 0x2af, 0x2b0, 0x7, 
    0x60, 0x2, 0x2, 0x2b0, 0x4b, 0x3, 0x2, 0x2, 0x2, 0x2b1, 0x2b2, 0x5, 
    0x32, 0x1a, 0x2, 0x2b2, 0x2b3, 0x5, 0x8e, 0x48, 0x2, 0x2b3, 0x2b4, 0x7, 
    0x44, 0x2, 0x2, 0x2b4, 0x2b5, 0x5, 0x96, 0x4c, 0x2, 0x2b5, 0x2b6, 0x5, 
    0x9a, 0x4e, 0x2, 0x2b6, 0x2b7, 0x7, 0x45, 0x2, 0x2, 0x2b7, 0x2b8, 0x7, 
    0x60, 0x2, 0x2, 0x2b8, 0x4d, 0x3, 0x2, 0x2, 0x2, 0x2b9, 0x2ba, 0x5, 
    0x17c, 0xbf, 0x2, 0x2ba, 0x2bb, 0x7, 0x5f, 0x2, 0x2, 0x2bb, 0x2bc, 0x5, 
    0x190, 0xc9, 0x2, 0x2bc, 0x4f, 0x3, 0x2, 0x2, 0x2, 0x2bd, 0x2be, 0x7, 
    0x48, 0x2, 0x2, 0x2be, 0x2bf, 0x5, 0x9c, 0x4f, 0x2, 0x2bf, 0x2c0, 0x7, 
    0x49, 0x2, 0x2, 0x2c0, 0x51, 0x3, 0x2, 0x2, 0x2, 0x2c1, 0x2c2, 0x5, 
    0x5e, 0x30, 0x2, 0x2c2, 0x2c3, 0x7, 0x60, 0x2, 0x2, 0x2c3, 0x53, 0x3, 
    0x2, 0x2, 0x2, 0x2c4, 0x2c5, 0x5, 0x17e, 0xc0, 0x2, 0x2c5, 0x2c6, 0x7, 
    0x60, 0x2, 0x2, 0x2c6, 0x55, 0x3, 0x2, 0x2, 0x2, 0x2c7, 0x2c8, 0x5, 
    0xa2, 0x52, 0x2, 0x2c8, 0x2c9, 0x7, 0x2, 0x2, 0x3, 0x2c9, 0x57, 0x3, 
    0x2, 0x2, 0x2, 0x2ca, 0x2cb, 0x5, 0x64, 0x33, 0x2, 0x2cb, 0x2cc, 0x5, 
    0xa4, 0x53, 0x2, 0x2cc, 0x2cd, 0x5, 0x2e, 0x18, 0x2, 0x2cd, 0x2ce, 0x5, 
    0xa6, 0x54, 0x2, 0x2ce, 0x2cf, 0x5, 0x50, 0x29, 0x2, 0x2cf, 0x59, 0x3, 
    0x2, 0x2, 0x2, 0x2d0, 0x2d2, 0x7, 0x74, 0x2, 0x2, 0x2d1, 0x2d0, 0x3, 
    0x2, 0x2, 0x2, 0x2d2, 0x2d3, 0x3, 0x2, 0x2, 0x2, 0x2d3, 0x2d1, 0x3, 
    0x2, 0x2, 0x2, 0x2d3, 0x2d4, 0x3, 0x2, 0x2, 0x2, 0x2d4, 0x5b, 0x3, 0x2, 
    0x2, 0x2, 0x2d5, 0x2d7, 0x7, 0x2b, 0x2, 0x2, 0x2d6, 0x2d5, 0x3, 0x2, 
    0x2, 0x2, 0x2d6, 0x2d7, 0x3, 0x2, 0x2, 0x2, 0x2d7, 0x5d, 0x3, 0x2, 0x2, 
    0x2, 0x2d8, 0x2da, 0x5, 0xac, 0x57, 0x2, 0x2d9, 0x2d8, 0x3, 0x2, 0x2, 
    0x2, 0x2d9, 0x2da, 0x3, 0x2, 0x2, 0x2, 0x2da, 0x5f, 0x3, 0x2, 0x2, 0x2, 
    0x2db, 0x2dc, 0x7, 0x5e, 0x2, 0x2, 0x2dc, 0x2dd, 0x5, 0xac, 0x57, 0x2, 
    0x2dd, 0x2de, 0x7, 0x5f, 0x2, 0x2, 0x2de, 0x2df, 0x5, 0xc, 0x7, 0x2, 
    0x2df, 0x61, 0x3, 0x2, 0x2, 0x2, 0x2e0, 0x2e2, 0x5, 0x60, 0x31, 0x2, 
    0x2e1, 0x2e0, 0x3, 0x2, 0x2, 0x2, 0x2e1, 0x2e2, 0x3, 0x2, 0x2, 0x2, 
    0x2e2, 0x63, 0x3, 0x2, 0x2, 0x2, 0x2e3, 0x2e5, 0x7, 0x2b, 0x2, 0x2, 
    0x2e4, 0x2e3, 0x3, 0x2, 0x2, 0x2, 0x2e4, 0x2e5, 0x3, 0x2, 0x2, 0x2, 
    0x2e5, 0x65, 0x3, 0x2, 0x2, 0x2, 0x2e6, 0x2e8, 0x5, 0x100, 0x81, 0x2, 
    0x2e7, 0x2e6, 0x3, 0x2, 0x2, 0x2, 0x2e7, 0x2e8, 0x3, 0x2, 0x2, 0x2, 
    0x2e8, 0x67, 0x3, 0x2, 0x2, 0x2, 0x2e9, 0x2eb, 0x7, 0x72, 0x2, 0x2, 
    0x2ea, 0x2e9, 0x3, 0x2, 0x2, 0x2, 0x2ea, 0x2eb, 0x3, 0x2, 0x2, 0x2, 
    0x2eb, 0x69, 0x3, 0x2, 0x2, 0x2, 0x2ec, 0x2ee, 0x5, 0x108, 0x85, 0x2, 
    0x2ed, 0x2ec, 0x3, 0x2, 0x2, 0x2, 0x2ed, 0x2ee, 0x3, 0x2, 0x2, 0x2, 
    0x2ee, 0x6b, 0x3, 0x2, 0x2, 0x2, 0x2ef, 0x2f1, 0x5, 0x20, 0x11, 0x2, 
    0x2f0, 0x2ef, 0x3, 0x2, 0x2, 0x2, 0x2f0, 0x2f1, 0x3, 0x2, 0x2, 0x2, 
    0x2f1, 0x6d, 0x3, 0x2, 0x2, 0x2, 0x2f2, 0x2f4, 0x5, 0x2e, 0x18, 0x2, 
    0x2f3, 0x2f2, 0x3, 0x2, 0x2, 0x2, 0x2f3, 0x2f4, 0x3, 0x2, 0x2, 0x2, 
    0x2f4, 0x6f, 0x3, 0x2, 0x2, 0x2, 0x2f5, 0x2f7, 0x5, 0x3a, 0x1e, 0x2, 
    0x2f6, 0x2f5, 0x3, 0x2, 0x2, 0x2, 0x2f6, 0x2f7, 0x3, 0x2, 0x2, 0x2, 
    0x2f7, 0x71, 0x3, 0x2, 0x2, 0x2, 0x2f8, 0x2fa, 0x5, 0x30, 0x19, 0x2, 
    0x2f9, 0x2f8, 0x3, 0x2, 0x2, 0x2, 0x2fa, 0x2fd, 0x3, 0x2, 0x2, 0x2, 
    0x2fb, 0x2f9, 0x3, 0x2, 0x2, 0x2, 0x2fb, 0x2fc, 0x3, 0x2, 0x2, 0x2, 
    0x2fc, 0x73, 0x3, 0x2, 0x2, 0x2, 0x2fd, 0x2fb, 0x3, 0x2, 0x2, 0x2, 0x2fe, 
    0x300, 0x5, 0xe, 0x8, 0x2, 0x2ff, 0x2fe, 0x3, 0x2, 0x2, 0x2, 0x2ff, 
    0x300, 0x3, 0x2, 0x2, 0x2, 0x300, 0x75, 0x3, 0x2, 0x2, 0x2, 0x301, 0x303, 
    0x5, 0x120, 0x91, 0x2, 0x302, 0x301, 0x3, 0x2, 0x2, 0x2, 0x302, 0x303, 
    0x3, 0x2, 0x2, 0x2, 0x303, 0x77, 0x3, 0x2, 0x2, 0x2, 0x304, 0x305, 0x7, 
    0x61, 0x2, 0x2, 0x305, 0x306, 0x5, 0x38, 0x1d, 0x2, 0x306, 0x79, 0x3, 
    0x2, 0x2, 0x2, 0x307, 0x309, 0x5, 0x78, 0x3d, 0x2, 0x308, 0x307, 0x3, 
    0x2, 0x2, 0x2, 0x309, 0x30c, 0x3, 0x2, 0x2, 0x2, 0x30a, 0x308, 0x3, 
    0x2, 0x2, 0x2, 0x30a, 0x30b, 0x3, 0x2, 0x2, 0x2, 0x30b, 0x7b, 0x3, 0x2, 
    0x2, 0x2, 0x30c, 0x30a, 0x3, 0x2, 0x2, 0x2, 0x30d, 0x30e, 0x5, 0x38, 
    0x1d, 0x2, 0x30e, 0x30f, 0x5, 0x7a, 0x3e, 0x2, 0x30f, 0x7d, 0x3, 0x2, 
    0x2, 0x2, 0x310, 0x311, 0x7, 0x44, 0x2, 0x2, 0x311, 0x312, 0x5, 0x5e, 
    0x30, 0x2, 0x312, 0x313, 0x7, 0x45, 0x2, 0x2, 0x313, 0x7f, 0x3, 0x2, 
    0x2, 0x2, 0x314, 0x316, 0x5, 0x7e, 0x40, 0x2, 0x315, 0x314, 0x3, 0x2, 
    0x2, 0x2, 0x315, 0x316, 0x3, 0x2, 0x2, 0x2, 0x316, 0x81, 0x3, 0x2, 0x2, 
    0x2, 0x317, 0x318, 0xa, 0x7, 0x2, 0x2, 0x318, 0x319, 0x5, 0x80, 0x41, 
    0x2, 0x319, 0x83, 0x3, 0x2, 0x2, 0x2, 0x31a, 0x31c, 0x5, 0x11a, 0x8e, 
    0x2, 0x31b, 0x31a, 0x3, 0x2, 0x2, 0x2, 0x31b, 0x31c, 0x3, 0x2, 0x2, 
    0x2, 0x31c, 0x85, 0x3, 0x2, 0x2, 0x2, 0x31d, 0x31f, 0x5, 0x42, 0x22, 
    0x2, 0x31e, 0x31d, 0x3, 0x2, 0x2, 0x2, 0x31e, 0x31f, 0x3, 0x2, 0x2, 
    0x2, 0x31f, 0x87, 0x3, 0x2, 0x2, 0x2, 0x320, 0x322, 0x5, 0x3c, 0x1f, 
    0x2, 0x321, 0x320, 0x3, 0x2, 0x2, 0x2, 0x321, 0x322, 0x3, 0x2, 0x2, 
    0x2, 0x322, 0x89, 0x3, 0x2, 0x2, 0x2, 0x323, 0x325, 0x5, 0x48, 0x25, 
    0x2, 0x324, 0x323, 0x3, 0x2, 0x2, 0x2, 0x324, 0x325, 0x3, 0x2, 0x2, 
    0x2, 0x325, 0x8b, 0x3, 0x2, 0x2, 0x2, 0x326, 0x327, 0x9, 0x8, 0x2, 0x2, 
    0x327, 0x8d, 0x3, 0x2, 0x2, 0x2, 0x328, 0x32a, 0x5, 0x8c, 0x47, 0x2, 
    0x329, 0x328, 0x3, 0x2, 0x2, 0x2, 0x329, 0x32a, 0x3, 0x2, 0x2, 0x2, 
    0x32a, 0x8f, 0x3, 0x2, 0x2, 0x2, 0x32b, 0x32c, 0x7, 0x61, 0x2, 0x2, 
    0x32c, 0x32d, 0x5, 0xfa, 0x7e, 0x2, 0x32d, 0x91, 0x3, 0x2, 0x2, 0x2, 
    0x32e, 0x330, 0x5, 0x90, 0x49, 0x2, 0x32f, 0x32e, 0x3, 0x2, 0x2, 0x2, 
    0x330, 0x333, 0x3, 0x2, 0x2, 0x2, 0x331, 0x32f, 0x3, 0x2, 0x2, 0x2, 
    0x331, 0x332, 0x3, 0x2, 0x2, 0x2, 0x332, 0x93, 0x3, 0x2, 0x2, 0x2, 0x333, 
    0x331, 0x3, 0x2, 0x2, 0x2, 0x334, 0x335, 0x5, 0xfa, 0x7e, 0x2, 0x335, 
    0x336, 0x5, 0x92, 0x4a, 0x2, 0x336, 0x95, 0x3, 0x2, 0x2, 0x2, 0x337, 
    0x339, 0x5, 0x94, 0x4b, 0x2, 0x338, 0x337, 0x3, 0x2, 0x2, 0x2, 0x338, 
    0x339, 0x3, 0x2, 0x2, 0x2, 0x339, 0x97, 0x3, 0x2, 0x2, 0x2, 0x33a, 0x33b, 
    0x7, 0x5f, 0x2, 0x2, 0x33b, 0x33c, 0x5, 0x96, 0x4c, 0x2, 0x33c, 0x99, 
    0x3, 0x2, 0x2, 0x2, 0x33d, 0x33f, 0x5, 0x98, 0x4d, 0x2, 0x33e, 0x33d, 
    0x3, 0x2, 0x2, 0x2, 0x33f, 0x342, 0x3, 0x2, 0x2, 0x2, 0x340, 0x33e, 
    0x3, 0x2, 0x2, 0x2, 0x340, 0x341, 0x3, 0x2, 0x2, 0x2, 0x341, 0x9b, 0x3, 
    0x2, 0x2, 0x2, 0x342, 0x340, 0x3, 0x2, 0x2, 0x2, 0x343, 0x345, 0x5, 
    0x132, 0x9a, 0x2, 0x344, 0x343, 0x3, 0x2, 0x2, 0x2, 0x344, 0x345, 0x3, 
    0x2, 0x2, 0x2, 0x345, 0x9d, 0x3, 0x2, 0x2, 0x2, 0x346, 0x347, 0x7, 0x1d, 
    0x2, 0x2, 0x347, 0x348, 0x5, 0x190, 0xc9, 0x2, 0x348, 0x9f, 0x3, 0x2, 
    0x2, 0x2, 0x349, 0x34b, 0x5, 0x9e, 0x50, 0x2, 0x34a, 0x349, 0x3, 0x2, 
    0x2, 0x2, 0x34a, 0x34b, 0x3, 0x2, 0x2, 0x2, 0x34b, 0xa1, 0x3, 0x2, 0x2, 
    0x2, 0x34c, 0x34e, 0x5, 0x134, 0x9b, 0x2, 0x34d, 0x34c, 0x3, 0x2, 0x2, 
    0x2, 0x34d, 0x34e, 0x3, 0x2, 0x2, 0x2, 0x34e, 0xa3, 0x3, 0x2, 0x2, 0x2, 
    0x34f, 0x351, 0x5, 0x16, 0xc, 0x2, 0x350, 0x34f, 0x3, 0x2, 0x2, 0x2, 
    0x350, 0x351, 0x3, 0x2, 0x2, 0x2, 0x351, 0xa5, 0x3, 0x2, 0x2, 0x2, 0x352, 
    0x354, 0x5, 0x138, 0x9d, 0x2, 0x353, 0x352, 0x3, 0x2, 0x2, 0x2, 0x353, 
    0x354, 0x3, 0x2, 0x2, 0x2, 0x354, 0xa7, 0x3, 0x2, 0x2, 0x2, 0x355, 0x356, 
    0x7, 0x61, 0x2, 0x2, 0x356, 0x357, 0x5, 0xe, 0x8, 0x2, 0x357, 0xa9, 
    0x3, 0x2, 0x2, 0x2, 0x358, 0x35a, 0x5, 0xa8, 0x55, 0x2, 0x359, 0x358, 
    0x3, 0x2, 0x2, 0x2, 0x35a, 0x35d, 0x3, 0x2, 0x2, 0x2, 0x35b, 0x359, 
    0x3, 0x2, 0x2, 0x2, 0x35b, 0x35c, 0x3, 0x2, 0x2, 0x2, 0x35c, 0xab, 0x3, 
    0x2, 0x2, 0x2, 0x35d, 0x35b, 0x3, 0x2, 0x2, 0x2, 0x35e, 0x35f, 0x5, 
    0xe, 0x8, 0x2, 0x35f, 0x360, 0x5, 0xaa, 0x56, 0x2, 0x360, 0xad, 0x3, 
    0x2, 0x2, 0x2, 0x361, 0x362, 0x7, 0x61, 0x2, 0x2, 0x362, 0x363, 0x5, 
    0x4, 0x3, 0x2, 0x363, 0xaf, 0x3, 0x2, 0x2, 0x2, 0x364, 0x366, 0x5, 0xae, 
    0x58, 0x2, 0x365, 0x364, 0x3, 0x2, 0x2, 0x2, 0x366, 0x369, 0x3, 0x2, 
    0x2, 0x2, 0x367, 0x365, 0x3, 0x2, 0x2, 0x2, 0x367, 0x368, 0x3, 0x2, 
    0x2, 0x2, 0x368, 0xb1, 0x3, 0x2, 0x2, 0x2, 0x369, 0x367, 0x3, 0x2, 0x2, 
    0x2, 0x36a, 0x36b, 0x5, 0x4, 0x3, 0x2, 0x36b, 0x36c, 0x5, 0xb0, 0x59, 
    0x2, 0x36c, 0xb3, 0x3, 0x2, 0x2, 0x2, 0x36d, 0x373, 0x5, 0x1c4, 0xe3, 
    0x2, 0x36e, 0x373, 0x5, 0x1c6, 0xe4, 0x2, 0x36f, 0x373, 0x7, 0x51, 0x2, 
    0x2, 0x370, 0x373, 0x7, 0x53, 0x2, 0x2, 0x371, 0x373, 0x5, 0x1c8, 0xe5, 
    0x2, 0x372, 0x36d, 0x3, 0x2, 0x2, 0x2, 0x372, 0x36e, 0x3, 0x2, 0x2, 
    0x2, 0x372, 0x36f, 0x3, 0x2, 0x2, 0x2, 0x372, 0x370, 0x3, 0x2, 0x2, 
    0x2, 0x372, 0x371, 0x3, 0x2, 0x2, 0x2, 0x373, 0xb5, 0x3, 0x2, 0x2, 0x2, 
    0x374, 0x376, 0x5, 0xb4, 0x5b, 0x2, 0x375, 0x374, 0x3, 0x2, 0x2, 0x2, 
    0x376, 0x379, 0x3, 0x2, 0x2, 0x2, 0x377, 0x375, 0x3, 0x2, 0x2, 0x2, 
    0x377, 0x378, 0x3, 0x2, 0x2, 0x2, 0x378, 0xb7, 0x3, 0x2, 0x2, 0x2, 0x379, 
    0x377, 0x3, 0x2, 0x2, 0x2, 0x37a, 0x37b, 0x5, 0x188, 0xc5, 0x2, 0x37b, 
    0x37c, 0x5, 0xb6, 0x5c, 0x2, 0x37c, 0xb9, 0x3, 0x2, 0x2, 0x2, 0x37d, 
    0x37e, 0x7, 0x61, 0x2, 0x2, 0x37e, 0x37f, 0x5, 0x8a, 0x46, 0x2, 0x37f, 
    0x380, 0x5, 0x46, 0x24, 0x2, 0x380, 0xbb, 0x3, 0x2, 0x2, 0x2, 0x381, 
    0x383, 0x5, 0xba, 0x5e, 0x2, 0x382, 0x381, 0x3, 0x2, 0x2, 0x2, 0x383, 
    0x386, 0x3, 0x2, 0x2, 0x2, 0x384, 0x382, 0x3, 0x2, 0x2, 0x2, 0x384, 
    0x385, 0x3, 0x2, 0x2, 0x2, 0x385, 0xbd, 0x3, 0x2, 0x2, 0x2, 0x386, 0x384, 
    0x3, 0x2, 0x2, 0x2, 0x387, 0x388, 0x5, 0x8a, 0x46, 0x2, 0x388, 0x389, 
    0x5, 0x46, 0x24, 0x2, 0x389, 0x38a, 0x5, 0xbc, 0x5f, 0x2, 0x38a, 0xbf, 
    0x3, 0x2, 0x2, 0x2, 0x38b, 0x38c, 0x5, 0x160, 0xb1, 0x2, 0x38c, 0x38d, 
    0x5, 0xa, 0x6, 0x2, 0x38d, 0xc1, 0x3, 0x2, 0x2, 0x2, 0x38e, 0x390, 0x5, 
    0xc0, 0x61, 0x2, 0x38f, 0x38e, 0x3, 0x2, 0x2, 0x2, 0x390, 0x393, 0x3, 
    0x2, 0x2, 0x2, 0x391, 0x38f, 0x3, 0x2, 0x2, 0x2, 0x391, 0x392, 0x3, 
    0x2, 0x2, 0x2, 0x392, 0xc3, 0x3, 0x2, 0x2, 0x2, 0x393, 0x391, 0x3, 0x2, 
    0x2, 0x2, 0x394, 0x395, 0x5, 0xa, 0x6, 0x2, 0x395, 0x396, 0x5, 0xc2, 
    0x62, 0x2, 0x396, 0xc5, 0x3, 0x2, 0x2, 0x2, 0x397, 0x398, 0x5, 0x162, 
    0xb2, 0x2, 0x398, 0x399, 0x5, 0xc4, 0x63, 0x2, 0x399, 0xc7, 0x3, 0x2, 
    0x2, 0x2, 0x39a, 0x39c, 0x5, 0xc6, 0x64, 0x2, 0x39b, 0x39a, 0x3, 0x2, 
    0x2, 0x2, 0x39c, 0x39f, 0x3, 0x2, 0x2, 0x2, 0x39d, 0x39b, 0x3, 0x2, 
    0x2, 0x2, 0x39d, 0x39e, 0x3, 0x2, 0x2, 0x2, 0x39e, 0xc9, 0x3, 0x2, 0x2, 
    0x2, 0x39f, 0x39d, 0x3, 0x2, 0x2, 0x2, 0x3a0, 0x3a1, 0x5, 0xc4, 0x63, 
    0x2, 0x3a1, 0x3a2, 0x5, 0xc8, 0x65, 0x2, 0x3a2, 0xcb, 0x3, 0x2, 0x2, 
    0x2, 0x3a3, 0x3a4, 0x5, 0x164, 0xb3, 0x2, 0x3a4, 0x3a5, 0x5, 0xca, 0x66, 
    0x2, 0x3a5, 0xcd, 0x3, 0x2, 0x2, 0x2, 0x3a6, 0x3a8, 0x5, 0xcc, 0x67, 
    0x2, 0x3a7, 0x3a6, 0x3, 0x2, 0x2, 0x2, 0x3a8, 0x3ab, 0x3, 0x2, 0x2, 
    0x2, 0x3a9, 0x3a7, 0x3, 0x2, 0x2, 0x2, 0x3a9, 0x3aa, 0x3, 0x2, 0x2, 
    0x2, 0x3aa, 0xcf, 0x3, 0x2, 0x2, 0x2, 0x3ab, 0x3a9, 0x3, 0x2, 0x2, 0x2, 
    0x3ac, 0x3ad, 0x5, 0xca, 0x66, 0x2, 0x3ad, 0x3ae, 0x5, 0xce, 0x68, 0x2, 
    0x3ae, 0xd1, 0x3, 0x2, 0x2, 0x2, 0x3af, 0x3b0, 0x5, 0x166, 0xb4, 0x2, 
    0x3b0, 0x3b1, 0x5, 0xd0, 0x69, 0x2, 0x3b1, 0xd3, 0x3, 0x2, 0x2, 0x2, 
    0x3b2, 0x3b4, 0x5, 0xd2, 0x6a, 0x2, 0x3b3, 0x3b2, 0x3, 0x2, 0x2, 0x2, 
    0x3b4, 0x3b7, 0x3, 0x2, 0x2, 0x2, 0x3b5, 0x3b3, 0x3, 0x2, 0x2, 0x2, 
    0x3b5, 0x3b6, 0x3, 0x2, 0x2, 0x2, 0x3b6, 0xd5, 0x3, 0x2, 0x2, 0x2, 0x3b7, 
    0x3b5, 0x3, 0x2, 0x2, 0x2, 0x3b8, 0x3b9, 0x5, 0xd0, 0x69, 0x2, 0x3b9, 
    0x3ba, 0x5, 0xd4, 0x6b, 0x2, 0x3ba, 0xd7, 0x3, 0x2, 0x2, 0x2, 0x3bb, 
    0x3bc, 0x5, 0x168, 0xb5, 0x2, 0x3bc, 0x3bd, 0x5, 0xd6, 0x6c, 0x2, 0x3bd, 
    0xd9, 0x3, 0x2, 0x2, 0x2, 0x3be, 0x3c0, 0x5, 0xd8, 0x6d, 0x2, 0x3bf, 
    0x3be, 0x3, 0x2, 0x2, 0x2, 0x3c0, 0x3c3, 0x3, 0x2, 0x2, 0x2, 0x3c1, 
    0x3bf, 0x3, 0x2, 0x2, 0x2, 0x3c1, 0x3c2, 0x3, 0x2, 0x2, 0x2, 0x3c2, 
    0xdb, 0x3, 0x2, 0x2, 0x2, 0x3c3, 0x3c1, 0x3, 0x2, 0x2, 0x2, 0x3c4, 0x3c5, 
    0x5, 0xd6, 0x6c, 0x2, 0x3c5, 0x3c6, 0x5, 0xda, 0x6e, 0x2, 0x3c6, 0xdd, 
    0x3, 0x2, 0x2, 0x2, 0x3c7, 0x3c8, 0x7, 0x57, 0x2, 0x2, 0x3c8, 0x3c9, 
    0x5, 0xdc, 0x6f, 0x2, 0x3c9, 0xdf, 0x3, 0x2, 0x2, 0x2, 0x3ca, 0x3cc, 
    0x5, 0xde, 0x70, 0x2, 0x3cb, 0x3ca, 0x3, 0x2, 0x2, 0x2, 0x3cc, 0x3cf, 
    0x3, 0x2, 0x2, 0x2, 0x3cd, 0x3cb, 0x3, 0x2, 0x2, 0x2, 0x3cd, 0x3ce, 
    0x3, 0x2, 0x2, 0x2, 0x3ce, 0xe1, 0x3, 0x2, 0x2, 0x2, 0x3cf, 0x3cd, 0x3, 
    0x2, 0x2, 0x2, 0x3d0, 0x3d1, 0x5, 0xdc, 0x6f, 0x2, 0x3d1, 0x3d2, 0x5, 
    0xe0, 0x71, 0x2, 0x3d2, 0xe3, 0x3, 0x2, 0x2, 0x2, 0x3d3, 0x3d4, 0x7, 
    0x5b, 0x2, 0x2, 0x3d4, 0x3d5, 0x5, 0xe2, 0x72, 0x2, 0x3d5, 0xe5, 0x3, 
    0x2, 0x2, 0x2, 0x3d6, 0x3d8, 0x5, 0xe4, 0x73, 0x2, 0x3d7, 0x3d6, 0x3, 
    0x2, 0x2, 0x2, 0x3d8, 0x3db, 0x3, 0x2, 0x2, 0x2, 0x3d9, 0x3d7, 0x3, 
    0x2, 0x2, 0x2, 0x3d9, 0x3da, 0x3, 0x2, 0x2, 0x2, 0x3da, 0xe7, 0x3, 0x2, 
    0x2, 0x2, 0x3db, 0x3d9, 0x3, 0x2, 0x2, 0x2, 0x3dc, 0x3dd, 0x5, 0xe2, 
    0x72, 0x2, 0x3dd, 0x3de, 0x5, 0xe6, 0x74, 0x2, 0x3de, 0xe9, 0x3, 0x2, 
    0x2, 0x2, 0x3df, 0x3e0, 0x7, 0x58, 0x2, 0x2, 0x3e0, 0x3e1, 0x5, 0xe8, 
    0x75, 0x2, 0x3e1, 0xeb, 0x3, 0x2, 0x2, 0x2, 0x3e2, 0x3e4, 0x5, 0xea, 
    0x76, 0x2, 0x3e3, 0x3e2, 0x3, 0x2, 0x2, 0x2, 0x3e4, 0x3e7, 0x3, 0x2, 
    0x2, 0x2, 0x3e5, 0x3e3, 0x3, 0x2, 0x2, 0x2, 0x3e5, 0x3e6, 0x3, 0x2, 
    0x2, 0x2, 0x3e6, 0xed, 0x3, 0x2, 0x2, 0x2, 0x3e7, 0x3e5, 0x3, 0x2, 0x2, 
    0x2, 0x3e8, 0x3e9, 0x5, 0xe8, 0x75, 0x2, 0x3e9, 0x3ea, 0x5, 0xec, 0x77, 
    0x2, 0x3ea, 0xef, 0x3, 0x2, 0x2, 0x2, 0x3eb, 0x3ec, 0x7, 0x59, 0x2, 
    0x2, 0x3ec, 0x3ed, 0x5, 0xee, 0x78, 0x2, 0x3ed, 0xf1, 0x3, 0x2, 0x2, 
    0x2, 0x3ee, 0x3f0, 0x5, 0xf0, 0x79, 0x2, 0x3ef, 0x3ee, 0x3, 0x2, 0x2, 
    0x2, 0x3f0, 0x3f3, 0x3, 0x2, 0x2, 0x2, 0x3f1, 0x3ef, 0x3, 0x2, 0x2, 
    0x2, 0x3f1, 0x3f2, 0x3, 0x2, 0x2, 0x2, 0x3f2, 0xf3, 0x3, 0x2, 0x2, 0x2, 
    0x3f3, 0x3f1, 0x3, 0x2, 0x2, 0x2, 0x3f4, 0x3f5, 0x5, 0xee, 0x78, 0x2, 
    0x3f5, 0x3f6, 0x5, 0xf2, 0x7a, 0x2, 0x3f6, 0xf5, 0x3, 0x2, 0x2, 0x2, 
    0x3f7, 0x3f8, 0x7, 0x5a, 0x2, 0x2, 0x3f8, 0x3f9, 0x5, 0xf4, 0x7b, 0x2, 
    0x3f9, 0xf7, 0x3, 0x2, 0x2, 0x2, 0x3fa, 0x3fc, 0x5, 0xf6, 0x7c, 0x2, 
    0x3fb, 0x3fa, 0x3, 0x2, 0x2, 0x2, 0x3fc, 0x3ff, 0x3, 0x2, 0x2, 0x2, 
    0x3fd, 0x3fb, 0x3, 0x2, 0x2, 0x2, 0x3fd, 0x3fe, 0x3, 0x2, 0x2, 0x2, 
    0x3fe, 0xf9, 0x3, 0x2, 0x2, 0x2, 0x3ff, 0x3fd, 0x3, 0x2, 0x2, 0x2, 0x400, 
    0x401, 0x5, 0xf4, 0x7b, 0x2, 0x401, 0x402, 0x5, 0xf8, 0x7d, 0x2, 0x402, 
    0xfb, 0x3, 0x2, 0x2, 0x2, 0x403, 0x404, 0x7, 0x61, 0x2, 0x2, 0x404, 
    0x405, 0x5, 0x18, 0xd, 0x2, 0x405, 0xfd, 0x3, 0x2, 0x2, 0x2, 0x406, 
    0x408, 0x5, 0xfc, 0x7f, 0x2, 0x407, 0x406, 0x3, 0x2, 0x2, 0x2, 0x408, 
    0x40b, 0x3, 0x2, 0x2, 0x2, 0x409, 0x407, 0x3, 0x2, 0x2, 0x2, 0x409, 
    0x40a, 0x3, 0x2, 0x2, 0x2, 0x40a, 0xff, 0x3, 0x2, 0x2, 0x2, 0x40b, 0x409, 
    0x3, 0x2, 0x2, 0x2, 0x40c, 0x40d, 0x5, 0x18, 0xd, 0x2, 0x40d, 0x40e, 
    0x5, 0xfe, 0x80, 0x2, 0x40e, 0x101, 0x3, 0x2, 0x2, 0x2, 0x40f, 0x410, 
    0x5, 0x13a, 0x9e, 0x2, 0x410, 0x103, 0x3, 0x2, 0x2, 0x2, 0x411, 0x412, 
    0x7, 0x61, 0x2, 0x2, 0x412, 0x413, 0x5, 0x22, 0x12, 0x2, 0x413, 0x105, 
    0x3, 0x2, 0x2, 0x2, 0x414, 0x416, 0x5, 0x104, 0x83, 0x2, 0x415, 0x414, 
    0x3, 0x2, 0x2, 0x2, 0x416, 0x419, 0x3, 0x2, 0x2, 0x2, 0x417, 0x415, 
    0x3, 0x2, 0x2, 0x2, 0x417, 0x418, 0x3, 0x2, 0x2, 0x2, 0x418, 0x107, 
    0x3, 0x2, 0x2, 0x2, 0x419, 0x417, 0x3, 0x2, 0x2, 0x2, 0x41a, 0x41b, 
    0x5, 0x22, 0x12, 0x2, 0x41b, 0x41c, 0x5, 0x106, 0x84, 0x2, 0x41c, 0x109, 
    0x3, 0x2, 0x2, 0x2, 0x41d, 0x41e, 0x7, 0x61, 0x2, 0x2, 0x41e, 0x41f, 
    0x5, 0x26, 0x14, 0x2, 0x41f, 0x10b, 0x3, 0x2, 0x2, 0x2, 0x420, 0x422, 
    0x5, 0x10a, 0x86, 0x2, 0x421, 0x420, 0x3, 0x2, 0x2, 0x2, 0x422, 0x425, 
    0x3, 0x2, 0x2, 0x2, 0x423, 0x421, 0x3, 0x2, 0x2, 0x2, 0x423, 0x424, 
    0x3, 0x2, 0x2, 0x2, 0x424, 0x10d, 0x3, 0x2, 0x2, 0x2, 0x425, 0x423, 
    0x3, 0x2, 0x2, 0x2, 0x426, 0x427, 0x5, 0x26, 0x14, 0x2, 0x427, 0x428, 
    0x5, 0x10c, 0x87, 0x2, 0x428, 0x10f, 0x3, 0x2, 0x2, 0x2, 0x429, 0x42c, 
    0x5, 0x1ca, 0xe6, 0x2, 0x42a, 0x42c, 0x5, 0x1cc, 0xe7, 0x2, 0x42b, 0x429, 
    0x3, 0x2, 0x2, 0x2, 0x42b, 0x42a, 0x3, 0x2, 0x2, 0x2, 0x42c, 0x111, 
    0x3, 0x2, 0x2, 0x2, 0x42d, 0x42f, 0x5, 0x110, 0x89, 0x2, 0x42e, 0x42d, 
    0x3, 0x2, 0x2, 0x2, 0x42f, 0x432, 0x3, 0x2, 0x2, 0x2, 0x430, 0x42e, 
    0x3, 0x2, 0x2, 0x2, 0x430, 0x431, 0x3, 0x2, 0x2, 0x2, 0x431, 0x113, 
    0x3, 0x2, 0x2, 0x2, 0x432, 0x430, 0x3, 0x2, 0x2, 0x2, 0x433, 0x436, 
    0x7, 0x72, 0x2, 0x2, 0x434, 0x436, 0x5, 0x1ce, 0xe8, 0x2, 0x435, 0x433, 
    0x3, 0x2, 0x2, 0x2, 0x435, 0x434, 0x3, 0x2, 0x2, 0x2, 0x436, 0x115, 
    0x3, 0x2, 0x2, 0x2, 0x437, 0x438, 0x5, 0x114, 0x8b, 0x2, 0x438, 0x439, 
    0x5, 0x112, 0x8a, 0x2, 0x439, 0x117, 0x3, 0x2, 0x2, 0x2, 0x43a, 0x43b, 
    0x5, 0x2a, 0x16, 0x2, 0x43b, 0x119, 0x3, 0x2, 0x2, 0x2, 0x43c, 0x43d, 
    0x5, 0x13c, 0x9f, 0x2, 0x43d, 0x11b, 0x3, 0x2, 0x2, 0x2, 0x43e, 0x43f, 
    0x7, 0x61, 0x2, 0x2, 0x43f, 0x440, 0x7, 0x72, 0x2, 0x2, 0x440, 0x11d, 
    0x3, 0x2, 0x2, 0x2, 0x441, 0x443, 0x5, 0x11c, 0x8f, 0x2, 0x442, 0x441, 
    0x3, 0x2, 0x2, 0x2, 0x443, 0x446, 0x3, 0x2, 0x2, 0x2, 0x444, 0x442, 
    0x3, 0x2, 0x2, 0x2, 0x444, 0x445, 0x3, 0x2, 0x2, 0x2, 0x445, 0x11f, 
    0x3, 0x2, 0x2, 0x2, 0x446, 0x444, 0x3, 0x2, 0x2, 0x2, 0x447, 0x448, 
    0x7, 0x72, 0x2, 0x2, 0x448, 0x449, 0x5, 0x11e, 0x90, 0x2, 0x449, 0x121, 
    0x3, 0x2, 0x2, 0x2, 0x44a, 0x44b, 0x7, 0x61, 0x2, 0x2, 0x44b, 0x44c, 
    0x5, 0x3e, 0x20, 0x2, 0x44c, 0x123, 0x3, 0x2, 0x2, 0x2, 0x44d, 0x44f, 
    0x5, 0x122, 0x92, 0x2, 0x44e, 0x44d, 0x3, 0x2, 0x2, 0x2, 0x44f, 0x452, 
    0x3, 0x2, 0x2, 0x2, 0x450, 0x44e, 0x3, 0x2, 0x2, 0x2, 0x450, 0x451, 
    0x3, 0x2, 0x2, 0x2, 0x451, 0x125, 0x3, 0x2, 0x2, 0x2, 0x452, 0x450, 
    0x3, 0x2, 0x2, 0x2, 0x453, 0x454, 0x5, 0x3e, 0x20, 0x2, 0x454, 0x455, 
    0x5, 0x124, 0x93, 0x2, 0x455, 0x127, 0x3, 0x2, 0x2, 0x2, 0x456, 0x459, 
    0x5, 0x1d0, 0xe9, 0x2, 0x457, 0x459, 0x5, 0x1d2, 0xea, 0x2, 0x458, 0x456, 
    0x3, 0x2, 0x2, 0x2, 0x458, 0x457, 0x3, 0x2, 0x2, 0x2, 0x459, 0x129, 
    0x3, 0x2, 0x2, 0x2, 0x45a, 0x45c, 0x5, 0x128, 0x95, 0x2, 0x45b, 0x45a, 
    0x3, 0x2, 0x2, 0x2, 0x45c, 0x45f, 0x3, 0x2, 0x2, 0x2, 0x45d, 0x45b, 
    0x3, 0x2, 0x2, 0x2, 0x45d, 0x45e, 0x3, 0x2, 0x2, 0x2, 0x45e, 0x12b, 
    0x3, 0x2, 0x2, 0x2, 0x45f, 0x45d, 0x3, 0x2, 0x2, 0x2, 0x460, 0x463, 
    0x5, 0x1d4, 0xeb, 0x2, 0x461, 0x463, 0x5, 0x1d6, 0xec, 0x2, 0x462, 0x460, 
    0x3, 0x2, 0x2, 0x2, 0x462, 0x461, 0x3, 0x2, 0x2, 0x2, 0x463, 0x12d, 
    0x3, 0x2, 0x2, 0x2, 0x464, 0x465, 0x5, 0x12c, 0x97, 0x2, 0x465, 0x466, 
    0x5, 0x12a, 0x96, 0x2, 0x466, 0x12f, 0x3, 0x2, 0x2, 0x2, 0x467, 0x468, 
    0x5, 0x13e, 0xa0, 0x2, 0x468, 0x131, 0x3, 0x2, 0x2, 0x2, 0x469, 0x46a, 
    0x5, 0x140, 0xa1, 0x2, 0x46a, 0x133, 0x3, 0x2, 0x2, 0x2, 0x46b, 0x46c, 
    0x5, 0x142, 0xa2, 0x2, 0x46c, 0x135, 0x3, 0x2, 0x2, 0x2, 0x46d, 0x46e, 
    0x5, 0x14, 0xb, 0x2, 0x46e, 0x137, 0x3, 0x2, 0x2, 0x2, 0x46f, 0x470, 
    0x5, 0x144, 0xa3, 0x2, 0x470, 0x139, 0x3, 0x2, 0x2, 0x2, 0x471, 0x473, 
    0x5, 0x18c, 0xc7, 0x2, 0x472, 0x471, 0x3, 0x2, 0x2, 0x2, 0x473, 0x474, 
    0x3, 0x2, 0x2, 0x2, 0x474, 0x472, 0x3, 0x2, 0x2, 0x2, 0x474, 0x475, 
    0x3, 0x2, 0x2, 0x2, 0x475, 0x13b, 0x3, 0x2, 0x2, 0x2, 0x476, 0x478, 
    0x5, 0x118, 0x8d, 0x2, 0x477, 0x476, 0x3, 0x2, 0x2, 0x2, 0x478, 0x479, 
    0x3, 0x2, 0x2, 0x2, 0x479, 0x477, 0x3, 0x2, 0x2, 0x2, 0x479, 0x47a, 
    0x3, 0x2, 0x2, 0x2, 0x47a, 0x13d, 0x3, 0x2, 0x2, 0x2, 0x47b, 0x47d, 
    0x5, 0x18e, 0xc8, 0x2, 0x47c, 0x47b, 0x3, 0x2, 0x2, 0x2, 0x47d, 0x47e, 
    0x3, 0x2, 0x2, 0x2, 0x47e, 0x47c, 0x3, 0x2, 0x2, 0x2, 0x47e, 0x47f, 
    0x3, 0x2, 0x2, 0x2, 0x47f, 0x13f, 0x3, 0x2, 0x2, 0x2, 0x480, 0x482, 
    0x5, 0x192, 0xca, 0x2, 0x481, 0x480, 0x3, 0x2, 0x2, 0x2, 0x482, 0x483, 
    0x3, 0x2, 0x2, 0x2, 0x483, 0x481, 0x3, 0x2, 0x2, 0x2, 0x483, 0x484, 
    0x3, 0x2, 0x2, 0x2, 0x484, 0x141, 0x3, 0x2, 0x2, 0x2, 0x485, 0x487, 
    0x5, 0x194, 0xcb, 0x2, 0x486, 0x485, 0x3, 0x2, 0x2, 0x2, 0x487, 0x488, 
    0x3, 0x2, 0x2, 0x2, 0x488, 0x486, 0x3, 0x2, 0x2, 0x2, 0x488, 0x489, 
    0x3, 0x2, 0x2, 0x2, 0x489, 0x143, 0x3, 0x2, 0x2, 0x2, 0x48a, 0x48c, 
    0x5, 0x136, 0x9c, 0x2, 0x48b, 0x48a, 0x3, 0x2, 0x2, 0x2, 0x48c, 0x48d, 
    0x3, 0x2, 0x2, 0x2, 0x48d, 0x48b, 0x3, 0x2, 0x2, 0x2, 0x48d, 0x48e, 
    0x3, 0x2, 0x2, 0x2, 0x48e, 0x145, 0x3, 0x2, 0x2, 0x2, 0x48f, 0x491, 
    0x7, 0x61, 0x2, 0x2, 0x490, 0x48f, 0x3, 0x2, 0x2, 0x2, 0x490, 0x491, 
    0x3, 0x2, 0x2, 0x2, 0x491, 0x147, 0x3, 0x2, 0x2, 0x2, 0x492, 0x493, 
    0x7, 0x62, 0x2, 0x2, 0x493, 0x494, 0x5, 0x46, 0x24, 0x2, 0x494, 0x149, 
    0x3, 0x2, 0x2, 0x2, 0x495, 0x497, 0x5, 0x148, 0xa5, 0x2, 0x496, 0x495, 
    0x3, 0x2, 0x2, 0x2, 0x496, 0x497, 0x3, 0x2, 0x2, 0x2, 0x497, 0x14b, 
    0x3, 0x2, 0x2, 0x2, 0x498, 0x499, 0x7, 0x62, 0x2, 0x2, 0x499, 0x49a, 
    0x5, 0x12, 0xa, 0x2, 0x49a, 0x14d, 0x3, 0x2, 0x2, 0x2, 0x49b, 0x49d, 
    0x5, 0x14c, 0xa7, 0x2, 0x49c, 0x49b, 0x3, 0x2, 0x2, 0x2, 0x49c, 0x49d, 
    0x3, 0x2, 0x2, 0x2, 0x49d, 0x14f, 0x3, 0x2, 0x2, 0x2, 0x49e, 0x49f, 
    0x7, 0x61, 0x2, 0x2, 0x49f, 0x4a0, 0x7, 0x71, 0x2, 0x2, 0x4a0, 0x151, 
    0x3, 0x2, 0x2, 0x2, 0x4a1, 0x4a3, 0x5, 0x150, 0xa9, 0x2, 0x4a2, 0x4a1, 
    0x3, 0x2, 0x2, 0x2, 0x4a2, 0x4a3, 0x3, 0x2, 0x2, 0x2, 0x4a3, 0x153, 
    0x3, 0x2, 0x2, 0x2, 0x4a4, 0x4a9, 0x5, 0x1d8, 0xed, 0x2, 0x4a5, 0x4a9, 
    0x5, 0x1da, 0xee, 0x2, 0x4a6, 0x4a9, 0x5, 0x1dc, 0xef, 0x2, 0x4a7, 0x4a9, 
    0x5, 0x1de, 0xf0, 0x2, 0x4a8, 0x4a4, 0x3, 0x2, 0x2, 0x2, 0x4a8, 0x4a5, 
    0x3, 0x2, 0x2, 0x2, 0x4a8, 0x4a6, 0x3, 0x2, 0x2, 0x2, 0x4a8, 0x4a7, 
    0x3, 0x2, 0x2, 0x2, 0x4a9, 0x155, 0x3, 0x2, 0x2, 0x2, 0x4aa, 0x4ab, 
    0x9, 0x9, 0x2, 0x2, 0x4ab, 0x157, 0x3, 0x2, 0x2, 0x2, 0x4ac, 0x4af, 
    0x5, 0x1e0, 0xf1, 0x2, 0x4ad, 0x4af, 0x5, 0x1e2, 0xf2, 0x2, 0x4ae, 0x4ac, 
    0x3, 0x2, 0x2, 0x2, 0x4ae, 0x4ad, 0x3, 0x2, 0x2, 0x2, 0x4af, 0x159, 
    0x3, 0x2, 0x2, 0x2, 0x4b0, 0x4b3, 0x5, 0x40, 0x21, 0x2, 0x4b1, 0x4b3, 
    0x7, 0x1a, 0x2, 0x2, 0x4b2, 0x4b0, 0x3, 0x2, 0x2, 0x2, 0x4b2, 0x4b1, 
    0x3, 0x2, 0x2, 0x2, 0x4b3, 0x15b, 0x3, 0x2, 0x2, 0x2, 0x4b4, 0x4b5, 
    0x9, 0xa, 0x2, 0x2, 0x4b5, 0x15d, 0x3, 0x2, 0x2, 0x2, 0x4b6, 0x4b7, 
    0x5, 0x5c, 0x2f, 0x2, 0x4b7, 0x4b8, 0x7, 0x44, 0x2, 0x2, 0x4b8, 0x4b9, 
    0x5, 0x40, 0x21, 0x2, 0x4b9, 0x4ba, 0x7, 0x45, 0x2, 0x2, 0x4ba, 0x4bb, 
    0x7, 0x48, 0x2, 0x2, 0x4bb, 0x4bc, 0x5, 0xbe, 0x60, 0x2, 0x4bc, 0x4bd, 
    0x5, 0x146, 0xa4, 0x2, 0x4bd, 0x15f, 0x3, 0x2, 0x2, 0x2, 0x4be, 0x4bf, 
    0x9, 0xb, 0x2, 0x2, 0x4bf, 0x161, 0x3, 0x2, 0x2, 0x2, 0x4c0, 0x4c1, 
    0x9, 0xc, 0x2, 0x2, 0x4c1, 0x163, 0x3, 0x2, 0x2, 0x2, 0x4c2, 0x4c3, 
    0x9, 0xd, 0x2, 0x2, 0x4c3, 0x165, 0x3, 0x2, 0x2, 0x2, 0x4c4, 0x4c5, 
    0x9, 0xe, 0x2, 0x2, 0x4c5, 0x167, 0x3, 0x2, 0x2, 0x2, 0x4c6, 0x4c7, 
    0x9, 0xf, 0x2, 0x2, 0x4c7, 0x169, 0x3, 0x2, 0x2, 0x2, 0x4c8, 0x4cb, 
    0x5, 0x1e4, 0xf3, 0x2, 0x4c9, 0x4cb, 0x5, 0x1e6, 0xf4, 0x2, 0x4ca, 0x4c8, 
    0x3, 0x2, 0x2, 0x2, 0x4ca, 0x4c9, 0x3, 0x2, 0x2, 0x2, 0x4cb, 0x16b, 
    0x3, 0x2, 0x2, 0x2, 0x4cc, 0x4cf, 0x5, 0x40, 0x21, 0x2, 0x4cd, 0x4cf, 
    0x5, 0x12, 0xa, 0x2, 0x4ce, 0x4cc, 0x3, 0x2, 0x2, 0x2, 0x4ce, 0x4cd, 
    0x3, 0x2, 0x2, 0x2, 0x4cf, 0x16d, 0x3, 0x2, 0x2, 0x2, 0x4d0, 0x4d3, 
    0x5, 0x1e8, 0xf5, 0x2, 0x4d1, 0x4d3, 0x7, 0x72, 0x2, 0x2, 0x4d2, 0x4d0, 
    0x3, 0x2, 0x2, 0x2, 0x4d2, 0x4d1, 0x3, 0x2, 0x2, 0x2, 0x4d3, 0x16f, 
    0x3, 0x2, 0x2, 0x2, 0x4d4, 0x4d7, 0x7, 0x72, 0x2, 0x2, 0x4d5, 0x4d7, 
    0x5, 0x1ea, 0xf6, 0x2, 0x4d6, 0x4d4, 0x3, 0x2, 0x2, 0x2, 0x4d6, 0x4d5, 
    0x3, 0x2, 0x2, 0x2, 0x4d7, 0x171, 0x3, 0x2, 0x2, 0x2, 0x4d8, 0x4d9, 
    0x5, 0x84, 0x43, 0x2, 0x4d9, 0x4da, 0x5, 0x70, 0x39, 0x2, 0x4da, 0x173, 
    0x3, 0x2, 0x2, 0x2, 0x4db, 0x4de, 0x5, 0x1ec, 0xf7, 0x2, 0x4dc, 0x4de, 
    0x5, 0x1ee, 0xf8, 0x2, 0x4dd, 0x4db, 0x3, 0x2, 0x2, 0x2, 0x4dd, 0x4dc, 
    0x3, 0x2, 0x2, 0x2, 0x4de, 0x175, 0x3, 0x2, 0x2, 0x2, 0x4df, 0x4e2, 
    0x5, 0x3c, 0x1f, 0x2, 0x4e0, 0x4e2, 0x5, 0x76, 0x3c, 0x2, 0x4e1, 0x4df, 
    0x3, 0x2, 0x2, 0x2, 0x4e1, 0x4e0, 0x3, 0x2, 0x2, 0x2, 0x4e2, 0x177, 
    0x3, 0x2, 0x2, 0x2, 0x4e3, 0x4e7, 0x5, 0x1f0, 0xf9, 0x2, 0x4e4, 0x4e7, 
    0x7, 0x54, 0x2, 0x2, 0x4e5, 0x4e7, 0x5, 0x1f2, 0xfa, 0x2, 0x4e6, 0x4e3, 
    0x3, 0x2, 0x2, 0x2, 0x4e6, 0x4e4, 0x3, 0x2, 0x2, 0x2, 0x4e6, 0x4e5, 
    0x3, 0x2, 0x2, 0x2, 0x4e7, 0x179, 0x3, 0x2, 0x2, 0x2, 0x4e8, 0x4e9, 
    0x5, 0x1a4, 0xd3, 0x2, 0x4e9, 0x4ea, 0x7, 0x45, 0x2, 0x2, 0x4ea, 0x4eb, 
    0x5, 0x72, 0x3a, 0x2, 0x4eb, 0x17b, 0x3, 0x2, 0x2, 0x2, 0x4ec, 0x4f0, 
    0x7, 0x72, 0x2, 0x2, 0x4ed, 0x4f0, 0x5, 0x1f4, 0xfb, 0x2, 0x4ee, 0x4f0, 
    0x7, 0x1a, 0x2, 0x2, 0x4ef, 0x4ec, 0x3, 0x2, 0x2, 0x2, 0x4ef, 0x4ed, 
    0x3, 0x2, 0x2, 0x2, 0x4ef, 0x4ee, 0x3, 0x2, 0x2, 0x2, 0x4f0, 0x17d, 
    0x3, 0x2, 0x2, 0x2, 0x4f1, 0x4f6, 0x7, 0x19, 0x2, 0x2, 0x4f2, 0x4f6, 
    0x7, 0x13, 0x2, 0x2, 0x4f3, 0x4f6, 0x5, 0x1f6, 0xfc, 0x2, 0x4f4, 0x4f6, 
    0x5, 0x1f8, 0xfd, 0x2, 0x4f5, 0x4f1, 0x3, 0x2, 0x2, 0x2, 0x4f5, 0x4f2, 
    0x3, 0x2, 0x2, 0x2, 0x4f5, 0x4f3, 0x3, 0x2, 0x2, 0x2, 0x4f5, 0x4f4, 
    0x3, 0x2, 0x2, 0x2, 0x4f6, 0x17f, 0x3, 0x2, 0x2, 0x2, 0x4f7, 0x4f8, 
    0x5, 0x68, 0x35, 0x2, 0x4f8, 0x4f9, 0x7, 0x48, 0x2, 0x2, 0x4f9, 0x4fa, 
    0x5, 0x10e, 0x88, 0x2, 0x4fa, 0x4fb, 0x5, 0x146, 0xa4, 0x2, 0x4fb, 0x181, 
    0x3, 0x2, 0x2, 0x2, 0x4fc, 0x4ff, 0x5, 0x1fa, 0xfe, 0x2, 0x4fd, 0x4ff, 
    0x5, 0x1fc, 0xff, 0x2, 0x4fe, 0x4fc, 0x3, 0x2, 0x2, 0x2, 0x4fe, 0x4fd, 
    0x3, 0x2, 0x2, 0x2, 0x4ff, 0x183, 0x3, 0x2, 0x2, 0x2, 0x500, 0x501, 
    0x5, 0x1a6, 0xd4, 0x2, 0x501, 0x502, 0x5, 0x5e, 0x30, 0x2, 0x502, 0x503, 
    0x7, 0x60, 0x2, 0x2, 0x503, 0x504, 0x5, 0x5e, 0x30, 0x2, 0x504, 0x185, 
    0x3, 0x2, 0x2, 0x2, 0x505, 0x508, 0x7, 0x72, 0x2, 0x2, 0x506, 0x508, 
    0x5, 0x6, 0x4, 0x2, 0x507, 0x505, 0x3, 0x2, 0x2, 0x2, 0x507, 0x506, 
    0x3, 0x2, 0x2, 0x2, 0x508, 0x187, 0x3, 0x2, 0x2, 0x2, 0x509, 0x510, 
    0x7, 0x72, 0x2, 0x2, 0x50a, 0x510, 0x7, 0x73, 0x2, 0x2, 0x50b, 0x510, 
    0x5, 0x5a, 0x2e, 0x2, 0x50c, 0x510, 0x5, 0x2, 0x2, 0x2, 0x50d, 0x510, 
    0x5, 0x1fe, 0x100, 0x2, 0x50e, 0x510, 0x5, 0x200, 0x101, 0x2, 0x50f, 
    0x509, 0x3, 0x2, 0x2, 0x2, 0x50f, 0x50a, 0x3, 0x2, 0x2, 0x2, 0x50f, 
    0x50b, 0x3, 0x2, 0x2, 0x2, 0x50f, 0x50c, 0x3, 0x2, 0x2, 0x2, 0x50f, 
    0x50d, 0x3, 0x2, 0x2, 0x2, 0x50f, 0x50e, 0x3, 0x2, 0x2, 0x2, 0x510, 
    0x189, 0x3, 0x2, 0x2, 0x2, 0x511, 0x521, 0x7, 0x33, 0x2, 0x2, 0x512, 
    0x521, 0x7, 0x1f, 0x2, 0x2, 0x513, 0x521, 0x7, 0x30, 0x2, 0x2, 0x514, 
    0x521, 0x7, 0x43, 0x2, 0x2, 0x515, 0x521, 0x7, 0x12, 0x2, 0x2, 0x516, 
    0x521, 0x7, 0x27, 0x2, 0x2, 0x517, 0x521, 0x5, 0x1a, 0xe, 0x2, 0x518, 
    0x521, 0x5, 0x2a, 0x16, 0x2, 0x519, 0x521, 0x7, 0x24, 0x2, 0x2, 0x51a, 
    0x521, 0x7, 0x41, 0x2, 0x2, 0x51b, 0x521, 0x7, 0xb, 0x2, 0x2, 0x51c, 
    0x521, 0x7, 0xc, 0x2, 0x2, 0x51d, 0x521, 0x5, 0x34, 0x1b, 0x2, 0x51e, 
    0x521, 0x5, 0x202, 0x102, 0x2, 0x51f, 0x521, 0x5, 0x2c, 0x17, 0x2, 0x520, 
    0x511, 0x3, 0x2, 0x2, 0x2, 0x520, 0x512, 0x3, 0x2, 0x2, 0x2, 0x520, 
    0x513, 0x3, 0x2, 0x2, 0x2, 0x520, 0x514, 0x3, 0x2, 0x2, 0x2, 0x520, 
    0x515, 0x3, 0x2, 0x2, 0x2, 0x520, 0x516, 0x3, 0x2, 0x2, 0x2, 0x520, 
    0x517, 0x3, 0x2, 0x2, 0x2, 0x520, 0x518, 0x3, 0x2, 0x2, 0x2, 0x520, 
    0x519, 0x3, 0x2, 0x2, 0x2, 0x520, 0x51a, 0x3, 0x2, 0x2, 0x2, 0x520, 
    0x51b, 0x3, 0x2, 0x2, 0x2, 0x520, 0x51c, 0x3, 0x2, 0x2, 0x2, 0x520, 
    0x51d, 0x3, 0x2, 0x2, 0x2, 0x520, 0x51e, 0x3, 0x2, 0x2, 0x2, 0x520, 
    0x51f, 0x3, 0x2, 0x2, 0x2, 0x521, 0x18b, 0x3, 0x2, 0x2, 0x2, 0x522, 
    0x525, 0x5, 0x204, 0x103, 0x2, 0x523, 0x525, 0x5, 0x4a, 0x26, 0x2, 0x524, 
    0x522, 0x3, 0x2, 0x2, 0x2, 0x524, 0x523, 0x3, 0x2, 0x2, 0x2, 0x525, 
    0x18d, 0x3, 0x2, 0x2, 0x2, 0x526, 0x529, 0x5, 0x206, 0x104, 0x2, 0x527, 
    0x529, 0x5, 0x208, 0x105, 0x2, 0x528, 0x526, 0x3, 0x2, 0x2, 0x2, 0x528, 
    0x527, 0x3, 0x2, 0x2, 0x2, 0x529, 0x18f, 0x3, 0x2, 0x2, 0x2, 0x52a, 
    0x533, 0x5, 0x4e, 0x28, 0x2, 0x52b, 0x533, 0x5, 0x50, 0x29, 0x2, 0x52c, 
    0x533, 0x5, 0x52, 0x2a, 0x2, 0x52d, 0x533, 0x5, 0x20a, 0x106, 0x2, 0x52e, 
    0x533, 0x5, 0x20c, 0x107, 0x2, 0x52f, 0x533, 0x5, 0x54, 0x2b, 0x2, 0x530, 
    0x533, 0x5, 0x4c, 0x27, 0x2, 0x531, 0x533, 0x5, 0x20e, 0x108, 0x2, 0x532, 
    0x52a, 0x3, 0x2, 0x2, 0x2, 0x532, 0x52b, 0x3, 0x2, 0x2, 0x2, 0x532, 
    0x52c, 0x3, 0x2, 0x2, 0x2, 0x532, 0x52d, 0x3, 0x2, 0x2, 0x2, 0x532, 
    0x52e, 0x3, 0x2, 0x2, 0x2, 0x532, 0x52f, 0x3, 0x2, 0x2, 0x2, 0x532, 
    0x530, 0x3, 0x2, 0x2, 0x2, 0x532, 0x531, 0x3, 0x2, 0x2, 0x2, 0x533, 
    0x191, 0x3, 0x2, 0x2, 0x2, 0x534, 0x537, 0x5, 0x14, 0xb, 0x2, 0x535, 
    0x537, 0x5, 0x190, 0xc9, 0x2, 0x536, 0x534, 0x3, 0x2, 0x2, 0x2, 0x536, 
    0x535, 0x3, 0x2, 0x2, 0x2, 0x537, 0x193, 0x3, 0x2, 0x2, 0x2, 0x538, 
    0x53d, 0x5, 0x58, 0x2d, 0x2, 0x539, 0x53d, 0x5, 0x14, 0xb, 0x2, 0x53a, 
    0x53d, 0x7, 0x11, 0x2, 0x2, 0x53b, 0x53d, 0x7, 0x60, 0x2, 0x2, 0x53c, 
    0x538, 0x3, 0x2, 0x2, 0x2, 0x53c, 0x539, 0x3, 0x2, 0x2, 0x2, 0x53c, 
    0x53a, 0x3, 0x2, 0x2, 0x2, 0x53c, 0x53b, 0x3, 0x2, 0x2, 0x2, 0x53d, 
    0x195, 0x3, 0x2, 0x2, 0x2, 0x53e, 0x53f, 0x9, 0x10, 0x2, 0x2, 0x53f, 
    0x197, 0x3, 0x2, 0x2, 0x2, 0x540, 0x543, 0x5, 0x40, 0x21, 0x2, 0x541, 
    0x543, 0x5, 0x6, 0x4, 0x2, 0x542, 0x540, 0x3, 0x2, 0x2, 0x2, 0x542, 
    0x541, 0x3, 0x2, 0x2, 0x2, 0x543, 0x199, 0x3, 0x2, 0x2, 0x2, 0x544, 
    0x545, 0x9, 0x11, 0x2, 0x2, 0x545, 0x19b, 0x3, 0x2, 0x2, 0x2, 0x546, 
    0x549, 0x5, 0x1a, 0xe, 0x2, 0x547, 0x549, 0x5, 0x2a, 0x16, 0x2, 0x548, 
    0x546, 0x3, 0x2, 0x2, 0x2, 0x548, 0x547, 0x3, 0x2, 0x2, 0x2, 0x549, 
    0x19d, 0x3, 0x2, 0x2, 0x2, 0x54a, 0x54b, 0x9, 0x12, 0x2, 0x2, 0x54b, 
    0x19f, 0x3, 0x2, 0x2, 0x2, 0x54c, 0x54f, 0x5, 0x74, 0x3b, 0x2, 0x54d, 
    0x54f, 0x7, 0x54, 0x2, 0x2, 0x54e, 0x54c, 0x3, 0x2, 0x2, 0x2, 0x54e, 
    0x54d, 0x3, 0x2, 0x2, 0x2, 0x54f, 0x1a1, 0x3, 0x2, 0x2, 0x2, 0x550, 
    0x553, 0x5, 0x2e, 0x18, 0x2, 0x551, 0x553, 0x5, 0x86, 0x44, 0x2, 0x552, 
    0x550, 0x3, 0x2, 0x2, 0x2, 0x552, 0x551, 0x3, 0x2, 0x2, 0x2, 0x553, 
    0x1a3, 0x3, 0x2, 0x2, 0x2, 0x554, 0x557, 0x5, 0x42, 0x22, 0x2, 0x555, 
    0x557, 0x5, 0x88, 0x45, 0x2, 0x556, 0x554, 0x3, 0x2, 0x2, 0x2, 0x556, 
    0x555, 0x3, 0x2, 0x2, 0x2, 0x557, 0x1a5, 0x3, 0x2, 0x2, 0x2, 0x558, 
    0x55b, 0x5, 0x210, 0x109, 0x2, 0x559, 0x55b, 0x5, 0x14, 0xb, 0x2, 0x55a, 
    0x558, 0x3, 0x2, 0x2, 0x2, 0x55a, 0x559, 0x3, 0x2, 0x2, 0x2, 0x55b, 
    0x1a7, 0x3, 0x2, 0x2, 0x2, 0x55c, 0x55f, 0x5, 0x212, 0x10a, 0x2, 0x55d, 
    0x55f, 0x5, 0x214, 0x10b, 0x2, 0x55e, 0x55c, 0x3, 0x2, 0x2, 0x2, 0x55e, 
    0x55d, 0x3, 0x2, 0x2, 0x2, 0x55f, 0x1a9, 0x3, 0x2, 0x2, 0x2, 0x560, 
    0x561, 0x9, 0x13, 0x2, 0x2, 0x561, 0x1ab, 0x3, 0x2, 0x2, 0x2, 0x562, 
    0x563, 0x5, 0x8, 0x5, 0x2, 0x563, 0x564, 0x5, 0xa, 0x6, 0x2, 0x564, 
    0x1ad, 0x3, 0x2, 0x2, 0x2, 0x565, 0x566, 0x7, 0x59, 0x2, 0x2, 0x566, 
    0x567, 0x7, 0x72, 0x2, 0x2, 0x567, 0x1af, 0x3, 0x2, 0x2, 0x2, 0x568, 
    0x569, 0x5, 0x156, 0xac, 0x2, 0x569, 0x56a, 0x5, 0x6, 0x4, 0x2, 0x56a, 
    0x1b1, 0x3, 0x2, 0x2, 0x2, 0x56b, 0x56c, 0x5, 0x158, 0xad, 0x2, 0x56c, 
    0x56d, 0x7, 0x45, 0x2, 0x2, 0x56d, 0x1b3, 0x3, 0x2, 0x2, 0x2, 0x56e, 
    0x56f, 0x5, 0x5c, 0x2f, 0x2, 0x56f, 0x570, 0x7, 0x44, 0x2, 0x2, 0x570, 
    0x571, 0x5, 0x40, 0x21, 0x2, 0x571, 0x572, 0x7, 0x45, 0x2, 0x2, 0x572, 
    0x573, 0x5, 0xa, 0x6, 0x2, 0x573, 0x1b5, 0x3, 0x2, 0x2, 0x2, 0x574, 
    0x575, 0x5, 0x6, 0x4, 0x2, 0x575, 0x576, 0x5, 0x10, 0x9, 0x2, 0x576, 
    0x577, 0x5, 0xe, 0x8, 0x2, 0x577, 0x1b7, 0x3, 0x2, 0x2, 0x2, 0x578, 
    0x579, 0x5, 0x64, 0x33, 0x2, 0x579, 0x57a, 0x5, 0x16, 0xc, 0x2, 0x57a, 
    0x57b, 0x5, 0x66, 0x34, 0x2, 0x57b, 0x57c, 0x7, 0x60, 0x2, 0x2, 0x57c, 
    0x1b9, 0x3, 0x2, 0x2, 0x2, 0x57d, 0x57e, 0x5, 0x16a, 0xb6, 0x2, 0x57e, 
    0x57f, 0x7, 0x45, 0x2, 0x2, 0x57f, 0x1bb, 0x3, 0x2, 0x2, 0x2, 0x580, 
    0x581, 0x5, 0x6e, 0x38, 0x2, 0x581, 0x582, 0x7, 0x5f, 0x2, 0x2, 0x582, 
    0x583, 0x5, 0x12, 0xa, 0x2, 0x583, 0x1bd, 0x3, 0x2, 0x2, 0x2, 0x584, 
    0x585, 0x5, 0x32, 0x1a, 0x2, 0x585, 0x586, 0x7, 0x44, 0x2, 0x2, 0x586, 
    0x587, 0x5, 0x5a, 0x2e, 0x2, 0x587, 0x588, 0x7, 0x45, 0x2, 0x2, 0x588, 
    0x1bf, 0x3, 0x2, 0x2, 0x2, 0x589, 0x58a, 0x5, 0x70, 0x39, 0x2, 0x58a, 
    0x58b, 0x5, 0x12e, 0x98, 0x2, 0x58b, 0x58c, 0x5, 0x72, 0x3a, 0x2, 0x58c, 
    0x1c1, 0x3, 0x2, 0x2, 0x2, 0x58d, 0x58e, 0x7, 0x48, 0x2, 0x2, 0x58e, 
    0x58f, 0x5, 0xbe, 0x60, 0x2, 0x58f, 0x590, 0x5, 0x146, 0xa4, 0x2, 0x590, 
    0x591, 0x7, 0x49, 0x2, 0x2, 0x591, 0x1c3, 0x3, 0x2, 0x2, 0x2, 0x592, 
    0x593, 0x7, 0x46, 0x2, 0x2, 0x593, 0x594, 0x5, 0xac, 0x57, 0x2, 0x594, 
    0x595, 0x7, 0x47, 0x2, 0x2, 0x595, 0x1c5, 0x3, 0x2, 0x2, 0x2, 0x596, 
    0x597, 0x7, 0x44, 0x2, 0x2, 0x597, 0x598, 0x5, 0x5e, 0x30, 0x2, 0x598, 
    0x599, 0x7, 0x45, 0x2, 0x2, 0x599, 0x1c7, 0x3, 0x2, 0x2, 0x2, 0x59a, 
    0x59b, 0x5, 0x15c, 0xaf, 0x2, 0x59b, 0x59c, 0x7, 0x72, 0x2, 0x2, 0x59c, 
    0x1c9, 0x3, 0x2, 0x2, 0x2, 0x59d, 0x59e, 0x7, 0x46, 0x2, 0x2, 0x59e, 
    0x59f, 0x5, 0x174, 0xbb, 0x2, 0x59f, 0x5a0, 0x7, 0x47, 0x2, 0x2, 0x5a0, 
    0x1cb, 0x3, 0x2, 0x2, 0x2, 0x5a1, 0x5a2, 0x7, 0x44, 0x2, 0x2, 0x5a2, 
    0x5a3, 0x5, 0x176, 0xbc, 0x2, 0x5a3, 0x5a4, 0x7, 0x45, 0x2, 0x2, 0x5a4, 
    0x1cd, 0x3, 0x2, 0x2, 0x2, 0x5a5, 0x5a6, 0x7, 0x44, 0x2, 0x2, 0x5a6, 
    0x5a7, 0x5, 0x2e, 0x18, 0x2, 0x5a7, 0x5a8, 0x7, 0x45, 0x2, 0x2, 0x5a8, 
    0x1cf, 0x3, 0x2, 0x2, 0x2, 0x5a9, 0x5aa, 0x7, 0x44, 0x2, 0x2, 0x5aa, 
    0x5ab, 0x5, 0x88, 0x45, 0x2, 0x5ab, 0x5ac, 0x7, 0x45, 0x2, 0x2, 0x5ac, 
    0x5ad, 0x5, 0x72, 0x3a, 0x2, 0x5ad, 0x1d1, 0x3, 0x2, 0x2, 0x2, 0x5ae, 
    0x5af, 0x7, 0x46, 0x2, 0x2, 0x5af, 0x5b0, 0x5, 0x178, 0xbd, 0x2, 0x5b0, 
    0x5b1, 0x7, 0x47, 0x2, 0x2, 0x5b1, 0x1d3, 0x3, 0x2, 0x2, 0x2, 0x5b2, 
    0x5b3, 0x7, 0x46, 0x2, 0x2, 0x5b3, 0x5b4, 0x5, 0x178, 0xbd, 0x2, 0x5b4, 
    0x5b5, 0x7, 0x47, 0x2, 0x2, 0x5b5, 0x1d5, 0x3, 0x2, 0x2, 0x2, 0x5b6, 
    0x5b7, 0x7, 0x44, 0x2, 0x2, 0x5b7, 0x5b8, 0x5, 0x17a, 0xbe, 0x2, 0x5b8, 
    0x1d7, 0x3, 0x2, 0x2, 0x2, 0x5b9, 0x5ba, 0x7, 0x44, 0x2, 0x2, 0x5ba, 
    0x5bb, 0x5, 0xac, 0x57, 0x2, 0x5bb, 0x1d9, 0x3, 0x2, 0x2, 0x2, 0x5bc, 
    0x5bd, 0x5, 0x5c, 0x2f, 0x2, 0x5bd, 0x5be, 0x7, 0x44, 0x2, 0x2, 0x5be, 
    0x5bf, 0x5, 0x50, 0x29, 0x2, 0x5bf, 0x1db, 0x3, 0x2, 0x2, 0x2, 0x5c0, 
    0x5c1, 0x7, 0xd, 0x2, 0x2, 0x5c1, 0x5c2, 0x7, 0x44, 0x2, 0x2, 0x5c2, 
    0x5c3, 0x5, 0x6, 0x4, 0x2, 0x5c3, 0x5c4, 0x7, 0x61, 0x2, 0x2, 0x5c4, 
    0x5c5, 0x5, 0x40, 0x21, 0x2, 0x5c5, 0x1dd, 0x3, 0x2, 0x2, 0x2, 0x5c6, 
    0x5c7, 0x7, 0xe, 0x2, 0x2, 0x5c7, 0x5c8, 0x7, 0x44, 0x2, 0x2, 0x5c8, 
    0x5c9, 0x5, 0x40, 0x21, 0x2, 0x5c9, 0x5ca, 0x7, 0x61, 0x2, 0x2, 0x5ca, 
    0x5cb, 0x5, 0x6, 0x4, 0x2, 0x5cb, 0x1df, 0x3, 0x2, 0x2, 0x2, 0x5cc, 
    0x5cd, 0x7, 0x2f, 0x2, 0x2, 0x5cd, 0x5ce, 0x7, 0x44, 0x2, 0x2, 0x5ce, 
    0x5cf, 0x5, 0x40, 0x21, 0x2, 0x5cf, 0x1e1, 0x3, 0x2, 0x2, 0x2, 0x5d0, 
    0x5d1, 0x5, 0x196, 0xcc, 0x2, 0x5d1, 0x5d2, 0x7, 0x44, 0x2, 0x2, 0x5d2, 
    0x5d3, 0x5, 0x198, 0xcd, 0x2, 0x5d3, 0x1e3, 0x3, 0x2, 0x2, 0x2, 0x5d4, 
    0x5d5, 0x7, 0x2b, 0x2, 0x2, 0x5d5, 0x5d6, 0x7, 0x44, 0x2, 0x2, 0x5d6, 
    0x5d7, 0x5, 0x19a, 0xce, 0x2, 0x5d7, 0x1e5, 0x3, 0x2, 0x2, 0x2, 0x5d8, 
    0x5d9, 0x7, 0xf, 0x2, 0x2, 0x5d9, 0x5da, 0x7, 0x44, 0x2, 0x2, 0x5da, 
    0x5db, 0x5, 0x12, 0xa, 0x2, 0x5db, 0x1e7, 0x3, 0x2, 0x2, 0x2, 0x5dc, 
    0x5dd, 0x5, 0x68, 0x35, 0x2, 0x5dd, 0x5de, 0x7, 0x48, 0x2, 0x2, 0x5de, 
    0x5df, 0x5, 0x102, 0x82, 0x2, 0x5df, 0x5e0, 0x7, 0x49, 0x2, 0x2, 0x5e0, 
    0x1e9, 0x3, 0x2, 0x2, 0x2, 0x5e1, 0x5e2, 0x5, 0x180, 0xc1, 0x2, 0x5e2, 
    0x5e3, 0x7, 0x49, 0x2, 0x2, 0x5e3, 0x1eb, 0x3, 0x2, 0x2, 0x2, 0x5e4, 
    0x5e5, 0x5, 0x182, 0xc2, 0x2, 0x5e5, 0x5e6, 0x5, 0xe, 0x8, 0x2, 0x5e6, 
    0x1ed, 0x3, 0x2, 0x2, 0x2, 0x5e7, 0x5e8, 0x5, 0x84, 0x43, 0x2, 0x5e8, 
    0x5e9, 0x5, 0x1a0, 0xd1, 0x2, 0x5e9, 0x1ef, 0x3, 0x2, 0x2, 0x2, 0x5ea, 
    0x5eb, 0x5, 0x84, 0x43, 0x2, 0x5eb, 0x5ec, 0x5, 0x74, 0x3b, 0x2, 0x5ec, 
    0x1f1, 0x3, 0x2, 0x2, 0x2, 0x5ed, 0x5ee, 0x5, 0x182, 0xc2, 0x2, 0x5ee, 
    0x5ef, 0x5, 0xe, 0x8, 0x2, 0x5ef, 0x1f3, 0x3, 0x2, 0x2, 0x2, 0x5f0, 
    0x5f1, 0x7, 0x14, 0x2, 0x2, 0x5f1, 0x5f2, 0x5, 0x12, 0xa, 0x2, 0x5f2, 
    0x1f5, 0x3, 0x2, 0x2, 0x2, 0x5f3, 0x5f4, 0x7, 0x2c, 0x2, 0x2, 0x5f4, 
    0x5f5, 0x5, 0x5e, 0x30, 0x2, 0x5f5, 0x1f7, 0x3, 0x2, 0x2, 0x2, 0x5f6, 
    0x5f7, 0x7, 0x22, 0x2, 0x2, 0x5f7, 0x5f8, 0x5, 0x186, 0xc4, 0x2, 0x5f8, 
    0x1f9, 0x3, 0x2, 0x2, 0x2, 0x5f9, 0x5fa, 0x7, 0x30, 0x2, 0x2, 0x5fa, 
    0x5fb, 0x5, 0x84, 0x43, 0x2, 0x5fb, 0x1fb, 0x3, 0x2, 0x2, 0x2, 0x5fc, 
    0x5fd, 0x5, 0x11a, 0x8e, 0x2, 0x5fd, 0x5fe, 0x7, 0x30, 0x2, 0x2, 0x5fe, 
    0x1fd, 0x3, 0x2, 0x2, 0x2, 0x5ff, 0x600, 0x5, 0x154, 0xab, 0x2, 0x600, 
    0x601, 0x7, 0x45, 0x2, 0x2, 0x601, 0x1ff, 0x3, 0x2, 0x2, 0x2, 0x602, 
    0x603, 0x5, 0x15e, 0xb0, 0x2, 0x603, 0x604, 0x7, 0x49, 0x2, 0x2, 0x604, 
    0x201, 0x3, 0x2, 0x2, 0x2, 0x605, 0x606, 0x7, 0x10, 0x2, 0x2, 0x606, 
    0x607, 0x7, 0x44, 0x2, 0x2, 0x607, 0x608, 0x7, 0x72, 0x2, 0x2, 0x608, 
    0x609, 0x7, 0x45, 0x2, 0x2, 0x609, 0x203, 0x3, 0x2, 0x2, 0x2, 0x60a, 
    0x60b, 0x5, 0x64, 0x33, 0x2, 0x60b, 0x60c, 0x5, 0x20, 0x11, 0x2, 0x60c, 
    0x60d, 0x5, 0x6a, 0x36, 0x2, 0x60d, 0x60e, 0x7, 0x60, 0x2, 0x2, 0x60e, 
    0x205, 0x3, 0x2, 0x2, 0x2, 0x60f, 0x610, 0x7, 0x46, 0x2, 0x2, 0x610, 
    0x611, 0x5, 0x12, 0xa, 0x2, 0x611, 0x612, 0x7, 0x47, 0x2, 0x2, 0x612, 
    0x207, 0x3, 0x2, 0x2, 0x2, 0x613, 0x614, 0x7, 0x70, 0x2, 0x2, 0x614, 
    0x615, 0x7, 0x72, 0x2, 0x2, 0x615, 0x209, 0x3, 0x2, 0x2, 0x2, 0x616, 
    0x617, 0x7, 0x23, 0x2, 0x2, 0x617, 0x618, 0x7, 0x44, 0x2, 0x2, 0x618, 
    0x619, 0x5, 0xac, 0x57, 0x2, 0x619, 0x61a, 0x7, 0x45, 0x2, 0x2, 0x61a, 
    0x61b, 0x5, 0x190, 0xc9, 0x2, 0x61b, 0x61c, 0x5, 0xa0, 0x51, 0x2, 0x61c, 
    0x20b, 0x3, 0x2, 0x2, 0x2, 0x61d, 0x61e, 0x7, 0x1b, 0x2, 0x2, 0x61e, 
    0x61f, 0x5, 0x190, 0xc9, 0x2, 0x61f, 0x620, 0x7, 0x38, 0x2, 0x2, 0x620, 
    0x621, 0x7, 0x44, 0x2, 0x2, 0x621, 0x622, 0x5, 0xac, 0x57, 0x2, 0x622, 
    0x623, 0x7, 0x45, 0x2, 0x2, 0x623, 0x624, 0x7, 0x60, 0x2, 0x2, 0x624, 
    0x20d, 0x3, 0x2, 0x2, 0x2, 0x625, 0x626, 0x5, 0x1a8, 0xd5, 0x2, 0x626, 
    0x627, 0x7, 0x45, 0x2, 0x2, 0x627, 0x628, 0x5, 0x190, 0xc9, 0x2, 0x628, 
    0x20f, 0x3, 0x2, 0x2, 0x2, 0x629, 0x62a, 0x5, 0x5e, 0x30, 0x2, 0x62a, 
    0x62b, 0x7, 0x60, 0x2, 0x2, 0x62b, 0x211, 0x3, 0x2, 0x2, 0x2, 0x62c, 
    0x62d, 0x7, 0x21, 0x2, 0x2, 0x62d, 0x62e, 0x7, 0x44, 0x2, 0x2, 0x62e, 
    0x62f, 0x5, 0x184, 0xc3, 0x2, 0x62f, 0x213, 0x3, 0x2, 0x2, 0x2, 0x630, 
    0x631, 0x5, 0x1aa, 0xd6, 0x2, 0x631, 0x632, 0x7, 0x44, 0x2, 0x2, 0x632, 
    0x633, 0x5, 0xac, 0x57, 0x2, 0x633, 0x215, 0x3, 0x2, 0x2, 0x2, 0x6b, 
    0x226, 0x22c, 0x233, 0x23c, 0x241, 0x259, 0x265, 0x27f, 0x28b, 0x28e, 
    0x29e, 0x2a4, 0x2d3, 0x2d6, 0x2d9, 0x2e1, 0x2e4, 0x2e7, 0x2ea, 0x2ed, 
    0x2f0, 0x2f3, 0x2f6, 0x2fb, 0x2ff, 0x302, 0x30a, 0x315, 0x31b, 0x31e, 
    0x321, 0x324, 0x329, 0x331, 0x338, 0x340, 0x344, 0x34a, 0x34d, 0x350, 
    0x353, 0x35b, 0x367, 0x372, 0x377, 0x384, 0x391, 0x39d, 0x3a9, 0x3b5, 
    0x3c1, 0x3cd, 0x3d9, 0x3e5, 0x3f1, 0x3fd, 0x409, 0x417, 0x423, 0x42b, 
    0x430, 0x435, 0x444, 0x450, 0x458, 0x45d, 0x462, 0x474, 0x479, 0x47e, 
    0x483, 0x488, 0x48d, 0x490, 0x496, 0x49c, 0x4a2, 0x4a8, 0x4ae, 0x4b2, 
    0x4ca, 0x4ce, 0x4d2, 0x4d6, 0x4dd, 0x4e1, 0x4e6, 0x4ef, 0x4f5, 0x4fe, 
    0x507, 0x50f, 0x520, 0x524, 0x528, 0x532, 0x536, 0x53c, 0x542, 0x548, 
    0x54e, 0x552, 0x556, 0x55a, 0x55e, 
  };

  atn::ATNDeserializer deserializer;
  _atn = deserializer.deserialize(_serializedATN);

  size_t count = _atn.getNumberOfDecisions();
  _decisionToDFA.reserve(count);
  for (size_t i = 0; i < count; i++) { 
    _decisionToDFA.emplace_back(_atn.getDecisionState(i), i);
  }
}

PnfCParser::Initializer PnfCParser::_init;
