
// Generated from PnfC.g4 by ANTLR 4.7.2

#pragma once


#include "antlr4-runtime.h"
#include "PnfCListener.h"


namespace antlr_C_perses {

/**
 * This class provides an empty implementation of PnfCListener,
 * which can be extended to create a listener which only needs to handle a subset
 * of the available methods.
 */
class  PnfCBaseListener : public PnfCListener {
public:

  virtual void enterGenericSelection(PnfCParser::GenericSelectionContext * /*ctx*/) override { }
  virtual void exitGenericSelection(PnfCParser::GenericSelectionContext * /*ctx*/) override { }

  virtual void enterGenericAssociation(PnfCParser::GenericAssociationContext * /*ctx*/) override { }
  virtual void exitGenericAssociation(PnfCParser::GenericAssociationContext * /*ctx*/) override { }

  virtual void enterUnaryExpression(PnfCParser::UnaryExpressionContext * /*ctx*/) override { }
  virtual void exitUnaryExpression(PnfCParser::UnaryExpressionContext * /*ctx*/) override { }

  virtual void enterUnaryOperator(PnfCParser::UnaryOperatorContext * /*ctx*/) override { }
  virtual void exitUnaryOperator(PnfCParser::UnaryOperatorContext * /*ctx*/) override { }

  virtual void enterCastExpression(PnfCParser::CastExpressionContext * /*ctx*/) override { }
  virtual void exitCastExpression(PnfCParser::CastExpressionContext * /*ctx*/) override { }

  virtual void enterConditionalExpression(PnfCParser::ConditionalExpressionContext * /*ctx*/) override { }
  virtual void exitConditionalExpression(PnfCParser::ConditionalExpressionContext * /*ctx*/) override { }

  virtual void enterAssignmentExpression(PnfCParser::AssignmentExpressionContext * /*ctx*/) override { }
  virtual void exitAssignmentExpression(PnfCParser::AssignmentExpressionContext * /*ctx*/) override { }

  virtual void enterAssignmentOperator(PnfCParser::AssignmentOperatorContext * /*ctx*/) override { }
  virtual void exitAssignmentOperator(PnfCParser::AssignmentOperatorContext * /*ctx*/) override { }

  virtual void enterConstantExpression(PnfCParser::ConstantExpressionContext * /*ctx*/) override { }
  virtual void exitConstantExpression(PnfCParser::ConstantExpressionContext * /*ctx*/) override { }

  virtual void enterDeclaration(PnfCParser::DeclarationContext * /*ctx*/) override { }
  virtual void exitDeclaration(PnfCParser::DeclarationContext * /*ctx*/) override { }

  virtual void enterDeclarationSpecifiers(PnfCParser::DeclarationSpecifiersContext * /*ctx*/) override { }
  virtual void exitDeclarationSpecifiers(PnfCParser::DeclarationSpecifiersContext * /*ctx*/) override { }

  virtual void enterInitDeclarator(PnfCParser::InitDeclaratorContext * /*ctx*/) override { }
  virtual void exitInitDeclarator(PnfCParser::InitDeclaratorContext * /*ctx*/) override { }

  virtual void enterTypeSpecifier(PnfCParser::TypeSpecifierContext * /*ctx*/) override { }
  virtual void exitTypeSpecifier(PnfCParser::TypeSpecifierContext * /*ctx*/) override { }

  virtual void enterStructOrUnionSpecifier(PnfCParser::StructOrUnionSpecifierContext * /*ctx*/) override { }
  virtual void exitStructOrUnionSpecifier(PnfCParser::StructOrUnionSpecifierContext * /*ctx*/) override { }

  virtual void enterStructOrUnion(PnfCParser::StructOrUnionContext * /*ctx*/) override { }
  virtual void exitStructOrUnion(PnfCParser::StructOrUnionContext * /*ctx*/) override { }

  virtual void enterSpecifierQualifierList(PnfCParser::SpecifierQualifierListContext * /*ctx*/) override { }
  virtual void exitSpecifierQualifierList(PnfCParser::SpecifierQualifierListContext * /*ctx*/) override { }

  virtual void enterStructDeclarator(PnfCParser::StructDeclaratorContext * /*ctx*/) override { }
  virtual void exitStructDeclarator(PnfCParser::StructDeclaratorContext * /*ctx*/) override { }

  virtual void enterEnumSpecifier(PnfCParser::EnumSpecifierContext * /*ctx*/) override { }
  virtual void exitEnumSpecifier(PnfCParser::EnumSpecifierContext * /*ctx*/) override { }

  virtual void enterEnumerator(PnfCParser::EnumeratorContext * /*ctx*/) override { }
  virtual void exitEnumerator(PnfCParser::EnumeratorContext * /*ctx*/) override { }

  virtual void enterAtomicTypeSpecifier(PnfCParser::AtomicTypeSpecifierContext * /*ctx*/) override { }
  virtual void exitAtomicTypeSpecifier(PnfCParser::AtomicTypeSpecifierContext * /*ctx*/) override { }

  virtual void enterTypeQualifier(PnfCParser::TypeQualifierContext * /*ctx*/) override { }
  virtual void exitTypeQualifier(PnfCParser::TypeQualifierContext * /*ctx*/) override { }

  virtual void enterAlignmentSpecifier(PnfCParser::AlignmentSpecifierContext * /*ctx*/) override { }
  virtual void exitAlignmentSpecifier(PnfCParser::AlignmentSpecifierContext * /*ctx*/) override { }

  virtual void enterDeclarator(PnfCParser::DeclaratorContext * /*ctx*/) override { }
  virtual void exitDeclarator(PnfCParser::DeclaratorContext * /*ctx*/) override { }

  virtual void enterGccDeclaratorExtension(PnfCParser::GccDeclaratorExtensionContext * /*ctx*/) override { }
  virtual void exitGccDeclaratorExtension(PnfCParser::GccDeclaratorExtensionContext * /*ctx*/) override { }

  virtual void enterAsmKeyword(PnfCParser::AsmKeywordContext * /*ctx*/) override { }
  virtual void exitAsmKeyword(PnfCParser::AsmKeywordContext * /*ctx*/) override { }

  virtual void enterGccAttributeSpecifier(PnfCParser::GccAttributeSpecifierContext * /*ctx*/) override { }
  virtual void exitGccAttributeSpecifier(PnfCParser::GccAttributeSpecifierContext * /*ctx*/) override { }

  virtual void enterGccAttributeList(PnfCParser::GccAttributeListContext * /*ctx*/) override { }
  virtual void exitGccAttributeList(PnfCParser::GccAttributeListContext * /*ctx*/) override { }

  virtual void enterGccAttribute(PnfCParser::GccAttributeContext * /*ctx*/) override { }
  virtual void exitGccAttribute(PnfCParser::GccAttributeContext * /*ctx*/) override { }

  virtual void enterPointer(PnfCParser::PointerContext * /*ctx*/) override { }
  virtual void exitPointer(PnfCParser::PointerContext * /*ctx*/) override { }

  virtual void enterParameterTypeList(PnfCParser::ParameterTypeListContext * /*ctx*/) override { }
  virtual void exitParameterTypeList(PnfCParser::ParameterTypeListContext * /*ctx*/) override { }

  virtual void enterParameterDeclaration(PnfCParser::ParameterDeclarationContext * /*ctx*/) override { }
  virtual void exitParameterDeclaration(PnfCParser::ParameterDeclarationContext * /*ctx*/) override { }

  virtual void enterTypeName(PnfCParser::TypeNameContext * /*ctx*/) override { }
  virtual void exitTypeName(PnfCParser::TypeNameContext * /*ctx*/) override { }

  virtual void enterAbstractDeclarator(PnfCParser::AbstractDeclaratorContext * /*ctx*/) override { }
  virtual void exitAbstractDeclarator(PnfCParser::AbstractDeclaratorContext * /*ctx*/) override { }

  virtual void enterTypedefName(PnfCParser::TypedefNameContext * /*ctx*/) override { }
  virtual void exitTypedefName(PnfCParser::TypedefNameContext * /*ctx*/) override { }

  virtual void enterInitializer(PnfCParser::InitializerContext * /*ctx*/) override { }
  virtual void exitInitializer(PnfCParser::InitializerContext * /*ctx*/) override { }

  virtual void enterDesignation(PnfCParser::DesignationContext * /*ctx*/) override { }
  virtual void exitDesignation(PnfCParser::DesignationContext * /*ctx*/) override { }

  virtual void enterStaticAssertDeclaration(PnfCParser::StaticAssertDeclarationContext * /*ctx*/) override { }
  virtual void exitStaticAssertDeclaration(PnfCParser::StaticAssertDeclarationContext * /*ctx*/) override { }

  virtual void enterAsmStatement(PnfCParser::AsmStatementContext * /*ctx*/) override { }
  virtual void exitAsmStatement(PnfCParser::AsmStatementContext * /*ctx*/) override { }

  virtual void enterLabeledStatement(PnfCParser::LabeledStatementContext * /*ctx*/) override { }
  virtual void exitLabeledStatement(PnfCParser::LabeledStatementContext * /*ctx*/) override { }

  virtual void enterCompoundStatement(PnfCParser::CompoundStatementContext * /*ctx*/) override { }
  virtual void exitCompoundStatement(PnfCParser::CompoundStatementContext * /*ctx*/) override { }

  virtual void enterExpressionStatement(PnfCParser::ExpressionStatementContext * /*ctx*/) override { }
  virtual void exitExpressionStatement(PnfCParser::ExpressionStatementContext * /*ctx*/) override { }

  virtual void enterJumpStatement(PnfCParser::JumpStatementContext * /*ctx*/) override { }
  virtual void exitJumpStatement(PnfCParser::JumpStatementContext * /*ctx*/) override { }

  virtual void enterCompilationUnit(PnfCParser::CompilationUnitContext * /*ctx*/) override { }
  virtual void exitCompilationUnit(PnfCParser::CompilationUnitContext * /*ctx*/) override { }

  virtual void enterFunctionDefinition(PnfCParser::FunctionDefinitionContext * /*ctx*/) override { }
  virtual void exitFunctionDefinition(PnfCParser::FunctionDefinitionContext * /*ctx*/) override { }

  virtual void enterKleene_plus__primaryExpression_1(PnfCParser::Kleene_plus__primaryExpression_1Context * /*ctx*/) override { }
  virtual void exitKleene_plus__primaryExpression_1(PnfCParser::Kleene_plus__primaryExpression_1Context * /*ctx*/) override { }

  virtual void enterOptional__primaryExpression_2(PnfCParser::Optional__primaryExpression_2Context * /*ctx*/) override { }
  virtual void exitOptional__primaryExpression_2(PnfCParser::Optional__primaryExpression_2Context * /*ctx*/) override { }

  virtual void enterOptional__postfixExpression_1(PnfCParser::Optional__postfixExpression_1Context * /*ctx*/) override { }
  virtual void exitOptional__postfixExpression_1(PnfCParser::Optional__postfixExpression_1Context * /*ctx*/) override { }

  virtual void enterAux_rule__conditionalExpression_1(PnfCParser::Aux_rule__conditionalExpression_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__conditionalExpression_1(PnfCParser::Aux_rule__conditionalExpression_1Context * /*ctx*/) override { }

  virtual void enterOptional__conditionalExpression_2(PnfCParser::Optional__conditionalExpression_2Context * /*ctx*/) override { }
  virtual void exitOptional__conditionalExpression_2(PnfCParser::Optional__conditionalExpression_2Context * /*ctx*/) override { }

  virtual void enterOptional__declaration_1(PnfCParser::Optional__declaration_1Context * /*ctx*/) override { }
  virtual void exitOptional__declaration_1(PnfCParser::Optional__declaration_1Context * /*ctx*/) override { }

  virtual void enterOptional__declaration_2(PnfCParser::Optional__declaration_2Context * /*ctx*/) override { }
  virtual void exitOptional__declaration_2(PnfCParser::Optional__declaration_2Context * /*ctx*/) override { }

  virtual void enterOptional__structOrUnionSpecifier_1(PnfCParser::Optional__structOrUnionSpecifier_1Context * /*ctx*/) override { }
  virtual void exitOptional__structOrUnionSpecifier_1(PnfCParser::Optional__structOrUnionSpecifier_1Context * /*ctx*/) override { }

  virtual void enterOptional__structDeclaration_2(PnfCParser::Optional__structDeclaration_2Context * /*ctx*/) override { }
  virtual void exitOptional__structDeclaration_2(PnfCParser::Optional__structDeclaration_2Context * /*ctx*/) override { }

  virtual void enterOptional__specifierQualifierList_1(PnfCParser::Optional__specifierQualifierList_1Context * /*ctx*/) override { }
  virtual void exitOptional__specifierQualifierList_1(PnfCParser::Optional__specifierQualifierList_1Context * /*ctx*/) override { }

  virtual void enterOptional__structDeclarator_1(PnfCParser::Optional__structDeclarator_1Context * /*ctx*/) override { }
  virtual void exitOptional__structDeclarator_1(PnfCParser::Optional__structDeclarator_1Context * /*ctx*/) override { }

  virtual void enterOptional__declarator_1(PnfCParser::Optional__declarator_1Context * /*ctx*/) override { }
  virtual void exitOptional__declarator_1(PnfCParser::Optional__declarator_1Context * /*ctx*/) override { }

  virtual void enterKleene_star__declarator_2(PnfCParser::Kleene_star__declarator_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__declarator_2(PnfCParser::Kleene_star__declarator_2Context * /*ctx*/) override { }

  virtual void enterOptional__directDeclarator_2(PnfCParser::Optional__directDeclarator_2Context * /*ctx*/) override { }
  virtual void exitOptional__directDeclarator_2(PnfCParser::Optional__directDeclarator_2Context * /*ctx*/) override { }

  virtual void enterOptional__directDeclarator_5(PnfCParser::Optional__directDeclarator_5Context * /*ctx*/) override { }
  virtual void exitOptional__directDeclarator_5(PnfCParser::Optional__directDeclarator_5Context * /*ctx*/) override { }

  virtual void enterAux_rule__gccAttributeList_1(PnfCParser::Aux_rule__gccAttributeList_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__gccAttributeList_1(PnfCParser::Aux_rule__gccAttributeList_1Context * /*ctx*/) override { }

  virtual void enterKleene_star__gccAttributeList_2(PnfCParser::Kleene_star__gccAttributeList_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__gccAttributeList_2(PnfCParser::Kleene_star__gccAttributeList_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__gccAttributeList_3(PnfCParser::Aux_rule__gccAttributeList_3Context * /*ctx*/) override { }
  virtual void exitAux_rule__gccAttributeList_3(PnfCParser::Aux_rule__gccAttributeList_3Context * /*ctx*/) override { }

  virtual void enterAux_rule__gccAttribute_2(PnfCParser::Aux_rule__gccAttribute_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__gccAttribute_2(PnfCParser::Aux_rule__gccAttribute_2Context * /*ctx*/) override { }

  virtual void enterOptional__gccAttribute_3(PnfCParser::Optional__gccAttribute_3Context * /*ctx*/) override { }
  virtual void exitOptional__gccAttribute_3(PnfCParser::Optional__gccAttribute_3Context * /*ctx*/) override { }

  virtual void enterAux_rule__gccAttribute_4(PnfCParser::Aux_rule__gccAttribute_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__gccAttribute_4(PnfCParser::Aux_rule__gccAttribute_4Context * /*ctx*/) override { }

  virtual void enterOptional__pointer_1(PnfCParser::Optional__pointer_1Context * /*ctx*/) override { }
  virtual void exitOptional__pointer_1(PnfCParser::Optional__pointer_1Context * /*ctx*/) override { }

  virtual void enterOptional__typeName_1(PnfCParser::Optional__typeName_1Context * /*ctx*/) override { }
  virtual void exitOptional__typeName_1(PnfCParser::Optional__typeName_1Context * /*ctx*/) override { }

  virtual void enterOptional__directAbstractDeclarator_5(PnfCParser::Optional__directAbstractDeclarator_5Context * /*ctx*/) override { }
  virtual void exitOptional__directAbstractDeclarator_5(PnfCParser::Optional__directAbstractDeclarator_5Context * /*ctx*/) override { }

  virtual void enterOptional__initializerList_1(PnfCParser::Optional__initializerList_1Context * /*ctx*/) override { }
  virtual void exitOptional__initializerList_1(PnfCParser::Optional__initializerList_1Context * /*ctx*/) override { }

  virtual void enterAux_rule__asmStatement_1(PnfCParser::Aux_rule__asmStatement_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__asmStatement_1(PnfCParser::Aux_rule__asmStatement_1Context * /*ctx*/) override { }

  virtual void enterOptional__asmStatement_2(PnfCParser::Optional__asmStatement_2Context * /*ctx*/) override { }
  virtual void exitOptional__asmStatement_2(PnfCParser::Optional__asmStatement_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__asmStatement_3(PnfCParser::Aux_rule__asmStatement_3Context * /*ctx*/) override { }
  virtual void exitAux_rule__asmStatement_3(PnfCParser::Aux_rule__asmStatement_3Context * /*ctx*/) override { }

  virtual void enterKleene_star__asmStatement_4(PnfCParser::Kleene_star__asmStatement_4Context * /*ctx*/) override { }
  virtual void exitKleene_star__asmStatement_4(PnfCParser::Kleene_star__asmStatement_4Context * /*ctx*/) override { }

  virtual void enterAux_rule__asmStatement_5(PnfCParser::Aux_rule__asmStatement_5Context * /*ctx*/) override { }
  virtual void exitAux_rule__asmStatement_5(PnfCParser::Aux_rule__asmStatement_5Context * /*ctx*/) override { }

  virtual void enterOptional__asmStatement_6(PnfCParser::Optional__asmStatement_6Context * /*ctx*/) override { }
  virtual void exitOptional__asmStatement_6(PnfCParser::Optional__asmStatement_6Context * /*ctx*/) override { }

  virtual void enterAux_rule__asmStatement_11(PnfCParser::Aux_rule__asmStatement_11Context * /*ctx*/) override { }
  virtual void exitAux_rule__asmStatement_11(PnfCParser::Aux_rule__asmStatement_11Context * /*ctx*/) override { }

  virtual void enterKleene_star__asmStatement_12(PnfCParser::Kleene_star__asmStatement_12Context * /*ctx*/) override { }
  virtual void exitKleene_star__asmStatement_12(PnfCParser::Kleene_star__asmStatement_12Context * /*ctx*/) override { }

  virtual void enterOptional__compoundStatement_1(PnfCParser::Optional__compoundStatement_1Context * /*ctx*/) override { }
  virtual void exitOptional__compoundStatement_1(PnfCParser::Optional__compoundStatement_1Context * /*ctx*/) override { }

  virtual void enterAux_rule__selectionStatement_1(PnfCParser::Aux_rule__selectionStatement_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__selectionStatement_1(PnfCParser::Aux_rule__selectionStatement_1Context * /*ctx*/) override { }

  virtual void enterOptional__selectionStatement_2(PnfCParser::Optional__selectionStatement_2Context * /*ctx*/) override { }
  virtual void exitOptional__selectionStatement_2(PnfCParser::Optional__selectionStatement_2Context * /*ctx*/) override { }

  virtual void enterOptional__compilationUnit_1(PnfCParser::Optional__compilationUnit_1Context * /*ctx*/) override { }
  virtual void exitOptional__compilationUnit_1(PnfCParser::Optional__compilationUnit_1Context * /*ctx*/) override { }

  virtual void enterOptional__functionDefinition_2(PnfCParser::Optional__functionDefinition_2Context * /*ctx*/) override { }
  virtual void exitOptional__functionDefinition_2(PnfCParser::Optional__functionDefinition_2Context * /*ctx*/) override { }

  virtual void enterOptional__functionDefinition_3(PnfCParser::Optional__functionDefinition_3Context * /*ctx*/) override { }
  virtual void exitOptional__functionDefinition_3(PnfCParser::Optional__functionDefinition_3Context * /*ctx*/) override { }

  virtual void enterAux_rule__expression_2(PnfCParser::Aux_rule__expression_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__expression_2(PnfCParser::Aux_rule__expression_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__expression_1(PnfCParser::Kleene_star__expression_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__expression_1(PnfCParser::Kleene_star__expression_1Context * /*ctx*/) override { }

  virtual void enterExpression(PnfCParser::ExpressionContext * /*ctx*/) override { }
  virtual void exitExpression(PnfCParser::ExpressionContext * /*ctx*/) override { }

  virtual void enterAux_rule__genericAssocList_2(PnfCParser::Aux_rule__genericAssocList_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__genericAssocList_2(PnfCParser::Aux_rule__genericAssocList_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__genericAssocList_1(PnfCParser::Kleene_star__genericAssocList_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__genericAssocList_1(PnfCParser::Kleene_star__genericAssocList_1Context * /*ctx*/) override { }

  virtual void enterGenericAssocList(PnfCParser::GenericAssocListContext * /*ctx*/) override { }
  virtual void exitGenericAssocList(PnfCParser::GenericAssocListContext * /*ctx*/) override { }

  virtual void enterAux_rule__postfixExpression_3(PnfCParser::Aux_rule__postfixExpression_3Context * /*ctx*/) override { }
  virtual void exitAux_rule__postfixExpression_3(PnfCParser::Aux_rule__postfixExpression_3Context * /*ctx*/) override { }

  virtual void enterKleene_star__postfixExpression_2(PnfCParser::Kleene_star__postfixExpression_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__postfixExpression_2(PnfCParser::Kleene_star__postfixExpression_2Context * /*ctx*/) override { }

  virtual void enterPostfixExpression(PnfCParser::PostfixExpressionContext * /*ctx*/) override { }
  virtual void exitPostfixExpression(PnfCParser::PostfixExpressionContext * /*ctx*/) override { }

  virtual void enterAux_rule__initializerList_4(PnfCParser::Aux_rule__initializerList_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__initializerList_4(PnfCParser::Aux_rule__initializerList_4Context * /*ctx*/) override { }

  virtual void enterKleene_star__initializerList_3(PnfCParser::Kleene_star__initializerList_3Context * /*ctx*/) override { }
  virtual void exitKleene_star__initializerList_3(PnfCParser::Kleene_star__initializerList_3Context * /*ctx*/) override { }

  virtual void enterInitializerList(PnfCParser::InitializerListContext * /*ctx*/) override { }
  virtual void exitInitializerList(PnfCParser::InitializerListContext * /*ctx*/) override { }

  virtual void enterAux_rule__multiplicativeExpression_2(PnfCParser::Aux_rule__multiplicativeExpression_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__multiplicativeExpression_2(PnfCParser::Aux_rule__multiplicativeExpression_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__multiplicativeExpression_1(PnfCParser::Kleene_star__multiplicativeExpression_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__multiplicativeExpression_1(PnfCParser::Kleene_star__multiplicativeExpression_1Context * /*ctx*/) override { }

  virtual void enterMultiplicativeExpression(PnfCParser::MultiplicativeExpressionContext * /*ctx*/) override { }
  virtual void exitMultiplicativeExpression(PnfCParser::MultiplicativeExpressionContext * /*ctx*/) override { }

  virtual void enterAux_rule__additiveExpression_2(PnfCParser::Aux_rule__additiveExpression_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__additiveExpression_2(PnfCParser::Aux_rule__additiveExpression_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__additiveExpression_1(PnfCParser::Kleene_star__additiveExpression_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__additiveExpression_1(PnfCParser::Kleene_star__additiveExpression_1Context * /*ctx*/) override { }

  virtual void enterAdditiveExpression(PnfCParser::AdditiveExpressionContext * /*ctx*/) override { }
  virtual void exitAdditiveExpression(PnfCParser::AdditiveExpressionContext * /*ctx*/) override { }

  virtual void enterAux_rule__shiftExpression_2(PnfCParser::Aux_rule__shiftExpression_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__shiftExpression_2(PnfCParser::Aux_rule__shiftExpression_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__shiftExpression_1(PnfCParser::Kleene_star__shiftExpression_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__shiftExpression_1(PnfCParser::Kleene_star__shiftExpression_1Context * /*ctx*/) override { }

  virtual void enterShiftExpression(PnfCParser::ShiftExpressionContext * /*ctx*/) override { }
  virtual void exitShiftExpression(PnfCParser::ShiftExpressionContext * /*ctx*/) override { }

  virtual void enterAux_rule__relationalExpression_2(PnfCParser::Aux_rule__relationalExpression_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__relationalExpression_2(PnfCParser::Aux_rule__relationalExpression_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__relationalExpression_1(PnfCParser::Kleene_star__relationalExpression_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__relationalExpression_1(PnfCParser::Kleene_star__relationalExpression_1Context * /*ctx*/) override { }

  virtual void enterRelationalExpression(PnfCParser::RelationalExpressionContext * /*ctx*/) override { }
  virtual void exitRelationalExpression(PnfCParser::RelationalExpressionContext * /*ctx*/) override { }

  virtual void enterAux_rule__equalityExpression_2(PnfCParser::Aux_rule__equalityExpression_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__equalityExpression_2(PnfCParser::Aux_rule__equalityExpression_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__equalityExpression_1(PnfCParser::Kleene_star__equalityExpression_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__equalityExpression_1(PnfCParser::Kleene_star__equalityExpression_1Context * /*ctx*/) override { }

  virtual void enterEqualityExpression(PnfCParser::EqualityExpressionContext * /*ctx*/) override { }
  virtual void exitEqualityExpression(PnfCParser::EqualityExpressionContext * /*ctx*/) override { }

  virtual void enterAux_rule__andExpression_2(PnfCParser::Aux_rule__andExpression_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__andExpression_2(PnfCParser::Aux_rule__andExpression_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__andExpression_1(PnfCParser::Kleene_star__andExpression_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__andExpression_1(PnfCParser::Kleene_star__andExpression_1Context * /*ctx*/) override { }

  virtual void enterAndExpression(PnfCParser::AndExpressionContext * /*ctx*/) override { }
  virtual void exitAndExpression(PnfCParser::AndExpressionContext * /*ctx*/) override { }

  virtual void enterAux_rule__exclusiveOrExpression_2(PnfCParser::Aux_rule__exclusiveOrExpression_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__exclusiveOrExpression_2(PnfCParser::Aux_rule__exclusiveOrExpression_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__exclusiveOrExpression_1(PnfCParser::Kleene_star__exclusiveOrExpression_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__exclusiveOrExpression_1(PnfCParser::Kleene_star__exclusiveOrExpression_1Context * /*ctx*/) override { }

  virtual void enterExclusiveOrExpression(PnfCParser::ExclusiveOrExpressionContext * /*ctx*/) override { }
  virtual void exitExclusiveOrExpression(PnfCParser::ExclusiveOrExpressionContext * /*ctx*/) override { }

  virtual void enterAux_rule__inclusiveOrExpression_2(PnfCParser::Aux_rule__inclusiveOrExpression_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__inclusiveOrExpression_2(PnfCParser::Aux_rule__inclusiveOrExpression_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__inclusiveOrExpression_1(PnfCParser::Kleene_star__inclusiveOrExpression_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__inclusiveOrExpression_1(PnfCParser::Kleene_star__inclusiveOrExpression_1Context * /*ctx*/) override { }

  virtual void enterInclusiveOrExpression(PnfCParser::InclusiveOrExpressionContext * /*ctx*/) override { }
  virtual void exitInclusiveOrExpression(PnfCParser::InclusiveOrExpressionContext * /*ctx*/) override { }

  virtual void enterAux_rule__logicalAndExpression_2(PnfCParser::Aux_rule__logicalAndExpression_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__logicalAndExpression_2(PnfCParser::Aux_rule__logicalAndExpression_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__logicalAndExpression_1(PnfCParser::Kleene_star__logicalAndExpression_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__logicalAndExpression_1(PnfCParser::Kleene_star__logicalAndExpression_1Context * /*ctx*/) override { }

  virtual void enterLogicalAndExpression(PnfCParser::LogicalAndExpressionContext * /*ctx*/) override { }
  virtual void exitLogicalAndExpression(PnfCParser::LogicalAndExpressionContext * /*ctx*/) override { }

  virtual void enterAux_rule__logicalOrExpression_2(PnfCParser::Aux_rule__logicalOrExpression_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__logicalOrExpression_2(PnfCParser::Aux_rule__logicalOrExpression_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__logicalOrExpression_1(PnfCParser::Kleene_star__logicalOrExpression_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__logicalOrExpression_1(PnfCParser::Kleene_star__logicalOrExpression_1Context * /*ctx*/) override { }

  virtual void enterLogicalOrExpression(PnfCParser::LogicalOrExpressionContext * /*ctx*/) override { }
  virtual void exitLogicalOrExpression(PnfCParser::LogicalOrExpressionContext * /*ctx*/) override { }

  virtual void enterAux_rule__initDeclaratorList_2(PnfCParser::Aux_rule__initDeclaratorList_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__initDeclaratorList_2(PnfCParser::Aux_rule__initDeclaratorList_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__initDeclaratorList_1(PnfCParser::Kleene_star__initDeclaratorList_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__initDeclaratorList_1(PnfCParser::Kleene_star__initDeclaratorList_1Context * /*ctx*/) override { }

  virtual void enterInitDeclaratorList(PnfCParser::InitDeclaratorListContext * /*ctx*/) override { }
  virtual void exitInitDeclaratorList(PnfCParser::InitDeclaratorListContext * /*ctx*/) override { }

  virtual void enterStructDeclarationList(PnfCParser::StructDeclarationListContext * /*ctx*/) override { }
  virtual void exitStructDeclarationList(PnfCParser::StructDeclarationListContext * /*ctx*/) override { }

  virtual void enterAux_rule__structDeclaratorList_2(PnfCParser::Aux_rule__structDeclaratorList_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__structDeclaratorList_2(PnfCParser::Aux_rule__structDeclaratorList_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__structDeclaratorList_1(PnfCParser::Kleene_star__structDeclaratorList_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__structDeclaratorList_1(PnfCParser::Kleene_star__structDeclaratorList_1Context * /*ctx*/) override { }

  virtual void enterStructDeclaratorList(PnfCParser::StructDeclaratorListContext * /*ctx*/) override { }
  virtual void exitStructDeclaratorList(PnfCParser::StructDeclaratorListContext * /*ctx*/) override { }

  virtual void enterAux_rule__enumeratorList_2(PnfCParser::Aux_rule__enumeratorList_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__enumeratorList_2(PnfCParser::Aux_rule__enumeratorList_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__enumeratorList_1(PnfCParser::Kleene_star__enumeratorList_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__enumeratorList_1(PnfCParser::Kleene_star__enumeratorList_1Context * /*ctx*/) override { }

  virtual void enterEnumeratorList(PnfCParser::EnumeratorListContext * /*ctx*/) override { }
  virtual void exitEnumeratorList(PnfCParser::EnumeratorListContext * /*ctx*/) override { }

  virtual void enterAux_rule__directDeclarator_7(PnfCParser::Aux_rule__directDeclarator_7Context * /*ctx*/) override { }
  virtual void exitAux_rule__directDeclarator_7(PnfCParser::Aux_rule__directDeclarator_7Context * /*ctx*/) override { }

  virtual void enterKleene_star__directDeclarator_6(PnfCParser::Kleene_star__directDeclarator_6Context * /*ctx*/) override { }
  virtual void exitKleene_star__directDeclarator_6(PnfCParser::Kleene_star__directDeclarator_6Context * /*ctx*/) override { }

  virtual void enterAux_rule__directDeclarator_8(PnfCParser::Aux_rule__directDeclarator_8Context * /*ctx*/) override { }
  virtual void exitAux_rule__directDeclarator_8(PnfCParser::Aux_rule__directDeclarator_8Context * /*ctx*/) override { }

  virtual void enterDirectDeclarator(PnfCParser::DirectDeclaratorContext * /*ctx*/) override { }
  virtual void exitDirectDeclarator(PnfCParser::DirectDeclaratorContext * /*ctx*/) override { }

  virtual void enterAux_rule__typeQualifierList_2(PnfCParser::Aux_rule__typeQualifierList_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__typeQualifierList_2(PnfCParser::Aux_rule__typeQualifierList_2Context * /*ctx*/) override { }

  virtual void enterTypeQualifierList(PnfCParser::TypeQualifierListContext * /*ctx*/) override { }
  virtual void exitTypeQualifierList(PnfCParser::TypeQualifierListContext * /*ctx*/) override { }

  virtual void enterAux_rule__identifierList_2(PnfCParser::Aux_rule__identifierList_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__identifierList_2(PnfCParser::Aux_rule__identifierList_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__identifierList_1(PnfCParser::Kleene_star__identifierList_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__identifierList_1(PnfCParser::Kleene_star__identifierList_1Context * /*ctx*/) override { }

  virtual void enterIdentifierList(PnfCParser::IdentifierListContext * /*ctx*/) override { }
  virtual void exitIdentifierList(PnfCParser::IdentifierListContext * /*ctx*/) override { }

  virtual void enterAux_rule__parameterList_2(PnfCParser::Aux_rule__parameterList_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__parameterList_2(PnfCParser::Aux_rule__parameterList_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__parameterList_1(PnfCParser::Kleene_star__parameterList_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__parameterList_1(PnfCParser::Kleene_star__parameterList_1Context * /*ctx*/) override { }

  virtual void enterParameterList(PnfCParser::ParameterListContext * /*ctx*/) override { }
  virtual void exitParameterList(PnfCParser::ParameterListContext * /*ctx*/) override { }

  virtual void enterAux_rule__directAbstractDeclarator_13(PnfCParser::Aux_rule__directAbstractDeclarator_13Context * /*ctx*/) override { }
  virtual void exitAux_rule__directAbstractDeclarator_13(PnfCParser::Aux_rule__directAbstractDeclarator_13Context * /*ctx*/) override { }

  virtual void enterKleene_star__directAbstractDeclarator_12(PnfCParser::Kleene_star__directAbstractDeclarator_12Context * /*ctx*/) override { }
  virtual void exitKleene_star__directAbstractDeclarator_12(PnfCParser::Kleene_star__directAbstractDeclarator_12Context * /*ctx*/) override { }

  virtual void enterAux_rule__directAbstractDeclarator_14(PnfCParser::Aux_rule__directAbstractDeclarator_14Context * /*ctx*/) override { }
  virtual void exitAux_rule__directAbstractDeclarator_14(PnfCParser::Aux_rule__directAbstractDeclarator_14Context * /*ctx*/) override { }

  virtual void enterDirectAbstractDeclarator(PnfCParser::DirectAbstractDeclaratorContext * /*ctx*/) override { }
  virtual void exitDirectAbstractDeclarator(PnfCParser::DirectAbstractDeclaratorContext * /*ctx*/) override { }

  virtual void enterDesignatorList(PnfCParser::DesignatorListContext * /*ctx*/) override { }
  virtual void exitDesignatorList(PnfCParser::DesignatorListContext * /*ctx*/) override { }

  virtual void enterBlockItemList(PnfCParser::BlockItemListContext * /*ctx*/) override { }
  virtual void exitBlockItemList(PnfCParser::BlockItemListContext * /*ctx*/) override { }

  virtual void enterTranslationUnit(PnfCParser::TranslationUnitContext * /*ctx*/) override { }
  virtual void exitTranslationUnit(PnfCParser::TranslationUnitContext * /*ctx*/) override { }

  virtual void enterAux_rule__declarationList_2(PnfCParser::Aux_rule__declarationList_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__declarationList_2(PnfCParser::Aux_rule__declarationList_2Context * /*ctx*/) override { }

  virtual void enterDeclarationList(PnfCParser::DeclarationListContext * /*ctx*/) override { }
  virtual void exitDeclarationList(PnfCParser::DeclarationListContext * /*ctx*/) override { }

  virtual void enterKleene_plus__structDeclarationList_3(PnfCParser::Kleene_plus__structDeclarationList_3Context * /*ctx*/) override { }
  virtual void exitKleene_plus__structDeclarationList_3(PnfCParser::Kleene_plus__structDeclarationList_3Context * /*ctx*/) override { }

  virtual void enterKleene_plus__typeQualifierList_3(PnfCParser::Kleene_plus__typeQualifierList_3Context * /*ctx*/) override { }
  virtual void exitKleene_plus__typeQualifierList_3(PnfCParser::Kleene_plus__typeQualifierList_3Context * /*ctx*/) override { }

  virtual void enterKleene_plus__designatorList_3(PnfCParser::Kleene_plus__designatorList_3Context * /*ctx*/) override { }
  virtual void exitKleene_plus__designatorList_3(PnfCParser::Kleene_plus__designatorList_3Context * /*ctx*/) override { }

  virtual void enterKleene_plus__blockItemList_3(PnfCParser::Kleene_plus__blockItemList_3Context * /*ctx*/) override { }
  virtual void exitKleene_plus__blockItemList_3(PnfCParser::Kleene_plus__blockItemList_3Context * /*ctx*/) override { }

  virtual void enterKleene_plus__translationUnit_3(PnfCParser::Kleene_plus__translationUnit_3Context * /*ctx*/) override { }
  virtual void exitKleene_plus__translationUnit_3(PnfCParser::Kleene_plus__translationUnit_3Context * /*ctx*/) override { }

  virtual void enterKleene_plus__declarationList_3(PnfCParser::Kleene_plus__declarationList_3Context * /*ctx*/) override { }
  virtual void exitKleene_plus__declarationList_3(PnfCParser::Kleene_plus__declarationList_3Context * /*ctx*/) override { }

  virtual void enterOptional__postfixExpression_5(PnfCParser::Optional__postfixExpression_5Context * /*ctx*/) override { }
  virtual void exitOptional__postfixExpression_5(PnfCParser::Optional__postfixExpression_5Context * /*ctx*/) override { }

  virtual void enterAux_rule__initDeclarator_1(PnfCParser::Aux_rule__initDeclarator_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__initDeclarator_1(PnfCParser::Aux_rule__initDeclarator_1Context * /*ctx*/) override { }

  virtual void enterOptional__initDeclarator_2(PnfCParser::Optional__initDeclarator_2Context * /*ctx*/) override { }
  virtual void exitOptional__initDeclarator_2(PnfCParser::Optional__initDeclarator_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__enumerator_1(PnfCParser::Aux_rule__enumerator_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__enumerator_1(PnfCParser::Aux_rule__enumerator_1Context * /*ctx*/) override { }

  virtual void enterOptional__enumerator_2(PnfCParser::Optional__enumerator_2Context * /*ctx*/) override { }
  virtual void exitOptional__enumerator_2(PnfCParser::Optional__enumerator_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__parameterTypeList_1(PnfCParser::Aux_rule__parameterTypeList_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__parameterTypeList_1(PnfCParser::Aux_rule__parameterTypeList_1Context * /*ctx*/) override { }

  virtual void enterOptional__parameterTypeList_2(PnfCParser::Optional__parameterTypeList_2Context * /*ctx*/) override { }
  virtual void exitOptional__parameterTypeList_2(PnfCParser::Optional__parameterTypeList_2Context * /*ctx*/) override { }

  virtual void enterAltnt_block__primaryExpression_3(PnfCParser::Altnt_block__primaryExpression_3Context * /*ctx*/) override { }
  virtual void exitAltnt_block__primaryExpression_3(PnfCParser::Altnt_block__primaryExpression_3Context * /*ctx*/) override { }

  virtual void enterAltnt_block__unaryExpression_1(PnfCParser::Altnt_block__unaryExpression_1Context * /*ctx*/) override { }
  virtual void exitAltnt_block__unaryExpression_1(PnfCParser::Altnt_block__unaryExpression_1Context * /*ctx*/) override { }

  virtual void enterAltnt_block__unaryExpression_2(PnfCParser::Altnt_block__unaryExpression_2Context * /*ctx*/) override { }
  virtual void exitAltnt_block__unaryExpression_2(PnfCParser::Altnt_block__unaryExpression_2Context * /*ctx*/) override { }

  virtual void enterAltnt_block__genericAssociation_1(PnfCParser::Altnt_block__genericAssociation_1Context * /*ctx*/) override { }
  virtual void exitAltnt_block__genericAssociation_1(PnfCParser::Altnt_block__genericAssociation_1Context * /*ctx*/) override { }

  virtual void enterAltnt_block__postfixExpression_7(PnfCParser::Altnt_block__postfixExpression_7Context * /*ctx*/) override { }
  virtual void exitAltnt_block__postfixExpression_7(PnfCParser::Altnt_block__postfixExpression_7Context * /*ctx*/) override { }

  virtual void enterAltnt_block__postfixExpression_8(PnfCParser::Altnt_block__postfixExpression_8Context * /*ctx*/) override { }
  virtual void exitAltnt_block__postfixExpression_8(PnfCParser::Altnt_block__postfixExpression_8Context * /*ctx*/) override { }

  virtual void enterAltnt_block__multiplicativeExpression_3(PnfCParser::Altnt_block__multiplicativeExpression_3Context * /*ctx*/) override { }
  virtual void exitAltnt_block__multiplicativeExpression_3(PnfCParser::Altnt_block__multiplicativeExpression_3Context * /*ctx*/) override { }

  virtual void enterAltnt_block__additiveExpression_3(PnfCParser::Altnt_block__additiveExpression_3Context * /*ctx*/) override { }
  virtual void exitAltnt_block__additiveExpression_3(PnfCParser::Altnt_block__additiveExpression_3Context * /*ctx*/) override { }

  virtual void enterAltnt_block__shiftExpression_3(PnfCParser::Altnt_block__shiftExpression_3Context * /*ctx*/) override { }
  virtual void exitAltnt_block__shiftExpression_3(PnfCParser::Altnt_block__shiftExpression_3Context * /*ctx*/) override { }

  virtual void enterAltnt_block__relationalExpression_3(PnfCParser::Altnt_block__relationalExpression_3Context * /*ctx*/) override { }
  virtual void exitAltnt_block__relationalExpression_3(PnfCParser::Altnt_block__relationalExpression_3Context * /*ctx*/) override { }

  virtual void enterAltnt_block__equalityExpression_3(PnfCParser::Altnt_block__equalityExpression_3Context * /*ctx*/) override { }
  virtual void exitAltnt_block__equalityExpression_3(PnfCParser::Altnt_block__equalityExpression_3Context * /*ctx*/) override { }

  virtual void enterAltnt_block__typeSpecifier_1(PnfCParser::Altnt_block__typeSpecifier_1Context * /*ctx*/) override { }
  virtual void exitAltnt_block__typeSpecifier_1(PnfCParser::Altnt_block__typeSpecifier_1Context * /*ctx*/) override { }

  virtual void enterAltnt_block__alignmentSpecifier_1(PnfCParser::Altnt_block__alignmentSpecifier_1Context * /*ctx*/) override { }
  virtual void exitAltnt_block__alignmentSpecifier_1(PnfCParser::Altnt_block__alignmentSpecifier_1Context * /*ctx*/) override { }

  virtual void enterAltnt_block__structOrUnionSpecifier_2(PnfCParser::Altnt_block__structOrUnionSpecifier_2Context * /*ctx*/) override { }
  virtual void exitAltnt_block__structOrUnionSpecifier_2(PnfCParser::Altnt_block__structOrUnionSpecifier_2Context * /*ctx*/) override { }

  virtual void enterAltnt_block__enumSpecifier_3(PnfCParser::Altnt_block__enumSpecifier_3Context * /*ctx*/) override { }
  virtual void exitAltnt_block__enumSpecifier_3(PnfCParser::Altnt_block__enumSpecifier_3Context * /*ctx*/) override { }

  virtual void enterAltnt_block__pointer_5(PnfCParser::Altnt_block__pointer_5Context * /*ctx*/) override { }
  virtual void exitAltnt_block__pointer_5(PnfCParser::Altnt_block__pointer_5Context * /*ctx*/) override { }

  virtual void enterAltnt_block__directDeclarator_9(PnfCParser::Altnt_block__directDeclarator_9Context * /*ctx*/) override { }
  virtual void exitAltnt_block__directDeclarator_9(PnfCParser::Altnt_block__directDeclarator_9Context * /*ctx*/) override { }

  virtual void enterAltnt_block__directDeclarator_10(PnfCParser::Altnt_block__directDeclarator_10Context * /*ctx*/) override { }
  virtual void exitAltnt_block__directDeclarator_10(PnfCParser::Altnt_block__directDeclarator_10Context * /*ctx*/) override { }

  virtual void enterAltnt_block__directAbstractDeclarator_15(PnfCParser::Altnt_block__directAbstractDeclarator_15Context * /*ctx*/) override { }
  virtual void exitAltnt_block__directAbstractDeclarator_15(PnfCParser::Altnt_block__directAbstractDeclarator_15Context * /*ctx*/) override { }

  virtual void enterAltnt_block__directAbstractDeclarator_17(PnfCParser::Altnt_block__directAbstractDeclarator_17Context * /*ctx*/) override { }
  virtual void exitAltnt_block__directAbstractDeclarator_17(PnfCParser::Altnt_block__directAbstractDeclarator_17Context * /*ctx*/) override { }

  virtual void enterAltnt_block__labeledStatement_1(PnfCParser::Altnt_block__labeledStatement_1Context * /*ctx*/) override { }
  virtual void exitAltnt_block__labeledStatement_1(PnfCParser::Altnt_block__labeledStatement_1Context * /*ctx*/) override { }

  virtual void enterAltnt_block__jumpStatement_2(PnfCParser::Altnt_block__jumpStatement_2Context * /*ctx*/) override { }
  virtual void exitAltnt_block__jumpStatement_2(PnfCParser::Altnt_block__jumpStatement_2Context * /*ctx*/) override { }

  virtual void enterAltnt_block__enumSpecifier_4(PnfCParser::Altnt_block__enumSpecifier_4Context * /*ctx*/) override { }
  virtual void exitAltnt_block__enumSpecifier_4(PnfCParser::Altnt_block__enumSpecifier_4Context * /*ctx*/) override { }

  virtual void enterAltnt_block__directDeclarator_11(PnfCParser::Altnt_block__directDeclarator_11Context * /*ctx*/) override { }
  virtual void exitAltnt_block__directDeclarator_11(PnfCParser::Altnt_block__directDeclarator_11Context * /*ctx*/) override { }

  virtual void enterAltnt_block__iterationStatement_7(PnfCParser::Altnt_block__iterationStatement_7Context * /*ctx*/) override { }
  virtual void exitAltnt_block__iterationStatement_7(PnfCParser::Altnt_block__iterationStatement_7Context * /*ctx*/) override { }

  virtual void enterAltnt_block__jumpStatement_3(PnfCParser::Altnt_block__jumpStatement_3Context * /*ctx*/) override { }
  virtual void exitAltnt_block__jumpStatement_3(PnfCParser::Altnt_block__jumpStatement_3Context * /*ctx*/) override { }

  virtual void enterAux_rule__postfixExpression_4(PnfCParser::Aux_rule__postfixExpression_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__postfixExpression_4(PnfCParser::Aux_rule__postfixExpression_4Context * /*ctx*/) override { }

  virtual void enterDeclarationSpecifier(PnfCParser::DeclarationSpecifierContext * /*ctx*/) override { }
  virtual void exitDeclarationSpecifier(PnfCParser::DeclarationSpecifierContext * /*ctx*/) override { }

  virtual void enterAux_rule__structDeclarationList_2(PnfCParser::Aux_rule__structDeclarationList_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__structDeclarationList_2(PnfCParser::Aux_rule__structDeclarationList_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__designatorList_2(PnfCParser::Aux_rule__designatorList_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__designatorList_2(PnfCParser::Aux_rule__designatorList_2Context * /*ctx*/) override { }

  virtual void enterStatement(PnfCParser::StatementContext * /*ctx*/) override { }
  virtual void exitStatement(PnfCParser::StatementContext * /*ctx*/) override { }

  virtual void enterAux_rule__blockItemList_2(PnfCParser::Aux_rule__blockItemList_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__blockItemList_2(PnfCParser::Aux_rule__blockItemList_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__translationUnit_2(PnfCParser::Aux_rule__translationUnit_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__translationUnit_2(PnfCParser::Aux_rule__translationUnit_2Context * /*ctx*/) override { }

  virtual void enterAltnt_block__unaryExpression_3(PnfCParser::Altnt_block__unaryExpression_3Context * /*ctx*/) override { }
  virtual void exitAltnt_block__unaryExpression_3(PnfCParser::Altnt_block__unaryExpression_3Context * /*ctx*/) override { }

  virtual void enterAltnt_block__unaryExpression_4(PnfCParser::Altnt_block__unaryExpression_4Context * /*ctx*/) override { }
  virtual void exitAltnt_block__unaryExpression_4(PnfCParser::Altnt_block__unaryExpression_4Context * /*ctx*/) override { }

  virtual void enterAltnt_block__typeSpecifier_2(PnfCParser::Altnt_block__typeSpecifier_2Context * /*ctx*/) override { }
  virtual void exitAltnt_block__typeSpecifier_2(PnfCParser::Altnt_block__typeSpecifier_2Context * /*ctx*/) override { }

  virtual void enterAltnt_block__specifierQualifierList_3(PnfCParser::Altnt_block__specifierQualifierList_3Context * /*ctx*/) override { }
  virtual void exitAltnt_block__specifierQualifierList_3(PnfCParser::Altnt_block__specifierQualifierList_3Context * /*ctx*/) override { }

  virtual void enterAltnt_block__pointer_8(PnfCParser::Altnt_block__pointer_8Context * /*ctx*/) override { }
  virtual void exitAltnt_block__pointer_8(PnfCParser::Altnt_block__pointer_8Context * /*ctx*/) override { }

  virtual void enterAltnt_block__directDeclarator_12(PnfCParser::Altnt_block__directDeclarator_12Context * /*ctx*/) override { }
  virtual void exitAltnt_block__directDeclarator_12(PnfCParser::Altnt_block__directDeclarator_12Context * /*ctx*/) override { }

  virtual void enterAltnt_block__parameterDeclaration_2(PnfCParser::Altnt_block__parameterDeclaration_2Context * /*ctx*/) override { }
  virtual void exitAltnt_block__parameterDeclaration_2(PnfCParser::Altnt_block__parameterDeclaration_2Context * /*ctx*/) override { }

  virtual void enterAltnt_block__directAbstractDeclarator_20(PnfCParser::Altnt_block__directAbstractDeclarator_20Context * /*ctx*/) override { }
  virtual void exitAltnt_block__directAbstractDeclarator_20(PnfCParser::Altnt_block__directAbstractDeclarator_20Context * /*ctx*/) override { }

  virtual void enterAltnt_block__iterationStatement_8(PnfCParser::Altnt_block__iterationStatement_8Context * /*ctx*/) override { }
  virtual void exitAltnt_block__iterationStatement_8(PnfCParser::Altnt_block__iterationStatement_8Context * /*ctx*/) override { }

  virtual void enterAltnt_block__statement_1(PnfCParser::Altnt_block__statement_1Context * /*ctx*/) override { }
  virtual void exitAltnt_block__statement_1(PnfCParser::Altnt_block__statement_1Context * /*ctx*/) override { }

  virtual void enterAltnt_block__statement_2(PnfCParser::Altnt_block__statement_2Context * /*ctx*/) override { }
  virtual void exitAltnt_block__statement_2(PnfCParser::Altnt_block__statement_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__unaryExpression_5(PnfCParser::Aux_rule__unaryExpression_5Context * /*ctx*/) override { }
  virtual void exitAux_rule__unaryExpression_5(PnfCParser::Aux_rule__unaryExpression_5Context * /*ctx*/) override { }

  virtual void enterAux_rule__unaryExpression_6(PnfCParser::Aux_rule__unaryExpression_6Context * /*ctx*/) override { }
  virtual void exitAux_rule__unaryExpression_6(PnfCParser::Aux_rule__unaryExpression_6Context * /*ctx*/) override { }

  virtual void enterAux_rule__unaryExpression_7(PnfCParser::Aux_rule__unaryExpression_7Context * /*ctx*/) override { }
  virtual void exitAux_rule__unaryExpression_7(PnfCParser::Aux_rule__unaryExpression_7Context * /*ctx*/) override { }

  virtual void enterAux_rule__unaryExpression_8(PnfCParser::Aux_rule__unaryExpression_8Context * /*ctx*/) override { }
  virtual void exitAux_rule__unaryExpression_8(PnfCParser::Aux_rule__unaryExpression_8Context * /*ctx*/) override { }

  virtual void enterAux_rule__castExpression_2(PnfCParser::Aux_rule__castExpression_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__castExpression_2(PnfCParser::Aux_rule__castExpression_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__assignmentExpression_1(PnfCParser::Aux_rule__assignmentExpression_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__assignmentExpression_1(PnfCParser::Aux_rule__assignmentExpression_1Context * /*ctx*/) override { }

  virtual void enterAux_rule__declaration_3(PnfCParser::Aux_rule__declaration_3Context * /*ctx*/) override { }
  virtual void exitAux_rule__declaration_3(PnfCParser::Aux_rule__declaration_3Context * /*ctx*/) override { }

  virtual void enterAux_rule__typeSpecifier_3(PnfCParser::Aux_rule__typeSpecifier_3Context * /*ctx*/) override { }
  virtual void exitAux_rule__typeSpecifier_3(PnfCParser::Aux_rule__typeSpecifier_3Context * /*ctx*/) override { }

  virtual void enterAux_rule__structDeclarator_2(PnfCParser::Aux_rule__structDeclarator_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__structDeclarator_2(PnfCParser::Aux_rule__structDeclarator_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__gccDeclaratorExtension_2(PnfCParser::Aux_rule__gccDeclaratorExtension_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__gccDeclaratorExtension_2(PnfCParser::Aux_rule__gccDeclaratorExtension_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__abstractDeclarator_3(PnfCParser::Aux_rule__abstractDeclarator_3Context * /*ctx*/) override { }
  virtual void exitAux_rule__abstractDeclarator_3(PnfCParser::Aux_rule__abstractDeclarator_3Context * /*ctx*/) override { }

  virtual void enterAux_rule__initializer_2(PnfCParser::Aux_rule__initializer_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__initializer_2(PnfCParser::Aux_rule__initializer_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__postfixExpression_10(PnfCParser::Aux_rule__postfixExpression_10Context * /*ctx*/) override { }
  virtual void exitAux_rule__postfixExpression_10(PnfCParser::Aux_rule__postfixExpression_10Context * /*ctx*/) override { }

  virtual void enterAux_rule__postfixExpression_11(PnfCParser::Aux_rule__postfixExpression_11Context * /*ctx*/) override { }
  virtual void exitAux_rule__postfixExpression_11(PnfCParser::Aux_rule__postfixExpression_11Context * /*ctx*/) override { }

  virtual void enterAux_rule__postfixExpression_12(PnfCParser::Aux_rule__postfixExpression_12Context * /*ctx*/) override { }
  virtual void exitAux_rule__postfixExpression_12(PnfCParser::Aux_rule__postfixExpression_12Context * /*ctx*/) override { }

  virtual void enterAux_rule__directDeclarator_13(PnfCParser::Aux_rule__directDeclarator_13Context * /*ctx*/) override { }
  virtual void exitAux_rule__directDeclarator_13(PnfCParser::Aux_rule__directDeclarator_13Context * /*ctx*/) override { }

  virtual void enterAux_rule__directDeclarator_14(PnfCParser::Aux_rule__directDeclarator_14Context * /*ctx*/) override { }
  virtual void exitAux_rule__directDeclarator_14(PnfCParser::Aux_rule__directDeclarator_14Context * /*ctx*/) override { }

  virtual void enterAux_rule__directDeclarator_15(PnfCParser::Aux_rule__directDeclarator_15Context * /*ctx*/) override { }
  virtual void exitAux_rule__directDeclarator_15(PnfCParser::Aux_rule__directDeclarator_15Context * /*ctx*/) override { }

  virtual void enterAux_rule__directAbstractDeclarator_21(PnfCParser::Aux_rule__directAbstractDeclarator_21Context * /*ctx*/) override { }
  virtual void exitAux_rule__directAbstractDeclarator_21(PnfCParser::Aux_rule__directAbstractDeclarator_21Context * /*ctx*/) override { }

  virtual void enterAux_rule__directAbstractDeclarator_22(PnfCParser::Aux_rule__directAbstractDeclarator_22Context * /*ctx*/) override { }
  virtual void exitAux_rule__directAbstractDeclarator_22(PnfCParser::Aux_rule__directAbstractDeclarator_22Context * /*ctx*/) override { }

  virtual void enterAux_rule__directAbstractDeclarator_23(PnfCParser::Aux_rule__directAbstractDeclarator_23Context * /*ctx*/) override { }
  virtual void exitAux_rule__directAbstractDeclarator_23(PnfCParser::Aux_rule__directAbstractDeclarator_23Context * /*ctx*/) override { }

  virtual void enterAux_rule__directAbstractDeclarator_24(PnfCParser::Aux_rule__directAbstractDeclarator_24Context * /*ctx*/) override { }
  virtual void exitAux_rule__directAbstractDeclarator_24(PnfCParser::Aux_rule__directAbstractDeclarator_24Context * /*ctx*/) override { }

  virtual void enterAux_rule__primaryExpression_4(PnfCParser::Aux_rule__primaryExpression_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__primaryExpression_4(PnfCParser::Aux_rule__primaryExpression_4Context * /*ctx*/) override { }

  virtual void enterAux_rule__primaryExpression_5(PnfCParser::Aux_rule__primaryExpression_5Context * /*ctx*/) override { }
  virtual void exitAux_rule__primaryExpression_5(PnfCParser::Aux_rule__primaryExpression_5Context * /*ctx*/) override { }

  virtual void enterAux_rule__primaryExpression_6(PnfCParser::Aux_rule__primaryExpression_6Context * /*ctx*/) override { }
  virtual void exitAux_rule__primaryExpression_6(PnfCParser::Aux_rule__primaryExpression_6Context * /*ctx*/) override { }

  virtual void enterAux_rule__primaryExpression_7(PnfCParser::Aux_rule__primaryExpression_7Context * /*ctx*/) override { }
  virtual void exitAux_rule__primaryExpression_7(PnfCParser::Aux_rule__primaryExpression_7Context * /*ctx*/) override { }

  virtual void enterAux_rule__unaryExpression_9(PnfCParser::Aux_rule__unaryExpression_9Context * /*ctx*/) override { }
  virtual void exitAux_rule__unaryExpression_9(PnfCParser::Aux_rule__unaryExpression_9Context * /*ctx*/) override { }

  virtual void enterAux_rule__unaryExpression_10(PnfCParser::Aux_rule__unaryExpression_10Context * /*ctx*/) override { }
  virtual void exitAux_rule__unaryExpression_10(PnfCParser::Aux_rule__unaryExpression_10Context * /*ctx*/) override { }

  virtual void enterAux_rule__typeSpecifier_4(PnfCParser::Aux_rule__typeSpecifier_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__typeSpecifier_4(PnfCParser::Aux_rule__typeSpecifier_4Context * /*ctx*/) override { }

  virtual void enterAux_rule__typeSpecifier_5(PnfCParser::Aux_rule__typeSpecifier_5Context * /*ctx*/) override { }
  virtual void exitAux_rule__typeSpecifier_5(PnfCParser::Aux_rule__typeSpecifier_5Context * /*ctx*/) override { }

  virtual void enterAux_rule__structOrUnionSpecifier_3(PnfCParser::Aux_rule__structOrUnionSpecifier_3Context * /*ctx*/) override { }
  virtual void exitAux_rule__structOrUnionSpecifier_3(PnfCParser::Aux_rule__structOrUnionSpecifier_3Context * /*ctx*/) override { }

  virtual void enterAux_rule__enumSpecifier_6(PnfCParser::Aux_rule__enumSpecifier_6Context * /*ctx*/) override { }
  virtual void exitAux_rule__enumSpecifier_6(PnfCParser::Aux_rule__enumSpecifier_6Context * /*ctx*/) override { }

  virtual void enterAux_rule__directDeclarator_16(PnfCParser::Aux_rule__directDeclarator_16Context * /*ctx*/) override { }
  virtual void exitAux_rule__directDeclarator_16(PnfCParser::Aux_rule__directDeclarator_16Context * /*ctx*/) override { }

  virtual void enterAux_rule__directDeclarator_17(PnfCParser::Aux_rule__directDeclarator_17Context * /*ctx*/) override { }
  virtual void exitAux_rule__directDeclarator_17(PnfCParser::Aux_rule__directDeclarator_17Context * /*ctx*/) override { }

  virtual void enterAux_rule__directAbstractDeclarator_25(PnfCParser::Aux_rule__directAbstractDeclarator_25Context * /*ctx*/) override { }
  virtual void exitAux_rule__directAbstractDeclarator_25(PnfCParser::Aux_rule__directAbstractDeclarator_25Context * /*ctx*/) override { }

  virtual void enterAux_rule__directAbstractDeclarator_26(PnfCParser::Aux_rule__directAbstractDeclarator_26Context * /*ctx*/) override { }
  virtual void exitAux_rule__directAbstractDeclarator_26(PnfCParser::Aux_rule__directAbstractDeclarator_26Context * /*ctx*/) override { }

  virtual void enterAux_rule__labeledStatement_2(PnfCParser::Aux_rule__labeledStatement_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__labeledStatement_2(PnfCParser::Aux_rule__labeledStatement_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__jumpStatement_4(PnfCParser::Aux_rule__jumpStatement_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__jumpStatement_4(PnfCParser::Aux_rule__jumpStatement_4Context * /*ctx*/) override { }

  virtual void enterAux_rule__jumpStatement_5(PnfCParser::Aux_rule__jumpStatement_5Context * /*ctx*/) override { }
  virtual void exitAux_rule__jumpStatement_5(PnfCParser::Aux_rule__jumpStatement_5Context * /*ctx*/) override { }

  virtual void enterAux_rule__directDeclarator_18(PnfCParser::Aux_rule__directDeclarator_18Context * /*ctx*/) override { }
  virtual void exitAux_rule__directDeclarator_18(PnfCParser::Aux_rule__directDeclarator_18Context * /*ctx*/) override { }

  virtual void enterAux_rule__directDeclarator_19(PnfCParser::Aux_rule__directDeclarator_19Context * /*ctx*/) override { }
  virtual void exitAux_rule__directDeclarator_19(PnfCParser::Aux_rule__directDeclarator_19Context * /*ctx*/) override { }

  virtual void enterAux_rule__postfixExpression_13(PnfCParser::Aux_rule__postfixExpression_13Context * /*ctx*/) override { }
  virtual void exitAux_rule__postfixExpression_13(PnfCParser::Aux_rule__postfixExpression_13Context * /*ctx*/) override { }

  virtual void enterAux_rule__postfixExpression_14(PnfCParser::Aux_rule__postfixExpression_14Context * /*ctx*/) override { }
  virtual void exitAux_rule__postfixExpression_14(PnfCParser::Aux_rule__postfixExpression_14Context * /*ctx*/) override { }

  virtual void enterAux_rule__declarationSpecifier_1(PnfCParser::Aux_rule__declarationSpecifier_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__declarationSpecifier_1(PnfCParser::Aux_rule__declarationSpecifier_1Context * /*ctx*/) override { }

  virtual void enterAux_rule__structDeclarationList_4(PnfCParser::Aux_rule__structDeclarationList_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__structDeclarationList_4(PnfCParser::Aux_rule__structDeclarationList_4Context * /*ctx*/) override { }

  virtual void enterAux_rule__designatorList_4(PnfCParser::Aux_rule__designatorList_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__designatorList_4(PnfCParser::Aux_rule__designatorList_4Context * /*ctx*/) override { }

  virtual void enterAux_rule__designatorList_5(PnfCParser::Aux_rule__designatorList_5Context * /*ctx*/) override { }
  virtual void exitAux_rule__designatorList_5(PnfCParser::Aux_rule__designatorList_5Context * /*ctx*/) override { }

  virtual void enterAux_rule__statement_3(PnfCParser::Aux_rule__statement_3Context * /*ctx*/) override { }
  virtual void exitAux_rule__statement_3(PnfCParser::Aux_rule__statement_3Context * /*ctx*/) override { }

  virtual void enterAux_rule__statement_4(PnfCParser::Aux_rule__statement_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__statement_4(PnfCParser::Aux_rule__statement_4Context * /*ctx*/) override { }

  virtual void enterAux_rule__statement_5(PnfCParser::Aux_rule__statement_5Context * /*ctx*/) override { }
  virtual void exitAux_rule__statement_5(PnfCParser::Aux_rule__statement_5Context * /*ctx*/) override { }

  virtual void enterAux_rule__iterationStatement_9(PnfCParser::Aux_rule__iterationStatement_9Context * /*ctx*/) override { }
  virtual void exitAux_rule__iterationStatement_9(PnfCParser::Aux_rule__iterationStatement_9Context * /*ctx*/) override { }

  virtual void enterAux_rule__statement_6(PnfCParser::Aux_rule__statement_6Context * /*ctx*/) override { }
  virtual void exitAux_rule__statement_6(PnfCParser::Aux_rule__statement_6Context * /*ctx*/) override { }

  virtual void enterAux_rule__statement_7(PnfCParser::Aux_rule__statement_7Context * /*ctx*/) override { }
  virtual void exitAux_rule__statement_7(PnfCParser::Aux_rule__statement_7Context * /*ctx*/) override { }


  virtual void enterEveryRule(antlr4::ParserRuleContext * /*ctx*/) override { }
  virtual void exitEveryRule(antlr4::ParserRuleContext * /*ctx*/) override { }
  virtual void visitTerminal(antlr4::tree::TerminalNode * /*node*/) override { }
  virtual void visitErrorNode(antlr4::tree::ErrorNode * /*node*/) override { }

};

}  // namespace antlr_C_perses
