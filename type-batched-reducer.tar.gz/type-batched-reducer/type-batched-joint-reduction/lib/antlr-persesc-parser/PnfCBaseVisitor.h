
// Generated from PnfC.g4 by ANTLR 4.7.2

#pragma once


#include "antlr4-runtime.h"
#include "PnfCVisitor.h"


namespace antlr_C_perses {

/**
 * This class provides an empty implementation of PnfCVisitor, which can be
 * extended to create a visitor which only needs to handle a subset of the available methods.
 */
class  PnfCBaseVisitor : public PnfCVisitor {
public:

  virtual antlrcpp::Any visitGenericSelection(PnfCParser::GenericSelectionContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitGenericAssociation(PnfCParser::GenericAssociationContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitUnaryExpression(PnfCParser::UnaryExpressionContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitUnaryOperator(PnfCParser::UnaryOperatorContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitCastExpression(PnfCParser::CastExpressionContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitConditionalExpression(PnfCParser::ConditionalExpressionContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAssignmentExpression(PnfCParser::AssignmentExpressionContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAssignmentOperator(PnfCParser::AssignmentOperatorContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitConstantExpression(PnfCParser::ConstantExpressionContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitDeclaration(PnfCParser::DeclarationContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitDeclarationSpecifiers(PnfCParser::DeclarationSpecifiersContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitInitDeclarator(PnfCParser::InitDeclaratorContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTypeSpecifier(PnfCParser::TypeSpecifierContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitStructOrUnionSpecifier(PnfCParser::StructOrUnionSpecifierContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitStructOrUnion(PnfCParser::StructOrUnionContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitSpecifierQualifierList(PnfCParser::SpecifierQualifierListContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitStructDeclarator(PnfCParser::StructDeclaratorContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitEnumSpecifier(PnfCParser::EnumSpecifierContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitEnumerator(PnfCParser::EnumeratorContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAtomicTypeSpecifier(PnfCParser::AtomicTypeSpecifierContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTypeQualifier(PnfCParser::TypeQualifierContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAlignmentSpecifier(PnfCParser::AlignmentSpecifierContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitDeclarator(PnfCParser::DeclaratorContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitGccDeclaratorExtension(PnfCParser::GccDeclaratorExtensionContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAsmKeyword(PnfCParser::AsmKeywordContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitGccAttributeSpecifier(PnfCParser::GccAttributeSpecifierContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitGccAttributeList(PnfCParser::GccAttributeListContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitGccAttribute(PnfCParser::GccAttributeContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitPointer(PnfCParser::PointerContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitParameterTypeList(PnfCParser::ParameterTypeListContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitParameterDeclaration(PnfCParser::ParameterDeclarationContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTypeName(PnfCParser::TypeNameContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAbstractDeclarator(PnfCParser::AbstractDeclaratorContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTypedefName(PnfCParser::TypedefNameContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitInitializer(PnfCParser::InitializerContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitDesignation(PnfCParser::DesignationContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitStaticAssertDeclaration(PnfCParser::StaticAssertDeclarationContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAsmStatement(PnfCParser::AsmStatementContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitLabeledStatement(PnfCParser::LabeledStatementContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitCompoundStatement(PnfCParser::CompoundStatementContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExpressionStatement(PnfCParser::ExpressionStatementContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitJumpStatement(PnfCParser::JumpStatementContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitCompilationUnit(PnfCParser::CompilationUnitContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitFunctionDefinition(PnfCParser::FunctionDefinitionContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_plus__primaryExpression_1(PnfCParser::Kleene_plus__primaryExpression_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__primaryExpression_2(PnfCParser::Optional__primaryExpression_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__postfixExpression_1(PnfCParser::Optional__postfixExpression_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__conditionalExpression_1(PnfCParser::Aux_rule__conditionalExpression_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__conditionalExpression_2(PnfCParser::Optional__conditionalExpression_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__declaration_1(PnfCParser::Optional__declaration_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__declaration_2(PnfCParser::Optional__declaration_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__structOrUnionSpecifier_1(PnfCParser::Optional__structOrUnionSpecifier_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__structDeclaration_2(PnfCParser::Optional__structDeclaration_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__specifierQualifierList_1(PnfCParser::Optional__specifierQualifierList_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__structDeclarator_1(PnfCParser::Optional__structDeclarator_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__declarator_1(PnfCParser::Optional__declarator_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__declarator_2(PnfCParser::Kleene_star__declarator_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__directDeclarator_2(PnfCParser::Optional__directDeclarator_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__directDeclarator_5(PnfCParser::Optional__directDeclarator_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__gccAttributeList_1(PnfCParser::Aux_rule__gccAttributeList_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__gccAttributeList_2(PnfCParser::Kleene_star__gccAttributeList_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__gccAttributeList_3(PnfCParser::Aux_rule__gccAttributeList_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__gccAttribute_2(PnfCParser::Aux_rule__gccAttribute_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__gccAttribute_3(PnfCParser::Optional__gccAttribute_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__gccAttribute_4(PnfCParser::Aux_rule__gccAttribute_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__pointer_1(PnfCParser::Optional__pointer_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__typeName_1(PnfCParser::Optional__typeName_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__directAbstractDeclarator_5(PnfCParser::Optional__directAbstractDeclarator_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__initializerList_1(PnfCParser::Optional__initializerList_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__asmStatement_1(PnfCParser::Aux_rule__asmStatement_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__asmStatement_2(PnfCParser::Optional__asmStatement_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__asmStatement_3(PnfCParser::Aux_rule__asmStatement_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__asmStatement_4(PnfCParser::Kleene_star__asmStatement_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__asmStatement_5(PnfCParser::Aux_rule__asmStatement_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__asmStatement_6(PnfCParser::Optional__asmStatement_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__asmStatement_11(PnfCParser::Aux_rule__asmStatement_11Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__asmStatement_12(PnfCParser::Kleene_star__asmStatement_12Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__compoundStatement_1(PnfCParser::Optional__compoundStatement_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__selectionStatement_1(PnfCParser::Aux_rule__selectionStatement_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__selectionStatement_2(PnfCParser::Optional__selectionStatement_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__compilationUnit_1(PnfCParser::Optional__compilationUnit_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__functionDefinition_2(PnfCParser::Optional__functionDefinition_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__functionDefinition_3(PnfCParser::Optional__functionDefinition_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__expression_2(PnfCParser::Aux_rule__expression_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__expression_1(PnfCParser::Kleene_star__expression_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExpression(PnfCParser::ExpressionContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__genericAssocList_2(PnfCParser::Aux_rule__genericAssocList_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__genericAssocList_1(PnfCParser::Kleene_star__genericAssocList_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitGenericAssocList(PnfCParser::GenericAssocListContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__postfixExpression_3(PnfCParser::Aux_rule__postfixExpression_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__postfixExpression_2(PnfCParser::Kleene_star__postfixExpression_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitPostfixExpression(PnfCParser::PostfixExpressionContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__initializerList_4(PnfCParser::Aux_rule__initializerList_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__initializerList_3(PnfCParser::Kleene_star__initializerList_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitInitializerList(PnfCParser::InitializerListContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__multiplicativeExpression_2(PnfCParser::Aux_rule__multiplicativeExpression_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__multiplicativeExpression_1(PnfCParser::Kleene_star__multiplicativeExpression_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitMultiplicativeExpression(PnfCParser::MultiplicativeExpressionContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__additiveExpression_2(PnfCParser::Aux_rule__additiveExpression_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__additiveExpression_1(PnfCParser::Kleene_star__additiveExpression_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAdditiveExpression(PnfCParser::AdditiveExpressionContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__shiftExpression_2(PnfCParser::Aux_rule__shiftExpression_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__shiftExpression_1(PnfCParser::Kleene_star__shiftExpression_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitShiftExpression(PnfCParser::ShiftExpressionContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__relationalExpression_2(PnfCParser::Aux_rule__relationalExpression_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__relationalExpression_1(PnfCParser::Kleene_star__relationalExpression_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitRelationalExpression(PnfCParser::RelationalExpressionContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__equalityExpression_2(PnfCParser::Aux_rule__equalityExpression_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__equalityExpression_1(PnfCParser::Kleene_star__equalityExpression_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitEqualityExpression(PnfCParser::EqualityExpressionContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__andExpression_2(PnfCParser::Aux_rule__andExpression_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__andExpression_1(PnfCParser::Kleene_star__andExpression_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAndExpression(PnfCParser::AndExpressionContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__exclusiveOrExpression_2(PnfCParser::Aux_rule__exclusiveOrExpression_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__exclusiveOrExpression_1(PnfCParser::Kleene_star__exclusiveOrExpression_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExclusiveOrExpression(PnfCParser::ExclusiveOrExpressionContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__inclusiveOrExpression_2(PnfCParser::Aux_rule__inclusiveOrExpression_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__inclusiveOrExpression_1(PnfCParser::Kleene_star__inclusiveOrExpression_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitInclusiveOrExpression(PnfCParser::InclusiveOrExpressionContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__logicalAndExpression_2(PnfCParser::Aux_rule__logicalAndExpression_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__logicalAndExpression_1(PnfCParser::Kleene_star__logicalAndExpression_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitLogicalAndExpression(PnfCParser::LogicalAndExpressionContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__logicalOrExpression_2(PnfCParser::Aux_rule__logicalOrExpression_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__logicalOrExpression_1(PnfCParser::Kleene_star__logicalOrExpression_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitLogicalOrExpression(PnfCParser::LogicalOrExpressionContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__initDeclaratorList_2(PnfCParser::Aux_rule__initDeclaratorList_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__initDeclaratorList_1(PnfCParser::Kleene_star__initDeclaratorList_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitInitDeclaratorList(PnfCParser::InitDeclaratorListContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitStructDeclarationList(PnfCParser::StructDeclarationListContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__structDeclaratorList_2(PnfCParser::Aux_rule__structDeclaratorList_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__structDeclaratorList_1(PnfCParser::Kleene_star__structDeclaratorList_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitStructDeclaratorList(PnfCParser::StructDeclaratorListContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__enumeratorList_2(PnfCParser::Aux_rule__enumeratorList_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__enumeratorList_1(PnfCParser::Kleene_star__enumeratorList_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitEnumeratorList(PnfCParser::EnumeratorListContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__directDeclarator_7(PnfCParser::Aux_rule__directDeclarator_7Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__directDeclarator_6(PnfCParser::Kleene_star__directDeclarator_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__directDeclarator_8(PnfCParser::Aux_rule__directDeclarator_8Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitDirectDeclarator(PnfCParser::DirectDeclaratorContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__typeQualifierList_2(PnfCParser::Aux_rule__typeQualifierList_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTypeQualifierList(PnfCParser::TypeQualifierListContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__identifierList_2(PnfCParser::Aux_rule__identifierList_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__identifierList_1(PnfCParser::Kleene_star__identifierList_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitIdentifierList(PnfCParser::IdentifierListContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__parameterList_2(PnfCParser::Aux_rule__parameterList_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__parameterList_1(PnfCParser::Kleene_star__parameterList_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitParameterList(PnfCParser::ParameterListContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__directAbstractDeclarator_13(PnfCParser::Aux_rule__directAbstractDeclarator_13Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__directAbstractDeclarator_12(PnfCParser::Kleene_star__directAbstractDeclarator_12Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__directAbstractDeclarator_14(PnfCParser::Aux_rule__directAbstractDeclarator_14Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitDirectAbstractDeclarator(PnfCParser::DirectAbstractDeclaratorContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitDesignatorList(PnfCParser::DesignatorListContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitBlockItemList(PnfCParser::BlockItemListContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTranslationUnit(PnfCParser::TranslationUnitContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__declarationList_2(PnfCParser::Aux_rule__declarationList_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitDeclarationList(PnfCParser::DeclarationListContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_plus__structDeclarationList_3(PnfCParser::Kleene_plus__structDeclarationList_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_plus__typeQualifierList_3(PnfCParser::Kleene_plus__typeQualifierList_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_plus__designatorList_3(PnfCParser::Kleene_plus__designatorList_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_plus__blockItemList_3(PnfCParser::Kleene_plus__blockItemList_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_plus__translationUnit_3(PnfCParser::Kleene_plus__translationUnit_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_plus__declarationList_3(PnfCParser::Kleene_plus__declarationList_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__postfixExpression_5(PnfCParser::Optional__postfixExpression_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__initDeclarator_1(PnfCParser::Aux_rule__initDeclarator_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__initDeclarator_2(PnfCParser::Optional__initDeclarator_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__enumerator_1(PnfCParser::Aux_rule__enumerator_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__enumerator_2(PnfCParser::Optional__enumerator_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__parameterTypeList_1(PnfCParser::Aux_rule__parameterTypeList_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__parameterTypeList_2(PnfCParser::Optional__parameterTypeList_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__primaryExpression_3(PnfCParser::Altnt_block__primaryExpression_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__unaryExpression_1(PnfCParser::Altnt_block__unaryExpression_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__unaryExpression_2(PnfCParser::Altnt_block__unaryExpression_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__genericAssociation_1(PnfCParser::Altnt_block__genericAssociation_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__postfixExpression_7(PnfCParser::Altnt_block__postfixExpression_7Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__postfixExpression_8(PnfCParser::Altnt_block__postfixExpression_8Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__multiplicativeExpression_3(PnfCParser::Altnt_block__multiplicativeExpression_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__additiveExpression_3(PnfCParser::Altnt_block__additiveExpression_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__shiftExpression_3(PnfCParser::Altnt_block__shiftExpression_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__relationalExpression_3(PnfCParser::Altnt_block__relationalExpression_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__equalityExpression_3(PnfCParser::Altnt_block__equalityExpression_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__typeSpecifier_1(PnfCParser::Altnt_block__typeSpecifier_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__alignmentSpecifier_1(PnfCParser::Altnt_block__alignmentSpecifier_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__structOrUnionSpecifier_2(PnfCParser::Altnt_block__structOrUnionSpecifier_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__enumSpecifier_3(PnfCParser::Altnt_block__enumSpecifier_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__pointer_5(PnfCParser::Altnt_block__pointer_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__directDeclarator_9(PnfCParser::Altnt_block__directDeclarator_9Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__directDeclarator_10(PnfCParser::Altnt_block__directDeclarator_10Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__directAbstractDeclarator_15(PnfCParser::Altnt_block__directAbstractDeclarator_15Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__directAbstractDeclarator_17(PnfCParser::Altnt_block__directAbstractDeclarator_17Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__labeledStatement_1(PnfCParser::Altnt_block__labeledStatement_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__jumpStatement_2(PnfCParser::Altnt_block__jumpStatement_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__enumSpecifier_4(PnfCParser::Altnt_block__enumSpecifier_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__directDeclarator_11(PnfCParser::Altnt_block__directDeclarator_11Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__iterationStatement_7(PnfCParser::Altnt_block__iterationStatement_7Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__jumpStatement_3(PnfCParser::Altnt_block__jumpStatement_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__postfixExpression_4(PnfCParser::Aux_rule__postfixExpression_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitDeclarationSpecifier(PnfCParser::DeclarationSpecifierContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__structDeclarationList_2(PnfCParser::Aux_rule__structDeclarationList_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__designatorList_2(PnfCParser::Aux_rule__designatorList_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitStatement(PnfCParser::StatementContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__blockItemList_2(PnfCParser::Aux_rule__blockItemList_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__translationUnit_2(PnfCParser::Aux_rule__translationUnit_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__unaryExpression_3(PnfCParser::Altnt_block__unaryExpression_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__unaryExpression_4(PnfCParser::Altnt_block__unaryExpression_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__typeSpecifier_2(PnfCParser::Altnt_block__typeSpecifier_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__specifierQualifierList_3(PnfCParser::Altnt_block__specifierQualifierList_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__pointer_8(PnfCParser::Altnt_block__pointer_8Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__directDeclarator_12(PnfCParser::Altnt_block__directDeclarator_12Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__parameterDeclaration_2(PnfCParser::Altnt_block__parameterDeclaration_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__directAbstractDeclarator_20(PnfCParser::Altnt_block__directAbstractDeclarator_20Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__iterationStatement_8(PnfCParser::Altnt_block__iterationStatement_8Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__statement_1(PnfCParser::Altnt_block__statement_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__statement_2(PnfCParser::Altnt_block__statement_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__unaryExpression_5(PnfCParser::Aux_rule__unaryExpression_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__unaryExpression_6(PnfCParser::Aux_rule__unaryExpression_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__unaryExpression_7(PnfCParser::Aux_rule__unaryExpression_7Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__unaryExpression_8(PnfCParser::Aux_rule__unaryExpression_8Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__castExpression_2(PnfCParser::Aux_rule__castExpression_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__assignmentExpression_1(PnfCParser::Aux_rule__assignmentExpression_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__declaration_3(PnfCParser::Aux_rule__declaration_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__typeSpecifier_3(PnfCParser::Aux_rule__typeSpecifier_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__structDeclarator_2(PnfCParser::Aux_rule__structDeclarator_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__gccDeclaratorExtension_2(PnfCParser::Aux_rule__gccDeclaratorExtension_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__abstractDeclarator_3(PnfCParser::Aux_rule__abstractDeclarator_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__initializer_2(PnfCParser::Aux_rule__initializer_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__postfixExpression_10(PnfCParser::Aux_rule__postfixExpression_10Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__postfixExpression_11(PnfCParser::Aux_rule__postfixExpression_11Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__postfixExpression_12(PnfCParser::Aux_rule__postfixExpression_12Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__directDeclarator_13(PnfCParser::Aux_rule__directDeclarator_13Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__directDeclarator_14(PnfCParser::Aux_rule__directDeclarator_14Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__directDeclarator_15(PnfCParser::Aux_rule__directDeclarator_15Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__directAbstractDeclarator_21(PnfCParser::Aux_rule__directAbstractDeclarator_21Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__directAbstractDeclarator_22(PnfCParser::Aux_rule__directAbstractDeclarator_22Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__directAbstractDeclarator_23(PnfCParser::Aux_rule__directAbstractDeclarator_23Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__directAbstractDeclarator_24(PnfCParser::Aux_rule__directAbstractDeclarator_24Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__primaryExpression_4(PnfCParser::Aux_rule__primaryExpression_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__primaryExpression_5(PnfCParser::Aux_rule__primaryExpression_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__primaryExpression_6(PnfCParser::Aux_rule__primaryExpression_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__primaryExpression_7(PnfCParser::Aux_rule__primaryExpression_7Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__unaryExpression_9(PnfCParser::Aux_rule__unaryExpression_9Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__unaryExpression_10(PnfCParser::Aux_rule__unaryExpression_10Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__typeSpecifier_4(PnfCParser::Aux_rule__typeSpecifier_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__typeSpecifier_5(PnfCParser::Aux_rule__typeSpecifier_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__structOrUnionSpecifier_3(PnfCParser::Aux_rule__structOrUnionSpecifier_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__enumSpecifier_6(PnfCParser::Aux_rule__enumSpecifier_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__directDeclarator_16(PnfCParser::Aux_rule__directDeclarator_16Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__directDeclarator_17(PnfCParser::Aux_rule__directDeclarator_17Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__directAbstractDeclarator_25(PnfCParser::Aux_rule__directAbstractDeclarator_25Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__directAbstractDeclarator_26(PnfCParser::Aux_rule__directAbstractDeclarator_26Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__labeledStatement_2(PnfCParser::Aux_rule__labeledStatement_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__jumpStatement_4(PnfCParser::Aux_rule__jumpStatement_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__jumpStatement_5(PnfCParser::Aux_rule__jumpStatement_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__directDeclarator_18(PnfCParser::Aux_rule__directDeclarator_18Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__directDeclarator_19(PnfCParser::Aux_rule__directDeclarator_19Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__postfixExpression_13(PnfCParser::Aux_rule__postfixExpression_13Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__postfixExpression_14(PnfCParser::Aux_rule__postfixExpression_14Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__declarationSpecifier_1(PnfCParser::Aux_rule__declarationSpecifier_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__structDeclarationList_4(PnfCParser::Aux_rule__structDeclarationList_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__designatorList_4(PnfCParser::Aux_rule__designatorList_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__designatorList_5(PnfCParser::Aux_rule__designatorList_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__statement_3(PnfCParser::Aux_rule__statement_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__statement_4(PnfCParser::Aux_rule__statement_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__statement_5(PnfCParser::Aux_rule__statement_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__iterationStatement_9(PnfCParser::Aux_rule__iterationStatement_9Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__statement_6(PnfCParser::Aux_rule__statement_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__statement_7(PnfCParser::Aux_rule__statement_7Context *ctx) override {
    return visitChildren(ctx);
  }


};

}  // namespace antlr_C_perses
