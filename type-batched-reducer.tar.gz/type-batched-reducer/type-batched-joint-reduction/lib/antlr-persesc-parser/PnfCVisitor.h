
// Generated from PnfC.g4 by ANTLR 4.7.2

#pragma once


#include "antlr4-runtime.h"
#include "PnfCParser.h"


namespace antlr_C_perses {

/**
 * This class defines an abstract visitor for a parse tree
 * produced by PnfCParser.
 */
class  PnfCVisitor : public antlr4::tree::AbstractParseTreeVisitor {
public:

  /**
   * Visit parse trees produced by PnfCParser.
   */
    virtual antlrcpp::Any visitGenericSelection(PnfCParser::GenericSelectionContext *context) = 0;

    virtual antlrcpp::Any visitGenericAssociation(PnfCParser::GenericAssociationContext *context) = 0;

    virtual antlrcpp::Any visitUnaryExpression(PnfCParser::UnaryExpressionContext *context) = 0;

    virtual antlrcpp::Any visitUnaryOperator(PnfCParser::UnaryOperatorContext *context) = 0;

    virtual antlrcpp::Any visitCastExpression(PnfCParser::CastExpressionContext *context) = 0;

    virtual antlrcpp::Any visitConditionalExpression(PnfCParser::ConditionalExpressionContext *context) = 0;

    virtual antlrcpp::Any visitAssignmentExpression(PnfCParser::AssignmentExpressionContext *context) = 0;

    virtual antlrcpp::Any visitAssignmentOperator(PnfCParser::AssignmentOperatorContext *context) = 0;

    virtual antlrcpp::Any visitConstantExpression(PnfCParser::ConstantExpressionContext *context) = 0;

    virtual antlrcpp::Any visitDeclaration(PnfCParser::DeclarationContext *context) = 0;

    virtual antlrcpp::Any visitDeclarationSpecifiers(PnfCParser::DeclarationSpecifiersContext *context) = 0;

    virtual antlrcpp::Any visitInitDeclarator(PnfCParser::InitDeclaratorContext *context) = 0;

    virtual antlrcpp::Any visitTypeSpecifier(PnfCParser::TypeSpecifierContext *context) = 0;

    virtual antlrcpp::Any visitStructOrUnionSpecifier(PnfCParser::StructOrUnionSpecifierContext *context) = 0;

    virtual antlrcpp::Any visitStructOrUnion(PnfCParser::StructOrUnionContext *context) = 0;

    virtual antlrcpp::Any visitSpecifierQualifierList(PnfCParser::SpecifierQualifierListContext *context) = 0;

    virtual antlrcpp::Any visitStructDeclarator(PnfCParser::StructDeclaratorContext *context) = 0;

    virtual antlrcpp::Any visitEnumSpecifier(PnfCParser::EnumSpecifierContext *context) = 0;

    virtual antlrcpp::Any visitEnumerator(PnfCParser::EnumeratorContext *context) = 0;

    virtual antlrcpp::Any visitAtomicTypeSpecifier(PnfCParser::AtomicTypeSpecifierContext *context) = 0;

    virtual antlrcpp::Any visitTypeQualifier(PnfCParser::TypeQualifierContext *context) = 0;

    virtual antlrcpp::Any visitAlignmentSpecifier(PnfCParser::AlignmentSpecifierContext *context) = 0;

    virtual antlrcpp::Any visitDeclarator(PnfCParser::DeclaratorContext *context) = 0;

    virtual antlrcpp::Any visitGccDeclaratorExtension(PnfCParser::GccDeclaratorExtensionContext *context) = 0;

    virtual antlrcpp::Any visitAsmKeyword(PnfCParser::AsmKeywordContext *context) = 0;

    virtual antlrcpp::Any visitGccAttributeSpecifier(PnfCParser::GccAttributeSpecifierContext *context) = 0;

    virtual antlrcpp::Any visitGccAttributeList(PnfCParser::GccAttributeListContext *context) = 0;

    virtual antlrcpp::Any visitGccAttribute(PnfCParser::GccAttributeContext *context) = 0;

    virtual antlrcpp::Any visitPointer(PnfCParser::PointerContext *context) = 0;

    virtual antlrcpp::Any visitParameterTypeList(PnfCParser::ParameterTypeListContext *context) = 0;

    virtual antlrcpp::Any visitParameterDeclaration(PnfCParser::ParameterDeclarationContext *context) = 0;

    virtual antlrcpp::Any visitTypeName(PnfCParser::TypeNameContext *context) = 0;

    virtual antlrcpp::Any visitAbstractDeclarator(PnfCParser::AbstractDeclaratorContext *context) = 0;

    virtual antlrcpp::Any visitTypedefName(PnfCParser::TypedefNameContext *context) = 0;

    virtual antlrcpp::Any visitInitializer(PnfCParser::InitializerContext *context) = 0;

    virtual antlrcpp::Any visitDesignation(PnfCParser::DesignationContext *context) = 0;

    virtual antlrcpp::Any visitStaticAssertDeclaration(PnfCParser::StaticAssertDeclarationContext *context) = 0;

    virtual antlrcpp::Any visitAsmStatement(PnfCParser::AsmStatementContext *context) = 0;

    virtual antlrcpp::Any visitLabeledStatement(PnfCParser::LabeledStatementContext *context) = 0;

    virtual antlrcpp::Any visitCompoundStatement(PnfCParser::CompoundStatementContext *context) = 0;

    virtual antlrcpp::Any visitExpressionStatement(PnfCParser::ExpressionStatementContext *context) = 0;

    virtual antlrcpp::Any visitJumpStatement(PnfCParser::JumpStatementContext *context) = 0;

    virtual antlrcpp::Any visitCompilationUnit(PnfCParser::CompilationUnitContext *context) = 0;

    virtual antlrcpp::Any visitFunctionDefinition(PnfCParser::FunctionDefinitionContext *context) = 0;

    virtual antlrcpp::Any visitKleene_plus__primaryExpression_1(PnfCParser::Kleene_plus__primaryExpression_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__primaryExpression_2(PnfCParser::Optional__primaryExpression_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__postfixExpression_1(PnfCParser::Optional__postfixExpression_1Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__conditionalExpression_1(PnfCParser::Aux_rule__conditionalExpression_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__conditionalExpression_2(PnfCParser::Optional__conditionalExpression_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__declaration_1(PnfCParser::Optional__declaration_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__declaration_2(PnfCParser::Optional__declaration_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__structOrUnionSpecifier_1(PnfCParser::Optional__structOrUnionSpecifier_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__structDeclaration_2(PnfCParser::Optional__structDeclaration_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__specifierQualifierList_1(PnfCParser::Optional__specifierQualifierList_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__structDeclarator_1(PnfCParser::Optional__structDeclarator_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__declarator_1(PnfCParser::Optional__declarator_1Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__declarator_2(PnfCParser::Kleene_star__declarator_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__directDeclarator_2(PnfCParser::Optional__directDeclarator_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__directDeclarator_5(PnfCParser::Optional__directDeclarator_5Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__gccAttributeList_1(PnfCParser::Aux_rule__gccAttributeList_1Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__gccAttributeList_2(PnfCParser::Kleene_star__gccAttributeList_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__gccAttributeList_3(PnfCParser::Aux_rule__gccAttributeList_3Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__gccAttribute_2(PnfCParser::Aux_rule__gccAttribute_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__gccAttribute_3(PnfCParser::Optional__gccAttribute_3Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__gccAttribute_4(PnfCParser::Aux_rule__gccAttribute_4Context *context) = 0;

    virtual antlrcpp::Any visitOptional__pointer_1(PnfCParser::Optional__pointer_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__typeName_1(PnfCParser::Optional__typeName_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__directAbstractDeclarator_5(PnfCParser::Optional__directAbstractDeclarator_5Context *context) = 0;

    virtual antlrcpp::Any visitOptional__initializerList_1(PnfCParser::Optional__initializerList_1Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__asmStatement_1(PnfCParser::Aux_rule__asmStatement_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__asmStatement_2(PnfCParser::Optional__asmStatement_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__asmStatement_3(PnfCParser::Aux_rule__asmStatement_3Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__asmStatement_4(PnfCParser::Kleene_star__asmStatement_4Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__asmStatement_5(PnfCParser::Aux_rule__asmStatement_5Context *context) = 0;

    virtual antlrcpp::Any visitOptional__asmStatement_6(PnfCParser::Optional__asmStatement_6Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__asmStatement_11(PnfCParser::Aux_rule__asmStatement_11Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__asmStatement_12(PnfCParser::Kleene_star__asmStatement_12Context *context) = 0;

    virtual antlrcpp::Any visitOptional__compoundStatement_1(PnfCParser::Optional__compoundStatement_1Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__selectionStatement_1(PnfCParser::Aux_rule__selectionStatement_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__selectionStatement_2(PnfCParser::Optional__selectionStatement_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__compilationUnit_1(PnfCParser::Optional__compilationUnit_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__functionDefinition_2(PnfCParser::Optional__functionDefinition_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__functionDefinition_3(PnfCParser::Optional__functionDefinition_3Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__expression_2(PnfCParser::Aux_rule__expression_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__expression_1(PnfCParser::Kleene_star__expression_1Context *context) = 0;

    virtual antlrcpp::Any visitExpression(PnfCParser::ExpressionContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__genericAssocList_2(PnfCParser::Aux_rule__genericAssocList_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__genericAssocList_1(PnfCParser::Kleene_star__genericAssocList_1Context *context) = 0;

    virtual antlrcpp::Any visitGenericAssocList(PnfCParser::GenericAssocListContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__postfixExpression_3(PnfCParser::Aux_rule__postfixExpression_3Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__postfixExpression_2(PnfCParser::Kleene_star__postfixExpression_2Context *context) = 0;

    virtual antlrcpp::Any visitPostfixExpression(PnfCParser::PostfixExpressionContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__initializerList_4(PnfCParser::Aux_rule__initializerList_4Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__initializerList_3(PnfCParser::Kleene_star__initializerList_3Context *context) = 0;

    virtual antlrcpp::Any visitInitializerList(PnfCParser::InitializerListContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__multiplicativeExpression_2(PnfCParser::Aux_rule__multiplicativeExpression_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__multiplicativeExpression_1(PnfCParser::Kleene_star__multiplicativeExpression_1Context *context) = 0;

    virtual antlrcpp::Any visitMultiplicativeExpression(PnfCParser::MultiplicativeExpressionContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__additiveExpression_2(PnfCParser::Aux_rule__additiveExpression_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__additiveExpression_1(PnfCParser::Kleene_star__additiveExpression_1Context *context) = 0;

    virtual antlrcpp::Any visitAdditiveExpression(PnfCParser::AdditiveExpressionContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__shiftExpression_2(PnfCParser::Aux_rule__shiftExpression_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__shiftExpression_1(PnfCParser::Kleene_star__shiftExpression_1Context *context) = 0;

    virtual antlrcpp::Any visitShiftExpression(PnfCParser::ShiftExpressionContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__relationalExpression_2(PnfCParser::Aux_rule__relationalExpression_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__relationalExpression_1(PnfCParser::Kleene_star__relationalExpression_1Context *context) = 0;

    virtual antlrcpp::Any visitRelationalExpression(PnfCParser::RelationalExpressionContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__equalityExpression_2(PnfCParser::Aux_rule__equalityExpression_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__equalityExpression_1(PnfCParser::Kleene_star__equalityExpression_1Context *context) = 0;

    virtual antlrcpp::Any visitEqualityExpression(PnfCParser::EqualityExpressionContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__andExpression_2(PnfCParser::Aux_rule__andExpression_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__andExpression_1(PnfCParser::Kleene_star__andExpression_1Context *context) = 0;

    virtual antlrcpp::Any visitAndExpression(PnfCParser::AndExpressionContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__exclusiveOrExpression_2(PnfCParser::Aux_rule__exclusiveOrExpression_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__exclusiveOrExpression_1(PnfCParser::Kleene_star__exclusiveOrExpression_1Context *context) = 0;

    virtual antlrcpp::Any visitExclusiveOrExpression(PnfCParser::ExclusiveOrExpressionContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__inclusiveOrExpression_2(PnfCParser::Aux_rule__inclusiveOrExpression_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__inclusiveOrExpression_1(PnfCParser::Kleene_star__inclusiveOrExpression_1Context *context) = 0;

    virtual antlrcpp::Any visitInclusiveOrExpression(PnfCParser::InclusiveOrExpressionContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__logicalAndExpression_2(PnfCParser::Aux_rule__logicalAndExpression_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__logicalAndExpression_1(PnfCParser::Kleene_star__logicalAndExpression_1Context *context) = 0;

    virtual antlrcpp::Any visitLogicalAndExpression(PnfCParser::LogicalAndExpressionContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__logicalOrExpression_2(PnfCParser::Aux_rule__logicalOrExpression_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__logicalOrExpression_1(PnfCParser::Kleene_star__logicalOrExpression_1Context *context) = 0;

    virtual antlrcpp::Any visitLogicalOrExpression(PnfCParser::LogicalOrExpressionContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__initDeclaratorList_2(PnfCParser::Aux_rule__initDeclaratorList_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__initDeclaratorList_1(PnfCParser::Kleene_star__initDeclaratorList_1Context *context) = 0;

    virtual antlrcpp::Any visitInitDeclaratorList(PnfCParser::InitDeclaratorListContext *context) = 0;

    virtual antlrcpp::Any visitStructDeclarationList(PnfCParser::StructDeclarationListContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__structDeclaratorList_2(PnfCParser::Aux_rule__structDeclaratorList_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__structDeclaratorList_1(PnfCParser::Kleene_star__structDeclaratorList_1Context *context) = 0;

    virtual antlrcpp::Any visitStructDeclaratorList(PnfCParser::StructDeclaratorListContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__enumeratorList_2(PnfCParser::Aux_rule__enumeratorList_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__enumeratorList_1(PnfCParser::Kleene_star__enumeratorList_1Context *context) = 0;

    virtual antlrcpp::Any visitEnumeratorList(PnfCParser::EnumeratorListContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__directDeclarator_7(PnfCParser::Aux_rule__directDeclarator_7Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__directDeclarator_6(PnfCParser::Kleene_star__directDeclarator_6Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__directDeclarator_8(PnfCParser::Aux_rule__directDeclarator_8Context *context) = 0;

    virtual antlrcpp::Any visitDirectDeclarator(PnfCParser::DirectDeclaratorContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__typeQualifierList_2(PnfCParser::Aux_rule__typeQualifierList_2Context *context) = 0;

    virtual antlrcpp::Any visitTypeQualifierList(PnfCParser::TypeQualifierListContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__identifierList_2(PnfCParser::Aux_rule__identifierList_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__identifierList_1(PnfCParser::Kleene_star__identifierList_1Context *context) = 0;

    virtual antlrcpp::Any visitIdentifierList(PnfCParser::IdentifierListContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__parameterList_2(PnfCParser::Aux_rule__parameterList_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__parameterList_1(PnfCParser::Kleene_star__parameterList_1Context *context) = 0;

    virtual antlrcpp::Any visitParameterList(PnfCParser::ParameterListContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__directAbstractDeclarator_13(PnfCParser::Aux_rule__directAbstractDeclarator_13Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__directAbstractDeclarator_12(PnfCParser::Kleene_star__directAbstractDeclarator_12Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__directAbstractDeclarator_14(PnfCParser::Aux_rule__directAbstractDeclarator_14Context *context) = 0;

    virtual antlrcpp::Any visitDirectAbstractDeclarator(PnfCParser::DirectAbstractDeclaratorContext *context) = 0;

    virtual antlrcpp::Any visitDesignatorList(PnfCParser::DesignatorListContext *context) = 0;

    virtual antlrcpp::Any visitBlockItemList(PnfCParser::BlockItemListContext *context) = 0;

    virtual antlrcpp::Any visitTranslationUnit(PnfCParser::TranslationUnitContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__declarationList_2(PnfCParser::Aux_rule__declarationList_2Context *context) = 0;

    virtual antlrcpp::Any visitDeclarationList(PnfCParser::DeclarationListContext *context) = 0;

    virtual antlrcpp::Any visitKleene_plus__structDeclarationList_3(PnfCParser::Kleene_plus__structDeclarationList_3Context *context) = 0;

    virtual antlrcpp::Any visitKleene_plus__typeQualifierList_3(PnfCParser::Kleene_plus__typeQualifierList_3Context *context) = 0;

    virtual antlrcpp::Any visitKleene_plus__designatorList_3(PnfCParser::Kleene_plus__designatorList_3Context *context) = 0;

    virtual antlrcpp::Any visitKleene_plus__blockItemList_3(PnfCParser::Kleene_plus__blockItemList_3Context *context) = 0;

    virtual antlrcpp::Any visitKleene_plus__translationUnit_3(PnfCParser::Kleene_plus__translationUnit_3Context *context) = 0;

    virtual antlrcpp::Any visitKleene_plus__declarationList_3(PnfCParser::Kleene_plus__declarationList_3Context *context) = 0;

    virtual antlrcpp::Any visitOptional__postfixExpression_5(PnfCParser::Optional__postfixExpression_5Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__initDeclarator_1(PnfCParser::Aux_rule__initDeclarator_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__initDeclarator_2(PnfCParser::Optional__initDeclarator_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__enumerator_1(PnfCParser::Aux_rule__enumerator_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__enumerator_2(PnfCParser::Optional__enumerator_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__parameterTypeList_1(PnfCParser::Aux_rule__parameterTypeList_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__parameterTypeList_2(PnfCParser::Optional__parameterTypeList_2Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__primaryExpression_3(PnfCParser::Altnt_block__primaryExpression_3Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__unaryExpression_1(PnfCParser::Altnt_block__unaryExpression_1Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__unaryExpression_2(PnfCParser::Altnt_block__unaryExpression_2Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__genericAssociation_1(PnfCParser::Altnt_block__genericAssociation_1Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__postfixExpression_7(PnfCParser::Altnt_block__postfixExpression_7Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__postfixExpression_8(PnfCParser::Altnt_block__postfixExpression_8Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__multiplicativeExpression_3(PnfCParser::Altnt_block__multiplicativeExpression_3Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__additiveExpression_3(PnfCParser::Altnt_block__additiveExpression_3Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__shiftExpression_3(PnfCParser::Altnt_block__shiftExpression_3Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__relationalExpression_3(PnfCParser::Altnt_block__relationalExpression_3Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__equalityExpression_3(PnfCParser::Altnt_block__equalityExpression_3Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__typeSpecifier_1(PnfCParser::Altnt_block__typeSpecifier_1Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__alignmentSpecifier_1(PnfCParser::Altnt_block__alignmentSpecifier_1Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__structOrUnionSpecifier_2(PnfCParser::Altnt_block__structOrUnionSpecifier_2Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__enumSpecifier_3(PnfCParser::Altnt_block__enumSpecifier_3Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__pointer_5(PnfCParser::Altnt_block__pointer_5Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__directDeclarator_9(PnfCParser::Altnt_block__directDeclarator_9Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__directDeclarator_10(PnfCParser::Altnt_block__directDeclarator_10Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__directAbstractDeclarator_15(PnfCParser::Altnt_block__directAbstractDeclarator_15Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__directAbstractDeclarator_17(PnfCParser::Altnt_block__directAbstractDeclarator_17Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__labeledStatement_1(PnfCParser::Altnt_block__labeledStatement_1Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__jumpStatement_2(PnfCParser::Altnt_block__jumpStatement_2Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__enumSpecifier_4(PnfCParser::Altnt_block__enumSpecifier_4Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__directDeclarator_11(PnfCParser::Altnt_block__directDeclarator_11Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__iterationStatement_7(PnfCParser::Altnt_block__iterationStatement_7Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__jumpStatement_3(PnfCParser::Altnt_block__jumpStatement_3Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__postfixExpression_4(PnfCParser::Aux_rule__postfixExpression_4Context *context) = 0;

    virtual antlrcpp::Any visitDeclarationSpecifier(PnfCParser::DeclarationSpecifierContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__structDeclarationList_2(PnfCParser::Aux_rule__structDeclarationList_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__designatorList_2(PnfCParser::Aux_rule__designatorList_2Context *context) = 0;

    virtual antlrcpp::Any visitStatement(PnfCParser::StatementContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__blockItemList_2(PnfCParser::Aux_rule__blockItemList_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__translationUnit_2(PnfCParser::Aux_rule__translationUnit_2Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__unaryExpression_3(PnfCParser::Altnt_block__unaryExpression_3Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__unaryExpression_4(PnfCParser::Altnt_block__unaryExpression_4Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__typeSpecifier_2(PnfCParser::Altnt_block__typeSpecifier_2Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__specifierQualifierList_3(PnfCParser::Altnt_block__specifierQualifierList_3Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__pointer_8(PnfCParser::Altnt_block__pointer_8Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__directDeclarator_12(PnfCParser::Altnt_block__directDeclarator_12Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__parameterDeclaration_2(PnfCParser::Altnt_block__parameterDeclaration_2Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__directAbstractDeclarator_20(PnfCParser::Altnt_block__directAbstractDeclarator_20Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__iterationStatement_8(PnfCParser::Altnt_block__iterationStatement_8Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__statement_1(PnfCParser::Altnt_block__statement_1Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__statement_2(PnfCParser::Altnt_block__statement_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__unaryExpression_5(PnfCParser::Aux_rule__unaryExpression_5Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__unaryExpression_6(PnfCParser::Aux_rule__unaryExpression_6Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__unaryExpression_7(PnfCParser::Aux_rule__unaryExpression_7Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__unaryExpression_8(PnfCParser::Aux_rule__unaryExpression_8Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__castExpression_2(PnfCParser::Aux_rule__castExpression_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__assignmentExpression_1(PnfCParser::Aux_rule__assignmentExpression_1Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__declaration_3(PnfCParser::Aux_rule__declaration_3Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__typeSpecifier_3(PnfCParser::Aux_rule__typeSpecifier_3Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__structDeclarator_2(PnfCParser::Aux_rule__structDeclarator_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__gccDeclaratorExtension_2(PnfCParser::Aux_rule__gccDeclaratorExtension_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__abstractDeclarator_3(PnfCParser::Aux_rule__abstractDeclarator_3Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__initializer_2(PnfCParser::Aux_rule__initializer_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__postfixExpression_10(PnfCParser::Aux_rule__postfixExpression_10Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__postfixExpression_11(PnfCParser::Aux_rule__postfixExpression_11Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__postfixExpression_12(PnfCParser::Aux_rule__postfixExpression_12Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__directDeclarator_13(PnfCParser::Aux_rule__directDeclarator_13Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__directDeclarator_14(PnfCParser::Aux_rule__directDeclarator_14Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__directDeclarator_15(PnfCParser::Aux_rule__directDeclarator_15Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__directAbstractDeclarator_21(PnfCParser::Aux_rule__directAbstractDeclarator_21Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__directAbstractDeclarator_22(PnfCParser::Aux_rule__directAbstractDeclarator_22Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__directAbstractDeclarator_23(PnfCParser::Aux_rule__directAbstractDeclarator_23Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__directAbstractDeclarator_24(PnfCParser::Aux_rule__directAbstractDeclarator_24Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__primaryExpression_4(PnfCParser::Aux_rule__primaryExpression_4Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__primaryExpression_5(PnfCParser::Aux_rule__primaryExpression_5Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__primaryExpression_6(PnfCParser::Aux_rule__primaryExpression_6Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__primaryExpression_7(PnfCParser::Aux_rule__primaryExpression_7Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__unaryExpression_9(PnfCParser::Aux_rule__unaryExpression_9Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__unaryExpression_10(PnfCParser::Aux_rule__unaryExpression_10Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__typeSpecifier_4(PnfCParser::Aux_rule__typeSpecifier_4Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__typeSpecifier_5(PnfCParser::Aux_rule__typeSpecifier_5Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__structOrUnionSpecifier_3(PnfCParser::Aux_rule__structOrUnionSpecifier_3Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__enumSpecifier_6(PnfCParser::Aux_rule__enumSpecifier_6Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__directDeclarator_16(PnfCParser::Aux_rule__directDeclarator_16Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__directDeclarator_17(PnfCParser::Aux_rule__directDeclarator_17Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__directAbstractDeclarator_25(PnfCParser::Aux_rule__directAbstractDeclarator_25Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__directAbstractDeclarator_26(PnfCParser::Aux_rule__directAbstractDeclarator_26Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__labeledStatement_2(PnfCParser::Aux_rule__labeledStatement_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__jumpStatement_4(PnfCParser::Aux_rule__jumpStatement_4Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__jumpStatement_5(PnfCParser::Aux_rule__jumpStatement_5Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__directDeclarator_18(PnfCParser::Aux_rule__directDeclarator_18Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__directDeclarator_19(PnfCParser::Aux_rule__directDeclarator_19Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__postfixExpression_13(PnfCParser::Aux_rule__postfixExpression_13Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__postfixExpression_14(PnfCParser::Aux_rule__postfixExpression_14Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__declarationSpecifier_1(PnfCParser::Aux_rule__declarationSpecifier_1Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__structDeclarationList_4(PnfCParser::Aux_rule__structDeclarationList_4Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__designatorList_4(PnfCParser::Aux_rule__designatorList_4Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__designatorList_5(PnfCParser::Aux_rule__designatorList_5Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__statement_3(PnfCParser::Aux_rule__statement_3Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__statement_4(PnfCParser::Aux_rule__statement_4Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__statement_5(PnfCParser::Aux_rule__statement_5Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__iterationStatement_9(PnfCParser::Aux_rule__iterationStatement_9Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__statement_6(PnfCParser::Aux_rule__statement_6Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__statement_7(PnfCParser::Aux_rule__statement_7Context *context) = 0;


};

}  // namespace antlr_C_perses
