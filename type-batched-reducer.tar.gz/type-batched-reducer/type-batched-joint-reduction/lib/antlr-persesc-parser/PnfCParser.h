
// Generated from PnfC.g4 by ANTLR 4.7.2

#pragma once


#include "antlr4-runtime.h"


namespace antlr_C_perses {


class  PnfCParser : public antlr4::Parser {
public:
  enum {
    T__0 = 1, T__1 = 2, T__2 = 3, T__3 = 4, T__4 = 5, T__5 = 6, T__6 = 7, 
    T__7 = 8, T__8 = 9, T__9 = 10, T__10 = 11, T__11 = 12, T__12 = 13, T__13 = 14, 
    IncludeDirective = 15, Auto = 16, Break = 17, Case = 18, Char = 19, 
    Const = 20, Nonnull = 21, Nullable = 22, Continue = 23, Default = 24, 
    Do = 25, Double = 26, Else = 27, Enum = 28, Extern = 29, Float = 30, 
    For = 31, Goto = 32, If = 33, Inline = 34, Int = 35, Long = 36, Register = 37, 
    Restrict = 38, Restrict_gcc = 39, Restrict_gcc2 = 40, Extension_gcc = 41, 
    Return = 42, Short = 43, Signed = 44, Sizeof = 45, Static = 46, Struct = 47, 
    Switch = 48, Typedef = 49, Union = 50, Unsigned = 51, Void = 52, Volatile = 53, 
    While = 54, Alignas = 55, Alignof = 56, Alignof_gcc = 57, Atomic = 58, 
    Bool = 59, Complex = 60, Generic = 61, Imaginary = 62, Noreturn = 63, 
    StaticAssert = 64, ThreadLocal = 65, LeftParen = 66, RightParen = 67, 
    LeftBracket = 68, RightBracket = 69, LeftBrace = 70, RightBrace = 71, 
    Less = 72, LessEqual = 73, Greater = 74, GreaterEqual = 75, LeftShift = 76, 
    RightShift = 77, Plus = 78, PlusPlus = 79, Minus = 80, MinusMinus = 81, 
    Star = 82, Div = 83, Mod = 84, And = 85, Or = 86, AndAnd = 87, OrOr = 88, 
    Caret = 89, Not = 90, Tilde = 91, Question = 92, Colon = 93, Semi = 94, 
    Comma = 95, Assign = 96, StarAssign = 97, DivAssign = 98, ModAssign = 99, 
    PlusAssign = 100, MinusAssign = 101, LeftShiftAssign = 102, RightShiftAssign = 103, 
    AndAssign = 104, XorAssign = 105, OrAssign = 106, Equal = 107, NotEqual = 108, 
    Arrow = 109, Dot = 110, Ellipsis = 111, Identifier = 112, Constant = 113, 
    StringLiteral = 114, ComplexDefine = 115, AsmBlock = 116, LineAfterPreprocessing = 117, 
    LineDirective = 118, PragmaDirective = 119, Whitespace = 120, Newline = 121, 
    BlockComment = 122, LineComment = 123
  };

  enum {
    RuleGenericSelection = 0, RuleGenericAssociation = 1, RuleUnaryExpression = 2, 
    RuleUnaryOperator = 3, RuleCastExpression = 4, RuleConditionalExpression = 5, 
    RuleAssignmentExpression = 6, RuleAssignmentOperator = 7, RuleConstantExpression = 8, 
    RuleDeclaration = 9, RuleDeclarationSpecifiers = 10, RuleInitDeclarator = 11, 
    RuleTypeSpecifier = 12, RuleStructOrUnionSpecifier = 13, RuleStructOrUnion = 14, 
    RuleSpecifierQualifierList = 15, RuleStructDeclarator = 16, RuleEnumSpecifier = 17, 
    RuleEnumerator = 18, RuleAtomicTypeSpecifier = 19, RuleTypeQualifier = 20, 
    RuleAlignmentSpecifier = 21, RuleDeclarator = 22, RuleGccDeclaratorExtension = 23, 
    RuleAsmKeyword = 24, RuleGccAttributeSpecifier = 25, RuleGccAttributeList = 26, 
    RuleGccAttribute = 27, RulePointer = 28, RuleParameterTypeList = 29, 
    RuleParameterDeclaration = 30, RuleTypeName = 31, RuleAbstractDeclarator = 32, 
    RuleTypedefName = 33, RuleInitializer = 34, RuleDesignation = 35, RuleStaticAssertDeclaration = 36, 
    RuleAsmStatement = 37, RuleLabeledStatement = 38, RuleCompoundStatement = 39, 
    RuleExpressionStatement = 40, RuleJumpStatement = 41, RuleCompilationUnit = 42, 
    RuleFunctionDefinition = 43, RuleKleene_plus__primaryExpression_1 = 44, 
    RuleOptional__primaryExpression_2 = 45, RuleOptional__postfixExpression_1 = 46, 
    RuleAux_rule__conditionalExpression_1 = 47, RuleOptional__conditionalExpression_2 = 48, 
    RuleOptional__declaration_1 = 49, RuleOptional__declaration_2 = 50, 
    RuleOptional__structOrUnionSpecifier_1 = 51, RuleOptional__structDeclaration_2 = 52, 
    RuleOptional__specifierQualifierList_1 = 53, RuleOptional__structDeclarator_1 = 54, 
    RuleOptional__declarator_1 = 55, RuleKleene_star__declarator_2 = 56, 
    RuleOptional__directDeclarator_2 = 57, RuleOptional__directDeclarator_5 = 58, 
    RuleAux_rule__gccAttributeList_1 = 59, RuleKleene_star__gccAttributeList_2 = 60, 
    RuleAux_rule__gccAttributeList_3 = 61, RuleAux_rule__gccAttribute_2 = 62, 
    RuleOptional__gccAttribute_3 = 63, RuleAux_rule__gccAttribute_4 = 64, 
    RuleOptional__pointer_1 = 65, RuleOptional__typeName_1 = 66, RuleOptional__directAbstractDeclarator_5 = 67, 
    RuleOptional__initializerList_1 = 68, RuleAux_rule__asmStatement_1 = 69, 
    RuleOptional__asmStatement_2 = 70, RuleAux_rule__asmStatement_3 = 71, 
    RuleKleene_star__asmStatement_4 = 72, RuleAux_rule__asmStatement_5 = 73, 
    RuleOptional__asmStatement_6 = 74, RuleAux_rule__asmStatement_11 = 75, 
    RuleKleene_star__asmStatement_12 = 76, RuleOptional__compoundStatement_1 = 77, 
    RuleAux_rule__selectionStatement_1 = 78, RuleOptional__selectionStatement_2 = 79, 
    RuleOptional__compilationUnit_1 = 80, RuleOptional__functionDefinition_2 = 81, 
    RuleOptional__functionDefinition_3 = 82, RuleAux_rule__expression_2 = 83, 
    RuleKleene_star__expression_1 = 84, RuleExpression = 85, RuleAux_rule__genericAssocList_2 = 86, 
    RuleKleene_star__genericAssocList_1 = 87, RuleGenericAssocList = 88, 
    RuleAux_rule__postfixExpression_3 = 89, RuleKleene_star__postfixExpression_2 = 90, 
    RulePostfixExpression = 91, RuleAux_rule__initializerList_4 = 92, RuleKleene_star__initializerList_3 = 93, 
    RuleInitializerList = 94, RuleAux_rule__multiplicativeExpression_2 = 95, 
    RuleKleene_star__multiplicativeExpression_1 = 96, RuleMultiplicativeExpression = 97, 
    RuleAux_rule__additiveExpression_2 = 98, RuleKleene_star__additiveExpression_1 = 99, 
    RuleAdditiveExpression = 100, RuleAux_rule__shiftExpression_2 = 101, 
    RuleKleene_star__shiftExpression_1 = 102, RuleShiftExpression = 103, 
    RuleAux_rule__relationalExpression_2 = 104, RuleKleene_star__relationalExpression_1 = 105, 
    RuleRelationalExpression = 106, RuleAux_rule__equalityExpression_2 = 107, 
    RuleKleene_star__equalityExpression_1 = 108, RuleEqualityExpression = 109, 
    RuleAux_rule__andExpression_2 = 110, RuleKleene_star__andExpression_1 = 111, 
    RuleAndExpression = 112, RuleAux_rule__exclusiveOrExpression_2 = 113, 
    RuleKleene_star__exclusiveOrExpression_1 = 114, RuleExclusiveOrExpression = 115, 
    RuleAux_rule__inclusiveOrExpression_2 = 116, RuleKleene_star__inclusiveOrExpression_1 = 117, 
    RuleInclusiveOrExpression = 118, RuleAux_rule__logicalAndExpression_2 = 119, 
    RuleKleene_star__logicalAndExpression_1 = 120, RuleLogicalAndExpression = 121, 
    RuleAux_rule__logicalOrExpression_2 = 122, RuleKleene_star__logicalOrExpression_1 = 123, 
    RuleLogicalOrExpression = 124, RuleAux_rule__initDeclaratorList_2 = 125, 
    RuleKleene_star__initDeclaratorList_1 = 126, RuleInitDeclaratorList = 127, 
    RuleStructDeclarationList = 128, RuleAux_rule__structDeclaratorList_2 = 129, 
    RuleKleene_star__structDeclaratorList_1 = 130, RuleStructDeclaratorList = 131, 
    RuleAux_rule__enumeratorList_2 = 132, RuleKleene_star__enumeratorList_1 = 133, 
    RuleEnumeratorList = 134, RuleAux_rule__directDeclarator_7 = 135, RuleKleene_star__directDeclarator_6 = 136, 
    RuleAux_rule__directDeclarator_8 = 137, RuleDirectDeclarator = 138, 
    RuleAux_rule__typeQualifierList_2 = 139, RuleTypeQualifierList = 140, 
    RuleAux_rule__identifierList_2 = 141, RuleKleene_star__identifierList_1 = 142, 
    RuleIdentifierList = 143, RuleAux_rule__parameterList_2 = 144, RuleKleene_star__parameterList_1 = 145, 
    RuleParameterList = 146, RuleAux_rule__directAbstractDeclarator_13 = 147, 
    RuleKleene_star__directAbstractDeclarator_12 = 148, RuleAux_rule__directAbstractDeclarator_14 = 149, 
    RuleDirectAbstractDeclarator = 150, RuleDesignatorList = 151, RuleBlockItemList = 152, 
    RuleTranslationUnit = 153, RuleAux_rule__declarationList_2 = 154, RuleDeclarationList = 155, 
    RuleKleene_plus__structDeclarationList_3 = 156, RuleKleene_plus__typeQualifierList_3 = 157, 
    RuleKleene_plus__designatorList_3 = 158, RuleKleene_plus__blockItemList_3 = 159, 
    RuleKleene_plus__translationUnit_3 = 160, RuleKleene_plus__declarationList_3 = 161, 
    RuleOptional__postfixExpression_5 = 162, RuleAux_rule__initDeclarator_1 = 163, 
    RuleOptional__initDeclarator_2 = 164, RuleAux_rule__enumerator_1 = 165, 
    RuleOptional__enumerator_2 = 166, RuleAux_rule__parameterTypeList_1 = 167, 
    RuleOptional__parameterTypeList_2 = 168, RuleAltnt_block__primaryExpression_3 = 169, 
    RuleAltnt_block__unaryExpression_1 = 170, RuleAltnt_block__unaryExpression_2 = 171, 
    RuleAltnt_block__genericAssociation_1 = 172, RuleAltnt_block__postfixExpression_7 = 173, 
    RuleAltnt_block__postfixExpression_8 = 174, RuleAltnt_block__multiplicativeExpression_3 = 175, 
    RuleAltnt_block__additiveExpression_3 = 176, RuleAltnt_block__shiftExpression_3 = 177, 
    RuleAltnt_block__relationalExpression_3 = 178, RuleAltnt_block__equalityExpression_3 = 179, 
    RuleAltnt_block__typeSpecifier_1 = 180, RuleAltnt_block__alignmentSpecifier_1 = 181, 
    RuleAltnt_block__structOrUnionSpecifier_2 = 182, RuleAltnt_block__enumSpecifier_3 = 183, 
    RuleAltnt_block__pointer_5 = 184, RuleAltnt_block__directDeclarator_9 = 185, 
    RuleAltnt_block__directDeclarator_10 = 186, RuleAltnt_block__directAbstractDeclarator_15 = 187, 
    RuleAltnt_block__directAbstractDeclarator_17 = 188, RuleAltnt_block__labeledStatement_1 = 189, 
    RuleAltnt_block__jumpStatement_2 = 190, RuleAltnt_block__enumSpecifier_4 = 191, 
    RuleAltnt_block__directDeclarator_11 = 192, RuleAltnt_block__iterationStatement_7 = 193, 
    RuleAltnt_block__jumpStatement_3 = 194, RuleAux_rule__postfixExpression_4 = 195, 
    RuleDeclarationSpecifier = 196, RuleAux_rule__structDeclarationList_2 = 197, 
    RuleAux_rule__designatorList_2 = 198, RuleStatement = 199, RuleAux_rule__blockItemList_2 = 200, 
    RuleAux_rule__translationUnit_2 = 201, RuleAltnt_block__unaryExpression_3 = 202, 
    RuleAltnt_block__unaryExpression_4 = 203, RuleAltnt_block__typeSpecifier_2 = 204, 
    RuleAltnt_block__specifierQualifierList_3 = 205, RuleAltnt_block__pointer_8 = 206, 
    RuleAltnt_block__directDeclarator_12 = 207, RuleAltnt_block__parameterDeclaration_2 = 208, 
    RuleAltnt_block__directAbstractDeclarator_20 = 209, RuleAltnt_block__iterationStatement_8 = 210, 
    RuleAltnt_block__statement_1 = 211, RuleAltnt_block__statement_2 = 212, 
    RuleAux_rule__unaryExpression_5 = 213, RuleAux_rule__unaryExpression_6 = 214, 
    RuleAux_rule__unaryExpression_7 = 215, RuleAux_rule__unaryExpression_8 = 216, 
    RuleAux_rule__castExpression_2 = 217, RuleAux_rule__assignmentExpression_1 = 218, 
    RuleAux_rule__declaration_3 = 219, RuleAux_rule__typeSpecifier_3 = 220, 
    RuleAux_rule__structDeclarator_2 = 221, RuleAux_rule__gccDeclaratorExtension_2 = 222, 
    RuleAux_rule__abstractDeclarator_3 = 223, RuleAux_rule__initializer_2 = 224, 
    RuleAux_rule__postfixExpression_10 = 225, RuleAux_rule__postfixExpression_11 = 226, 
    RuleAux_rule__postfixExpression_12 = 227, RuleAux_rule__directDeclarator_13 = 228, 
    RuleAux_rule__directDeclarator_14 = 229, RuleAux_rule__directDeclarator_15 = 230, 
    RuleAux_rule__directAbstractDeclarator_21 = 231, RuleAux_rule__directAbstractDeclarator_22 = 232, 
    RuleAux_rule__directAbstractDeclarator_23 = 233, RuleAux_rule__directAbstractDeclarator_24 = 234, 
    RuleAux_rule__primaryExpression_4 = 235, RuleAux_rule__primaryExpression_5 = 236, 
    RuleAux_rule__primaryExpression_6 = 237, RuleAux_rule__primaryExpression_7 = 238, 
    RuleAux_rule__unaryExpression_9 = 239, RuleAux_rule__unaryExpression_10 = 240, 
    RuleAux_rule__typeSpecifier_4 = 241, RuleAux_rule__typeSpecifier_5 = 242, 
    RuleAux_rule__structOrUnionSpecifier_3 = 243, RuleAux_rule__enumSpecifier_6 = 244, 
    RuleAux_rule__directDeclarator_16 = 245, RuleAux_rule__directDeclarator_17 = 246, 
    RuleAux_rule__directAbstractDeclarator_25 = 247, RuleAux_rule__directAbstractDeclarator_26 = 248, 
    RuleAux_rule__labeledStatement_2 = 249, RuleAux_rule__jumpStatement_4 = 250, 
    RuleAux_rule__jumpStatement_5 = 251, RuleAux_rule__directDeclarator_18 = 252, 
    RuleAux_rule__directDeclarator_19 = 253, RuleAux_rule__postfixExpression_13 = 254, 
    RuleAux_rule__postfixExpression_14 = 255, RuleAux_rule__declarationSpecifier_1 = 256, 
    RuleAux_rule__structDeclarationList_4 = 257, RuleAux_rule__designatorList_4 = 258, 
    RuleAux_rule__designatorList_5 = 259, RuleAux_rule__statement_3 = 260, 
    RuleAux_rule__statement_4 = 261, RuleAux_rule__statement_5 = 262, RuleAux_rule__iterationStatement_9 = 263, 
    RuleAux_rule__statement_6 = 264, RuleAux_rule__statement_7 = 265
  };

  PnfCParser(antlr4::TokenStream *input);
  ~PnfCParser();

  virtual std::string getGrammarFileName() const override;
  virtual const antlr4::atn::ATN& getATN() const override { return _atn; };
  virtual const std::vector<std::string>& getTokenNames() const override { return _tokenNames; }; // deprecated: use vocabulary instead.
  virtual const std::vector<std::string>& getRuleNames() const override;
  virtual antlr4::dfa::Vocabulary& getVocabulary() const override;


  class GenericSelectionContext;
  class GenericAssociationContext;
  class UnaryExpressionContext;
  class UnaryOperatorContext;
  class CastExpressionContext;
  class ConditionalExpressionContext;
  class AssignmentExpressionContext;
  class AssignmentOperatorContext;
  class ConstantExpressionContext;
  class DeclarationContext;
  class DeclarationSpecifiersContext;
  class InitDeclaratorContext;
  class TypeSpecifierContext;
  class StructOrUnionSpecifierContext;
  class StructOrUnionContext;
  class SpecifierQualifierListContext;
  class StructDeclaratorContext;
  class EnumSpecifierContext;
  class EnumeratorContext;
  class AtomicTypeSpecifierContext;
  class TypeQualifierContext;
  class AlignmentSpecifierContext;
  class DeclaratorContext;
  class GccDeclaratorExtensionContext;
  class AsmKeywordContext;
  class GccAttributeSpecifierContext;
  class GccAttributeListContext;
  class GccAttributeContext;
  class PointerContext;
  class ParameterTypeListContext;
  class ParameterDeclarationContext;
  class TypeNameContext;
  class AbstractDeclaratorContext;
  class TypedefNameContext;
  class InitializerContext;
  class DesignationContext;
  class StaticAssertDeclarationContext;
  class AsmStatementContext;
  class LabeledStatementContext;
  class CompoundStatementContext;
  class ExpressionStatementContext;
  class JumpStatementContext;
  class CompilationUnitContext;
  class FunctionDefinitionContext;
  class Kleene_plus__primaryExpression_1Context;
  class Optional__primaryExpression_2Context;
  class Optional__postfixExpression_1Context;
  class Aux_rule__conditionalExpression_1Context;
  class Optional__conditionalExpression_2Context;
  class Optional__declaration_1Context;
  class Optional__declaration_2Context;
  class Optional__structOrUnionSpecifier_1Context;
  class Optional__structDeclaration_2Context;
  class Optional__specifierQualifierList_1Context;
  class Optional__structDeclarator_1Context;
  class Optional__declarator_1Context;
  class Kleene_star__declarator_2Context;
  class Optional__directDeclarator_2Context;
  class Optional__directDeclarator_5Context;
  class Aux_rule__gccAttributeList_1Context;
  class Kleene_star__gccAttributeList_2Context;
  class Aux_rule__gccAttributeList_3Context;
  class Aux_rule__gccAttribute_2Context;
  class Optional__gccAttribute_3Context;
  class Aux_rule__gccAttribute_4Context;
  class Optional__pointer_1Context;
  class Optional__typeName_1Context;
  class Optional__directAbstractDeclarator_5Context;
  class Optional__initializerList_1Context;
  class Aux_rule__asmStatement_1Context;
  class Optional__asmStatement_2Context;
  class Aux_rule__asmStatement_3Context;
  class Kleene_star__asmStatement_4Context;
  class Aux_rule__asmStatement_5Context;
  class Optional__asmStatement_6Context;
  class Aux_rule__asmStatement_11Context;
  class Kleene_star__asmStatement_12Context;
  class Optional__compoundStatement_1Context;
  class Aux_rule__selectionStatement_1Context;
  class Optional__selectionStatement_2Context;
  class Optional__compilationUnit_1Context;
  class Optional__functionDefinition_2Context;
  class Optional__functionDefinition_3Context;
  class Aux_rule__expression_2Context;
  class Kleene_star__expression_1Context;
  class ExpressionContext;
  class Aux_rule__genericAssocList_2Context;
  class Kleene_star__genericAssocList_1Context;
  class GenericAssocListContext;
  class Aux_rule__postfixExpression_3Context;
  class Kleene_star__postfixExpression_2Context;
  class PostfixExpressionContext;
  class Aux_rule__initializerList_4Context;
  class Kleene_star__initializerList_3Context;
  class InitializerListContext;
  class Aux_rule__multiplicativeExpression_2Context;
  class Kleene_star__multiplicativeExpression_1Context;
  class MultiplicativeExpressionContext;
  class Aux_rule__additiveExpression_2Context;
  class Kleene_star__additiveExpression_1Context;
  class AdditiveExpressionContext;
  class Aux_rule__shiftExpression_2Context;
  class Kleene_star__shiftExpression_1Context;
  class ShiftExpressionContext;
  class Aux_rule__relationalExpression_2Context;
  class Kleene_star__relationalExpression_1Context;
  class RelationalExpressionContext;
  class Aux_rule__equalityExpression_2Context;
  class Kleene_star__equalityExpression_1Context;
  class EqualityExpressionContext;
  class Aux_rule__andExpression_2Context;
  class Kleene_star__andExpression_1Context;
  class AndExpressionContext;
  class Aux_rule__exclusiveOrExpression_2Context;
  class Kleene_star__exclusiveOrExpression_1Context;
  class ExclusiveOrExpressionContext;
  class Aux_rule__inclusiveOrExpression_2Context;
  class Kleene_star__inclusiveOrExpression_1Context;
  class InclusiveOrExpressionContext;
  class Aux_rule__logicalAndExpression_2Context;
  class Kleene_star__logicalAndExpression_1Context;
  class LogicalAndExpressionContext;
  class Aux_rule__logicalOrExpression_2Context;
  class Kleene_star__logicalOrExpression_1Context;
  class LogicalOrExpressionContext;
  class Aux_rule__initDeclaratorList_2Context;
  class Kleene_star__initDeclaratorList_1Context;
  class InitDeclaratorListContext;
  class StructDeclarationListContext;
  class Aux_rule__structDeclaratorList_2Context;
  class Kleene_star__structDeclaratorList_1Context;
  class StructDeclaratorListContext;
  class Aux_rule__enumeratorList_2Context;
  class Kleene_star__enumeratorList_1Context;
  class EnumeratorListContext;
  class Aux_rule__directDeclarator_7Context;
  class Kleene_star__directDeclarator_6Context;
  class Aux_rule__directDeclarator_8Context;
  class DirectDeclaratorContext;
  class Aux_rule__typeQualifierList_2Context;
  class TypeQualifierListContext;
  class Aux_rule__identifierList_2Context;
  class Kleene_star__identifierList_1Context;
  class IdentifierListContext;
  class Aux_rule__parameterList_2Context;
  class Kleene_star__parameterList_1Context;
  class ParameterListContext;
  class Aux_rule__directAbstractDeclarator_13Context;
  class Kleene_star__directAbstractDeclarator_12Context;
  class Aux_rule__directAbstractDeclarator_14Context;
  class DirectAbstractDeclaratorContext;
  class DesignatorListContext;
  class BlockItemListContext;
  class TranslationUnitContext;
  class Aux_rule__declarationList_2Context;
  class DeclarationListContext;
  class Kleene_plus__structDeclarationList_3Context;
  class Kleene_plus__typeQualifierList_3Context;
  class Kleene_plus__designatorList_3Context;
  class Kleene_plus__blockItemList_3Context;
  class Kleene_plus__translationUnit_3Context;
  class Kleene_plus__declarationList_3Context;
  class Optional__postfixExpression_5Context;
  class Aux_rule__initDeclarator_1Context;
  class Optional__initDeclarator_2Context;
  class Aux_rule__enumerator_1Context;
  class Optional__enumerator_2Context;
  class Aux_rule__parameterTypeList_1Context;
  class Optional__parameterTypeList_2Context;
  class Altnt_block__primaryExpression_3Context;
  class Altnt_block__unaryExpression_1Context;
  class Altnt_block__unaryExpression_2Context;
  class Altnt_block__genericAssociation_1Context;
  class Altnt_block__postfixExpression_7Context;
  class Altnt_block__postfixExpression_8Context;
  class Altnt_block__multiplicativeExpression_3Context;
  class Altnt_block__additiveExpression_3Context;
  class Altnt_block__shiftExpression_3Context;
  class Altnt_block__relationalExpression_3Context;
  class Altnt_block__equalityExpression_3Context;
  class Altnt_block__typeSpecifier_1Context;
  class Altnt_block__alignmentSpecifier_1Context;
  class Altnt_block__structOrUnionSpecifier_2Context;
  class Altnt_block__enumSpecifier_3Context;
  class Altnt_block__pointer_5Context;
  class Altnt_block__directDeclarator_9Context;
  class Altnt_block__directDeclarator_10Context;
  class Altnt_block__directAbstractDeclarator_15Context;
  class Altnt_block__directAbstractDeclarator_17Context;
  class Altnt_block__labeledStatement_1Context;
  class Altnt_block__jumpStatement_2Context;
  class Altnt_block__enumSpecifier_4Context;
  class Altnt_block__directDeclarator_11Context;
  class Altnt_block__iterationStatement_7Context;
  class Altnt_block__jumpStatement_3Context;
  class Aux_rule__postfixExpression_4Context;
  class DeclarationSpecifierContext;
  class Aux_rule__structDeclarationList_2Context;
  class Aux_rule__designatorList_2Context;
  class StatementContext;
  class Aux_rule__blockItemList_2Context;
  class Aux_rule__translationUnit_2Context;
  class Altnt_block__unaryExpression_3Context;
  class Altnt_block__unaryExpression_4Context;
  class Altnt_block__typeSpecifier_2Context;
  class Altnt_block__specifierQualifierList_3Context;
  class Altnt_block__pointer_8Context;
  class Altnt_block__directDeclarator_12Context;
  class Altnt_block__parameterDeclaration_2Context;
  class Altnt_block__directAbstractDeclarator_20Context;
  class Altnt_block__iterationStatement_8Context;
  class Altnt_block__statement_1Context;
  class Altnt_block__statement_2Context;
  class Aux_rule__unaryExpression_5Context;
  class Aux_rule__unaryExpression_6Context;
  class Aux_rule__unaryExpression_7Context;
  class Aux_rule__unaryExpression_8Context;
  class Aux_rule__castExpression_2Context;
  class Aux_rule__assignmentExpression_1Context;
  class Aux_rule__declaration_3Context;
  class Aux_rule__typeSpecifier_3Context;
  class Aux_rule__structDeclarator_2Context;
  class Aux_rule__gccDeclaratorExtension_2Context;
  class Aux_rule__abstractDeclarator_3Context;
  class Aux_rule__initializer_2Context;
  class Aux_rule__postfixExpression_10Context;
  class Aux_rule__postfixExpression_11Context;
  class Aux_rule__postfixExpression_12Context;
  class Aux_rule__directDeclarator_13Context;
  class Aux_rule__directDeclarator_14Context;
  class Aux_rule__directDeclarator_15Context;
  class Aux_rule__directAbstractDeclarator_21Context;
  class Aux_rule__directAbstractDeclarator_22Context;
  class Aux_rule__directAbstractDeclarator_23Context;
  class Aux_rule__directAbstractDeclarator_24Context;
  class Aux_rule__primaryExpression_4Context;
  class Aux_rule__primaryExpression_5Context;
  class Aux_rule__primaryExpression_6Context;
  class Aux_rule__primaryExpression_7Context;
  class Aux_rule__unaryExpression_9Context;
  class Aux_rule__unaryExpression_10Context;
  class Aux_rule__typeSpecifier_4Context;
  class Aux_rule__typeSpecifier_5Context;
  class Aux_rule__structOrUnionSpecifier_3Context;
  class Aux_rule__enumSpecifier_6Context;
  class Aux_rule__directDeclarator_16Context;
  class Aux_rule__directDeclarator_17Context;
  class Aux_rule__directAbstractDeclarator_25Context;
  class Aux_rule__directAbstractDeclarator_26Context;
  class Aux_rule__labeledStatement_2Context;
  class Aux_rule__jumpStatement_4Context;
  class Aux_rule__jumpStatement_5Context;
  class Aux_rule__directDeclarator_18Context;
  class Aux_rule__directDeclarator_19Context;
  class Aux_rule__postfixExpression_13Context;
  class Aux_rule__postfixExpression_14Context;
  class Aux_rule__declarationSpecifier_1Context;
  class Aux_rule__structDeclarationList_4Context;
  class Aux_rule__designatorList_4Context;
  class Aux_rule__designatorList_5Context;
  class Aux_rule__statement_3Context;
  class Aux_rule__statement_4Context;
  class Aux_rule__statement_5Context;
  class Aux_rule__iterationStatement_9Context;
  class Aux_rule__statement_6Context;
  class Aux_rule__statement_7Context; 

  class  GenericSelectionContext : public antlr4::ParserRuleContext {
  public:
    GenericSelectionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Generic();
    antlr4::tree::TerminalNode *LeftParen();
    AssignmentExpressionContext *assignmentExpression();
    antlr4::tree::TerminalNode *Comma();
    GenericAssocListContext *genericAssocList();
    antlr4::tree::TerminalNode *RightParen();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  GenericSelectionContext* genericSelection();

  class  GenericAssociationContext : public antlr4::ParserRuleContext {
  public:
    GenericAssociationContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__genericAssociation_1Context *altnt_block__genericAssociation_1();
    antlr4::tree::TerminalNode *Colon();
    AssignmentExpressionContext *assignmentExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  GenericAssociationContext* genericAssociation();

  class  UnaryExpressionContext : public antlr4::ParserRuleContext {
  public:
    UnaryExpressionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    PostfixExpressionContext *postfixExpression();
    Aux_rule__unaryExpression_5Context *aux_rule__unaryExpression_5();
    Aux_rule__unaryExpression_6Context *aux_rule__unaryExpression_6();
    Aux_rule__unaryExpression_7Context *aux_rule__unaryExpression_7();
    Aux_rule__unaryExpression_8Context *aux_rule__unaryExpression_8();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  UnaryExpressionContext* unaryExpression();

  class  UnaryOperatorContext : public antlr4::ParserRuleContext {
  public:
    UnaryOperatorContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *And();
    antlr4::tree::TerminalNode *Star();
    antlr4::tree::TerminalNode *Plus();
    antlr4::tree::TerminalNode *Minus();
    antlr4::tree::TerminalNode *Tilde();
    antlr4::tree::TerminalNode *Not();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  UnaryOperatorContext* unaryOperator();

  class  CastExpressionContext : public antlr4::ParserRuleContext {
  public:
    CastExpressionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    UnaryExpressionContext *unaryExpression();
    Aux_rule__castExpression_2Context *aux_rule__castExpression_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  CastExpressionContext* castExpression();

  class  ConditionalExpressionContext : public antlr4::ParserRuleContext {
  public:
    ConditionalExpressionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    LogicalOrExpressionContext *logicalOrExpression();
    Optional__conditionalExpression_2Context *optional__conditionalExpression_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ConditionalExpressionContext* conditionalExpression();

  class  AssignmentExpressionContext : public antlr4::ParserRuleContext {
  public:
    AssignmentExpressionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ConditionalExpressionContext *conditionalExpression();
    Aux_rule__assignmentExpression_1Context *aux_rule__assignmentExpression_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  AssignmentExpressionContext* assignmentExpression();

  class  AssignmentOperatorContext : public antlr4::ParserRuleContext {
  public:
    AssignmentOperatorContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Assign();
    antlr4::tree::TerminalNode *StarAssign();
    antlr4::tree::TerminalNode *DivAssign();
    antlr4::tree::TerminalNode *ModAssign();
    antlr4::tree::TerminalNode *PlusAssign();
    antlr4::tree::TerminalNode *MinusAssign();
    antlr4::tree::TerminalNode *LeftShiftAssign();
    antlr4::tree::TerminalNode *RightShiftAssign();
    antlr4::tree::TerminalNode *AndAssign();
    antlr4::tree::TerminalNode *XorAssign();
    antlr4::tree::TerminalNode *OrAssign();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  AssignmentOperatorContext* assignmentOperator();

  class  ConstantExpressionContext : public antlr4::ParserRuleContext {
  public:
    ConstantExpressionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ConditionalExpressionContext *conditionalExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ConstantExpressionContext* constantExpression();

  class  DeclarationContext : public antlr4::ParserRuleContext {
  public:
    DeclarationContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__declaration_3Context *aux_rule__declaration_3();
    StaticAssertDeclarationContext *staticAssertDeclaration();
    AsmStatementContext *asmStatement();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  DeclarationContext* declaration();

  class  DeclarationSpecifiersContext : public antlr4::ParserRuleContext {
  public:
    DeclarationSpecifiersContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<DeclarationSpecifierContext *> declarationSpecifier();
    DeclarationSpecifierContext* declarationSpecifier(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  DeclarationSpecifiersContext* declarationSpecifiers();

  class  InitDeclaratorContext : public antlr4::ParserRuleContext {
  public:
    InitDeclaratorContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    DeclaratorContext *declarator();
    Optional__initDeclarator_2Context *optional__initDeclarator_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  InitDeclaratorContext* initDeclarator();

  class  TypeSpecifierContext : public antlr4::ParserRuleContext {
  public:
    TypeSpecifierContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Void();
    antlr4::tree::TerminalNode *Char();
    antlr4::tree::TerminalNode *Short();
    antlr4::tree::TerminalNode *Int();
    antlr4::tree::TerminalNode *Long();
    antlr4::tree::TerminalNode *Float();
    antlr4::tree::TerminalNode *Double();
    antlr4::tree::TerminalNode *Signed();
    antlr4::tree::TerminalNode *Unsigned();
    antlr4::tree::TerminalNode *Bool();
    antlr4::tree::TerminalNode *Complex();
    AtomicTypeSpecifierContext *atomicTypeSpecifier();
    StructOrUnionSpecifierContext *structOrUnionSpecifier();
    EnumSpecifierContext *enumSpecifier();
    TypedefNameContext *typedefName();
    Aux_rule__typeSpecifier_3Context *aux_rule__typeSpecifier_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  TypeSpecifierContext* typeSpecifier();

  class  StructOrUnionSpecifierContext : public antlr4::ParserRuleContext {
  public:
    StructOrUnionSpecifierContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    StructOrUnionContext *structOrUnion();
    Altnt_block__structOrUnionSpecifier_2Context *altnt_block__structOrUnionSpecifier_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  StructOrUnionSpecifierContext* structOrUnionSpecifier();

  class  StructOrUnionContext : public antlr4::ParserRuleContext {
  public:
    StructOrUnionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Struct();
    antlr4::tree::TerminalNode *Union();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  StructOrUnionContext* structOrUnion();

  class  SpecifierQualifierListContext : public antlr4::ParserRuleContext {
  public:
    SpecifierQualifierListContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__specifierQualifierList_3Context *altnt_block__specifierQualifierList_3();
    Optional__specifierQualifierList_1Context *optional__specifierQualifierList_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  SpecifierQualifierListContext* specifierQualifierList();

  class  StructDeclaratorContext : public antlr4::ParserRuleContext {
  public:
    StructDeclaratorContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    DeclaratorContext *declarator();
    Aux_rule__structDeclarator_2Context *aux_rule__structDeclarator_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  StructDeclaratorContext* structDeclarator();

  class  EnumSpecifierContext : public antlr4::ParserRuleContext {
  public:
    EnumSpecifierContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Enum();
    Altnt_block__enumSpecifier_3Context *altnt_block__enumSpecifier_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  EnumSpecifierContext* enumSpecifier();

  class  EnumeratorContext : public antlr4::ParserRuleContext {
  public:
    EnumeratorContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    TypedefNameContext *typedefName();
    Optional__enumerator_2Context *optional__enumerator_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  EnumeratorContext* enumerator();

  class  AtomicTypeSpecifierContext : public antlr4::ParserRuleContext {
  public:
    AtomicTypeSpecifierContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Atomic();
    antlr4::tree::TerminalNode *LeftParen();
    TypeNameContext *typeName();
    antlr4::tree::TerminalNode *RightParen();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  AtomicTypeSpecifierContext* atomicTypeSpecifier();

  class  TypeQualifierContext : public antlr4::ParserRuleContext {
  public:
    TypeQualifierContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Const();
    antlr4::tree::TerminalNode *Restrict();
    antlr4::tree::TerminalNode *Restrict_gcc();
    antlr4::tree::TerminalNode *Restrict_gcc2();
    antlr4::tree::TerminalNode *Volatile();
    antlr4::tree::TerminalNode *Atomic();
    antlr4::tree::TerminalNode *Nonnull();
    antlr4::tree::TerminalNode *Nullable();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  TypeQualifierContext* typeQualifier();

  class  AlignmentSpecifierContext : public antlr4::ParserRuleContext {
  public:
    AlignmentSpecifierContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Alignas();
    antlr4::tree::TerminalNode *LeftParen();
    Altnt_block__alignmentSpecifier_1Context *altnt_block__alignmentSpecifier_1();
    antlr4::tree::TerminalNode *RightParen();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  AlignmentSpecifierContext* alignmentSpecifier();

  class  DeclaratorContext : public antlr4::ParserRuleContext {
  public:
    DeclaratorContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__declarator_1Context *optional__declarator_1();
    DirectDeclaratorContext *directDeclarator();
    Kleene_star__declarator_2Context *kleene_star__declarator_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  DeclaratorContext* declarator();

  class  GccDeclaratorExtensionContext : public antlr4::ParserRuleContext {
  public:
    GccDeclaratorExtensionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__gccDeclaratorExtension_2Context *aux_rule__gccDeclaratorExtension_2();
    GccAttributeSpecifierContext *gccAttributeSpecifier();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  GccDeclaratorExtensionContext* gccDeclaratorExtension();

  class  AsmKeywordContext : public antlr4::ParserRuleContext {
  public:
    AsmKeywordContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  AsmKeywordContext* asmKeyword();

  class  GccAttributeSpecifierContext : public antlr4::ParserRuleContext {
  public:
    GccAttributeSpecifierContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<antlr4::tree::TerminalNode *> LeftParen();
    antlr4::tree::TerminalNode* LeftParen(size_t i);
    GccAttributeListContext *gccAttributeList();
    std::vector<antlr4::tree::TerminalNode *> RightParen();
    antlr4::tree::TerminalNode* RightParen(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  GccAttributeSpecifierContext* gccAttributeSpecifier();

  class  GccAttributeListContext : public antlr4::ParserRuleContext {
  public:
    GccAttributeListContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__gccAttributeList_3Context *aux_rule__gccAttributeList_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  GccAttributeListContext* gccAttributeList();

  class  GccAttributeContext : public antlr4::ParserRuleContext {
  public:
    GccAttributeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__gccAttribute_4Context *aux_rule__gccAttribute_4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  GccAttributeContext* gccAttribute();

  class  PointerContext : public antlr4::ParserRuleContext {
  public:
    PointerContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__pointer_8Context *altnt_block__pointer_8();
    Altnt_block__pointer_5Context *altnt_block__pointer_5();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  PointerContext* pointer();

  class  ParameterTypeListContext : public antlr4::ParserRuleContext {
  public:
    ParameterTypeListContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ParameterListContext *parameterList();
    Optional__parameterTypeList_2Context *optional__parameterTypeList_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ParameterTypeListContext* parameterTypeList();

  class  ParameterDeclarationContext : public antlr4::ParserRuleContext {
  public:
    ParameterDeclarationContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    DeclarationSpecifiersContext *declarationSpecifiers();
    Altnt_block__parameterDeclaration_2Context *altnt_block__parameterDeclaration_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ParameterDeclarationContext* parameterDeclaration();

  class  TypeNameContext : public antlr4::ParserRuleContext {
  public:
    TypeNameContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    SpecifierQualifierListContext *specifierQualifierList();
    Optional__typeName_1Context *optional__typeName_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  TypeNameContext* typeName();

  class  AbstractDeclaratorContext : public antlr4::ParserRuleContext {
  public:
    AbstractDeclaratorContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    PointerContext *pointer();
    Aux_rule__abstractDeclarator_3Context *aux_rule__abstractDeclarator_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  AbstractDeclaratorContext* abstractDeclarator();

  class  TypedefNameContext : public antlr4::ParserRuleContext {
  public:
    TypedefNameContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Identifier();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  TypedefNameContext* typedefName();

  class  InitializerContext : public antlr4::ParserRuleContext {
  public:
    InitializerContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    AssignmentExpressionContext *assignmentExpression();
    Aux_rule__initializer_2Context *aux_rule__initializer_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  InitializerContext* initializer();

  class  DesignationContext : public antlr4::ParserRuleContext {
  public:
    DesignationContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    DesignatorListContext *designatorList();
    antlr4::tree::TerminalNode *Assign();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  DesignationContext* designation();

  class  StaticAssertDeclarationContext : public antlr4::ParserRuleContext {
  public:
    StaticAssertDeclarationContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *StaticAssert();
    antlr4::tree::TerminalNode *LeftParen();
    ConstantExpressionContext *constantExpression();
    antlr4::tree::TerminalNode *Comma();
    Kleene_plus__primaryExpression_1Context *kleene_plus__primaryExpression_1();
    antlr4::tree::TerminalNode *RightParen();
    antlr4::tree::TerminalNode *Semi();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  StaticAssertDeclarationContext* staticAssertDeclaration();

  class  AsmStatementContext : public antlr4::ParserRuleContext {
  public:
    AsmStatementContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    AsmKeywordContext *asmKeyword();
    Optional__asmStatement_2Context *optional__asmStatement_2();
    antlr4::tree::TerminalNode *LeftParen();
    Optional__asmStatement_6Context *optional__asmStatement_6();
    Kleene_star__asmStatement_12Context *kleene_star__asmStatement_12();
    antlr4::tree::TerminalNode *RightParen();
    antlr4::tree::TerminalNode *Semi();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  AsmStatementContext* asmStatement();

  class  LabeledStatementContext : public antlr4::ParserRuleContext {
  public:
    LabeledStatementContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__labeledStatement_1Context *altnt_block__labeledStatement_1();
    antlr4::tree::TerminalNode *Colon();
    StatementContext *statement();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  LabeledStatementContext* labeledStatement();

  class  CompoundStatementContext : public antlr4::ParserRuleContext {
  public:
    CompoundStatementContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LeftBrace();
    Optional__compoundStatement_1Context *optional__compoundStatement_1();
    antlr4::tree::TerminalNode *RightBrace();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  CompoundStatementContext* compoundStatement();

  class  ExpressionStatementContext : public antlr4::ParserRuleContext {
  public:
    ExpressionStatementContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__postfixExpression_1Context *optional__postfixExpression_1();
    antlr4::tree::TerminalNode *Semi();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ExpressionStatementContext* expressionStatement();

  class  JumpStatementContext : public antlr4::ParserRuleContext {
  public:
    JumpStatementContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__jumpStatement_2Context *altnt_block__jumpStatement_2();
    antlr4::tree::TerminalNode *Semi();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  JumpStatementContext* jumpStatement();

  class  CompilationUnitContext : public antlr4::ParserRuleContext {
  public:
    CompilationUnitContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__compilationUnit_1Context *optional__compilationUnit_1();
    antlr4::tree::TerminalNode *EOF();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  CompilationUnitContext* compilationUnit();

  class  FunctionDefinitionContext : public antlr4::ParserRuleContext {
  public:
    FunctionDefinitionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__declaration_1Context *optional__declaration_1();
    Optional__functionDefinition_2Context *optional__functionDefinition_2();
    DeclaratorContext *declarator();
    Optional__functionDefinition_3Context *optional__functionDefinition_3();
    CompoundStatementContext *compoundStatement();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  FunctionDefinitionContext* functionDefinition();

  class  Kleene_plus__primaryExpression_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_plus__primaryExpression_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<antlr4::tree::TerminalNode *> StringLiteral();
    antlr4::tree::TerminalNode* StringLiteral(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_plus__primaryExpression_1Context* kleene_plus__primaryExpression_1();

  class  Optional__primaryExpression_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__primaryExpression_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Extension_gcc();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__primaryExpression_2Context* optional__primaryExpression_2();

  class  Optional__postfixExpression_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__postfixExpression_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ExpressionContext *expression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__postfixExpression_1Context* optional__postfixExpression_1();

  class  Aux_rule__conditionalExpression_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__conditionalExpression_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Question();
    ExpressionContext *expression();
    antlr4::tree::TerminalNode *Colon();
    ConditionalExpressionContext *conditionalExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__conditionalExpression_1Context* aux_rule__conditionalExpression_1();

  class  Optional__conditionalExpression_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__conditionalExpression_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__conditionalExpression_1Context *aux_rule__conditionalExpression_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__conditionalExpression_2Context* optional__conditionalExpression_2();

  class  Optional__declaration_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__declaration_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Extension_gcc();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__declaration_1Context* optional__declaration_1();

  class  Optional__declaration_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__declaration_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    InitDeclaratorListContext *initDeclaratorList();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__declaration_2Context* optional__declaration_2();

  class  Optional__structOrUnionSpecifier_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__structOrUnionSpecifier_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Identifier();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__structOrUnionSpecifier_1Context* optional__structOrUnionSpecifier_1();

  class  Optional__structDeclaration_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__structDeclaration_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    StructDeclaratorListContext *structDeclaratorList();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__structDeclaration_2Context* optional__structDeclaration_2();

  class  Optional__specifierQualifierList_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__specifierQualifierList_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    SpecifierQualifierListContext *specifierQualifierList();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__specifierQualifierList_1Context* optional__specifierQualifierList_1();

  class  Optional__structDeclarator_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__structDeclarator_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    DeclaratorContext *declarator();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__structDeclarator_1Context* optional__structDeclarator_1();

  class  Optional__declarator_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__declarator_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    PointerContext *pointer();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__declarator_1Context* optional__declarator_1();

  class  Kleene_star__declarator_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__declarator_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<GccDeclaratorExtensionContext *> gccDeclaratorExtension();
    GccDeclaratorExtensionContext* gccDeclaratorExtension(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__declarator_2Context* kleene_star__declarator_2();

  class  Optional__directDeclarator_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__directDeclarator_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    AssignmentExpressionContext *assignmentExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__directDeclarator_2Context* optional__directDeclarator_2();

  class  Optional__directDeclarator_5Context : public antlr4::ParserRuleContext {
  public:
    Optional__directDeclarator_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    IdentifierListContext *identifierList();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__directDeclarator_5Context* optional__directDeclarator_5();

  class  Aux_rule__gccAttributeList_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__gccAttributeList_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Comma();
    GccAttributeContext *gccAttribute();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__gccAttributeList_1Context* aux_rule__gccAttributeList_1();

  class  Kleene_star__gccAttributeList_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__gccAttributeList_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__gccAttributeList_1Context *> aux_rule__gccAttributeList_1();
    Aux_rule__gccAttributeList_1Context* aux_rule__gccAttributeList_1(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__gccAttributeList_2Context* kleene_star__gccAttributeList_2();

  class  Aux_rule__gccAttributeList_3Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__gccAttributeList_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    GccAttributeContext *gccAttribute();
    Kleene_star__gccAttributeList_2Context *kleene_star__gccAttributeList_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__gccAttributeList_3Context* aux_rule__gccAttributeList_3();

  class  Aux_rule__gccAttribute_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__gccAttribute_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LeftParen();
    Optional__postfixExpression_1Context *optional__postfixExpression_1();
    antlr4::tree::TerminalNode *RightParen();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__gccAttribute_2Context* aux_rule__gccAttribute_2();

  class  Optional__gccAttribute_3Context : public antlr4::ParserRuleContext {
  public:
    Optional__gccAttribute_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__gccAttribute_2Context *aux_rule__gccAttribute_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__gccAttribute_3Context* optional__gccAttribute_3();

  class  Aux_rule__gccAttribute_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__gccAttribute_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__gccAttribute_3Context *optional__gccAttribute_3();
    antlr4::tree::TerminalNode *Comma();
    antlr4::tree::TerminalNode *LeftParen();
    antlr4::tree::TerminalNode *RightParen();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__gccAttribute_4Context* aux_rule__gccAttribute_4();

  class  Optional__pointer_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__pointer_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    TypeQualifierListContext *typeQualifierList();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__pointer_1Context* optional__pointer_1();

  class  Optional__typeName_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__typeName_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    AbstractDeclaratorContext *abstractDeclarator();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__typeName_1Context* optional__typeName_1();

  class  Optional__directAbstractDeclarator_5Context : public antlr4::ParserRuleContext {
  public:
    Optional__directAbstractDeclarator_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ParameterTypeListContext *parameterTypeList();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__directAbstractDeclarator_5Context* optional__directAbstractDeclarator_5();

  class  Optional__initializerList_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__initializerList_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    DesignationContext *designation();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__initializerList_1Context* optional__initializerList_1();

  class  Aux_rule__asmStatement_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__asmStatement_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Volatile();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__asmStatement_1Context* aux_rule__asmStatement_1();

  class  Optional__asmStatement_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__asmStatement_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__asmStatement_1Context *aux_rule__asmStatement_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__asmStatement_2Context* optional__asmStatement_2();

  class  Aux_rule__asmStatement_3Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__asmStatement_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Comma();
    LogicalOrExpressionContext *logicalOrExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__asmStatement_3Context* aux_rule__asmStatement_3();

  class  Kleene_star__asmStatement_4Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__asmStatement_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__asmStatement_3Context *> aux_rule__asmStatement_3();
    Aux_rule__asmStatement_3Context* aux_rule__asmStatement_3(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__asmStatement_4Context* kleene_star__asmStatement_4();

  class  Aux_rule__asmStatement_5Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__asmStatement_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    LogicalOrExpressionContext *logicalOrExpression();
    Kleene_star__asmStatement_4Context *kleene_star__asmStatement_4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__asmStatement_5Context* aux_rule__asmStatement_5();

  class  Optional__asmStatement_6Context : public antlr4::ParserRuleContext {
  public:
    Optional__asmStatement_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__asmStatement_5Context *aux_rule__asmStatement_5();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__asmStatement_6Context* optional__asmStatement_6();

  class  Aux_rule__asmStatement_11Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__asmStatement_11Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Colon();
    Optional__asmStatement_6Context *optional__asmStatement_6();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__asmStatement_11Context* aux_rule__asmStatement_11();

  class  Kleene_star__asmStatement_12Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__asmStatement_12Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__asmStatement_11Context *> aux_rule__asmStatement_11();
    Aux_rule__asmStatement_11Context* aux_rule__asmStatement_11(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__asmStatement_12Context* kleene_star__asmStatement_12();

  class  Optional__compoundStatement_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__compoundStatement_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    BlockItemListContext *blockItemList();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__compoundStatement_1Context* optional__compoundStatement_1();

  class  Aux_rule__selectionStatement_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__selectionStatement_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Else();
    StatementContext *statement();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__selectionStatement_1Context* aux_rule__selectionStatement_1();

  class  Optional__selectionStatement_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__selectionStatement_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__selectionStatement_1Context *aux_rule__selectionStatement_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__selectionStatement_2Context* optional__selectionStatement_2();

  class  Optional__compilationUnit_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__compilationUnit_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    TranslationUnitContext *translationUnit();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__compilationUnit_1Context* optional__compilationUnit_1();

  class  Optional__functionDefinition_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__functionDefinition_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    DeclarationSpecifiersContext *declarationSpecifiers();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__functionDefinition_2Context* optional__functionDefinition_2();

  class  Optional__functionDefinition_3Context : public antlr4::ParserRuleContext {
  public:
    Optional__functionDefinition_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    DeclarationListContext *declarationList();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__functionDefinition_3Context* optional__functionDefinition_3();

  class  Aux_rule__expression_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__expression_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Comma();
    AssignmentExpressionContext *assignmentExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__expression_2Context* aux_rule__expression_2();

  class  Kleene_star__expression_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__expression_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__expression_2Context *> aux_rule__expression_2();
    Aux_rule__expression_2Context* aux_rule__expression_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__expression_1Context* kleene_star__expression_1();

  class  ExpressionContext : public antlr4::ParserRuleContext {
  public:
    ExpressionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    AssignmentExpressionContext *assignmentExpression();
    Kleene_star__expression_1Context *kleene_star__expression_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ExpressionContext* expression();

  class  Aux_rule__genericAssocList_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__genericAssocList_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Comma();
    GenericAssociationContext *genericAssociation();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__genericAssocList_2Context* aux_rule__genericAssocList_2();

  class  Kleene_star__genericAssocList_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__genericAssocList_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__genericAssocList_2Context *> aux_rule__genericAssocList_2();
    Aux_rule__genericAssocList_2Context* aux_rule__genericAssocList_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__genericAssocList_1Context* kleene_star__genericAssocList_1();

  class  GenericAssocListContext : public antlr4::ParserRuleContext {
  public:
    GenericAssocListContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    GenericAssociationContext *genericAssociation();
    Kleene_star__genericAssocList_1Context *kleene_star__genericAssocList_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  GenericAssocListContext* genericAssocList();

  class  Aux_rule__postfixExpression_3Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__postfixExpression_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__postfixExpression_10Context *aux_rule__postfixExpression_10();
    Aux_rule__postfixExpression_11Context *aux_rule__postfixExpression_11();
    antlr4::tree::TerminalNode *PlusPlus();
    antlr4::tree::TerminalNode *MinusMinus();
    Aux_rule__postfixExpression_12Context *aux_rule__postfixExpression_12();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__postfixExpression_3Context* aux_rule__postfixExpression_3();

  class  Kleene_star__postfixExpression_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__postfixExpression_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__postfixExpression_3Context *> aux_rule__postfixExpression_3();
    Aux_rule__postfixExpression_3Context* aux_rule__postfixExpression_3(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__postfixExpression_2Context* kleene_star__postfixExpression_2();

  class  PostfixExpressionContext : public antlr4::ParserRuleContext {
  public:
    PostfixExpressionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__postfixExpression_4Context *aux_rule__postfixExpression_4();
    Kleene_star__postfixExpression_2Context *kleene_star__postfixExpression_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  PostfixExpressionContext* postfixExpression();

  class  Aux_rule__initializerList_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__initializerList_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Comma();
    Optional__initializerList_1Context *optional__initializerList_1();
    InitializerContext *initializer();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__initializerList_4Context* aux_rule__initializerList_4();

  class  Kleene_star__initializerList_3Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__initializerList_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__initializerList_4Context *> aux_rule__initializerList_4();
    Aux_rule__initializerList_4Context* aux_rule__initializerList_4(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__initializerList_3Context* kleene_star__initializerList_3();

  class  InitializerListContext : public antlr4::ParserRuleContext {
  public:
    InitializerListContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__initializerList_1Context *optional__initializerList_1();
    InitializerContext *initializer();
    Kleene_star__initializerList_3Context *kleene_star__initializerList_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  InitializerListContext* initializerList();

  class  Aux_rule__multiplicativeExpression_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__multiplicativeExpression_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__multiplicativeExpression_3Context *altnt_block__multiplicativeExpression_3();
    CastExpressionContext *castExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__multiplicativeExpression_2Context* aux_rule__multiplicativeExpression_2();

  class  Kleene_star__multiplicativeExpression_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__multiplicativeExpression_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__multiplicativeExpression_2Context *> aux_rule__multiplicativeExpression_2();
    Aux_rule__multiplicativeExpression_2Context* aux_rule__multiplicativeExpression_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__multiplicativeExpression_1Context* kleene_star__multiplicativeExpression_1();

  class  MultiplicativeExpressionContext : public antlr4::ParserRuleContext {
  public:
    MultiplicativeExpressionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    CastExpressionContext *castExpression();
    Kleene_star__multiplicativeExpression_1Context *kleene_star__multiplicativeExpression_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  MultiplicativeExpressionContext* multiplicativeExpression();

  class  Aux_rule__additiveExpression_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__additiveExpression_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__additiveExpression_3Context *altnt_block__additiveExpression_3();
    MultiplicativeExpressionContext *multiplicativeExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__additiveExpression_2Context* aux_rule__additiveExpression_2();

  class  Kleene_star__additiveExpression_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__additiveExpression_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__additiveExpression_2Context *> aux_rule__additiveExpression_2();
    Aux_rule__additiveExpression_2Context* aux_rule__additiveExpression_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__additiveExpression_1Context* kleene_star__additiveExpression_1();

  class  AdditiveExpressionContext : public antlr4::ParserRuleContext {
  public:
    AdditiveExpressionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    MultiplicativeExpressionContext *multiplicativeExpression();
    Kleene_star__additiveExpression_1Context *kleene_star__additiveExpression_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  AdditiveExpressionContext* additiveExpression();

  class  Aux_rule__shiftExpression_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__shiftExpression_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__shiftExpression_3Context *altnt_block__shiftExpression_3();
    AdditiveExpressionContext *additiveExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__shiftExpression_2Context* aux_rule__shiftExpression_2();

  class  Kleene_star__shiftExpression_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__shiftExpression_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__shiftExpression_2Context *> aux_rule__shiftExpression_2();
    Aux_rule__shiftExpression_2Context* aux_rule__shiftExpression_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__shiftExpression_1Context* kleene_star__shiftExpression_1();

  class  ShiftExpressionContext : public antlr4::ParserRuleContext {
  public:
    ShiftExpressionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    AdditiveExpressionContext *additiveExpression();
    Kleene_star__shiftExpression_1Context *kleene_star__shiftExpression_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ShiftExpressionContext* shiftExpression();

  class  Aux_rule__relationalExpression_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__relationalExpression_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__relationalExpression_3Context *altnt_block__relationalExpression_3();
    ShiftExpressionContext *shiftExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__relationalExpression_2Context* aux_rule__relationalExpression_2();

  class  Kleene_star__relationalExpression_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__relationalExpression_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__relationalExpression_2Context *> aux_rule__relationalExpression_2();
    Aux_rule__relationalExpression_2Context* aux_rule__relationalExpression_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__relationalExpression_1Context* kleene_star__relationalExpression_1();

  class  RelationalExpressionContext : public antlr4::ParserRuleContext {
  public:
    RelationalExpressionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ShiftExpressionContext *shiftExpression();
    Kleene_star__relationalExpression_1Context *kleene_star__relationalExpression_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  RelationalExpressionContext* relationalExpression();

  class  Aux_rule__equalityExpression_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__equalityExpression_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__equalityExpression_3Context *altnt_block__equalityExpression_3();
    RelationalExpressionContext *relationalExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__equalityExpression_2Context* aux_rule__equalityExpression_2();

  class  Kleene_star__equalityExpression_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__equalityExpression_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__equalityExpression_2Context *> aux_rule__equalityExpression_2();
    Aux_rule__equalityExpression_2Context* aux_rule__equalityExpression_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__equalityExpression_1Context* kleene_star__equalityExpression_1();

  class  EqualityExpressionContext : public antlr4::ParserRuleContext {
  public:
    EqualityExpressionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    RelationalExpressionContext *relationalExpression();
    Kleene_star__equalityExpression_1Context *kleene_star__equalityExpression_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  EqualityExpressionContext* equalityExpression();

  class  Aux_rule__andExpression_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__andExpression_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *And();
    EqualityExpressionContext *equalityExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__andExpression_2Context* aux_rule__andExpression_2();

  class  Kleene_star__andExpression_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__andExpression_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__andExpression_2Context *> aux_rule__andExpression_2();
    Aux_rule__andExpression_2Context* aux_rule__andExpression_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__andExpression_1Context* kleene_star__andExpression_1();

  class  AndExpressionContext : public antlr4::ParserRuleContext {
  public:
    AndExpressionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    EqualityExpressionContext *equalityExpression();
    Kleene_star__andExpression_1Context *kleene_star__andExpression_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  AndExpressionContext* andExpression();

  class  Aux_rule__exclusiveOrExpression_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__exclusiveOrExpression_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Caret();
    AndExpressionContext *andExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__exclusiveOrExpression_2Context* aux_rule__exclusiveOrExpression_2();

  class  Kleene_star__exclusiveOrExpression_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__exclusiveOrExpression_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__exclusiveOrExpression_2Context *> aux_rule__exclusiveOrExpression_2();
    Aux_rule__exclusiveOrExpression_2Context* aux_rule__exclusiveOrExpression_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__exclusiveOrExpression_1Context* kleene_star__exclusiveOrExpression_1();

  class  ExclusiveOrExpressionContext : public antlr4::ParserRuleContext {
  public:
    ExclusiveOrExpressionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    AndExpressionContext *andExpression();
    Kleene_star__exclusiveOrExpression_1Context *kleene_star__exclusiveOrExpression_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ExclusiveOrExpressionContext* exclusiveOrExpression();

  class  Aux_rule__inclusiveOrExpression_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__inclusiveOrExpression_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Or();
    ExclusiveOrExpressionContext *exclusiveOrExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__inclusiveOrExpression_2Context* aux_rule__inclusiveOrExpression_2();

  class  Kleene_star__inclusiveOrExpression_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__inclusiveOrExpression_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__inclusiveOrExpression_2Context *> aux_rule__inclusiveOrExpression_2();
    Aux_rule__inclusiveOrExpression_2Context* aux_rule__inclusiveOrExpression_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__inclusiveOrExpression_1Context* kleene_star__inclusiveOrExpression_1();

  class  InclusiveOrExpressionContext : public antlr4::ParserRuleContext {
  public:
    InclusiveOrExpressionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ExclusiveOrExpressionContext *exclusiveOrExpression();
    Kleene_star__inclusiveOrExpression_1Context *kleene_star__inclusiveOrExpression_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  InclusiveOrExpressionContext* inclusiveOrExpression();

  class  Aux_rule__logicalAndExpression_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__logicalAndExpression_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *AndAnd();
    InclusiveOrExpressionContext *inclusiveOrExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__logicalAndExpression_2Context* aux_rule__logicalAndExpression_2();

  class  Kleene_star__logicalAndExpression_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__logicalAndExpression_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__logicalAndExpression_2Context *> aux_rule__logicalAndExpression_2();
    Aux_rule__logicalAndExpression_2Context* aux_rule__logicalAndExpression_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__logicalAndExpression_1Context* kleene_star__logicalAndExpression_1();

  class  LogicalAndExpressionContext : public antlr4::ParserRuleContext {
  public:
    LogicalAndExpressionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    InclusiveOrExpressionContext *inclusiveOrExpression();
    Kleene_star__logicalAndExpression_1Context *kleene_star__logicalAndExpression_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  LogicalAndExpressionContext* logicalAndExpression();

  class  Aux_rule__logicalOrExpression_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__logicalOrExpression_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *OrOr();
    LogicalAndExpressionContext *logicalAndExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__logicalOrExpression_2Context* aux_rule__logicalOrExpression_2();

  class  Kleene_star__logicalOrExpression_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__logicalOrExpression_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__logicalOrExpression_2Context *> aux_rule__logicalOrExpression_2();
    Aux_rule__logicalOrExpression_2Context* aux_rule__logicalOrExpression_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__logicalOrExpression_1Context* kleene_star__logicalOrExpression_1();

  class  LogicalOrExpressionContext : public antlr4::ParserRuleContext {
  public:
    LogicalOrExpressionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    LogicalAndExpressionContext *logicalAndExpression();
    Kleene_star__logicalOrExpression_1Context *kleene_star__logicalOrExpression_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  LogicalOrExpressionContext* logicalOrExpression();

  class  Aux_rule__initDeclaratorList_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__initDeclaratorList_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Comma();
    InitDeclaratorContext *initDeclarator();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__initDeclaratorList_2Context* aux_rule__initDeclaratorList_2();

  class  Kleene_star__initDeclaratorList_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__initDeclaratorList_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__initDeclaratorList_2Context *> aux_rule__initDeclaratorList_2();
    Aux_rule__initDeclaratorList_2Context* aux_rule__initDeclaratorList_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__initDeclaratorList_1Context* kleene_star__initDeclaratorList_1();

  class  InitDeclaratorListContext : public antlr4::ParserRuleContext {
  public:
    InitDeclaratorListContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    InitDeclaratorContext *initDeclarator();
    Kleene_star__initDeclaratorList_1Context *kleene_star__initDeclaratorList_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  InitDeclaratorListContext* initDeclaratorList();

  class  StructDeclarationListContext : public antlr4::ParserRuleContext {
  public:
    StructDeclarationListContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_plus__structDeclarationList_3Context *kleene_plus__structDeclarationList_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  StructDeclarationListContext* structDeclarationList();

  class  Aux_rule__structDeclaratorList_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__structDeclaratorList_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Comma();
    StructDeclaratorContext *structDeclarator();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__structDeclaratorList_2Context* aux_rule__structDeclaratorList_2();

  class  Kleene_star__structDeclaratorList_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__structDeclaratorList_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__structDeclaratorList_2Context *> aux_rule__structDeclaratorList_2();
    Aux_rule__structDeclaratorList_2Context* aux_rule__structDeclaratorList_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__structDeclaratorList_1Context* kleene_star__structDeclaratorList_1();

  class  StructDeclaratorListContext : public antlr4::ParserRuleContext {
  public:
    StructDeclaratorListContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    StructDeclaratorContext *structDeclarator();
    Kleene_star__structDeclaratorList_1Context *kleene_star__structDeclaratorList_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  StructDeclaratorListContext* structDeclaratorList();

  class  Aux_rule__enumeratorList_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__enumeratorList_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Comma();
    EnumeratorContext *enumerator();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__enumeratorList_2Context* aux_rule__enumeratorList_2();

  class  Kleene_star__enumeratorList_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__enumeratorList_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__enumeratorList_2Context *> aux_rule__enumeratorList_2();
    Aux_rule__enumeratorList_2Context* aux_rule__enumeratorList_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__enumeratorList_1Context* kleene_star__enumeratorList_1();

  class  EnumeratorListContext : public antlr4::ParserRuleContext {
  public:
    EnumeratorListContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    EnumeratorContext *enumerator();
    Kleene_star__enumeratorList_1Context *kleene_star__enumeratorList_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  EnumeratorListContext* enumeratorList();

  class  Aux_rule__directDeclarator_7Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__directDeclarator_7Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__directDeclarator_13Context *aux_rule__directDeclarator_13();
    Aux_rule__directDeclarator_14Context *aux_rule__directDeclarator_14();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__directDeclarator_7Context* aux_rule__directDeclarator_7();

  class  Kleene_star__directDeclarator_6Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__directDeclarator_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__directDeclarator_7Context *> aux_rule__directDeclarator_7();
    Aux_rule__directDeclarator_7Context* aux_rule__directDeclarator_7(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__directDeclarator_6Context* kleene_star__directDeclarator_6();

  class  Aux_rule__directDeclarator_8Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__directDeclarator_8Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Identifier();
    Aux_rule__directDeclarator_15Context *aux_rule__directDeclarator_15();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__directDeclarator_8Context* aux_rule__directDeclarator_8();

  class  DirectDeclaratorContext : public antlr4::ParserRuleContext {
  public:
    DirectDeclaratorContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__directDeclarator_8Context *aux_rule__directDeclarator_8();
    Kleene_star__directDeclarator_6Context *kleene_star__directDeclarator_6();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  DirectDeclaratorContext* directDeclarator();

  class  Aux_rule__typeQualifierList_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__typeQualifierList_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    TypeQualifierContext *typeQualifier();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__typeQualifierList_2Context* aux_rule__typeQualifierList_2();

  class  TypeQualifierListContext : public antlr4::ParserRuleContext {
  public:
    TypeQualifierListContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_plus__typeQualifierList_3Context *kleene_plus__typeQualifierList_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  TypeQualifierListContext* typeQualifierList();

  class  Aux_rule__identifierList_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__identifierList_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Comma();
    antlr4::tree::TerminalNode *Identifier();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__identifierList_2Context* aux_rule__identifierList_2();

  class  Kleene_star__identifierList_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__identifierList_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__identifierList_2Context *> aux_rule__identifierList_2();
    Aux_rule__identifierList_2Context* aux_rule__identifierList_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__identifierList_1Context* kleene_star__identifierList_1();

  class  IdentifierListContext : public antlr4::ParserRuleContext {
  public:
    IdentifierListContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Identifier();
    Kleene_star__identifierList_1Context *kleene_star__identifierList_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  IdentifierListContext* identifierList();

  class  Aux_rule__parameterList_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__parameterList_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Comma();
    ParameterDeclarationContext *parameterDeclaration();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__parameterList_2Context* aux_rule__parameterList_2();

  class  Kleene_star__parameterList_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__parameterList_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__parameterList_2Context *> aux_rule__parameterList_2();
    Aux_rule__parameterList_2Context* aux_rule__parameterList_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__parameterList_1Context* kleene_star__parameterList_1();

  class  ParameterListContext : public antlr4::ParserRuleContext {
  public:
    ParameterListContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ParameterDeclarationContext *parameterDeclaration();
    Kleene_star__parameterList_1Context *kleene_star__parameterList_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ParameterListContext* parameterList();

  class  Aux_rule__directAbstractDeclarator_13Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__directAbstractDeclarator_13Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__directAbstractDeclarator_21Context *aux_rule__directAbstractDeclarator_21();
    Aux_rule__directAbstractDeclarator_22Context *aux_rule__directAbstractDeclarator_22();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__directAbstractDeclarator_13Context* aux_rule__directAbstractDeclarator_13();

  class  Kleene_star__directAbstractDeclarator_12Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__directAbstractDeclarator_12Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__directAbstractDeclarator_13Context *> aux_rule__directAbstractDeclarator_13();
    Aux_rule__directAbstractDeclarator_13Context* aux_rule__directAbstractDeclarator_13(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__directAbstractDeclarator_12Context* kleene_star__directAbstractDeclarator_12();

  class  Aux_rule__directAbstractDeclarator_14Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__directAbstractDeclarator_14Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__directAbstractDeclarator_23Context *aux_rule__directAbstractDeclarator_23();
    Aux_rule__directAbstractDeclarator_24Context *aux_rule__directAbstractDeclarator_24();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__directAbstractDeclarator_14Context* aux_rule__directAbstractDeclarator_14();

  class  DirectAbstractDeclaratorContext : public antlr4::ParserRuleContext {
  public:
    DirectAbstractDeclaratorContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__directAbstractDeclarator_14Context *aux_rule__directAbstractDeclarator_14();
    Kleene_star__directAbstractDeclarator_12Context *kleene_star__directAbstractDeclarator_12();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  DirectAbstractDeclaratorContext* directAbstractDeclarator();

  class  DesignatorListContext : public antlr4::ParserRuleContext {
  public:
    DesignatorListContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_plus__designatorList_3Context *kleene_plus__designatorList_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  DesignatorListContext* designatorList();

  class  BlockItemListContext : public antlr4::ParserRuleContext {
  public:
    BlockItemListContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_plus__blockItemList_3Context *kleene_plus__blockItemList_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  BlockItemListContext* blockItemList();

  class  TranslationUnitContext : public antlr4::ParserRuleContext {
  public:
    TranslationUnitContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_plus__translationUnit_3Context *kleene_plus__translationUnit_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  TranslationUnitContext* translationUnit();

  class  Aux_rule__declarationList_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__declarationList_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    DeclarationContext *declaration();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__declarationList_2Context* aux_rule__declarationList_2();

  class  DeclarationListContext : public antlr4::ParserRuleContext {
  public:
    DeclarationListContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_plus__declarationList_3Context *kleene_plus__declarationList_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  DeclarationListContext* declarationList();

  class  Kleene_plus__structDeclarationList_3Context : public antlr4::ParserRuleContext {
  public:
    Kleene_plus__structDeclarationList_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__structDeclarationList_2Context *> aux_rule__structDeclarationList_2();
    Aux_rule__structDeclarationList_2Context* aux_rule__structDeclarationList_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_plus__structDeclarationList_3Context* kleene_plus__structDeclarationList_3();

  class  Kleene_plus__typeQualifierList_3Context : public antlr4::ParserRuleContext {
  public:
    Kleene_plus__typeQualifierList_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__typeQualifierList_2Context *> aux_rule__typeQualifierList_2();
    Aux_rule__typeQualifierList_2Context* aux_rule__typeQualifierList_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_plus__typeQualifierList_3Context* kleene_plus__typeQualifierList_3();

  class  Kleene_plus__designatorList_3Context : public antlr4::ParserRuleContext {
  public:
    Kleene_plus__designatorList_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__designatorList_2Context *> aux_rule__designatorList_2();
    Aux_rule__designatorList_2Context* aux_rule__designatorList_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_plus__designatorList_3Context* kleene_plus__designatorList_3();

  class  Kleene_plus__blockItemList_3Context : public antlr4::ParserRuleContext {
  public:
    Kleene_plus__blockItemList_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__blockItemList_2Context *> aux_rule__blockItemList_2();
    Aux_rule__blockItemList_2Context* aux_rule__blockItemList_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_plus__blockItemList_3Context* kleene_plus__blockItemList_3();

  class  Kleene_plus__translationUnit_3Context : public antlr4::ParserRuleContext {
  public:
    Kleene_plus__translationUnit_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__translationUnit_2Context *> aux_rule__translationUnit_2();
    Aux_rule__translationUnit_2Context* aux_rule__translationUnit_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_plus__translationUnit_3Context* kleene_plus__translationUnit_3();

  class  Kleene_plus__declarationList_3Context : public antlr4::ParserRuleContext {
  public:
    Kleene_plus__declarationList_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__declarationList_2Context *> aux_rule__declarationList_2();
    Aux_rule__declarationList_2Context* aux_rule__declarationList_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_plus__declarationList_3Context* kleene_plus__declarationList_3();

  class  Optional__postfixExpression_5Context : public antlr4::ParserRuleContext {
  public:
    Optional__postfixExpression_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Comma();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__postfixExpression_5Context* optional__postfixExpression_5();

  class  Aux_rule__initDeclarator_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__initDeclarator_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Assign();
    InitializerContext *initializer();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__initDeclarator_1Context* aux_rule__initDeclarator_1();

  class  Optional__initDeclarator_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__initDeclarator_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__initDeclarator_1Context *aux_rule__initDeclarator_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__initDeclarator_2Context* optional__initDeclarator_2();

  class  Aux_rule__enumerator_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__enumerator_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Assign();
    ConstantExpressionContext *constantExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__enumerator_1Context* aux_rule__enumerator_1();

  class  Optional__enumerator_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__enumerator_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__enumerator_1Context *aux_rule__enumerator_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__enumerator_2Context* optional__enumerator_2();

  class  Aux_rule__parameterTypeList_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__parameterTypeList_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Comma();
    antlr4::tree::TerminalNode *Ellipsis();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__parameterTypeList_1Context* aux_rule__parameterTypeList_1();

  class  Optional__parameterTypeList_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__parameterTypeList_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__parameterTypeList_1Context *aux_rule__parameterTypeList_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__parameterTypeList_2Context* optional__parameterTypeList_2();

  class  Altnt_block__primaryExpression_3Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__primaryExpression_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__primaryExpression_4Context *aux_rule__primaryExpression_4();
    Aux_rule__primaryExpression_5Context *aux_rule__primaryExpression_5();
    Aux_rule__primaryExpression_6Context *aux_rule__primaryExpression_6();
    Aux_rule__primaryExpression_7Context *aux_rule__primaryExpression_7();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__primaryExpression_3Context* altnt_block__primaryExpression_3();

  class  Altnt_block__unaryExpression_1Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__unaryExpression_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *PlusPlus();
    antlr4::tree::TerminalNode *MinusMinus();
    antlr4::tree::TerminalNode *Sizeof();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__unaryExpression_1Context* altnt_block__unaryExpression_1();

  class  Altnt_block__unaryExpression_2Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__unaryExpression_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__unaryExpression_9Context *aux_rule__unaryExpression_9();
    Aux_rule__unaryExpression_10Context *aux_rule__unaryExpression_10();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__unaryExpression_2Context* altnt_block__unaryExpression_2();

  class  Altnt_block__genericAssociation_1Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__genericAssociation_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    TypeNameContext *typeName();
    antlr4::tree::TerminalNode *Default();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__genericAssociation_1Context* altnt_block__genericAssociation_1();

  class  Altnt_block__postfixExpression_7Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__postfixExpression_7Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Dot();
    antlr4::tree::TerminalNode *Arrow();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__postfixExpression_7Context* altnt_block__postfixExpression_7();

  class  Altnt_block__postfixExpression_8Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__postfixExpression_8Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__primaryExpression_2Context *optional__primaryExpression_2();
    antlr4::tree::TerminalNode *LeftParen();
    TypeNameContext *typeName();
    antlr4::tree::TerminalNode *RightParen();
    antlr4::tree::TerminalNode *LeftBrace();
    InitializerListContext *initializerList();
    Optional__postfixExpression_5Context *optional__postfixExpression_5();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__postfixExpression_8Context* altnt_block__postfixExpression_8();

  class  Altnt_block__multiplicativeExpression_3Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__multiplicativeExpression_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Star();
    antlr4::tree::TerminalNode *Div();
    antlr4::tree::TerminalNode *Mod();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__multiplicativeExpression_3Context* altnt_block__multiplicativeExpression_3();

  class  Altnt_block__additiveExpression_3Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__additiveExpression_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Plus();
    antlr4::tree::TerminalNode *Minus();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__additiveExpression_3Context* altnt_block__additiveExpression_3();

  class  Altnt_block__shiftExpression_3Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__shiftExpression_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LeftShift();
    antlr4::tree::TerminalNode *RightShift();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__shiftExpression_3Context* altnt_block__shiftExpression_3();

  class  Altnt_block__relationalExpression_3Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__relationalExpression_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Less();
    antlr4::tree::TerminalNode *Greater();
    antlr4::tree::TerminalNode *LessEqual();
    antlr4::tree::TerminalNode *GreaterEqual();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__relationalExpression_3Context* altnt_block__relationalExpression_3();

  class  Altnt_block__equalityExpression_3Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__equalityExpression_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Equal();
    antlr4::tree::TerminalNode *NotEqual();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__equalityExpression_3Context* altnt_block__equalityExpression_3();

  class  Altnt_block__typeSpecifier_1Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__typeSpecifier_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__typeSpecifier_4Context *aux_rule__typeSpecifier_4();
    Aux_rule__typeSpecifier_5Context *aux_rule__typeSpecifier_5();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__typeSpecifier_1Context* altnt_block__typeSpecifier_1();

  class  Altnt_block__alignmentSpecifier_1Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__alignmentSpecifier_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    TypeNameContext *typeName();
    ConstantExpressionContext *constantExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__alignmentSpecifier_1Context* altnt_block__alignmentSpecifier_1();

  class  Altnt_block__structOrUnionSpecifier_2Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__structOrUnionSpecifier_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__structOrUnionSpecifier_3Context *aux_rule__structOrUnionSpecifier_3();
    antlr4::tree::TerminalNode *Identifier();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__structOrUnionSpecifier_2Context* altnt_block__structOrUnionSpecifier_2();

  class  Altnt_block__enumSpecifier_3Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__enumSpecifier_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Identifier();
    Aux_rule__enumSpecifier_6Context *aux_rule__enumSpecifier_6();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__enumSpecifier_3Context* altnt_block__enumSpecifier_3();

  class  Altnt_block__pointer_5Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__pointer_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__pointer_1Context *optional__pointer_1();
    Optional__declarator_1Context *optional__declarator_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__pointer_5Context* altnt_block__pointer_5();

  class  Altnt_block__directDeclarator_9Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__directDeclarator_9Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__directDeclarator_16Context *aux_rule__directDeclarator_16();
    Aux_rule__directDeclarator_17Context *aux_rule__directDeclarator_17();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__directDeclarator_9Context* altnt_block__directDeclarator_9();

  class  Altnt_block__directDeclarator_10Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__directDeclarator_10Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ParameterTypeListContext *parameterTypeList();
    Optional__directDeclarator_5Context *optional__directDeclarator_5();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__directDeclarator_10Context* altnt_block__directDeclarator_10();

  class  Altnt_block__directAbstractDeclarator_15Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__directAbstractDeclarator_15Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__directAbstractDeclarator_25Context *aux_rule__directAbstractDeclarator_25();
    antlr4::tree::TerminalNode *Star();
    Aux_rule__directAbstractDeclarator_26Context *aux_rule__directAbstractDeclarator_26();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__directAbstractDeclarator_15Context* altnt_block__directAbstractDeclarator_15();

  class  Altnt_block__directAbstractDeclarator_17Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__directAbstractDeclarator_17Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__directAbstractDeclarator_20Context *altnt_block__directAbstractDeclarator_20();
    antlr4::tree::TerminalNode *RightParen();
    Kleene_star__declarator_2Context *kleene_star__declarator_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__directAbstractDeclarator_17Context* altnt_block__directAbstractDeclarator_17();

  class  Altnt_block__labeledStatement_1Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__labeledStatement_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Identifier();
    Aux_rule__labeledStatement_2Context *aux_rule__labeledStatement_2();
    antlr4::tree::TerminalNode *Default();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__labeledStatement_1Context* altnt_block__labeledStatement_1();

  class  Altnt_block__jumpStatement_2Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__jumpStatement_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Continue();
    antlr4::tree::TerminalNode *Break();
    Aux_rule__jumpStatement_4Context *aux_rule__jumpStatement_4();
    Aux_rule__jumpStatement_5Context *aux_rule__jumpStatement_5();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__jumpStatement_2Context* altnt_block__jumpStatement_2();

  class  Altnt_block__enumSpecifier_4Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__enumSpecifier_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__structOrUnionSpecifier_1Context *optional__structOrUnionSpecifier_1();
    antlr4::tree::TerminalNode *LeftBrace();
    EnumeratorListContext *enumeratorList();
    Optional__postfixExpression_5Context *optional__postfixExpression_5();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__enumSpecifier_4Context* altnt_block__enumSpecifier_4();

  class  Altnt_block__directDeclarator_11Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__directDeclarator_11Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__directDeclarator_18Context *aux_rule__directDeclarator_18();
    Aux_rule__directDeclarator_19Context *aux_rule__directDeclarator_19();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__directDeclarator_11Context* altnt_block__directDeclarator_11();

  class  Altnt_block__iterationStatement_7Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__iterationStatement_7Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__iterationStatement_8Context *altnt_block__iterationStatement_8();
    std::vector<Optional__postfixExpression_1Context *> optional__postfixExpression_1();
    Optional__postfixExpression_1Context* optional__postfixExpression_1(size_t i);
    antlr4::tree::TerminalNode *Semi();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__iterationStatement_7Context* altnt_block__iterationStatement_7();

  class  Altnt_block__jumpStatement_3Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__jumpStatement_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Identifier();
    UnaryExpressionContext *unaryExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__jumpStatement_3Context* altnt_block__jumpStatement_3();

  class  Aux_rule__postfixExpression_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__postfixExpression_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Identifier();
    antlr4::tree::TerminalNode *Constant();
    Kleene_plus__primaryExpression_1Context *kleene_plus__primaryExpression_1();
    GenericSelectionContext *genericSelection();
    Aux_rule__postfixExpression_13Context *aux_rule__postfixExpression_13();
    Aux_rule__postfixExpression_14Context *aux_rule__postfixExpression_14();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__postfixExpression_4Context* aux_rule__postfixExpression_4();

  class  DeclarationSpecifierContext : public antlr4::ParserRuleContext {
  public:
    DeclarationSpecifierContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Typedef();
    antlr4::tree::TerminalNode *Extern();
    antlr4::tree::TerminalNode *Static();
    antlr4::tree::TerminalNode *ThreadLocal();
    antlr4::tree::TerminalNode *Auto();
    antlr4::tree::TerminalNode *Register();
    TypeSpecifierContext *typeSpecifier();
    TypeQualifierContext *typeQualifier();
    antlr4::tree::TerminalNode *Inline();
    antlr4::tree::TerminalNode *Noreturn();
    GccAttributeSpecifierContext *gccAttributeSpecifier();
    Aux_rule__declarationSpecifier_1Context *aux_rule__declarationSpecifier_1();
    AlignmentSpecifierContext *alignmentSpecifier();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  DeclarationSpecifierContext* declarationSpecifier();

  class  Aux_rule__structDeclarationList_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__structDeclarationList_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__structDeclarationList_4Context *aux_rule__structDeclarationList_4();
    StaticAssertDeclarationContext *staticAssertDeclaration();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__structDeclarationList_2Context* aux_rule__structDeclarationList_2();

  class  Aux_rule__designatorList_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__designatorList_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__designatorList_4Context *aux_rule__designatorList_4();
    Aux_rule__designatorList_5Context *aux_rule__designatorList_5();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__designatorList_2Context* aux_rule__designatorList_2();

  class  StatementContext : public antlr4::ParserRuleContext {
  public:
    StatementContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    LabeledStatementContext *labeledStatement();
    CompoundStatementContext *compoundStatement();
    ExpressionStatementContext *expressionStatement();
    Aux_rule__statement_3Context *aux_rule__statement_3();
    Aux_rule__statement_4Context *aux_rule__statement_4();
    JumpStatementContext *jumpStatement();
    AsmStatementContext *asmStatement();
    Aux_rule__statement_5Context *aux_rule__statement_5();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  StatementContext* statement();

  class  Aux_rule__blockItemList_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__blockItemList_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    DeclarationContext *declaration();
    StatementContext *statement();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__blockItemList_2Context* aux_rule__blockItemList_2();

  class  Aux_rule__translationUnit_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__translationUnit_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    FunctionDefinitionContext *functionDefinition();
    DeclarationContext *declaration();
    antlr4::tree::TerminalNode *IncludeDirective();
    antlr4::tree::TerminalNode *Semi();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__translationUnit_2Context* aux_rule__translationUnit_2();

  class  Altnt_block__unaryExpression_3Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__unaryExpression_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Alignof();
    antlr4::tree::TerminalNode *Alignof_gcc();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__unaryExpression_3Context* altnt_block__unaryExpression_3();

  class  Altnt_block__unaryExpression_4Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__unaryExpression_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    TypeNameContext *typeName();
    UnaryExpressionContext *unaryExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__unaryExpression_4Context* altnt_block__unaryExpression_4();

  class  Altnt_block__typeSpecifier_2Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__typeSpecifier_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__typeSpecifier_2Context* altnt_block__typeSpecifier_2();

  class  Altnt_block__specifierQualifierList_3Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__specifierQualifierList_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    TypeSpecifierContext *typeSpecifier();
    TypeQualifierContext *typeQualifier();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__specifierQualifierList_3Context* altnt_block__specifierQualifierList_3();

  class  Altnt_block__pointer_8Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__pointer_8Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Star();
    antlr4::tree::TerminalNode *Caret();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__pointer_8Context* altnt_block__pointer_8();

  class  Altnt_block__directDeclarator_12Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__directDeclarator_12Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__directDeclarator_2Context *optional__directDeclarator_2();
    antlr4::tree::TerminalNode *Star();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__directDeclarator_12Context* altnt_block__directDeclarator_12();

  class  Altnt_block__parameterDeclaration_2Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__parameterDeclaration_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    DeclaratorContext *declarator();
    Optional__typeName_1Context *optional__typeName_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__parameterDeclaration_2Context* altnt_block__parameterDeclaration_2();

  class  Altnt_block__directAbstractDeclarator_20Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__directAbstractDeclarator_20Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    AbstractDeclaratorContext *abstractDeclarator();
    Optional__directAbstractDeclarator_5Context *optional__directAbstractDeclarator_5();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__directAbstractDeclarator_20Context* altnt_block__directAbstractDeclarator_20();

  class  Altnt_block__iterationStatement_8Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__iterationStatement_8Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__iterationStatement_9Context *aux_rule__iterationStatement_9();
    DeclarationContext *declaration();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__iterationStatement_8Context* altnt_block__iterationStatement_8();

  class  Altnt_block__statement_1Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__statement_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__statement_6Context *aux_rule__statement_6();
    Aux_rule__statement_7Context *aux_rule__statement_7();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__statement_1Context* altnt_block__statement_1();

  class  Altnt_block__statement_2Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__statement_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Switch();
    antlr4::tree::TerminalNode *While();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__statement_2Context* altnt_block__statement_2();

  class  Aux_rule__unaryExpression_5Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__unaryExpression_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    UnaryOperatorContext *unaryOperator();
    CastExpressionContext *castExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__unaryExpression_5Context* aux_rule__unaryExpression_5();

  class  Aux_rule__unaryExpression_6Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__unaryExpression_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *AndAnd();
    antlr4::tree::TerminalNode *Identifier();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__unaryExpression_6Context* aux_rule__unaryExpression_6();

  class  Aux_rule__unaryExpression_7Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__unaryExpression_7Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__unaryExpression_1Context *altnt_block__unaryExpression_1();
    UnaryExpressionContext *unaryExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__unaryExpression_7Context* aux_rule__unaryExpression_7();

  class  Aux_rule__unaryExpression_8Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__unaryExpression_8Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__unaryExpression_2Context *altnt_block__unaryExpression_2();
    antlr4::tree::TerminalNode *RightParen();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__unaryExpression_8Context* aux_rule__unaryExpression_8();

  class  Aux_rule__castExpression_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__castExpression_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__primaryExpression_2Context *optional__primaryExpression_2();
    antlr4::tree::TerminalNode *LeftParen();
    TypeNameContext *typeName();
    antlr4::tree::TerminalNode *RightParen();
    CastExpressionContext *castExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__castExpression_2Context* aux_rule__castExpression_2();

  class  Aux_rule__assignmentExpression_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__assignmentExpression_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    UnaryExpressionContext *unaryExpression();
    AssignmentOperatorContext *assignmentOperator();
    AssignmentExpressionContext *assignmentExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__assignmentExpression_1Context* aux_rule__assignmentExpression_1();

  class  Aux_rule__declaration_3Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__declaration_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__declaration_1Context *optional__declaration_1();
    DeclarationSpecifiersContext *declarationSpecifiers();
    Optional__declaration_2Context *optional__declaration_2();
    antlr4::tree::TerminalNode *Semi();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__declaration_3Context* aux_rule__declaration_3();

  class  Aux_rule__typeSpecifier_3Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__typeSpecifier_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__typeSpecifier_1Context *altnt_block__typeSpecifier_1();
    antlr4::tree::TerminalNode *RightParen();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__typeSpecifier_3Context* aux_rule__typeSpecifier_3();

  class  Aux_rule__structDeclarator_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__structDeclarator_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__structDeclarator_1Context *optional__structDeclarator_1();
    antlr4::tree::TerminalNode *Colon();
    ConstantExpressionContext *constantExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__structDeclarator_2Context* aux_rule__structDeclarator_2();

  class  Aux_rule__gccDeclaratorExtension_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__gccDeclaratorExtension_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    AsmKeywordContext *asmKeyword();
    antlr4::tree::TerminalNode *LeftParen();
    Kleene_plus__primaryExpression_1Context *kleene_plus__primaryExpression_1();
    antlr4::tree::TerminalNode *RightParen();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__gccDeclaratorExtension_2Context* aux_rule__gccDeclaratorExtension_2();

  class  Aux_rule__abstractDeclarator_3Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__abstractDeclarator_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__declarator_1Context *optional__declarator_1();
    DirectAbstractDeclaratorContext *directAbstractDeclarator();
    Kleene_star__declarator_2Context *kleene_star__declarator_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__abstractDeclarator_3Context* aux_rule__abstractDeclarator_3();

  class  Aux_rule__initializer_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__initializer_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LeftBrace();
    InitializerListContext *initializerList();
    Optional__postfixExpression_5Context *optional__postfixExpression_5();
    antlr4::tree::TerminalNode *RightBrace();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__initializer_2Context* aux_rule__initializer_2();

  class  Aux_rule__postfixExpression_10Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__postfixExpression_10Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LeftBracket();
    ExpressionContext *expression();
    antlr4::tree::TerminalNode *RightBracket();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__postfixExpression_10Context* aux_rule__postfixExpression_10();

  class  Aux_rule__postfixExpression_11Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__postfixExpression_11Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LeftParen();
    Optional__postfixExpression_1Context *optional__postfixExpression_1();
    antlr4::tree::TerminalNode *RightParen();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__postfixExpression_11Context* aux_rule__postfixExpression_11();

  class  Aux_rule__postfixExpression_12Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__postfixExpression_12Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__postfixExpression_7Context *altnt_block__postfixExpression_7();
    antlr4::tree::TerminalNode *Identifier();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__postfixExpression_12Context* aux_rule__postfixExpression_12();

  class  Aux_rule__directDeclarator_13Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__directDeclarator_13Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LeftBracket();
    Altnt_block__directDeclarator_9Context *altnt_block__directDeclarator_9();
    antlr4::tree::TerminalNode *RightBracket();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__directDeclarator_13Context* aux_rule__directDeclarator_13();

  class  Aux_rule__directDeclarator_14Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__directDeclarator_14Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LeftParen();
    Altnt_block__directDeclarator_10Context *altnt_block__directDeclarator_10();
    antlr4::tree::TerminalNode *RightParen();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__directDeclarator_14Context* aux_rule__directDeclarator_14();

  class  Aux_rule__directDeclarator_15Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__directDeclarator_15Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LeftParen();
    DeclaratorContext *declarator();
    antlr4::tree::TerminalNode *RightParen();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__directDeclarator_15Context* aux_rule__directDeclarator_15();

  class  Aux_rule__directAbstractDeclarator_21Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__directAbstractDeclarator_21Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LeftParen();
    Optional__directAbstractDeclarator_5Context *optional__directAbstractDeclarator_5();
    antlr4::tree::TerminalNode *RightParen();
    Kleene_star__declarator_2Context *kleene_star__declarator_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__directAbstractDeclarator_21Context* aux_rule__directAbstractDeclarator_21();

  class  Aux_rule__directAbstractDeclarator_22Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__directAbstractDeclarator_22Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LeftBracket();
    Altnt_block__directAbstractDeclarator_15Context *altnt_block__directAbstractDeclarator_15();
    antlr4::tree::TerminalNode *RightBracket();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__directAbstractDeclarator_22Context* aux_rule__directAbstractDeclarator_22();

  class  Aux_rule__directAbstractDeclarator_23Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__directAbstractDeclarator_23Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LeftBracket();
    Altnt_block__directAbstractDeclarator_15Context *altnt_block__directAbstractDeclarator_15();
    antlr4::tree::TerminalNode *RightBracket();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__directAbstractDeclarator_23Context* aux_rule__directAbstractDeclarator_23();

  class  Aux_rule__directAbstractDeclarator_24Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__directAbstractDeclarator_24Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LeftParen();
    Altnt_block__directAbstractDeclarator_17Context *altnt_block__directAbstractDeclarator_17();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__directAbstractDeclarator_24Context* aux_rule__directAbstractDeclarator_24();

  class  Aux_rule__primaryExpression_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__primaryExpression_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LeftParen();
    ExpressionContext *expression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__primaryExpression_4Context* aux_rule__primaryExpression_4();

  class  Aux_rule__primaryExpression_5Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__primaryExpression_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__primaryExpression_2Context *optional__primaryExpression_2();
    antlr4::tree::TerminalNode *LeftParen();
    CompoundStatementContext *compoundStatement();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__primaryExpression_5Context* aux_rule__primaryExpression_5();

  class  Aux_rule__primaryExpression_6Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__primaryExpression_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LeftParen();
    UnaryExpressionContext *unaryExpression();
    antlr4::tree::TerminalNode *Comma();
    TypeNameContext *typeName();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__primaryExpression_6Context* aux_rule__primaryExpression_6();

  class  Aux_rule__primaryExpression_7Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__primaryExpression_7Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LeftParen();
    TypeNameContext *typeName();
    antlr4::tree::TerminalNode *Comma();
    UnaryExpressionContext *unaryExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__primaryExpression_7Context* aux_rule__primaryExpression_7();

  class  Aux_rule__unaryExpression_9Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__unaryExpression_9Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Sizeof();
    antlr4::tree::TerminalNode *LeftParen();
    TypeNameContext *typeName();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__unaryExpression_9Context* aux_rule__unaryExpression_9();

  class  Aux_rule__unaryExpression_10Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__unaryExpression_10Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__unaryExpression_3Context *altnt_block__unaryExpression_3();
    antlr4::tree::TerminalNode *LeftParen();
    Altnt_block__unaryExpression_4Context *altnt_block__unaryExpression_4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__unaryExpression_10Context* aux_rule__unaryExpression_10();

  class  Aux_rule__typeSpecifier_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__typeSpecifier_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Extension_gcc();
    antlr4::tree::TerminalNode *LeftParen();
    Altnt_block__typeSpecifier_2Context *altnt_block__typeSpecifier_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__typeSpecifier_4Context* aux_rule__typeSpecifier_4();

  class  Aux_rule__typeSpecifier_5Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__typeSpecifier_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LeftParen();
    ConstantExpressionContext *constantExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__typeSpecifier_5Context* aux_rule__typeSpecifier_5();

  class  Aux_rule__structOrUnionSpecifier_3Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__structOrUnionSpecifier_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__structOrUnionSpecifier_1Context *optional__structOrUnionSpecifier_1();
    antlr4::tree::TerminalNode *LeftBrace();
    StructDeclarationListContext *structDeclarationList();
    antlr4::tree::TerminalNode *RightBrace();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__structOrUnionSpecifier_3Context* aux_rule__structOrUnionSpecifier_3();

  class  Aux_rule__enumSpecifier_6Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__enumSpecifier_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__enumSpecifier_4Context *altnt_block__enumSpecifier_4();
    antlr4::tree::TerminalNode *RightBrace();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__enumSpecifier_6Context* aux_rule__enumSpecifier_6();

  class  Aux_rule__directDeclarator_16Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__directDeclarator_16Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__directDeclarator_11Context *altnt_block__directDeclarator_11();
    AssignmentExpressionContext *assignmentExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__directDeclarator_16Context* aux_rule__directDeclarator_16();

  class  Aux_rule__directDeclarator_17Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__directDeclarator_17Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__pointer_1Context *optional__pointer_1();
    Altnt_block__directDeclarator_12Context *altnt_block__directDeclarator_12();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__directDeclarator_17Context* aux_rule__directDeclarator_17();

  class  Aux_rule__directAbstractDeclarator_25Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__directAbstractDeclarator_25Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__pointer_1Context *optional__pointer_1();
    Optional__directDeclarator_2Context *optional__directDeclarator_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__directAbstractDeclarator_25Context* aux_rule__directAbstractDeclarator_25();

  class  Aux_rule__directAbstractDeclarator_26Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__directAbstractDeclarator_26Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__directDeclarator_11Context *altnt_block__directDeclarator_11();
    AssignmentExpressionContext *assignmentExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__directAbstractDeclarator_26Context* aux_rule__directAbstractDeclarator_26();

  class  Aux_rule__labeledStatement_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__labeledStatement_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Case();
    ConstantExpressionContext *constantExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__labeledStatement_2Context* aux_rule__labeledStatement_2();

  class  Aux_rule__jumpStatement_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__jumpStatement_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Return();
    Optional__postfixExpression_1Context *optional__postfixExpression_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__jumpStatement_4Context* aux_rule__jumpStatement_4();

  class  Aux_rule__jumpStatement_5Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__jumpStatement_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Goto();
    Altnt_block__jumpStatement_3Context *altnt_block__jumpStatement_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__jumpStatement_5Context* aux_rule__jumpStatement_5();

  class  Aux_rule__directDeclarator_18Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__directDeclarator_18Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Static();
    Optional__pointer_1Context *optional__pointer_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__directDeclarator_18Context* aux_rule__directDeclarator_18();

  class  Aux_rule__directDeclarator_19Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__directDeclarator_19Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    TypeQualifierListContext *typeQualifierList();
    antlr4::tree::TerminalNode *Static();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__directDeclarator_19Context* aux_rule__directDeclarator_19();

  class  Aux_rule__postfixExpression_13Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__postfixExpression_13Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__primaryExpression_3Context *altnt_block__primaryExpression_3();
    antlr4::tree::TerminalNode *RightParen();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__postfixExpression_13Context* aux_rule__postfixExpression_13();

  class  Aux_rule__postfixExpression_14Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__postfixExpression_14Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__postfixExpression_8Context *altnt_block__postfixExpression_8();
    antlr4::tree::TerminalNode *RightBrace();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__postfixExpression_14Context* aux_rule__postfixExpression_14();

  class  Aux_rule__declarationSpecifier_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__declarationSpecifier_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LeftParen();
    antlr4::tree::TerminalNode *Identifier();
    antlr4::tree::TerminalNode *RightParen();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__declarationSpecifier_1Context* aux_rule__declarationSpecifier_1();

  class  Aux_rule__structDeclarationList_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__structDeclarationList_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__declaration_1Context *optional__declaration_1();
    SpecifierQualifierListContext *specifierQualifierList();
    Optional__structDeclaration_2Context *optional__structDeclaration_2();
    antlr4::tree::TerminalNode *Semi();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__structDeclarationList_4Context* aux_rule__structDeclarationList_4();

  class  Aux_rule__designatorList_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__designatorList_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LeftBracket();
    ConstantExpressionContext *constantExpression();
    antlr4::tree::TerminalNode *RightBracket();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__designatorList_4Context* aux_rule__designatorList_4();

  class  Aux_rule__designatorList_5Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__designatorList_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Dot();
    antlr4::tree::TerminalNode *Identifier();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__designatorList_5Context* aux_rule__designatorList_5();

  class  Aux_rule__statement_3Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__statement_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *If();
    antlr4::tree::TerminalNode *LeftParen();
    ExpressionContext *expression();
    antlr4::tree::TerminalNode *RightParen();
    StatementContext *statement();
    Optional__selectionStatement_2Context *optional__selectionStatement_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__statement_3Context* aux_rule__statement_3();

  class  Aux_rule__statement_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__statement_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Do();
    StatementContext *statement();
    antlr4::tree::TerminalNode *While();
    antlr4::tree::TerminalNode *LeftParen();
    ExpressionContext *expression();
    antlr4::tree::TerminalNode *RightParen();
    antlr4::tree::TerminalNode *Semi();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__statement_4Context* aux_rule__statement_4();

  class  Aux_rule__statement_5Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__statement_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__statement_1Context *altnt_block__statement_1();
    antlr4::tree::TerminalNode *RightParen();
    StatementContext *statement();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__statement_5Context* aux_rule__statement_5();

  class  Aux_rule__iterationStatement_9Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__iterationStatement_9Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__postfixExpression_1Context *optional__postfixExpression_1();
    antlr4::tree::TerminalNode *Semi();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__iterationStatement_9Context* aux_rule__iterationStatement_9();

  class  Aux_rule__statement_6Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__statement_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *For();
    antlr4::tree::TerminalNode *LeftParen();
    Altnt_block__iterationStatement_7Context *altnt_block__iterationStatement_7();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__statement_6Context* aux_rule__statement_6();

  class  Aux_rule__statement_7Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__statement_7Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__statement_2Context *altnt_block__statement_2();
    antlr4::tree::TerminalNode *LeftParen();
    ExpressionContext *expression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__statement_7Context* aux_rule__statement_7();


private:
  static std::vector<antlr4::dfa::DFA> _decisionToDFA;
  static antlr4::atn::PredictionContextCache _sharedContextCache;
  static std::vector<std::string> _ruleNames;
  static std::vector<std::string> _tokenNames;

  static std::vector<std::string> _literalNames;
  static std::vector<std::string> _symbolicNames;
  static antlr4::dfa::Vocabulary _vocabulary;
  static antlr4::atn::ATN _atn;
  static std::vector<uint16_t> _serializedATN;


  struct Initializer {
    Initializer();
  };
  static Initializer _init;
};

}  // namespace antlr_C_perses
