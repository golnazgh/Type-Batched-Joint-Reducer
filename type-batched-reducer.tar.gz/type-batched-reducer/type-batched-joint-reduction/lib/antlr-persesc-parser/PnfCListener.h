
// Generated from PnfC.g4 by ANTLR 4.7.2

#pragma once


#include "antlr4-runtime.h"
#include "PnfCParser.h"


namespace antlr_C_perses {

/**
 * This interface defines an abstract listener for a parse tree produced by PnfCParser.
 */
class  PnfCListener : public antlr4::tree::ParseTreeListener {
public:

  virtual void enterGenericSelection(PnfCParser::GenericSelectionContext *ctx) = 0;
  virtual void exitGenericSelection(PnfCParser::GenericSelectionContext *ctx) = 0;

  virtual void enterGenericAssociation(PnfCParser::GenericAssociationContext *ctx) = 0;
  virtual void exitGenericAssociation(PnfCParser::GenericAssociationContext *ctx) = 0;

  virtual void enterUnaryExpression(PnfCParser::UnaryExpressionContext *ctx) = 0;
  virtual void exitUnaryExpression(PnfCParser::UnaryExpressionContext *ctx) = 0;

  virtual void enterUnaryOperator(PnfCParser::UnaryOperatorContext *ctx) = 0;
  virtual void exitUnaryOperator(PnfCParser::UnaryOperatorContext *ctx) = 0;

  virtual void enterCastExpression(PnfCParser::CastExpressionContext *ctx) = 0;
  virtual void exitCastExpression(PnfCParser::CastExpressionContext *ctx) = 0;

  virtual void enterConditionalExpression(PnfCParser::ConditionalExpressionContext *ctx) = 0;
  virtual void exitConditionalExpression(PnfCParser::ConditionalExpressionContext *ctx) = 0;

  virtual void enterAssignmentExpression(PnfCParser::AssignmentExpressionContext *ctx) = 0;
  virtual void exitAssignmentExpression(PnfCParser::AssignmentExpressionContext *ctx) = 0;

  virtual void enterAssignmentOperator(PnfCParser::AssignmentOperatorContext *ctx) = 0;
  virtual void exitAssignmentOperator(PnfCParser::AssignmentOperatorContext *ctx) = 0;

  virtual void enterConstantExpression(PnfCParser::ConstantExpressionContext *ctx) = 0;
  virtual void exitConstantExpression(PnfCParser::ConstantExpressionContext *ctx) = 0;

  virtual void enterDeclaration(PnfCParser::DeclarationContext *ctx) = 0;
  virtual void exitDeclaration(PnfCParser::DeclarationContext *ctx) = 0;

  virtual void enterDeclarationSpecifiers(PnfCParser::DeclarationSpecifiersContext *ctx) = 0;
  virtual void exitDeclarationSpecifiers(PnfCParser::DeclarationSpecifiersContext *ctx) = 0;

  virtual void enterInitDeclarator(PnfCParser::InitDeclaratorContext *ctx) = 0;
  virtual void exitInitDeclarator(PnfCParser::InitDeclaratorContext *ctx) = 0;

  virtual void enterTypeSpecifier(PnfCParser::TypeSpecifierContext *ctx) = 0;
  virtual void exitTypeSpecifier(PnfCParser::TypeSpecifierContext *ctx) = 0;

  virtual void enterStructOrUnionSpecifier(PnfCParser::StructOrUnionSpecifierContext *ctx) = 0;
  virtual void exitStructOrUnionSpecifier(PnfCParser::StructOrUnionSpecifierContext *ctx) = 0;

  virtual void enterStructOrUnion(PnfCParser::StructOrUnionContext *ctx) = 0;
  virtual void exitStructOrUnion(PnfCParser::StructOrUnionContext *ctx) = 0;

  virtual void enterSpecifierQualifierList(PnfCParser::SpecifierQualifierListContext *ctx) = 0;
  virtual void exitSpecifierQualifierList(PnfCParser::SpecifierQualifierListContext *ctx) = 0;

  virtual void enterStructDeclarator(PnfCParser::StructDeclaratorContext *ctx) = 0;
  virtual void exitStructDeclarator(PnfCParser::StructDeclaratorContext *ctx) = 0;

  virtual void enterEnumSpecifier(PnfCParser::EnumSpecifierContext *ctx) = 0;
  virtual void exitEnumSpecifier(PnfCParser::EnumSpecifierContext *ctx) = 0;

  virtual void enterEnumerator(PnfCParser::EnumeratorContext *ctx) = 0;
  virtual void exitEnumerator(PnfCParser::EnumeratorContext *ctx) = 0;

  virtual void enterAtomicTypeSpecifier(PnfCParser::AtomicTypeSpecifierContext *ctx) = 0;
  virtual void exitAtomicTypeSpecifier(PnfCParser::AtomicTypeSpecifierContext *ctx) = 0;

  virtual void enterTypeQualifier(PnfCParser::TypeQualifierContext *ctx) = 0;
  virtual void exitTypeQualifier(PnfCParser::TypeQualifierContext *ctx) = 0;

  virtual void enterAlignmentSpecifier(PnfCParser::AlignmentSpecifierContext *ctx) = 0;
  virtual void exitAlignmentSpecifier(PnfCParser::AlignmentSpecifierContext *ctx) = 0;

  virtual void enterDeclarator(PnfCParser::DeclaratorContext *ctx) = 0;
  virtual void exitDeclarator(PnfCParser::DeclaratorContext *ctx) = 0;

  virtual void enterGccDeclaratorExtension(PnfCParser::GccDeclaratorExtensionContext *ctx) = 0;
  virtual void exitGccDeclaratorExtension(PnfCParser::GccDeclaratorExtensionContext *ctx) = 0;

  virtual void enterAsmKeyword(PnfCParser::AsmKeywordContext *ctx) = 0;
  virtual void exitAsmKeyword(PnfCParser::AsmKeywordContext *ctx) = 0;

  virtual void enterGccAttributeSpecifier(PnfCParser::GccAttributeSpecifierContext *ctx) = 0;
  virtual void exitGccAttributeSpecifier(PnfCParser::GccAttributeSpecifierContext *ctx) = 0;

  virtual void enterGccAttributeList(PnfCParser::GccAttributeListContext *ctx) = 0;
  virtual void exitGccAttributeList(PnfCParser::GccAttributeListContext *ctx) = 0;

  virtual void enterGccAttribute(PnfCParser::GccAttributeContext *ctx) = 0;
  virtual void exitGccAttribute(PnfCParser::GccAttributeContext *ctx) = 0;

  virtual void enterPointer(PnfCParser::PointerContext *ctx) = 0;
  virtual void exitPointer(PnfCParser::PointerContext *ctx) = 0;

  virtual void enterParameterTypeList(PnfCParser::ParameterTypeListContext *ctx) = 0;
  virtual void exitParameterTypeList(PnfCParser::ParameterTypeListContext *ctx) = 0;

  virtual void enterParameterDeclaration(PnfCParser::ParameterDeclarationContext *ctx) = 0;
  virtual void exitParameterDeclaration(PnfCParser::ParameterDeclarationContext *ctx) = 0;

  virtual void enterTypeName(PnfCParser::TypeNameContext *ctx) = 0;
  virtual void exitTypeName(PnfCParser::TypeNameContext *ctx) = 0;

  virtual void enterAbstractDeclarator(PnfCParser::AbstractDeclaratorContext *ctx) = 0;
  virtual void exitAbstractDeclarator(PnfCParser::AbstractDeclaratorContext *ctx) = 0;

  virtual void enterTypedefName(PnfCParser::TypedefNameContext *ctx) = 0;
  virtual void exitTypedefName(PnfCParser::TypedefNameContext *ctx) = 0;

  virtual void enterInitializer(PnfCParser::InitializerContext *ctx) = 0;
  virtual void exitInitializer(PnfCParser::InitializerContext *ctx) = 0;

  virtual void enterDesignation(PnfCParser::DesignationContext *ctx) = 0;
  virtual void exitDesignation(PnfCParser::DesignationContext *ctx) = 0;

  virtual void enterStaticAssertDeclaration(PnfCParser::StaticAssertDeclarationContext *ctx) = 0;
  virtual void exitStaticAssertDeclaration(PnfCParser::StaticAssertDeclarationContext *ctx) = 0;

  virtual void enterAsmStatement(PnfCParser::AsmStatementContext *ctx) = 0;
  virtual void exitAsmStatement(PnfCParser::AsmStatementContext *ctx) = 0;

  virtual void enterLabeledStatement(PnfCParser::LabeledStatementContext *ctx) = 0;
  virtual void exitLabeledStatement(PnfCParser::LabeledStatementContext *ctx) = 0;

  virtual void enterCompoundStatement(PnfCParser::CompoundStatementContext *ctx) = 0;
  virtual void exitCompoundStatement(PnfCParser::CompoundStatementContext *ctx) = 0;

  virtual void enterExpressionStatement(PnfCParser::ExpressionStatementContext *ctx) = 0;
  virtual void exitExpressionStatement(PnfCParser::ExpressionStatementContext *ctx) = 0;

  virtual void enterJumpStatement(PnfCParser::JumpStatementContext *ctx) = 0;
  virtual void exitJumpStatement(PnfCParser::JumpStatementContext *ctx) = 0;

  virtual void enterCompilationUnit(PnfCParser::CompilationUnitContext *ctx) = 0;
  virtual void exitCompilationUnit(PnfCParser::CompilationUnitContext *ctx) = 0;

  virtual void enterFunctionDefinition(PnfCParser::FunctionDefinitionContext *ctx) = 0;
  virtual void exitFunctionDefinition(PnfCParser::FunctionDefinitionContext *ctx) = 0;

  virtual void enterKleene_plus__primaryExpression_1(PnfCParser::Kleene_plus__primaryExpression_1Context *ctx) = 0;
  virtual void exitKleene_plus__primaryExpression_1(PnfCParser::Kleene_plus__primaryExpression_1Context *ctx) = 0;

  virtual void enterOptional__primaryExpression_2(PnfCParser::Optional__primaryExpression_2Context *ctx) = 0;
  virtual void exitOptional__primaryExpression_2(PnfCParser::Optional__primaryExpression_2Context *ctx) = 0;

  virtual void enterOptional__postfixExpression_1(PnfCParser::Optional__postfixExpression_1Context *ctx) = 0;
  virtual void exitOptional__postfixExpression_1(PnfCParser::Optional__postfixExpression_1Context *ctx) = 0;

  virtual void enterAux_rule__conditionalExpression_1(PnfCParser::Aux_rule__conditionalExpression_1Context *ctx) = 0;
  virtual void exitAux_rule__conditionalExpression_1(PnfCParser::Aux_rule__conditionalExpression_1Context *ctx) = 0;

  virtual void enterOptional__conditionalExpression_2(PnfCParser::Optional__conditionalExpression_2Context *ctx) = 0;
  virtual void exitOptional__conditionalExpression_2(PnfCParser::Optional__conditionalExpression_2Context *ctx) = 0;

  virtual void enterOptional__declaration_1(PnfCParser::Optional__declaration_1Context *ctx) = 0;
  virtual void exitOptional__declaration_1(PnfCParser::Optional__declaration_1Context *ctx) = 0;

  virtual void enterOptional__declaration_2(PnfCParser::Optional__declaration_2Context *ctx) = 0;
  virtual void exitOptional__declaration_2(PnfCParser::Optional__declaration_2Context *ctx) = 0;

  virtual void enterOptional__structOrUnionSpecifier_1(PnfCParser::Optional__structOrUnionSpecifier_1Context *ctx) = 0;
  virtual void exitOptional__structOrUnionSpecifier_1(PnfCParser::Optional__structOrUnionSpecifier_1Context *ctx) = 0;

  virtual void enterOptional__structDeclaration_2(PnfCParser::Optional__structDeclaration_2Context *ctx) = 0;
  virtual void exitOptional__structDeclaration_2(PnfCParser::Optional__structDeclaration_2Context *ctx) = 0;

  virtual void enterOptional__specifierQualifierList_1(PnfCParser::Optional__specifierQualifierList_1Context *ctx) = 0;
  virtual void exitOptional__specifierQualifierList_1(PnfCParser::Optional__specifierQualifierList_1Context *ctx) = 0;

  virtual void enterOptional__structDeclarator_1(PnfCParser::Optional__structDeclarator_1Context *ctx) = 0;
  virtual void exitOptional__structDeclarator_1(PnfCParser::Optional__structDeclarator_1Context *ctx) = 0;

  virtual void enterOptional__declarator_1(PnfCParser::Optional__declarator_1Context *ctx) = 0;
  virtual void exitOptional__declarator_1(PnfCParser::Optional__declarator_1Context *ctx) = 0;

  virtual void enterKleene_star__declarator_2(PnfCParser::Kleene_star__declarator_2Context *ctx) = 0;
  virtual void exitKleene_star__declarator_2(PnfCParser::Kleene_star__declarator_2Context *ctx) = 0;

  virtual void enterOptional__directDeclarator_2(PnfCParser::Optional__directDeclarator_2Context *ctx) = 0;
  virtual void exitOptional__directDeclarator_2(PnfCParser::Optional__directDeclarator_2Context *ctx) = 0;

  virtual void enterOptional__directDeclarator_5(PnfCParser::Optional__directDeclarator_5Context *ctx) = 0;
  virtual void exitOptional__directDeclarator_5(PnfCParser::Optional__directDeclarator_5Context *ctx) = 0;

  virtual void enterAux_rule__gccAttributeList_1(PnfCParser::Aux_rule__gccAttributeList_1Context *ctx) = 0;
  virtual void exitAux_rule__gccAttributeList_1(PnfCParser::Aux_rule__gccAttributeList_1Context *ctx) = 0;

  virtual void enterKleene_star__gccAttributeList_2(PnfCParser::Kleene_star__gccAttributeList_2Context *ctx) = 0;
  virtual void exitKleene_star__gccAttributeList_2(PnfCParser::Kleene_star__gccAttributeList_2Context *ctx) = 0;

  virtual void enterAux_rule__gccAttributeList_3(PnfCParser::Aux_rule__gccAttributeList_3Context *ctx) = 0;
  virtual void exitAux_rule__gccAttributeList_3(PnfCParser::Aux_rule__gccAttributeList_3Context *ctx) = 0;

  virtual void enterAux_rule__gccAttribute_2(PnfCParser::Aux_rule__gccAttribute_2Context *ctx) = 0;
  virtual void exitAux_rule__gccAttribute_2(PnfCParser::Aux_rule__gccAttribute_2Context *ctx) = 0;

  virtual void enterOptional__gccAttribute_3(PnfCParser::Optional__gccAttribute_3Context *ctx) = 0;
  virtual void exitOptional__gccAttribute_3(PnfCParser::Optional__gccAttribute_3Context *ctx) = 0;

  virtual void enterAux_rule__gccAttribute_4(PnfCParser::Aux_rule__gccAttribute_4Context *ctx) = 0;
  virtual void exitAux_rule__gccAttribute_4(PnfCParser::Aux_rule__gccAttribute_4Context *ctx) = 0;

  virtual void enterOptional__pointer_1(PnfCParser::Optional__pointer_1Context *ctx) = 0;
  virtual void exitOptional__pointer_1(PnfCParser::Optional__pointer_1Context *ctx) = 0;

  virtual void enterOptional__typeName_1(PnfCParser::Optional__typeName_1Context *ctx) = 0;
  virtual void exitOptional__typeName_1(PnfCParser::Optional__typeName_1Context *ctx) = 0;

  virtual void enterOptional__directAbstractDeclarator_5(PnfCParser::Optional__directAbstractDeclarator_5Context *ctx) = 0;
  virtual void exitOptional__directAbstractDeclarator_5(PnfCParser::Optional__directAbstractDeclarator_5Context *ctx) = 0;

  virtual void enterOptional__initializerList_1(PnfCParser::Optional__initializerList_1Context *ctx) = 0;
  virtual void exitOptional__initializerList_1(PnfCParser::Optional__initializerList_1Context *ctx) = 0;

  virtual void enterAux_rule__asmStatement_1(PnfCParser::Aux_rule__asmStatement_1Context *ctx) = 0;
  virtual void exitAux_rule__asmStatement_1(PnfCParser::Aux_rule__asmStatement_1Context *ctx) = 0;

  virtual void enterOptional__asmStatement_2(PnfCParser::Optional__asmStatement_2Context *ctx) = 0;
  virtual void exitOptional__asmStatement_2(PnfCParser::Optional__asmStatement_2Context *ctx) = 0;

  virtual void enterAux_rule__asmStatement_3(PnfCParser::Aux_rule__asmStatement_3Context *ctx) = 0;
  virtual void exitAux_rule__asmStatement_3(PnfCParser::Aux_rule__asmStatement_3Context *ctx) = 0;

  virtual void enterKleene_star__asmStatement_4(PnfCParser::Kleene_star__asmStatement_4Context *ctx) = 0;
  virtual void exitKleene_star__asmStatement_4(PnfCParser::Kleene_star__asmStatement_4Context *ctx) = 0;

  virtual void enterAux_rule__asmStatement_5(PnfCParser::Aux_rule__asmStatement_5Context *ctx) = 0;
  virtual void exitAux_rule__asmStatement_5(PnfCParser::Aux_rule__asmStatement_5Context *ctx) = 0;

  virtual void enterOptional__asmStatement_6(PnfCParser::Optional__asmStatement_6Context *ctx) = 0;
  virtual void exitOptional__asmStatement_6(PnfCParser::Optional__asmStatement_6Context *ctx) = 0;

  virtual void enterAux_rule__asmStatement_11(PnfCParser::Aux_rule__asmStatement_11Context *ctx) = 0;
  virtual void exitAux_rule__asmStatement_11(PnfCParser::Aux_rule__asmStatement_11Context *ctx) = 0;

  virtual void enterKleene_star__asmStatement_12(PnfCParser::Kleene_star__asmStatement_12Context *ctx) = 0;
  virtual void exitKleene_star__asmStatement_12(PnfCParser::Kleene_star__asmStatement_12Context *ctx) = 0;

  virtual void enterOptional__compoundStatement_1(PnfCParser::Optional__compoundStatement_1Context *ctx) = 0;
  virtual void exitOptional__compoundStatement_1(PnfCParser::Optional__compoundStatement_1Context *ctx) = 0;

  virtual void enterAux_rule__selectionStatement_1(PnfCParser::Aux_rule__selectionStatement_1Context *ctx) = 0;
  virtual void exitAux_rule__selectionStatement_1(PnfCParser::Aux_rule__selectionStatement_1Context *ctx) = 0;

  virtual void enterOptional__selectionStatement_2(PnfCParser::Optional__selectionStatement_2Context *ctx) = 0;
  virtual void exitOptional__selectionStatement_2(PnfCParser::Optional__selectionStatement_2Context *ctx) = 0;

  virtual void enterOptional__compilationUnit_1(PnfCParser::Optional__compilationUnit_1Context *ctx) = 0;
  virtual void exitOptional__compilationUnit_1(PnfCParser::Optional__compilationUnit_1Context *ctx) = 0;

  virtual void enterOptional__functionDefinition_2(PnfCParser::Optional__functionDefinition_2Context *ctx) = 0;
  virtual void exitOptional__functionDefinition_2(PnfCParser::Optional__functionDefinition_2Context *ctx) = 0;

  virtual void enterOptional__functionDefinition_3(PnfCParser::Optional__functionDefinition_3Context *ctx) = 0;
  virtual void exitOptional__functionDefinition_3(PnfCParser::Optional__functionDefinition_3Context *ctx) = 0;

  virtual void enterAux_rule__expression_2(PnfCParser::Aux_rule__expression_2Context *ctx) = 0;
  virtual void exitAux_rule__expression_2(PnfCParser::Aux_rule__expression_2Context *ctx) = 0;

  virtual void enterKleene_star__expression_1(PnfCParser::Kleene_star__expression_1Context *ctx) = 0;
  virtual void exitKleene_star__expression_1(PnfCParser::Kleene_star__expression_1Context *ctx) = 0;

  virtual void enterExpression(PnfCParser::ExpressionContext *ctx) = 0;
  virtual void exitExpression(PnfCParser::ExpressionContext *ctx) = 0;

  virtual void enterAux_rule__genericAssocList_2(PnfCParser::Aux_rule__genericAssocList_2Context *ctx) = 0;
  virtual void exitAux_rule__genericAssocList_2(PnfCParser::Aux_rule__genericAssocList_2Context *ctx) = 0;

  virtual void enterKleene_star__genericAssocList_1(PnfCParser::Kleene_star__genericAssocList_1Context *ctx) = 0;
  virtual void exitKleene_star__genericAssocList_1(PnfCParser::Kleene_star__genericAssocList_1Context *ctx) = 0;

  virtual void enterGenericAssocList(PnfCParser::GenericAssocListContext *ctx) = 0;
  virtual void exitGenericAssocList(PnfCParser::GenericAssocListContext *ctx) = 0;

  virtual void enterAux_rule__postfixExpression_3(PnfCParser::Aux_rule__postfixExpression_3Context *ctx) = 0;
  virtual void exitAux_rule__postfixExpression_3(PnfCParser::Aux_rule__postfixExpression_3Context *ctx) = 0;

  virtual void enterKleene_star__postfixExpression_2(PnfCParser::Kleene_star__postfixExpression_2Context *ctx) = 0;
  virtual void exitKleene_star__postfixExpression_2(PnfCParser::Kleene_star__postfixExpression_2Context *ctx) = 0;

  virtual void enterPostfixExpression(PnfCParser::PostfixExpressionContext *ctx) = 0;
  virtual void exitPostfixExpression(PnfCParser::PostfixExpressionContext *ctx) = 0;

  virtual void enterAux_rule__initializerList_4(PnfCParser::Aux_rule__initializerList_4Context *ctx) = 0;
  virtual void exitAux_rule__initializerList_4(PnfCParser::Aux_rule__initializerList_4Context *ctx) = 0;

  virtual void enterKleene_star__initializerList_3(PnfCParser::Kleene_star__initializerList_3Context *ctx) = 0;
  virtual void exitKleene_star__initializerList_3(PnfCParser::Kleene_star__initializerList_3Context *ctx) = 0;

  virtual void enterInitializerList(PnfCParser::InitializerListContext *ctx) = 0;
  virtual void exitInitializerList(PnfCParser::InitializerListContext *ctx) = 0;

  virtual void enterAux_rule__multiplicativeExpression_2(PnfCParser::Aux_rule__multiplicativeExpression_2Context *ctx) = 0;
  virtual void exitAux_rule__multiplicativeExpression_2(PnfCParser::Aux_rule__multiplicativeExpression_2Context *ctx) = 0;

  virtual void enterKleene_star__multiplicativeExpression_1(PnfCParser::Kleene_star__multiplicativeExpression_1Context *ctx) = 0;
  virtual void exitKleene_star__multiplicativeExpression_1(PnfCParser::Kleene_star__multiplicativeExpression_1Context *ctx) = 0;

  virtual void enterMultiplicativeExpression(PnfCParser::MultiplicativeExpressionContext *ctx) = 0;
  virtual void exitMultiplicativeExpression(PnfCParser::MultiplicativeExpressionContext *ctx) = 0;

  virtual void enterAux_rule__additiveExpression_2(PnfCParser::Aux_rule__additiveExpression_2Context *ctx) = 0;
  virtual void exitAux_rule__additiveExpression_2(PnfCParser::Aux_rule__additiveExpression_2Context *ctx) = 0;

  virtual void enterKleene_star__additiveExpression_1(PnfCParser::Kleene_star__additiveExpression_1Context *ctx) = 0;
  virtual void exitKleene_star__additiveExpression_1(PnfCParser::Kleene_star__additiveExpression_1Context *ctx) = 0;

  virtual void enterAdditiveExpression(PnfCParser::AdditiveExpressionContext *ctx) = 0;
  virtual void exitAdditiveExpression(PnfCParser::AdditiveExpressionContext *ctx) = 0;

  virtual void enterAux_rule__shiftExpression_2(PnfCParser::Aux_rule__shiftExpression_2Context *ctx) = 0;
  virtual void exitAux_rule__shiftExpression_2(PnfCParser::Aux_rule__shiftExpression_2Context *ctx) = 0;

  virtual void enterKleene_star__shiftExpression_1(PnfCParser::Kleene_star__shiftExpression_1Context *ctx) = 0;
  virtual void exitKleene_star__shiftExpression_1(PnfCParser::Kleene_star__shiftExpression_1Context *ctx) = 0;

  virtual void enterShiftExpression(PnfCParser::ShiftExpressionContext *ctx) = 0;
  virtual void exitShiftExpression(PnfCParser::ShiftExpressionContext *ctx) = 0;

  virtual void enterAux_rule__relationalExpression_2(PnfCParser::Aux_rule__relationalExpression_2Context *ctx) = 0;
  virtual void exitAux_rule__relationalExpression_2(PnfCParser::Aux_rule__relationalExpression_2Context *ctx) = 0;

  virtual void enterKleene_star__relationalExpression_1(PnfCParser::Kleene_star__relationalExpression_1Context *ctx) = 0;
  virtual void exitKleene_star__relationalExpression_1(PnfCParser::Kleene_star__relationalExpression_1Context *ctx) = 0;

  virtual void enterRelationalExpression(PnfCParser::RelationalExpressionContext *ctx) = 0;
  virtual void exitRelationalExpression(PnfCParser::RelationalExpressionContext *ctx) = 0;

  virtual void enterAux_rule__equalityExpression_2(PnfCParser::Aux_rule__equalityExpression_2Context *ctx) = 0;
  virtual void exitAux_rule__equalityExpression_2(PnfCParser::Aux_rule__equalityExpression_2Context *ctx) = 0;

  virtual void enterKleene_star__equalityExpression_1(PnfCParser::Kleene_star__equalityExpression_1Context *ctx) = 0;
  virtual void exitKleene_star__equalityExpression_1(PnfCParser::Kleene_star__equalityExpression_1Context *ctx) = 0;

  virtual void enterEqualityExpression(PnfCParser::EqualityExpressionContext *ctx) = 0;
  virtual void exitEqualityExpression(PnfCParser::EqualityExpressionContext *ctx) = 0;

  virtual void enterAux_rule__andExpression_2(PnfCParser::Aux_rule__andExpression_2Context *ctx) = 0;
  virtual void exitAux_rule__andExpression_2(PnfCParser::Aux_rule__andExpression_2Context *ctx) = 0;

  virtual void enterKleene_star__andExpression_1(PnfCParser::Kleene_star__andExpression_1Context *ctx) = 0;
  virtual void exitKleene_star__andExpression_1(PnfCParser::Kleene_star__andExpression_1Context *ctx) = 0;

  virtual void enterAndExpression(PnfCParser::AndExpressionContext *ctx) = 0;
  virtual void exitAndExpression(PnfCParser::AndExpressionContext *ctx) = 0;

  virtual void enterAux_rule__exclusiveOrExpression_2(PnfCParser::Aux_rule__exclusiveOrExpression_2Context *ctx) = 0;
  virtual void exitAux_rule__exclusiveOrExpression_2(PnfCParser::Aux_rule__exclusiveOrExpression_2Context *ctx) = 0;

  virtual void enterKleene_star__exclusiveOrExpression_1(PnfCParser::Kleene_star__exclusiveOrExpression_1Context *ctx) = 0;
  virtual void exitKleene_star__exclusiveOrExpression_1(PnfCParser::Kleene_star__exclusiveOrExpression_1Context *ctx) = 0;

  virtual void enterExclusiveOrExpression(PnfCParser::ExclusiveOrExpressionContext *ctx) = 0;
  virtual void exitExclusiveOrExpression(PnfCParser::ExclusiveOrExpressionContext *ctx) = 0;

  virtual void enterAux_rule__inclusiveOrExpression_2(PnfCParser::Aux_rule__inclusiveOrExpression_2Context *ctx) = 0;
  virtual void exitAux_rule__inclusiveOrExpression_2(PnfCParser::Aux_rule__inclusiveOrExpression_2Context *ctx) = 0;

  virtual void enterKleene_star__inclusiveOrExpression_1(PnfCParser::Kleene_star__inclusiveOrExpression_1Context *ctx) = 0;
  virtual void exitKleene_star__inclusiveOrExpression_1(PnfCParser::Kleene_star__inclusiveOrExpression_1Context *ctx) = 0;

  virtual void enterInclusiveOrExpression(PnfCParser::InclusiveOrExpressionContext *ctx) = 0;
  virtual void exitInclusiveOrExpression(PnfCParser::InclusiveOrExpressionContext *ctx) = 0;

  virtual void enterAux_rule__logicalAndExpression_2(PnfCParser::Aux_rule__logicalAndExpression_2Context *ctx) = 0;
  virtual void exitAux_rule__logicalAndExpression_2(PnfCParser::Aux_rule__logicalAndExpression_2Context *ctx) = 0;

  virtual void enterKleene_star__logicalAndExpression_1(PnfCParser::Kleene_star__logicalAndExpression_1Context *ctx) = 0;
  virtual void exitKleene_star__logicalAndExpression_1(PnfCParser::Kleene_star__logicalAndExpression_1Context *ctx) = 0;

  virtual void enterLogicalAndExpression(PnfCParser::LogicalAndExpressionContext *ctx) = 0;
  virtual void exitLogicalAndExpression(PnfCParser::LogicalAndExpressionContext *ctx) = 0;

  virtual void enterAux_rule__logicalOrExpression_2(PnfCParser::Aux_rule__logicalOrExpression_2Context *ctx) = 0;
  virtual void exitAux_rule__logicalOrExpression_2(PnfCParser::Aux_rule__logicalOrExpression_2Context *ctx) = 0;

  virtual void enterKleene_star__logicalOrExpression_1(PnfCParser::Kleene_star__logicalOrExpression_1Context *ctx) = 0;
  virtual void exitKleene_star__logicalOrExpression_1(PnfCParser::Kleene_star__logicalOrExpression_1Context *ctx) = 0;

  virtual void enterLogicalOrExpression(PnfCParser::LogicalOrExpressionContext *ctx) = 0;
  virtual void exitLogicalOrExpression(PnfCParser::LogicalOrExpressionContext *ctx) = 0;

  virtual void enterAux_rule__initDeclaratorList_2(PnfCParser::Aux_rule__initDeclaratorList_2Context *ctx) = 0;
  virtual void exitAux_rule__initDeclaratorList_2(PnfCParser::Aux_rule__initDeclaratorList_2Context *ctx) = 0;

  virtual void enterKleene_star__initDeclaratorList_1(PnfCParser::Kleene_star__initDeclaratorList_1Context *ctx) = 0;
  virtual void exitKleene_star__initDeclaratorList_1(PnfCParser::Kleene_star__initDeclaratorList_1Context *ctx) = 0;

  virtual void enterInitDeclaratorList(PnfCParser::InitDeclaratorListContext *ctx) = 0;
  virtual void exitInitDeclaratorList(PnfCParser::InitDeclaratorListContext *ctx) = 0;

  virtual void enterStructDeclarationList(PnfCParser::StructDeclarationListContext *ctx) = 0;
  virtual void exitStructDeclarationList(PnfCParser::StructDeclarationListContext *ctx) = 0;

  virtual void enterAux_rule__structDeclaratorList_2(PnfCParser::Aux_rule__structDeclaratorList_2Context *ctx) = 0;
  virtual void exitAux_rule__structDeclaratorList_2(PnfCParser::Aux_rule__structDeclaratorList_2Context *ctx) = 0;

  virtual void enterKleene_star__structDeclaratorList_1(PnfCParser::Kleene_star__structDeclaratorList_1Context *ctx) = 0;
  virtual void exitKleene_star__structDeclaratorList_1(PnfCParser::Kleene_star__structDeclaratorList_1Context *ctx) = 0;

  virtual void enterStructDeclaratorList(PnfCParser::StructDeclaratorListContext *ctx) = 0;
  virtual void exitStructDeclaratorList(PnfCParser::StructDeclaratorListContext *ctx) = 0;

  virtual void enterAux_rule__enumeratorList_2(PnfCParser::Aux_rule__enumeratorList_2Context *ctx) = 0;
  virtual void exitAux_rule__enumeratorList_2(PnfCParser::Aux_rule__enumeratorList_2Context *ctx) = 0;

  virtual void enterKleene_star__enumeratorList_1(PnfCParser::Kleene_star__enumeratorList_1Context *ctx) = 0;
  virtual void exitKleene_star__enumeratorList_1(PnfCParser::Kleene_star__enumeratorList_1Context *ctx) = 0;

  virtual void enterEnumeratorList(PnfCParser::EnumeratorListContext *ctx) = 0;
  virtual void exitEnumeratorList(PnfCParser::EnumeratorListContext *ctx) = 0;

  virtual void enterAux_rule__directDeclarator_7(PnfCParser::Aux_rule__directDeclarator_7Context *ctx) = 0;
  virtual void exitAux_rule__directDeclarator_7(PnfCParser::Aux_rule__directDeclarator_7Context *ctx) = 0;

  virtual void enterKleene_star__directDeclarator_6(PnfCParser::Kleene_star__directDeclarator_6Context *ctx) = 0;
  virtual void exitKleene_star__directDeclarator_6(PnfCParser::Kleene_star__directDeclarator_6Context *ctx) = 0;

  virtual void enterAux_rule__directDeclarator_8(PnfCParser::Aux_rule__directDeclarator_8Context *ctx) = 0;
  virtual void exitAux_rule__directDeclarator_8(PnfCParser::Aux_rule__directDeclarator_8Context *ctx) = 0;

  virtual void enterDirectDeclarator(PnfCParser::DirectDeclaratorContext *ctx) = 0;
  virtual void exitDirectDeclarator(PnfCParser::DirectDeclaratorContext *ctx) = 0;

  virtual void enterAux_rule__typeQualifierList_2(PnfCParser::Aux_rule__typeQualifierList_2Context *ctx) = 0;
  virtual void exitAux_rule__typeQualifierList_2(PnfCParser::Aux_rule__typeQualifierList_2Context *ctx) = 0;

  virtual void enterTypeQualifierList(PnfCParser::TypeQualifierListContext *ctx) = 0;
  virtual void exitTypeQualifierList(PnfCParser::TypeQualifierListContext *ctx) = 0;

  virtual void enterAux_rule__identifierList_2(PnfCParser::Aux_rule__identifierList_2Context *ctx) = 0;
  virtual void exitAux_rule__identifierList_2(PnfCParser::Aux_rule__identifierList_2Context *ctx) = 0;

  virtual void enterKleene_star__identifierList_1(PnfCParser::Kleene_star__identifierList_1Context *ctx) = 0;
  virtual void exitKleene_star__identifierList_1(PnfCParser::Kleene_star__identifierList_1Context *ctx) = 0;

  virtual void enterIdentifierList(PnfCParser::IdentifierListContext *ctx) = 0;
  virtual void exitIdentifierList(PnfCParser::IdentifierListContext *ctx) = 0;

  virtual void enterAux_rule__parameterList_2(PnfCParser::Aux_rule__parameterList_2Context *ctx) = 0;
  virtual void exitAux_rule__parameterList_2(PnfCParser::Aux_rule__parameterList_2Context *ctx) = 0;

  virtual void enterKleene_star__parameterList_1(PnfCParser::Kleene_star__parameterList_1Context *ctx) = 0;
  virtual void exitKleene_star__parameterList_1(PnfCParser::Kleene_star__parameterList_1Context *ctx) = 0;

  virtual void enterParameterList(PnfCParser::ParameterListContext *ctx) = 0;
  virtual void exitParameterList(PnfCParser::ParameterListContext *ctx) = 0;

  virtual void enterAux_rule__directAbstractDeclarator_13(PnfCParser::Aux_rule__directAbstractDeclarator_13Context *ctx) = 0;
  virtual void exitAux_rule__directAbstractDeclarator_13(PnfCParser::Aux_rule__directAbstractDeclarator_13Context *ctx) = 0;

  virtual void enterKleene_star__directAbstractDeclarator_12(PnfCParser::Kleene_star__directAbstractDeclarator_12Context *ctx) = 0;
  virtual void exitKleene_star__directAbstractDeclarator_12(PnfCParser::Kleene_star__directAbstractDeclarator_12Context *ctx) = 0;

  virtual void enterAux_rule__directAbstractDeclarator_14(PnfCParser::Aux_rule__directAbstractDeclarator_14Context *ctx) = 0;
  virtual void exitAux_rule__directAbstractDeclarator_14(PnfCParser::Aux_rule__directAbstractDeclarator_14Context *ctx) = 0;

  virtual void enterDirectAbstractDeclarator(PnfCParser::DirectAbstractDeclaratorContext *ctx) = 0;
  virtual void exitDirectAbstractDeclarator(PnfCParser::DirectAbstractDeclaratorContext *ctx) = 0;

  virtual void enterDesignatorList(PnfCParser::DesignatorListContext *ctx) = 0;
  virtual void exitDesignatorList(PnfCParser::DesignatorListContext *ctx) = 0;

  virtual void enterBlockItemList(PnfCParser::BlockItemListContext *ctx) = 0;
  virtual void exitBlockItemList(PnfCParser::BlockItemListContext *ctx) = 0;

  virtual void enterTranslationUnit(PnfCParser::TranslationUnitContext *ctx) = 0;
  virtual void exitTranslationUnit(PnfCParser::TranslationUnitContext *ctx) = 0;

  virtual void enterAux_rule__declarationList_2(PnfCParser::Aux_rule__declarationList_2Context *ctx) = 0;
  virtual void exitAux_rule__declarationList_2(PnfCParser::Aux_rule__declarationList_2Context *ctx) = 0;

  virtual void enterDeclarationList(PnfCParser::DeclarationListContext *ctx) = 0;
  virtual void exitDeclarationList(PnfCParser::DeclarationListContext *ctx) = 0;

  virtual void enterKleene_plus__structDeclarationList_3(PnfCParser::Kleene_plus__structDeclarationList_3Context *ctx) = 0;
  virtual void exitKleene_plus__structDeclarationList_3(PnfCParser::Kleene_plus__structDeclarationList_3Context *ctx) = 0;

  virtual void enterKleene_plus__typeQualifierList_3(PnfCParser::Kleene_plus__typeQualifierList_3Context *ctx) = 0;
  virtual void exitKleene_plus__typeQualifierList_3(PnfCParser::Kleene_plus__typeQualifierList_3Context *ctx) = 0;

  virtual void enterKleene_plus__designatorList_3(PnfCParser::Kleene_plus__designatorList_3Context *ctx) = 0;
  virtual void exitKleene_plus__designatorList_3(PnfCParser::Kleene_plus__designatorList_3Context *ctx) = 0;

  virtual void enterKleene_plus__blockItemList_3(PnfCParser::Kleene_plus__blockItemList_3Context *ctx) = 0;
  virtual void exitKleene_plus__blockItemList_3(PnfCParser::Kleene_plus__blockItemList_3Context *ctx) = 0;

  virtual void enterKleene_plus__translationUnit_3(PnfCParser::Kleene_plus__translationUnit_3Context *ctx) = 0;
  virtual void exitKleene_plus__translationUnit_3(PnfCParser::Kleene_plus__translationUnit_3Context *ctx) = 0;

  virtual void enterKleene_plus__declarationList_3(PnfCParser::Kleene_plus__declarationList_3Context *ctx) = 0;
  virtual void exitKleene_plus__declarationList_3(PnfCParser::Kleene_plus__declarationList_3Context *ctx) = 0;

  virtual void enterOptional__postfixExpression_5(PnfCParser::Optional__postfixExpression_5Context *ctx) = 0;
  virtual void exitOptional__postfixExpression_5(PnfCParser::Optional__postfixExpression_5Context *ctx) = 0;

  virtual void enterAux_rule__initDeclarator_1(PnfCParser::Aux_rule__initDeclarator_1Context *ctx) = 0;
  virtual void exitAux_rule__initDeclarator_1(PnfCParser::Aux_rule__initDeclarator_1Context *ctx) = 0;

  virtual void enterOptional__initDeclarator_2(PnfCParser::Optional__initDeclarator_2Context *ctx) = 0;
  virtual void exitOptional__initDeclarator_2(PnfCParser::Optional__initDeclarator_2Context *ctx) = 0;

  virtual void enterAux_rule__enumerator_1(PnfCParser::Aux_rule__enumerator_1Context *ctx) = 0;
  virtual void exitAux_rule__enumerator_1(PnfCParser::Aux_rule__enumerator_1Context *ctx) = 0;

  virtual void enterOptional__enumerator_2(PnfCParser::Optional__enumerator_2Context *ctx) = 0;
  virtual void exitOptional__enumerator_2(PnfCParser::Optional__enumerator_2Context *ctx) = 0;

  virtual void enterAux_rule__parameterTypeList_1(PnfCParser::Aux_rule__parameterTypeList_1Context *ctx) = 0;
  virtual void exitAux_rule__parameterTypeList_1(PnfCParser::Aux_rule__parameterTypeList_1Context *ctx) = 0;

  virtual void enterOptional__parameterTypeList_2(PnfCParser::Optional__parameterTypeList_2Context *ctx) = 0;
  virtual void exitOptional__parameterTypeList_2(PnfCParser::Optional__parameterTypeList_2Context *ctx) = 0;

  virtual void enterAltnt_block__primaryExpression_3(PnfCParser::Altnt_block__primaryExpression_3Context *ctx) = 0;
  virtual void exitAltnt_block__primaryExpression_3(PnfCParser::Altnt_block__primaryExpression_3Context *ctx) = 0;

  virtual void enterAltnt_block__unaryExpression_1(PnfCParser::Altnt_block__unaryExpression_1Context *ctx) = 0;
  virtual void exitAltnt_block__unaryExpression_1(PnfCParser::Altnt_block__unaryExpression_1Context *ctx) = 0;

  virtual void enterAltnt_block__unaryExpression_2(PnfCParser::Altnt_block__unaryExpression_2Context *ctx) = 0;
  virtual void exitAltnt_block__unaryExpression_2(PnfCParser::Altnt_block__unaryExpression_2Context *ctx) = 0;

  virtual void enterAltnt_block__genericAssociation_1(PnfCParser::Altnt_block__genericAssociation_1Context *ctx) = 0;
  virtual void exitAltnt_block__genericAssociation_1(PnfCParser::Altnt_block__genericAssociation_1Context *ctx) = 0;

  virtual void enterAltnt_block__postfixExpression_7(PnfCParser::Altnt_block__postfixExpression_7Context *ctx) = 0;
  virtual void exitAltnt_block__postfixExpression_7(PnfCParser::Altnt_block__postfixExpression_7Context *ctx) = 0;

  virtual void enterAltnt_block__postfixExpression_8(PnfCParser::Altnt_block__postfixExpression_8Context *ctx) = 0;
  virtual void exitAltnt_block__postfixExpression_8(PnfCParser::Altnt_block__postfixExpression_8Context *ctx) = 0;

  virtual void enterAltnt_block__multiplicativeExpression_3(PnfCParser::Altnt_block__multiplicativeExpression_3Context *ctx) = 0;
  virtual void exitAltnt_block__multiplicativeExpression_3(PnfCParser::Altnt_block__multiplicativeExpression_3Context *ctx) = 0;

  virtual void enterAltnt_block__additiveExpression_3(PnfCParser::Altnt_block__additiveExpression_3Context *ctx) = 0;
  virtual void exitAltnt_block__additiveExpression_3(PnfCParser::Altnt_block__additiveExpression_3Context *ctx) = 0;

  virtual void enterAltnt_block__shiftExpression_3(PnfCParser::Altnt_block__shiftExpression_3Context *ctx) = 0;
  virtual void exitAltnt_block__shiftExpression_3(PnfCParser::Altnt_block__shiftExpression_3Context *ctx) = 0;

  virtual void enterAltnt_block__relationalExpression_3(PnfCParser::Altnt_block__relationalExpression_3Context *ctx) = 0;
  virtual void exitAltnt_block__relationalExpression_3(PnfCParser::Altnt_block__relationalExpression_3Context *ctx) = 0;

  virtual void enterAltnt_block__equalityExpression_3(PnfCParser::Altnt_block__equalityExpression_3Context *ctx) = 0;
  virtual void exitAltnt_block__equalityExpression_3(PnfCParser::Altnt_block__equalityExpression_3Context *ctx) = 0;

  virtual void enterAltnt_block__typeSpecifier_1(PnfCParser::Altnt_block__typeSpecifier_1Context *ctx) = 0;
  virtual void exitAltnt_block__typeSpecifier_1(PnfCParser::Altnt_block__typeSpecifier_1Context *ctx) = 0;

  virtual void enterAltnt_block__alignmentSpecifier_1(PnfCParser::Altnt_block__alignmentSpecifier_1Context *ctx) = 0;
  virtual void exitAltnt_block__alignmentSpecifier_1(PnfCParser::Altnt_block__alignmentSpecifier_1Context *ctx) = 0;

  virtual void enterAltnt_block__structOrUnionSpecifier_2(PnfCParser::Altnt_block__structOrUnionSpecifier_2Context *ctx) = 0;
  virtual void exitAltnt_block__structOrUnionSpecifier_2(PnfCParser::Altnt_block__structOrUnionSpecifier_2Context *ctx) = 0;

  virtual void enterAltnt_block__enumSpecifier_3(PnfCParser::Altnt_block__enumSpecifier_3Context *ctx) = 0;
  virtual void exitAltnt_block__enumSpecifier_3(PnfCParser::Altnt_block__enumSpecifier_3Context *ctx) = 0;

  virtual void enterAltnt_block__pointer_5(PnfCParser::Altnt_block__pointer_5Context *ctx) = 0;
  virtual void exitAltnt_block__pointer_5(PnfCParser::Altnt_block__pointer_5Context *ctx) = 0;

  virtual void enterAltnt_block__directDeclarator_9(PnfCParser::Altnt_block__directDeclarator_9Context *ctx) = 0;
  virtual void exitAltnt_block__directDeclarator_9(PnfCParser::Altnt_block__directDeclarator_9Context *ctx) = 0;

  virtual void enterAltnt_block__directDeclarator_10(PnfCParser::Altnt_block__directDeclarator_10Context *ctx) = 0;
  virtual void exitAltnt_block__directDeclarator_10(PnfCParser::Altnt_block__directDeclarator_10Context *ctx) = 0;

  virtual void enterAltnt_block__directAbstractDeclarator_15(PnfCParser::Altnt_block__directAbstractDeclarator_15Context *ctx) = 0;
  virtual void exitAltnt_block__directAbstractDeclarator_15(PnfCParser::Altnt_block__directAbstractDeclarator_15Context *ctx) = 0;

  virtual void enterAltnt_block__directAbstractDeclarator_17(PnfCParser::Altnt_block__directAbstractDeclarator_17Context *ctx) = 0;
  virtual void exitAltnt_block__directAbstractDeclarator_17(PnfCParser::Altnt_block__directAbstractDeclarator_17Context *ctx) = 0;

  virtual void enterAltnt_block__labeledStatement_1(PnfCParser::Altnt_block__labeledStatement_1Context *ctx) = 0;
  virtual void exitAltnt_block__labeledStatement_1(PnfCParser::Altnt_block__labeledStatement_1Context *ctx) = 0;

  virtual void enterAltnt_block__jumpStatement_2(PnfCParser::Altnt_block__jumpStatement_2Context *ctx) = 0;
  virtual void exitAltnt_block__jumpStatement_2(PnfCParser::Altnt_block__jumpStatement_2Context *ctx) = 0;

  virtual void enterAltnt_block__enumSpecifier_4(PnfCParser::Altnt_block__enumSpecifier_4Context *ctx) = 0;
  virtual void exitAltnt_block__enumSpecifier_4(PnfCParser::Altnt_block__enumSpecifier_4Context *ctx) = 0;

  virtual void enterAltnt_block__directDeclarator_11(PnfCParser::Altnt_block__directDeclarator_11Context *ctx) = 0;
  virtual void exitAltnt_block__directDeclarator_11(PnfCParser::Altnt_block__directDeclarator_11Context *ctx) = 0;

  virtual void enterAltnt_block__iterationStatement_7(PnfCParser::Altnt_block__iterationStatement_7Context *ctx) = 0;
  virtual void exitAltnt_block__iterationStatement_7(PnfCParser::Altnt_block__iterationStatement_7Context *ctx) = 0;

  virtual void enterAltnt_block__jumpStatement_3(PnfCParser::Altnt_block__jumpStatement_3Context *ctx) = 0;
  virtual void exitAltnt_block__jumpStatement_3(PnfCParser::Altnt_block__jumpStatement_3Context *ctx) = 0;

  virtual void enterAux_rule__postfixExpression_4(PnfCParser::Aux_rule__postfixExpression_4Context *ctx) = 0;
  virtual void exitAux_rule__postfixExpression_4(PnfCParser::Aux_rule__postfixExpression_4Context *ctx) = 0;

  virtual void enterDeclarationSpecifier(PnfCParser::DeclarationSpecifierContext *ctx) = 0;
  virtual void exitDeclarationSpecifier(PnfCParser::DeclarationSpecifierContext *ctx) = 0;

  virtual void enterAux_rule__structDeclarationList_2(PnfCParser::Aux_rule__structDeclarationList_2Context *ctx) = 0;
  virtual void exitAux_rule__structDeclarationList_2(PnfCParser::Aux_rule__structDeclarationList_2Context *ctx) = 0;

  virtual void enterAux_rule__designatorList_2(PnfCParser::Aux_rule__designatorList_2Context *ctx) = 0;
  virtual void exitAux_rule__designatorList_2(PnfCParser::Aux_rule__designatorList_2Context *ctx) = 0;

  virtual void enterStatement(PnfCParser::StatementContext *ctx) = 0;
  virtual void exitStatement(PnfCParser::StatementContext *ctx) = 0;

  virtual void enterAux_rule__blockItemList_2(PnfCParser::Aux_rule__blockItemList_2Context *ctx) = 0;
  virtual void exitAux_rule__blockItemList_2(PnfCParser::Aux_rule__blockItemList_2Context *ctx) = 0;

  virtual void enterAux_rule__translationUnit_2(PnfCParser::Aux_rule__translationUnit_2Context *ctx) = 0;
  virtual void exitAux_rule__translationUnit_2(PnfCParser::Aux_rule__translationUnit_2Context *ctx) = 0;

  virtual void enterAltnt_block__unaryExpression_3(PnfCParser::Altnt_block__unaryExpression_3Context *ctx) = 0;
  virtual void exitAltnt_block__unaryExpression_3(PnfCParser::Altnt_block__unaryExpression_3Context *ctx) = 0;

  virtual void enterAltnt_block__unaryExpression_4(PnfCParser::Altnt_block__unaryExpression_4Context *ctx) = 0;
  virtual void exitAltnt_block__unaryExpression_4(PnfCParser::Altnt_block__unaryExpression_4Context *ctx) = 0;

  virtual void enterAltnt_block__typeSpecifier_2(PnfCParser::Altnt_block__typeSpecifier_2Context *ctx) = 0;
  virtual void exitAltnt_block__typeSpecifier_2(PnfCParser::Altnt_block__typeSpecifier_2Context *ctx) = 0;

  virtual void enterAltnt_block__specifierQualifierList_3(PnfCParser::Altnt_block__specifierQualifierList_3Context *ctx) = 0;
  virtual void exitAltnt_block__specifierQualifierList_3(PnfCParser::Altnt_block__specifierQualifierList_3Context *ctx) = 0;

  virtual void enterAltnt_block__pointer_8(PnfCParser::Altnt_block__pointer_8Context *ctx) = 0;
  virtual void exitAltnt_block__pointer_8(PnfCParser::Altnt_block__pointer_8Context *ctx) = 0;

  virtual void enterAltnt_block__directDeclarator_12(PnfCParser::Altnt_block__directDeclarator_12Context *ctx) = 0;
  virtual void exitAltnt_block__directDeclarator_12(PnfCParser::Altnt_block__directDeclarator_12Context *ctx) = 0;

  virtual void enterAltnt_block__parameterDeclaration_2(PnfCParser::Altnt_block__parameterDeclaration_2Context *ctx) = 0;
  virtual void exitAltnt_block__parameterDeclaration_2(PnfCParser::Altnt_block__parameterDeclaration_2Context *ctx) = 0;

  virtual void enterAltnt_block__directAbstractDeclarator_20(PnfCParser::Altnt_block__directAbstractDeclarator_20Context *ctx) = 0;
  virtual void exitAltnt_block__directAbstractDeclarator_20(PnfCParser::Altnt_block__directAbstractDeclarator_20Context *ctx) = 0;

  virtual void enterAltnt_block__iterationStatement_8(PnfCParser::Altnt_block__iterationStatement_8Context *ctx) = 0;
  virtual void exitAltnt_block__iterationStatement_8(PnfCParser::Altnt_block__iterationStatement_8Context *ctx) = 0;

  virtual void enterAltnt_block__statement_1(PnfCParser::Altnt_block__statement_1Context *ctx) = 0;
  virtual void exitAltnt_block__statement_1(PnfCParser::Altnt_block__statement_1Context *ctx) = 0;

  virtual void enterAltnt_block__statement_2(PnfCParser::Altnt_block__statement_2Context *ctx) = 0;
  virtual void exitAltnt_block__statement_2(PnfCParser::Altnt_block__statement_2Context *ctx) = 0;

  virtual void enterAux_rule__unaryExpression_5(PnfCParser::Aux_rule__unaryExpression_5Context *ctx) = 0;
  virtual void exitAux_rule__unaryExpression_5(PnfCParser::Aux_rule__unaryExpression_5Context *ctx) = 0;

  virtual void enterAux_rule__unaryExpression_6(PnfCParser::Aux_rule__unaryExpression_6Context *ctx) = 0;
  virtual void exitAux_rule__unaryExpression_6(PnfCParser::Aux_rule__unaryExpression_6Context *ctx) = 0;

  virtual void enterAux_rule__unaryExpression_7(PnfCParser::Aux_rule__unaryExpression_7Context *ctx) = 0;
  virtual void exitAux_rule__unaryExpression_7(PnfCParser::Aux_rule__unaryExpression_7Context *ctx) = 0;

  virtual void enterAux_rule__unaryExpression_8(PnfCParser::Aux_rule__unaryExpression_8Context *ctx) = 0;
  virtual void exitAux_rule__unaryExpression_8(PnfCParser::Aux_rule__unaryExpression_8Context *ctx) = 0;

  virtual void enterAux_rule__castExpression_2(PnfCParser::Aux_rule__castExpression_2Context *ctx) = 0;
  virtual void exitAux_rule__castExpression_2(PnfCParser::Aux_rule__castExpression_2Context *ctx) = 0;

  virtual void enterAux_rule__assignmentExpression_1(PnfCParser::Aux_rule__assignmentExpression_1Context *ctx) = 0;
  virtual void exitAux_rule__assignmentExpression_1(PnfCParser::Aux_rule__assignmentExpression_1Context *ctx) = 0;

  virtual void enterAux_rule__declaration_3(PnfCParser::Aux_rule__declaration_3Context *ctx) = 0;
  virtual void exitAux_rule__declaration_3(PnfCParser::Aux_rule__declaration_3Context *ctx) = 0;

  virtual void enterAux_rule__typeSpecifier_3(PnfCParser::Aux_rule__typeSpecifier_3Context *ctx) = 0;
  virtual void exitAux_rule__typeSpecifier_3(PnfCParser::Aux_rule__typeSpecifier_3Context *ctx) = 0;

  virtual void enterAux_rule__structDeclarator_2(PnfCParser::Aux_rule__structDeclarator_2Context *ctx) = 0;
  virtual void exitAux_rule__structDeclarator_2(PnfCParser::Aux_rule__structDeclarator_2Context *ctx) = 0;

  virtual void enterAux_rule__gccDeclaratorExtension_2(PnfCParser::Aux_rule__gccDeclaratorExtension_2Context *ctx) = 0;
  virtual void exitAux_rule__gccDeclaratorExtension_2(PnfCParser::Aux_rule__gccDeclaratorExtension_2Context *ctx) = 0;

  virtual void enterAux_rule__abstractDeclarator_3(PnfCParser::Aux_rule__abstractDeclarator_3Context *ctx) = 0;
  virtual void exitAux_rule__abstractDeclarator_3(PnfCParser::Aux_rule__abstractDeclarator_3Context *ctx) = 0;

  virtual void enterAux_rule__initializer_2(PnfCParser::Aux_rule__initializer_2Context *ctx) = 0;
  virtual void exitAux_rule__initializer_2(PnfCParser::Aux_rule__initializer_2Context *ctx) = 0;

  virtual void enterAux_rule__postfixExpression_10(PnfCParser::Aux_rule__postfixExpression_10Context *ctx) = 0;
  virtual void exitAux_rule__postfixExpression_10(PnfCParser::Aux_rule__postfixExpression_10Context *ctx) = 0;

  virtual void enterAux_rule__postfixExpression_11(PnfCParser::Aux_rule__postfixExpression_11Context *ctx) = 0;
  virtual void exitAux_rule__postfixExpression_11(PnfCParser::Aux_rule__postfixExpression_11Context *ctx) = 0;

  virtual void enterAux_rule__postfixExpression_12(PnfCParser::Aux_rule__postfixExpression_12Context *ctx) = 0;
  virtual void exitAux_rule__postfixExpression_12(PnfCParser::Aux_rule__postfixExpression_12Context *ctx) = 0;

  virtual void enterAux_rule__directDeclarator_13(PnfCParser::Aux_rule__directDeclarator_13Context *ctx) = 0;
  virtual void exitAux_rule__directDeclarator_13(PnfCParser::Aux_rule__directDeclarator_13Context *ctx) = 0;

  virtual void enterAux_rule__directDeclarator_14(PnfCParser::Aux_rule__directDeclarator_14Context *ctx) = 0;
  virtual void exitAux_rule__directDeclarator_14(PnfCParser::Aux_rule__directDeclarator_14Context *ctx) = 0;

  virtual void enterAux_rule__directDeclarator_15(PnfCParser::Aux_rule__directDeclarator_15Context *ctx) = 0;
  virtual void exitAux_rule__directDeclarator_15(PnfCParser::Aux_rule__directDeclarator_15Context *ctx) = 0;

  virtual void enterAux_rule__directAbstractDeclarator_21(PnfCParser::Aux_rule__directAbstractDeclarator_21Context *ctx) = 0;
  virtual void exitAux_rule__directAbstractDeclarator_21(PnfCParser::Aux_rule__directAbstractDeclarator_21Context *ctx) = 0;

  virtual void enterAux_rule__directAbstractDeclarator_22(PnfCParser::Aux_rule__directAbstractDeclarator_22Context *ctx) = 0;
  virtual void exitAux_rule__directAbstractDeclarator_22(PnfCParser::Aux_rule__directAbstractDeclarator_22Context *ctx) = 0;

  virtual void enterAux_rule__directAbstractDeclarator_23(PnfCParser::Aux_rule__directAbstractDeclarator_23Context *ctx) = 0;
  virtual void exitAux_rule__directAbstractDeclarator_23(PnfCParser::Aux_rule__directAbstractDeclarator_23Context *ctx) = 0;

  virtual void enterAux_rule__directAbstractDeclarator_24(PnfCParser::Aux_rule__directAbstractDeclarator_24Context *ctx) = 0;
  virtual void exitAux_rule__directAbstractDeclarator_24(PnfCParser::Aux_rule__directAbstractDeclarator_24Context *ctx) = 0;

  virtual void enterAux_rule__primaryExpression_4(PnfCParser::Aux_rule__primaryExpression_4Context *ctx) = 0;
  virtual void exitAux_rule__primaryExpression_4(PnfCParser::Aux_rule__primaryExpression_4Context *ctx) = 0;

  virtual void enterAux_rule__primaryExpression_5(PnfCParser::Aux_rule__primaryExpression_5Context *ctx) = 0;
  virtual void exitAux_rule__primaryExpression_5(PnfCParser::Aux_rule__primaryExpression_5Context *ctx) = 0;

  virtual void enterAux_rule__primaryExpression_6(PnfCParser::Aux_rule__primaryExpression_6Context *ctx) = 0;
  virtual void exitAux_rule__primaryExpression_6(PnfCParser::Aux_rule__primaryExpression_6Context *ctx) = 0;

  virtual void enterAux_rule__primaryExpression_7(PnfCParser::Aux_rule__primaryExpression_7Context *ctx) = 0;
  virtual void exitAux_rule__primaryExpression_7(PnfCParser::Aux_rule__primaryExpression_7Context *ctx) = 0;

  virtual void enterAux_rule__unaryExpression_9(PnfCParser::Aux_rule__unaryExpression_9Context *ctx) = 0;
  virtual void exitAux_rule__unaryExpression_9(PnfCParser::Aux_rule__unaryExpression_9Context *ctx) = 0;

  virtual void enterAux_rule__unaryExpression_10(PnfCParser::Aux_rule__unaryExpression_10Context *ctx) = 0;
  virtual void exitAux_rule__unaryExpression_10(PnfCParser::Aux_rule__unaryExpression_10Context *ctx) = 0;

  virtual void enterAux_rule__typeSpecifier_4(PnfCParser::Aux_rule__typeSpecifier_4Context *ctx) = 0;
  virtual void exitAux_rule__typeSpecifier_4(PnfCParser::Aux_rule__typeSpecifier_4Context *ctx) = 0;

  virtual void enterAux_rule__typeSpecifier_5(PnfCParser::Aux_rule__typeSpecifier_5Context *ctx) = 0;
  virtual void exitAux_rule__typeSpecifier_5(PnfCParser::Aux_rule__typeSpecifier_5Context *ctx) = 0;

  virtual void enterAux_rule__structOrUnionSpecifier_3(PnfCParser::Aux_rule__structOrUnionSpecifier_3Context *ctx) = 0;
  virtual void exitAux_rule__structOrUnionSpecifier_3(PnfCParser::Aux_rule__structOrUnionSpecifier_3Context *ctx) = 0;

  virtual void enterAux_rule__enumSpecifier_6(PnfCParser::Aux_rule__enumSpecifier_6Context *ctx) = 0;
  virtual void exitAux_rule__enumSpecifier_6(PnfCParser::Aux_rule__enumSpecifier_6Context *ctx) = 0;

  virtual void enterAux_rule__directDeclarator_16(PnfCParser::Aux_rule__directDeclarator_16Context *ctx) = 0;
  virtual void exitAux_rule__directDeclarator_16(PnfCParser::Aux_rule__directDeclarator_16Context *ctx) = 0;

  virtual void enterAux_rule__directDeclarator_17(PnfCParser::Aux_rule__directDeclarator_17Context *ctx) = 0;
  virtual void exitAux_rule__directDeclarator_17(PnfCParser::Aux_rule__directDeclarator_17Context *ctx) = 0;

  virtual void enterAux_rule__directAbstractDeclarator_25(PnfCParser::Aux_rule__directAbstractDeclarator_25Context *ctx) = 0;
  virtual void exitAux_rule__directAbstractDeclarator_25(PnfCParser::Aux_rule__directAbstractDeclarator_25Context *ctx) = 0;

  virtual void enterAux_rule__directAbstractDeclarator_26(PnfCParser::Aux_rule__directAbstractDeclarator_26Context *ctx) = 0;
  virtual void exitAux_rule__directAbstractDeclarator_26(PnfCParser::Aux_rule__directAbstractDeclarator_26Context *ctx) = 0;

  virtual void enterAux_rule__labeledStatement_2(PnfCParser::Aux_rule__labeledStatement_2Context *ctx) = 0;
  virtual void exitAux_rule__labeledStatement_2(PnfCParser::Aux_rule__labeledStatement_2Context *ctx) = 0;

  virtual void enterAux_rule__jumpStatement_4(PnfCParser::Aux_rule__jumpStatement_4Context *ctx) = 0;
  virtual void exitAux_rule__jumpStatement_4(PnfCParser::Aux_rule__jumpStatement_4Context *ctx) = 0;

  virtual void enterAux_rule__jumpStatement_5(PnfCParser::Aux_rule__jumpStatement_5Context *ctx) = 0;
  virtual void exitAux_rule__jumpStatement_5(PnfCParser::Aux_rule__jumpStatement_5Context *ctx) = 0;

  virtual void enterAux_rule__directDeclarator_18(PnfCParser::Aux_rule__directDeclarator_18Context *ctx) = 0;
  virtual void exitAux_rule__directDeclarator_18(PnfCParser::Aux_rule__directDeclarator_18Context *ctx) = 0;

  virtual void enterAux_rule__directDeclarator_19(PnfCParser::Aux_rule__directDeclarator_19Context *ctx) = 0;
  virtual void exitAux_rule__directDeclarator_19(PnfCParser::Aux_rule__directDeclarator_19Context *ctx) = 0;

  virtual void enterAux_rule__postfixExpression_13(PnfCParser::Aux_rule__postfixExpression_13Context *ctx) = 0;
  virtual void exitAux_rule__postfixExpression_13(PnfCParser::Aux_rule__postfixExpression_13Context *ctx) = 0;

  virtual void enterAux_rule__postfixExpression_14(PnfCParser::Aux_rule__postfixExpression_14Context *ctx) = 0;
  virtual void exitAux_rule__postfixExpression_14(PnfCParser::Aux_rule__postfixExpression_14Context *ctx) = 0;

  virtual void enterAux_rule__declarationSpecifier_1(PnfCParser::Aux_rule__declarationSpecifier_1Context *ctx) = 0;
  virtual void exitAux_rule__declarationSpecifier_1(PnfCParser::Aux_rule__declarationSpecifier_1Context *ctx) = 0;

  virtual void enterAux_rule__structDeclarationList_4(PnfCParser::Aux_rule__structDeclarationList_4Context *ctx) = 0;
  virtual void exitAux_rule__structDeclarationList_4(PnfCParser::Aux_rule__structDeclarationList_4Context *ctx) = 0;

  virtual void enterAux_rule__designatorList_4(PnfCParser::Aux_rule__designatorList_4Context *ctx) = 0;
  virtual void exitAux_rule__designatorList_4(PnfCParser::Aux_rule__designatorList_4Context *ctx) = 0;

  virtual void enterAux_rule__designatorList_5(PnfCParser::Aux_rule__designatorList_5Context *ctx) = 0;
  virtual void exitAux_rule__designatorList_5(PnfCParser::Aux_rule__designatorList_5Context *ctx) = 0;

  virtual void enterAux_rule__statement_3(PnfCParser::Aux_rule__statement_3Context *ctx) = 0;
  virtual void exitAux_rule__statement_3(PnfCParser::Aux_rule__statement_3Context *ctx) = 0;

  virtual void enterAux_rule__statement_4(PnfCParser::Aux_rule__statement_4Context *ctx) = 0;
  virtual void exitAux_rule__statement_4(PnfCParser::Aux_rule__statement_4Context *ctx) = 0;

  virtual void enterAux_rule__statement_5(PnfCParser::Aux_rule__statement_5Context *ctx) = 0;
  virtual void exitAux_rule__statement_5(PnfCParser::Aux_rule__statement_5Context *ctx) = 0;

  virtual void enterAux_rule__iterationStatement_9(PnfCParser::Aux_rule__iterationStatement_9Context *ctx) = 0;
  virtual void exitAux_rule__iterationStatement_9(PnfCParser::Aux_rule__iterationStatement_9Context *ctx) = 0;

  virtual void enterAux_rule__statement_6(PnfCParser::Aux_rule__statement_6Context *ctx) = 0;
  virtual void exitAux_rule__statement_6(PnfCParser::Aux_rule__statement_6Context *ctx) = 0;

  virtual void enterAux_rule__statement_7(PnfCParser::Aux_rule__statement_7Context *ctx) = 0;
  virtual void exitAux_rule__statement_7(PnfCParser::Aux_rule__statement_7Context *ctx) = 0;


};

}  // namespace antlr_C_perses
