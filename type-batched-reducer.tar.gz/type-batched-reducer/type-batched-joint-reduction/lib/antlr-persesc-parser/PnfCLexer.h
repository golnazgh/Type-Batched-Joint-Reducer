
// Generated from PnfC.g4 by ANTLR 4.7.2

#pragma once


#include "antlr4-runtime.h"


namespace antlr_C_perses {


class  PnfCLexer : public antlr4::Lexer {
public:
  enum {
    T__0 = 1, T__1 = 2, T__2 = 3, T__3 = 4, T__4 = 5, T__5 = 6, T__6 = 7, 
    T__7 = 8, T__8 = 9, T__9 = 10, T__10 = 11, T__11 = 12, T__12 = 13, T__13 = 14, 
    IncludeDirective = 15, Auto = 16, Break = 17, Case = 18, Char = 19, 
    Const = 20, Nonnull = 21, Nullable = 22, Continue = 23, Default = 24, 
    Do = 25, Double = 26, Else = 27, Enum = 28, Extern = 29, Float = 30, 
    For = 31, Goto = 32, If = 33, Inline = 34, Int = 35, Long = 36, Register = 37, 
    Restrict = 38, Restrict_gcc = 39, Restrict_gcc2 = 40, Extension_gcc = 41, 
    Return = 42, Short = 43, Signed = 44, Sizeof = 45, Static = 46, Struct = 47, 
    Switch = 48, Typedef = 49, Union = 50, Unsigned = 51, Void = 52, Volatile = 53, 
    While = 54, Alignas = 55, Alignof = 56, Alignof_gcc = 57, Atomic = 58, 
    Bool = 59, Complex = 60, Generic = 61, Imaginary = 62, Noreturn = 63, 
    StaticAssert = 64, ThreadLocal = 65, LeftParen = 66, RightParen = 67, 
    LeftBracket = 68, RightBracket = 69, LeftBrace = 70, RightBrace = 71, 
    Less = 72, LessEqual = 73, Greater = 74, GreaterEqual = 75, LeftShift = 76, 
    RightShift = 77, Plus = 78, PlusPlus = 79, Minus = 80, MinusMinus = 81, 
    Star = 82, Div = 83, Mod = 84, And = 85, Or = 86, AndAnd = 87, OrOr = 88, 
    Caret = 89, Not = 90, Tilde = 91, Question = 92, Colon = 93, Semi = 94, 
    Comma = 95, Assign = 96, StarAssign = 97, DivAssign = 98, ModAssign = 99, 
    PlusAssign = 100, MinusAssign = 101, LeftShiftAssign = 102, RightShiftAssign = 103, 
    AndAssign = 104, XorAssign = 105, OrAssign = 106, Equal = 107, NotEqual = 108, 
    Arrow = 109, Dot = 110, Ellipsis = 111, Identifier = 112, Constant = 113, 
    StringLiteral = 114, ComplexDefine = 115, AsmBlock = 116, LineAfterPreprocessing = 117, 
    LineDirective = 118, PragmaDirective = 119, Whitespace = 120, Newline = 121, 
    BlockComment = 122, LineComment = 123
  };

  PnfCLexer(antlr4::CharStream *input);
  ~PnfCLexer();

  virtual std::string getGrammarFileName() const override;
  virtual const std::vector<std::string>& getRuleNames() const override;

  virtual const std::vector<std::string>& getChannelNames() const override;
  virtual const std::vector<std::string>& getModeNames() const override;
  virtual const std::vector<std::string>& getTokenNames() const override; // deprecated, use vocabulary instead
  virtual antlr4::dfa::Vocabulary& getVocabulary() const override;

  virtual const std::vector<uint16_t> getSerializedATN() const override;
  virtual const antlr4::atn::ATN& getATN() const override;

private:
  static std::vector<antlr4::dfa::DFA> _decisionToDFA;
  static antlr4::atn::PredictionContextCache _sharedContextCache;
  static std::vector<std::string> _ruleNames;
  static std::vector<std::string> _tokenNames;
  static std::vector<std::string> _channelNames;
  static std::vector<std::string> _modeNames;

  static std::vector<std::string> _literalNames;
  static std::vector<std::string> _symbolicNames;
  static antlr4::dfa::Vocabulary _vocabulary;
  static antlr4::atn::ATN _atn;
  static std::vector<uint16_t> _serializedATN;


  // Individual action functions triggered by action() above.

  // Individual semantic predicate functions triggered by sempred() above.

  struct Initializer {
    Initializer();
  };
  static Initializer _init;
};

}  // namespace antlr_C_perses
