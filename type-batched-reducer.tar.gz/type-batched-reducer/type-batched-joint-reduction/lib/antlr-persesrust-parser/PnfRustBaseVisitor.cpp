
// Generated from PnfRust.g4 by ANTLR 4.7.2


#include "PnfRustBaseVisitor.h"


using namespace antlr_rust_perses;

