
// Generated from PnfRust.g4 by ANTLR 4.7.2

#pragma once


#include "antlr4-runtime.h"
#include "PnfRustParser.h"


namespace antlr_rust_perses {

/**
 * This class defines an abstract visitor for a parse tree
 * produced by PnfRustParser.
 */
class  PnfRustVisitor : public antlr4::tree::AbstractParseTreeVisitor {
public:

  /**
   * Visit parse trees produced by PnfRustParser.
   */
    virtual antlrcpp::Any visitCrate(PnfRustParser::CrateContext *context) = 0;

    virtual antlrcpp::Any visitMod_body(PnfRustParser::Mod_bodyContext *context) = 0;

    virtual antlrcpp::Any visitVisibility(PnfRustParser::VisibilityContext *context) = 0;

    virtual antlrcpp::Any visitVisibility_restriction(PnfRustParser::Visibility_restrictionContext *context) = 0;

    virtual antlrcpp::Any visitItem(PnfRustParser::ItemContext *context) = 0;

    virtual antlrcpp::Any visitPub_item(PnfRustParser::Pub_itemContext *context) = 0;

    virtual antlrcpp::Any visitExtern_crate(PnfRustParser::Extern_crateContext *context) = 0;

    virtual antlrcpp::Any visitUse_decl(PnfRustParser::Use_declContext *context) = 0;

    virtual antlrcpp::Any visitUse_path(PnfRustParser::Use_pathContext *context) = 0;

    virtual antlrcpp::Any visitUse_suffix(PnfRustParser::Use_suffixContext *context) = 0;

    virtual antlrcpp::Any visitUse_item(PnfRustParser::Use_itemContext *context) = 0;

    virtual antlrcpp::Any visitUse_item_list(PnfRustParser::Use_item_listContext *context) = 0;

    virtual antlrcpp::Any visitRename(PnfRustParser::RenameContext *context) = 0;

    virtual antlrcpp::Any visitMod_decl_short(PnfRustParser::Mod_decl_shortContext *context) = 0;

    virtual antlrcpp::Any visitMod_decl(PnfRustParser::Mod_declContext *context) = 0;

    virtual antlrcpp::Any visitExtern_mod(PnfRustParser::Extern_modContext *context) = 0;

    virtual antlrcpp::Any visitForeign_item(PnfRustParser::Foreign_itemContext *context) = 0;

    virtual antlrcpp::Any visitForeign_item_tail(PnfRustParser::Foreign_item_tailContext *context) = 0;

    virtual antlrcpp::Any visitStatic_decl(PnfRustParser::Static_declContext *context) = 0;

    virtual antlrcpp::Any visitAssociated_static_decl(PnfRustParser::Associated_static_declContext *context) = 0;

    virtual antlrcpp::Any visitConst_decl(PnfRustParser::Const_declContext *context) = 0;

    virtual antlrcpp::Any visitAssociated_const_decl(PnfRustParser::Associated_const_declContext *context) = 0;

    virtual antlrcpp::Any visitFn_decl(PnfRustParser::Fn_declContext *context) = 0;

    virtual antlrcpp::Any visitMethod_decl(PnfRustParser::Method_declContext *context) = 0;

    virtual antlrcpp::Any visitTrait_method_decl(PnfRustParser::Trait_method_declContext *context) = 0;

    virtual antlrcpp::Any visitForeign_fn_decl(PnfRustParser::Foreign_fn_declContext *context) = 0;

    virtual antlrcpp::Any visitMacro_decl(PnfRustParser::Macro_declContext *context) = 0;

    virtual antlrcpp::Any visitMacro_head(PnfRustParser::Macro_headContext *context) = 0;

    virtual antlrcpp::Any visitFn_head(PnfRustParser::Fn_headContext *context) = 0;

    virtual antlrcpp::Any visitParam(PnfRustParser::ParamContext *context) = 0;

    virtual antlrcpp::Any visitParam_list(PnfRustParser::Param_listContext *context) = 0;

    virtual antlrcpp::Any visitVariadic_param_list(PnfRustParser::Variadic_param_listContext *context) = 0;

    virtual antlrcpp::Any visitVariadic_param_list_names_optional(PnfRustParser::Variadic_param_list_names_optionalContext *context) = 0;

    virtual antlrcpp::Any visitSelf_param(PnfRustParser::Self_paramContext *context) = 0;

    virtual antlrcpp::Any visitMethod_param_list(PnfRustParser::Method_param_listContext *context) = 0;

    virtual antlrcpp::Any visitTrait_method_param(PnfRustParser::Trait_method_paramContext *context) = 0;

    virtual antlrcpp::Any visitRestricted_pat(PnfRustParser::Restricted_patContext *context) = 0;

    virtual antlrcpp::Any visitTrait_method_param_list(PnfRustParser::Trait_method_param_listContext *context) = 0;

    virtual antlrcpp::Any visitRtype(PnfRustParser::RtypeContext *context) = 0;

    virtual antlrcpp::Any visitFn_rtype(PnfRustParser::Fn_rtypeContext *context) = 0;

    virtual antlrcpp::Any visitType_decl(PnfRustParser::Type_declContext *context) = 0;

    virtual antlrcpp::Any visitStruct_decl(PnfRustParser::Struct_declContext *context) = 0;

    virtual antlrcpp::Any visitStruct_tail(PnfRustParser::Struct_tailContext *context) = 0;

    virtual antlrcpp::Any visitTuple_struct_field(PnfRustParser::Tuple_struct_fieldContext *context) = 0;

    virtual antlrcpp::Any visitTuple_struct_field_list(PnfRustParser::Tuple_struct_field_listContext *context) = 0;

    virtual antlrcpp::Any visitField_decl(PnfRustParser::Field_declContext *context) = 0;

    virtual antlrcpp::Any visitField_decl_list(PnfRustParser::Field_decl_listContext *context) = 0;

    virtual antlrcpp::Any visitEnum_decl(PnfRustParser::Enum_declContext *context) = 0;

    virtual antlrcpp::Any visitEnum_variant(PnfRustParser::Enum_variantContext *context) = 0;

    virtual antlrcpp::Any visitEnum_variant_list(PnfRustParser::Enum_variant_listContext *context) = 0;

    virtual antlrcpp::Any visitEnum_variant_main(PnfRustParser::Enum_variant_mainContext *context) = 0;

    virtual antlrcpp::Any visitEnum_tuple_field(PnfRustParser::Enum_tuple_fieldContext *context) = 0;

    virtual antlrcpp::Any visitEnum_tuple_field_list(PnfRustParser::Enum_tuple_field_listContext *context) = 0;

    virtual antlrcpp::Any visitUnion_decl(PnfRustParser::Union_declContext *context) = 0;

    virtual antlrcpp::Any visitTrait_decl(PnfRustParser::Trait_declContext *context) = 0;

    virtual antlrcpp::Any visitTrait_alias(PnfRustParser::Trait_aliasContext *context) = 0;

    virtual antlrcpp::Any visitTrait_item(PnfRustParser::Trait_itemContext *context) = 0;

    virtual antlrcpp::Any visitTy_default(PnfRustParser::Ty_defaultContext *context) = 0;

    virtual antlrcpp::Any visitImpl_block(PnfRustParser::Impl_blockContext *context) = 0;

    virtual antlrcpp::Any visitImpl_what(PnfRustParser::Impl_whatContext *context) = 0;

    virtual antlrcpp::Any visitImpl_item(PnfRustParser::Impl_itemContext *context) = 0;

    virtual antlrcpp::Any visitImpl_item_tail(PnfRustParser::Impl_item_tailContext *context) = 0;

    virtual antlrcpp::Any visitAttr(PnfRustParser::AttrContext *context) = 0;

    virtual antlrcpp::Any visitInner_attr(PnfRustParser::Inner_attrContext *context) = 0;

    virtual antlrcpp::Any visitTt(PnfRustParser::TtContext *context) = 0;

    virtual antlrcpp::Any visitTt_delimited(PnfRustParser::Tt_delimitedContext *context) = 0;

    virtual antlrcpp::Any visitTt_brackets(PnfRustParser::Tt_bracketsContext *context) = 0;

    virtual antlrcpp::Any visitTt_block(PnfRustParser::Tt_blockContext *context) = 0;

    virtual antlrcpp::Any visitMacro_tail(PnfRustParser::Macro_tailContext *context) = 0;

    virtual antlrcpp::Any visitPath(PnfRustParser::PathContext *context) = 0;

    virtual antlrcpp::Any visitAs_trait(PnfRustParser::As_traitContext *context) = 0;

    virtual antlrcpp::Any visitPath_segment(PnfRustParser::Path_segmentContext *context) = 0;

    virtual antlrcpp::Any visitPath_segment_no_super(PnfRustParser::Path_segment_no_superContext *context) = 0;

    virtual antlrcpp::Any visitSimple_path(PnfRustParser::Simple_pathContext *context) = 0;

    virtual antlrcpp::Any visitSimple_path_segment(PnfRustParser::Simple_path_segmentContext *context) = 0;

    virtual antlrcpp::Any visitFor_lifetimes(PnfRustParser::For_lifetimesContext *context) = 0;

    virtual antlrcpp::Any visitLifetime_def_list(PnfRustParser::Lifetime_def_listContext *context) = 0;

    virtual antlrcpp::Any visitLifetime_def(PnfRustParser::Lifetime_defContext *context) = 0;

    virtual antlrcpp::Any visitType_path_main(PnfRustParser::Type_path_mainContext *context) = 0;

    virtual antlrcpp::Any visitTy_path_tail(PnfRustParser::Ty_path_tailContext *context) = 0;

    virtual antlrcpp::Any visitType_path_segment(PnfRustParser::Type_path_segmentContext *context) = 0;

    virtual antlrcpp::Any visitTy_path_segment_no_super(PnfRustParser::Ty_path_segment_no_superContext *context) = 0;

    virtual antlrcpp::Any visitWhere_clause(PnfRustParser::Where_clauseContext *context) = 0;

    virtual antlrcpp::Any visitWhere_bound_list(PnfRustParser::Where_bound_listContext *context) = 0;

    virtual antlrcpp::Any visitWhere_bound(PnfRustParser::Where_boundContext *context) = 0;

    virtual antlrcpp::Any visitEmpty_ok_colon_bound(PnfRustParser::Empty_ok_colon_boundContext *context) = 0;

    virtual antlrcpp::Any visitColon_bound(PnfRustParser::Colon_boundContext *context) = 0;

    virtual antlrcpp::Any visitPrim_bound(PnfRustParser::Prim_boundContext *context) = 0;

    virtual antlrcpp::Any visitInferred_type(PnfRustParser::Inferred_typeContext *context) = 0;

    virtual antlrcpp::Any visitArray_or_slice_type(PnfRustParser::Array_or_slice_typeContext *context) = 0;

    virtual antlrcpp::Any visitReference_type(PnfRustParser::Reference_typeContext *context) = 0;

    virtual antlrcpp::Any visitRaw_pointer_type(PnfRustParser::Raw_pointer_typeContext *context) = 0;

    virtual antlrcpp::Any visitNever_type(PnfRustParser::Never_typeContext *context) = 0;

    virtual antlrcpp::Any visitTuple_type(PnfRustParser::Tuple_typeContext *context) = 0;

    virtual antlrcpp::Any visitImpl_trait_type(PnfRustParser::Impl_trait_typeContext *context) = 0;

    virtual antlrcpp::Any visitImpl_trait_type_one_bound(PnfRustParser::Impl_trait_type_one_boundContext *context) = 0;

    virtual antlrcpp::Any visitTrait_object_type_one_bound(PnfRustParser::Trait_object_type_one_boundContext *context) = 0;

    virtual antlrcpp::Any visitType_param_bounds(PnfRustParser::Type_param_boundsContext *context) = 0;

    virtual antlrcpp::Any visitType_param_bound(PnfRustParser::Type_param_boundContext *context) = 0;

    virtual antlrcpp::Any visitTrait_object_type(PnfRustParser::Trait_object_typeContext *context) = 0;

    virtual antlrcpp::Any visitTrait_bound(PnfRustParser::Trait_boundContext *context) = 0;

    virtual antlrcpp::Any visitBare_function_type(PnfRustParser::Bare_function_typeContext *context) = 0;

    virtual antlrcpp::Any visitMut_or_const(PnfRustParser::Mut_or_constContext *context) = 0;

    virtual antlrcpp::Any visitExtern_abi(PnfRustParser::Extern_abiContext *context) = 0;

    virtual antlrcpp::Any visitType_arguments(PnfRustParser::Type_argumentsContext *context) = 0;

    virtual antlrcpp::Any visitType_argument(PnfRustParser::Type_argumentContext *context) = 0;

    virtual antlrcpp::Any visitTy_sum(PnfRustParser::Ty_sumContext *context) = 0;

    virtual antlrcpp::Any visitTy_sum_list(PnfRustParser::Ty_sum_listContext *context) = 0;

    virtual antlrcpp::Any visitType_parameters(PnfRustParser::Type_parametersContext *context) = 0;

    virtual antlrcpp::Any visitLifetime_param(PnfRustParser::Lifetime_paramContext *context) = 0;

    virtual antlrcpp::Any visitLifetime_param_list(PnfRustParser::Lifetime_param_listContext *context) = 0;

    virtual antlrcpp::Any visitType_parameter(PnfRustParser::Type_parameterContext *context) = 0;

    virtual antlrcpp::Any visitType_parameter_list(PnfRustParser::Type_parameter_listContext *context) = 0;

    virtual antlrcpp::Any visitPattern(PnfRustParser::PatternContext *context) = 0;

    virtual antlrcpp::Any visitPat_ident(PnfRustParser::Pat_identContext *context) = 0;

    virtual antlrcpp::Any visitPat_range_end(PnfRustParser::Pat_range_endContext *context) = 0;

    virtual antlrcpp::Any visitPat_lit(PnfRustParser::Pat_litContext *context) = 0;

    virtual antlrcpp::Any visitPat_list_with_dots(PnfRustParser::Pat_list_with_dotsContext *context) = 0;

    virtual antlrcpp::Any visitPat_list_dots_tail(PnfRustParser::Pat_list_dots_tailContext *context) = 0;

    virtual antlrcpp::Any visitPat_fields_left(PnfRustParser::Pat_fields_leftContext *context) = 0;

    virtual antlrcpp::Any visitPat_fields(PnfRustParser::Pat_fieldsContext *context) = 0;

    virtual antlrcpp::Any visitPat_field(PnfRustParser::Pat_fieldContext *context) = 0;

    virtual antlrcpp::Any visitExpr(PnfRustParser::ExprContext *context) = 0;

    virtual antlrcpp::Any visitExpr_no_struct(PnfRustParser::Expr_no_structContext *context) = 0;

    virtual antlrcpp::Any visitExpr_list(PnfRustParser::Expr_listContext *context) = 0;

    virtual antlrcpp::Any visitBlock(PnfRustParser::BlockContext *context) = 0;

    virtual antlrcpp::Any visitBlock_with_inner_attrs(PnfRustParser::Block_with_inner_attrsContext *context) = 0;

    virtual antlrcpp::Any visitStmt(PnfRustParser::StmtContext *context) = 0;

    virtual antlrcpp::Any visitBlocky_expr(PnfRustParser::Blocky_exprContext *context) = 0;

    virtual antlrcpp::Any visitIf_cond_or_pat(PnfRustParser::If_cond_or_patContext *context) = 0;

    virtual antlrcpp::Any visitWhile_cond_or_pat(PnfRustParser::While_cond_or_patContext *context) = 0;

    virtual antlrcpp::Any visitLoop_label(PnfRustParser::Loop_labelContext *context) = 0;

    virtual antlrcpp::Any visitMatch_arms(PnfRustParser::Match_armsContext *context) = 0;

    virtual antlrcpp::Any visitMatch_arm_intro(PnfRustParser::Match_arm_introContext *context) = 0;

    virtual antlrcpp::Any visitMatch_pattern(PnfRustParser::Match_patternContext *context) = 0;

    virtual antlrcpp::Any visitMatch_if_clause(PnfRustParser::Match_if_clauseContext *context) = 0;

    virtual antlrcpp::Any visitExpr_attrs(PnfRustParser::Expr_attrsContext *context) = 0;

    virtual antlrcpp::Any visitExpr_inner_attrs(PnfRustParser::Expr_inner_attrsContext *context) = 0;

    virtual antlrcpp::Any visitPrim_expr(PnfRustParser::Prim_exprContext *context) = 0;

    virtual antlrcpp::Any visitPrim_expr_no_struct(PnfRustParser::Prim_expr_no_structContext *context) = 0;

    virtual antlrcpp::Any visitLit(PnfRustParser::LitContext *context) = 0;

    virtual antlrcpp::Any visitClosure_params(PnfRustParser::Closure_paramsContext *context) = 0;

    virtual antlrcpp::Any visitClosure_param(PnfRustParser::Closure_paramContext *context) = 0;

    virtual antlrcpp::Any visitClosure_param_list(PnfRustParser::Closure_param_listContext *context) = 0;

    virtual antlrcpp::Any visitClosure_tail(PnfRustParser::Closure_tailContext *context) = 0;

    virtual antlrcpp::Any visitLifetime_or_expr(PnfRustParser::Lifetime_or_exprContext *context) = 0;

    virtual antlrcpp::Any visitFields(PnfRustParser::FieldsContext *context) = 0;

    virtual antlrcpp::Any visitStruct_update_base(PnfRustParser::Struct_update_baseContext *context) = 0;

    virtual antlrcpp::Any visitField(PnfRustParser::FieldContext *context) = 0;

    virtual antlrcpp::Any visitField_name(PnfRustParser::Field_nameContext *context) = 0;

    virtual antlrcpp::Any visitPre_expr(PnfRustParser::Pre_exprContext *context) = 0;

    virtual antlrcpp::Any visitCmp_expr(PnfRustParser::Cmp_exprContext *context) = 0;

    virtual antlrcpp::Any visitRange_expr(PnfRustParser::Range_exprContext *context) = 0;

    virtual antlrcpp::Any visitAssign_expr(PnfRustParser::Assign_exprContext *context) = 0;

    virtual antlrcpp::Any visitPre_expr_no_struct(PnfRustParser::Pre_expr_no_structContext *context) = 0;

    virtual antlrcpp::Any visitCmp_expr_no_struct(PnfRustParser::Cmp_expr_no_structContext *context) = 0;

    virtual antlrcpp::Any visitRange_expr_no_struct(PnfRustParser::Range_expr_no_structContext *context) = 0;

    virtual antlrcpp::Any visitAssign_expr_no_struct(PnfRustParser::Assign_expr_no_structContext *context) = 0;

    virtual antlrcpp::Any visitIdent(PnfRustParser::IdentContext *context) = 0;

    virtual antlrcpp::Any visitAny_ident(PnfRustParser::Any_identContext *context) = 0;

    virtual antlrcpp::Any visitTokens_no_delimiters_cash(PnfRustParser::Tokens_no_delimiters_cashContext *context) = 0;

    virtual antlrcpp::Any visitTokens_no_delimiters_repetition_operators(PnfRustParser::Tokens_no_delimiters_repetition_operatorsContext *context) = 0;

    virtual antlrcpp::Any visitMacro_rules_definition(PnfRustParser::Macro_rules_definitionContext *context) = 0;

    virtual antlrcpp::Any visitMacro_rules_def(PnfRustParser::Macro_rules_defContext *context) = 0;

    virtual antlrcpp::Any visitMacro_rules(PnfRustParser::Macro_rulesContext *context) = 0;

    virtual antlrcpp::Any visitMacro_rule(PnfRustParser::Macro_ruleContext *context) = 0;

    virtual antlrcpp::Any visitMacro_matcher(PnfRustParser::Macro_matcherContext *context) = 0;

    virtual antlrcpp::Any visitMacro_match(PnfRustParser::Macro_matchContext *context) = 0;

    virtual antlrcpp::Any visitMacro_rep_sep(PnfRustParser::Macro_rep_sepContext *context) = 0;

    virtual antlrcpp::Any visitMacro_rep_op(PnfRustParser::Macro_rep_opContext *context) = 0;

    virtual antlrcpp::Any visitMacro_transcriber(PnfRustParser::Macro_transcriberContext *context) = 0;

    virtual antlrcpp::Any visitDelim_token_tree(PnfRustParser::Delim_token_treeContext *context) = 0;

    virtual antlrcpp::Any visitMacro_invocation_semi(PnfRustParser::Macro_invocation_semiContext *context) = 0;

    virtual antlrcpp::Any visitMacro_invocation(PnfRustParser::Macro_invocationContext *context) = 0;

    virtual antlrcpp::Any visitLifetime(PnfRustParser::LifetimeContext *context) = 0;

    virtual antlrcpp::Any visitKleene_star__mod_body_1(PnfRustParser::Kleene_star__mod_body_1Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__mod_body_2(PnfRustParser::Kleene_star__mod_body_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__visibility_1(PnfRustParser::Optional__visibility_1Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__item_1(PnfRustParser::Kleene_star__item_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__item_2(PnfRustParser::Optional__item_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__extern_crate_1(PnfRustParser::Optional__extern_crate_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__use_path_2(PnfRustParser::Optional__use_path_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__use_path_4(PnfRustParser::Aux_rule__use_path_4Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__use_path_5(PnfRustParser::Kleene_star__use_path_5Context *context) = 0;

    virtual antlrcpp::Any visitOptional__use_path_6(PnfRustParser::Optional__use_path_6Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__use_item_list_1(PnfRustParser::Aux_rule__use_item_list_1Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__use_item_list_2(PnfRustParser::Kleene_star__use_item_list_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__use_item_list_3(PnfRustParser::Optional__use_item_list_3Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__extern_mod_2(PnfRustParser::Kleene_star__extern_mod_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__foreign_item_tail_2(PnfRustParser::Aux_rule__foreign_item_tail_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__foreign_item_tail_3(PnfRustParser::Optional__foreign_item_tail_3Context *context) = 0;

    virtual antlrcpp::Any visitOptional__static_decl_1(PnfRustParser::Optional__static_decl_1Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__associated_const_decl_1(PnfRustParser::Aux_rule__associated_const_decl_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__associated_const_decl_2(PnfRustParser::Optional__associated_const_decl_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__fn_decl_1(PnfRustParser::Optional__fn_decl_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__fn_decl_2(PnfRustParser::Optional__fn_decl_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__method_decl_1(PnfRustParser::Optional__method_decl_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__trait_method_decl_1(PnfRustParser::Optional__trait_method_decl_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__foreign_fn_decl_1(PnfRustParser::Optional__foreign_fn_decl_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__foreign_fn_decl_2(PnfRustParser::Optional__foreign_fn_decl_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__macro_decl_2(PnfRustParser::Aux_rule__macro_decl_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__macro_decl_3(PnfRustParser::Optional__macro_decl_3Context *context) = 0;

    virtual antlrcpp::Any visitOptional__macro_head_1(PnfRustParser::Optional__macro_head_1Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__fn_head_1(PnfRustParser::Aux_rule__fn_head_1Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__fn_head_2(PnfRustParser::Kleene_star__fn_head_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__fn_head_3(PnfRustParser::Optional__fn_head_3Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__param_3(PnfRustParser::Aux_rule__param_3Context *context) = 0;

    virtual antlrcpp::Any visitOptional__param_4(PnfRustParser::Optional__param_4Context *context) = 0;

    virtual antlrcpp::Any visitOptional__param_6(PnfRustParser::Optional__param_6Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__param_list_1(PnfRustParser::Aux_rule__param_list_1Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__param_list_2(PnfRustParser::Kleene_star__param_list_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__param_list_4(PnfRustParser::Aux_rule__param_list_4Context *context) = 0;

    virtual antlrcpp::Any visitOptional__param_list_5(PnfRustParser::Optional__param_list_5Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__variadic_param_list_4(PnfRustParser::Aux_rule__variadic_param_list_4Context *context) = 0;

    virtual antlrcpp::Any visitOptional__variadic_param_list_5(PnfRustParser::Optional__variadic_param_list_5Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__trait_method_param_2(PnfRustParser::Aux_rule__trait_method_param_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__trait_method_param_3(PnfRustParser::Kleene_star__trait_method_param_3Context *context) = 0;

    virtual antlrcpp::Any visitOptional__restricted_pat_1(PnfRustParser::Optional__restricted_pat_1Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__restricted_pat_2(PnfRustParser::Aux_rule__restricted_pat_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__restricted_pat_3(PnfRustParser::Optional__restricted_pat_3Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__trait_method_param_list_2(PnfRustParser::Aux_rule__trait_method_param_list_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__trait_method_param_list_3(PnfRustParser::Kleene_star__trait_method_param_list_3Context *context) = 0;

    virtual antlrcpp::Any visitOptional__type_decl_4(PnfRustParser::Optional__type_decl_4Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__type_decl_6(PnfRustParser::Aux_rule__type_decl_6Context *context) = 0;

    virtual antlrcpp::Any visitOptional__type_decl_7(PnfRustParser::Optional__type_decl_7Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__type_decl_8(PnfRustParser::Aux_rule__type_decl_8Context *context) = 0;

    virtual antlrcpp::Any visitOptional__type_decl_9(PnfRustParser::Optional__type_decl_9Context *context) = 0;

    virtual antlrcpp::Any visitOptional__struct_tail_2(PnfRustParser::Optional__struct_tail_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__struct_tail_5(PnfRustParser::Optional__struct_tail_5Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__tuple_struct_field_list_1(PnfRustParser::Aux_rule__tuple_struct_field_list_1Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__tuple_struct_field_list_2(PnfRustParser::Kleene_star__tuple_struct_field_list_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__field_decl_list_1(PnfRustParser::Aux_rule__field_decl_list_1Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__field_decl_list_2(PnfRustParser::Kleene_star__field_decl_list_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__enum_decl_3(PnfRustParser::Optional__enum_decl_3Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__enum_variant_3(PnfRustParser::Aux_rule__enum_variant_3Context *context) = 0;

    virtual antlrcpp::Any visitOptional__enum_variant_4(PnfRustParser::Optional__enum_variant_4Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__enum_variant_list_1(PnfRustParser::Aux_rule__enum_variant_list_1Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__enum_variant_list_2(PnfRustParser::Kleene_star__enum_variant_list_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__enum_variant_main_1(PnfRustParser::Optional__enum_variant_main_1Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__enum_tuple_field_list_1(PnfRustParser::Aux_rule__enum_tuple_field_list_1Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__enum_tuple_field_list_2(PnfRustParser::Kleene_star__enum_tuple_field_list_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__trait_decl_2(PnfRustParser::Optional__trait_decl_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__trait_decl_7(PnfRustParser::Kleene_star__trait_decl_7Context *context) = 0;

    virtual antlrcpp::Any visitOptional__impl_block_1(PnfRustParser::Optional__impl_block_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__impl_block_2(PnfRustParser::Optional__impl_block_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__impl_block_3(PnfRustParser::Optional__impl_block_3Context *context) = 0;

    virtual antlrcpp::Any visitOptional__impl_block_4(PnfRustParser::Optional__impl_block_4Context *context) = 0;

    virtual antlrcpp::Any visitOptional__impl_block_5(PnfRustParser::Optional__impl_block_5Context *context) = 0;

    virtual antlrcpp::Any visitOptional__impl_block_6(PnfRustParser::Optional__impl_block_6Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__impl_block_7(PnfRustParser::Kleene_star__impl_block_7Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__impl_item_1(PnfRustParser::Aux_rule__impl_item_1Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__impl_item_2(PnfRustParser::Kleene_star__impl_item_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__impl_item_tail_11(PnfRustParser::Aux_rule__impl_item_tail_11Context *context) = 0;

    virtual antlrcpp::Any visitOptional__impl_item_tail_12(PnfRustParser::Optional__impl_item_tail_12Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__inner_attr_1(PnfRustParser::Kleene_star__inner_attr_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__path_1(PnfRustParser::Optional__path_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__path_parent_1(PnfRustParser::Optional__path_parent_1Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__path_segment_no_super_1(PnfRustParser::Aux_rule__path_segment_no_super_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__path_segment_no_super_2(PnfRustParser::Optional__path_segment_no_super_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__simple_path_1(PnfRustParser::Optional__simple_path_1Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__simple_path_2(PnfRustParser::Aux_rule__simple_path_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__simple_path_3(PnfRustParser::Kleene_star__simple_path_3Context *context) = 0;

    virtual antlrcpp::Any visitOptional__for_lifetimes_1(PnfRustParser::Optional__for_lifetimes_1Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__lifetime_def_list_1(PnfRustParser::Aux_rule__lifetime_def_list_1Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__lifetime_def_list_2(PnfRustParser::Kleene_star__lifetime_def_list_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__lifetime_def_1(PnfRustParser::Aux_rule__lifetime_def_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__lifetime_def_2(PnfRustParser::Optional__lifetime_def_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__type_path_main_1(PnfRustParser::Optional__type_path_main_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__ty_path_tail_1(PnfRustParser::Optional__ty_path_tail_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__ty_path_segment_no_super_2(PnfRustParser::Optional__ty_path_segment_no_super_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__ty_path_segment_no_super_3(PnfRustParser::Optional__ty_path_segment_no_super_3Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__where_bound_list_1(PnfRustParser::Aux_rule__where_bound_list_1Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__where_bound_list_2(PnfRustParser::Kleene_star__where_bound_list_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__where_bound_1(PnfRustParser::Optional__where_bound_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__where_bound_2(PnfRustParser::Optional__where_bound_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__empty_ok_colon_bound_1(PnfRustParser::Optional__empty_ok_colon_bound_1Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__prim_bound_3(PnfRustParser::Aux_rule__prim_bound_3Context *context) = 0;

    virtual antlrcpp::Any visitOptional__prim_bound_4(PnfRustParser::Optional__prim_bound_4Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__prim_bound_5(PnfRustParser::Aux_rule__prim_bound_5Context *context) = 0;

    virtual antlrcpp::Any visitOptional__type_1(PnfRustParser::Optional__type_1Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__array_or_slice_type_1(PnfRustParser::Aux_rule__array_or_slice_type_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__array_or_slice_type_2(PnfRustParser::Optional__array_or_slice_type_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__type_param_bounds_1(PnfRustParser::Aux_rule__type_param_bounds_1Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__type_param_bounds_2(PnfRustParser::Kleene_star__type_param_bounds_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__type_param_bounds_3(PnfRustParser::Optional__type_param_bounds_3Context *context) = 0;

    virtual antlrcpp::Any visitOptional__trait_object_type_2(PnfRustParser::Optional__trait_object_type_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__bare_function_type_4(PnfRustParser::Optional__bare_function_type_4Context *context) = 0;

    virtual antlrcpp::Any visitOptional__extern_abi_1(PnfRustParser::Optional__extern_abi_1Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__type_arguments_1(PnfRustParser::Aux_rule__type_arguments_1Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__type_arguments_2(PnfRustParser::Kleene_star__type_arguments_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__type_arguments_4(PnfRustParser::Aux_rule__type_arguments_4Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__type_arguments_5(PnfRustParser::Kleene_star__type_arguments_5Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__type_arguments_6(PnfRustParser::Aux_rule__type_arguments_6Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__type_arguments_7(PnfRustParser::Kleene_star__type_arguments_7Context *context) = 0;

    virtual antlrcpp::Any visitOptional__ty_sum_1(PnfRustParser::Optional__ty_sum_1Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__ty_sum_2(PnfRustParser::Aux_rule__ty_sum_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__ty_sum_3(PnfRustParser::Optional__ty_sum_3Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__ty_sum_list_1(PnfRustParser::Aux_rule__ty_sum_list_1Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__ty_sum_list_2(PnfRustParser::Kleene_star__ty_sum_list_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__type_parameters_1(PnfRustParser::Aux_rule__type_parameters_1Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__type_parameters_2(PnfRustParser::Kleene_star__type_parameters_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__type_parameters_3(PnfRustParser::Optional__type_parameters_3Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__lifetime_param_list_1(PnfRustParser::Aux_rule__lifetime_param_list_1Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__lifetime_param_list_2(PnfRustParser::Kleene_star__lifetime_param_list_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__type_parameter_4(PnfRustParser::Optional__type_parameter_4Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__type_parameter_list_1(PnfRustParser::Aux_rule__type_parameter_list_1Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__type_parameter_list_2(PnfRustParser::Kleene_star__type_parameter_list_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__pattern_1(PnfRustParser::Aux_rule__pattern_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__pattern_2(PnfRustParser::Optional__pattern_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__pattern_without_mut_1(PnfRustParser::Optional__pattern_without_mut_1Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__pattern_without_mut_2(PnfRustParser::Aux_rule__pattern_without_mut_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__pattern_without_mut_3(PnfRustParser::Optional__pattern_without_mut_3Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__pattern_without_mut_4(PnfRustParser::Aux_rule__pattern_without_mut_4Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__pattern_without_mut_5(PnfRustParser::Kleene_star__pattern_without_mut_5Context *context) = 0;

    virtual antlrcpp::Any visitOptional__pattern_without_mut_12(PnfRustParser::Optional__pattern_without_mut_12Context *context) = 0;

    virtual antlrcpp::Any visitOptional__pattern_without_mut_13(PnfRustParser::Optional__pattern_without_mut_13Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__pattern_without_mut_15(PnfRustParser::Aux_rule__pattern_without_mut_15Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__pattern_without_mut_16(PnfRustParser::Kleene_star__pattern_without_mut_16Context *context) = 0;

    virtual antlrcpp::Any visitOptional__pat_lit_1(PnfRustParser::Optional__pat_lit_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__pat_list_with_dots_3(PnfRustParser::Optional__pat_list_with_dots_3Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__pat_list_with_dots_4(PnfRustParser::Aux_rule__pat_list_with_dots_4Context *context) = 0;

    virtual antlrcpp::Any visitOptional__pat_list_with_dots_5(PnfRustParser::Optional__pat_list_with_dots_5Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__pat_list_dots_tail_1(PnfRustParser::Aux_rule__pat_list_dots_tail_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__pat_list_dots_tail_2(PnfRustParser::Optional__pat_list_dots_tail_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__pat_fields_1(PnfRustParser::Aux_rule__pat_fields_1Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__pat_fields_2(PnfRustParser::Kleene_star__pat_fields_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__pat_fields_3(PnfRustParser::Aux_rule__pat_fields_3Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__pat_fields_4(PnfRustParser::Kleene_star__pat_fields_4Context *context) = 0;

    virtual antlrcpp::Any visitOptional__pat_field_2(PnfRustParser::Optional__pat_field_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__expr_1(PnfRustParser::Optional__expr_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__expr_2(PnfRustParser::Optional__expr_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__expr_list_1(PnfRustParser::Aux_rule__expr_list_1Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__expr_list_2(PnfRustParser::Kleene_star__expr_list_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__block_with_inner_attrs_2(PnfRustParser::Kleene_star__block_with_inner_attrs_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__block_with_inner_attrs_3(PnfRustParser::Optional__block_with_inner_attrs_3Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__blocky_expr_1(PnfRustParser::Aux_rule__blocky_expr_1Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__blocky_expr_2(PnfRustParser::Kleene_star__blocky_expr_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__blocky_expr_3(PnfRustParser::Aux_rule__blocky_expr_3Context *context) = 0;

    virtual antlrcpp::Any visitOptional__blocky_expr_4(PnfRustParser::Optional__blocky_expr_4Context *context) = 0;

    virtual antlrcpp::Any visitOptional__blocky_expr_5(PnfRustParser::Optional__blocky_expr_5Context *context) = 0;

    virtual antlrcpp::Any visitOptional__blocky_expr_6(PnfRustParser::Optional__blocky_expr_6Context *context) = 0;

    virtual antlrcpp::Any visitOptional__blocky_expr_7(PnfRustParser::Optional__blocky_expr_7Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__match_arms_4(PnfRustParser::Aux_rule__match_arms_4Context *context) = 0;

    virtual antlrcpp::Any visitOptional__match_arms_5(PnfRustParser::Optional__match_arms_5Context *context) = 0;

    virtual antlrcpp::Any visitOptional__match_arm_intro_2(PnfRustParser::Optional__match_arm_intro_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__match_pattern_2(PnfRustParser::Aux_rule__match_pattern_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__match_pattern_3(PnfRustParser::Kleene_star__match_pattern_3Context *context) = 0;

    virtual antlrcpp::Any visitOptional__prim_expr_1(PnfRustParser::Optional__prim_expr_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__prim_expr_2(PnfRustParser::Optional__prim_expr_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__prim_expr_no_struct_1(PnfRustParser::Optional__prim_expr_no_struct_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__prim_expr_no_struct_5(PnfRustParser::Optional__prim_expr_no_struct_5Context *context) = 0;

    virtual antlrcpp::Any visitOptional__prim_expr_no_struct_9(PnfRustParser::Optional__prim_expr_no_struct_9Context *context) = 0;

    virtual antlrcpp::Any visitOptional__prim_expr_no_struct_10(PnfRustParser::Optional__prim_expr_no_struct_10Context *context) = 0;

    virtual antlrcpp::Any visitOptional__prim_expr_no_struct_11(PnfRustParser::Optional__prim_expr_no_struct_11Context *context) = 0;

    virtual antlrcpp::Any visitOptional__prim_expr_no_struct_12(PnfRustParser::Optional__prim_expr_no_struct_12Context *context) = 0;

    virtual antlrcpp::Any visitOptional__prim_expr_no_struct_13(PnfRustParser::Optional__prim_expr_no_struct_13Context *context) = 0;

    virtual antlrcpp::Any visitOptional__closure_params_1(PnfRustParser::Optional__closure_params_1Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__closure_param_list_1(PnfRustParser::Aux_rule__closure_param_list_1Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__closure_param_list_2(PnfRustParser::Kleene_star__closure_param_list_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__fields_1(PnfRustParser::Aux_rule__fields_1Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__fields_2(PnfRustParser::Kleene_star__fields_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__field_1(PnfRustParser::Kleene_star__field_1Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__post_expr_tail_4(PnfRustParser::Aux_rule__post_expr_tail_4Context *context) = 0;

    virtual antlrcpp::Any visitOptional__post_expr_tail_5(PnfRustParser::Optional__post_expr_tail_5Context *context) = 0;

    virtual antlrcpp::Any visitOptional__range_expr_1(PnfRustParser::Optional__range_expr_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__range_expr_no_struct_1(PnfRustParser::Optional__range_expr_no_struct_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__macro_rules_def_1(PnfRustParser::Optional__macro_rules_def_1Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__macro_rules_1(PnfRustParser::Aux_rule__macro_rules_1Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__macro_rules_2(PnfRustParser::Kleene_star__macro_rules_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__macro_rules_3(PnfRustParser::Optional__macro_rules_3Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__macro_matcher_1(PnfRustParser::Kleene_star__macro_matcher_1Context *context) = 0;

    virtual antlrcpp::Any visitKleene_plus__macro_match_1(PnfRustParser::Kleene_plus__macro_match_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__macro_match_2(PnfRustParser::Optional__macro_match_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__bound_4(PnfRustParser::Aux_rule__bound_4Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__bound_3(PnfRustParser::Kleene_star__bound_3Context *context) = 0;

    virtual antlrcpp::Any visitBound(PnfRustParser::BoundContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__path_parent_3(PnfRustParser::Aux_rule__path_parent_3Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__path_parent_2(PnfRustParser::Kleene_star__path_parent_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__path_parent_4(PnfRustParser::Aux_rule__path_parent_4Context *context) = 0;

    virtual antlrcpp::Any visitPath_parent(PnfRustParser::Path_parentContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__lifetime_bound_2(PnfRustParser::Aux_rule__lifetime_bound_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__lifetime_bound_1(PnfRustParser::Kleene_star__lifetime_bound_1Context *context) = 0;

    virtual antlrcpp::Any visitLifetime_bound(PnfRustParser::Lifetime_boundContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__ty_path_parent_3(PnfRustParser::Aux_rule__ty_path_parent_3Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__ty_path_parent_2(PnfRustParser::Kleene_star__ty_path_parent_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__ty_path_parent_4(PnfRustParser::Aux_rule__ty_path_parent_4Context *context) = 0;

    virtual antlrcpp::Any visitTy_path_parent(PnfRustParser::Ty_path_parentContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__pattern_without_mut_19(PnfRustParser::Aux_rule__pattern_without_mut_19Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__pattern_without_mut_18(PnfRustParser::Kleene_star__pattern_without_mut_18Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__pattern_without_mut_20(PnfRustParser::Aux_rule__pattern_without_mut_20Context *context) = 0;

    virtual antlrcpp::Any visitPattern_without_mut(PnfRustParser::Pattern_without_mutContext *context) = 0;

    virtual antlrcpp::Any visitKleene_star__post_expr_1(PnfRustParser::Kleene_star__post_expr_1Context *context) = 0;

    virtual antlrcpp::Any visitPost_expr(PnfRustParser::Post_exprContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__cast_expr_2(PnfRustParser::Aux_rule__cast_expr_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__cast_expr_1(PnfRustParser::Kleene_star__cast_expr_1Context *context) = 0;

    virtual antlrcpp::Any visitCast_expr(PnfRustParser::Cast_exprContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__mul_expr_2(PnfRustParser::Aux_rule__mul_expr_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__mul_expr_1(PnfRustParser::Kleene_star__mul_expr_1Context *context) = 0;

    virtual antlrcpp::Any visitMul_expr(PnfRustParser::Mul_exprContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__add_expr_2(PnfRustParser::Aux_rule__add_expr_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__add_expr_1(PnfRustParser::Kleene_star__add_expr_1Context *context) = 0;

    virtual antlrcpp::Any visitAdd_expr(PnfRustParser::Add_exprContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__shift_expr_2(PnfRustParser::Aux_rule__shift_expr_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__shift_expr_1(PnfRustParser::Kleene_star__shift_expr_1Context *context) = 0;

    virtual antlrcpp::Any visitShift_expr(PnfRustParser::Shift_exprContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__bit_and_expr_2(PnfRustParser::Aux_rule__bit_and_expr_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__bit_and_expr_1(PnfRustParser::Kleene_star__bit_and_expr_1Context *context) = 0;

    virtual antlrcpp::Any visitBit_and_expr(PnfRustParser::Bit_and_exprContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__bit_xor_expr_2(PnfRustParser::Aux_rule__bit_xor_expr_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__bit_xor_expr_1(PnfRustParser::Kleene_star__bit_xor_expr_1Context *context) = 0;

    virtual antlrcpp::Any visitBit_xor_expr(PnfRustParser::Bit_xor_exprContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__bit_or_expr_2(PnfRustParser::Aux_rule__bit_or_expr_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__bit_or_expr_1(PnfRustParser::Kleene_star__bit_or_expr_1Context *context) = 0;

    virtual antlrcpp::Any visitBit_or_expr(PnfRustParser::Bit_or_exprContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__and_expr_2(PnfRustParser::Aux_rule__and_expr_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__and_expr_1(PnfRustParser::Kleene_star__and_expr_1Context *context) = 0;

    virtual antlrcpp::Any visitAnd_expr(PnfRustParser::And_exprContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__or_expr_2(PnfRustParser::Aux_rule__or_expr_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__or_expr_1(PnfRustParser::Kleene_star__or_expr_1Context *context) = 0;

    virtual antlrcpp::Any visitOr_expr(PnfRustParser::Or_exprContext *context) = 0;

    virtual antlrcpp::Any visitPost_expr_no_struct(PnfRustParser::Post_expr_no_structContext *context) = 0;

    virtual antlrcpp::Any visitCast_expr_no_struct(PnfRustParser::Cast_expr_no_structContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__mul_expr_no_struct_2(PnfRustParser::Aux_rule__mul_expr_no_struct_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__mul_expr_no_struct_1(PnfRustParser::Kleene_star__mul_expr_no_struct_1Context *context) = 0;

    virtual antlrcpp::Any visitMul_expr_no_struct(PnfRustParser::Mul_expr_no_structContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__add_expr_no_struct_2(PnfRustParser::Aux_rule__add_expr_no_struct_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__add_expr_no_struct_1(PnfRustParser::Kleene_star__add_expr_no_struct_1Context *context) = 0;

    virtual antlrcpp::Any visitAdd_expr_no_struct(PnfRustParser::Add_expr_no_structContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__shift_expr_no_struct_2(PnfRustParser::Aux_rule__shift_expr_no_struct_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__shift_expr_no_struct_1(PnfRustParser::Kleene_star__shift_expr_no_struct_1Context *context) = 0;

    virtual antlrcpp::Any visitShift_expr_no_struct(PnfRustParser::Shift_expr_no_structContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__bit_and_expr_no_struct_2(PnfRustParser::Aux_rule__bit_and_expr_no_struct_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__bit_and_expr_no_struct_1(PnfRustParser::Kleene_star__bit_and_expr_no_struct_1Context *context) = 0;

    virtual antlrcpp::Any visitBit_and_expr_no_struct(PnfRustParser::Bit_and_expr_no_structContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__bit_xor_expr_no_struct_2(PnfRustParser::Aux_rule__bit_xor_expr_no_struct_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__bit_xor_expr_no_struct_1(PnfRustParser::Kleene_star__bit_xor_expr_no_struct_1Context *context) = 0;

    virtual antlrcpp::Any visitBit_xor_expr_no_struct(PnfRustParser::Bit_xor_expr_no_structContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__bit_or_expr_no_struct_2(PnfRustParser::Aux_rule__bit_or_expr_no_struct_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__bit_or_expr_no_struct_1(PnfRustParser::Kleene_star__bit_or_expr_no_struct_1Context *context) = 0;

    virtual antlrcpp::Any visitBit_or_expr_no_struct(PnfRustParser::Bit_or_expr_no_structContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__and_expr_no_struct_2(PnfRustParser::Aux_rule__and_expr_no_struct_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__and_expr_no_struct_1(PnfRustParser::Kleene_star__and_expr_no_struct_1Context *context) = 0;

    virtual antlrcpp::Any visitAnd_expr_no_struct(PnfRustParser::And_expr_no_structContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__or_expr_no_struct_2(PnfRustParser::Aux_rule__or_expr_no_struct_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__or_expr_no_struct_1(PnfRustParser::Kleene_star__or_expr_no_struct_1Context *context) = 0;

    virtual antlrcpp::Any visitOr_expr_no_struct(PnfRustParser::Or_expr_no_structContext *context) = 0;

    virtual antlrcpp::Any visitKleene_plus__expr_attrs_2(PnfRustParser::Kleene_plus__expr_attrs_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_plus__expr_inner_attrs_2(PnfRustParser::Kleene_plus__expr_inner_attrs_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__enum_variant_main_3(PnfRustParser::Aux_rule__enum_variant_main_3Context *context) = 0;

    virtual antlrcpp::Any visitOptional__enum_variant_main_4(PnfRustParser::Optional__enum_variant_main_4Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__impl_what_1(PnfRustParser::Aux_rule__impl_what_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__impl_what_2(PnfRustParser::Optional__impl_what_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__path_2(PnfRustParser::Aux_rule__path_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__path_3(PnfRustParser::Optional__path_3Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__type_path_main_2(PnfRustParser::Aux_rule__type_path_main_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__type_path_main_3(PnfRustParser::Optional__type_path_main_3Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__tuple_type_2(PnfRustParser::Aux_rule__tuple_type_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__tuple_type_3(PnfRustParser::Optional__tuple_type_3Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__type_argument_1(PnfRustParser::Aux_rule__type_argument_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__type_argument_2(PnfRustParser::Optional__type_argument_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__pattern_without_mut_21(PnfRustParser::Aux_rule__pattern_without_mut_21Context *context) = 0;

    virtual antlrcpp::Any visitOptional__pattern_without_mut_22(PnfRustParser::Optional__pattern_without_mut_22Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__pattern_without_mut_23(PnfRustParser::Aux_rule__pattern_without_mut_23Context *context) = 0;

    virtual antlrcpp::Any visitOptional__pattern_without_mut_24(PnfRustParser::Optional__pattern_without_mut_24Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__assign_expr_1(PnfRustParser::Aux_rule__assign_expr_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__assign_expr_2(PnfRustParser::Optional__assign_expr_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__assign_expr_no_struct_1(PnfRustParser::Aux_rule__assign_expr_no_struct_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__assign_expr_no_struct_2(PnfRustParser::Optional__assign_expr_no_struct_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__blocky_expr_11(PnfRustParser::Optional__blocky_expr_11Context *context) = 0;

    virtual antlrcpp::Any visitOptional__closure_params_2(PnfRustParser::Optional__closure_params_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__cmp_expr_1(PnfRustParser::Aux_rule__cmp_expr_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__cmp_expr_2(PnfRustParser::Optional__cmp_expr_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__range_expr_5(PnfRustParser::Aux_rule__range_expr_5Context *context) = 0;

    virtual antlrcpp::Any visitOptional__range_expr_6(PnfRustParser::Optional__range_expr_6Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__cmp_expr_no_struct_5(PnfRustParser::Aux_rule__cmp_expr_no_struct_5Context *context) = 0;

    virtual antlrcpp::Any visitOptional__cmp_expr_no_struct_6(PnfRustParser::Optional__cmp_expr_no_struct_6Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__range_expr_no_struct_5(PnfRustParser::Aux_rule__range_expr_no_struct_5Context *context) = 0;

    virtual antlrcpp::Any visitOptional__range_expr_no_struct_6(PnfRustParser::Optional__range_expr_no_struct_6Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__visibility_restriction_1(PnfRustParser::Altnt_block__visibility_restriction_1Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__type_decl_10(PnfRustParser::Altnt_block__type_decl_10Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__use_suffix_2(PnfRustParser::Altnt_block__use_suffix_2Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__foreign_item_tail_11(PnfRustParser::Altnt_block__foreign_item_tail_11Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__macro_invocation_semi_4(PnfRustParser::Altnt_block__macro_invocation_semi_4Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__type_parameters_4(PnfRustParser::Altnt_block__type_parameters_4Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__trait_method_param_6(PnfRustParser::Altnt_block__trait_method_param_6Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__struct_tail_6(PnfRustParser::Altnt_block__struct_tail_6Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__enum_variant_main_5(PnfRustParser::Altnt_block__enum_variant_main_5Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__trait_item_19(PnfRustParser::Altnt_block__trait_item_19Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__impl_what_3(PnfRustParser::Altnt_block__impl_what_3Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__type_arguments_9(PnfRustParser::Altnt_block__type_arguments_9Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__impl_item_tail_13(PnfRustParser::Altnt_block__impl_item_tail_13Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__pattern_without_mut_25(PnfRustParser::Altnt_block__pattern_without_mut_25Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__pattern_without_mut_26(PnfRustParser::Altnt_block__pattern_without_mut_26Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__pattern_without_mut_27(PnfRustParser::Altnt_block__pattern_without_mut_27Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__pattern_without_mut_28(PnfRustParser::Altnt_block__pattern_without_mut_28Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__pattern_without_mut_29(PnfRustParser::Altnt_block__pattern_without_mut_29Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__pat_fields_6(PnfRustParser::Altnt_block__pat_fields_6Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__stmt_8(PnfRustParser::Altnt_block__stmt_8Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__blocky_expr_12(PnfRustParser::Altnt_block__blocky_expr_12Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__if_cond_or_pat_1(PnfRustParser::Altnt_block__if_cond_or_pat_1Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__match_arms_6(PnfRustParser::Altnt_block__match_arms_6Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__prim_expr_no_struct_18(PnfRustParser::Altnt_block__prim_expr_no_struct_18Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__prim_expr_no_struct_19(PnfRustParser::Altnt_block__prim_expr_no_struct_19Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__post_expr_tail_7(PnfRustParser::Altnt_block__post_expr_tail_7Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__pre_expr_3(PnfRustParser::Altnt_block__pre_expr_3Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__cast_expr_3(PnfRustParser::Altnt_block__cast_expr_3Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__mul_expr_3(PnfRustParser::Altnt_block__mul_expr_3Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__add_expr_3(PnfRustParser::Altnt_block__add_expr_3Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__shift_expr_3(PnfRustParser::Altnt_block__shift_expr_3Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__range_expr_7(PnfRustParser::Altnt_block__range_expr_7Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__range_expr_no_struct_7(PnfRustParser::Altnt_block__range_expr_no_struct_7Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__macro_rules_def_4(PnfRustParser::Altnt_block__macro_rules_def_4Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__macro_match_3(PnfRustParser::Altnt_block__macro_match_3Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__macro_invocation_semi_5(PnfRustParser::Altnt_block__macro_invocation_semi_5Context *context) = 0;

    virtual antlrcpp::Any visitType(PnfRustParser::TypeContext *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__extern_crate_2(PnfRustParser::Altnt_block__extern_crate_2Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__use_path_7(PnfRustParser::Altnt_block__use_path_7Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__use_item_2(PnfRustParser::Altnt_block__use_item_2Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__const_decl_2(PnfRustParser::Altnt_block__const_decl_2Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__fn_decl_4(PnfRustParser::Altnt_block__fn_decl_4Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__method_param_list_4(PnfRustParser::Altnt_block__method_param_list_4Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__restricted_pat_4(PnfRustParser::Altnt_block__restricted_pat_4Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__trait_method_param_list_5(PnfRustParser::Altnt_block__trait_method_param_list_5Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__fn_rtype_1(PnfRustParser::Altnt_block__fn_rtype_1Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__trait_alias_3(PnfRustParser::Altnt_block__trait_alias_3Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__trait_item_20(PnfRustParser::Altnt_block__trait_item_20Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__ty_path_tail_3(PnfRustParser::Altnt_block__ty_path_tail_3Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__pat_fields_7(PnfRustParser::Altnt_block__pat_fields_7Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__prim_expr_no_struct_20(PnfRustParser::Altnt_block__prim_expr_no_struct_20Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__fields_4(PnfRustParser::Altnt_block__fields_4Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__type_arguments_10(PnfRustParser::Altnt_block__type_arguments_10Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__assign_expr_3(PnfRustParser::Altnt_block__assign_expr_3Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__assign_expr_no_struct_3(PnfRustParser::Altnt_block__assign_expr_no_struct_3Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__cmp_expr_3(PnfRustParser::Altnt_block__cmp_expr_3Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__cmp_expr_no_struct_7(PnfRustParser::Altnt_block__cmp_expr_no_struct_7Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__trait_method_param_7(PnfRustParser::Altnt_block__trait_method_param_7Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__trait_method_param_8(PnfRustParser::Aux_rule__trait_method_param_8Context *context) = 0;

    virtual antlrcpp::Any visitOptional__trait_method_param_9(PnfRustParser::Optional__trait_method_param_9Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__struct_tail_7(PnfRustParser::Aux_rule__struct_tail_7Context *context) = 0;

    virtual antlrcpp::Any visitOptional__struct_tail_8(PnfRustParser::Optional__struct_tail_8Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__assign_expr_no_struct_4(PnfRustParser::Aux_rule__assign_expr_no_struct_4Context *context) = 0;

    virtual antlrcpp::Any visitOptional__assign_expr_no_struct_5(PnfRustParser::Optional__assign_expr_no_struct_5Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__blocky_expr_13(PnfRustParser::Aux_rule__blocky_expr_13Context *context) = 0;

    virtual antlrcpp::Any visitOptional__blocky_expr_14(PnfRustParser::Optional__blocky_expr_14Context *context) = 0;

    virtual antlrcpp::Any visitOptional__cmp_expr_no_struct_8(PnfRustParser::Optional__cmp_expr_no_struct_8Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__type_decl_11(PnfRustParser::Altnt_block__type_decl_11Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__use_path_8(PnfRustParser::Altnt_block__use_path_8Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__foreign_item_4(PnfRustParser::Altnt_block__foreign_item_4Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__param_12(PnfRustParser::Altnt_block__param_12Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__trait_item_21(PnfRustParser::Altnt_block__trait_item_21Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__trait_item_22(PnfRustParser::Altnt_block__trait_item_22Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__type_arguments_11(PnfRustParser::Altnt_block__type_arguments_11Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__pattern_without_mut_31(PnfRustParser::Altnt_block__pattern_without_mut_31Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__pat_field_6(PnfRustParser::Altnt_block__pat_field_6Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__blocky_expr_15(PnfRustParser::Altnt_block__blocky_expr_15Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__prim_expr_no_struct_22(PnfRustParser::Altnt_block__prim_expr_no_struct_22Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__prim_expr_no_struct_23(PnfRustParser::Altnt_block__prim_expr_no_struct_23Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__prim_expr_no_struct_24(PnfRustParser::Altnt_block__prim_expr_no_struct_24Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__range_expr_8(PnfRustParser::Altnt_block__range_expr_8Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__item_7(PnfRustParser::Altnt_block__item_7Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__param_11(PnfRustParser::Altnt_block__param_11Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__ty_path_segment_no_super_6(PnfRustParser::Altnt_block__ty_path_segment_no_super_6Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__post_expr_2(PnfRustParser::Aux_rule__post_expr_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__visibility_2(PnfRustParser::Aux_rule__visibility_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__use_suffix_3(PnfRustParser::Aux_rule__use_suffix_3Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__foreign_item_tail_12(PnfRustParser::Aux_rule__foreign_item_tail_12Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__param_13(PnfRustParser::Aux_rule__param_13Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__self_param_6(PnfRustParser::Aux_rule__self_param_6Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__self_param_7(PnfRustParser::Aux_rule__self_param_7Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__trait_method_param_10(PnfRustParser::Aux_rule__trait_method_param_10Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__struct_tail_9(PnfRustParser::Aux_rule__struct_tail_9Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__struct_tail_10(PnfRustParser::Aux_rule__struct_tail_10Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__trait_item_23(PnfRustParser::Aux_rule__trait_item_23Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__trait_item_24(PnfRustParser::Aux_rule__trait_item_24Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__trait_item_25(PnfRustParser::Aux_rule__trait_item_25Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__impl_what_4(PnfRustParser::Aux_rule__impl_what_4Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__impl_what_5(PnfRustParser::Aux_rule__impl_what_5Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__impl_what_6(PnfRustParser::Aux_rule__impl_what_6Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__impl_item_tail_14(PnfRustParser::Aux_rule__impl_item_tail_14Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__impl_item_tail_15(PnfRustParser::Aux_rule__impl_item_tail_15Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__tt_1(PnfRustParser::Aux_rule__tt_1Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__ty_path_tail_4(PnfRustParser::Aux_rule__ty_path_tail_4Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__where_bound_3(PnfRustParser::Aux_rule__where_bound_3Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__where_bound_4(PnfRustParser::Aux_rule__where_bound_4Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__trait_bound_5(PnfRustParser::Aux_rule__trait_bound_5Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__trait_bound_6(PnfRustParser::Aux_rule__trait_bound_6Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__type_argument_3(PnfRustParser::Aux_rule__type_argument_3Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__type_parameter_5(PnfRustParser::Aux_rule__type_parameter_5Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__pattern_3(PnfRustParser::Aux_rule__pattern_3Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__pat_ident_1(PnfRustParser::Aux_rule__pat_ident_1Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__pat_list_with_dots_6(PnfRustParser::Aux_rule__pat_list_with_dots_6Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__pat_fields_8(PnfRustParser::Aux_rule__pat_fields_8Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__pat_fields_9(PnfRustParser::Aux_rule__pat_fields_9Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__stmt_9(PnfRustParser::Aux_rule__stmt_9Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__stmt_10(PnfRustParser::Aux_rule__stmt_10Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__blocky_expr_16(PnfRustParser::Aux_rule__blocky_expr_16Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__blocky_expr_17(PnfRustParser::Aux_rule__blocky_expr_17Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__blocky_expr_18(PnfRustParser::Aux_rule__blocky_expr_18Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__prim_expr_3(PnfRustParser::Aux_rule__prim_expr_3Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__prim_expr_no_struct_25(PnfRustParser::Aux_rule__prim_expr_no_struct_25Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__prim_expr_no_struct_26(PnfRustParser::Aux_rule__prim_expr_no_struct_26Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__prim_expr_no_struct_27(PnfRustParser::Aux_rule__prim_expr_no_struct_27Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__prim_expr_no_struct_28(PnfRustParser::Aux_rule__prim_expr_no_struct_28Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__prim_expr_no_struct_29(PnfRustParser::Aux_rule__prim_expr_no_struct_29Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__prim_expr_no_struct_30(PnfRustParser::Aux_rule__prim_expr_no_struct_30Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__prim_expr_no_struct_31(PnfRustParser::Aux_rule__prim_expr_no_struct_31Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__closure_params_3(PnfRustParser::Aux_rule__closure_params_3Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__closure_tail_2(PnfRustParser::Aux_rule__closure_tail_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__fields_5(PnfRustParser::Aux_rule__fields_5Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__field_2(PnfRustParser::Aux_rule__field_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__pre_expr_5(PnfRustParser::Aux_rule__pre_expr_5Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__pre_expr_6(PnfRustParser::Aux_rule__pre_expr_6Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__range_expr_9(PnfRustParser::Aux_rule__range_expr_9Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__range_expr_10(PnfRustParser::Aux_rule__range_expr_10Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__pre_expr_no_struct_4(PnfRustParser::Aux_rule__pre_expr_no_struct_4Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__range_expr_no_struct_9(PnfRustParser::Aux_rule__range_expr_no_struct_9Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__range_expr_no_struct_10(PnfRustParser::Aux_rule__range_expr_no_struct_10Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__macro_rules_def_5(PnfRustParser::Aux_rule__macro_rules_def_5Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__macro_rules_def_6(PnfRustParser::Aux_rule__macro_rules_def_6Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__macro_matcher_4(PnfRustParser::Aux_rule__macro_matcher_4Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__macro_matcher_5(PnfRustParser::Aux_rule__macro_matcher_5Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__macro_matcher_6(PnfRustParser::Aux_rule__macro_matcher_6Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__macro_match_4(PnfRustParser::Aux_rule__macro_match_4Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__delim_token_tree_4(PnfRustParser::Aux_rule__delim_token_tree_4Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__delim_token_tree_5(PnfRustParser::Aux_rule__delim_token_tree_5Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__delim_token_tree_6(PnfRustParser::Aux_rule__delim_token_tree_6Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__prim_bound_6(PnfRustParser::Aux_rule__prim_bound_6Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__bound_5(PnfRustParser::Aux_rule__bound_5Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__bound_6(PnfRustParser::Aux_rule__bound_6Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__path_parent_6(PnfRustParser::Aux_rule__path_parent_6Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__path_parent_7(PnfRustParser::Aux_rule__path_parent_7Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__ty_path_parent_6(PnfRustParser::Aux_rule__ty_path_parent_6Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__ty_path_parent_7(PnfRustParser::Aux_rule__ty_path_parent_7Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__pattern_without_mut_32(PnfRustParser::Aux_rule__pattern_without_mut_32Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__pattern_without_mut_33(PnfRustParser::Aux_rule__pattern_without_mut_33Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__pattern_without_mut_34(PnfRustParser::Aux_rule__pattern_without_mut_34Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__pattern_without_mut_35(PnfRustParser::Aux_rule__pattern_without_mut_35Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__pattern_without_mut_36(PnfRustParser::Aux_rule__pattern_without_mut_36Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__pattern_without_mut_37(PnfRustParser::Aux_rule__pattern_without_mut_37Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__pattern_without_mut_38(PnfRustParser::Aux_rule__pattern_without_mut_38Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__pattern_without_mut_39(PnfRustParser::Aux_rule__pattern_without_mut_39Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__pattern_without_mut_40(PnfRustParser::Aux_rule__pattern_without_mut_40Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__visibility_restriction_2(PnfRustParser::Aux_rule__visibility_restriction_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__use_suffix_4(PnfRustParser::Aux_rule__use_suffix_4Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__foreign_item_tail_13(PnfRustParser::Aux_rule__foreign_item_tail_13Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__foreign_item_tail_14(PnfRustParser::Aux_rule__foreign_item_tail_14Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__macro_invocation_semi_6(PnfRustParser::Aux_rule__macro_invocation_semi_6Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__macro_invocation_semi_7(PnfRustParser::Aux_rule__macro_invocation_semi_7Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__type_parameters_5(PnfRustParser::Aux_rule__type_parameters_5Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__enum_variant_main_6(PnfRustParser::Aux_rule__enum_variant_main_6Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__enum_variant_main_7(PnfRustParser::Aux_rule__enum_variant_main_7Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__impl_item_tail_16(PnfRustParser::Aux_rule__impl_item_tail_16Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__impl_item_tail_17(PnfRustParser::Aux_rule__impl_item_tail_17Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__pattern_without_mut_41(PnfRustParser::Aux_rule__pattern_without_mut_41Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__pattern_without_mut_42(PnfRustParser::Aux_rule__pattern_without_mut_42Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__pattern_without_mut_43(PnfRustParser::Aux_rule__pattern_without_mut_43Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__pat_fields_10(PnfRustParser::Aux_rule__pat_fields_10Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__stmt_11(PnfRustParser::Aux_rule__stmt_11Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__blocky_expr_19(PnfRustParser::Aux_rule__blocky_expr_19Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__if_cond_or_pat_2(PnfRustParser::Aux_rule__if_cond_or_pat_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__match_arms_7(PnfRustParser::Aux_rule__match_arms_7Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__match_arms_8(PnfRustParser::Aux_rule__match_arms_8Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__post_expr_tail_8(PnfRustParser::Aux_rule__post_expr_tail_8Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__pre_expr_7(PnfRustParser::Aux_rule__pre_expr_7Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__shift_expr_4(PnfRustParser::Aux_rule__shift_expr_4Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__shift_expr_5(PnfRustParser::Aux_rule__shift_expr_5Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__range_expr_11(PnfRustParser::Aux_rule__range_expr_11Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__range_expr_no_struct_11(PnfRustParser::Aux_rule__range_expr_no_struct_11Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__macro_rules_def_7(PnfRustParser::Aux_rule__macro_rules_def_7Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__macro_rules_def_8(PnfRustParser::Aux_rule__macro_rules_def_8Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__macro_match_5(PnfRustParser::Aux_rule__macro_match_5Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__macro_match_6(PnfRustParser::Aux_rule__macro_match_6Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__macro_invocation_semi_8(PnfRustParser::Aux_rule__macro_invocation_semi_8Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__macro_invocation_semi_9(PnfRustParser::Aux_rule__macro_invocation_semi_9Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__type_3(PnfRustParser::Aux_rule__type_3Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__type_4(PnfRustParser::Aux_rule__type_4Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__type_5(PnfRustParser::Aux_rule__type_5Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__fn_rtype_2(PnfRustParser::Aux_rule__fn_rtype_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__trait_alias_4(PnfRustParser::Aux_rule__trait_alias_4Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__pat_fields_11(PnfRustParser::Aux_rule__pat_fields_11Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__prim_expr_no_struct_32(PnfRustParser::Aux_rule__prim_expr_no_struct_32Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__fields_6(PnfRustParser::Aux_rule__fields_6Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__assign_expr_no_struct_6(PnfRustParser::Aux_rule__assign_expr_no_struct_6Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__cmp_expr_no_struct_9(PnfRustParser::Aux_rule__cmp_expr_no_struct_9Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__trait_method_param_11(PnfRustParser::Aux_rule__trait_method_param_11Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__type_decl_12(PnfRustParser::Aux_rule__type_decl_12Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__type_decl_13(PnfRustParser::Aux_rule__type_decl_13Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__use_path_9(PnfRustParser::Aux_rule__use_path_9Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__use_path_10(PnfRustParser::Aux_rule__use_path_10Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__foreign_item_5(PnfRustParser::Aux_rule__foreign_item_5Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__param_14(PnfRustParser::Aux_rule__param_14Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__param_15(PnfRustParser::Aux_rule__param_15Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__trait_item_26(PnfRustParser::Aux_rule__trait_item_26Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__trait_item_27(PnfRustParser::Aux_rule__trait_item_27Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__type_arguments_12(PnfRustParser::Aux_rule__type_arguments_12Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__type_arguments_13(PnfRustParser::Aux_rule__type_arguments_13Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__pattern_without_mut_44(PnfRustParser::Aux_rule__pattern_without_mut_44Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__pattern_without_mut_45(PnfRustParser::Aux_rule__pattern_without_mut_45Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__pat_field_7(PnfRustParser::Aux_rule__pat_field_7Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__pat_field_8(PnfRustParser::Aux_rule__pat_field_8Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__prim_expr_no_struct_33(PnfRustParser::Aux_rule__prim_expr_no_struct_33Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__prim_expr_no_struct_34(PnfRustParser::Aux_rule__prim_expr_no_struct_34Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__prim_expr_no_struct_35(PnfRustParser::Aux_rule__prim_expr_no_struct_35Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__item_8(PnfRustParser::Aux_rule__item_8Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__param_16(PnfRustParser::Aux_rule__param_16Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__ty_path_segment_no_super_7(PnfRustParser::Aux_rule__ty_path_segment_no_super_7Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__post_expr_3(PnfRustParser::Aux_rule__post_expr_3Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__post_expr_4(PnfRustParser::Aux_rule__post_expr_4Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__post_expr_5(PnfRustParser::Aux_rule__post_expr_5Context *context) = 0;


};

}  // namespace antlr_rust_perses
