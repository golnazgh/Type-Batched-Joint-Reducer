
// Generated from PnfRust.g4 by ANTLR 4.7.2

#pragma once


#include "antlr4-runtime.h"
#include "PnfRustVisitor.h"


namespace antlr_rust_perses {

/**
 * This class provides an empty implementation of PnfRustVisitor, which can be
 * extended to create a visitor which only needs to handle a subset of the available methods.
 */
class  PnfRustBaseVisitor : public PnfRustVisitor {
public:

  virtual antlrcpp::Any visitCrate(PnfRustParser::CrateContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitMod_body(PnfRustParser::Mod_bodyContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitVisibility(PnfRustParser::VisibilityContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitVisibility_restriction(PnfRustParser::Visibility_restrictionContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitItem(PnfRustParser::ItemContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitPub_item(PnfRustParser::Pub_itemContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExtern_crate(PnfRustParser::Extern_crateContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitUse_decl(PnfRustParser::Use_declContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitUse_path(PnfRustParser::Use_pathContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitUse_suffix(PnfRustParser::Use_suffixContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitUse_item(PnfRustParser::Use_itemContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitUse_item_list(PnfRustParser::Use_item_listContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitRename(PnfRustParser::RenameContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitMod_decl_short(PnfRustParser::Mod_decl_shortContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitMod_decl(PnfRustParser::Mod_declContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExtern_mod(PnfRustParser::Extern_modContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitForeign_item(PnfRustParser::Foreign_itemContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitForeign_item_tail(PnfRustParser::Foreign_item_tailContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitStatic_decl(PnfRustParser::Static_declContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAssociated_static_decl(PnfRustParser::Associated_static_declContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitConst_decl(PnfRustParser::Const_declContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAssociated_const_decl(PnfRustParser::Associated_const_declContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitFn_decl(PnfRustParser::Fn_declContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitMethod_decl(PnfRustParser::Method_declContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTrait_method_decl(PnfRustParser::Trait_method_declContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitForeign_fn_decl(PnfRustParser::Foreign_fn_declContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitMacro_decl(PnfRustParser::Macro_declContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitMacro_head(PnfRustParser::Macro_headContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitFn_head(PnfRustParser::Fn_headContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitParam(PnfRustParser::ParamContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitParam_list(PnfRustParser::Param_listContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitVariadic_param_list(PnfRustParser::Variadic_param_listContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitVariadic_param_list_names_optional(PnfRustParser::Variadic_param_list_names_optionalContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitSelf_param(PnfRustParser::Self_paramContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitMethod_param_list(PnfRustParser::Method_param_listContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTrait_method_param(PnfRustParser::Trait_method_paramContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitRestricted_pat(PnfRustParser::Restricted_patContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTrait_method_param_list(PnfRustParser::Trait_method_param_listContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitRtype(PnfRustParser::RtypeContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitFn_rtype(PnfRustParser::Fn_rtypeContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitType_decl(PnfRustParser::Type_declContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitStruct_decl(PnfRustParser::Struct_declContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitStruct_tail(PnfRustParser::Struct_tailContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTuple_struct_field(PnfRustParser::Tuple_struct_fieldContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTuple_struct_field_list(PnfRustParser::Tuple_struct_field_listContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitField_decl(PnfRustParser::Field_declContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitField_decl_list(PnfRustParser::Field_decl_listContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitEnum_decl(PnfRustParser::Enum_declContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitEnum_variant(PnfRustParser::Enum_variantContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitEnum_variant_list(PnfRustParser::Enum_variant_listContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitEnum_variant_main(PnfRustParser::Enum_variant_mainContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitEnum_tuple_field(PnfRustParser::Enum_tuple_fieldContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitEnum_tuple_field_list(PnfRustParser::Enum_tuple_field_listContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitUnion_decl(PnfRustParser::Union_declContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTrait_decl(PnfRustParser::Trait_declContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTrait_alias(PnfRustParser::Trait_aliasContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTrait_item(PnfRustParser::Trait_itemContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTy_default(PnfRustParser::Ty_defaultContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitImpl_block(PnfRustParser::Impl_blockContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitImpl_what(PnfRustParser::Impl_whatContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitImpl_item(PnfRustParser::Impl_itemContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitImpl_item_tail(PnfRustParser::Impl_item_tailContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAttr(PnfRustParser::AttrContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitInner_attr(PnfRustParser::Inner_attrContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTt(PnfRustParser::TtContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTt_delimited(PnfRustParser::Tt_delimitedContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTt_brackets(PnfRustParser::Tt_bracketsContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTt_block(PnfRustParser::Tt_blockContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitMacro_tail(PnfRustParser::Macro_tailContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitPath(PnfRustParser::PathContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAs_trait(PnfRustParser::As_traitContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitPath_segment(PnfRustParser::Path_segmentContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitPath_segment_no_super(PnfRustParser::Path_segment_no_superContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitSimple_path(PnfRustParser::Simple_pathContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitSimple_path_segment(PnfRustParser::Simple_path_segmentContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitFor_lifetimes(PnfRustParser::For_lifetimesContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitLifetime_def_list(PnfRustParser::Lifetime_def_listContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitLifetime_def(PnfRustParser::Lifetime_defContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitType_path_main(PnfRustParser::Type_path_mainContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTy_path_tail(PnfRustParser::Ty_path_tailContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitType_path_segment(PnfRustParser::Type_path_segmentContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTy_path_segment_no_super(PnfRustParser::Ty_path_segment_no_superContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitWhere_clause(PnfRustParser::Where_clauseContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitWhere_bound_list(PnfRustParser::Where_bound_listContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitWhere_bound(PnfRustParser::Where_boundContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitEmpty_ok_colon_bound(PnfRustParser::Empty_ok_colon_boundContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitColon_bound(PnfRustParser::Colon_boundContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitPrim_bound(PnfRustParser::Prim_boundContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitInferred_type(PnfRustParser::Inferred_typeContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitArray_or_slice_type(PnfRustParser::Array_or_slice_typeContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitReference_type(PnfRustParser::Reference_typeContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitRaw_pointer_type(PnfRustParser::Raw_pointer_typeContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitNever_type(PnfRustParser::Never_typeContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTuple_type(PnfRustParser::Tuple_typeContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitImpl_trait_type(PnfRustParser::Impl_trait_typeContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitImpl_trait_type_one_bound(PnfRustParser::Impl_trait_type_one_boundContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTrait_object_type_one_bound(PnfRustParser::Trait_object_type_one_boundContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitType_param_bounds(PnfRustParser::Type_param_boundsContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitType_param_bound(PnfRustParser::Type_param_boundContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTrait_object_type(PnfRustParser::Trait_object_typeContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTrait_bound(PnfRustParser::Trait_boundContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitBare_function_type(PnfRustParser::Bare_function_typeContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitMut_or_const(PnfRustParser::Mut_or_constContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExtern_abi(PnfRustParser::Extern_abiContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitType_arguments(PnfRustParser::Type_argumentsContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitType_argument(PnfRustParser::Type_argumentContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTy_sum(PnfRustParser::Ty_sumContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTy_sum_list(PnfRustParser::Ty_sum_listContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitType_parameters(PnfRustParser::Type_parametersContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitLifetime_param(PnfRustParser::Lifetime_paramContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitLifetime_param_list(PnfRustParser::Lifetime_param_listContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitType_parameter(PnfRustParser::Type_parameterContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitType_parameter_list(PnfRustParser::Type_parameter_listContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitPattern(PnfRustParser::PatternContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitPat_ident(PnfRustParser::Pat_identContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitPat_range_end(PnfRustParser::Pat_range_endContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitPat_lit(PnfRustParser::Pat_litContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitPat_list_with_dots(PnfRustParser::Pat_list_with_dotsContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitPat_list_dots_tail(PnfRustParser::Pat_list_dots_tailContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitPat_fields_left(PnfRustParser::Pat_fields_leftContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitPat_fields(PnfRustParser::Pat_fieldsContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitPat_field(PnfRustParser::Pat_fieldContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExpr(PnfRustParser::ExprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExpr_no_struct(PnfRustParser::Expr_no_structContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExpr_list(PnfRustParser::Expr_listContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitBlock(PnfRustParser::BlockContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitBlock_with_inner_attrs(PnfRustParser::Block_with_inner_attrsContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitStmt(PnfRustParser::StmtContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitBlocky_expr(PnfRustParser::Blocky_exprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitIf_cond_or_pat(PnfRustParser::If_cond_or_patContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitWhile_cond_or_pat(PnfRustParser::While_cond_or_patContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitLoop_label(PnfRustParser::Loop_labelContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitMatch_arms(PnfRustParser::Match_armsContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitMatch_arm_intro(PnfRustParser::Match_arm_introContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitMatch_pattern(PnfRustParser::Match_patternContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitMatch_if_clause(PnfRustParser::Match_if_clauseContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExpr_attrs(PnfRustParser::Expr_attrsContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExpr_inner_attrs(PnfRustParser::Expr_inner_attrsContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitPrim_expr(PnfRustParser::Prim_exprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitPrim_expr_no_struct(PnfRustParser::Prim_expr_no_structContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitLit(PnfRustParser::LitContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitClosure_params(PnfRustParser::Closure_paramsContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitClosure_param(PnfRustParser::Closure_paramContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitClosure_param_list(PnfRustParser::Closure_param_listContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitClosure_tail(PnfRustParser::Closure_tailContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitLifetime_or_expr(PnfRustParser::Lifetime_or_exprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitFields(PnfRustParser::FieldsContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitStruct_update_base(PnfRustParser::Struct_update_baseContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitField(PnfRustParser::FieldContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitField_name(PnfRustParser::Field_nameContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitPre_expr(PnfRustParser::Pre_exprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitCmp_expr(PnfRustParser::Cmp_exprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitRange_expr(PnfRustParser::Range_exprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAssign_expr(PnfRustParser::Assign_exprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitPre_expr_no_struct(PnfRustParser::Pre_expr_no_structContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitCmp_expr_no_struct(PnfRustParser::Cmp_expr_no_structContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitRange_expr_no_struct(PnfRustParser::Range_expr_no_structContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAssign_expr_no_struct(PnfRustParser::Assign_expr_no_structContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitIdent(PnfRustParser::IdentContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAny_ident(PnfRustParser::Any_identContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTokens_no_delimiters_cash(PnfRustParser::Tokens_no_delimiters_cashContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTokens_no_delimiters_repetition_operators(PnfRustParser::Tokens_no_delimiters_repetition_operatorsContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitMacro_rules_definition(PnfRustParser::Macro_rules_definitionContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitMacro_rules_def(PnfRustParser::Macro_rules_defContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitMacro_rules(PnfRustParser::Macro_rulesContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitMacro_rule(PnfRustParser::Macro_ruleContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitMacro_matcher(PnfRustParser::Macro_matcherContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitMacro_match(PnfRustParser::Macro_matchContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitMacro_rep_sep(PnfRustParser::Macro_rep_sepContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitMacro_rep_op(PnfRustParser::Macro_rep_opContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitMacro_transcriber(PnfRustParser::Macro_transcriberContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitDelim_token_tree(PnfRustParser::Delim_token_treeContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitMacro_invocation_semi(PnfRustParser::Macro_invocation_semiContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitMacro_invocation(PnfRustParser::Macro_invocationContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitLifetime(PnfRustParser::LifetimeContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__mod_body_1(PnfRustParser::Kleene_star__mod_body_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__mod_body_2(PnfRustParser::Kleene_star__mod_body_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__visibility_1(PnfRustParser::Optional__visibility_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__item_1(PnfRustParser::Kleene_star__item_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__item_2(PnfRustParser::Optional__item_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__extern_crate_1(PnfRustParser::Optional__extern_crate_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__use_path_2(PnfRustParser::Optional__use_path_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__use_path_4(PnfRustParser::Aux_rule__use_path_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__use_path_5(PnfRustParser::Kleene_star__use_path_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__use_path_6(PnfRustParser::Optional__use_path_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__use_item_list_1(PnfRustParser::Aux_rule__use_item_list_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__use_item_list_2(PnfRustParser::Kleene_star__use_item_list_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__use_item_list_3(PnfRustParser::Optional__use_item_list_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__extern_mod_2(PnfRustParser::Kleene_star__extern_mod_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__foreign_item_tail_2(PnfRustParser::Aux_rule__foreign_item_tail_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__foreign_item_tail_3(PnfRustParser::Optional__foreign_item_tail_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__static_decl_1(PnfRustParser::Optional__static_decl_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__associated_const_decl_1(PnfRustParser::Aux_rule__associated_const_decl_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__associated_const_decl_2(PnfRustParser::Optional__associated_const_decl_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__fn_decl_1(PnfRustParser::Optional__fn_decl_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__fn_decl_2(PnfRustParser::Optional__fn_decl_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__method_decl_1(PnfRustParser::Optional__method_decl_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__trait_method_decl_1(PnfRustParser::Optional__trait_method_decl_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__foreign_fn_decl_1(PnfRustParser::Optional__foreign_fn_decl_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__foreign_fn_decl_2(PnfRustParser::Optional__foreign_fn_decl_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__macro_decl_2(PnfRustParser::Aux_rule__macro_decl_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__macro_decl_3(PnfRustParser::Optional__macro_decl_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__macro_head_1(PnfRustParser::Optional__macro_head_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__fn_head_1(PnfRustParser::Aux_rule__fn_head_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__fn_head_2(PnfRustParser::Kleene_star__fn_head_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__fn_head_3(PnfRustParser::Optional__fn_head_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__param_3(PnfRustParser::Aux_rule__param_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__param_4(PnfRustParser::Optional__param_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__param_6(PnfRustParser::Optional__param_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__param_list_1(PnfRustParser::Aux_rule__param_list_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__param_list_2(PnfRustParser::Kleene_star__param_list_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__param_list_4(PnfRustParser::Aux_rule__param_list_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__param_list_5(PnfRustParser::Optional__param_list_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__variadic_param_list_4(PnfRustParser::Aux_rule__variadic_param_list_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__variadic_param_list_5(PnfRustParser::Optional__variadic_param_list_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__trait_method_param_2(PnfRustParser::Aux_rule__trait_method_param_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__trait_method_param_3(PnfRustParser::Kleene_star__trait_method_param_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__restricted_pat_1(PnfRustParser::Optional__restricted_pat_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__restricted_pat_2(PnfRustParser::Aux_rule__restricted_pat_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__restricted_pat_3(PnfRustParser::Optional__restricted_pat_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__trait_method_param_list_2(PnfRustParser::Aux_rule__trait_method_param_list_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__trait_method_param_list_3(PnfRustParser::Kleene_star__trait_method_param_list_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__type_decl_4(PnfRustParser::Optional__type_decl_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__type_decl_6(PnfRustParser::Aux_rule__type_decl_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__type_decl_7(PnfRustParser::Optional__type_decl_7Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__type_decl_8(PnfRustParser::Aux_rule__type_decl_8Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__type_decl_9(PnfRustParser::Optional__type_decl_9Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__struct_tail_2(PnfRustParser::Optional__struct_tail_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__struct_tail_5(PnfRustParser::Optional__struct_tail_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__tuple_struct_field_list_1(PnfRustParser::Aux_rule__tuple_struct_field_list_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__tuple_struct_field_list_2(PnfRustParser::Kleene_star__tuple_struct_field_list_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__field_decl_list_1(PnfRustParser::Aux_rule__field_decl_list_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__field_decl_list_2(PnfRustParser::Kleene_star__field_decl_list_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__enum_decl_3(PnfRustParser::Optional__enum_decl_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__enum_variant_3(PnfRustParser::Aux_rule__enum_variant_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__enum_variant_4(PnfRustParser::Optional__enum_variant_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__enum_variant_list_1(PnfRustParser::Aux_rule__enum_variant_list_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__enum_variant_list_2(PnfRustParser::Kleene_star__enum_variant_list_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__enum_variant_main_1(PnfRustParser::Optional__enum_variant_main_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__enum_tuple_field_list_1(PnfRustParser::Aux_rule__enum_tuple_field_list_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__enum_tuple_field_list_2(PnfRustParser::Kleene_star__enum_tuple_field_list_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__trait_decl_2(PnfRustParser::Optional__trait_decl_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__trait_decl_7(PnfRustParser::Kleene_star__trait_decl_7Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__impl_block_1(PnfRustParser::Optional__impl_block_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__impl_block_2(PnfRustParser::Optional__impl_block_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__impl_block_3(PnfRustParser::Optional__impl_block_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__impl_block_4(PnfRustParser::Optional__impl_block_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__impl_block_5(PnfRustParser::Optional__impl_block_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__impl_block_6(PnfRustParser::Optional__impl_block_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__impl_block_7(PnfRustParser::Kleene_star__impl_block_7Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__impl_item_1(PnfRustParser::Aux_rule__impl_item_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__impl_item_2(PnfRustParser::Kleene_star__impl_item_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__impl_item_tail_11(PnfRustParser::Aux_rule__impl_item_tail_11Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__impl_item_tail_12(PnfRustParser::Optional__impl_item_tail_12Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__inner_attr_1(PnfRustParser::Kleene_star__inner_attr_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__path_1(PnfRustParser::Optional__path_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__path_parent_1(PnfRustParser::Optional__path_parent_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__path_segment_no_super_1(PnfRustParser::Aux_rule__path_segment_no_super_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__path_segment_no_super_2(PnfRustParser::Optional__path_segment_no_super_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__simple_path_1(PnfRustParser::Optional__simple_path_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__simple_path_2(PnfRustParser::Aux_rule__simple_path_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__simple_path_3(PnfRustParser::Kleene_star__simple_path_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__for_lifetimes_1(PnfRustParser::Optional__for_lifetimes_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__lifetime_def_list_1(PnfRustParser::Aux_rule__lifetime_def_list_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__lifetime_def_list_2(PnfRustParser::Kleene_star__lifetime_def_list_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__lifetime_def_1(PnfRustParser::Aux_rule__lifetime_def_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__lifetime_def_2(PnfRustParser::Optional__lifetime_def_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__type_path_main_1(PnfRustParser::Optional__type_path_main_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__ty_path_tail_1(PnfRustParser::Optional__ty_path_tail_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__ty_path_segment_no_super_2(PnfRustParser::Optional__ty_path_segment_no_super_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__ty_path_segment_no_super_3(PnfRustParser::Optional__ty_path_segment_no_super_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__where_bound_list_1(PnfRustParser::Aux_rule__where_bound_list_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__where_bound_list_2(PnfRustParser::Kleene_star__where_bound_list_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__where_bound_1(PnfRustParser::Optional__where_bound_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__where_bound_2(PnfRustParser::Optional__where_bound_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__empty_ok_colon_bound_1(PnfRustParser::Optional__empty_ok_colon_bound_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__prim_bound_3(PnfRustParser::Aux_rule__prim_bound_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__prim_bound_4(PnfRustParser::Optional__prim_bound_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__prim_bound_5(PnfRustParser::Aux_rule__prim_bound_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__type_1(PnfRustParser::Optional__type_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__array_or_slice_type_1(PnfRustParser::Aux_rule__array_or_slice_type_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__array_or_slice_type_2(PnfRustParser::Optional__array_or_slice_type_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__type_param_bounds_1(PnfRustParser::Aux_rule__type_param_bounds_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__type_param_bounds_2(PnfRustParser::Kleene_star__type_param_bounds_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__type_param_bounds_3(PnfRustParser::Optional__type_param_bounds_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__trait_object_type_2(PnfRustParser::Optional__trait_object_type_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__bare_function_type_4(PnfRustParser::Optional__bare_function_type_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__extern_abi_1(PnfRustParser::Optional__extern_abi_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__type_arguments_1(PnfRustParser::Aux_rule__type_arguments_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__type_arguments_2(PnfRustParser::Kleene_star__type_arguments_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__type_arguments_4(PnfRustParser::Aux_rule__type_arguments_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__type_arguments_5(PnfRustParser::Kleene_star__type_arguments_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__type_arguments_6(PnfRustParser::Aux_rule__type_arguments_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__type_arguments_7(PnfRustParser::Kleene_star__type_arguments_7Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__ty_sum_1(PnfRustParser::Optional__ty_sum_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__ty_sum_2(PnfRustParser::Aux_rule__ty_sum_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__ty_sum_3(PnfRustParser::Optional__ty_sum_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__ty_sum_list_1(PnfRustParser::Aux_rule__ty_sum_list_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__ty_sum_list_2(PnfRustParser::Kleene_star__ty_sum_list_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__type_parameters_1(PnfRustParser::Aux_rule__type_parameters_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__type_parameters_2(PnfRustParser::Kleene_star__type_parameters_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__type_parameters_3(PnfRustParser::Optional__type_parameters_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__lifetime_param_list_1(PnfRustParser::Aux_rule__lifetime_param_list_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__lifetime_param_list_2(PnfRustParser::Kleene_star__lifetime_param_list_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__type_parameter_4(PnfRustParser::Optional__type_parameter_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__type_parameter_list_1(PnfRustParser::Aux_rule__type_parameter_list_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__type_parameter_list_2(PnfRustParser::Kleene_star__type_parameter_list_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__pattern_1(PnfRustParser::Aux_rule__pattern_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__pattern_2(PnfRustParser::Optional__pattern_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__pattern_without_mut_1(PnfRustParser::Optional__pattern_without_mut_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__pattern_without_mut_2(PnfRustParser::Aux_rule__pattern_without_mut_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__pattern_without_mut_3(PnfRustParser::Optional__pattern_without_mut_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__pattern_without_mut_4(PnfRustParser::Aux_rule__pattern_without_mut_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__pattern_without_mut_5(PnfRustParser::Kleene_star__pattern_without_mut_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__pattern_without_mut_12(PnfRustParser::Optional__pattern_without_mut_12Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__pattern_without_mut_13(PnfRustParser::Optional__pattern_without_mut_13Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__pattern_without_mut_15(PnfRustParser::Aux_rule__pattern_without_mut_15Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__pattern_without_mut_16(PnfRustParser::Kleene_star__pattern_without_mut_16Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__pat_lit_1(PnfRustParser::Optional__pat_lit_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__pat_list_with_dots_3(PnfRustParser::Optional__pat_list_with_dots_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__pat_list_with_dots_4(PnfRustParser::Aux_rule__pat_list_with_dots_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__pat_list_with_dots_5(PnfRustParser::Optional__pat_list_with_dots_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__pat_list_dots_tail_1(PnfRustParser::Aux_rule__pat_list_dots_tail_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__pat_list_dots_tail_2(PnfRustParser::Optional__pat_list_dots_tail_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__pat_fields_1(PnfRustParser::Aux_rule__pat_fields_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__pat_fields_2(PnfRustParser::Kleene_star__pat_fields_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__pat_fields_3(PnfRustParser::Aux_rule__pat_fields_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__pat_fields_4(PnfRustParser::Kleene_star__pat_fields_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__pat_field_2(PnfRustParser::Optional__pat_field_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__expr_1(PnfRustParser::Optional__expr_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__expr_2(PnfRustParser::Optional__expr_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__expr_list_1(PnfRustParser::Aux_rule__expr_list_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__expr_list_2(PnfRustParser::Kleene_star__expr_list_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__block_with_inner_attrs_2(PnfRustParser::Kleene_star__block_with_inner_attrs_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__block_with_inner_attrs_3(PnfRustParser::Optional__block_with_inner_attrs_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__blocky_expr_1(PnfRustParser::Aux_rule__blocky_expr_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__blocky_expr_2(PnfRustParser::Kleene_star__blocky_expr_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__blocky_expr_3(PnfRustParser::Aux_rule__blocky_expr_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__blocky_expr_4(PnfRustParser::Optional__blocky_expr_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__blocky_expr_5(PnfRustParser::Optional__blocky_expr_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__blocky_expr_6(PnfRustParser::Optional__blocky_expr_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__blocky_expr_7(PnfRustParser::Optional__blocky_expr_7Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__match_arms_4(PnfRustParser::Aux_rule__match_arms_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__match_arms_5(PnfRustParser::Optional__match_arms_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__match_arm_intro_2(PnfRustParser::Optional__match_arm_intro_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__match_pattern_2(PnfRustParser::Aux_rule__match_pattern_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__match_pattern_3(PnfRustParser::Kleene_star__match_pattern_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__prim_expr_1(PnfRustParser::Optional__prim_expr_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__prim_expr_2(PnfRustParser::Optional__prim_expr_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__prim_expr_no_struct_1(PnfRustParser::Optional__prim_expr_no_struct_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__prim_expr_no_struct_5(PnfRustParser::Optional__prim_expr_no_struct_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__prim_expr_no_struct_9(PnfRustParser::Optional__prim_expr_no_struct_9Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__prim_expr_no_struct_10(PnfRustParser::Optional__prim_expr_no_struct_10Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__prim_expr_no_struct_11(PnfRustParser::Optional__prim_expr_no_struct_11Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__prim_expr_no_struct_12(PnfRustParser::Optional__prim_expr_no_struct_12Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__prim_expr_no_struct_13(PnfRustParser::Optional__prim_expr_no_struct_13Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__closure_params_1(PnfRustParser::Optional__closure_params_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__closure_param_list_1(PnfRustParser::Aux_rule__closure_param_list_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__closure_param_list_2(PnfRustParser::Kleene_star__closure_param_list_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__fields_1(PnfRustParser::Aux_rule__fields_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__fields_2(PnfRustParser::Kleene_star__fields_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__field_1(PnfRustParser::Kleene_star__field_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__post_expr_tail_4(PnfRustParser::Aux_rule__post_expr_tail_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__post_expr_tail_5(PnfRustParser::Optional__post_expr_tail_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__range_expr_1(PnfRustParser::Optional__range_expr_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__range_expr_no_struct_1(PnfRustParser::Optional__range_expr_no_struct_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__macro_rules_def_1(PnfRustParser::Optional__macro_rules_def_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__macro_rules_1(PnfRustParser::Aux_rule__macro_rules_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__macro_rules_2(PnfRustParser::Kleene_star__macro_rules_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__macro_rules_3(PnfRustParser::Optional__macro_rules_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__macro_matcher_1(PnfRustParser::Kleene_star__macro_matcher_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_plus__macro_match_1(PnfRustParser::Kleene_plus__macro_match_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__macro_match_2(PnfRustParser::Optional__macro_match_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__bound_4(PnfRustParser::Aux_rule__bound_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__bound_3(PnfRustParser::Kleene_star__bound_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitBound(PnfRustParser::BoundContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__path_parent_3(PnfRustParser::Aux_rule__path_parent_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__path_parent_2(PnfRustParser::Kleene_star__path_parent_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__path_parent_4(PnfRustParser::Aux_rule__path_parent_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitPath_parent(PnfRustParser::Path_parentContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__lifetime_bound_2(PnfRustParser::Aux_rule__lifetime_bound_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__lifetime_bound_1(PnfRustParser::Kleene_star__lifetime_bound_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitLifetime_bound(PnfRustParser::Lifetime_boundContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__ty_path_parent_3(PnfRustParser::Aux_rule__ty_path_parent_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__ty_path_parent_2(PnfRustParser::Kleene_star__ty_path_parent_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__ty_path_parent_4(PnfRustParser::Aux_rule__ty_path_parent_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTy_path_parent(PnfRustParser::Ty_path_parentContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__pattern_without_mut_19(PnfRustParser::Aux_rule__pattern_without_mut_19Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__pattern_without_mut_18(PnfRustParser::Kleene_star__pattern_without_mut_18Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__pattern_without_mut_20(PnfRustParser::Aux_rule__pattern_without_mut_20Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitPattern_without_mut(PnfRustParser::Pattern_without_mutContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__post_expr_1(PnfRustParser::Kleene_star__post_expr_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitPost_expr(PnfRustParser::Post_exprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__cast_expr_2(PnfRustParser::Aux_rule__cast_expr_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__cast_expr_1(PnfRustParser::Kleene_star__cast_expr_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitCast_expr(PnfRustParser::Cast_exprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__mul_expr_2(PnfRustParser::Aux_rule__mul_expr_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__mul_expr_1(PnfRustParser::Kleene_star__mul_expr_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitMul_expr(PnfRustParser::Mul_exprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__add_expr_2(PnfRustParser::Aux_rule__add_expr_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__add_expr_1(PnfRustParser::Kleene_star__add_expr_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAdd_expr(PnfRustParser::Add_exprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__shift_expr_2(PnfRustParser::Aux_rule__shift_expr_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__shift_expr_1(PnfRustParser::Kleene_star__shift_expr_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitShift_expr(PnfRustParser::Shift_exprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__bit_and_expr_2(PnfRustParser::Aux_rule__bit_and_expr_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__bit_and_expr_1(PnfRustParser::Kleene_star__bit_and_expr_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitBit_and_expr(PnfRustParser::Bit_and_exprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__bit_xor_expr_2(PnfRustParser::Aux_rule__bit_xor_expr_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__bit_xor_expr_1(PnfRustParser::Kleene_star__bit_xor_expr_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitBit_xor_expr(PnfRustParser::Bit_xor_exprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__bit_or_expr_2(PnfRustParser::Aux_rule__bit_or_expr_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__bit_or_expr_1(PnfRustParser::Kleene_star__bit_or_expr_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitBit_or_expr(PnfRustParser::Bit_or_exprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__and_expr_2(PnfRustParser::Aux_rule__and_expr_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__and_expr_1(PnfRustParser::Kleene_star__and_expr_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAnd_expr(PnfRustParser::And_exprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__or_expr_2(PnfRustParser::Aux_rule__or_expr_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__or_expr_1(PnfRustParser::Kleene_star__or_expr_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOr_expr(PnfRustParser::Or_exprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitPost_expr_no_struct(PnfRustParser::Post_expr_no_structContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitCast_expr_no_struct(PnfRustParser::Cast_expr_no_structContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__mul_expr_no_struct_2(PnfRustParser::Aux_rule__mul_expr_no_struct_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__mul_expr_no_struct_1(PnfRustParser::Kleene_star__mul_expr_no_struct_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitMul_expr_no_struct(PnfRustParser::Mul_expr_no_structContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__add_expr_no_struct_2(PnfRustParser::Aux_rule__add_expr_no_struct_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__add_expr_no_struct_1(PnfRustParser::Kleene_star__add_expr_no_struct_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAdd_expr_no_struct(PnfRustParser::Add_expr_no_structContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__shift_expr_no_struct_2(PnfRustParser::Aux_rule__shift_expr_no_struct_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__shift_expr_no_struct_1(PnfRustParser::Kleene_star__shift_expr_no_struct_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitShift_expr_no_struct(PnfRustParser::Shift_expr_no_structContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__bit_and_expr_no_struct_2(PnfRustParser::Aux_rule__bit_and_expr_no_struct_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__bit_and_expr_no_struct_1(PnfRustParser::Kleene_star__bit_and_expr_no_struct_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitBit_and_expr_no_struct(PnfRustParser::Bit_and_expr_no_structContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__bit_xor_expr_no_struct_2(PnfRustParser::Aux_rule__bit_xor_expr_no_struct_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__bit_xor_expr_no_struct_1(PnfRustParser::Kleene_star__bit_xor_expr_no_struct_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitBit_xor_expr_no_struct(PnfRustParser::Bit_xor_expr_no_structContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__bit_or_expr_no_struct_2(PnfRustParser::Aux_rule__bit_or_expr_no_struct_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__bit_or_expr_no_struct_1(PnfRustParser::Kleene_star__bit_or_expr_no_struct_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitBit_or_expr_no_struct(PnfRustParser::Bit_or_expr_no_structContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__and_expr_no_struct_2(PnfRustParser::Aux_rule__and_expr_no_struct_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__and_expr_no_struct_1(PnfRustParser::Kleene_star__and_expr_no_struct_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAnd_expr_no_struct(PnfRustParser::And_expr_no_structContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__or_expr_no_struct_2(PnfRustParser::Aux_rule__or_expr_no_struct_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__or_expr_no_struct_1(PnfRustParser::Kleene_star__or_expr_no_struct_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOr_expr_no_struct(PnfRustParser::Or_expr_no_structContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_plus__expr_attrs_2(PnfRustParser::Kleene_plus__expr_attrs_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_plus__expr_inner_attrs_2(PnfRustParser::Kleene_plus__expr_inner_attrs_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__enum_variant_main_3(PnfRustParser::Aux_rule__enum_variant_main_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__enum_variant_main_4(PnfRustParser::Optional__enum_variant_main_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__impl_what_1(PnfRustParser::Aux_rule__impl_what_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__impl_what_2(PnfRustParser::Optional__impl_what_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__path_2(PnfRustParser::Aux_rule__path_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__path_3(PnfRustParser::Optional__path_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__type_path_main_2(PnfRustParser::Aux_rule__type_path_main_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__type_path_main_3(PnfRustParser::Optional__type_path_main_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__tuple_type_2(PnfRustParser::Aux_rule__tuple_type_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__tuple_type_3(PnfRustParser::Optional__tuple_type_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__type_argument_1(PnfRustParser::Aux_rule__type_argument_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__type_argument_2(PnfRustParser::Optional__type_argument_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__pattern_without_mut_21(PnfRustParser::Aux_rule__pattern_without_mut_21Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__pattern_without_mut_22(PnfRustParser::Optional__pattern_without_mut_22Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__pattern_without_mut_23(PnfRustParser::Aux_rule__pattern_without_mut_23Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__pattern_without_mut_24(PnfRustParser::Optional__pattern_without_mut_24Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__assign_expr_1(PnfRustParser::Aux_rule__assign_expr_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__assign_expr_2(PnfRustParser::Optional__assign_expr_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__assign_expr_no_struct_1(PnfRustParser::Aux_rule__assign_expr_no_struct_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__assign_expr_no_struct_2(PnfRustParser::Optional__assign_expr_no_struct_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__blocky_expr_11(PnfRustParser::Optional__blocky_expr_11Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__closure_params_2(PnfRustParser::Optional__closure_params_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__cmp_expr_1(PnfRustParser::Aux_rule__cmp_expr_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__cmp_expr_2(PnfRustParser::Optional__cmp_expr_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__range_expr_5(PnfRustParser::Aux_rule__range_expr_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__range_expr_6(PnfRustParser::Optional__range_expr_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__cmp_expr_no_struct_5(PnfRustParser::Aux_rule__cmp_expr_no_struct_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__cmp_expr_no_struct_6(PnfRustParser::Optional__cmp_expr_no_struct_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__range_expr_no_struct_5(PnfRustParser::Aux_rule__range_expr_no_struct_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__range_expr_no_struct_6(PnfRustParser::Optional__range_expr_no_struct_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__visibility_restriction_1(PnfRustParser::Altnt_block__visibility_restriction_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__type_decl_10(PnfRustParser::Altnt_block__type_decl_10Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__use_suffix_2(PnfRustParser::Altnt_block__use_suffix_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__foreign_item_tail_11(PnfRustParser::Altnt_block__foreign_item_tail_11Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__macro_invocation_semi_4(PnfRustParser::Altnt_block__macro_invocation_semi_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__type_parameters_4(PnfRustParser::Altnt_block__type_parameters_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__trait_method_param_6(PnfRustParser::Altnt_block__trait_method_param_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__struct_tail_6(PnfRustParser::Altnt_block__struct_tail_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__enum_variant_main_5(PnfRustParser::Altnt_block__enum_variant_main_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__trait_item_19(PnfRustParser::Altnt_block__trait_item_19Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__impl_what_3(PnfRustParser::Altnt_block__impl_what_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__type_arguments_9(PnfRustParser::Altnt_block__type_arguments_9Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__impl_item_tail_13(PnfRustParser::Altnt_block__impl_item_tail_13Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__pattern_without_mut_25(PnfRustParser::Altnt_block__pattern_without_mut_25Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__pattern_without_mut_26(PnfRustParser::Altnt_block__pattern_without_mut_26Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__pattern_without_mut_27(PnfRustParser::Altnt_block__pattern_without_mut_27Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__pattern_without_mut_28(PnfRustParser::Altnt_block__pattern_without_mut_28Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__pattern_without_mut_29(PnfRustParser::Altnt_block__pattern_without_mut_29Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__pat_fields_6(PnfRustParser::Altnt_block__pat_fields_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__stmt_8(PnfRustParser::Altnt_block__stmt_8Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__blocky_expr_12(PnfRustParser::Altnt_block__blocky_expr_12Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__if_cond_or_pat_1(PnfRustParser::Altnt_block__if_cond_or_pat_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__match_arms_6(PnfRustParser::Altnt_block__match_arms_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__prim_expr_no_struct_18(PnfRustParser::Altnt_block__prim_expr_no_struct_18Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__prim_expr_no_struct_19(PnfRustParser::Altnt_block__prim_expr_no_struct_19Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__post_expr_tail_7(PnfRustParser::Altnt_block__post_expr_tail_7Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__pre_expr_3(PnfRustParser::Altnt_block__pre_expr_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__cast_expr_3(PnfRustParser::Altnt_block__cast_expr_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__mul_expr_3(PnfRustParser::Altnt_block__mul_expr_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__add_expr_3(PnfRustParser::Altnt_block__add_expr_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__shift_expr_3(PnfRustParser::Altnt_block__shift_expr_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__range_expr_7(PnfRustParser::Altnt_block__range_expr_7Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__range_expr_no_struct_7(PnfRustParser::Altnt_block__range_expr_no_struct_7Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__macro_rules_def_4(PnfRustParser::Altnt_block__macro_rules_def_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__macro_match_3(PnfRustParser::Altnt_block__macro_match_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__macro_invocation_semi_5(PnfRustParser::Altnt_block__macro_invocation_semi_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitType(PnfRustParser::TypeContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__extern_crate_2(PnfRustParser::Altnt_block__extern_crate_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__use_path_7(PnfRustParser::Altnt_block__use_path_7Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__use_item_2(PnfRustParser::Altnt_block__use_item_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__const_decl_2(PnfRustParser::Altnt_block__const_decl_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__fn_decl_4(PnfRustParser::Altnt_block__fn_decl_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__method_param_list_4(PnfRustParser::Altnt_block__method_param_list_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__restricted_pat_4(PnfRustParser::Altnt_block__restricted_pat_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__trait_method_param_list_5(PnfRustParser::Altnt_block__trait_method_param_list_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__fn_rtype_1(PnfRustParser::Altnt_block__fn_rtype_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__trait_alias_3(PnfRustParser::Altnt_block__trait_alias_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__trait_item_20(PnfRustParser::Altnt_block__trait_item_20Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__ty_path_tail_3(PnfRustParser::Altnt_block__ty_path_tail_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__pat_fields_7(PnfRustParser::Altnt_block__pat_fields_7Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__prim_expr_no_struct_20(PnfRustParser::Altnt_block__prim_expr_no_struct_20Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__fields_4(PnfRustParser::Altnt_block__fields_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__type_arguments_10(PnfRustParser::Altnt_block__type_arguments_10Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__assign_expr_3(PnfRustParser::Altnt_block__assign_expr_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__assign_expr_no_struct_3(PnfRustParser::Altnt_block__assign_expr_no_struct_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__cmp_expr_3(PnfRustParser::Altnt_block__cmp_expr_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__cmp_expr_no_struct_7(PnfRustParser::Altnt_block__cmp_expr_no_struct_7Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__trait_method_param_7(PnfRustParser::Altnt_block__trait_method_param_7Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__trait_method_param_8(PnfRustParser::Aux_rule__trait_method_param_8Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__trait_method_param_9(PnfRustParser::Optional__trait_method_param_9Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__struct_tail_7(PnfRustParser::Aux_rule__struct_tail_7Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__struct_tail_8(PnfRustParser::Optional__struct_tail_8Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__assign_expr_no_struct_4(PnfRustParser::Aux_rule__assign_expr_no_struct_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__assign_expr_no_struct_5(PnfRustParser::Optional__assign_expr_no_struct_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__blocky_expr_13(PnfRustParser::Aux_rule__blocky_expr_13Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__blocky_expr_14(PnfRustParser::Optional__blocky_expr_14Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__cmp_expr_no_struct_8(PnfRustParser::Optional__cmp_expr_no_struct_8Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__type_decl_11(PnfRustParser::Altnt_block__type_decl_11Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__use_path_8(PnfRustParser::Altnt_block__use_path_8Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__foreign_item_4(PnfRustParser::Altnt_block__foreign_item_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__param_12(PnfRustParser::Altnt_block__param_12Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__trait_item_21(PnfRustParser::Altnt_block__trait_item_21Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__trait_item_22(PnfRustParser::Altnt_block__trait_item_22Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__type_arguments_11(PnfRustParser::Altnt_block__type_arguments_11Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__pattern_without_mut_31(PnfRustParser::Altnt_block__pattern_without_mut_31Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__pat_field_6(PnfRustParser::Altnt_block__pat_field_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__blocky_expr_15(PnfRustParser::Altnt_block__blocky_expr_15Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__prim_expr_no_struct_22(PnfRustParser::Altnt_block__prim_expr_no_struct_22Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__prim_expr_no_struct_23(PnfRustParser::Altnt_block__prim_expr_no_struct_23Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__prim_expr_no_struct_24(PnfRustParser::Altnt_block__prim_expr_no_struct_24Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__range_expr_8(PnfRustParser::Altnt_block__range_expr_8Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__item_7(PnfRustParser::Altnt_block__item_7Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__param_11(PnfRustParser::Altnt_block__param_11Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__ty_path_segment_no_super_6(PnfRustParser::Altnt_block__ty_path_segment_no_super_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__post_expr_2(PnfRustParser::Aux_rule__post_expr_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__visibility_2(PnfRustParser::Aux_rule__visibility_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__use_suffix_3(PnfRustParser::Aux_rule__use_suffix_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__foreign_item_tail_12(PnfRustParser::Aux_rule__foreign_item_tail_12Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__param_13(PnfRustParser::Aux_rule__param_13Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__self_param_6(PnfRustParser::Aux_rule__self_param_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__self_param_7(PnfRustParser::Aux_rule__self_param_7Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__trait_method_param_10(PnfRustParser::Aux_rule__trait_method_param_10Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__struct_tail_9(PnfRustParser::Aux_rule__struct_tail_9Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__struct_tail_10(PnfRustParser::Aux_rule__struct_tail_10Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__trait_item_23(PnfRustParser::Aux_rule__trait_item_23Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__trait_item_24(PnfRustParser::Aux_rule__trait_item_24Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__trait_item_25(PnfRustParser::Aux_rule__trait_item_25Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__impl_what_4(PnfRustParser::Aux_rule__impl_what_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__impl_what_5(PnfRustParser::Aux_rule__impl_what_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__impl_what_6(PnfRustParser::Aux_rule__impl_what_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__impl_item_tail_14(PnfRustParser::Aux_rule__impl_item_tail_14Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__impl_item_tail_15(PnfRustParser::Aux_rule__impl_item_tail_15Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__tt_1(PnfRustParser::Aux_rule__tt_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__ty_path_tail_4(PnfRustParser::Aux_rule__ty_path_tail_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__where_bound_3(PnfRustParser::Aux_rule__where_bound_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__where_bound_4(PnfRustParser::Aux_rule__where_bound_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__trait_bound_5(PnfRustParser::Aux_rule__trait_bound_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__trait_bound_6(PnfRustParser::Aux_rule__trait_bound_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__type_argument_3(PnfRustParser::Aux_rule__type_argument_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__type_parameter_5(PnfRustParser::Aux_rule__type_parameter_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__pattern_3(PnfRustParser::Aux_rule__pattern_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__pat_ident_1(PnfRustParser::Aux_rule__pat_ident_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__pat_list_with_dots_6(PnfRustParser::Aux_rule__pat_list_with_dots_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__pat_fields_8(PnfRustParser::Aux_rule__pat_fields_8Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__pat_fields_9(PnfRustParser::Aux_rule__pat_fields_9Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__stmt_9(PnfRustParser::Aux_rule__stmt_9Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__stmt_10(PnfRustParser::Aux_rule__stmt_10Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__blocky_expr_16(PnfRustParser::Aux_rule__blocky_expr_16Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__blocky_expr_17(PnfRustParser::Aux_rule__blocky_expr_17Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__blocky_expr_18(PnfRustParser::Aux_rule__blocky_expr_18Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__prim_expr_3(PnfRustParser::Aux_rule__prim_expr_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__prim_expr_no_struct_25(PnfRustParser::Aux_rule__prim_expr_no_struct_25Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__prim_expr_no_struct_26(PnfRustParser::Aux_rule__prim_expr_no_struct_26Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__prim_expr_no_struct_27(PnfRustParser::Aux_rule__prim_expr_no_struct_27Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__prim_expr_no_struct_28(PnfRustParser::Aux_rule__prim_expr_no_struct_28Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__prim_expr_no_struct_29(PnfRustParser::Aux_rule__prim_expr_no_struct_29Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__prim_expr_no_struct_30(PnfRustParser::Aux_rule__prim_expr_no_struct_30Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__prim_expr_no_struct_31(PnfRustParser::Aux_rule__prim_expr_no_struct_31Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__closure_params_3(PnfRustParser::Aux_rule__closure_params_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__closure_tail_2(PnfRustParser::Aux_rule__closure_tail_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__fields_5(PnfRustParser::Aux_rule__fields_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__field_2(PnfRustParser::Aux_rule__field_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__pre_expr_5(PnfRustParser::Aux_rule__pre_expr_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__pre_expr_6(PnfRustParser::Aux_rule__pre_expr_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__range_expr_9(PnfRustParser::Aux_rule__range_expr_9Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__range_expr_10(PnfRustParser::Aux_rule__range_expr_10Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__pre_expr_no_struct_4(PnfRustParser::Aux_rule__pre_expr_no_struct_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__range_expr_no_struct_9(PnfRustParser::Aux_rule__range_expr_no_struct_9Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__range_expr_no_struct_10(PnfRustParser::Aux_rule__range_expr_no_struct_10Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__macro_rules_def_5(PnfRustParser::Aux_rule__macro_rules_def_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__macro_rules_def_6(PnfRustParser::Aux_rule__macro_rules_def_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__macro_matcher_4(PnfRustParser::Aux_rule__macro_matcher_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__macro_matcher_5(PnfRustParser::Aux_rule__macro_matcher_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__macro_matcher_6(PnfRustParser::Aux_rule__macro_matcher_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__macro_match_4(PnfRustParser::Aux_rule__macro_match_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__delim_token_tree_4(PnfRustParser::Aux_rule__delim_token_tree_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__delim_token_tree_5(PnfRustParser::Aux_rule__delim_token_tree_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__delim_token_tree_6(PnfRustParser::Aux_rule__delim_token_tree_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__prim_bound_6(PnfRustParser::Aux_rule__prim_bound_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__bound_5(PnfRustParser::Aux_rule__bound_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__bound_6(PnfRustParser::Aux_rule__bound_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__path_parent_6(PnfRustParser::Aux_rule__path_parent_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__path_parent_7(PnfRustParser::Aux_rule__path_parent_7Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__ty_path_parent_6(PnfRustParser::Aux_rule__ty_path_parent_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__ty_path_parent_7(PnfRustParser::Aux_rule__ty_path_parent_7Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__pattern_without_mut_32(PnfRustParser::Aux_rule__pattern_without_mut_32Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__pattern_without_mut_33(PnfRustParser::Aux_rule__pattern_without_mut_33Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__pattern_without_mut_34(PnfRustParser::Aux_rule__pattern_without_mut_34Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__pattern_without_mut_35(PnfRustParser::Aux_rule__pattern_without_mut_35Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__pattern_without_mut_36(PnfRustParser::Aux_rule__pattern_without_mut_36Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__pattern_without_mut_37(PnfRustParser::Aux_rule__pattern_without_mut_37Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__pattern_without_mut_38(PnfRustParser::Aux_rule__pattern_without_mut_38Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__pattern_without_mut_39(PnfRustParser::Aux_rule__pattern_without_mut_39Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__pattern_without_mut_40(PnfRustParser::Aux_rule__pattern_without_mut_40Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__visibility_restriction_2(PnfRustParser::Aux_rule__visibility_restriction_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__use_suffix_4(PnfRustParser::Aux_rule__use_suffix_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__foreign_item_tail_13(PnfRustParser::Aux_rule__foreign_item_tail_13Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__foreign_item_tail_14(PnfRustParser::Aux_rule__foreign_item_tail_14Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__macro_invocation_semi_6(PnfRustParser::Aux_rule__macro_invocation_semi_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__macro_invocation_semi_7(PnfRustParser::Aux_rule__macro_invocation_semi_7Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__type_parameters_5(PnfRustParser::Aux_rule__type_parameters_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__enum_variant_main_6(PnfRustParser::Aux_rule__enum_variant_main_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__enum_variant_main_7(PnfRustParser::Aux_rule__enum_variant_main_7Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__impl_item_tail_16(PnfRustParser::Aux_rule__impl_item_tail_16Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__impl_item_tail_17(PnfRustParser::Aux_rule__impl_item_tail_17Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__pattern_without_mut_41(PnfRustParser::Aux_rule__pattern_without_mut_41Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__pattern_without_mut_42(PnfRustParser::Aux_rule__pattern_without_mut_42Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__pattern_without_mut_43(PnfRustParser::Aux_rule__pattern_without_mut_43Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__pat_fields_10(PnfRustParser::Aux_rule__pat_fields_10Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__stmt_11(PnfRustParser::Aux_rule__stmt_11Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__blocky_expr_19(PnfRustParser::Aux_rule__blocky_expr_19Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__if_cond_or_pat_2(PnfRustParser::Aux_rule__if_cond_or_pat_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__match_arms_7(PnfRustParser::Aux_rule__match_arms_7Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__match_arms_8(PnfRustParser::Aux_rule__match_arms_8Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__post_expr_tail_8(PnfRustParser::Aux_rule__post_expr_tail_8Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__pre_expr_7(PnfRustParser::Aux_rule__pre_expr_7Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__shift_expr_4(PnfRustParser::Aux_rule__shift_expr_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__shift_expr_5(PnfRustParser::Aux_rule__shift_expr_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__range_expr_11(PnfRustParser::Aux_rule__range_expr_11Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__range_expr_no_struct_11(PnfRustParser::Aux_rule__range_expr_no_struct_11Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__macro_rules_def_7(PnfRustParser::Aux_rule__macro_rules_def_7Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__macro_rules_def_8(PnfRustParser::Aux_rule__macro_rules_def_8Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__macro_match_5(PnfRustParser::Aux_rule__macro_match_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__macro_match_6(PnfRustParser::Aux_rule__macro_match_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__macro_invocation_semi_8(PnfRustParser::Aux_rule__macro_invocation_semi_8Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__macro_invocation_semi_9(PnfRustParser::Aux_rule__macro_invocation_semi_9Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__type_3(PnfRustParser::Aux_rule__type_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__type_4(PnfRustParser::Aux_rule__type_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__type_5(PnfRustParser::Aux_rule__type_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__fn_rtype_2(PnfRustParser::Aux_rule__fn_rtype_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__trait_alias_4(PnfRustParser::Aux_rule__trait_alias_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__pat_fields_11(PnfRustParser::Aux_rule__pat_fields_11Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__prim_expr_no_struct_32(PnfRustParser::Aux_rule__prim_expr_no_struct_32Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__fields_6(PnfRustParser::Aux_rule__fields_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__assign_expr_no_struct_6(PnfRustParser::Aux_rule__assign_expr_no_struct_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__cmp_expr_no_struct_9(PnfRustParser::Aux_rule__cmp_expr_no_struct_9Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__trait_method_param_11(PnfRustParser::Aux_rule__trait_method_param_11Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__type_decl_12(PnfRustParser::Aux_rule__type_decl_12Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__type_decl_13(PnfRustParser::Aux_rule__type_decl_13Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__use_path_9(PnfRustParser::Aux_rule__use_path_9Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__use_path_10(PnfRustParser::Aux_rule__use_path_10Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__foreign_item_5(PnfRustParser::Aux_rule__foreign_item_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__param_14(PnfRustParser::Aux_rule__param_14Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__param_15(PnfRustParser::Aux_rule__param_15Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__trait_item_26(PnfRustParser::Aux_rule__trait_item_26Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__trait_item_27(PnfRustParser::Aux_rule__trait_item_27Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__type_arguments_12(PnfRustParser::Aux_rule__type_arguments_12Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__type_arguments_13(PnfRustParser::Aux_rule__type_arguments_13Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__pattern_without_mut_44(PnfRustParser::Aux_rule__pattern_without_mut_44Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__pattern_without_mut_45(PnfRustParser::Aux_rule__pattern_without_mut_45Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__pat_field_7(PnfRustParser::Aux_rule__pat_field_7Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__pat_field_8(PnfRustParser::Aux_rule__pat_field_8Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__prim_expr_no_struct_33(PnfRustParser::Aux_rule__prim_expr_no_struct_33Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__prim_expr_no_struct_34(PnfRustParser::Aux_rule__prim_expr_no_struct_34Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__prim_expr_no_struct_35(PnfRustParser::Aux_rule__prim_expr_no_struct_35Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__item_8(PnfRustParser::Aux_rule__item_8Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__param_16(PnfRustParser::Aux_rule__param_16Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__ty_path_segment_no_super_7(PnfRustParser::Aux_rule__ty_path_segment_no_super_7Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__post_expr_3(PnfRustParser::Aux_rule__post_expr_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__post_expr_4(PnfRustParser::Aux_rule__post_expr_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__post_expr_5(PnfRustParser::Aux_rule__post_expr_5Context *ctx) override {
    return visitChildren(ctx);
  }


};

}  // namespace antlr_rust_perses
