
// Generated from PnfRust.g4 by ANTLR 4.7.2

#pragma once


#include "antlr4-runtime.h"


namespace antlr_rust_perses {


class  PnfRustParser : public antlr4::Parser {
public:
  enum {
    T__0 = 1, T__1 = 2, T__2 = 3, T__3 = 4, T__4 = 5, T__5 = 6, T__6 = 7, 
    T__7 = 8, T__8 = 9, T__9 = 10, T__10 = 11, T__11 = 12, T__12 = 13, T__13 = 14, 
    T__14 = 15, T__15 = 16, T__16 = 17, T__17 = 18, T__18 = 19, T__19 = 20, 
    T__20 = 21, T__21 = 22, T__22 = 23, T__23 = 24, T__24 = 25, T__25 = 26, 
    T__26 = 27, T__27 = 28, T__28 = 29, T__29 = 30, T__30 = 31, T__31 = 32, 
    T__32 = 33, T__33 = 34, T__34 = 35, T__35 = 36, T__36 = 37, T__37 = 38, 
    T__38 = 39, T__39 = 40, T__40 = 41, T__41 = 42, T__42 = 43, T__43 = 44, 
    T__44 = 45, T__45 = 46, T__46 = 47, T__47 = 48, T__48 = 49, T__49 = 50, 
    T__50 = 51, T__51 = 52, T__52 = 53, T__53 = 54, T__54 = 55, T__55 = 56, 
    T__56 = 57, T__57 = 58, T__58 = 59, T__59 = 60, T__60 = 61, T__61 = 62, 
    T__62 = 63, T__63 = 64, T__64 = 65, T__65 = 66, T__66 = 67, T__67 = 68, 
    T__68 = 69, T__69 = 70, T__70 = 71, T__71 = 72, T__72 = 73, T__73 = 74, 
    T__74 = 75, T__75 = 76, T__76 = 77, T__77 = 78, T__78 = 79, T__79 = 80, 
    T__80 = 81, T__81 = 82, T__82 = 83, T__83 = 84, T__84 = 85, T__85 = 86, 
    T__86 = 87, T__87 = 88, T__88 = 89, T__89 = 90, T__90 = 91, T__91 = 92, 
    T__92 = 93, T__93 = 94, T__94 = 95, T__95 = 96, T__96 = 97, T__97 = 98, 
    T__98 = 99, CashMoney = 100, RawIdentifier = 101, Lifetime = 102, Ident = 103, 
    CharLit = 104, StringLit = 105, ByteLit = 106, ByteStringLit = 107, 
    BareIntLit = 108, FullIntLit = 109, FloatLit = 110, Whitespace = 111, 
    LineComment = 112, BlockComment = 113, Shebang = 114
  };

  enum {
    RuleCrate = 0, RuleMod_body = 1, RuleVisibility = 2, RuleVisibility_restriction = 3, 
    RuleItem = 4, RulePub_item = 5, RuleExtern_crate = 6, RuleUse_decl = 7, 
    RuleUse_path = 8, RuleUse_suffix = 9, RuleUse_item = 10, RuleUse_item_list = 11, 
    RuleRename = 12, RuleMod_decl_short = 13, RuleMod_decl = 14, RuleExtern_mod = 15, 
    RuleForeign_item = 16, RuleForeign_item_tail = 17, RuleStatic_decl = 18, 
    RuleAssociated_static_decl = 19, RuleConst_decl = 20, RuleAssociated_const_decl = 21, 
    RuleFn_decl = 22, RuleMethod_decl = 23, RuleTrait_method_decl = 24, 
    RuleForeign_fn_decl = 25, RuleMacro_decl = 26, RuleMacro_head = 27, 
    RuleFn_head = 28, RuleParam = 29, RuleParam_list = 30, RuleVariadic_param_list = 31, 
    RuleVariadic_param_list_names_optional = 32, RuleSelf_param = 33, RuleMethod_param_list = 34, 
    RuleTrait_method_param = 35, RuleRestricted_pat = 36, RuleTrait_method_param_list = 37, 
    RuleRtype = 38, RuleFn_rtype = 39, RuleType_decl = 40, RuleStruct_decl = 41, 
    RuleStruct_tail = 42, RuleTuple_struct_field = 43, RuleTuple_struct_field_list = 44, 
    RuleField_decl = 45, RuleField_decl_list = 46, RuleEnum_decl = 47, RuleEnum_variant = 48, 
    RuleEnum_variant_list = 49, RuleEnum_variant_main = 50, RuleEnum_tuple_field = 51, 
    RuleEnum_tuple_field_list = 52, RuleUnion_decl = 53, RuleTrait_decl = 54, 
    RuleTrait_alias = 55, RuleTrait_item = 56, RuleTy_default = 57, RuleImpl_block = 58, 
    RuleImpl_what = 59, RuleImpl_item = 60, RuleImpl_item_tail = 61, RuleAttr = 62, 
    RuleInner_attr = 63, RuleTt = 64, RuleTt_delimited = 65, RuleTt_brackets = 66, 
    RuleTt_block = 67, RuleMacro_tail = 68, RulePath = 69, RuleAs_trait = 70, 
    RulePath_segment = 71, RulePath_segment_no_super = 72, RuleSimple_path = 73, 
    RuleSimple_path_segment = 74, RuleFor_lifetimes = 75, RuleLifetime_def_list = 76, 
    RuleLifetime_def = 77, RuleType_path_main = 78, RuleTy_path_tail = 79, 
    RuleType_path_segment = 80, RuleTy_path_segment_no_super = 81, RuleWhere_clause = 82, 
    RuleWhere_bound_list = 83, RuleWhere_bound = 84, RuleEmpty_ok_colon_bound = 85, 
    RuleColon_bound = 86, RulePrim_bound = 87, RuleInferred_type = 88, RuleArray_or_slice_type = 89, 
    RuleReference_type = 90, RuleRaw_pointer_type = 91, RuleNever_type = 92, 
    RuleTuple_type = 93, RuleImpl_trait_type = 94, RuleImpl_trait_type_one_bound = 95, 
    RuleTrait_object_type_one_bound = 96, RuleType_param_bounds = 97, RuleType_param_bound = 98, 
    RuleTrait_object_type = 99, RuleTrait_bound = 100, RuleBare_function_type = 101, 
    RuleMut_or_const = 102, RuleExtern_abi = 103, RuleType_arguments = 104, 
    RuleType_argument = 105, RuleTy_sum = 106, RuleTy_sum_list = 107, RuleType_parameters = 108, 
    RuleLifetime_param = 109, RuleLifetime_param_list = 110, RuleType_parameter = 111, 
    RuleType_parameter_list = 112, RulePattern = 113, RulePat_ident = 114, 
    RulePat_range_end = 115, RulePat_lit = 116, RulePat_list_with_dots = 117, 
    RulePat_list_dots_tail = 118, RulePat_fields_left = 119, RulePat_fields = 120, 
    RulePat_field = 121, RuleExpr = 122, RuleExpr_no_struct = 123, RuleExpr_list = 124, 
    RuleBlock = 125, RuleBlock_with_inner_attrs = 126, RuleStmt = 127, RuleBlocky_expr = 128, 
    RuleIf_cond_or_pat = 129, RuleWhile_cond_or_pat = 130, RuleLoop_label = 131, 
    RuleMatch_arms = 132, RuleMatch_arm_intro = 133, RuleMatch_pattern = 134, 
    RuleMatch_if_clause = 135, RuleExpr_attrs = 136, RuleExpr_inner_attrs = 137, 
    RulePrim_expr = 138, RulePrim_expr_no_struct = 139, RuleLit = 140, RuleClosure_params = 141, 
    RuleClosure_param = 142, RuleClosure_param_list = 143, RuleClosure_tail = 144, 
    RuleLifetime_or_expr = 145, RuleFields = 146, RuleStruct_update_base = 147, 
    RuleField = 148, RuleField_name = 149, RulePre_expr = 150, RuleCmp_expr = 151, 
    RuleRange_expr = 152, RuleAssign_expr = 153, RulePre_expr_no_struct = 154, 
    RuleCmp_expr_no_struct = 155, RuleRange_expr_no_struct = 156, RuleAssign_expr_no_struct = 157, 
    RuleIdent = 158, RuleAny_ident = 159, RuleTokens_no_delimiters_cash = 160, 
    RuleTokens_no_delimiters_repetition_operators = 161, RuleMacro_rules_definition = 162, 
    RuleMacro_rules_def = 163, RuleMacro_rules = 164, RuleMacro_rule = 165, 
    RuleMacro_matcher = 166, RuleMacro_match = 167, RuleMacro_rep_sep = 168, 
    RuleMacro_rep_op = 169, RuleMacro_transcriber = 170, RuleDelim_token_tree = 171, 
    RuleMacro_invocation_semi = 172, RuleMacro_invocation = 173, RuleLifetime = 174, 
    RuleKleene_star__mod_body_1 = 175, RuleKleene_star__mod_body_2 = 176, 
    RuleOptional__visibility_1 = 177, RuleKleene_star__item_1 = 178, RuleOptional__item_2 = 179, 
    RuleOptional__extern_crate_1 = 180, RuleOptional__use_path_2 = 181, 
    RuleAux_rule__use_path_4 = 182, RuleKleene_star__use_path_5 = 183, RuleOptional__use_path_6 = 184, 
    RuleAux_rule__use_item_list_1 = 185, RuleKleene_star__use_item_list_2 = 186, 
    RuleOptional__use_item_list_3 = 187, RuleKleene_star__extern_mod_2 = 188, 
    RuleAux_rule__foreign_item_tail_2 = 189, RuleOptional__foreign_item_tail_3 = 190, 
    RuleOptional__static_decl_1 = 191, RuleAux_rule__associated_const_decl_1 = 192, 
    RuleOptional__associated_const_decl_2 = 193, RuleOptional__fn_decl_1 = 194, 
    RuleOptional__fn_decl_2 = 195, RuleOptional__method_decl_1 = 196, RuleOptional__trait_method_decl_1 = 197, 
    RuleOptional__foreign_fn_decl_1 = 198, RuleOptional__foreign_fn_decl_2 = 199, 
    RuleAux_rule__macro_decl_2 = 200, RuleOptional__macro_decl_3 = 201, 
    RuleOptional__macro_head_1 = 202, RuleAux_rule__fn_head_1 = 203, RuleKleene_star__fn_head_2 = 204, 
    RuleOptional__fn_head_3 = 205, RuleAux_rule__param_3 = 206, RuleOptional__param_4 = 207, 
    RuleOptional__param_6 = 208, RuleAux_rule__param_list_1 = 209, RuleKleene_star__param_list_2 = 210, 
    RuleAux_rule__param_list_4 = 211, RuleOptional__param_list_5 = 212, 
    RuleAux_rule__variadic_param_list_4 = 213, RuleOptional__variadic_param_list_5 = 214, 
    RuleAux_rule__trait_method_param_2 = 215, RuleKleene_star__trait_method_param_3 = 216, 
    RuleOptional__restricted_pat_1 = 217, RuleAux_rule__restricted_pat_2 = 218, 
    RuleOptional__restricted_pat_3 = 219, RuleAux_rule__trait_method_param_list_2 = 220, 
    RuleKleene_star__trait_method_param_list_3 = 221, RuleOptional__type_decl_4 = 222, 
    RuleAux_rule__type_decl_6 = 223, RuleOptional__type_decl_7 = 224, RuleAux_rule__type_decl_8 = 225, 
    RuleOptional__type_decl_9 = 226, RuleOptional__struct_tail_2 = 227, 
    RuleOptional__struct_tail_5 = 228, RuleAux_rule__tuple_struct_field_list_1 = 229, 
    RuleKleene_star__tuple_struct_field_list_2 = 230, RuleAux_rule__field_decl_list_1 = 231, 
    RuleKleene_star__field_decl_list_2 = 232, RuleOptional__enum_decl_3 = 233, 
    RuleAux_rule__enum_variant_3 = 234, RuleOptional__enum_variant_4 = 235, 
    RuleAux_rule__enum_variant_list_1 = 236, RuleKleene_star__enum_variant_list_2 = 237, 
    RuleOptional__enum_variant_main_1 = 238, RuleAux_rule__enum_tuple_field_list_1 = 239, 
    RuleKleene_star__enum_tuple_field_list_2 = 240, RuleOptional__trait_decl_2 = 241, 
    RuleKleene_star__trait_decl_7 = 242, RuleOptional__impl_block_1 = 243, 
    RuleOptional__impl_block_2 = 244, RuleOptional__impl_block_3 = 245, 
    RuleOptional__impl_block_4 = 246, RuleOptional__impl_block_5 = 247, 
    RuleOptional__impl_block_6 = 248, RuleKleene_star__impl_block_7 = 249, 
    RuleAux_rule__impl_item_1 = 250, RuleKleene_star__impl_item_2 = 251, 
    RuleAux_rule__impl_item_tail_11 = 252, RuleOptional__impl_item_tail_12 = 253, 
    RuleKleene_star__inner_attr_1 = 254, RuleOptional__path_1 = 255, RuleOptional__path_parent_1 = 256, 
    RuleAux_rule__path_segment_no_super_1 = 257, RuleOptional__path_segment_no_super_2 = 258, 
    RuleOptional__simple_path_1 = 259, RuleAux_rule__simple_path_2 = 260, 
    RuleKleene_star__simple_path_3 = 261, RuleOptional__for_lifetimes_1 = 262, 
    RuleAux_rule__lifetime_def_list_1 = 263, RuleKleene_star__lifetime_def_list_2 = 264, 
    RuleAux_rule__lifetime_def_1 = 265, RuleOptional__lifetime_def_2 = 266, 
    RuleOptional__type_path_main_1 = 267, RuleOptional__ty_path_tail_1 = 268, 
    RuleOptional__ty_path_segment_no_super_2 = 269, RuleOptional__ty_path_segment_no_super_3 = 270, 
    RuleAux_rule__where_bound_list_1 = 271, RuleKleene_star__where_bound_list_2 = 272, 
    RuleOptional__where_bound_1 = 273, RuleOptional__where_bound_2 = 274, 
    RuleOptional__empty_ok_colon_bound_1 = 275, RuleAux_rule__prim_bound_3 = 276, 
    RuleOptional__prim_bound_4 = 277, RuleAux_rule__prim_bound_5 = 278, 
    RuleOptional__type_1 = 279, RuleAux_rule__array_or_slice_type_1 = 280, 
    RuleOptional__array_or_slice_type_2 = 281, RuleAux_rule__type_param_bounds_1 = 282, 
    RuleKleene_star__type_param_bounds_2 = 283, RuleOptional__type_param_bounds_3 = 284, 
    RuleOptional__trait_object_type_2 = 285, RuleOptional__bare_function_type_4 = 286, 
    RuleOptional__extern_abi_1 = 287, RuleAux_rule__type_arguments_1 = 288, 
    RuleKleene_star__type_arguments_2 = 289, RuleAux_rule__type_arguments_4 = 290, 
    RuleKleene_star__type_arguments_5 = 291, RuleAux_rule__type_arguments_6 = 292, 
    RuleKleene_star__type_arguments_7 = 293, RuleOptional__ty_sum_1 = 294, 
    RuleAux_rule__ty_sum_2 = 295, RuleOptional__ty_sum_3 = 296, RuleAux_rule__ty_sum_list_1 = 297, 
    RuleKleene_star__ty_sum_list_2 = 298, RuleAux_rule__type_parameters_1 = 299, 
    RuleKleene_star__type_parameters_2 = 300, RuleOptional__type_parameters_3 = 301, 
    RuleAux_rule__lifetime_param_list_1 = 302, RuleKleene_star__lifetime_param_list_2 = 303, 
    RuleOptional__type_parameter_4 = 304, RuleAux_rule__type_parameter_list_1 = 305, 
    RuleKleene_star__type_parameter_list_2 = 306, RuleAux_rule__pattern_1 = 307, 
    RuleOptional__pattern_2 = 308, RuleOptional__pattern_without_mut_1 = 309, 
    RuleAux_rule__pattern_without_mut_2 = 310, RuleOptional__pattern_without_mut_3 = 311, 
    RuleAux_rule__pattern_without_mut_4 = 312, RuleKleene_star__pattern_without_mut_5 = 313, 
    RuleOptional__pattern_without_mut_12 = 314, RuleOptional__pattern_without_mut_13 = 315, 
    RuleAux_rule__pattern_without_mut_15 = 316, RuleKleene_star__pattern_without_mut_16 = 317, 
    RuleOptional__pat_lit_1 = 318, RuleOptional__pat_list_with_dots_3 = 319, 
    RuleAux_rule__pat_list_with_dots_4 = 320, RuleOptional__pat_list_with_dots_5 = 321, 
    RuleAux_rule__pat_list_dots_tail_1 = 322, RuleOptional__pat_list_dots_tail_2 = 323, 
    RuleAux_rule__pat_fields_1 = 324, RuleKleene_star__pat_fields_2 = 325, 
    RuleAux_rule__pat_fields_3 = 326, RuleKleene_star__pat_fields_4 = 327, 
    RuleOptional__pat_field_2 = 328, RuleOptional__expr_1 = 329, RuleOptional__expr_2 = 330, 
    RuleAux_rule__expr_list_1 = 331, RuleKleene_star__expr_list_2 = 332, 
    RuleKleene_star__block_with_inner_attrs_2 = 333, RuleOptional__block_with_inner_attrs_3 = 334, 
    RuleAux_rule__blocky_expr_1 = 335, RuleKleene_star__blocky_expr_2 = 336, 
    RuleAux_rule__blocky_expr_3 = 337, RuleOptional__blocky_expr_4 = 338, 
    RuleOptional__blocky_expr_5 = 339, RuleOptional__blocky_expr_6 = 340, 
    RuleOptional__blocky_expr_7 = 341, RuleAux_rule__match_arms_4 = 342, 
    RuleOptional__match_arms_5 = 343, RuleOptional__match_arm_intro_2 = 344, 
    RuleAux_rule__match_pattern_2 = 345, RuleKleene_star__match_pattern_3 = 346, 
    RuleOptional__prim_expr_1 = 347, RuleOptional__prim_expr_2 = 348, RuleOptional__prim_expr_no_struct_1 = 349, 
    RuleOptional__prim_expr_no_struct_5 = 350, RuleOptional__prim_expr_no_struct_9 = 351, 
    RuleOptional__prim_expr_no_struct_10 = 352, RuleOptional__prim_expr_no_struct_11 = 353, 
    RuleOptional__prim_expr_no_struct_12 = 354, RuleOptional__prim_expr_no_struct_13 = 355, 
    RuleOptional__closure_params_1 = 356, RuleAux_rule__closure_param_list_1 = 357, 
    RuleKleene_star__closure_param_list_2 = 358, RuleAux_rule__fields_1 = 359, 
    RuleKleene_star__fields_2 = 360, RuleKleene_star__field_1 = 361, RuleAux_rule__post_expr_tail_4 = 362, 
    RuleOptional__post_expr_tail_5 = 363, RuleOptional__range_expr_1 = 364, 
    RuleOptional__range_expr_no_struct_1 = 365, RuleOptional__macro_rules_def_1 = 366, 
    RuleAux_rule__macro_rules_1 = 367, RuleKleene_star__macro_rules_2 = 368, 
    RuleOptional__macro_rules_3 = 369, RuleKleene_star__macro_matcher_1 = 370, 
    RuleKleene_plus__macro_match_1 = 371, RuleOptional__macro_match_2 = 372, 
    RuleAux_rule__bound_4 = 373, RuleKleene_star__bound_3 = 374, RuleBound = 375, 
    RuleAux_rule__path_parent_3 = 376, RuleKleene_star__path_parent_2 = 377, 
    RuleAux_rule__path_parent_4 = 378, RulePath_parent = 379, RuleAux_rule__lifetime_bound_2 = 380, 
    RuleKleene_star__lifetime_bound_1 = 381, RuleLifetime_bound = 382, RuleAux_rule__ty_path_parent_3 = 383, 
    RuleKleene_star__ty_path_parent_2 = 384, RuleAux_rule__ty_path_parent_4 = 385, 
    RuleTy_path_parent = 386, RuleAux_rule__pattern_without_mut_19 = 387, 
    RuleKleene_star__pattern_without_mut_18 = 388, RuleAux_rule__pattern_without_mut_20 = 389, 
    RulePattern_without_mut = 390, RuleKleene_star__post_expr_1 = 391, RulePost_expr = 392, 
    RuleAux_rule__cast_expr_2 = 393, RuleKleene_star__cast_expr_1 = 394, 
    RuleCast_expr = 395, RuleAux_rule__mul_expr_2 = 396, RuleKleene_star__mul_expr_1 = 397, 
    RuleMul_expr = 398, RuleAux_rule__add_expr_2 = 399, RuleKleene_star__add_expr_1 = 400, 
    RuleAdd_expr = 401, RuleAux_rule__shift_expr_2 = 402, RuleKleene_star__shift_expr_1 = 403, 
    RuleShift_expr = 404, RuleAux_rule__bit_and_expr_2 = 405, RuleKleene_star__bit_and_expr_1 = 406, 
    RuleBit_and_expr = 407, RuleAux_rule__bit_xor_expr_2 = 408, RuleKleene_star__bit_xor_expr_1 = 409, 
    RuleBit_xor_expr = 410, RuleAux_rule__bit_or_expr_2 = 411, RuleKleene_star__bit_or_expr_1 = 412, 
    RuleBit_or_expr = 413, RuleAux_rule__and_expr_2 = 414, RuleKleene_star__and_expr_1 = 415, 
    RuleAnd_expr = 416, RuleAux_rule__or_expr_2 = 417, RuleKleene_star__or_expr_1 = 418, 
    RuleOr_expr = 419, RulePost_expr_no_struct = 420, RuleCast_expr_no_struct = 421, 
    RuleAux_rule__mul_expr_no_struct_2 = 422, RuleKleene_star__mul_expr_no_struct_1 = 423, 
    RuleMul_expr_no_struct = 424, RuleAux_rule__add_expr_no_struct_2 = 425, 
    RuleKleene_star__add_expr_no_struct_1 = 426, RuleAdd_expr_no_struct = 427, 
    RuleAux_rule__shift_expr_no_struct_2 = 428, RuleKleene_star__shift_expr_no_struct_1 = 429, 
    RuleShift_expr_no_struct = 430, RuleAux_rule__bit_and_expr_no_struct_2 = 431, 
    RuleKleene_star__bit_and_expr_no_struct_1 = 432, RuleBit_and_expr_no_struct = 433, 
    RuleAux_rule__bit_xor_expr_no_struct_2 = 434, RuleKleene_star__bit_xor_expr_no_struct_1 = 435, 
    RuleBit_xor_expr_no_struct = 436, RuleAux_rule__bit_or_expr_no_struct_2 = 437, 
    RuleKleene_star__bit_or_expr_no_struct_1 = 438, RuleBit_or_expr_no_struct = 439, 
    RuleAux_rule__and_expr_no_struct_2 = 440, RuleKleene_star__and_expr_no_struct_1 = 441, 
    RuleAnd_expr_no_struct = 442, RuleAux_rule__or_expr_no_struct_2 = 443, 
    RuleKleene_star__or_expr_no_struct_1 = 444, RuleOr_expr_no_struct = 445, 
    RuleKleene_plus__expr_attrs_2 = 446, RuleKleene_plus__expr_inner_attrs_2 = 447, 
    RuleAux_rule__enum_variant_main_3 = 448, RuleOptional__enum_variant_main_4 = 449, 
    RuleAux_rule__impl_what_1 = 450, RuleOptional__impl_what_2 = 451, RuleAux_rule__path_2 = 452, 
    RuleOptional__path_3 = 453, RuleAux_rule__type_path_main_2 = 454, RuleOptional__type_path_main_3 = 455, 
    RuleAux_rule__tuple_type_2 = 456, RuleOptional__tuple_type_3 = 457, 
    RuleAux_rule__type_argument_1 = 458, RuleOptional__type_argument_2 = 459, 
    RuleAux_rule__pattern_without_mut_21 = 460, RuleOptional__pattern_without_mut_22 = 461, 
    RuleAux_rule__pattern_without_mut_23 = 462, RuleOptional__pattern_without_mut_24 = 463, 
    RuleAux_rule__assign_expr_1 = 464, RuleOptional__assign_expr_2 = 465, 
    RuleAux_rule__assign_expr_no_struct_1 = 466, RuleOptional__assign_expr_no_struct_2 = 467, 
    RuleOptional__blocky_expr_11 = 468, RuleOptional__closure_params_2 = 469, 
    RuleAux_rule__cmp_expr_1 = 470, RuleOptional__cmp_expr_2 = 471, RuleAux_rule__range_expr_5 = 472, 
    RuleOptional__range_expr_6 = 473, RuleAux_rule__cmp_expr_no_struct_5 = 474, 
    RuleOptional__cmp_expr_no_struct_6 = 475, RuleAux_rule__range_expr_no_struct_5 = 476, 
    RuleOptional__range_expr_no_struct_6 = 477, RuleAltnt_block__visibility_restriction_1 = 478, 
    RuleAltnt_block__type_decl_10 = 479, RuleAltnt_block__use_suffix_2 = 480, 
    RuleAltnt_block__foreign_item_tail_11 = 481, RuleAltnt_block__macro_invocation_semi_4 = 482, 
    RuleAltnt_block__type_parameters_4 = 483, RuleAltnt_block__trait_method_param_6 = 484, 
    RuleAltnt_block__struct_tail_6 = 485, RuleAltnt_block__enum_variant_main_5 = 486, 
    RuleAltnt_block__trait_item_19 = 487, RuleAltnt_block__impl_what_3 = 488, 
    RuleAltnt_block__type_arguments_9 = 489, RuleAltnt_block__impl_item_tail_13 = 490, 
    RuleAltnt_block__pattern_without_mut_25 = 491, RuleAltnt_block__pattern_without_mut_26 = 492, 
    RuleAltnt_block__pattern_without_mut_27 = 493, RuleAltnt_block__pattern_without_mut_28 = 494, 
    RuleAltnt_block__pattern_without_mut_29 = 495, RuleAltnt_block__pat_fields_6 = 496, 
    RuleAltnt_block__stmt_8 = 497, RuleAltnt_block__blocky_expr_12 = 498, 
    RuleAltnt_block__if_cond_or_pat_1 = 499, RuleAltnt_block__match_arms_6 = 500, 
    RuleAltnt_block__prim_expr_no_struct_18 = 501, RuleAltnt_block__prim_expr_no_struct_19 = 502, 
    RuleAltnt_block__post_expr_tail_7 = 503, RuleAltnt_block__pre_expr_3 = 504, 
    RuleAltnt_block__cast_expr_3 = 505, RuleAltnt_block__mul_expr_3 = 506, 
    RuleAltnt_block__add_expr_3 = 507, RuleAltnt_block__shift_expr_3 = 508, 
    RuleAltnt_block__range_expr_7 = 509, RuleAltnt_block__range_expr_no_struct_7 = 510, 
    RuleAltnt_block__macro_rules_def_4 = 511, RuleAltnt_block__macro_match_3 = 512, 
    RuleAltnt_block__macro_invocation_semi_5 = 513, RuleType = 514, RuleAltnt_block__extern_crate_2 = 515, 
    RuleAltnt_block__use_path_7 = 516, RuleAltnt_block__use_item_2 = 517, 
    RuleAltnt_block__const_decl_2 = 518, RuleAltnt_block__fn_decl_4 = 519, 
    RuleAltnt_block__method_param_list_4 = 520, RuleAltnt_block__restricted_pat_4 = 521, 
    RuleAltnt_block__trait_method_param_list_5 = 522, RuleAltnt_block__fn_rtype_1 = 523, 
    RuleAltnt_block__trait_alias_3 = 524, RuleAltnt_block__trait_item_20 = 525, 
    RuleAltnt_block__ty_path_tail_3 = 526, RuleAltnt_block__pat_fields_7 = 527, 
    RuleAltnt_block__prim_expr_no_struct_20 = 528, RuleAltnt_block__fields_4 = 529, 
    RuleAltnt_block__type_arguments_10 = 530, RuleAltnt_block__assign_expr_3 = 531, 
    RuleAltnt_block__assign_expr_no_struct_3 = 532, RuleAltnt_block__cmp_expr_3 = 533, 
    RuleAltnt_block__cmp_expr_no_struct_7 = 534, RuleAltnt_block__trait_method_param_7 = 535, 
    RuleAux_rule__trait_method_param_8 = 536, RuleOptional__trait_method_param_9 = 537, 
    RuleAux_rule__struct_tail_7 = 538, RuleOptional__struct_tail_8 = 539, 
    RuleAux_rule__assign_expr_no_struct_4 = 540, RuleOptional__assign_expr_no_struct_5 = 541, 
    RuleAux_rule__blocky_expr_13 = 542, RuleOptional__blocky_expr_14 = 543, 
    RuleOptional__cmp_expr_no_struct_8 = 544, RuleAltnt_block__type_decl_11 = 545, 
    RuleAltnt_block__use_path_8 = 546, RuleAltnt_block__foreign_item_4 = 547, 
    RuleAltnt_block__param_12 = 548, RuleAltnt_block__trait_item_21 = 549, 
    RuleAltnt_block__trait_item_22 = 550, RuleAltnt_block__type_arguments_11 = 551, 
    RuleAltnt_block__pattern_without_mut_31 = 552, RuleAltnt_block__pat_field_6 = 553, 
    RuleAltnt_block__blocky_expr_15 = 554, RuleAltnt_block__prim_expr_no_struct_22 = 555, 
    RuleAltnt_block__prim_expr_no_struct_23 = 556, RuleAltnt_block__prim_expr_no_struct_24 = 557, 
    RuleAltnt_block__range_expr_8 = 558, RuleAltnt_block__item_7 = 559, 
    RuleAltnt_block__param_11 = 560, RuleAltnt_block__ty_path_segment_no_super_6 = 561, 
    RuleAux_rule__post_expr_2 = 562, RuleAux_rule__visibility_2 = 563, RuleAux_rule__use_suffix_3 = 564, 
    RuleAux_rule__foreign_item_tail_12 = 565, RuleAux_rule__param_13 = 566, 
    RuleAux_rule__self_param_6 = 567, RuleAux_rule__self_param_7 = 568, 
    RuleAux_rule__trait_method_param_10 = 569, RuleAux_rule__struct_tail_9 = 570, 
    RuleAux_rule__struct_tail_10 = 571, RuleAux_rule__trait_item_23 = 572, 
    RuleAux_rule__trait_item_24 = 573, RuleAux_rule__trait_item_25 = 574, 
    RuleAux_rule__impl_what_4 = 575, RuleAux_rule__impl_what_5 = 576, RuleAux_rule__impl_what_6 = 577, 
    RuleAux_rule__impl_item_tail_14 = 578, RuleAux_rule__impl_item_tail_15 = 579, 
    RuleAux_rule__tt_1 = 580, RuleAux_rule__ty_path_tail_4 = 581, RuleAux_rule__where_bound_3 = 582, 
    RuleAux_rule__where_bound_4 = 583, RuleAux_rule__trait_bound_5 = 584, 
    RuleAux_rule__trait_bound_6 = 585, RuleAux_rule__type_argument_3 = 586, 
    RuleAux_rule__type_parameter_5 = 587, RuleAux_rule__pattern_3 = 588, 
    RuleAux_rule__pat_ident_1 = 589, RuleAux_rule__pat_list_with_dots_6 = 590, 
    RuleAux_rule__pat_fields_8 = 591, RuleAux_rule__pat_fields_9 = 592, 
    RuleAux_rule__stmt_9 = 593, RuleAux_rule__stmt_10 = 594, RuleAux_rule__blocky_expr_16 = 595, 
    RuleAux_rule__blocky_expr_17 = 596, RuleAux_rule__blocky_expr_18 = 597, 
    RuleAux_rule__prim_expr_3 = 598, RuleAux_rule__prim_expr_no_struct_25 = 599, 
    RuleAux_rule__prim_expr_no_struct_26 = 600, RuleAux_rule__prim_expr_no_struct_27 = 601, 
    RuleAux_rule__prim_expr_no_struct_28 = 602, RuleAux_rule__prim_expr_no_struct_29 = 603, 
    RuleAux_rule__prim_expr_no_struct_30 = 604, RuleAux_rule__prim_expr_no_struct_31 = 605, 
    RuleAux_rule__closure_params_3 = 606, RuleAux_rule__closure_tail_2 = 607, 
    RuleAux_rule__fields_5 = 608, RuleAux_rule__field_2 = 609, RuleAux_rule__pre_expr_5 = 610, 
    RuleAux_rule__pre_expr_6 = 611, RuleAux_rule__range_expr_9 = 612, RuleAux_rule__range_expr_10 = 613, 
    RuleAux_rule__pre_expr_no_struct_4 = 614, RuleAux_rule__range_expr_no_struct_9 = 615, 
    RuleAux_rule__range_expr_no_struct_10 = 616, RuleAux_rule__macro_rules_def_5 = 617, 
    RuleAux_rule__macro_rules_def_6 = 618, RuleAux_rule__macro_matcher_4 = 619, 
    RuleAux_rule__macro_matcher_5 = 620, RuleAux_rule__macro_matcher_6 = 621, 
    RuleAux_rule__macro_match_4 = 622, RuleAux_rule__delim_token_tree_4 = 623, 
    RuleAux_rule__delim_token_tree_5 = 624, RuleAux_rule__delim_token_tree_6 = 625, 
    RuleAux_rule__prim_bound_6 = 626, RuleAux_rule__bound_5 = 627, RuleAux_rule__bound_6 = 628, 
    RuleAux_rule__path_parent_6 = 629, RuleAux_rule__path_parent_7 = 630, 
    RuleAux_rule__ty_path_parent_6 = 631, RuleAux_rule__ty_path_parent_7 = 632, 
    RuleAux_rule__pattern_without_mut_32 = 633, RuleAux_rule__pattern_without_mut_33 = 634, 
    RuleAux_rule__pattern_without_mut_34 = 635, RuleAux_rule__pattern_without_mut_35 = 636, 
    RuleAux_rule__pattern_without_mut_36 = 637, RuleAux_rule__pattern_without_mut_37 = 638, 
    RuleAux_rule__pattern_without_mut_38 = 639, RuleAux_rule__pattern_without_mut_39 = 640, 
    RuleAux_rule__pattern_without_mut_40 = 641, RuleAux_rule__visibility_restriction_2 = 642, 
    RuleAux_rule__use_suffix_4 = 643, RuleAux_rule__foreign_item_tail_13 = 644, 
    RuleAux_rule__foreign_item_tail_14 = 645, RuleAux_rule__macro_invocation_semi_6 = 646, 
    RuleAux_rule__macro_invocation_semi_7 = 647, RuleAux_rule__type_parameters_5 = 648, 
    RuleAux_rule__enum_variant_main_6 = 649, RuleAux_rule__enum_variant_main_7 = 650, 
    RuleAux_rule__impl_item_tail_16 = 651, RuleAux_rule__impl_item_tail_17 = 652, 
    RuleAux_rule__pattern_without_mut_41 = 653, RuleAux_rule__pattern_without_mut_42 = 654, 
    RuleAux_rule__pattern_without_mut_43 = 655, RuleAux_rule__pat_fields_10 = 656, 
    RuleAux_rule__stmt_11 = 657, RuleAux_rule__blocky_expr_19 = 658, RuleAux_rule__if_cond_or_pat_2 = 659, 
    RuleAux_rule__match_arms_7 = 660, RuleAux_rule__match_arms_8 = 661, 
    RuleAux_rule__post_expr_tail_8 = 662, RuleAux_rule__pre_expr_7 = 663, 
    RuleAux_rule__shift_expr_4 = 664, RuleAux_rule__shift_expr_5 = 665, 
    RuleAux_rule__range_expr_11 = 666, RuleAux_rule__range_expr_no_struct_11 = 667, 
    RuleAux_rule__macro_rules_def_7 = 668, RuleAux_rule__macro_rules_def_8 = 669, 
    RuleAux_rule__macro_match_5 = 670, RuleAux_rule__macro_match_6 = 671, 
    RuleAux_rule__macro_invocation_semi_8 = 672, RuleAux_rule__macro_invocation_semi_9 = 673, 
    RuleAux_rule__type_3 = 674, RuleAux_rule__type_4 = 675, RuleAux_rule__type_5 = 676, 
    RuleAux_rule__fn_rtype_2 = 677, RuleAux_rule__trait_alias_4 = 678, RuleAux_rule__pat_fields_11 = 679, 
    RuleAux_rule__prim_expr_no_struct_32 = 680, RuleAux_rule__fields_6 = 681, 
    RuleAux_rule__assign_expr_no_struct_6 = 682, RuleAux_rule__cmp_expr_no_struct_9 = 683, 
    RuleAux_rule__trait_method_param_11 = 684, RuleAux_rule__type_decl_12 = 685, 
    RuleAux_rule__type_decl_13 = 686, RuleAux_rule__use_path_9 = 687, RuleAux_rule__use_path_10 = 688, 
    RuleAux_rule__foreign_item_5 = 689, RuleAux_rule__param_14 = 690, RuleAux_rule__param_15 = 691, 
    RuleAux_rule__trait_item_26 = 692, RuleAux_rule__trait_item_27 = 693, 
    RuleAux_rule__type_arguments_12 = 694, RuleAux_rule__type_arguments_13 = 695, 
    RuleAux_rule__pattern_without_mut_44 = 696, RuleAux_rule__pattern_without_mut_45 = 697, 
    RuleAux_rule__pat_field_7 = 698, RuleAux_rule__pat_field_8 = 699, RuleAux_rule__prim_expr_no_struct_33 = 700, 
    RuleAux_rule__prim_expr_no_struct_34 = 701, RuleAux_rule__prim_expr_no_struct_35 = 702, 
    RuleAux_rule__item_8 = 703, RuleAux_rule__param_16 = 704, RuleAux_rule__ty_path_segment_no_super_7 = 705, 
    RuleAux_rule__post_expr_3 = 706, RuleAux_rule__post_expr_4 = 707, RuleAux_rule__post_expr_5 = 708
  };

  PnfRustParser(antlr4::TokenStream *input);
  ~PnfRustParser();

  virtual std::string getGrammarFileName() const override;
  virtual const antlr4::atn::ATN& getATN() const override { return _atn; };
  virtual const std::vector<std::string>& getTokenNames() const override { return _tokenNames; }; // deprecated: use vocabulary instead.
  virtual const std::vector<std::string>& getRuleNames() const override;
  virtual antlr4::dfa::Vocabulary& getVocabulary() const override;


  class CrateContext;
  class Mod_bodyContext;
  class VisibilityContext;
  class Visibility_restrictionContext;
  class ItemContext;
  class Pub_itemContext;
  class Extern_crateContext;
  class Use_declContext;
  class Use_pathContext;
  class Use_suffixContext;
  class Use_itemContext;
  class Use_item_listContext;
  class RenameContext;
  class Mod_decl_shortContext;
  class Mod_declContext;
  class Extern_modContext;
  class Foreign_itemContext;
  class Foreign_item_tailContext;
  class Static_declContext;
  class Associated_static_declContext;
  class Const_declContext;
  class Associated_const_declContext;
  class Fn_declContext;
  class Method_declContext;
  class Trait_method_declContext;
  class Foreign_fn_declContext;
  class Macro_declContext;
  class Macro_headContext;
  class Fn_headContext;
  class ParamContext;
  class Param_listContext;
  class Variadic_param_listContext;
  class Variadic_param_list_names_optionalContext;
  class Self_paramContext;
  class Method_param_listContext;
  class Trait_method_paramContext;
  class Restricted_patContext;
  class Trait_method_param_listContext;
  class RtypeContext;
  class Fn_rtypeContext;
  class Type_declContext;
  class Struct_declContext;
  class Struct_tailContext;
  class Tuple_struct_fieldContext;
  class Tuple_struct_field_listContext;
  class Field_declContext;
  class Field_decl_listContext;
  class Enum_declContext;
  class Enum_variantContext;
  class Enum_variant_listContext;
  class Enum_variant_mainContext;
  class Enum_tuple_fieldContext;
  class Enum_tuple_field_listContext;
  class Union_declContext;
  class Trait_declContext;
  class Trait_aliasContext;
  class Trait_itemContext;
  class Ty_defaultContext;
  class Impl_blockContext;
  class Impl_whatContext;
  class Impl_itemContext;
  class Impl_item_tailContext;
  class AttrContext;
  class Inner_attrContext;
  class TtContext;
  class Tt_delimitedContext;
  class Tt_bracketsContext;
  class Tt_blockContext;
  class Macro_tailContext;
  class PathContext;
  class As_traitContext;
  class Path_segmentContext;
  class Path_segment_no_superContext;
  class Simple_pathContext;
  class Simple_path_segmentContext;
  class For_lifetimesContext;
  class Lifetime_def_listContext;
  class Lifetime_defContext;
  class Type_path_mainContext;
  class Ty_path_tailContext;
  class Type_path_segmentContext;
  class Ty_path_segment_no_superContext;
  class Where_clauseContext;
  class Where_bound_listContext;
  class Where_boundContext;
  class Empty_ok_colon_boundContext;
  class Colon_boundContext;
  class Prim_boundContext;
  class Inferred_typeContext;
  class Array_or_slice_typeContext;
  class Reference_typeContext;
  class Raw_pointer_typeContext;
  class Never_typeContext;
  class Tuple_typeContext;
  class Impl_trait_typeContext;
  class Impl_trait_type_one_boundContext;
  class Trait_object_type_one_boundContext;
  class Type_param_boundsContext;
  class Type_param_boundContext;
  class Trait_object_typeContext;
  class Trait_boundContext;
  class Bare_function_typeContext;
  class Mut_or_constContext;
  class Extern_abiContext;
  class Type_argumentsContext;
  class Type_argumentContext;
  class Ty_sumContext;
  class Ty_sum_listContext;
  class Type_parametersContext;
  class Lifetime_paramContext;
  class Lifetime_param_listContext;
  class Type_parameterContext;
  class Type_parameter_listContext;
  class PatternContext;
  class Pat_identContext;
  class Pat_range_endContext;
  class Pat_litContext;
  class Pat_list_with_dotsContext;
  class Pat_list_dots_tailContext;
  class Pat_fields_leftContext;
  class Pat_fieldsContext;
  class Pat_fieldContext;
  class ExprContext;
  class Expr_no_structContext;
  class Expr_listContext;
  class BlockContext;
  class Block_with_inner_attrsContext;
  class StmtContext;
  class Blocky_exprContext;
  class If_cond_or_patContext;
  class While_cond_or_patContext;
  class Loop_labelContext;
  class Match_armsContext;
  class Match_arm_introContext;
  class Match_patternContext;
  class Match_if_clauseContext;
  class Expr_attrsContext;
  class Expr_inner_attrsContext;
  class Prim_exprContext;
  class Prim_expr_no_structContext;
  class LitContext;
  class Closure_paramsContext;
  class Closure_paramContext;
  class Closure_param_listContext;
  class Closure_tailContext;
  class Lifetime_or_exprContext;
  class FieldsContext;
  class Struct_update_baseContext;
  class FieldContext;
  class Field_nameContext;
  class Pre_exprContext;
  class Cmp_exprContext;
  class Range_exprContext;
  class Assign_exprContext;
  class Pre_expr_no_structContext;
  class Cmp_expr_no_structContext;
  class Range_expr_no_structContext;
  class Assign_expr_no_structContext;
  class IdentContext;
  class Any_identContext;
  class Tokens_no_delimiters_cashContext;
  class Tokens_no_delimiters_repetition_operatorsContext;
  class Macro_rules_definitionContext;
  class Macro_rules_defContext;
  class Macro_rulesContext;
  class Macro_ruleContext;
  class Macro_matcherContext;
  class Macro_matchContext;
  class Macro_rep_sepContext;
  class Macro_rep_opContext;
  class Macro_transcriberContext;
  class Delim_token_treeContext;
  class Macro_invocation_semiContext;
  class Macro_invocationContext;
  class LifetimeContext;
  class Kleene_star__mod_body_1Context;
  class Kleene_star__mod_body_2Context;
  class Optional__visibility_1Context;
  class Kleene_star__item_1Context;
  class Optional__item_2Context;
  class Optional__extern_crate_1Context;
  class Optional__use_path_2Context;
  class Aux_rule__use_path_4Context;
  class Kleene_star__use_path_5Context;
  class Optional__use_path_6Context;
  class Aux_rule__use_item_list_1Context;
  class Kleene_star__use_item_list_2Context;
  class Optional__use_item_list_3Context;
  class Kleene_star__extern_mod_2Context;
  class Aux_rule__foreign_item_tail_2Context;
  class Optional__foreign_item_tail_3Context;
  class Optional__static_decl_1Context;
  class Aux_rule__associated_const_decl_1Context;
  class Optional__associated_const_decl_2Context;
  class Optional__fn_decl_1Context;
  class Optional__fn_decl_2Context;
  class Optional__method_decl_1Context;
  class Optional__trait_method_decl_1Context;
  class Optional__foreign_fn_decl_1Context;
  class Optional__foreign_fn_decl_2Context;
  class Aux_rule__macro_decl_2Context;
  class Optional__macro_decl_3Context;
  class Optional__macro_head_1Context;
  class Aux_rule__fn_head_1Context;
  class Kleene_star__fn_head_2Context;
  class Optional__fn_head_3Context;
  class Aux_rule__param_3Context;
  class Optional__param_4Context;
  class Optional__param_6Context;
  class Aux_rule__param_list_1Context;
  class Kleene_star__param_list_2Context;
  class Aux_rule__param_list_4Context;
  class Optional__param_list_5Context;
  class Aux_rule__variadic_param_list_4Context;
  class Optional__variadic_param_list_5Context;
  class Aux_rule__trait_method_param_2Context;
  class Kleene_star__trait_method_param_3Context;
  class Optional__restricted_pat_1Context;
  class Aux_rule__restricted_pat_2Context;
  class Optional__restricted_pat_3Context;
  class Aux_rule__trait_method_param_list_2Context;
  class Kleene_star__trait_method_param_list_3Context;
  class Optional__type_decl_4Context;
  class Aux_rule__type_decl_6Context;
  class Optional__type_decl_7Context;
  class Aux_rule__type_decl_8Context;
  class Optional__type_decl_9Context;
  class Optional__struct_tail_2Context;
  class Optional__struct_tail_5Context;
  class Aux_rule__tuple_struct_field_list_1Context;
  class Kleene_star__tuple_struct_field_list_2Context;
  class Aux_rule__field_decl_list_1Context;
  class Kleene_star__field_decl_list_2Context;
  class Optional__enum_decl_3Context;
  class Aux_rule__enum_variant_3Context;
  class Optional__enum_variant_4Context;
  class Aux_rule__enum_variant_list_1Context;
  class Kleene_star__enum_variant_list_2Context;
  class Optional__enum_variant_main_1Context;
  class Aux_rule__enum_tuple_field_list_1Context;
  class Kleene_star__enum_tuple_field_list_2Context;
  class Optional__trait_decl_2Context;
  class Kleene_star__trait_decl_7Context;
  class Optional__impl_block_1Context;
  class Optional__impl_block_2Context;
  class Optional__impl_block_3Context;
  class Optional__impl_block_4Context;
  class Optional__impl_block_5Context;
  class Optional__impl_block_6Context;
  class Kleene_star__impl_block_7Context;
  class Aux_rule__impl_item_1Context;
  class Kleene_star__impl_item_2Context;
  class Aux_rule__impl_item_tail_11Context;
  class Optional__impl_item_tail_12Context;
  class Kleene_star__inner_attr_1Context;
  class Optional__path_1Context;
  class Optional__path_parent_1Context;
  class Aux_rule__path_segment_no_super_1Context;
  class Optional__path_segment_no_super_2Context;
  class Optional__simple_path_1Context;
  class Aux_rule__simple_path_2Context;
  class Kleene_star__simple_path_3Context;
  class Optional__for_lifetimes_1Context;
  class Aux_rule__lifetime_def_list_1Context;
  class Kleene_star__lifetime_def_list_2Context;
  class Aux_rule__lifetime_def_1Context;
  class Optional__lifetime_def_2Context;
  class Optional__type_path_main_1Context;
  class Optional__ty_path_tail_1Context;
  class Optional__ty_path_segment_no_super_2Context;
  class Optional__ty_path_segment_no_super_3Context;
  class Aux_rule__where_bound_list_1Context;
  class Kleene_star__where_bound_list_2Context;
  class Optional__where_bound_1Context;
  class Optional__where_bound_2Context;
  class Optional__empty_ok_colon_bound_1Context;
  class Aux_rule__prim_bound_3Context;
  class Optional__prim_bound_4Context;
  class Aux_rule__prim_bound_5Context;
  class Optional__type_1Context;
  class Aux_rule__array_or_slice_type_1Context;
  class Optional__array_or_slice_type_2Context;
  class Aux_rule__type_param_bounds_1Context;
  class Kleene_star__type_param_bounds_2Context;
  class Optional__type_param_bounds_3Context;
  class Optional__trait_object_type_2Context;
  class Optional__bare_function_type_4Context;
  class Optional__extern_abi_1Context;
  class Aux_rule__type_arguments_1Context;
  class Kleene_star__type_arguments_2Context;
  class Aux_rule__type_arguments_4Context;
  class Kleene_star__type_arguments_5Context;
  class Aux_rule__type_arguments_6Context;
  class Kleene_star__type_arguments_7Context;
  class Optional__ty_sum_1Context;
  class Aux_rule__ty_sum_2Context;
  class Optional__ty_sum_3Context;
  class Aux_rule__ty_sum_list_1Context;
  class Kleene_star__ty_sum_list_2Context;
  class Aux_rule__type_parameters_1Context;
  class Kleene_star__type_parameters_2Context;
  class Optional__type_parameters_3Context;
  class Aux_rule__lifetime_param_list_1Context;
  class Kleene_star__lifetime_param_list_2Context;
  class Optional__type_parameter_4Context;
  class Aux_rule__type_parameter_list_1Context;
  class Kleene_star__type_parameter_list_2Context;
  class Aux_rule__pattern_1Context;
  class Optional__pattern_2Context;
  class Optional__pattern_without_mut_1Context;
  class Aux_rule__pattern_without_mut_2Context;
  class Optional__pattern_without_mut_3Context;
  class Aux_rule__pattern_without_mut_4Context;
  class Kleene_star__pattern_without_mut_5Context;
  class Optional__pattern_without_mut_12Context;
  class Optional__pattern_without_mut_13Context;
  class Aux_rule__pattern_without_mut_15Context;
  class Kleene_star__pattern_without_mut_16Context;
  class Optional__pat_lit_1Context;
  class Optional__pat_list_with_dots_3Context;
  class Aux_rule__pat_list_with_dots_4Context;
  class Optional__pat_list_with_dots_5Context;
  class Aux_rule__pat_list_dots_tail_1Context;
  class Optional__pat_list_dots_tail_2Context;
  class Aux_rule__pat_fields_1Context;
  class Kleene_star__pat_fields_2Context;
  class Aux_rule__pat_fields_3Context;
  class Kleene_star__pat_fields_4Context;
  class Optional__pat_field_2Context;
  class Optional__expr_1Context;
  class Optional__expr_2Context;
  class Aux_rule__expr_list_1Context;
  class Kleene_star__expr_list_2Context;
  class Kleene_star__block_with_inner_attrs_2Context;
  class Optional__block_with_inner_attrs_3Context;
  class Aux_rule__blocky_expr_1Context;
  class Kleene_star__blocky_expr_2Context;
  class Aux_rule__blocky_expr_3Context;
  class Optional__blocky_expr_4Context;
  class Optional__blocky_expr_5Context;
  class Optional__blocky_expr_6Context;
  class Optional__blocky_expr_7Context;
  class Aux_rule__match_arms_4Context;
  class Optional__match_arms_5Context;
  class Optional__match_arm_intro_2Context;
  class Aux_rule__match_pattern_2Context;
  class Kleene_star__match_pattern_3Context;
  class Optional__prim_expr_1Context;
  class Optional__prim_expr_2Context;
  class Optional__prim_expr_no_struct_1Context;
  class Optional__prim_expr_no_struct_5Context;
  class Optional__prim_expr_no_struct_9Context;
  class Optional__prim_expr_no_struct_10Context;
  class Optional__prim_expr_no_struct_11Context;
  class Optional__prim_expr_no_struct_12Context;
  class Optional__prim_expr_no_struct_13Context;
  class Optional__closure_params_1Context;
  class Aux_rule__closure_param_list_1Context;
  class Kleene_star__closure_param_list_2Context;
  class Aux_rule__fields_1Context;
  class Kleene_star__fields_2Context;
  class Kleene_star__field_1Context;
  class Aux_rule__post_expr_tail_4Context;
  class Optional__post_expr_tail_5Context;
  class Optional__range_expr_1Context;
  class Optional__range_expr_no_struct_1Context;
  class Optional__macro_rules_def_1Context;
  class Aux_rule__macro_rules_1Context;
  class Kleene_star__macro_rules_2Context;
  class Optional__macro_rules_3Context;
  class Kleene_star__macro_matcher_1Context;
  class Kleene_plus__macro_match_1Context;
  class Optional__macro_match_2Context;
  class Aux_rule__bound_4Context;
  class Kleene_star__bound_3Context;
  class BoundContext;
  class Aux_rule__path_parent_3Context;
  class Kleene_star__path_parent_2Context;
  class Aux_rule__path_parent_4Context;
  class Path_parentContext;
  class Aux_rule__lifetime_bound_2Context;
  class Kleene_star__lifetime_bound_1Context;
  class Lifetime_boundContext;
  class Aux_rule__ty_path_parent_3Context;
  class Kleene_star__ty_path_parent_2Context;
  class Aux_rule__ty_path_parent_4Context;
  class Ty_path_parentContext;
  class Aux_rule__pattern_without_mut_19Context;
  class Kleene_star__pattern_without_mut_18Context;
  class Aux_rule__pattern_without_mut_20Context;
  class Pattern_without_mutContext;
  class Kleene_star__post_expr_1Context;
  class Post_exprContext;
  class Aux_rule__cast_expr_2Context;
  class Kleene_star__cast_expr_1Context;
  class Cast_exprContext;
  class Aux_rule__mul_expr_2Context;
  class Kleene_star__mul_expr_1Context;
  class Mul_exprContext;
  class Aux_rule__add_expr_2Context;
  class Kleene_star__add_expr_1Context;
  class Add_exprContext;
  class Aux_rule__shift_expr_2Context;
  class Kleene_star__shift_expr_1Context;
  class Shift_exprContext;
  class Aux_rule__bit_and_expr_2Context;
  class Kleene_star__bit_and_expr_1Context;
  class Bit_and_exprContext;
  class Aux_rule__bit_xor_expr_2Context;
  class Kleene_star__bit_xor_expr_1Context;
  class Bit_xor_exprContext;
  class Aux_rule__bit_or_expr_2Context;
  class Kleene_star__bit_or_expr_1Context;
  class Bit_or_exprContext;
  class Aux_rule__and_expr_2Context;
  class Kleene_star__and_expr_1Context;
  class And_exprContext;
  class Aux_rule__or_expr_2Context;
  class Kleene_star__or_expr_1Context;
  class Or_exprContext;
  class Post_expr_no_structContext;
  class Cast_expr_no_structContext;
  class Aux_rule__mul_expr_no_struct_2Context;
  class Kleene_star__mul_expr_no_struct_1Context;
  class Mul_expr_no_structContext;
  class Aux_rule__add_expr_no_struct_2Context;
  class Kleene_star__add_expr_no_struct_1Context;
  class Add_expr_no_structContext;
  class Aux_rule__shift_expr_no_struct_2Context;
  class Kleene_star__shift_expr_no_struct_1Context;
  class Shift_expr_no_structContext;
  class Aux_rule__bit_and_expr_no_struct_2Context;
  class Kleene_star__bit_and_expr_no_struct_1Context;
  class Bit_and_expr_no_structContext;
  class Aux_rule__bit_xor_expr_no_struct_2Context;
  class Kleene_star__bit_xor_expr_no_struct_1Context;
  class Bit_xor_expr_no_structContext;
  class Aux_rule__bit_or_expr_no_struct_2Context;
  class Kleene_star__bit_or_expr_no_struct_1Context;
  class Bit_or_expr_no_structContext;
  class Aux_rule__and_expr_no_struct_2Context;
  class Kleene_star__and_expr_no_struct_1Context;
  class And_expr_no_structContext;
  class Aux_rule__or_expr_no_struct_2Context;
  class Kleene_star__or_expr_no_struct_1Context;
  class Or_expr_no_structContext;
  class Kleene_plus__expr_attrs_2Context;
  class Kleene_plus__expr_inner_attrs_2Context;
  class Aux_rule__enum_variant_main_3Context;
  class Optional__enum_variant_main_4Context;
  class Aux_rule__impl_what_1Context;
  class Optional__impl_what_2Context;
  class Aux_rule__path_2Context;
  class Optional__path_3Context;
  class Aux_rule__type_path_main_2Context;
  class Optional__type_path_main_3Context;
  class Aux_rule__tuple_type_2Context;
  class Optional__tuple_type_3Context;
  class Aux_rule__type_argument_1Context;
  class Optional__type_argument_2Context;
  class Aux_rule__pattern_without_mut_21Context;
  class Optional__pattern_without_mut_22Context;
  class Aux_rule__pattern_without_mut_23Context;
  class Optional__pattern_without_mut_24Context;
  class Aux_rule__assign_expr_1Context;
  class Optional__assign_expr_2Context;
  class Aux_rule__assign_expr_no_struct_1Context;
  class Optional__assign_expr_no_struct_2Context;
  class Optional__blocky_expr_11Context;
  class Optional__closure_params_2Context;
  class Aux_rule__cmp_expr_1Context;
  class Optional__cmp_expr_2Context;
  class Aux_rule__range_expr_5Context;
  class Optional__range_expr_6Context;
  class Aux_rule__cmp_expr_no_struct_5Context;
  class Optional__cmp_expr_no_struct_6Context;
  class Aux_rule__range_expr_no_struct_5Context;
  class Optional__range_expr_no_struct_6Context;
  class Altnt_block__visibility_restriction_1Context;
  class Altnt_block__type_decl_10Context;
  class Altnt_block__use_suffix_2Context;
  class Altnt_block__foreign_item_tail_11Context;
  class Altnt_block__macro_invocation_semi_4Context;
  class Altnt_block__type_parameters_4Context;
  class Altnt_block__trait_method_param_6Context;
  class Altnt_block__struct_tail_6Context;
  class Altnt_block__enum_variant_main_5Context;
  class Altnt_block__trait_item_19Context;
  class Altnt_block__impl_what_3Context;
  class Altnt_block__type_arguments_9Context;
  class Altnt_block__impl_item_tail_13Context;
  class Altnt_block__pattern_without_mut_25Context;
  class Altnt_block__pattern_without_mut_26Context;
  class Altnt_block__pattern_without_mut_27Context;
  class Altnt_block__pattern_without_mut_28Context;
  class Altnt_block__pattern_without_mut_29Context;
  class Altnt_block__pat_fields_6Context;
  class Altnt_block__stmt_8Context;
  class Altnt_block__blocky_expr_12Context;
  class Altnt_block__if_cond_or_pat_1Context;
  class Altnt_block__match_arms_6Context;
  class Altnt_block__prim_expr_no_struct_18Context;
  class Altnt_block__prim_expr_no_struct_19Context;
  class Altnt_block__post_expr_tail_7Context;
  class Altnt_block__pre_expr_3Context;
  class Altnt_block__cast_expr_3Context;
  class Altnt_block__mul_expr_3Context;
  class Altnt_block__add_expr_3Context;
  class Altnt_block__shift_expr_3Context;
  class Altnt_block__range_expr_7Context;
  class Altnt_block__range_expr_no_struct_7Context;
  class Altnt_block__macro_rules_def_4Context;
  class Altnt_block__macro_match_3Context;
  class Altnt_block__macro_invocation_semi_5Context;
  class TypeContext;
  class Altnt_block__extern_crate_2Context;
  class Altnt_block__use_path_7Context;
  class Altnt_block__use_item_2Context;
  class Altnt_block__const_decl_2Context;
  class Altnt_block__fn_decl_4Context;
  class Altnt_block__method_param_list_4Context;
  class Altnt_block__restricted_pat_4Context;
  class Altnt_block__trait_method_param_list_5Context;
  class Altnt_block__fn_rtype_1Context;
  class Altnt_block__trait_alias_3Context;
  class Altnt_block__trait_item_20Context;
  class Altnt_block__ty_path_tail_3Context;
  class Altnt_block__pat_fields_7Context;
  class Altnt_block__prim_expr_no_struct_20Context;
  class Altnt_block__fields_4Context;
  class Altnt_block__type_arguments_10Context;
  class Altnt_block__assign_expr_3Context;
  class Altnt_block__assign_expr_no_struct_3Context;
  class Altnt_block__cmp_expr_3Context;
  class Altnt_block__cmp_expr_no_struct_7Context;
  class Altnt_block__trait_method_param_7Context;
  class Aux_rule__trait_method_param_8Context;
  class Optional__trait_method_param_9Context;
  class Aux_rule__struct_tail_7Context;
  class Optional__struct_tail_8Context;
  class Aux_rule__assign_expr_no_struct_4Context;
  class Optional__assign_expr_no_struct_5Context;
  class Aux_rule__blocky_expr_13Context;
  class Optional__blocky_expr_14Context;
  class Optional__cmp_expr_no_struct_8Context;
  class Altnt_block__type_decl_11Context;
  class Altnt_block__use_path_8Context;
  class Altnt_block__foreign_item_4Context;
  class Altnt_block__param_12Context;
  class Altnt_block__trait_item_21Context;
  class Altnt_block__trait_item_22Context;
  class Altnt_block__type_arguments_11Context;
  class Altnt_block__pattern_without_mut_31Context;
  class Altnt_block__pat_field_6Context;
  class Altnt_block__blocky_expr_15Context;
  class Altnt_block__prim_expr_no_struct_22Context;
  class Altnt_block__prim_expr_no_struct_23Context;
  class Altnt_block__prim_expr_no_struct_24Context;
  class Altnt_block__range_expr_8Context;
  class Altnt_block__item_7Context;
  class Altnt_block__param_11Context;
  class Altnt_block__ty_path_segment_no_super_6Context;
  class Aux_rule__post_expr_2Context;
  class Aux_rule__visibility_2Context;
  class Aux_rule__use_suffix_3Context;
  class Aux_rule__foreign_item_tail_12Context;
  class Aux_rule__param_13Context;
  class Aux_rule__self_param_6Context;
  class Aux_rule__self_param_7Context;
  class Aux_rule__trait_method_param_10Context;
  class Aux_rule__struct_tail_9Context;
  class Aux_rule__struct_tail_10Context;
  class Aux_rule__trait_item_23Context;
  class Aux_rule__trait_item_24Context;
  class Aux_rule__trait_item_25Context;
  class Aux_rule__impl_what_4Context;
  class Aux_rule__impl_what_5Context;
  class Aux_rule__impl_what_6Context;
  class Aux_rule__impl_item_tail_14Context;
  class Aux_rule__impl_item_tail_15Context;
  class Aux_rule__tt_1Context;
  class Aux_rule__ty_path_tail_4Context;
  class Aux_rule__where_bound_3Context;
  class Aux_rule__where_bound_4Context;
  class Aux_rule__trait_bound_5Context;
  class Aux_rule__trait_bound_6Context;
  class Aux_rule__type_argument_3Context;
  class Aux_rule__type_parameter_5Context;
  class Aux_rule__pattern_3Context;
  class Aux_rule__pat_ident_1Context;
  class Aux_rule__pat_list_with_dots_6Context;
  class Aux_rule__pat_fields_8Context;
  class Aux_rule__pat_fields_9Context;
  class Aux_rule__stmt_9Context;
  class Aux_rule__stmt_10Context;
  class Aux_rule__blocky_expr_16Context;
  class Aux_rule__blocky_expr_17Context;
  class Aux_rule__blocky_expr_18Context;
  class Aux_rule__prim_expr_3Context;
  class Aux_rule__prim_expr_no_struct_25Context;
  class Aux_rule__prim_expr_no_struct_26Context;
  class Aux_rule__prim_expr_no_struct_27Context;
  class Aux_rule__prim_expr_no_struct_28Context;
  class Aux_rule__prim_expr_no_struct_29Context;
  class Aux_rule__prim_expr_no_struct_30Context;
  class Aux_rule__prim_expr_no_struct_31Context;
  class Aux_rule__closure_params_3Context;
  class Aux_rule__closure_tail_2Context;
  class Aux_rule__fields_5Context;
  class Aux_rule__field_2Context;
  class Aux_rule__pre_expr_5Context;
  class Aux_rule__pre_expr_6Context;
  class Aux_rule__range_expr_9Context;
  class Aux_rule__range_expr_10Context;
  class Aux_rule__pre_expr_no_struct_4Context;
  class Aux_rule__range_expr_no_struct_9Context;
  class Aux_rule__range_expr_no_struct_10Context;
  class Aux_rule__macro_rules_def_5Context;
  class Aux_rule__macro_rules_def_6Context;
  class Aux_rule__macro_matcher_4Context;
  class Aux_rule__macro_matcher_5Context;
  class Aux_rule__macro_matcher_6Context;
  class Aux_rule__macro_match_4Context;
  class Aux_rule__delim_token_tree_4Context;
  class Aux_rule__delim_token_tree_5Context;
  class Aux_rule__delim_token_tree_6Context;
  class Aux_rule__prim_bound_6Context;
  class Aux_rule__bound_5Context;
  class Aux_rule__bound_6Context;
  class Aux_rule__path_parent_6Context;
  class Aux_rule__path_parent_7Context;
  class Aux_rule__ty_path_parent_6Context;
  class Aux_rule__ty_path_parent_7Context;
  class Aux_rule__pattern_without_mut_32Context;
  class Aux_rule__pattern_without_mut_33Context;
  class Aux_rule__pattern_without_mut_34Context;
  class Aux_rule__pattern_without_mut_35Context;
  class Aux_rule__pattern_without_mut_36Context;
  class Aux_rule__pattern_without_mut_37Context;
  class Aux_rule__pattern_without_mut_38Context;
  class Aux_rule__pattern_without_mut_39Context;
  class Aux_rule__pattern_without_mut_40Context;
  class Aux_rule__visibility_restriction_2Context;
  class Aux_rule__use_suffix_4Context;
  class Aux_rule__foreign_item_tail_13Context;
  class Aux_rule__foreign_item_tail_14Context;
  class Aux_rule__macro_invocation_semi_6Context;
  class Aux_rule__macro_invocation_semi_7Context;
  class Aux_rule__type_parameters_5Context;
  class Aux_rule__enum_variant_main_6Context;
  class Aux_rule__enum_variant_main_7Context;
  class Aux_rule__impl_item_tail_16Context;
  class Aux_rule__impl_item_tail_17Context;
  class Aux_rule__pattern_without_mut_41Context;
  class Aux_rule__pattern_without_mut_42Context;
  class Aux_rule__pattern_without_mut_43Context;
  class Aux_rule__pat_fields_10Context;
  class Aux_rule__stmt_11Context;
  class Aux_rule__blocky_expr_19Context;
  class Aux_rule__if_cond_or_pat_2Context;
  class Aux_rule__match_arms_7Context;
  class Aux_rule__match_arms_8Context;
  class Aux_rule__post_expr_tail_8Context;
  class Aux_rule__pre_expr_7Context;
  class Aux_rule__shift_expr_4Context;
  class Aux_rule__shift_expr_5Context;
  class Aux_rule__range_expr_11Context;
  class Aux_rule__range_expr_no_struct_11Context;
  class Aux_rule__macro_rules_def_7Context;
  class Aux_rule__macro_rules_def_8Context;
  class Aux_rule__macro_match_5Context;
  class Aux_rule__macro_match_6Context;
  class Aux_rule__macro_invocation_semi_8Context;
  class Aux_rule__macro_invocation_semi_9Context;
  class Aux_rule__type_3Context;
  class Aux_rule__type_4Context;
  class Aux_rule__type_5Context;
  class Aux_rule__fn_rtype_2Context;
  class Aux_rule__trait_alias_4Context;
  class Aux_rule__pat_fields_11Context;
  class Aux_rule__prim_expr_no_struct_32Context;
  class Aux_rule__fields_6Context;
  class Aux_rule__assign_expr_no_struct_6Context;
  class Aux_rule__cmp_expr_no_struct_9Context;
  class Aux_rule__trait_method_param_11Context;
  class Aux_rule__type_decl_12Context;
  class Aux_rule__type_decl_13Context;
  class Aux_rule__use_path_9Context;
  class Aux_rule__use_path_10Context;
  class Aux_rule__foreign_item_5Context;
  class Aux_rule__param_14Context;
  class Aux_rule__param_15Context;
  class Aux_rule__trait_item_26Context;
  class Aux_rule__trait_item_27Context;
  class Aux_rule__type_arguments_12Context;
  class Aux_rule__type_arguments_13Context;
  class Aux_rule__pattern_without_mut_44Context;
  class Aux_rule__pattern_without_mut_45Context;
  class Aux_rule__pat_field_7Context;
  class Aux_rule__pat_field_8Context;
  class Aux_rule__prim_expr_no_struct_33Context;
  class Aux_rule__prim_expr_no_struct_34Context;
  class Aux_rule__prim_expr_no_struct_35Context;
  class Aux_rule__item_8Context;
  class Aux_rule__param_16Context;
  class Aux_rule__ty_path_segment_no_super_7Context;
  class Aux_rule__post_expr_3Context;
  class Aux_rule__post_expr_4Context;
  class Aux_rule__post_expr_5Context; 

  class  CrateContext : public antlr4::ParserRuleContext {
  public:
    CrateContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Mod_bodyContext *mod_body();
    antlr4::tree::TerminalNode *EOF();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  CrateContext* crate();

  class  Mod_bodyContext : public antlr4::ParserRuleContext {
  public:
    Mod_bodyContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__mod_body_1Context *kleene_star__mod_body_1();
    Kleene_star__mod_body_2Context *kleene_star__mod_body_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Mod_bodyContext* mod_body();

  class  VisibilityContext : public antlr4::ParserRuleContext {
  public:
    VisibilityContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__visibility_2Context *aux_rule__visibility_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  VisibilityContext* visibility();

  class  Visibility_restrictionContext : public antlr4::ParserRuleContext {
  public:
    Visibility_restrictionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__visibility_restriction_1Context *altnt_block__visibility_restriction_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Visibility_restrictionContext* visibility_restriction();

  class  ItemContext : public antlr4::ParserRuleContext {
  public:
    ItemContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__item_1Context *kleene_star__item_1();
    Altnt_block__item_7Context *altnt_block__item_7();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ItemContext* item();

  class  Pub_itemContext : public antlr4::ParserRuleContext {
  public:
    Pub_itemContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Extern_crateContext *extern_crate();
    Use_declContext *use_decl();
    Mod_decl_shortContext *mod_decl_short();
    Mod_declContext *mod_decl();
    Static_declContext *static_decl();
    Const_declContext *const_decl();
    Associated_const_declContext *associated_const_decl();
    Associated_static_declContext *associated_static_decl();
    Fn_declContext *fn_decl();
    Type_declContext *type_decl();
    Struct_declContext *struct_decl();
    Enum_declContext *enum_decl();
    Union_declContext *union_decl();
    Trait_declContext *trait_decl();
    Trait_aliasContext *trait_alias();
    Macro_declContext *macro_decl();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Pub_itemContext* pub_item();

  class  Extern_crateContext : public antlr4::ParserRuleContext {
  public:
    Extern_crateContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__extern_crate_2Context *altnt_block__extern_crate_2();
    Optional__extern_crate_1Context *optional__extern_crate_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Extern_crateContext* extern_crate();

  class  Use_declContext : public antlr4::ParserRuleContext {
  public:
    Use_declContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Use_pathContext *use_path();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Use_declContext* use_decl();

  class  Use_pathContext : public antlr4::ParserRuleContext {
  public:
    Use_pathContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__simple_path_1Context *optional__simple_path_1();
    Altnt_block__use_path_8Context *altnt_block__use_path_8();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Use_pathContext* use_path();

  class  Use_suffixContext : public antlr4::ParserRuleContext {
  public:
    Use_suffixContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    RenameContext *rename();
    Aux_rule__use_suffix_3Context *aux_rule__use_suffix_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Use_suffixContext* use_suffix();

  class  Use_itemContext : public antlr4::ParserRuleContext {
  public:
    Use_itemContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__use_item_2Context *altnt_block__use_item_2();
    Optional__extern_crate_1Context *optional__extern_crate_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Use_itemContext* use_item();

  class  Use_item_listContext : public antlr4::ParserRuleContext {
  public:
    Use_item_listContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Use_itemContext *use_item();
    Kleene_star__use_item_list_2Context *kleene_star__use_item_list_2();
    Optional__use_item_list_3Context *optional__use_item_list_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Use_item_listContext* use_item_list();

  class  RenameContext : public antlr4::ParserRuleContext {
  public:
    RenameContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__const_decl_2Context *altnt_block__const_decl_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  RenameContext* rename();

  class  Mod_decl_shortContext : public antlr4::ParserRuleContext {
  public:
    Mod_decl_shortContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    IdentContext *ident();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Mod_decl_shortContext* mod_decl_short();

  class  Mod_declContext : public antlr4::ParserRuleContext {
  public:
    Mod_declContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    IdentContext *ident();
    Mod_bodyContext *mod_body();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Mod_declContext* mod_decl();

  class  Extern_modContext : public antlr4::ParserRuleContext {
  public:
    Extern_modContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Extern_abiContext *extern_abi();
    Kleene_star__mod_body_1Context *kleene_star__mod_body_1();
    Kleene_star__extern_mod_2Context *kleene_star__extern_mod_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Extern_modContext* extern_mod();

  class  Foreign_itemContext : public antlr4::ParserRuleContext {
  public:
    Foreign_itemContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__item_1Context *kleene_star__item_1();
    Altnt_block__foreign_item_4Context *altnt_block__foreign_item_4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Foreign_itemContext* foreign_item();

  class  Foreign_item_tailContext : public antlr4::ParserRuleContext {
  public:
    Foreign_item_tailContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Foreign_fn_declContext *foreign_fn_decl();
    Aux_rule__foreign_item_tail_12Context *aux_rule__foreign_item_tail_12();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Foreign_item_tailContext* foreign_item_tail();

  class  Static_declContext : public antlr4::ParserRuleContext {
  public:
    Static_declContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__static_decl_1Context *optional__static_decl_1();
    IdentContext *ident();
    Ty_sumContext *ty_sum();
    ExprContext *expr();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Static_declContext* static_decl();

  class  Associated_static_declContext : public antlr4::ParserRuleContext {
  public:
    Associated_static_declContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__static_decl_1Context *optional__static_decl_1();
    IdentContext *ident();
    Ty_sumContext *ty_sum();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Associated_static_declContext* associated_static_decl();

  class  Const_declContext : public antlr4::ParserRuleContext {
  public:
    Const_declContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__impl_block_1Context *optional__impl_block_1();
    Altnt_block__const_decl_2Context *altnt_block__const_decl_2();
    Ty_sumContext *ty_sum();
    ExprContext *expr();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Const_declContext* const_decl();

  class  Associated_const_declContext : public antlr4::ParserRuleContext {
  public:
    Associated_const_declContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    IdentContext *ident();
    Optional__associated_const_decl_2Context *optional__associated_const_decl_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Associated_const_declContext* associated_const_decl();

  class  Fn_declContext : public antlr4::ParserRuleContext {
  public:
    Fn_declContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Fn_headContext *fn_head();
    Optional__fn_decl_1Context *optional__fn_decl_1();
    Optional__fn_decl_2Context *optional__fn_decl_2();
    Optional__impl_block_6Context *optional__impl_block_6();
    Altnt_block__fn_decl_4Context *altnt_block__fn_decl_4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Fn_declContext* fn_decl();

  class  Method_declContext : public antlr4::ParserRuleContext {
  public:
    Method_declContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Fn_headContext *fn_head();
    Optional__method_decl_1Context *optional__method_decl_1();
    Optional__fn_decl_2Context *optional__fn_decl_2();
    Optional__impl_block_6Context *optional__impl_block_6();
    Altnt_block__fn_decl_4Context *altnt_block__fn_decl_4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Method_declContext* method_decl();

  class  Trait_method_declContext : public antlr4::ParserRuleContext {
  public:
    Trait_method_declContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Fn_headContext *fn_head();
    Optional__trait_method_decl_1Context *optional__trait_method_decl_1();
    Optional__foreign_fn_decl_2Context *optional__foreign_fn_decl_2();
    Optional__impl_block_6Context *optional__impl_block_6();
    Altnt_block__fn_decl_4Context *altnt_block__fn_decl_4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Trait_method_declContext* trait_method_decl();

  class  Foreign_fn_declContext : public antlr4::ParserRuleContext {
  public:
    Foreign_fn_declContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Fn_headContext *fn_head();
    Optional__foreign_fn_decl_1Context *optional__foreign_fn_decl_1();
    Optional__foreign_fn_decl_2Context *optional__foreign_fn_decl_2();
    Optional__impl_block_6Context *optional__impl_block_6();
    Altnt_block__fn_decl_4Context *altnt_block__fn_decl_4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Foreign_fn_declContext* foreign_fn_decl();

  class  Macro_declContext : public antlr4::ParserRuleContext {
  public:
    Macro_declContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Macro_headContext *macro_head();
    Optional__macro_decl_3Context *optional__macro_decl_3();
    Optional__fn_decl_2Context *optional__fn_decl_2();
    Optional__impl_block_6Context *optional__impl_block_6();
    TtContext *tt();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Macro_declContext* macro_decl();

  class  Macro_headContext : public antlr4::ParserRuleContext {
  public:
    Macro_headContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    IdentContext *ident();
    Optional__macro_head_1Context *optional__macro_head_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Macro_headContext* macro_head();

  class  Fn_headContext : public antlr4::ParserRuleContext {
  public:
    Fn_headContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__fn_head_2Context *kleene_star__fn_head_2();
    Optional__fn_head_3Context *optional__fn_head_3();
    IdentContext *ident();
    Optional__impl_block_3Context *optional__impl_block_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Fn_headContext* fn_head();

  class  ParamContext : public antlr4::ParserRuleContext {
  public:
    ParamContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__param_13Context *aux_rule__param_13();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ParamContext* param();

  class  Param_listContext : public antlr4::ParserRuleContext {
  public:
    Param_listContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ParamContext *param();
    Kleene_star__param_list_2Context *kleene_star__param_list_2();
    Optional__param_list_5Context *optional__param_list_5();
    Optional__use_item_list_3Context *optional__use_item_list_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Param_listContext* param_list();

  class  Variadic_param_listContext : public antlr4::ParserRuleContext {
  public:
    Variadic_param_listContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ParamContext *param();
    Kleene_star__param_list_2Context *kleene_star__param_list_2();
    Optional__variadic_param_list_5Context *optional__variadic_param_list_5();
    Optional__use_item_list_3Context *optional__use_item_list_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Variadic_param_listContext* variadic_param_list();

  class  Variadic_param_list_names_optionalContext : public antlr4::ParserRuleContext {
  public:
    Variadic_param_list_names_optionalContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Trait_method_paramContext *trait_method_param();
    Kleene_star__trait_method_param_list_3Context *kleene_star__trait_method_param_list_3();
    Optional__variadic_param_list_5Context *optional__variadic_param_list_5();
    Optional__use_item_list_3Context *optional__use_item_list_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Variadic_param_list_names_optionalContext* variadic_param_list_names_optional();

  class  Self_paramContext : public antlr4::ParserRuleContext {
  public:
    Self_paramContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__self_param_6Context *aux_rule__self_param_6();
    Aux_rule__self_param_7Context *aux_rule__self_param_7();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Self_paramContext* self_param();

  class  Method_param_listContext : public antlr4::ParserRuleContext {
  public:
    Method_param_listContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__method_param_list_4Context *altnt_block__method_param_list_4();
    Kleene_star__param_list_2Context *kleene_star__param_list_2();
    Optional__use_item_list_3Context *optional__use_item_list_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Method_param_listContext* method_param_list();

  class  Trait_method_paramContext : public antlr4::ParserRuleContext {
  public:
    Trait_method_paramContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__trait_method_param_10Context *aux_rule__trait_method_param_10();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Trait_method_paramContext* trait_method_param();

  class  Restricted_patContext : public antlr4::ParserRuleContext {
  public:
    Restricted_patContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__restricted_pat_1Context *optional__restricted_pat_1();
    Optional__restricted_pat_3Context *optional__restricted_pat_3();
    Altnt_block__restricted_pat_4Context *altnt_block__restricted_pat_4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Restricted_patContext* restricted_pat();

  class  Trait_method_param_listContext : public antlr4::ParserRuleContext {
  public:
    Trait_method_param_listContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__item_1Context *kleene_star__item_1();
    Altnt_block__trait_method_param_list_5Context *altnt_block__trait_method_param_list_5();
    Kleene_star__trait_method_param_list_3Context *kleene_star__trait_method_param_list_3();
    Optional__use_item_list_3Context *optional__use_item_list_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Trait_method_param_listContext* trait_method_param_list();

  class  RtypeContext : public antlr4::ParserRuleContext {
  public:
    RtypeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    TypeContext *type();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  RtypeContext* rtype();

  class  Fn_rtypeContext : public antlr4::ParserRuleContext {
  public:
    Fn_rtypeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__fn_rtype_1Context *altnt_block__fn_rtype_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Fn_rtypeContext* fn_rtype();

  class  Type_declContext : public antlr4::ParserRuleContext {
  public:
    Type_declContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    IdentContext *ident();
    Altnt_block__type_decl_10Context *altnt_block__type_decl_10();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Type_declContext* type_decl();

  class  Struct_declContext : public antlr4::ParserRuleContext {
  public:
    Struct_declContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    IdentContext *ident();
    Optional__impl_block_3Context *optional__impl_block_3();
    Struct_tailContext *struct_tail();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Struct_declContext* struct_decl();

  class  Struct_tailContext : public antlr4::ParserRuleContext {
  public:
    Struct_tailContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__struct_tail_9Context *aux_rule__struct_tail_9();
    Aux_rule__struct_tail_10Context *aux_rule__struct_tail_10();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Struct_tailContext* struct_tail();

  class  Tuple_struct_fieldContext : public antlr4::ParserRuleContext {
  public:
    Tuple_struct_fieldContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__item_1Context *kleene_star__item_1();
    Optional__item_2Context *optional__item_2();
    Ty_sumContext *ty_sum();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Tuple_struct_fieldContext* tuple_struct_field();

  class  Tuple_struct_field_listContext : public antlr4::ParserRuleContext {
  public:
    Tuple_struct_field_listContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Tuple_struct_fieldContext *tuple_struct_field();
    Kleene_star__tuple_struct_field_list_2Context *kleene_star__tuple_struct_field_list_2();
    Optional__use_item_list_3Context *optional__use_item_list_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Tuple_struct_field_listContext* tuple_struct_field_list();

  class  Field_declContext : public antlr4::ParserRuleContext {
  public:
    Field_declContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__item_1Context *kleene_star__item_1();
    Optional__item_2Context *optional__item_2();
    IdentContext *ident();
    Ty_sumContext *ty_sum();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Field_declContext* field_decl();

  class  Field_decl_listContext : public antlr4::ParserRuleContext {
  public:
    Field_decl_listContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Field_declContext *field_decl();
    Kleene_star__field_decl_list_2Context *kleene_star__field_decl_list_2();
    Optional__use_item_list_3Context *optional__use_item_list_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Field_decl_listContext* field_decl_list();

  class  Enum_declContext : public antlr4::ParserRuleContext {
  public:
    Enum_declContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    IdentContext *ident();
    Optional__impl_block_3Context *optional__impl_block_3();
    Optional__impl_block_6Context *optional__impl_block_6();
    Optional__enum_decl_3Context *optional__enum_decl_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Enum_declContext* enum_decl();

  class  Enum_variantContext : public antlr4::ParserRuleContext {
  public:
    Enum_variantContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__item_1Context *kleene_star__item_1();
    Optional__item_2Context *optional__item_2();
    Enum_variant_mainContext *enum_variant_main();
    Optional__enum_variant_4Context *optional__enum_variant_4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Enum_variantContext* enum_variant();

  class  Enum_variant_listContext : public antlr4::ParserRuleContext {
  public:
    Enum_variant_listContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Enum_variantContext *enum_variant();
    Kleene_star__enum_variant_list_2Context *kleene_star__enum_variant_list_2();
    Optional__use_item_list_3Context *optional__use_item_list_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Enum_variant_listContext* enum_variant_list();

  class  Enum_variant_mainContext : public antlr4::ParserRuleContext {
  public:
    Enum_variant_mainContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    IdentContext *ident();
    Altnt_block__enum_variant_main_5Context *altnt_block__enum_variant_main_5();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Enum_variant_mainContext* enum_variant_main();

  class  Enum_tuple_fieldContext : public antlr4::ParserRuleContext {
  public:
    Enum_tuple_fieldContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__item_1Context *kleene_star__item_1();
    Ty_sumContext *ty_sum();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Enum_tuple_fieldContext* enum_tuple_field();

  class  Enum_tuple_field_listContext : public antlr4::ParserRuleContext {
  public:
    Enum_tuple_field_listContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Enum_tuple_fieldContext *enum_tuple_field();
    Kleene_star__enum_tuple_field_list_2Context *kleene_star__enum_tuple_field_list_2();
    Optional__use_item_list_3Context *optional__use_item_list_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Enum_tuple_field_listContext* enum_tuple_field_list();

  class  Union_declContext : public antlr4::ParserRuleContext {
  public:
    Union_declContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    IdentContext *ident();
    Optional__impl_block_3Context *optional__impl_block_3();
    Optional__impl_block_6Context *optional__impl_block_6();
    Field_decl_listContext *field_decl_list();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Union_declContext* union_decl();

  class  Trait_declContext : public antlr4::ParserRuleContext {
  public:
    Trait_declContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__impl_block_2Context *optional__impl_block_2();
    Optional__trait_decl_2Context *optional__trait_decl_2();
    IdentContext *ident();
    Optional__impl_block_3Context *optional__impl_block_3();
    Optional__type_decl_4Context *optional__type_decl_4();
    Optional__impl_block_6Context *optional__impl_block_6();
    Kleene_star__mod_body_1Context *kleene_star__mod_body_1();
    Kleene_star__trait_decl_7Context *kleene_star__trait_decl_7();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Trait_declContext* trait_decl();

  class  Trait_aliasContext : public antlr4::ParserRuleContext {
  public:
    Trait_aliasContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    IdentContext *ident();
    Optional__impl_block_3Context *optional__impl_block_3();
    Altnt_block__trait_alias_3Context *altnt_block__trait_alias_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Trait_aliasContext* trait_alias();

  class  Trait_itemContext : public antlr4::ParserRuleContext {
  public:
    Trait_itemContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__trait_item_23Context *aux_rule__trait_item_23();
    Aux_rule__trait_item_24Context *aux_rule__trait_item_24();
    Aux_rule__trait_item_25Context *aux_rule__trait_item_25();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Trait_itemContext* trait_item();

  class  Ty_defaultContext : public antlr4::ParserRuleContext {
  public:
    Ty_defaultContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Ty_sumContext *ty_sum();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Ty_defaultContext* ty_default();

  class  Impl_blockContext : public antlr4::ParserRuleContext {
  public:
    Impl_blockContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__impl_block_1Context *optional__impl_block_1();
    Optional__impl_block_2Context *optional__impl_block_2();
    Optional__impl_block_3Context *optional__impl_block_3();
    Optional__impl_block_4Context *optional__impl_block_4();
    Optional__impl_block_5Context *optional__impl_block_5();
    Impl_whatContext *impl_what();
    Optional__impl_block_6Context *optional__impl_block_6();
    Kleene_star__impl_block_7Context *kleene_star__impl_block_7();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Impl_blockContext* impl_block();

  class  Impl_whatContext : public antlr4::ParserRuleContext {
  public:
    Impl_whatContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__impl_what_4Context *aux_rule__impl_what_4();
    Aux_rule__impl_what_5Context *aux_rule__impl_what_5();
    Aux_rule__impl_what_6Context *aux_rule__impl_what_6();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Impl_whatContext* impl_what();

  class  Impl_itemContext : public antlr4::ParserRuleContext {
  public:
    Impl_itemContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__impl_item_2Context *kleene_star__impl_item_2();
    Optional__item_2Context *optional__item_2();
    Impl_item_tailContext *impl_item_tail();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Impl_itemContext* impl_item();

  class  Impl_item_tailContext : public antlr4::ParserRuleContext {
  public:
    Impl_item_tailContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__impl_item_tail_14Context *aux_rule__impl_item_tail_14();
    Const_declContext *const_decl();
    Associated_const_declContext *associated_const_decl();
    Macro_invocation_semiContext *macro_invocation_semi();
    Aux_rule__impl_item_tail_15Context *aux_rule__impl_item_tail_15();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Impl_item_tailContext* impl_item_tail();

  class  AttrContext : public antlr4::ParserRuleContext {
  public:
    AttrContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__inner_attr_1Context *kleene_star__inner_attr_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  AttrContext* attr();

  class  Inner_attrContext : public antlr4::ParserRuleContext {
  public:
    Inner_attrContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__inner_attr_1Context *kleene_star__inner_attr_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Inner_attrContext* inner_attr();

  class  TtContext : public antlr4::ParserRuleContext {
  public:
    TtContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__tt_1Context *aux_rule__tt_1();
    Tt_delimitedContext *tt_delimited();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  TtContext* tt();

  class  Tt_delimitedContext : public antlr4::ParserRuleContext {
  public:
    Tt_delimitedContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__macro_decl_2Context *aux_rule__macro_decl_2();
    Tt_bracketsContext *tt_brackets();
    Tt_blockContext *tt_block();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Tt_delimitedContext* tt_delimited();

  class  Tt_bracketsContext : public antlr4::ParserRuleContext {
  public:
    Tt_bracketsContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__inner_attr_1Context *kleene_star__inner_attr_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Tt_bracketsContext* tt_brackets();

  class  Tt_blockContext : public antlr4::ParserRuleContext {
  public:
    Tt_blockContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__inner_attr_1Context *kleene_star__inner_attr_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Tt_blockContext* tt_block();

  class  Macro_tailContext : public antlr4::ParserRuleContext {
  public:
    Macro_tailContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Tt_delimitedContext *tt_delimited();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Macro_tailContext* macro_tail();

  class  PathContext : public antlr4::ParserRuleContext {
  public:
    PathContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__path_3Context *optional__path_3();
    Path_segment_no_superContext *path_segment_no_super();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  PathContext* path();

  class  As_traitContext : public antlr4::ParserRuleContext {
  public:
    As_traitContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Ty_sumContext *ty_sum();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  As_traitContext* as_trait();

  class  Path_segmentContext : public antlr4::ParserRuleContext {
  public:
    Path_segmentContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Path_segment_no_superContext *path_segment_no_super();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Path_segmentContext* path_segment();

  class  Path_segment_no_superContext : public antlr4::ParserRuleContext {
  public:
    Path_segment_no_superContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Simple_path_segmentContext *simple_path_segment();
    Optional__path_segment_no_super_2Context *optional__path_segment_no_super_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Path_segment_no_superContext* path_segment_no_super();

  class  Simple_pathContext : public antlr4::ParserRuleContext {
  public:
    Simple_pathContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__simple_path_1Context *optional__simple_path_1();
    Simple_path_segmentContext *simple_path_segment();
    Kleene_star__simple_path_3Context *kleene_star__simple_path_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Simple_pathContext* simple_path();

  class  Simple_path_segmentContext : public antlr4::ParserRuleContext {
  public:
    Simple_path_segmentContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    IdentContext *ident();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Simple_path_segmentContext* simple_path_segment();

  class  For_lifetimesContext : public antlr4::ParserRuleContext {
  public:
    For_lifetimesContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__for_lifetimes_1Context *optional__for_lifetimes_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  For_lifetimesContext* for_lifetimes();

  class  Lifetime_def_listContext : public antlr4::ParserRuleContext {
  public:
    Lifetime_def_listContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Lifetime_defContext *lifetime_def();
    Kleene_star__lifetime_def_list_2Context *kleene_star__lifetime_def_list_2();
    Optional__use_item_list_3Context *optional__use_item_list_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Lifetime_def_listContext* lifetime_def_list();

  class  Lifetime_defContext : public antlr4::ParserRuleContext {
  public:
    Lifetime_defContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    LifetimeContext *lifetime();
    Optional__lifetime_def_2Context *optional__lifetime_def_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Lifetime_defContext* lifetime_def();

  class  Type_path_mainContext : public antlr4::ParserRuleContext {
  public:
    Type_path_mainContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__type_path_main_3Context *optional__type_path_main_3();
    Ty_path_tailContext *ty_path_tail();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Type_path_mainContext* type_path_main();

  class  Ty_path_tailContext : public antlr4::ParserRuleContext {
  public:
    Ty_path_tailContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__ty_path_tail_4Context *aux_rule__ty_path_tail_4();
    Ty_path_segment_no_superContext *ty_path_segment_no_super();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Ty_path_tailContext* ty_path_tail();

  class  Type_path_segmentContext : public antlr4::ParserRuleContext {
  public:
    Type_path_segmentContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Ty_path_segment_no_superContext *ty_path_segment_no_super();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Type_path_segmentContext* type_path_segment();

  class  Ty_path_segment_no_superContext : public antlr4::ParserRuleContext {
  public:
    Ty_path_segment_no_superContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__ty_path_segment_no_super_6Context *altnt_block__ty_path_segment_no_super_6();
    Optional__ty_path_segment_no_super_3Context *optional__ty_path_segment_no_super_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Ty_path_segment_no_superContext* ty_path_segment_no_super();

  class  Where_clauseContext : public antlr4::ParserRuleContext {
  public:
    Where_clauseContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Where_bound_listContext *where_bound_list();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Where_clauseContext* where_clause();

  class  Where_bound_listContext : public antlr4::ParserRuleContext {
  public:
    Where_bound_listContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Where_boundContext *where_bound();
    Kleene_star__where_bound_list_2Context *kleene_star__where_bound_list_2();
    Optional__use_item_list_3Context *optional__use_item_list_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Where_bound_listContext* where_bound_list();

  class  Where_boundContext : public antlr4::ParserRuleContext {
  public:
    Where_boundContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__where_bound_3Context *aux_rule__where_bound_3();
    Aux_rule__where_bound_4Context *aux_rule__where_bound_4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Where_boundContext* where_bound();

  class  Empty_ok_colon_boundContext : public antlr4::ParserRuleContext {
  public:
    Empty_ok_colon_boundContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__empty_ok_colon_bound_1Context *optional__empty_ok_colon_bound_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Empty_ok_colon_boundContext* empty_ok_colon_bound();

  class  Colon_boundContext : public antlr4::ParserRuleContext {
  public:
    Colon_boundContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    BoundContext *bound();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Colon_boundContext* colon_bound();

  class  Prim_boundContext : public antlr4::ParserRuleContext {
  public:
    Prim_boundContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__prim_bound_5Context *aux_rule__prim_bound_5();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Prim_boundContext* prim_bound();

  class  Inferred_typeContext : public antlr4::ParserRuleContext {
  public:
    Inferred_typeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Inferred_typeContext* inferred_type();

  class  Array_or_slice_typeContext : public antlr4::ParserRuleContext {
  public:
    Array_or_slice_typeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Ty_sumContext *ty_sum();
    Optional__array_or_slice_type_2Context *optional__array_or_slice_type_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Array_or_slice_typeContext* array_or_slice_type();

  class  Reference_typeContext : public antlr4::ParserRuleContext {
  public:
    Reference_typeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__type_1Context *optional__type_1();
    Optional__static_decl_1Context *optional__static_decl_1();
    TypeContext *type();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Reference_typeContext* reference_type();

  class  Raw_pointer_typeContext : public antlr4::ParserRuleContext {
  public:
    Raw_pointer_typeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Mut_or_constContext *mut_or_const();
    TypeContext *type();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Raw_pointer_typeContext* raw_pointer_type();

  class  Never_typeContext : public antlr4::ParserRuleContext {
  public:
    Never_typeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Never_typeContext* never_type();

  class  Tuple_typeContext : public antlr4::ParserRuleContext {
  public:
    Tuple_typeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__tuple_type_3Context *optional__tuple_type_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Tuple_typeContext* tuple_type();

  class  Impl_trait_typeContext : public antlr4::ParserRuleContext {
  public:
    Impl_trait_typeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Type_param_boundsContext *type_param_bounds();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Impl_trait_typeContext* impl_trait_type();

  class  Impl_trait_type_one_boundContext : public antlr4::ParserRuleContext {
  public:
    Impl_trait_type_one_boundContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Trait_boundContext *trait_bound();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Impl_trait_type_one_boundContext* impl_trait_type_one_bound();

  class  Trait_object_type_one_boundContext : public antlr4::ParserRuleContext {
  public:
    Trait_object_type_one_boundContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__ty_sum_1Context *optional__ty_sum_1();
    Trait_boundContext *trait_bound();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Trait_object_type_one_boundContext* trait_object_type_one_bound();

  class  Type_param_boundsContext : public antlr4::ParserRuleContext {
  public:
    Type_param_boundsContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Type_param_boundContext *type_param_bound();
    Kleene_star__type_param_bounds_2Context *kleene_star__type_param_bounds_2();
    Optional__type_param_bounds_3Context *optional__type_param_bounds_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Type_param_boundsContext* type_param_bounds();

  class  Type_param_boundContext : public antlr4::ParserRuleContext {
  public:
    Type_param_boundContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    LifetimeContext *lifetime();
    Trait_boundContext *trait_bound();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Type_param_boundContext* type_param_bound();

  class  Trait_object_typeContext : public antlr4::ParserRuleContext {
  public:
    Trait_object_typeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__ty_sum_1Context *optional__ty_sum_1();
    Optional__trait_object_type_2Context *optional__trait_object_type_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Trait_object_typeContext* trait_object_type();

  class  Trait_boundContext : public antlr4::ParserRuleContext {
  public:
    Trait_boundContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__trait_bound_5Context *aux_rule__trait_bound_5();
    Aux_rule__trait_bound_6Context *aux_rule__trait_bound_6();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Trait_boundContext* trait_bound();

  class  Bare_function_typeContext : public antlr4::ParserRuleContext {
  public:
    Bare_function_typeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__where_bound_1Context *optional__where_bound_1();
    Optional__impl_block_2Context *optional__impl_block_2();
    Optional__fn_head_3Context *optional__fn_head_3();
    Optional__bare_function_type_4Context *optional__bare_function_type_4();
    Optional__foreign_fn_decl_2Context *optional__foreign_fn_decl_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Bare_function_typeContext* bare_function_type();

  class  Mut_or_constContext : public antlr4::ParserRuleContext {
  public:
    Mut_or_constContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Mut_or_constContext* mut_or_const();

  class  Extern_abiContext : public antlr4::ParserRuleContext {
  public:
    Extern_abiContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__extern_abi_1Context *optional__extern_abi_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Extern_abiContext* extern_abi();

  class  Type_argumentsContext : public antlr4::ParserRuleContext {
  public:
    Type_argumentsContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__type_arguments_9Context *altnt_block__type_arguments_9();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Type_argumentsContext* type_arguments();

  class  Type_argumentContext : public antlr4::ParserRuleContext {
  public:
    Type_argumentContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__type_argument_3Context *aux_rule__type_argument_3();
    antlr4::tree::TerminalNode *BareIntLit();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Type_argumentContext* type_argument();

  class  Ty_sumContext : public antlr4::ParserRuleContext {
  public:
    Ty_sumContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__ty_sum_1Context *optional__ty_sum_1();
    TypeContext *type();
    Optional__ty_sum_3Context *optional__ty_sum_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Ty_sumContext* ty_sum();

  class  Ty_sum_listContext : public antlr4::ParserRuleContext {
  public:
    Ty_sum_listContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Ty_sumContext *ty_sum();
    Kleene_star__ty_sum_list_2Context *kleene_star__ty_sum_list_2();
    Optional__use_item_list_3Context *optional__use_item_list_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Ty_sum_listContext* ty_sum_list();

  class  Type_parametersContext : public antlr4::ParserRuleContext {
  public:
    Type_parametersContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__type_parameters_4Context *altnt_block__type_parameters_4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Type_parametersContext* type_parameters();

  class  Lifetime_paramContext : public antlr4::ParserRuleContext {
  public:
    Lifetime_paramContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__item_1Context *kleene_star__item_1();
    Optional__impl_block_5Context *optional__impl_block_5();
    LifetimeContext *lifetime();
    Optional__lifetime_def_2Context *optional__lifetime_def_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Lifetime_paramContext* lifetime_param();

  class  Lifetime_param_listContext : public antlr4::ParserRuleContext {
  public:
    Lifetime_param_listContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Lifetime_paramContext *lifetime_param();
    Kleene_star__lifetime_param_list_2Context *kleene_star__lifetime_param_list_2();
    Optional__use_item_list_3Context *optional__use_item_list_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Lifetime_param_listContext* lifetime_param_list();

  class  Type_parameterContext : public antlr4::ParserRuleContext {
  public:
    Type_parameterContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__type_parameter_5Context *aux_rule__type_parameter_5();
    Ty_sumContext *ty_sum();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Type_parameterContext* type_parameter();

  class  Type_parameter_listContext : public antlr4::ParserRuleContext {
  public:
    Type_parameter_listContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Type_parameterContext *type_parameter();
    Kleene_star__type_parameter_list_2Context *kleene_star__type_parameter_list_2();
    Optional__use_item_list_3Context *optional__use_item_list_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Type_parameter_listContext* type_parameter_list();

  class  PatternContext : public antlr4::ParserRuleContext {
  public:
    PatternContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Pattern_without_mutContext *pattern_without_mut();
    Aux_rule__pattern_3Context *aux_rule__pattern_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  PatternContext* pattern();

  class  Pat_identContext : public antlr4::ParserRuleContext {
  public:
    Pat_identContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__pat_ident_1Context *aux_rule__pat_ident_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Pat_identContext* pat_ident();

  class  Pat_range_endContext : public antlr4::ParserRuleContext {
  public:
    Pat_range_endContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    PathContext *path();
    Pat_litContext *pat_lit();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Pat_range_endContext* pat_range_end();

  class  Pat_litContext : public antlr4::ParserRuleContext {
  public:
    Pat_litContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__pat_lit_1Context *optional__pat_lit_1();
    LitContext *lit();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Pat_litContext* pat_lit();

  class  Pat_list_with_dotsContext : public antlr4::ParserRuleContext {
  public:
    Pat_list_with_dotsContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Pat_list_dots_tailContext *pat_list_dots_tail();
    Aux_rule__pat_list_with_dots_6Context *aux_rule__pat_list_with_dots_6();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Pat_list_with_dotsContext* pat_list_with_dots();

  class  Pat_list_dots_tailContext : public antlr4::ParserRuleContext {
  public:
    Pat_list_dots_tailContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__pat_list_dots_tail_2Context *optional__pat_list_dots_tail_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Pat_list_dots_tailContext* pat_list_dots_tail();

  class  Pat_fields_leftContext : public antlr4::ParserRuleContext {
  public:
    Pat_fields_leftContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    IdentContext *ident();
    antlr4::tree::TerminalNode *BareIntLit();
    antlr4::tree::TerminalNode *FullIntLit();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Pat_fields_leftContext* pat_fields_left();

  class  Pat_fieldsContext : public antlr4::ParserRuleContext {
  public:
    Pat_fieldsContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__pat_fields_8Context *aux_rule__pat_fields_8();
    Aux_rule__pat_fields_9Context *aux_rule__pat_fields_9();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Pat_fieldsContext* pat_fields();

  class  Pat_fieldContext : public antlr4::ParserRuleContext {
  public:
    Pat_fieldContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__item_1Context *kleene_star__item_1();
    Altnt_block__pat_field_6Context *altnt_block__pat_field_6();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Pat_fieldContext* pat_field();

  class  ExprContext : public antlr4::ParserRuleContext {
  public:
    ExprContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__expr_1Context *optional__expr_1();
    Optional__expr_2Context *optional__expr_2();
    Assign_exprContext *assign_expr();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ExprContext* expr();

  class  Expr_no_structContext : public antlr4::ParserRuleContext {
  public:
    Expr_no_structContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__expr_1Context *optional__expr_1();
    Optional__expr_2Context *optional__expr_2();
    Assign_expr_no_structContext *assign_expr_no_struct();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Expr_no_structContext* expr_no_struct();

  class  Expr_listContext : public antlr4::ParserRuleContext {
  public:
    Expr_listContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ExprContext *expr();
    Kleene_star__expr_list_2Context *kleene_star__expr_list_2();
    Optional__use_item_list_3Context *optional__use_item_list_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Expr_listContext* expr_list();

  class  BlockContext : public antlr4::ParserRuleContext {
  public:
    BlockContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__block_with_inner_attrs_2Context *kleene_star__block_with_inner_attrs_2();
    Optional__block_with_inner_attrs_3Context *optional__block_with_inner_attrs_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  BlockContext* block();

  class  Block_with_inner_attrsContext : public antlr4::ParserRuleContext {
  public:
    Block_with_inner_attrsContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__mod_body_1Context *kleene_star__mod_body_1();
    Kleene_star__block_with_inner_attrs_2Context *kleene_star__block_with_inner_attrs_2();
    Optional__block_with_inner_attrs_3Context *optional__block_with_inner_attrs_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Block_with_inner_attrsContext* block_with_inner_attrs();

  class  StmtContext : public antlr4::ParserRuleContext {
  public:
    StmtContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ItemContext *item();
    Aux_rule__stmt_9Context *aux_rule__stmt_9();
    Macro_invocation_semiContext *macro_invocation_semi();
    Aux_rule__stmt_10Context *aux_rule__stmt_10();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  StmtContext* stmt();

  class  Blocky_exprContext : public antlr4::ParserRuleContext {
  public:
    Blocky_exprContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__blocky_expr_16Context *aux_rule__blocky_expr_16();
    Aux_rule__blocky_expr_17Context *aux_rule__blocky_expr_17();
    Aux_rule__blocky_expr_18Context *aux_rule__blocky_expr_18();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Blocky_exprContext* blocky_expr();

  class  If_cond_or_patContext : public antlr4::ParserRuleContext {
  public:
    If_cond_or_patContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__if_cond_or_pat_1Context *altnt_block__if_cond_or_pat_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  If_cond_or_patContext* if_cond_or_pat();

  class  While_cond_or_patContext : public antlr4::ParserRuleContext {
  public:
    While_cond_or_patContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__if_cond_or_pat_1Context *altnt_block__if_cond_or_pat_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  While_cond_or_patContext* while_cond_or_pat();

  class  Loop_labelContext : public antlr4::ParserRuleContext {
  public:
    Loop_labelContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    LifetimeContext *lifetime();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Loop_labelContext* loop_label();

  class  Match_armsContext : public antlr4::ParserRuleContext {
  public:
    Match_armsContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Match_arm_introContext *match_arm_intro();
    Altnt_block__match_arms_6Context *altnt_block__match_arms_6();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Match_armsContext* match_arms();

  class  Match_arm_introContext : public antlr4::ParserRuleContext {
  public:
    Match_arm_introContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__item_1Context *kleene_star__item_1();
    Match_patternContext *match_pattern();
    Optional__match_arm_intro_2Context *optional__match_arm_intro_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Match_arm_introContext* match_arm_intro();

  class  Match_patternContext : public antlr4::ParserRuleContext {
  public:
    Match_patternContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__pattern_without_mut_1Context *optional__pattern_without_mut_1();
    PatternContext *pattern();
    Kleene_star__match_pattern_3Context *kleene_star__match_pattern_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Match_patternContext* match_pattern();

  class  Match_if_clauseContext : public antlr4::ParserRuleContext {
  public:
    Match_if_clauseContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ExprContext *expr();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Match_if_clauseContext* match_if_clause();

  class  Expr_attrsContext : public antlr4::ParserRuleContext {
  public:
    Expr_attrsContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_plus__expr_attrs_2Context *kleene_plus__expr_attrs_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Expr_attrsContext* expr_attrs();

  class  Expr_inner_attrsContext : public antlr4::ParserRuleContext {
  public:
    Expr_inner_attrsContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_plus__expr_inner_attrs_2Context *kleene_plus__expr_inner_attrs_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Expr_inner_attrsContext* expr_inner_attrs();

  class  Prim_exprContext : public antlr4::ParserRuleContext {
  public:
    Prim_exprContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Prim_expr_no_structContext *prim_expr_no_struct();
    Aux_rule__prim_expr_3Context *aux_rule__prim_expr_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Prim_exprContext* prim_expr();

  class  Prim_expr_no_structContext : public antlr4::ParserRuleContext {
  public:
    Prim_expr_no_structContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    LitContext *lit();
    Aux_rule__prim_expr_no_struct_25Context *aux_rule__prim_expr_no_struct_25();
    Aux_rule__prim_expr_no_struct_26Context *aux_rule__prim_expr_no_struct_26();
    Aux_rule__prim_expr_no_struct_27Context *aux_rule__prim_expr_no_struct_27();
    Blocky_exprContext *blocky_expr();
    Aux_rule__prim_expr_no_struct_28Context *aux_rule__prim_expr_no_struct_28();
    Aux_rule__prim_expr_no_struct_29Context *aux_rule__prim_expr_no_struct_29();
    Aux_rule__prim_expr_no_struct_30Context *aux_rule__prim_expr_no_struct_30();
    Aux_rule__prim_expr_no_struct_31Context *aux_rule__prim_expr_no_struct_31();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Prim_expr_no_structContext* prim_expr_no_struct();

  class  LitContext : public antlr4::ParserRuleContext {
  public:
    LitContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *BareIntLit();
    antlr4::tree::TerminalNode *FullIntLit();
    antlr4::tree::TerminalNode *ByteLit();
    antlr4::tree::TerminalNode *ByteStringLit();
    antlr4::tree::TerminalNode *FloatLit();
    antlr4::tree::TerminalNode *CharLit();
    antlr4::tree::TerminalNode *StringLit();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  LitContext* lit();

  class  Closure_paramsContext : public antlr4::ParserRuleContext {
  public:
    Closure_paramsContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__closure_params_3Context *aux_rule__closure_params_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Closure_paramsContext* closure_params();

  class  Closure_paramContext : public antlr4::ParserRuleContext {
  public:
    Closure_paramContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__item_1Context *kleene_star__item_1();
    PatternContext *pattern();
    Optional__type_decl_7Context *optional__type_decl_7();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Closure_paramContext* closure_param();

  class  Closure_param_listContext : public antlr4::ParserRuleContext {
  public:
    Closure_param_listContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Closure_paramContext *closure_param();
    Kleene_star__closure_param_list_2Context *kleene_star__closure_param_list_2();
    Optional__use_item_list_3Context *optional__use_item_list_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Closure_param_listContext* closure_param_list();

  class  Closure_tailContext : public antlr4::ParserRuleContext {
  public:
    Closure_tailContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__closure_tail_2Context *aux_rule__closure_tail_2();
    ExprContext *expr();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Closure_tailContext* closure_tail();

  class  Lifetime_or_exprContext : public antlr4::ParserRuleContext {
  public:
    Lifetime_or_exprContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    LifetimeContext *lifetime();
    Expr_no_structContext *expr_no_struct();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Lifetime_or_exprContext* lifetime_or_expr();

  class  FieldsContext : public antlr4::ParserRuleContext {
  public:
    FieldsContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Struct_update_baseContext *struct_update_base();
    Aux_rule__fields_5Context *aux_rule__fields_5();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  FieldsContext* fields();

  class  Struct_update_baseContext : public antlr4::ParserRuleContext {
  public:
    Struct_update_baseContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ExprContext *expr();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Struct_update_baseContext* struct_update_base();

  class  FieldContext : public antlr4::ParserRuleContext {
  public:
    FieldContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    IdentContext *ident();
    Aux_rule__field_2Context *aux_rule__field_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  FieldContext* field();

  class  Field_nameContext : public antlr4::ParserRuleContext {
  public:
    Field_nameContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    IdentContext *ident();
    antlr4::tree::TerminalNode *BareIntLit();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Field_nameContext* field_name();

  class  Pre_exprContext : public antlr4::ParserRuleContext {
  public:
    Pre_exprContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Post_exprContext *post_expr();
    Aux_rule__pre_expr_5Context *aux_rule__pre_expr_5();
    Aux_rule__pre_expr_6Context *aux_rule__pre_expr_6();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Pre_exprContext* pre_expr();

  class  Cmp_exprContext : public antlr4::ParserRuleContext {
  public:
    Cmp_exprContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Bit_or_exprContext *bit_or_expr();
    Optional__cmp_expr_2Context *optional__cmp_expr_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Cmp_exprContext* cmp_expr();

  class  Range_exprContext : public antlr4::ParserRuleContext {
  public:
    Range_exprContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__range_expr_9Context *aux_rule__range_expr_9();
    Aux_rule__range_expr_10Context *aux_rule__range_expr_10();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Range_exprContext* range_expr();

  class  Assign_exprContext : public antlr4::ParserRuleContext {
  public:
    Assign_exprContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Range_exprContext *range_expr();
    Optional__assign_expr_2Context *optional__assign_expr_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Assign_exprContext* assign_expr();

  class  Pre_expr_no_structContext : public antlr4::ParserRuleContext {
  public:
    Pre_expr_no_structContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Post_expr_no_structContext *post_expr_no_struct();
    Aux_rule__pre_expr_no_struct_4Context *aux_rule__pre_expr_no_struct_4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Pre_expr_no_structContext* pre_expr_no_struct();

  class  Cmp_expr_no_structContext : public antlr4::ParserRuleContext {
  public:
    Cmp_expr_no_structContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__cmp_expr_no_struct_6Context *optional__cmp_expr_no_struct_6();
    Bit_or_expr_no_structContext *bit_or_expr_no_struct();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Cmp_expr_no_structContext* cmp_expr_no_struct();

  class  Range_expr_no_structContext : public antlr4::ParserRuleContext {
  public:
    Range_expr_no_structContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__range_expr_no_struct_9Context *aux_rule__range_expr_no_struct_9();
    Aux_rule__range_expr_no_struct_10Context *aux_rule__range_expr_no_struct_10();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Range_expr_no_structContext* range_expr_no_struct();

  class  Assign_expr_no_structContext : public antlr4::ParserRuleContext {
  public:
    Assign_expr_no_structContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Range_expr_no_structContext *range_expr_no_struct();
    Optional__assign_expr_no_struct_2Context *optional__assign_expr_no_struct_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Assign_expr_no_structContext* assign_expr_no_struct();

  class  IdentContext : public antlr4::ParserRuleContext {
  public:
    IdentContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Ident();
    antlr4::tree::TerminalNode *RawIdentifier();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  IdentContext* ident();

  class  Any_identContext : public antlr4::ParserRuleContext {
  public:
    Any_identContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    IdentContext *ident();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Any_identContext* any_ident();

  class  Tokens_no_delimiters_cashContext : public antlr4::ParserRuleContext {
  public:
    Tokens_no_delimiters_cashContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *CashMoney();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Tokens_no_delimiters_cashContext* tokens_no_delimiters_cash();

  class  Tokens_no_delimiters_repetition_operatorsContext : public antlr4::ParserRuleContext {
  public:
    Tokens_no_delimiters_repetition_operatorsContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Tokens_no_delimiters_repetition_operatorsContext* tokens_no_delimiters_repetition_operators();

  class  Macro_rules_definitionContext : public antlr4::ParserRuleContext {
  public:
    Macro_rules_definitionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__param_4Context *optional__param_4();
    Macro_rules_defContext *macro_rules_def();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Macro_rules_definitionContext* macro_rules_definition();

  class  Macro_rules_defContext : public antlr4::ParserRuleContext {
  public:
    Macro_rules_defContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__macro_rules_def_5Context *aux_rule__macro_rules_def_5();
    Aux_rule__macro_rules_def_6Context *aux_rule__macro_rules_def_6();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Macro_rules_defContext* macro_rules_def();

  class  Macro_rulesContext : public antlr4::ParserRuleContext {
  public:
    Macro_rulesContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Macro_ruleContext *macro_rule();
    Kleene_star__macro_rules_2Context *kleene_star__macro_rules_2();
    Optional__macro_rules_3Context *optional__macro_rules_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Macro_rulesContext* macro_rules();

  class  Macro_ruleContext : public antlr4::ParserRuleContext {
  public:
    Macro_ruleContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Macro_matcherContext *macro_matcher();
    Macro_transcriberContext *macro_transcriber();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Macro_ruleContext* macro_rule();

  class  Macro_matcherContext : public antlr4::ParserRuleContext {
  public:
    Macro_matcherContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__macro_matcher_4Context *aux_rule__macro_matcher_4();
    Aux_rule__macro_matcher_5Context *aux_rule__macro_matcher_5();
    Aux_rule__macro_matcher_6Context *aux_rule__macro_matcher_6();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Macro_matcherContext* macro_matcher();

  class  Macro_matchContext : public antlr4::ParserRuleContext {
  public:
    Macro_matchContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Tokens_no_delimiters_cashContext *tokens_no_delimiters_cash();
    Macro_matcherContext *macro_matcher();
    Aux_rule__macro_match_4Context *aux_rule__macro_match_4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Macro_matchContext* macro_match();

  class  Macro_rep_sepContext : public antlr4::ParserRuleContext {
  public:
    Macro_rep_sepContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Tokens_no_delimiters_repetition_operatorsContext *tokens_no_delimiters_repetition_operators();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Macro_rep_sepContext* macro_rep_sep();

  class  Macro_rep_opContext : public antlr4::ParserRuleContext {
  public:
    Macro_rep_opContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Macro_rep_opContext* macro_rep_op();

  class  Macro_transcriberContext : public antlr4::ParserRuleContext {
  public:
    Macro_transcriberContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Delim_token_treeContext *delim_token_tree();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Macro_transcriberContext* macro_transcriber();

  class  Delim_token_treeContext : public antlr4::ParserRuleContext {
  public:
    Delim_token_treeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__delim_token_tree_4Context *aux_rule__delim_token_tree_4();
    Aux_rule__delim_token_tree_5Context *aux_rule__delim_token_tree_5();
    Aux_rule__delim_token_tree_6Context *aux_rule__delim_token_tree_6();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Delim_token_treeContext* delim_token_tree();

  class  Macro_invocation_semiContext : public antlr4::ParserRuleContext {
  public:
    Macro_invocation_semiContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Simple_pathContext *simple_path();
    Altnt_block__macro_invocation_semi_4Context *altnt_block__macro_invocation_semi_4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Macro_invocation_semiContext* macro_invocation_semi();

  class  Macro_invocationContext : public antlr4::ParserRuleContext {
  public:
    Macro_invocationContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Simple_pathContext *simple_path();
    Delim_token_treeContext *delim_token_tree();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Macro_invocationContext* macro_invocation();

  class  LifetimeContext : public antlr4::ParserRuleContext {
  public:
    LifetimeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Lifetime();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  LifetimeContext* lifetime();

  class  Kleene_star__mod_body_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__mod_body_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Inner_attrContext *> inner_attr();
    Inner_attrContext* inner_attr(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__mod_body_1Context* kleene_star__mod_body_1();

  class  Kleene_star__mod_body_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__mod_body_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<ItemContext *> item();
    ItemContext* item(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__mod_body_2Context* kleene_star__mod_body_2();

  class  Optional__visibility_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__visibility_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Visibility_restrictionContext *visibility_restriction();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__visibility_1Context* optional__visibility_1();

  class  Kleene_star__item_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__item_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<AttrContext *> attr();
    AttrContext* attr(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__item_1Context* kleene_star__item_1();

  class  Optional__item_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__item_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    VisibilityContext *visibility();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__item_2Context* optional__item_2();

  class  Optional__extern_crate_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__extern_crate_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    RenameContext *rename();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__extern_crate_1Context* optional__extern_crate_1();

  class  Optional__use_path_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__use_path_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Use_item_listContext *use_item_list();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__use_path_2Context* optional__use_path_2();

  class  Aux_rule__use_path_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__use_path_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Any_identContext *any_ident();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__use_path_4Context* aux_rule__use_path_4();

  class  Kleene_star__use_path_5Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__use_path_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__use_path_4Context *> aux_rule__use_path_4();
    Aux_rule__use_path_4Context* aux_rule__use_path_4(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__use_path_5Context* kleene_star__use_path_5();

  class  Optional__use_path_6Context : public antlr4::ParserRuleContext {
  public:
    Optional__use_path_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Use_suffixContext *use_suffix();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__use_path_6Context* optional__use_path_6();

  class  Aux_rule__use_item_list_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__use_item_list_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Use_itemContext *use_item();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__use_item_list_1Context* aux_rule__use_item_list_1();

  class  Kleene_star__use_item_list_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__use_item_list_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__use_item_list_1Context *> aux_rule__use_item_list_1();
    Aux_rule__use_item_list_1Context* aux_rule__use_item_list_1(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__use_item_list_2Context* kleene_star__use_item_list_2();

  class  Optional__use_item_list_3Context : public antlr4::ParserRuleContext {
  public:
    Optional__use_item_list_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__use_item_list_3Context* optional__use_item_list_3();

  class  Kleene_star__extern_mod_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__extern_mod_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Foreign_itemContext *> foreign_item();
    Foreign_itemContext* foreign_item(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__extern_mod_2Context* kleene_star__extern_mod_2();

  class  Aux_rule__foreign_item_tail_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__foreign_item_tail_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ExprContext *expr();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__foreign_item_tail_2Context* aux_rule__foreign_item_tail_2();

  class  Optional__foreign_item_tail_3Context : public antlr4::ParserRuleContext {
  public:
    Optional__foreign_item_tail_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__foreign_item_tail_2Context *aux_rule__foreign_item_tail_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__foreign_item_tail_3Context* optional__foreign_item_tail_3();

  class  Optional__static_decl_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__static_decl_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__static_decl_1Context* optional__static_decl_1();

  class  Aux_rule__associated_const_decl_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__associated_const_decl_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Ty_sumContext *ty_sum();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__associated_const_decl_1Context* aux_rule__associated_const_decl_1();

  class  Optional__associated_const_decl_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__associated_const_decl_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__associated_const_decl_1Context *aux_rule__associated_const_decl_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__associated_const_decl_2Context* optional__associated_const_decl_2();

  class  Optional__fn_decl_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__fn_decl_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Param_listContext *param_list();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__fn_decl_1Context* optional__fn_decl_1();

  class  Optional__fn_decl_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__fn_decl_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Fn_rtypeContext *fn_rtype();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__fn_decl_2Context* optional__fn_decl_2();

  class  Optional__method_decl_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__method_decl_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Method_param_listContext *method_param_list();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__method_decl_1Context* optional__method_decl_1();

  class  Optional__trait_method_decl_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__trait_method_decl_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Trait_method_param_listContext *trait_method_param_list();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__trait_method_decl_1Context* optional__trait_method_decl_1();

  class  Optional__foreign_fn_decl_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__foreign_fn_decl_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Variadic_param_listContext *variadic_param_list();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__foreign_fn_decl_1Context* optional__foreign_fn_decl_1();

  class  Optional__foreign_fn_decl_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__foreign_fn_decl_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    RtypeContext *rtype();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__foreign_fn_decl_2Context* optional__foreign_fn_decl_2();

  class  Aux_rule__macro_decl_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__macro_decl_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__inner_attr_1Context *kleene_star__inner_attr_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__macro_decl_2Context* aux_rule__macro_decl_2();

  class  Optional__macro_decl_3Context : public antlr4::ParserRuleContext {
  public:
    Optional__macro_decl_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__macro_decl_2Context *aux_rule__macro_decl_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__macro_decl_3Context* optional__macro_decl_3();

  class  Optional__macro_head_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__macro_head_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Type_parameterContext *type_parameter();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__macro_head_1Context* optional__macro_head_1();

  class  Aux_rule__fn_head_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__fn_head_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__fn_head_1Context* aux_rule__fn_head_1();

  class  Kleene_star__fn_head_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__fn_head_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__fn_head_1Context *> aux_rule__fn_head_1();
    Aux_rule__fn_head_1Context* aux_rule__fn_head_1(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__fn_head_2Context* kleene_star__fn_head_2();

  class  Optional__fn_head_3Context : public antlr4::ParserRuleContext {
  public:
    Optional__fn_head_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Extern_abiContext *extern_abi();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__fn_head_3Context* optional__fn_head_3();

  class  Aux_rule__param_3Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__param_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__param_3Context* aux_rule__param_3();

  class  Optional__param_4Context : public antlr4::ParserRuleContext {
  public:
    Optional__param_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__param_3Context *aux_rule__param_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__param_4Context* optional__param_4();

  class  Optional__param_6Context : public antlr4::ParserRuleContext {
  public:
    Optional__param_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__param_6Context* optional__param_6();

  class  Aux_rule__param_list_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__param_list_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ParamContext *param();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__param_list_1Context* aux_rule__param_list_1();

  class  Kleene_star__param_list_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__param_list_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__param_list_1Context *> aux_rule__param_list_1();
    Aux_rule__param_list_1Context* aux_rule__param_list_1(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__param_list_2Context* kleene_star__param_list_2();

  class  Aux_rule__param_list_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__param_list_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__item_1Context *kleene_star__item_1();
    PatternContext *pattern();
    Mut_or_constContext *mut_or_const();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__param_list_4Context* aux_rule__param_list_4();

  class  Optional__param_list_5Context : public antlr4::ParserRuleContext {
  public:
    Optional__param_list_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__param_list_4Context *aux_rule__param_list_4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__param_list_5Context* optional__param_list_5();

  class  Aux_rule__variadic_param_list_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__variadic_param_list_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__item_1Context *kleene_star__item_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__variadic_param_list_4Context* aux_rule__variadic_param_list_4();

  class  Optional__variadic_param_list_5Context : public antlr4::ParserRuleContext {
  public:
    Optional__variadic_param_list_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__variadic_param_list_4Context *aux_rule__variadic_param_list_4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__variadic_param_list_5Context* optional__variadic_param_list_5();

  class  Aux_rule__trait_method_param_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__trait_method_param_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Restricted_patContext *restricted_pat();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__trait_method_param_2Context* aux_rule__trait_method_param_2();

  class  Kleene_star__trait_method_param_3Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__trait_method_param_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__trait_method_param_2Context *> aux_rule__trait_method_param_2();
    Aux_rule__trait_method_param_2Context* aux_rule__trait_method_param_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__trait_method_param_3Context* kleene_star__trait_method_param_3();

  class  Optional__restricted_pat_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__restricted_pat_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__restricted_pat_1Context* optional__restricted_pat_1();

  class  Aux_rule__restricted_pat_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__restricted_pat_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__restricted_pat_2Context* aux_rule__restricted_pat_2();

  class  Optional__restricted_pat_3Context : public antlr4::ParserRuleContext {
  public:
    Optional__restricted_pat_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__restricted_pat_2Context *aux_rule__restricted_pat_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__restricted_pat_3Context* optional__restricted_pat_3();

  class  Aux_rule__trait_method_param_list_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__trait_method_param_list_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Trait_method_paramContext *trait_method_param();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__trait_method_param_list_2Context* aux_rule__trait_method_param_list_2();

  class  Kleene_star__trait_method_param_list_3Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__trait_method_param_list_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__trait_method_param_list_2Context *> aux_rule__trait_method_param_list_2();
    Aux_rule__trait_method_param_list_2Context* aux_rule__trait_method_param_list_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__trait_method_param_list_3Context* kleene_star__trait_method_param_list_3();

  class  Optional__type_decl_4Context : public antlr4::ParserRuleContext {
  public:
    Optional__type_decl_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Colon_boundContext *colon_bound();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__type_decl_4Context* optional__type_decl_4();

  class  Aux_rule__type_decl_6Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__type_decl_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    TypeContext *type();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__type_decl_6Context* aux_rule__type_decl_6();

  class  Optional__type_decl_7Context : public antlr4::ParserRuleContext {
  public:
    Optional__type_decl_7Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__type_decl_6Context *aux_rule__type_decl_6();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__type_decl_7Context* optional__type_decl_7();

  class  Aux_rule__type_decl_8Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__type_decl_8Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    TypeContext *type();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__type_decl_8Context* aux_rule__type_decl_8();

  class  Optional__type_decl_9Context : public antlr4::ParserRuleContext {
  public:
    Optional__type_decl_9Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__type_decl_8Context *aux_rule__type_decl_8();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__type_decl_9Context* optional__type_decl_9();

  class  Optional__struct_tail_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__struct_tail_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Tuple_struct_field_listContext *tuple_struct_field_list();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__struct_tail_2Context* optional__struct_tail_2();

  class  Optional__struct_tail_5Context : public antlr4::ParserRuleContext {
  public:
    Optional__struct_tail_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Field_decl_listContext *field_decl_list();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__struct_tail_5Context* optional__struct_tail_5();

  class  Aux_rule__tuple_struct_field_list_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__tuple_struct_field_list_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Tuple_struct_fieldContext *tuple_struct_field();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__tuple_struct_field_list_1Context* aux_rule__tuple_struct_field_list_1();

  class  Kleene_star__tuple_struct_field_list_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__tuple_struct_field_list_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__tuple_struct_field_list_1Context *> aux_rule__tuple_struct_field_list_1();
    Aux_rule__tuple_struct_field_list_1Context* aux_rule__tuple_struct_field_list_1(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__tuple_struct_field_list_2Context* kleene_star__tuple_struct_field_list_2();

  class  Aux_rule__field_decl_list_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__field_decl_list_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Field_declContext *field_decl();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__field_decl_list_1Context* aux_rule__field_decl_list_1();

  class  Kleene_star__field_decl_list_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__field_decl_list_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__field_decl_list_1Context *> aux_rule__field_decl_list_1();
    Aux_rule__field_decl_list_1Context* aux_rule__field_decl_list_1(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__field_decl_list_2Context* kleene_star__field_decl_list_2();

  class  Optional__enum_decl_3Context : public antlr4::ParserRuleContext {
  public:
    Optional__enum_decl_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Enum_variant_listContext *enum_variant_list();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__enum_decl_3Context* optional__enum_decl_3();

  class  Aux_rule__enum_variant_3Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__enum_variant_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    LitContext *lit();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__enum_variant_3Context* aux_rule__enum_variant_3();

  class  Optional__enum_variant_4Context : public antlr4::ParserRuleContext {
  public:
    Optional__enum_variant_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__enum_variant_3Context *aux_rule__enum_variant_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__enum_variant_4Context* optional__enum_variant_4();

  class  Aux_rule__enum_variant_list_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__enum_variant_list_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Enum_variantContext *enum_variant();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__enum_variant_list_1Context* aux_rule__enum_variant_list_1();

  class  Kleene_star__enum_variant_list_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__enum_variant_list_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__enum_variant_list_1Context *> aux_rule__enum_variant_list_1();
    Aux_rule__enum_variant_list_1Context* aux_rule__enum_variant_list_1(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__enum_variant_list_2Context* kleene_star__enum_variant_list_2();

  class  Optional__enum_variant_main_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__enum_variant_main_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Enum_tuple_field_listContext *enum_tuple_field_list();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__enum_variant_main_1Context* optional__enum_variant_main_1();

  class  Aux_rule__enum_tuple_field_list_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__enum_tuple_field_list_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Enum_tuple_fieldContext *enum_tuple_field();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__enum_tuple_field_list_1Context* aux_rule__enum_tuple_field_list_1();

  class  Kleene_star__enum_tuple_field_list_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__enum_tuple_field_list_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__enum_tuple_field_list_1Context *> aux_rule__enum_tuple_field_list_1();
    Aux_rule__enum_tuple_field_list_1Context* aux_rule__enum_tuple_field_list_1(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__enum_tuple_field_list_2Context* kleene_star__enum_tuple_field_list_2();

  class  Optional__trait_decl_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__trait_decl_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__trait_decl_2Context* optional__trait_decl_2();

  class  Kleene_star__trait_decl_7Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__trait_decl_7Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Trait_itemContext *> trait_item();
    Trait_itemContext* trait_item(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__trait_decl_7Context* kleene_star__trait_decl_7();

  class  Optional__impl_block_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__impl_block_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__impl_block_1Context* optional__impl_block_1();

  class  Optional__impl_block_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__impl_block_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__impl_block_2Context* optional__impl_block_2();

  class  Optional__impl_block_3Context : public antlr4::ParserRuleContext {
  public:
    Optional__impl_block_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Type_parametersContext *type_parameters();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__impl_block_3Context* optional__impl_block_3();

  class  Optional__impl_block_4Context : public antlr4::ParserRuleContext {
  public:
    Optional__impl_block_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__impl_block_4Context* optional__impl_block_4();

  class  Optional__impl_block_5Context : public antlr4::ParserRuleContext {
  public:
    Optional__impl_block_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__impl_block_5Context* optional__impl_block_5();

  class  Optional__impl_block_6Context : public antlr4::ParserRuleContext {
  public:
    Optional__impl_block_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Where_clauseContext *where_clause();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__impl_block_6Context* optional__impl_block_6();

  class  Kleene_star__impl_block_7Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__impl_block_7Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Impl_itemContext *> impl_item();
    Impl_itemContext* impl_item(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__impl_block_7Context* kleene_star__impl_block_7();

  class  Aux_rule__impl_item_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__impl_item_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    AttrContext *attr();
    Inner_attrContext *inner_attr();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__impl_item_1Context* aux_rule__impl_item_1();

  class  Kleene_star__impl_item_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__impl_item_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__impl_item_1Context *> aux_rule__impl_item_1();
    Aux_rule__impl_item_1Context* aux_rule__impl_item_1(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__impl_item_2Context* kleene_star__impl_item_2();

  class  Aux_rule__impl_item_tail_11Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__impl_item_tail_11Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__inner_attr_1Context *kleene_star__inner_attr_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__impl_item_tail_11Context* aux_rule__impl_item_tail_11();

  class  Optional__impl_item_tail_12Context : public antlr4::ParserRuleContext {
  public:
    Optional__impl_item_tail_12Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__impl_item_tail_11Context *aux_rule__impl_item_tail_11();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__impl_item_tail_12Context* optional__impl_item_tail_12();

  class  Kleene_star__inner_attr_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__inner_attr_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<TtContext *> tt();
    TtContext* tt(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__inner_attr_1Context* kleene_star__inner_attr_1();

  class  Optional__path_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__path_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Path_parentContext *path_parent();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__path_1Context* optional__path_1();

  class  Optional__path_parent_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__path_parent_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    As_traitContext *as_trait();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__path_parent_1Context* optional__path_parent_1();

  class  Aux_rule__path_segment_no_super_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__path_segment_no_super_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Type_argumentsContext *type_arguments();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__path_segment_no_super_1Context* aux_rule__path_segment_no_super_1();

  class  Optional__path_segment_no_super_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__path_segment_no_super_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__path_segment_no_super_1Context *aux_rule__path_segment_no_super_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__path_segment_no_super_2Context* optional__path_segment_no_super_2();

  class  Optional__simple_path_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__simple_path_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__simple_path_1Context* optional__simple_path_1();

  class  Aux_rule__simple_path_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__simple_path_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Simple_path_segmentContext *simple_path_segment();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__simple_path_2Context* aux_rule__simple_path_2();

  class  Kleene_star__simple_path_3Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__simple_path_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__simple_path_2Context *> aux_rule__simple_path_2();
    Aux_rule__simple_path_2Context* aux_rule__simple_path_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__simple_path_3Context* kleene_star__simple_path_3();

  class  Optional__for_lifetimes_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__for_lifetimes_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Lifetime_def_listContext *lifetime_def_list();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__for_lifetimes_1Context* optional__for_lifetimes_1();

  class  Aux_rule__lifetime_def_list_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__lifetime_def_list_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Lifetime_defContext *lifetime_def();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__lifetime_def_list_1Context* aux_rule__lifetime_def_list_1();

  class  Kleene_star__lifetime_def_list_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__lifetime_def_list_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__lifetime_def_list_1Context *> aux_rule__lifetime_def_list_1();
    Aux_rule__lifetime_def_list_1Context* aux_rule__lifetime_def_list_1(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__lifetime_def_list_2Context* kleene_star__lifetime_def_list_2();

  class  Aux_rule__lifetime_def_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__lifetime_def_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Lifetime_boundContext *lifetime_bound();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__lifetime_def_1Context* aux_rule__lifetime_def_1();

  class  Optional__lifetime_def_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__lifetime_def_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__lifetime_def_1Context *aux_rule__lifetime_def_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__lifetime_def_2Context* optional__lifetime_def_2();

  class  Optional__type_path_main_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__type_path_main_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Ty_path_parentContext *ty_path_parent();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__type_path_main_1Context* optional__type_path_main_1();

  class  Optional__ty_path_tail_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__ty_path_tail_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Ty_sum_listContext *ty_sum_list();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__ty_path_tail_1Context* optional__ty_path_tail_1();

  class  Optional__ty_path_segment_no_super_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__ty_path_segment_no_super_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__ty_path_tail_3Context *altnt_block__ty_path_tail_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__ty_path_segment_no_super_2Context* optional__ty_path_segment_no_super_2();

  class  Optional__ty_path_segment_no_super_3Context : public antlr4::ParserRuleContext {
  public:
    Optional__ty_path_segment_no_super_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Type_argumentsContext *type_arguments();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__ty_path_segment_no_super_3Context* optional__ty_path_segment_no_super_3();

  class  Aux_rule__where_bound_list_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__where_bound_list_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Where_boundContext *where_bound();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__where_bound_list_1Context* aux_rule__where_bound_list_1();

  class  Kleene_star__where_bound_list_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__where_bound_list_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__where_bound_list_1Context *> aux_rule__where_bound_list_1();
    Aux_rule__where_bound_list_1Context* aux_rule__where_bound_list_1(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__where_bound_list_2Context* kleene_star__where_bound_list_2();

  class  Optional__where_bound_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__where_bound_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    For_lifetimesContext *for_lifetimes();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__where_bound_1Context* optional__where_bound_1();

  class  Optional__where_bound_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__where_bound_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Empty_ok_colon_boundContext *empty_ok_colon_bound();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__where_bound_2Context* optional__where_bound_2();

  class  Optional__empty_ok_colon_bound_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__empty_ok_colon_bound_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    BoundContext *bound();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__empty_ok_colon_bound_1Context* optional__empty_ok_colon_bound_1();

  class  Aux_rule__prim_bound_3Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__prim_bound_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__prim_bound_3Context* aux_rule__prim_bound_3();

  class  Optional__prim_bound_4Context : public antlr4::ParserRuleContext {
  public:
    Optional__prim_bound_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__prim_bound_3Context *aux_rule__prim_bound_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__prim_bound_4Context* optional__prim_bound_4();

  class  Aux_rule__prim_bound_5Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__prim_bound_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__prim_bound_6Context *aux_rule__prim_bound_6();
    LifetimeContext *lifetime();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__prim_bound_5Context* aux_rule__prim_bound_5();

  class  Optional__type_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__type_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    LifetimeContext *lifetime();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__type_1Context* optional__type_1();

  class  Aux_rule__array_or_slice_type_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__array_or_slice_type_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ExprContext *expr();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__array_or_slice_type_1Context* aux_rule__array_or_slice_type_1();

  class  Optional__array_or_slice_type_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__array_or_slice_type_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__array_or_slice_type_1Context *aux_rule__array_or_slice_type_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__array_or_slice_type_2Context* optional__array_or_slice_type_2();

  class  Aux_rule__type_param_bounds_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__type_param_bounds_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Type_param_boundContext *type_param_bound();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__type_param_bounds_1Context* aux_rule__type_param_bounds_1();

  class  Kleene_star__type_param_bounds_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__type_param_bounds_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__type_param_bounds_1Context *> aux_rule__type_param_bounds_1();
    Aux_rule__type_param_bounds_1Context* aux_rule__type_param_bounds_1(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__type_param_bounds_2Context* kleene_star__type_param_bounds_2();

  class  Optional__type_param_bounds_3Context : public antlr4::ParserRuleContext {
  public:
    Optional__type_param_bounds_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__type_param_bounds_3Context* optional__type_param_bounds_3();

  class  Optional__trait_object_type_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__trait_object_type_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Type_param_boundsContext *type_param_bounds();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__trait_object_type_2Context* optional__trait_object_type_2();

  class  Optional__bare_function_type_4Context : public antlr4::ParserRuleContext {
  public:
    Optional__bare_function_type_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Variadic_param_list_names_optionalContext *variadic_param_list_names_optional();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__bare_function_type_4Context* optional__bare_function_type_4();

  class  Optional__extern_abi_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__extern_abi_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *StringLit();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__extern_abi_1Context* optional__extern_abi_1();

  class  Aux_rule__type_arguments_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__type_arguments_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__type_arguments_10Context *altnt_block__type_arguments_10();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__type_arguments_1Context* aux_rule__type_arguments_1();

  class  Kleene_star__type_arguments_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__type_arguments_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__type_arguments_1Context *> aux_rule__type_arguments_1();
    Aux_rule__type_arguments_1Context* aux_rule__type_arguments_1(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__type_arguments_2Context* kleene_star__type_arguments_2();

  class  Aux_rule__type_arguments_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__type_arguments_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    LifetimeContext *lifetime();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__type_arguments_4Context* aux_rule__type_arguments_4();

  class  Kleene_star__type_arguments_5Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__type_arguments_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__type_arguments_4Context *> aux_rule__type_arguments_4();
    Aux_rule__type_arguments_4Context* aux_rule__type_arguments_4(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__type_arguments_5Context* kleene_star__type_arguments_5();

  class  Aux_rule__type_arguments_6Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__type_arguments_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Type_argumentContext *type_argument();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__type_arguments_6Context* aux_rule__type_arguments_6();

  class  Kleene_star__type_arguments_7Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__type_arguments_7Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__type_arguments_6Context *> aux_rule__type_arguments_6();
    Aux_rule__type_arguments_6Context* aux_rule__type_arguments_6(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__type_arguments_7Context* kleene_star__type_arguments_7();

  class  Optional__ty_sum_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__ty_sum_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__ty_sum_1Context* optional__ty_sum_1();

  class  Aux_rule__ty_sum_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__ty_sum_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    BoundContext *bound();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__ty_sum_2Context* aux_rule__ty_sum_2();

  class  Optional__ty_sum_3Context : public antlr4::ParserRuleContext {
  public:
    Optional__ty_sum_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__ty_sum_2Context *aux_rule__ty_sum_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__ty_sum_3Context* optional__ty_sum_3();

  class  Aux_rule__ty_sum_list_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__ty_sum_list_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Ty_sumContext *ty_sum();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__ty_sum_list_1Context* aux_rule__ty_sum_list_1();

  class  Kleene_star__ty_sum_list_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__ty_sum_list_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__ty_sum_list_1Context *> aux_rule__ty_sum_list_1();
    Aux_rule__ty_sum_list_1Context* aux_rule__ty_sum_list_1(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__ty_sum_list_2Context* kleene_star__ty_sum_list_2();

  class  Aux_rule__type_parameters_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__type_parameters_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Lifetime_paramContext *lifetime_param();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__type_parameters_1Context* aux_rule__type_parameters_1();

  class  Kleene_star__type_parameters_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__type_parameters_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__type_parameters_1Context *> aux_rule__type_parameters_1();
    Aux_rule__type_parameters_1Context* aux_rule__type_parameters_1(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__type_parameters_2Context* kleene_star__type_parameters_2();

  class  Optional__type_parameters_3Context : public antlr4::ParserRuleContext {
  public:
    Optional__type_parameters_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Type_parameter_listContext *type_parameter_list();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__type_parameters_3Context* optional__type_parameters_3();

  class  Aux_rule__lifetime_param_list_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__lifetime_param_list_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Lifetime_paramContext *lifetime_param();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__lifetime_param_list_1Context* aux_rule__lifetime_param_list_1();

  class  Kleene_star__lifetime_param_list_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__lifetime_param_list_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__lifetime_param_list_1Context *> aux_rule__lifetime_param_list_1();
    Aux_rule__lifetime_param_list_1Context* aux_rule__lifetime_param_list_1(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__lifetime_param_list_2Context* kleene_star__lifetime_param_list_2();

  class  Optional__type_parameter_4Context : public antlr4::ParserRuleContext {
  public:
    Optional__type_parameter_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Ty_defaultContext *ty_default();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__type_parameter_4Context* optional__type_parameter_4();

  class  Aux_rule__type_parameter_list_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__type_parameter_list_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Type_parameterContext *type_parameter();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__type_parameter_list_1Context* aux_rule__type_parameter_list_1();

  class  Kleene_star__type_parameter_list_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__type_parameter_list_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__type_parameter_list_1Context *> aux_rule__type_parameter_list_1();
    Aux_rule__type_parameter_list_1Context* aux_rule__type_parameter_list_1(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__type_parameter_list_2Context* kleene_star__type_parameter_list_2();

  class  Aux_rule__pattern_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__pattern_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    PatternContext *pattern();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__pattern_1Context* aux_rule__pattern_1();

  class  Optional__pattern_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__pattern_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__pattern_1Context *aux_rule__pattern_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__pattern_2Context* optional__pattern_2();

  class  Optional__pattern_without_mut_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__pattern_without_mut_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__pattern_without_mut_1Context* optional__pattern_without_mut_1();

  class  Aux_rule__pattern_without_mut_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__pattern_without_mut_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Match_patternContext *match_pattern();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__pattern_without_mut_2Context* aux_rule__pattern_without_mut_2();

  class  Optional__pattern_without_mut_3Context : public antlr4::ParserRuleContext {
  public:
    Optional__pattern_without_mut_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__pattern_without_mut_2Context *aux_rule__pattern_without_mut_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__pattern_without_mut_3Context* optional__pattern_without_mut_3();

  class  Aux_rule__pattern_without_mut_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__pattern_without_mut_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Pat_identContext *pat_ident();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__pattern_without_mut_4Context* aux_rule__pattern_without_mut_4();

  class  Kleene_star__pattern_without_mut_5Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__pattern_without_mut_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__pattern_without_mut_4Context *> aux_rule__pattern_without_mut_4();
    Aux_rule__pattern_without_mut_4Context* aux_rule__pattern_without_mut_4(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__pattern_without_mut_5Context* kleene_star__pattern_without_mut_5();

  class  Optional__pattern_without_mut_12Context : public antlr4::ParserRuleContext {
  public:
    Optional__pattern_without_mut_12Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Pat_list_with_dotsContext *pat_list_with_dots();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__pattern_without_mut_12Context* optional__pattern_without_mut_12();

  class  Optional__pattern_without_mut_13Context : public antlr4::ParserRuleContext {
  public:
    Optional__pattern_without_mut_13Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Pat_fieldsContext *pat_fields();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__pattern_without_mut_13Context* optional__pattern_without_mut_13();

  class  Aux_rule__pattern_without_mut_15Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__pattern_without_mut_15Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    PatternContext *pattern();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__pattern_without_mut_15Context* aux_rule__pattern_without_mut_15();

  class  Kleene_star__pattern_without_mut_16Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__pattern_without_mut_16Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__pattern_without_mut_15Context *> aux_rule__pattern_without_mut_15();
    Aux_rule__pattern_without_mut_15Context* aux_rule__pattern_without_mut_15(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__pattern_without_mut_16Context* kleene_star__pattern_without_mut_16();

  class  Optional__pat_lit_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__pat_lit_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__pat_lit_1Context* optional__pat_lit_1();

  class  Optional__pat_list_with_dots_3Context : public antlr4::ParserRuleContext {
  public:
    Optional__pat_list_with_dots_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Pat_list_dots_tailContext *pat_list_dots_tail();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__pat_list_with_dots_3Context* optional__pat_list_with_dots_3();

  class  Aux_rule__pat_list_with_dots_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__pat_list_with_dots_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__pat_list_with_dots_3Context *optional__pat_list_with_dots_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__pat_list_with_dots_4Context* aux_rule__pat_list_with_dots_4();

  class  Optional__pat_list_with_dots_5Context : public antlr4::ParserRuleContext {
  public:
    Optional__pat_list_with_dots_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__pat_list_with_dots_4Context *aux_rule__pat_list_with_dots_4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__pat_list_with_dots_5Context* optional__pat_list_with_dots_5();

  class  Aux_rule__pat_list_dots_tail_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__pat_list_dots_tail_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__pattern_without_mut_21Context *aux_rule__pattern_without_mut_21();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__pat_list_dots_tail_1Context* aux_rule__pat_list_dots_tail_1();

  class  Optional__pat_list_dots_tail_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__pat_list_dots_tail_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__pat_list_dots_tail_1Context *aux_rule__pat_list_dots_tail_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__pat_list_dots_tail_2Context* optional__pat_list_dots_tail_2();

  class  Aux_rule__pat_fields_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__pat_fields_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__pat_fields_6Context *altnt_block__pat_fields_6();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__pat_fields_1Context* aux_rule__pat_fields_1();

  class  Kleene_star__pat_fields_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__pat_fields_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__pat_fields_1Context *> aux_rule__pat_fields_1();
    Aux_rule__pat_fields_1Context* aux_rule__pat_fields_1(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__pat_fields_2Context* kleene_star__pat_fields_2();

  class  Aux_rule__pat_fields_3Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__pat_fields_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Pat_fieldContext *pat_field();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__pat_fields_3Context* aux_rule__pat_fields_3();

  class  Kleene_star__pat_fields_4Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__pat_fields_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__pat_fields_3Context *> aux_rule__pat_fields_3();
    Aux_rule__pat_fields_3Context* aux_rule__pat_fields_3(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__pat_fields_4Context* kleene_star__pat_fields_4();

  class  Optional__pat_field_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__pat_field_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__pat_field_2Context* optional__pat_field_2();

  class  Optional__expr_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__expr_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__expr_1Context* optional__expr_1();

  class  Optional__expr_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__expr_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Mut_or_constContext *mut_or_const();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__expr_2Context* optional__expr_2();

  class  Aux_rule__expr_list_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__expr_list_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ExprContext *expr();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__expr_list_1Context* aux_rule__expr_list_1();

  class  Kleene_star__expr_list_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__expr_list_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__expr_list_1Context *> aux_rule__expr_list_1();
    Aux_rule__expr_list_1Context* aux_rule__expr_list_1(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__expr_list_2Context* kleene_star__expr_list_2();

  class  Kleene_star__block_with_inner_attrs_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__block_with_inner_attrs_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<StmtContext *> stmt();
    StmtContext* stmt(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__block_with_inner_attrs_2Context* kleene_star__block_with_inner_attrs_2();

  class  Optional__block_with_inner_attrs_3Context : public antlr4::ParserRuleContext {
  public:
    Optional__block_with_inner_attrs_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ExprContext *expr();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__block_with_inner_attrs_3Context* optional__block_with_inner_attrs_3();

  class  Aux_rule__blocky_expr_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__blocky_expr_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    If_cond_or_patContext *if_cond_or_pat();
    BlockContext *block();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__blocky_expr_1Context* aux_rule__blocky_expr_1();

  class  Kleene_star__blocky_expr_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__blocky_expr_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__blocky_expr_1Context *> aux_rule__blocky_expr_1();
    Aux_rule__blocky_expr_1Context* aux_rule__blocky_expr_1(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__blocky_expr_2Context* kleene_star__blocky_expr_2();

  class  Aux_rule__blocky_expr_3Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__blocky_expr_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    BlockContext *block();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__blocky_expr_3Context* aux_rule__blocky_expr_3();

  class  Optional__blocky_expr_4Context : public antlr4::ParserRuleContext {
  public:
    Optional__blocky_expr_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__blocky_expr_3Context *aux_rule__blocky_expr_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__blocky_expr_4Context* optional__blocky_expr_4();

  class  Optional__blocky_expr_5Context : public antlr4::ParserRuleContext {
  public:
    Optional__blocky_expr_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Inner_attrContext *inner_attr();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__blocky_expr_5Context* optional__blocky_expr_5();

  class  Optional__blocky_expr_6Context : public antlr4::ParserRuleContext {
  public:
    Optional__blocky_expr_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Match_armsContext *match_arms();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__blocky_expr_6Context* optional__blocky_expr_6();

  class  Optional__blocky_expr_7Context : public antlr4::ParserRuleContext {
  public:
    Optional__blocky_expr_7Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Loop_labelContext *loop_label();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__blocky_expr_7Context* optional__blocky_expr_7();

  class  Aux_rule__match_arms_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__match_arms_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__blocky_expr_6Context *optional__blocky_expr_6();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__match_arms_4Context* aux_rule__match_arms_4();

  class  Optional__match_arms_5Context : public antlr4::ParserRuleContext {
  public:
    Optional__match_arms_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__match_arms_4Context *aux_rule__match_arms_4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__match_arms_5Context* optional__match_arms_5();

  class  Optional__match_arm_intro_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__match_arm_intro_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Match_if_clauseContext *match_if_clause();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__match_arm_intro_2Context* optional__match_arm_intro_2();

  class  Aux_rule__match_pattern_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__match_pattern_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    PatternContext *pattern();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__match_pattern_2Context* aux_rule__match_pattern_2();

  class  Kleene_star__match_pattern_3Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__match_pattern_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__match_pattern_2Context *> aux_rule__match_pattern_2();
    Aux_rule__match_pattern_2Context* aux_rule__match_pattern_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__match_pattern_3Context* kleene_star__match_pattern_3();

  class  Optional__prim_expr_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__prim_expr_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Expr_inner_attrsContext *expr_inner_attrs();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__prim_expr_1Context* optional__prim_expr_1();

  class  Optional__prim_expr_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__prim_expr_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    FieldsContext *fields();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__prim_expr_2Context* optional__prim_expr_2();

  class  Optional__prim_expr_no_struct_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__prim_expr_no_struct_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Macro_tailContext *macro_tail();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__prim_expr_no_struct_1Context* optional__prim_expr_no_struct_1();

  class  Optional__prim_expr_no_struct_5Context : public antlr4::ParserRuleContext {
  public:
    Optional__prim_expr_no_struct_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Expr_listContext *expr_list();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__prim_expr_no_struct_5Context* optional__prim_expr_no_struct_5();

  class  Optional__prim_expr_no_struct_9Context : public antlr4::ParserRuleContext {
  public:
    Optional__prim_expr_no_struct_9Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__prim_expr_no_struct_9Context* optional__prim_expr_no_struct_9();

  class  Optional__prim_expr_no_struct_10Context : public antlr4::ParserRuleContext {
  public:
    Optional__prim_expr_no_struct_10Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__prim_expr_no_struct_10Context* optional__prim_expr_no_struct_10();

  class  Optional__prim_expr_no_struct_11Context : public antlr4::ParserRuleContext {
  public:
    Optional__prim_expr_no_struct_11Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Lifetime_or_exprContext *lifetime_or_expr();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__prim_expr_no_struct_11Context* optional__prim_expr_no_struct_11();

  class  Optional__prim_expr_no_struct_12Context : public antlr4::ParserRuleContext {
  public:
    Optional__prim_expr_no_struct_12Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    LitContext *lit();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__prim_expr_no_struct_12Context* optional__prim_expr_no_struct_12();

  class  Optional__prim_expr_no_struct_13Context : public antlr4::ParserRuleContext {
  public:
    Optional__prim_expr_no_struct_13Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ItemContext *item();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__prim_expr_no_struct_13Context* optional__prim_expr_no_struct_13();

  class  Optional__closure_params_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__closure_params_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Closure_param_listContext *closure_param_list();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__closure_params_1Context* optional__closure_params_1();

  class  Aux_rule__closure_param_list_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__closure_param_list_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Closure_paramContext *closure_param();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__closure_param_list_1Context* aux_rule__closure_param_list_1();

  class  Kleene_star__closure_param_list_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__closure_param_list_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__closure_param_list_1Context *> aux_rule__closure_param_list_1();
    Aux_rule__closure_param_list_1Context* aux_rule__closure_param_list_1(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__closure_param_list_2Context* kleene_star__closure_param_list_2();

  class  Aux_rule__fields_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__fields_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    FieldContext *field();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__fields_1Context* aux_rule__fields_1();

  class  Kleene_star__fields_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__fields_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__fields_1Context *> aux_rule__fields_1();
    Aux_rule__fields_1Context* aux_rule__fields_1(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__fields_2Context* kleene_star__fields_2();

  class  Kleene_star__field_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__field_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Expr_attrsContext *> expr_attrs();
    Expr_attrsContext* expr_attrs(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__field_1Context* kleene_star__field_1();

  class  Aux_rule__post_expr_tail_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__post_expr_tail_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__path_segment_no_super_2Context *optional__path_segment_no_super_2();
    Optional__prim_expr_no_struct_5Context *optional__prim_expr_no_struct_5();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__post_expr_tail_4Context* aux_rule__post_expr_tail_4();

  class  Optional__post_expr_tail_5Context : public antlr4::ParserRuleContext {
  public:
    Optional__post_expr_tail_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__post_expr_tail_4Context *aux_rule__post_expr_tail_4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__post_expr_tail_5Context* optional__post_expr_tail_5();

  class  Optional__range_expr_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__range_expr_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Or_exprContext *or_expr();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__range_expr_1Context* optional__range_expr_1();

  class  Optional__range_expr_no_struct_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__range_expr_no_struct_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Or_expr_no_structContext *or_expr_no_struct();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__range_expr_no_struct_1Context* optional__range_expr_no_struct_1();

  class  Optional__macro_rules_def_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__macro_rules_def_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Macro_rulesContext *macro_rules();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__macro_rules_def_1Context* optional__macro_rules_def_1();

  class  Aux_rule__macro_rules_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__macro_rules_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Macro_ruleContext *macro_rule();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__macro_rules_1Context* aux_rule__macro_rules_1();

  class  Kleene_star__macro_rules_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__macro_rules_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__macro_rules_1Context *> aux_rule__macro_rules_1();
    Aux_rule__macro_rules_1Context* aux_rule__macro_rules_1(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__macro_rules_2Context* kleene_star__macro_rules_2();

  class  Optional__macro_rules_3Context : public antlr4::ParserRuleContext {
  public:
    Optional__macro_rules_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__macro_rules_3Context* optional__macro_rules_3();

  class  Kleene_star__macro_matcher_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__macro_matcher_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Macro_matchContext *> macro_match();
    Macro_matchContext* macro_match(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__macro_matcher_1Context* kleene_star__macro_matcher_1();

  class  Kleene_plus__macro_match_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_plus__macro_match_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Macro_matchContext *> macro_match();
    Macro_matchContext* macro_match(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_plus__macro_match_1Context* kleene_plus__macro_match_1();

  class  Optional__macro_match_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__macro_match_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Macro_rep_sepContext *macro_rep_sep();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__macro_match_2Context* optional__macro_match_2();

  class  Aux_rule__bound_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__bound_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__bound_5Context *aux_rule__bound_5();
    Aux_rule__bound_6Context *aux_rule__bound_6();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__bound_4Context* aux_rule__bound_4();

  class  Kleene_star__bound_3Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__bound_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__bound_4Context *> aux_rule__bound_4();
    Aux_rule__bound_4Context* aux_rule__bound_4(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__bound_3Context* kleene_star__bound_3();

  class  BoundContext : public antlr4::ParserRuleContext {
  public:
    BoundContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Prim_boundContext *prim_bound();
    Kleene_star__bound_3Context *kleene_star__bound_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  BoundContext* bound();

  class  Aux_rule__path_parent_3Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__path_parent_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Path_segmentContext *path_segment();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__path_parent_3Context* aux_rule__path_parent_3();

  class  Kleene_star__path_parent_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__path_parent_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__path_parent_3Context *> aux_rule__path_parent_3();
    Aux_rule__path_parent_3Context* aux_rule__path_parent_3(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__path_parent_2Context* kleene_star__path_parent_2();

  class  Aux_rule__path_parent_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__path_parent_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__path_parent_6Context *aux_rule__path_parent_6();
    Aux_rule__path_parent_7Context *aux_rule__path_parent_7();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__path_parent_4Context* aux_rule__path_parent_4();

  class  Path_parentContext : public antlr4::ParserRuleContext {
  public:
    Path_parentContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__path_parent_4Context *aux_rule__path_parent_4();
    Kleene_star__path_parent_2Context *kleene_star__path_parent_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Path_parentContext* path_parent();

  class  Aux_rule__lifetime_bound_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__lifetime_bound_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    LifetimeContext *lifetime();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__lifetime_bound_2Context* aux_rule__lifetime_bound_2();

  class  Kleene_star__lifetime_bound_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__lifetime_bound_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__lifetime_bound_2Context *> aux_rule__lifetime_bound_2();
    Aux_rule__lifetime_bound_2Context* aux_rule__lifetime_bound_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__lifetime_bound_1Context* kleene_star__lifetime_bound_1();

  class  Lifetime_boundContext : public antlr4::ParserRuleContext {
  public:
    Lifetime_boundContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    LifetimeContext *lifetime();
    Kleene_star__lifetime_bound_1Context *kleene_star__lifetime_bound_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Lifetime_boundContext* lifetime_bound();

  class  Aux_rule__ty_path_parent_3Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__ty_path_parent_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Type_path_segmentContext *type_path_segment();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__ty_path_parent_3Context* aux_rule__ty_path_parent_3();

  class  Kleene_star__ty_path_parent_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__ty_path_parent_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__ty_path_parent_3Context *> aux_rule__ty_path_parent_3();
    Aux_rule__ty_path_parent_3Context* aux_rule__ty_path_parent_3(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__ty_path_parent_2Context* kleene_star__ty_path_parent_2();

  class  Aux_rule__ty_path_parent_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__ty_path_parent_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__ty_path_parent_6Context *aux_rule__ty_path_parent_6();
    Aux_rule__ty_path_parent_7Context *aux_rule__ty_path_parent_7();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__ty_path_parent_4Context* aux_rule__ty_path_parent_4();

  class  Ty_path_parentContext : public antlr4::ParserRuleContext {
  public:
    Ty_path_parentContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__ty_path_parent_4Context *aux_rule__ty_path_parent_4();
    Kleene_star__ty_path_parent_2Context *kleene_star__ty_path_parent_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Ty_path_parentContext* ty_path_parent();

  class  Aux_rule__pattern_without_mut_19Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__pattern_without_mut_19Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Pattern_without_mutContext *pattern_without_mut();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__pattern_without_mut_19Context* aux_rule__pattern_without_mut_19();

  class  Kleene_star__pattern_without_mut_18Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__pattern_without_mut_18Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__pattern_without_mut_19Context *> aux_rule__pattern_without_mut_19();
    Aux_rule__pattern_without_mut_19Context* aux_rule__pattern_without_mut_19(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__pattern_without_mut_18Context* kleene_star__pattern_without_mut_18();

  class  Aux_rule__pattern_without_mut_20Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__pattern_without_mut_20Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__pattern_without_mut_32Context *aux_rule__pattern_without_mut_32();
    Pat_litContext *pat_lit();
    Aux_rule__pattern_without_mut_33Context *aux_rule__pattern_without_mut_33();
    Aux_rule__pattern_without_mut_34Context *aux_rule__pattern_without_mut_34();
    Aux_rule__pattern_without_mut_35Context *aux_rule__pattern_without_mut_35();
    Aux_rule__pattern_without_mut_36Context *aux_rule__pattern_without_mut_36();
    Aux_rule__pattern_without_mut_37Context *aux_rule__pattern_without_mut_37();
    Aux_rule__pattern_without_mut_38Context *aux_rule__pattern_without_mut_38();
    Aux_rule__pattern_without_mut_39Context *aux_rule__pattern_without_mut_39();
    Aux_rule__pattern_without_mut_40Context *aux_rule__pattern_without_mut_40();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__pattern_without_mut_20Context* aux_rule__pattern_without_mut_20();

  class  Pattern_without_mutContext : public antlr4::ParserRuleContext {
  public:
    Pattern_without_mutContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__pattern_without_mut_20Context *aux_rule__pattern_without_mut_20();
    Kleene_star__pattern_without_mut_18Context *kleene_star__pattern_without_mut_18();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Pattern_without_mutContext* pattern_without_mut();

  class  Kleene_star__post_expr_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__post_expr_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__post_expr_2Context *> aux_rule__post_expr_2();
    Aux_rule__post_expr_2Context* aux_rule__post_expr_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__post_expr_1Context* kleene_star__post_expr_1();

  class  Post_exprContext : public antlr4::ParserRuleContext {
  public:
    Post_exprContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Prim_exprContext *prim_expr();
    Kleene_star__post_expr_1Context *kleene_star__post_expr_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Post_exprContext* post_expr();

  class  Aux_rule__cast_expr_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__cast_expr_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__cast_expr_3Context *altnt_block__cast_expr_3();
    Ty_sumContext *ty_sum();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__cast_expr_2Context* aux_rule__cast_expr_2();

  class  Kleene_star__cast_expr_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__cast_expr_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__cast_expr_2Context *> aux_rule__cast_expr_2();
    Aux_rule__cast_expr_2Context* aux_rule__cast_expr_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__cast_expr_1Context* kleene_star__cast_expr_1();

  class  Cast_exprContext : public antlr4::ParserRuleContext {
  public:
    Cast_exprContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Pre_exprContext *pre_expr();
    Kleene_star__cast_expr_1Context *kleene_star__cast_expr_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Cast_exprContext* cast_expr();

  class  Aux_rule__mul_expr_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__mul_expr_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__mul_expr_3Context *altnt_block__mul_expr_3();
    Cast_exprContext *cast_expr();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__mul_expr_2Context* aux_rule__mul_expr_2();

  class  Kleene_star__mul_expr_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__mul_expr_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__mul_expr_2Context *> aux_rule__mul_expr_2();
    Aux_rule__mul_expr_2Context* aux_rule__mul_expr_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__mul_expr_1Context* kleene_star__mul_expr_1();

  class  Mul_exprContext : public antlr4::ParserRuleContext {
  public:
    Mul_exprContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Cast_exprContext *cast_expr();
    Kleene_star__mul_expr_1Context *kleene_star__mul_expr_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Mul_exprContext* mul_expr();

  class  Aux_rule__add_expr_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__add_expr_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__add_expr_3Context *altnt_block__add_expr_3();
    Mul_exprContext *mul_expr();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__add_expr_2Context* aux_rule__add_expr_2();

  class  Kleene_star__add_expr_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__add_expr_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__add_expr_2Context *> aux_rule__add_expr_2();
    Aux_rule__add_expr_2Context* aux_rule__add_expr_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__add_expr_1Context* kleene_star__add_expr_1();

  class  Add_exprContext : public antlr4::ParserRuleContext {
  public:
    Add_exprContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Mul_exprContext *mul_expr();
    Kleene_star__add_expr_1Context *kleene_star__add_expr_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Add_exprContext* add_expr();

  class  Aux_rule__shift_expr_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__shift_expr_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__shift_expr_3Context *altnt_block__shift_expr_3();
    Add_exprContext *add_expr();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__shift_expr_2Context* aux_rule__shift_expr_2();

  class  Kleene_star__shift_expr_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__shift_expr_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__shift_expr_2Context *> aux_rule__shift_expr_2();
    Aux_rule__shift_expr_2Context* aux_rule__shift_expr_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__shift_expr_1Context* kleene_star__shift_expr_1();

  class  Shift_exprContext : public antlr4::ParserRuleContext {
  public:
    Shift_exprContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Add_exprContext *add_expr();
    Kleene_star__shift_expr_1Context *kleene_star__shift_expr_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Shift_exprContext* shift_expr();

  class  Aux_rule__bit_and_expr_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__bit_and_expr_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Shift_exprContext *shift_expr();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__bit_and_expr_2Context* aux_rule__bit_and_expr_2();

  class  Kleene_star__bit_and_expr_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__bit_and_expr_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__bit_and_expr_2Context *> aux_rule__bit_and_expr_2();
    Aux_rule__bit_and_expr_2Context* aux_rule__bit_and_expr_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__bit_and_expr_1Context* kleene_star__bit_and_expr_1();

  class  Bit_and_exprContext : public antlr4::ParserRuleContext {
  public:
    Bit_and_exprContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Shift_exprContext *shift_expr();
    Kleene_star__bit_and_expr_1Context *kleene_star__bit_and_expr_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Bit_and_exprContext* bit_and_expr();

  class  Aux_rule__bit_xor_expr_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__bit_xor_expr_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Bit_and_exprContext *bit_and_expr();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__bit_xor_expr_2Context* aux_rule__bit_xor_expr_2();

  class  Kleene_star__bit_xor_expr_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__bit_xor_expr_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__bit_xor_expr_2Context *> aux_rule__bit_xor_expr_2();
    Aux_rule__bit_xor_expr_2Context* aux_rule__bit_xor_expr_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__bit_xor_expr_1Context* kleene_star__bit_xor_expr_1();

  class  Bit_xor_exprContext : public antlr4::ParserRuleContext {
  public:
    Bit_xor_exprContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Bit_and_exprContext *bit_and_expr();
    Kleene_star__bit_xor_expr_1Context *kleene_star__bit_xor_expr_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Bit_xor_exprContext* bit_xor_expr();

  class  Aux_rule__bit_or_expr_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__bit_or_expr_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Bit_xor_exprContext *bit_xor_expr();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__bit_or_expr_2Context* aux_rule__bit_or_expr_2();

  class  Kleene_star__bit_or_expr_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__bit_or_expr_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__bit_or_expr_2Context *> aux_rule__bit_or_expr_2();
    Aux_rule__bit_or_expr_2Context* aux_rule__bit_or_expr_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__bit_or_expr_1Context* kleene_star__bit_or_expr_1();

  class  Bit_or_exprContext : public antlr4::ParserRuleContext {
  public:
    Bit_or_exprContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Bit_xor_exprContext *bit_xor_expr();
    Kleene_star__bit_or_expr_1Context *kleene_star__bit_or_expr_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Bit_or_exprContext* bit_or_expr();

  class  Aux_rule__and_expr_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__and_expr_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Cmp_exprContext *cmp_expr();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__and_expr_2Context* aux_rule__and_expr_2();

  class  Kleene_star__and_expr_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__and_expr_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__and_expr_2Context *> aux_rule__and_expr_2();
    Aux_rule__and_expr_2Context* aux_rule__and_expr_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__and_expr_1Context* kleene_star__and_expr_1();

  class  And_exprContext : public antlr4::ParserRuleContext {
  public:
    And_exprContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Cmp_exprContext *cmp_expr();
    Kleene_star__and_expr_1Context *kleene_star__and_expr_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  And_exprContext* and_expr();

  class  Aux_rule__or_expr_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__or_expr_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    And_exprContext *and_expr();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__or_expr_2Context* aux_rule__or_expr_2();

  class  Kleene_star__or_expr_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__or_expr_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__or_expr_2Context *> aux_rule__or_expr_2();
    Aux_rule__or_expr_2Context* aux_rule__or_expr_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__or_expr_1Context* kleene_star__or_expr_1();

  class  Or_exprContext : public antlr4::ParserRuleContext {
  public:
    Or_exprContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    And_exprContext *and_expr();
    Kleene_star__or_expr_1Context *kleene_star__or_expr_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Or_exprContext* or_expr();

  class  Post_expr_no_structContext : public antlr4::ParserRuleContext {
  public:
    Post_expr_no_structContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Prim_expr_no_structContext *prim_expr_no_struct();
    Kleene_star__post_expr_1Context *kleene_star__post_expr_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Post_expr_no_structContext* post_expr_no_struct();

  class  Cast_expr_no_structContext : public antlr4::ParserRuleContext {
  public:
    Cast_expr_no_structContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Pre_expr_no_structContext *pre_expr_no_struct();
    Kleene_star__cast_expr_1Context *kleene_star__cast_expr_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Cast_expr_no_structContext* cast_expr_no_struct();

  class  Aux_rule__mul_expr_no_struct_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__mul_expr_no_struct_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__mul_expr_3Context *altnt_block__mul_expr_3();
    Cast_expr_no_structContext *cast_expr_no_struct();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__mul_expr_no_struct_2Context* aux_rule__mul_expr_no_struct_2();

  class  Kleene_star__mul_expr_no_struct_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__mul_expr_no_struct_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__mul_expr_no_struct_2Context *> aux_rule__mul_expr_no_struct_2();
    Aux_rule__mul_expr_no_struct_2Context* aux_rule__mul_expr_no_struct_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__mul_expr_no_struct_1Context* kleene_star__mul_expr_no_struct_1();

  class  Mul_expr_no_structContext : public antlr4::ParserRuleContext {
  public:
    Mul_expr_no_structContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Cast_expr_no_structContext *cast_expr_no_struct();
    Kleene_star__mul_expr_no_struct_1Context *kleene_star__mul_expr_no_struct_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Mul_expr_no_structContext* mul_expr_no_struct();

  class  Aux_rule__add_expr_no_struct_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__add_expr_no_struct_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__add_expr_3Context *altnt_block__add_expr_3();
    Mul_expr_no_structContext *mul_expr_no_struct();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__add_expr_no_struct_2Context* aux_rule__add_expr_no_struct_2();

  class  Kleene_star__add_expr_no_struct_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__add_expr_no_struct_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__add_expr_no_struct_2Context *> aux_rule__add_expr_no_struct_2();
    Aux_rule__add_expr_no_struct_2Context* aux_rule__add_expr_no_struct_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__add_expr_no_struct_1Context* kleene_star__add_expr_no_struct_1();

  class  Add_expr_no_structContext : public antlr4::ParserRuleContext {
  public:
    Add_expr_no_structContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Mul_expr_no_structContext *mul_expr_no_struct();
    Kleene_star__add_expr_no_struct_1Context *kleene_star__add_expr_no_struct_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Add_expr_no_structContext* add_expr_no_struct();

  class  Aux_rule__shift_expr_no_struct_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__shift_expr_no_struct_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__shift_expr_3Context *altnt_block__shift_expr_3();
    Add_expr_no_structContext *add_expr_no_struct();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__shift_expr_no_struct_2Context* aux_rule__shift_expr_no_struct_2();

  class  Kleene_star__shift_expr_no_struct_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__shift_expr_no_struct_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__shift_expr_no_struct_2Context *> aux_rule__shift_expr_no_struct_2();
    Aux_rule__shift_expr_no_struct_2Context* aux_rule__shift_expr_no_struct_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__shift_expr_no_struct_1Context* kleene_star__shift_expr_no_struct_1();

  class  Shift_expr_no_structContext : public antlr4::ParserRuleContext {
  public:
    Shift_expr_no_structContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Add_expr_no_structContext *add_expr_no_struct();
    Kleene_star__shift_expr_no_struct_1Context *kleene_star__shift_expr_no_struct_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Shift_expr_no_structContext* shift_expr_no_struct();

  class  Aux_rule__bit_and_expr_no_struct_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__bit_and_expr_no_struct_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Shift_expr_no_structContext *shift_expr_no_struct();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__bit_and_expr_no_struct_2Context* aux_rule__bit_and_expr_no_struct_2();

  class  Kleene_star__bit_and_expr_no_struct_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__bit_and_expr_no_struct_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__bit_and_expr_no_struct_2Context *> aux_rule__bit_and_expr_no_struct_2();
    Aux_rule__bit_and_expr_no_struct_2Context* aux_rule__bit_and_expr_no_struct_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__bit_and_expr_no_struct_1Context* kleene_star__bit_and_expr_no_struct_1();

  class  Bit_and_expr_no_structContext : public antlr4::ParserRuleContext {
  public:
    Bit_and_expr_no_structContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Shift_expr_no_structContext *shift_expr_no_struct();
    Kleene_star__bit_and_expr_no_struct_1Context *kleene_star__bit_and_expr_no_struct_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Bit_and_expr_no_structContext* bit_and_expr_no_struct();

  class  Aux_rule__bit_xor_expr_no_struct_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__bit_xor_expr_no_struct_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Bit_and_expr_no_structContext *bit_and_expr_no_struct();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__bit_xor_expr_no_struct_2Context* aux_rule__bit_xor_expr_no_struct_2();

  class  Kleene_star__bit_xor_expr_no_struct_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__bit_xor_expr_no_struct_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__bit_xor_expr_no_struct_2Context *> aux_rule__bit_xor_expr_no_struct_2();
    Aux_rule__bit_xor_expr_no_struct_2Context* aux_rule__bit_xor_expr_no_struct_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__bit_xor_expr_no_struct_1Context* kleene_star__bit_xor_expr_no_struct_1();

  class  Bit_xor_expr_no_structContext : public antlr4::ParserRuleContext {
  public:
    Bit_xor_expr_no_structContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Bit_and_expr_no_structContext *bit_and_expr_no_struct();
    Kleene_star__bit_xor_expr_no_struct_1Context *kleene_star__bit_xor_expr_no_struct_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Bit_xor_expr_no_structContext* bit_xor_expr_no_struct();

  class  Aux_rule__bit_or_expr_no_struct_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__bit_or_expr_no_struct_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Bit_xor_expr_no_structContext *bit_xor_expr_no_struct();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__bit_or_expr_no_struct_2Context* aux_rule__bit_or_expr_no_struct_2();

  class  Kleene_star__bit_or_expr_no_struct_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__bit_or_expr_no_struct_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__bit_or_expr_no_struct_2Context *> aux_rule__bit_or_expr_no_struct_2();
    Aux_rule__bit_or_expr_no_struct_2Context* aux_rule__bit_or_expr_no_struct_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__bit_or_expr_no_struct_1Context* kleene_star__bit_or_expr_no_struct_1();

  class  Bit_or_expr_no_structContext : public antlr4::ParserRuleContext {
  public:
    Bit_or_expr_no_structContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Bit_xor_expr_no_structContext *bit_xor_expr_no_struct();
    Kleene_star__bit_or_expr_no_struct_1Context *kleene_star__bit_or_expr_no_struct_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Bit_or_expr_no_structContext* bit_or_expr_no_struct();

  class  Aux_rule__and_expr_no_struct_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__and_expr_no_struct_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Cmp_expr_no_structContext *cmp_expr_no_struct();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__and_expr_no_struct_2Context* aux_rule__and_expr_no_struct_2();

  class  Kleene_star__and_expr_no_struct_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__and_expr_no_struct_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__and_expr_no_struct_2Context *> aux_rule__and_expr_no_struct_2();
    Aux_rule__and_expr_no_struct_2Context* aux_rule__and_expr_no_struct_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__and_expr_no_struct_1Context* kleene_star__and_expr_no_struct_1();

  class  And_expr_no_structContext : public antlr4::ParserRuleContext {
  public:
    And_expr_no_structContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Cmp_expr_no_structContext *cmp_expr_no_struct();
    Kleene_star__and_expr_no_struct_1Context *kleene_star__and_expr_no_struct_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  And_expr_no_structContext* and_expr_no_struct();

  class  Aux_rule__or_expr_no_struct_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__or_expr_no_struct_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    And_expr_no_structContext *and_expr_no_struct();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__or_expr_no_struct_2Context* aux_rule__or_expr_no_struct_2();

  class  Kleene_star__or_expr_no_struct_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__or_expr_no_struct_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__or_expr_no_struct_2Context *> aux_rule__or_expr_no_struct_2();
    Aux_rule__or_expr_no_struct_2Context* aux_rule__or_expr_no_struct_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__or_expr_no_struct_1Context* kleene_star__or_expr_no_struct_1();

  class  Or_expr_no_structContext : public antlr4::ParserRuleContext {
  public:
    Or_expr_no_structContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    And_expr_no_structContext *and_expr_no_struct();
    Kleene_star__or_expr_no_struct_1Context *kleene_star__or_expr_no_struct_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Or_expr_no_structContext* or_expr_no_struct();

  class  Kleene_plus__expr_attrs_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_plus__expr_attrs_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<AttrContext *> attr();
    AttrContext* attr(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_plus__expr_attrs_2Context* kleene_plus__expr_attrs_2();

  class  Kleene_plus__expr_inner_attrs_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_plus__expr_inner_attrs_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Inner_attrContext *> inner_attr();
    Inner_attrContext* inner_attr(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_plus__expr_inner_attrs_2Context* kleene_plus__expr_inner_attrs_2();

  class  Aux_rule__enum_variant_main_3Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__enum_variant_main_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__enum_variant_main_1Context *optional__enum_variant_main_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__enum_variant_main_3Context* aux_rule__enum_variant_main_3();

  class  Optional__enum_variant_main_4Context : public antlr4::ParserRuleContext {
  public:
    Optional__enum_variant_main_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__enum_variant_main_3Context *aux_rule__enum_variant_main_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__enum_variant_main_4Context* optional__enum_variant_main_4();

  class  Aux_rule__impl_what_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__impl_what_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Ty_sumContext *ty_sum();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__impl_what_1Context* aux_rule__impl_what_1();

  class  Optional__impl_what_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__impl_what_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__impl_what_1Context *aux_rule__impl_what_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__impl_what_2Context* optional__impl_what_2();

  class  Aux_rule__path_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__path_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__path_1Context *optional__path_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__path_2Context* aux_rule__path_2();

  class  Optional__path_3Context : public antlr4::ParserRuleContext {
  public:
    Optional__path_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__path_2Context *aux_rule__path_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__path_3Context* optional__path_3();

  class  Aux_rule__type_path_main_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__type_path_main_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__type_path_main_1Context *optional__type_path_main_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__type_path_main_2Context* aux_rule__type_path_main_2();

  class  Optional__type_path_main_3Context : public antlr4::ParserRuleContext {
  public:
    Optional__type_path_main_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__type_path_main_2Context *aux_rule__type_path_main_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__type_path_main_3Context* optional__type_path_main_3();

  class  Aux_rule__tuple_type_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__tuple_type_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Ty_sumContext *ty_sum();
    Optional__ty_path_tail_1Context *optional__ty_path_tail_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__tuple_type_2Context* aux_rule__tuple_type_2();

  class  Optional__tuple_type_3Context : public antlr4::ParserRuleContext {
  public:
    Optional__tuple_type_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__tuple_type_2Context *aux_rule__tuple_type_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__tuple_type_3Context* optional__tuple_type_3();

  class  Aux_rule__type_argument_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__type_argument_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    IdentContext *ident();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__type_argument_1Context* aux_rule__type_argument_1();

  class  Optional__type_argument_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__type_argument_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__type_argument_1Context *aux_rule__type_argument_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__type_argument_2Context* optional__type_argument_2();

  class  Aux_rule__pattern_without_mut_21Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__pattern_without_mut_21Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    PatternContext *pattern();
    Kleene_star__pattern_without_mut_16Context *kleene_star__pattern_without_mut_16();
    Optional__use_item_list_3Context *optional__use_item_list_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__pattern_without_mut_21Context* aux_rule__pattern_without_mut_21();

  class  Optional__pattern_without_mut_22Context : public antlr4::ParserRuleContext {
  public:
    Optional__pattern_without_mut_22Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__pattern_without_mut_21Context *aux_rule__pattern_without_mut_21();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__pattern_without_mut_22Context* optional__pattern_without_mut_22();

  class  Aux_rule__pattern_without_mut_23Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__pattern_without_mut_23Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__pattern_without_mut_12Context *optional__pattern_without_mut_12();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__pattern_without_mut_23Context* aux_rule__pattern_without_mut_23();

  class  Optional__pattern_without_mut_24Context : public antlr4::ParserRuleContext {
  public:
    Optional__pattern_without_mut_24Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__pattern_without_mut_23Context *aux_rule__pattern_without_mut_23();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__pattern_without_mut_24Context* optional__pattern_without_mut_24();

  class  Aux_rule__assign_expr_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__assign_expr_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__assign_expr_3Context *altnt_block__assign_expr_3();
    Assign_exprContext *assign_expr();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__assign_expr_1Context* aux_rule__assign_expr_1();

  class  Optional__assign_expr_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__assign_expr_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__assign_expr_1Context *aux_rule__assign_expr_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__assign_expr_2Context* optional__assign_expr_2();

  class  Aux_rule__assign_expr_no_struct_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__assign_expr_no_struct_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__assign_expr_no_struct_3Context *altnt_block__assign_expr_no_struct_3();
    Assign_expr_no_structContext *assign_expr_no_struct();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__assign_expr_no_struct_1Context* aux_rule__assign_expr_no_struct_1();

  class  Optional__assign_expr_no_struct_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__assign_expr_no_struct_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__assign_expr_no_struct_1Context *aux_rule__assign_expr_no_struct_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__assign_expr_no_struct_2Context* optional__assign_expr_no_struct_2();

  class  Optional__blocky_expr_11Context : public antlr4::ParserRuleContext {
  public:
    Optional__blocky_expr_11Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__blocky_expr_11Context* optional__blocky_expr_11();

  class  Optional__closure_params_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__closure_params_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__closure_params_1Context *optional__closure_params_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__closure_params_2Context* optional__closure_params_2();

  class  Aux_rule__cmp_expr_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__cmp_expr_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__cmp_expr_3Context *altnt_block__cmp_expr_3();
    Bit_or_exprContext *bit_or_expr();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__cmp_expr_1Context* aux_rule__cmp_expr_1();

  class  Optional__cmp_expr_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__cmp_expr_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__cmp_expr_1Context *aux_rule__cmp_expr_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__cmp_expr_2Context* optional__cmp_expr_2();

  class  Aux_rule__range_expr_5Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__range_expr_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__range_expr_1Context *optional__range_expr_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__range_expr_5Context* aux_rule__range_expr_5();

  class  Optional__range_expr_6Context : public antlr4::ParserRuleContext {
  public:
    Optional__range_expr_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__range_expr_5Context *aux_rule__range_expr_5();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__range_expr_6Context* optional__range_expr_6();

  class  Aux_rule__cmp_expr_no_struct_5Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__cmp_expr_no_struct_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Optional__expr_1Context *> optional__expr_1();
    Optional__expr_1Context* optional__expr_1(size_t i);
    std::vector<Optional__expr_2Context *> optional__expr_2();
    Optional__expr_2Context* optional__expr_2(size_t i);
    Bit_or_expr_no_structContext *bit_or_expr_no_struct();
    Altnt_block__cmp_expr_no_struct_7Context *altnt_block__cmp_expr_no_struct_7();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__cmp_expr_no_struct_5Context* aux_rule__cmp_expr_no_struct_5();

  class  Optional__cmp_expr_no_struct_6Context : public antlr4::ParserRuleContext {
  public:
    Optional__cmp_expr_no_struct_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__cmp_expr_no_struct_5Context *aux_rule__cmp_expr_no_struct_5();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__cmp_expr_no_struct_6Context* optional__cmp_expr_no_struct_6();

  class  Aux_rule__range_expr_no_struct_5Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__range_expr_no_struct_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__range_expr_no_struct_1Context *optional__range_expr_no_struct_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__range_expr_no_struct_5Context* aux_rule__range_expr_no_struct_5();

  class  Optional__range_expr_no_struct_6Context : public antlr4::ParserRuleContext {
  public:
    Optional__range_expr_no_struct_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__range_expr_no_struct_5Context *aux_rule__range_expr_no_struct_5();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__range_expr_no_struct_6Context* optional__range_expr_no_struct_6();

  class  Altnt_block__visibility_restriction_1Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__visibility_restriction_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__visibility_restriction_2Context *aux_rule__visibility_restriction_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__visibility_restriction_1Context* altnt_block__visibility_restriction_1();

  class  Altnt_block__type_decl_10Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__type_decl_10Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__impl_block_3Context *optional__impl_block_3();
    Altnt_block__type_decl_11Context *altnt_block__type_decl_11();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__type_decl_10Context* altnt_block__type_decl_10();

  class  Altnt_block__use_suffix_2Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__use_suffix_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__use_suffix_4Context *aux_rule__use_suffix_4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__use_suffix_2Context* altnt_block__use_suffix_2();

  class  Altnt_block__foreign_item_tail_11Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__foreign_item_tail_11Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__foreign_item_tail_13Context *aux_rule__foreign_item_tail_13();
    Aux_rule__foreign_item_tail_14Context *aux_rule__foreign_item_tail_14();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__foreign_item_tail_11Context* altnt_block__foreign_item_tail_11();

  class  Altnt_block__macro_invocation_semi_4Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__macro_invocation_semi_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__macro_invocation_semi_6Context *aux_rule__macro_invocation_semi_6();
    Aux_rule__macro_invocation_semi_7Context *aux_rule__macro_invocation_semi_7();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__macro_invocation_semi_4Context* altnt_block__macro_invocation_semi_4();

  class  Altnt_block__type_parameters_4Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__type_parameters_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Lifetime_param_listContext *lifetime_param_list();
    Aux_rule__type_parameters_5Context *aux_rule__type_parameters_5();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__type_parameters_4Context* altnt_block__type_parameters_4();

  class  Altnt_block__trait_method_param_6Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__trait_method_param_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__item_1Context *kleene_star__item_1();
    Optional__trait_method_param_9Context *optional__trait_method_param_9();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__trait_method_param_6Context* altnt_block__trait_method_param_6();

  class  Altnt_block__struct_tail_6Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__struct_tail_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__struct_tail_8Context *optional__struct_tail_8();
    Optional__impl_block_6Context *optional__impl_block_6();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__struct_tail_6Context* altnt_block__struct_tail_6();

  class  Altnt_block__enum_variant_main_5Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__enum_variant_main_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__enum_variant_main_4Context *optional__enum_variant_main_4();
    Aux_rule__enum_variant_main_6Context *aux_rule__enum_variant_main_6();
    Aux_rule__enum_variant_main_7Context *aux_rule__enum_variant_main_7();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__enum_variant_main_5Context* altnt_block__enum_variant_main_5();

  class  Altnt_block__trait_item_19Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__trait_item_19Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__item_1Context *kleene_star__item_1();
    Optional__impl_block_1Context *optional__impl_block_1();
    Altnt_block__trait_item_22Context *altnt_block__trait_item_22();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__trait_item_19Context* altnt_block__trait_item_19();

  class  Altnt_block__impl_what_3Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__impl_what_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Ty_sumContext *ty_sum();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__impl_what_3Context* altnt_block__impl_what_3();

  class  Altnt_block__type_arguments_9Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__type_arguments_9Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__type_arguments_11Context *altnt_block__type_arguments_11();
    Optional__use_item_list_3Context *optional__use_item_list_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__type_arguments_9Context* altnt_block__type_arguments_9();

  class  Altnt_block__impl_item_tail_13Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__impl_item_tail_13Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__impl_item_tail_16Context *aux_rule__impl_item_tail_16();
    Aux_rule__impl_item_tail_17Context *aux_rule__impl_item_tail_17();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__impl_item_tail_13Context* altnt_block__impl_item_tail_13();

  class  Altnt_block__pattern_without_mut_25Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__pattern_without_mut_25Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *CashMoney();
    Aux_rule__pattern_without_mut_41Context *aux_rule__pattern_without_mut_41();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__pattern_without_mut_25Context* altnt_block__pattern_without_mut_25();

  class  Altnt_block__pattern_without_mut_26Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__pattern_without_mut_26Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__pattern_without_mut_26Context* altnt_block__pattern_without_mut_26();

  class  Altnt_block__pattern_without_mut_27Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__pattern_without_mut_27Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Macro_tailContext *macro_tail();
    Optional__pattern_without_mut_24Context *optional__pattern_without_mut_24();
    Aux_rule__pattern_without_mut_42Context *aux_rule__pattern_without_mut_42();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__pattern_without_mut_27Context* altnt_block__pattern_without_mut_27();

  class  Altnt_block__pattern_without_mut_28Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__pattern_without_mut_28Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__pattern_without_mut_3Context *optional__pattern_without_mut_3();
    Aux_rule__pattern_without_mut_43Context *aux_rule__pattern_without_mut_43();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__pattern_without_mut_28Context* altnt_block__pattern_without_mut_28();

  class  Altnt_block__pattern_without_mut_29Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__pattern_without_mut_29Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__pattern_without_mut_29Context* altnt_block__pattern_without_mut_29();

  class  Altnt_block__pat_fields_6Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__pat_fields_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__pat_fields_10Context *aux_rule__pat_fields_10();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__pat_fields_6Context* altnt_block__pat_fields_6();

  class  Altnt_block__stmt_8Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__stmt_8Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__stmt_11Context *aux_rule__stmt_11();
    Optional__block_with_inner_attrs_3Context *optional__block_with_inner_attrs_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__stmt_8Context* altnt_block__stmt_8();

  class  Altnt_block__blocky_expr_12Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__blocky_expr_12Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__blocky_expr_11Context *optional__blocky_expr_11();
    Aux_rule__blocky_expr_19Context *aux_rule__blocky_expr_19();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__blocky_expr_12Context* altnt_block__blocky_expr_12();

  class  Altnt_block__if_cond_or_pat_1Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__if_cond_or_pat_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Expr_no_structContext *expr_no_struct();
    Aux_rule__if_cond_or_pat_2Context *aux_rule__if_cond_or_pat_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__if_cond_or_pat_1Context* altnt_block__if_cond_or_pat_1();

  class  Altnt_block__match_arms_6Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__match_arms_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__match_arms_7Context *aux_rule__match_arms_7();
    Aux_rule__match_arms_8Context *aux_rule__match_arms_8();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__match_arms_6Context* altnt_block__match_arms_6();

  class  Altnt_block__prim_expr_no_struct_18Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__prim_expr_no_struct_18Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__prim_expr_1Context *optional__prim_expr_1();
    Altnt_block__prim_expr_no_struct_23Context *altnt_block__prim_expr_no_struct_23();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__prim_expr_no_struct_18Context* altnt_block__prim_expr_no_struct_18();

  class  Altnt_block__prim_expr_no_struct_19Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__prim_expr_no_struct_19Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__prim_expr_1Context *optional__prim_expr_1();
    Altnt_block__prim_expr_no_struct_24Context *altnt_block__prim_expr_no_struct_24();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__prim_expr_no_struct_19Context* altnt_block__prim_expr_no_struct_19();

  class  Altnt_block__post_expr_tail_7Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__post_expr_tail_7Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__post_expr_tail_8Context *aux_rule__post_expr_tail_8();
    antlr4::tree::TerminalNode *BareIntLit();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__post_expr_tail_7Context* altnt_block__post_expr_tail_7();

  class  Altnt_block__pre_expr_3Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__pre_expr_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Expr_attrsContext *expr_attrs();
    Aux_rule__pre_expr_7Context *aux_rule__pre_expr_7();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__pre_expr_3Context* altnt_block__pre_expr_3();

  class  Altnt_block__cast_expr_3Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__cast_expr_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__cast_expr_3Context* altnt_block__cast_expr_3();

  class  Altnt_block__mul_expr_3Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__mul_expr_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__mul_expr_3Context* altnt_block__mul_expr_3();

  class  Altnt_block__add_expr_3Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__add_expr_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__add_expr_3Context* altnt_block__add_expr_3();

  class  Altnt_block__shift_expr_3Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__shift_expr_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__shift_expr_4Context *aux_rule__shift_expr_4();
    Aux_rule__shift_expr_5Context *aux_rule__shift_expr_5();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__shift_expr_3Context* altnt_block__shift_expr_3();

  class  Altnt_block__range_expr_7Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__range_expr_7Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__range_expr_6Context *optional__range_expr_6();
    Aux_rule__range_expr_11Context *aux_rule__range_expr_11();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__range_expr_7Context* altnt_block__range_expr_7();

  class  Altnt_block__range_expr_no_struct_7Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__range_expr_no_struct_7Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__range_expr_no_struct_6Context *optional__range_expr_no_struct_6();
    Aux_rule__range_expr_no_struct_11Context *aux_rule__range_expr_no_struct_11();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__range_expr_no_struct_7Context* altnt_block__range_expr_no_struct_7();

  class  Altnt_block__macro_rules_def_4Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__macro_rules_def_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__macro_rules_def_7Context *aux_rule__macro_rules_def_7();
    Aux_rule__macro_rules_def_8Context *aux_rule__macro_rules_def_8();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__macro_rules_def_4Context* altnt_block__macro_rules_def_4();

  class  Altnt_block__macro_match_3Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__macro_match_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__macro_match_5Context *aux_rule__macro_match_5();
    Aux_rule__macro_match_6Context *aux_rule__macro_match_6();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__macro_match_3Context* altnt_block__macro_match_3();

  class  Altnt_block__macro_invocation_semi_5Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__macro_invocation_semi_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__macro_invocation_semi_8Context *aux_rule__macro_invocation_semi_8();
    Aux_rule__macro_invocation_semi_9Context *aux_rule__macro_invocation_semi_9();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__macro_invocation_semi_5Context* altnt_block__macro_invocation_semi_5();

  class  TypeContext : public antlr4::ParserRuleContext {
  public:
    TypeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Impl_trait_type_one_boundContext *impl_trait_type_one_bound();
    Trait_object_type_one_boundContext *trait_object_type_one_bound();
    Aux_rule__type_3Context *aux_rule__type_3();
    Tuple_typeContext *tuple_type();
    Never_typeContext *never_type();
    Raw_pointer_typeContext *raw_pointer_type();
    Reference_typeContext *reference_type();
    Array_or_slice_typeContext *array_or_slice_type();
    Inferred_typeContext *inferred_type();
    Bare_function_typeContext *bare_function_type();
    Macro_invocationContext *macro_invocation();
    Aux_rule__type_4Context *aux_rule__type_4();
    Impl_trait_typeContext *impl_trait_type();
    Trait_object_typeContext *trait_object_type();
    Aux_rule__type_5Context *aux_rule__type_5();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  TypeContext* type();

  class  Altnt_block__extern_crate_2Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__extern_crate_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    IdentContext *ident();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__extern_crate_2Context* altnt_block__extern_crate_2();

  class  Altnt_block__use_path_7Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__use_path_7Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Any_identContext *any_ident();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__use_path_7Context* altnt_block__use_path_7();

  class  Altnt_block__use_item_2Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__use_item_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Any_identContext *any_ident();
    Use_pathContext *use_path();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__use_item_2Context* altnt_block__use_item_2();

  class  Altnt_block__const_decl_2Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__const_decl_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    IdentContext *ident();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__const_decl_2Context* altnt_block__const_decl_2();

  class  Altnt_block__fn_decl_4Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__fn_decl_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Block_with_inner_attrsContext *block_with_inner_attrs();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__fn_decl_4Context* altnt_block__fn_decl_4();

  class  Altnt_block__method_param_list_4Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__method_param_list_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ParamContext *param();
    Self_paramContext *self_param();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__method_param_list_4Context* altnt_block__method_param_list_4();

  class  Altnt_block__restricted_pat_4Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__restricted_pat_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    IdentContext *ident();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__restricted_pat_4Context* altnt_block__restricted_pat_4();

  class  Altnt_block__trait_method_param_list_5Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__trait_method_param_list_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Trait_method_paramContext *trait_method_param();
    Self_paramContext *self_param();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__trait_method_param_list_5Context* altnt_block__trait_method_param_list_5();

  class  Altnt_block__fn_rtype_1Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__fn_rtype_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    TypeContext *type();
    Aux_rule__fn_rtype_2Context *aux_rule__fn_rtype_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__fn_rtype_1Context* altnt_block__fn_rtype_1();

  class  Altnt_block__trait_alias_3Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__trait_alias_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__trait_alias_4Context *aux_rule__trait_alias_4();
    Where_clauseContext *where_clause();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__trait_alias_3Context* altnt_block__trait_alias_3();

  class  Altnt_block__trait_item_20Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__trait_item_20Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Const_declContext *const_decl();
    Associated_const_declContext *associated_const_decl();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__trait_item_20Context* altnt_block__trait_item_20();

  class  Altnt_block__ty_path_tail_3Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__ty_path_tail_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    IdentContext *ident();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__ty_path_tail_3Context* altnt_block__ty_path_tail_3();

  class  Altnt_block__pat_fields_7Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__pat_fields_7Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__pat_fields_11Context *aux_rule__pat_fields_11();
    Optional__use_item_list_3Context *optional__use_item_list_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__pat_fields_7Context* altnt_block__pat_fields_7();

  class  Altnt_block__prim_expr_no_struct_20Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__prim_expr_no_struct_20Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Blocky_exprContext *blocky_expr();
    Aux_rule__prim_expr_no_struct_32Context *aux_rule__prim_expr_no_struct_32();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__prim_expr_no_struct_20Context* altnt_block__prim_expr_no_struct_20();

  class  Altnt_block__fields_4Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__fields_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__fields_6Context *aux_rule__fields_6();
    Optional__use_item_list_3Context *optional__use_item_list_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__fields_4Context* altnt_block__fields_4();

  class  Altnt_block__type_arguments_10Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__type_arguments_10Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    LifetimeContext *lifetime();
    Type_argumentContext *type_argument();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__type_arguments_10Context* altnt_block__type_arguments_10();

  class  Altnt_block__assign_expr_3Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__assign_expr_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__assign_expr_3Context* altnt_block__assign_expr_3();

  class  Altnt_block__assign_expr_no_struct_3Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__assign_expr_no_struct_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__assign_expr_no_struct_6Context *aux_rule__assign_expr_no_struct_6();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__assign_expr_no_struct_3Context* altnt_block__assign_expr_no_struct_3();

  class  Altnt_block__cmp_expr_3Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__cmp_expr_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__cmp_expr_3Context* altnt_block__cmp_expr_3();

  class  Altnt_block__cmp_expr_no_struct_7Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__cmp_expr_no_struct_7Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__cmp_expr_no_struct_9Context *aux_rule__cmp_expr_no_struct_9();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__cmp_expr_no_struct_7Context* altnt_block__cmp_expr_no_struct_7();

  class  Altnt_block__trait_method_param_7Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__trait_method_param_7Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__trait_method_param_11Context *aux_rule__trait_method_param_11();
    Restricted_patContext *restricted_pat();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__trait_method_param_7Context* altnt_block__trait_method_param_7();

  class  Aux_rule__trait_method_param_8Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__trait_method_param_8Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__trait_method_param_7Context *altnt_block__trait_method_param_7();
    Kleene_star__item_1Context *kleene_star__item_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__trait_method_param_8Context* aux_rule__trait_method_param_8();

  class  Optional__trait_method_param_9Context : public antlr4::ParserRuleContext {
  public:
    Optional__trait_method_param_9Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__trait_method_param_8Context *aux_rule__trait_method_param_8();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__trait_method_param_9Context* optional__trait_method_param_9();

  class  Aux_rule__struct_tail_7Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__struct_tail_7Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__struct_tail_2Context *optional__struct_tail_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__struct_tail_7Context* aux_rule__struct_tail_7();

  class  Optional__struct_tail_8Context : public antlr4::ParserRuleContext {
  public:
    Optional__struct_tail_8Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__struct_tail_7Context *aux_rule__struct_tail_7();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__struct_tail_8Context* optional__struct_tail_8();

  class  Aux_rule__assign_expr_no_struct_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__assign_expr_no_struct_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__assign_expr_no_struct_4Context* aux_rule__assign_expr_no_struct_4();

  class  Optional__assign_expr_no_struct_5Context : public antlr4::ParserRuleContext {
  public:
    Optional__assign_expr_no_struct_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__assign_expr_no_struct_4Context *aux_rule__assign_expr_no_struct_4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__assign_expr_no_struct_5Context* optional__assign_expr_no_struct_5();

  class  Aux_rule__blocky_expr_13Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__blocky_expr_13Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    PatternContext *pattern();
    Expr_no_structContext *expr_no_struct();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__blocky_expr_13Context* aux_rule__blocky_expr_13();

  class  Optional__blocky_expr_14Context : public antlr4::ParserRuleContext {
  public:
    Optional__blocky_expr_14Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__blocky_expr_13Context *aux_rule__blocky_expr_13();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__blocky_expr_14Context* optional__blocky_expr_14();

  class  Optional__cmp_expr_no_struct_8Context : public antlr4::ParserRuleContext {
  public:
    Optional__cmp_expr_no_struct_8Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__cmp_expr_no_struct_8Context* optional__cmp_expr_no_struct_8();

  class  Altnt_block__type_decl_11Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__type_decl_11Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__type_decl_12Context *aux_rule__type_decl_12();
    Aux_rule__type_decl_13Context *aux_rule__type_decl_13();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__type_decl_11Context* altnt_block__type_decl_11();

  class  Altnt_block__use_path_8Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__use_path_8Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__use_path_9Context *aux_rule__use_path_9();
    Aux_rule__use_path_10Context *aux_rule__use_path_10();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__use_path_8Context* altnt_block__use_path_8();

  class  Altnt_block__foreign_item_4Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__foreign_item_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__foreign_item_5Context *aux_rule__foreign_item_5();
    Macro_invocation_semiContext *macro_invocation_semi();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__foreign_item_4Context* altnt_block__foreign_item_4();

  class  Altnt_block__param_12Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__param_12Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__param_14Context *aux_rule__param_14();
    Aux_rule__param_15Context *aux_rule__param_15();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__param_12Context* altnt_block__param_12();

  class  Altnt_block__trait_item_21Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__trait_item_21Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Trait_method_declContext *trait_method_decl();
    Macro_invocation_semiContext *macro_invocation_semi();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__trait_item_21Context* altnt_block__trait_item_21();

  class  Altnt_block__trait_item_22Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__trait_item_22Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__trait_item_26Context *aux_rule__trait_item_26();
    Aux_rule__trait_item_27Context *aux_rule__trait_item_27();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__trait_item_22Context* altnt_block__trait_item_22();

  class  Altnt_block__type_arguments_11Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__type_arguments_11Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__type_arguments_12Context *aux_rule__type_arguments_12();
    Aux_rule__type_arguments_13Context *aux_rule__type_arguments_13();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__type_arguments_11Context* altnt_block__type_arguments_11();

  class  Altnt_block__pattern_without_mut_31Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__pattern_without_mut_31Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__pattern_without_mut_44Context *aux_rule__pattern_without_mut_44();
    Aux_rule__pattern_without_mut_45Context *aux_rule__pattern_without_mut_45();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__pattern_without_mut_31Context* altnt_block__pattern_without_mut_31();

  class  Altnt_block__pat_field_6Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__pat_field_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__pat_field_7Context *aux_rule__pat_field_7();
    Aux_rule__pat_field_8Context *aux_rule__pat_field_8();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__pat_field_6Context* altnt_block__pat_field_6();

  class  Altnt_block__blocky_expr_15Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__blocky_expr_15Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    While_cond_or_patContext *while_cond_or_pat();
    Optional__blocky_expr_14Context *optional__blocky_expr_14();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__blocky_expr_15Context* altnt_block__blocky_expr_15();

  class  Altnt_block__prim_expr_no_struct_22Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__prim_expr_no_struct_22Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__prim_expr_no_struct_33Context *aux_rule__prim_expr_no_struct_33();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__prim_expr_no_struct_22Context* altnt_block__prim_expr_no_struct_22();

  class  Altnt_block__prim_expr_no_struct_23Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__prim_expr_no_struct_23Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__block_with_inner_attrs_3Context *optional__block_with_inner_attrs_3();
    Aux_rule__prim_expr_no_struct_34Context *aux_rule__prim_expr_no_struct_34();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__prim_expr_no_struct_23Context* altnt_block__prim_expr_no_struct_23();

  class  Altnt_block__prim_expr_no_struct_24Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__prim_expr_no_struct_24Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__prim_expr_no_struct_5Context *optional__prim_expr_no_struct_5();
    Aux_rule__prim_expr_no_struct_35Context *aux_rule__prim_expr_no_struct_35();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__prim_expr_no_struct_24Context* altnt_block__prim_expr_no_struct_24();

  class  Altnt_block__range_expr_8Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__range_expr_8Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__range_expr_8Context* altnt_block__range_expr_8();

  class  Altnt_block__item_7Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__item_7Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__item_8Context *aux_rule__item_8();
    Impl_blockContext *impl_block();
    Extern_modContext *extern_mod();
    Macro_rules_definitionContext *macro_rules_definition();
    Macro_invocation_semiContext *macro_invocation_semi();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__item_7Context* altnt_block__item_7();

  class  Altnt_block__param_11Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__param_11Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Ty_sumContext *ty_sum();
    Aux_rule__param_16Context *aux_rule__param_16();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__param_11Context* altnt_block__param_11();

  class  Altnt_block__ty_path_segment_no_super_6Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__ty_path_segment_no_super_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__ty_path_segment_no_super_7Context *aux_rule__ty_path_segment_no_super_7();
    IdentContext *ident();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__ty_path_segment_no_super_6Context* altnt_block__ty_path_segment_no_super_6();

  class  Aux_rule__post_expr_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__post_expr_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__post_expr_3Context *aux_rule__post_expr_3();
    Aux_rule__post_expr_4Context *aux_rule__post_expr_4();
    Aux_rule__post_expr_5Context *aux_rule__post_expr_5();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__post_expr_2Context* aux_rule__post_expr_2();

  class  Aux_rule__visibility_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__visibility_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__visibility_1Context *optional__visibility_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__visibility_2Context* aux_rule__visibility_2();

  class  Aux_rule__use_suffix_3Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__use_suffix_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__use_suffix_2Context *altnt_block__use_suffix_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__use_suffix_3Context* aux_rule__use_suffix_3();

  class  Aux_rule__foreign_item_tail_12Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__foreign_item_tail_12Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__foreign_item_tail_11Context *altnt_block__foreign_item_tail_11();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__foreign_item_tail_12Context* aux_rule__foreign_item_tail_12();

  class  Aux_rule__param_13Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__param_13Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__item_1Context *kleene_star__item_1();
    Altnt_block__param_12Context *altnt_block__param_12();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__param_13Context* aux_rule__param_13();

  class  Aux_rule__self_param_6Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__self_param_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__static_decl_1Context *optional__static_decl_1();
    Optional__associated_const_decl_2Context *optional__associated_const_decl_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__self_param_6Context* aux_rule__self_param_6();

  class  Aux_rule__self_param_7Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__self_param_7Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__type_1Context *optional__type_1();
    Optional__static_decl_1Context *optional__static_decl_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__self_param_7Context* aux_rule__self_param_7();

  class  Aux_rule__trait_method_param_10Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__trait_method_param_10Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__trait_method_param_6Context *altnt_block__trait_method_param_6();
    Ty_sumContext *ty_sum();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__trait_method_param_10Context* aux_rule__trait_method_param_10();

  class  Aux_rule__struct_tail_9Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__struct_tail_9Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__impl_block_6Context *optional__impl_block_6();
    Optional__struct_tail_5Context *optional__struct_tail_5();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__struct_tail_9Context* aux_rule__struct_tail_9();

  class  Aux_rule__struct_tail_10Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__struct_tail_10Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__struct_tail_6Context *altnt_block__struct_tail_6();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__struct_tail_10Context* aux_rule__struct_tail_10();

  class  Aux_rule__trait_item_23Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__trait_item_23Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__impl_block_1Context *optional__impl_block_1();
    Optional__item_2Context *optional__item_2();
    Altnt_block__trait_item_20Context *altnt_block__trait_item_20();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__trait_item_23Context* aux_rule__trait_item_23();

  class  Aux_rule__trait_item_24Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__trait_item_24Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__trait_item_19Context *altnt_block__trait_item_19();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__trait_item_24Context* aux_rule__trait_item_24();

  class  Aux_rule__trait_item_25Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__trait_item_25Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__item_1Context *kleene_star__item_1();
    Optional__impl_block_1Context *optional__impl_block_1();
    Optional__item_2Context *optional__item_2();
    Altnt_block__trait_item_21Context *altnt_block__trait_item_21();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__trait_item_25Context* aux_rule__trait_item_25();

  class  Aux_rule__impl_what_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__impl_what_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__impl_what_2Context *optional__impl_what_2();
    Ty_sumContext *ty_sum();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__impl_what_4Context* aux_rule__impl_what_4();

  class  Aux_rule__impl_what_5Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__impl_what_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    IdentContext *ident();
    Type_argumentsContext *type_arguments();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__impl_what_5Context* aux_rule__impl_what_5();

  class  Aux_rule__impl_what_6Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__impl_what_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Ty_sumContext *ty_sum();
    Altnt_block__impl_what_3Context *altnt_block__impl_what_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__impl_what_6Context* aux_rule__impl_what_6();

  class  Aux_rule__impl_item_tail_14Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__impl_item_tail_14Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__impl_block_1Context *optional__impl_block_1();
    Method_declContext *method_decl();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__impl_item_tail_14Context* aux_rule__impl_item_tail_14();

  class  Aux_rule__impl_item_tail_15Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__impl_item_tail_15Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__impl_item_tail_13Context *altnt_block__impl_item_tail_13();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__impl_item_tail_15Context* aux_rule__impl_item_tail_15();

  class  Aux_rule__tt_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__tt_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__tt_1Context* aux_rule__tt_1();

  class  Aux_rule__ty_path_tail_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__ty_path_tail_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__ty_path_tail_3Context *altnt_block__ty_path_tail_3();
    Optional__ty_path_tail_1Context *optional__ty_path_tail_1();
    Optional__foreign_fn_decl_2Context *optional__foreign_fn_decl_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__ty_path_tail_4Context* aux_rule__ty_path_tail_4();

  class  Aux_rule__where_bound_3Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__where_bound_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    LifetimeContext *lifetime();
    Lifetime_boundContext *lifetime_bound();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__where_bound_3Context* aux_rule__where_bound_3();

  class  Aux_rule__where_bound_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__where_bound_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__where_bound_1Context *optional__where_bound_1();
    TypeContext *type();
    Optional__where_bound_2Context *optional__where_bound_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__where_bound_4Context* aux_rule__where_bound_4();

  class  Aux_rule__trait_bound_5Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__trait_bound_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__impl_block_4Context *optional__impl_block_4();
    Optional__where_bound_1Context *optional__where_bound_1();
    Type_path_mainContext *type_path_main();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__trait_bound_5Context* aux_rule__trait_bound_5();

  class  Aux_rule__trait_bound_6Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__trait_bound_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__impl_block_4Context *optional__impl_block_4();
    Optional__where_bound_1Context *optional__where_bound_1();
    Type_path_mainContext *type_path_main();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__trait_bound_6Context* aux_rule__trait_bound_6();

  class  Aux_rule__type_argument_3Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__type_argument_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__type_argument_2Context *optional__type_argument_2();
    Ty_sumContext *ty_sum();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__type_argument_3Context* aux_rule__type_argument_3();

  class  Aux_rule__type_parameter_5Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__type_parameter_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__item_1Context *kleene_star__item_1();
    Optional__impl_block_5Context *optional__impl_block_5();
    IdentContext *ident();
    Optional__type_decl_4Context *optional__type_decl_4();
    Optional__type_parameter_4Context *optional__type_parameter_4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__type_parameter_5Context* aux_rule__type_parameter_5();

  class  Aux_rule__pattern_3Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__pattern_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    IdentContext *ident();
    Optional__pattern_2Context *optional__pattern_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__pattern_3Context* aux_rule__pattern_3();

  class  Aux_rule__pat_ident_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__pat_ident_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    IdentContext *ident();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__pat_ident_1Context* aux_rule__pat_ident_1();

  class  Aux_rule__pat_list_with_dots_6Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__pat_list_with_dots_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Match_patternContext *match_pattern();
    Kleene_star__pattern_without_mut_16Context *kleene_star__pattern_without_mut_16();
    Optional__pat_list_with_dots_5Context *optional__pat_list_with_dots_5();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__pat_list_with_dots_6Context* aux_rule__pat_list_with_dots_6();

  class  Aux_rule__pat_fields_8Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__pat_fields_8Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Pat_fields_leftContext *> pat_fields_left();
    Pat_fields_leftContext* pat_fields_left(size_t i);
    Kleene_star__pat_fields_2Context *kleene_star__pat_fields_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__pat_fields_8Context* aux_rule__pat_fields_8();

  class  Aux_rule__pat_fields_9Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__pat_fields_9Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Pat_fieldContext *pat_field();
    Kleene_star__pat_fields_4Context *kleene_star__pat_fields_4();
    Altnt_block__pat_fields_7Context *altnt_block__pat_fields_7();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__pat_fields_9Context* aux_rule__pat_fields_9();

  class  Aux_rule__stmt_9Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__stmt_9Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__item_1Context *kleene_star__item_1();
    Blocky_exprContext *blocky_expr();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__stmt_9Context* aux_rule__stmt_9();

  class  Aux_rule__stmt_10Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__stmt_10Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__stmt_8Context *altnt_block__stmt_8();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__stmt_10Context* aux_rule__stmt_10();

  class  Aux_rule__blocky_expr_16Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__blocky_expr_16Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    If_cond_or_patContext *if_cond_or_pat();
    BlockContext *block();
    Kleene_star__blocky_expr_2Context *kleene_star__blocky_expr_2();
    Optional__blocky_expr_4Context *optional__blocky_expr_4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__blocky_expr_16Context* aux_rule__blocky_expr_16();

  class  Aux_rule__blocky_expr_17Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__blocky_expr_17Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Expr_no_structContext *expr_no_struct();
    Optional__blocky_expr_5Context *optional__blocky_expr_5();
    Optional__blocky_expr_6Context *optional__blocky_expr_6();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__blocky_expr_17Context* aux_rule__blocky_expr_17();

  class  Aux_rule__blocky_expr_18Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__blocky_expr_18Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__blocky_expr_12Context *altnt_block__blocky_expr_12();
    Block_with_inner_attrsContext *block_with_inner_attrs();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__blocky_expr_18Context* aux_rule__blocky_expr_18();

  class  Aux_rule__prim_expr_3Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__prim_expr_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    PathContext *path();
    Optional__prim_expr_1Context *optional__prim_expr_1();
    Optional__prim_expr_2Context *optional__prim_expr_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__prim_expr_3Context* aux_rule__prim_expr_3();

  class  Aux_rule__prim_expr_no_struct_25Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__prim_expr_no_struct_25Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    PathContext *path();
    Optional__prim_expr_no_struct_1Context *optional__prim_expr_no_struct_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__prim_expr_no_struct_25Context* aux_rule__prim_expr_no_struct_25();

  class  Aux_rule__prim_expr_no_struct_26Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__prim_expr_no_struct_26Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__prim_expr_no_struct_9Context *optional__prim_expr_no_struct_9();
    Optional__prim_expr_no_struct_10Context *optional__prim_expr_no_struct_10();
    Closure_paramsContext *closure_params();
    Closure_tailContext *closure_tail();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__prim_expr_no_struct_26Context* aux_rule__prim_expr_no_struct_26();

  class  Aux_rule__prim_expr_no_struct_27Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__prim_expr_no_struct_27Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__prim_expr_no_struct_20Context *altnt_block__prim_expr_no_struct_20();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__prim_expr_no_struct_27Context* aux_rule__prim_expr_no_struct_27();

  class  Aux_rule__prim_expr_no_struct_28Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__prim_expr_no_struct_28Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__type_1Context *optional__type_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__prim_expr_no_struct_28Context* aux_rule__prim_expr_no_struct_28();

  class  Aux_rule__prim_expr_no_struct_29Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__prim_expr_no_struct_29Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__prim_expr_no_struct_18Context *altnt_block__prim_expr_no_struct_18();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__prim_expr_no_struct_29Context* aux_rule__prim_expr_no_struct_29();

  class  Aux_rule__prim_expr_no_struct_30Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__prim_expr_no_struct_30Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__prim_expr_no_struct_19Context *altnt_block__prim_expr_no_struct_19();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__prim_expr_no_struct_30Context* aux_rule__prim_expr_no_struct_30();

  class  Aux_rule__prim_expr_no_struct_31Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__prim_expr_no_struct_31Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__prim_expr_no_struct_22Context *altnt_block__prim_expr_no_struct_22();
    Optional__block_with_inner_attrs_3Context *optional__block_with_inner_attrs_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__prim_expr_no_struct_31Context* aux_rule__prim_expr_no_struct_31();

  class  Aux_rule__closure_params_3Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__closure_params_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__closure_params_2Context *optional__closure_params_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__closure_params_3Context* aux_rule__closure_params_3();

  class  Aux_rule__closure_tail_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__closure_tail_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__foreign_fn_decl_2Context *optional__foreign_fn_decl_2();
    BlockContext *block();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__closure_tail_2Context* aux_rule__closure_tail_2();

  class  Aux_rule__fields_5Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__fields_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    FieldContext *field();
    Kleene_star__fields_2Context *kleene_star__fields_2();
    Altnt_block__fields_4Context *altnt_block__fields_4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__fields_5Context* aux_rule__fields_5();

  class  Aux_rule__field_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__field_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__field_1Context *kleene_star__field_1();
    Field_nameContext *field_name();
    ExprContext *expr();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__field_2Context* aux_rule__field_2();

  class  Aux_rule__pre_expr_5Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__pre_expr_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Expr_no_structContext *expr_no_struct();
    BlockContext *block();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__pre_expr_5Context* aux_rule__pre_expr_5();

  class  Aux_rule__pre_expr_6Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__pre_expr_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__pre_expr_3Context *altnt_block__pre_expr_3();
    Pre_exprContext *pre_expr();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__pre_expr_6Context* aux_rule__pre_expr_6();

  class  Aux_rule__range_expr_9Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__range_expr_9Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Or_exprContext *or_expr();
    Altnt_block__range_expr_7Context *altnt_block__range_expr_7();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__range_expr_9Context* aux_rule__range_expr_9();

  class  Aux_rule__range_expr_10Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__range_expr_10Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__range_expr_8Context *altnt_block__range_expr_8();
    Optional__range_expr_1Context *optional__range_expr_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__range_expr_10Context* aux_rule__range_expr_10();

  class  Aux_rule__pre_expr_no_struct_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__pre_expr_no_struct_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__pre_expr_3Context *altnt_block__pre_expr_3();
    Pre_expr_no_structContext *pre_expr_no_struct();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__pre_expr_no_struct_4Context* aux_rule__pre_expr_no_struct_4();

  class  Aux_rule__range_expr_no_struct_9Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__range_expr_no_struct_9Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Or_expr_no_structContext *or_expr_no_struct();
    Altnt_block__range_expr_no_struct_7Context *altnt_block__range_expr_no_struct_7();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__range_expr_no_struct_9Context* aux_rule__range_expr_no_struct_9();

  class  Aux_rule__range_expr_no_struct_10Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__range_expr_no_struct_10Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__range_expr_8Context *altnt_block__range_expr_8();
    Optional__range_expr_no_struct_1Context *optional__range_expr_no_struct_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__range_expr_no_struct_10Context* aux_rule__range_expr_no_struct_10();

  class  Aux_rule__macro_rules_def_5Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__macro_rules_def_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__macro_rules_def_1Context *optional__macro_rules_def_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__macro_rules_def_5Context* aux_rule__macro_rules_def_5();

  class  Aux_rule__macro_rules_def_6Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__macro_rules_def_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__macro_rules_def_4Context *altnt_block__macro_rules_def_4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__macro_rules_def_6Context* aux_rule__macro_rules_def_6();

  class  Aux_rule__macro_matcher_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__macro_matcher_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__macro_matcher_1Context *kleene_star__macro_matcher_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__macro_matcher_4Context* aux_rule__macro_matcher_4();

  class  Aux_rule__macro_matcher_5Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__macro_matcher_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__macro_matcher_1Context *kleene_star__macro_matcher_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__macro_matcher_5Context* aux_rule__macro_matcher_5();

  class  Aux_rule__macro_matcher_6Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__macro_matcher_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__macro_matcher_1Context *kleene_star__macro_matcher_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__macro_matcher_6Context* aux_rule__macro_matcher_6();

  class  Aux_rule__macro_match_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__macro_match_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *CashMoney();
    Altnt_block__macro_match_3Context *altnt_block__macro_match_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__macro_match_4Context* aux_rule__macro_match_4();

  class  Aux_rule__delim_token_tree_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__delim_token_tree_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__inner_attr_1Context *kleene_star__inner_attr_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__delim_token_tree_4Context* aux_rule__delim_token_tree_4();

  class  Aux_rule__delim_token_tree_5Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__delim_token_tree_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__inner_attr_1Context *kleene_star__inner_attr_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__delim_token_tree_5Context* aux_rule__delim_token_tree_5();

  class  Aux_rule__delim_token_tree_6Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__delim_token_tree_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__inner_attr_1Context *kleene_star__inner_attr_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__delim_token_tree_6Context* aux_rule__delim_token_tree_6();

  class  Aux_rule__prim_bound_6Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__prim_bound_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__impl_block_4Context *optional__impl_block_4();
    Optional__where_bound_1Context *optional__where_bound_1();
    Optional__prim_bound_4Context *optional__prim_bound_4();
    Type_path_mainContext *type_path_main();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__prim_bound_6Context* aux_rule__prim_bound_6();

  class  Aux_rule__bound_5Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__bound_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Prim_boundContext *prim_bound();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__bound_5Context* aux_rule__bound_5();

  class  Aux_rule__bound_6Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__bound_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__type_parameters_2Context *kleene_star__type_parameters_2();
    Type_parameter_listContext *type_parameter_list();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__bound_6Context* aux_rule__bound_6();

  class  Aux_rule__path_parent_6Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__path_parent_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Ty_sumContext *ty_sum();
    Optional__path_parent_1Context *optional__path_parent_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__path_parent_6Context* aux_rule__path_parent_6();

  class  Aux_rule__path_parent_7Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__path_parent_7Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__simple_path_1Context *optional__simple_path_1();
    Path_segmentContext *path_segment();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__path_parent_7Context* aux_rule__path_parent_7();

  class  Aux_rule__ty_path_parent_6Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__ty_path_parent_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Ty_sumContext *ty_sum();
    Optional__path_parent_1Context *optional__path_parent_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__ty_path_parent_6Context* aux_rule__ty_path_parent_6();

  class  Aux_rule__ty_path_parent_7Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__ty_path_parent_7Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__simple_path_1Context *optional__simple_path_1();
    Type_path_segmentContext *type_path_segment();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__ty_path_parent_7Context* aux_rule__ty_path_parent_7();

  class  Aux_rule__pattern_without_mut_32Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__pattern_without_mut_32Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Pattern_without_mutContext *pattern_without_mut();
    Optional__pattern_without_mut_1Context *optional__pattern_without_mut_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__pattern_without_mut_32Context* aux_rule__pattern_without_mut_32();

  class  Aux_rule__pattern_without_mut_33Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__pattern_without_mut_33Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__pattern_without_mut_12Context *optional__pattern_without_mut_12();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__pattern_without_mut_33Context* aux_rule__pattern_without_mut_33();

  class  Aux_rule__pattern_without_mut_34Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__pattern_without_mut_34Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__pattern_without_mut_22Context *optional__pattern_without_mut_22();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__pattern_without_mut_34Context* aux_rule__pattern_without_mut_34();

  class  Aux_rule__pattern_without_mut_35Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__pattern_without_mut_35Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__pattern_without_mut_25Context *altnt_block__pattern_without_mut_25();
    PatternContext *pattern();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__pattern_without_mut_35Context* aux_rule__pattern_without_mut_35();

  class  Aux_rule__pattern_without_mut_36Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__pattern_without_mut_36Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Pat_range_endContext *> pat_range_end();
    Pat_range_endContext* pat_range_end(size_t i);
    Altnt_block__pattern_without_mut_26Context *altnt_block__pattern_without_mut_26();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__pattern_without_mut_36Context* aux_rule__pattern_without_mut_36();

  class  Aux_rule__pattern_without_mut_37Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__pattern_without_mut_37Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    PathContext *path();
    Altnt_block__pattern_without_mut_27Context *altnt_block__pattern_without_mut_27();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__pattern_without_mut_37Context* aux_rule__pattern_without_mut_37();

  class  Aux_rule__pattern_without_mut_38Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__pattern_without_mut_38Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    IdentContext *ident();
    Altnt_block__pattern_without_mut_28Context *altnt_block__pattern_without_mut_28();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__pattern_without_mut_38Context* aux_rule__pattern_without_mut_38();

  class  Aux_rule__pattern_without_mut_39Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__pattern_without_mut_39Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__pattern_without_mut_29Context *altnt_block__pattern_without_mut_29();
    Pattern_without_mutContext *pattern_without_mut();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__pattern_without_mut_39Context* aux_rule__pattern_without_mut_39();

  class  Aux_rule__pattern_without_mut_40Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__pattern_without_mut_40Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__pattern_without_mut_31Context *altnt_block__pattern_without_mut_31();
    Optional__pattern_2Context *optional__pattern_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__pattern_without_mut_40Context* aux_rule__pattern_without_mut_40();

  class  Aux_rule__visibility_restriction_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__visibility_restriction_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Simple_pathContext *simple_path();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__visibility_restriction_2Context* aux_rule__visibility_restriction_2();

  class  Aux_rule__use_suffix_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__use_suffix_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__use_path_2Context *optional__use_path_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__use_suffix_4Context* aux_rule__use_suffix_4();

  class  Aux_rule__foreign_item_tail_13Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__foreign_item_tail_13Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__static_decl_1Context *optional__static_decl_1();
    IdentContext *ident();
    TypeContext *type();
    Optional__foreign_item_tail_3Context *optional__foreign_item_tail_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__foreign_item_tail_13Context* aux_rule__foreign_item_tail_13();

  class  Aux_rule__foreign_item_tail_14Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__foreign_item_tail_14Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    IdentContext *ident();
    Optional__impl_block_3Context *optional__impl_block_3();
    Optional__type_decl_4Context *optional__type_decl_4();
    Optional__impl_block_6Context *optional__impl_block_6();
    Optional__type_decl_7Context *optional__type_decl_7();
    Optional__type_decl_9Context *optional__type_decl_9();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__foreign_item_tail_14Context* aux_rule__foreign_item_tail_14();

  class  Aux_rule__macro_invocation_semi_6Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__macro_invocation_semi_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__inner_attr_1Context *kleene_star__inner_attr_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__macro_invocation_semi_6Context* aux_rule__macro_invocation_semi_6();

  class  Aux_rule__macro_invocation_semi_7Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__macro_invocation_semi_7Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__macro_invocation_semi_5Context *altnt_block__macro_invocation_semi_5();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__macro_invocation_semi_7Context* aux_rule__macro_invocation_semi_7();

  class  Aux_rule__type_parameters_5Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__type_parameters_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__type_parameters_2Context *kleene_star__type_parameters_2();
    Optional__type_parameters_3Context *optional__type_parameters_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__type_parameters_5Context* aux_rule__type_parameters_5();

  class  Aux_rule__enum_variant_main_6Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__enum_variant_main_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__struct_tail_5Context *optional__struct_tail_5();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__enum_variant_main_6Context* aux_rule__enum_variant_main_6();

  class  Aux_rule__enum_variant_main_7Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__enum_variant_main_7Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ExprContext *expr();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__enum_variant_main_7Context* aux_rule__enum_variant_main_7();

  class  Aux_rule__impl_item_tail_16Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__impl_item_tail_16Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__impl_block_1Context *optional__impl_block_1();
    IdentContext *ident();
    Optional__impl_block_3Context *optional__impl_block_3();
    Optional__impl_block_6Context *optional__impl_block_6();
    Ty_sumContext *ty_sum();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__impl_item_tail_16Context* aux_rule__impl_item_tail_16();

  class  Aux_rule__impl_item_tail_17Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__impl_item_tail_17Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    IdentContext *ident();
    Optional__impl_block_3Context *optional__impl_block_3();
    Optional__type_decl_4Context *optional__type_decl_4();
    Optional__impl_block_6Context *optional__impl_block_6();
    Optional__type_decl_7Context *optional__type_decl_7();
    Optional__impl_item_tail_12Context *optional__impl_item_tail_12();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__impl_item_tail_17Context* aux_rule__impl_item_tail_17();

  class  Aux_rule__pattern_without_mut_41Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__pattern_without_mut_41Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__pattern_without_mut_29Context *altnt_block__pattern_without_mut_29();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__pattern_without_mut_41Context* aux_rule__pattern_without_mut_41();

  class  Aux_rule__pattern_without_mut_42Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__pattern_without_mut_42Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__pattern_without_mut_13Context *optional__pattern_without_mut_13();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__pattern_without_mut_42Context* aux_rule__pattern_without_mut_42();

  class  Aux_rule__pattern_without_mut_43Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__pattern_without_mut_43Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Match_patternContext *match_pattern();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__pattern_without_mut_43Context* aux_rule__pattern_without_mut_43();

  class  Aux_rule__pat_fields_10Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__pat_fields_10Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Pat_fields_leftContext *> pat_fields_left();
    Pat_fields_leftContext* pat_fields_left(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__pat_fields_10Context* aux_rule__pat_fields_10();

  class  Aux_rule__stmt_11Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__stmt_11Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__item_1Context *kleene_star__item_1();
    Match_patternContext *match_pattern();
    Optional__type_decl_7Context *optional__type_decl_7();
    Optional__foreign_item_tail_3Context *optional__foreign_item_tail_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__stmt_11Context* aux_rule__stmt_11();

  class  Aux_rule__blocky_expr_19Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__blocky_expr_19Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__blocky_expr_7Context *optional__blocky_expr_7();
    Altnt_block__blocky_expr_15Context *altnt_block__blocky_expr_15();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__blocky_expr_19Context* aux_rule__blocky_expr_19();

  class  Aux_rule__if_cond_or_pat_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__if_cond_or_pat_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    PatternContext *pattern();
    ExprContext *expr();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__if_cond_or_pat_2Context* aux_rule__if_cond_or_pat_2();

  class  Aux_rule__match_arms_7Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__match_arms_7Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Blocky_exprContext *blocky_expr();
    Optional__use_item_list_3Context *optional__use_item_list_3();
    Optional__blocky_expr_6Context *optional__blocky_expr_6();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__match_arms_7Context* aux_rule__match_arms_7();

  class  Aux_rule__match_arms_8Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__match_arms_8Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ExprContext *expr();
    Optional__match_arms_5Context *optional__match_arms_5();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__match_arms_8Context* aux_rule__match_arms_8();

  class  Aux_rule__post_expr_tail_8Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__post_expr_tail_8Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    IdentContext *ident();
    Optional__post_expr_tail_5Context *optional__post_expr_tail_5();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__post_expr_tail_8Context* aux_rule__post_expr_tail_8();

  class  Aux_rule__pre_expr_7Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__pre_expr_7Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__pattern_without_mut_29Context *altnt_block__pattern_without_mut_29();
    Optional__static_decl_1Context *optional__static_decl_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__pre_expr_7Context* aux_rule__pre_expr_7();

  class  Aux_rule__shift_expr_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__shift_expr_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__shift_expr_4Context* aux_rule__shift_expr_4();

  class  Aux_rule__shift_expr_5Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__shift_expr_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__shift_expr_5Context* aux_rule__shift_expr_5();

  class  Aux_rule__range_expr_11Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__range_expr_11Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__range_expr_1Context *optional__range_expr_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__range_expr_11Context* aux_rule__range_expr_11();

  class  Aux_rule__range_expr_no_struct_11Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__range_expr_no_struct_11Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__range_expr_no_struct_1Context *optional__range_expr_no_struct_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__range_expr_no_struct_11Context* aux_rule__range_expr_no_struct_11();

  class  Aux_rule__macro_rules_def_7Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__macro_rules_def_7Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__macro_rules_def_1Context *optional__macro_rules_def_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__macro_rules_def_7Context* aux_rule__macro_rules_def_7();

  class  Aux_rule__macro_rules_def_8Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__macro_rules_def_8Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__macro_rules_def_1Context *optional__macro_rules_def_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__macro_rules_def_8Context* aux_rule__macro_rules_def_8();

  class  Aux_rule__macro_match_5Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__macro_match_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__param_3Context *aux_rule__param_3();
    antlr4::tree::TerminalNode *EOF();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__macro_match_5Context* aux_rule__macro_match_5();

  class  Aux_rule__macro_match_6Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__macro_match_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_plus__macro_match_1Context *kleene_plus__macro_match_1();
    Optional__macro_match_2Context *optional__macro_match_2();
    Macro_rep_opContext *macro_rep_op();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__macro_match_6Context* aux_rule__macro_match_6();

  class  Aux_rule__macro_invocation_semi_8Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__macro_invocation_semi_8Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__inner_attr_1Context *kleene_star__inner_attr_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__macro_invocation_semi_8Context* aux_rule__macro_invocation_semi_8();

  class  Aux_rule__macro_invocation_semi_9Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__macro_invocation_semi_9Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__inner_attr_1Context *kleene_star__inner_attr_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__macro_invocation_semi_9Context* aux_rule__macro_invocation_semi_9();

  class  Aux_rule__type_3Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__type_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Ty_sumContext *ty_sum();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__type_3Context* aux_rule__type_3();

  class  Aux_rule__type_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__type_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__type_1Context *optional__type_1();
    Optional__static_decl_1Context *optional__static_decl_1();
    TypeContext *type();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__type_4Context* aux_rule__type_4();

  class  Aux_rule__type_5Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__type_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ExprContext *expr();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__type_5Context* aux_rule__type_5();

  class  Aux_rule__fn_rtype_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__fn_rtype_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    BoundContext *bound();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__fn_rtype_2Context* aux_rule__fn_rtype_2();

  class  Aux_rule__trait_alias_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__trait_alias_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Ty_sumContext *ty_sum();
    Optional__impl_block_6Context *optional__impl_block_6();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__trait_alias_4Context* aux_rule__trait_alias_4();

  class  Aux_rule__pat_fields_11Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__pat_fields_11Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__pat_fields_11Context* aux_rule__pat_fields_11();

  class  Aux_rule__prim_expr_no_struct_32Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__prim_expr_no_struct_32Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Closure_paramsContext *closure_params();
    Closure_tailContext *closure_tail();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__prim_expr_no_struct_32Context* aux_rule__prim_expr_no_struct_32();

  class  Aux_rule__fields_6Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__fields_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Struct_update_baseContext *struct_update_base();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__fields_6Context* aux_rule__fields_6();

  class  Aux_rule__assign_expr_no_struct_6Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__assign_expr_no_struct_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__assign_expr_no_struct_5Context *optional__assign_expr_no_struct_5();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__assign_expr_no_struct_6Context* aux_rule__assign_expr_no_struct_6();

  class  Aux_rule__cmp_expr_no_struct_9Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__cmp_expr_no_struct_9Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__cmp_expr_no_struct_8Context *optional__cmp_expr_no_struct_8();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__cmp_expr_no_struct_9Context* aux_rule__cmp_expr_no_struct_9();

  class  Aux_rule__trait_method_param_11Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__trait_method_param_11Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__trait_method_param_3Context *kleene_star__trait_method_param_3();
    Restricted_patContext *restricted_pat();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__trait_method_param_11Context* aux_rule__trait_method_param_11();

  class  Aux_rule__type_decl_12Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__type_decl_12Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__impl_block_6Context *optional__impl_block_6();
    Ty_sumContext *ty_sum();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__type_decl_12Context* aux_rule__type_decl_12();

  class  Aux_rule__type_decl_13Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__type_decl_13Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__type_decl_4Context *optional__type_decl_4();
    Optional__impl_block_6Context *optional__impl_block_6();
    Optional__type_decl_7Context *optional__type_decl_7();
    Optional__type_decl_9Context *optional__type_decl_9();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__type_decl_13Context* aux_rule__type_decl_13();

  class  Aux_rule__use_path_9Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__use_path_9Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__use_path_2Context *optional__use_path_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__use_path_9Context* aux_rule__use_path_9();

  class  Aux_rule__use_path_10Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__use_path_10Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__use_path_7Context *altnt_block__use_path_7();
    Kleene_star__use_path_5Context *kleene_star__use_path_5();
    Optional__use_path_6Context *optional__use_path_6();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__use_path_10Context* aux_rule__use_path_10();

  class  Aux_rule__foreign_item_5Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__foreign_item_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__item_2Context *optional__item_2();
    Foreign_item_tailContext *foreign_item_tail();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__foreign_item_5Context* aux_rule__foreign_item_5();

  class  Aux_rule__param_14Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__param_14Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__expr_2Context *optional__expr_2();
    Optional__param_4Context *optional__param_4();
    PatternContext *pattern();
    Altnt_block__param_11Context *altnt_block__param_11();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__param_14Context* aux_rule__param_14();

  class  Aux_rule__param_15Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__param_15Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__param_6Context *optional__param_6();
    Optional__type_1Context *optional__type_1();
    Optional__expr_2Context *optional__expr_2();
    Optional__type_decl_7Context *optional__type_decl_7();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__param_15Context* aux_rule__param_15();

  class  Aux_rule__trait_item_26Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__trait_item_26Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__item_2Context *optional__item_2();
    IdentContext *ident();
    Optional__impl_block_3Context *optional__impl_block_3();
    Optional__type_decl_4Context *optional__type_decl_4();
    Optional__impl_block_6Context *optional__impl_block_6();
    Optional__type_parameter_4Context *optional__type_parameter_4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__trait_item_26Context* aux_rule__trait_item_26();

  class  Aux_rule__trait_item_27Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__trait_item_27Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    IdentContext *ident();
    Ty_sumContext *ty_sum();
    Optional__foreign_item_tail_3Context *optional__foreign_item_tail_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__trait_item_27Context* aux_rule__trait_item_27();

  class  Aux_rule__type_arguments_12Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__type_arguments_12Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    LifetimeContext *lifetime();
    Kleene_star__type_arguments_2Context *kleene_star__type_arguments_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__type_arguments_12Context* aux_rule__type_arguments_12();

  class  Aux_rule__type_arguments_13Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__type_arguments_13Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__type_arguments_5Context *kleene_star__type_arguments_5();
    Type_argumentContext *type_argument();
    Kleene_star__type_arguments_7Context *kleene_star__type_arguments_7();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__type_arguments_13Context* aux_rule__type_arguments_13();

  class  Aux_rule__pattern_without_mut_44Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__pattern_without_mut_44Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Kleene_star__pattern_without_mut_5Context *kleene_star__pattern_without_mut_5();
    Pat_identContext *pat_ident();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__pattern_without_mut_44Context* aux_rule__pattern_without_mut_44();

  class  Aux_rule__pattern_without_mut_45Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__pattern_without_mut_45Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__restricted_pat_1Context *optional__restricted_pat_1();
    Optional__static_decl_1Context *optional__static_decl_1();
    IdentContext *ident();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__pattern_without_mut_45Context* aux_rule__pattern_without_mut_45();

  class  Aux_rule__pat_field_7Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__pat_field_7Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__pat_field_2Context *optional__pat_field_2();
    Optional__restricted_pat_1Context *optional__restricted_pat_1();
    Optional__static_decl_1Context *optional__static_decl_1();
    IdentContext *ident();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__pat_field_7Context* aux_rule__pat_field_7();

  class  Aux_rule__pat_field_8Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__pat_field_8Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    IdentContext *ident();
    PatternContext *pattern();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__pat_field_8Context* aux_rule__pat_field_8();

  class  Aux_rule__prim_expr_no_struct_33Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__prim_expr_no_struct_33Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__prim_expr_no_struct_11Context *optional__prim_expr_no_struct_11();
    Optional__prim_expr_no_struct_12Context *optional__prim_expr_no_struct_12();
    Optional__prim_expr_no_struct_13Context *optional__prim_expr_no_struct_13();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__prim_expr_no_struct_33Context* aux_rule__prim_expr_no_struct_33();

  class  Aux_rule__prim_expr_no_struct_34Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__prim_expr_no_struct_34Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ExprContext *expr();
    Optional__prim_expr_no_struct_5Context *optional__prim_expr_no_struct_5();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__prim_expr_no_struct_34Context* aux_rule__prim_expr_no_struct_34();

  class  Aux_rule__prim_expr_no_struct_35Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__prim_expr_no_struct_35Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<ExprContext *> expr();
    ExprContext* expr(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__prim_expr_no_struct_35Context* aux_rule__prim_expr_no_struct_35();

  class  Aux_rule__item_8Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__item_8Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__item_2Context *optional__item_2();
    Pub_itemContext *pub_item();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__item_8Context* aux_rule__item_8();

  class  Aux_rule__param_16Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__param_16Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    BoundContext *bound();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__param_16Context* aux_rule__param_16();

  class  Aux_rule__ty_path_segment_no_super_7Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__ty_path_segment_no_super_7Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__ty_path_segment_no_super_2Context *optional__ty_path_segment_no_super_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__ty_path_segment_no_super_7Context* aux_rule__ty_path_segment_no_super_7();

  class  Aux_rule__post_expr_3Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__post_expr_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ExprContext *expr();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__post_expr_3Context* aux_rule__post_expr_3();

  class  Aux_rule__post_expr_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__post_expr_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__prim_expr_no_struct_5Context *optional__prim_expr_no_struct_5();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__post_expr_4Context* aux_rule__post_expr_4();

  class  Aux_rule__post_expr_5Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__post_expr_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__post_expr_tail_7Context *altnt_block__post_expr_tail_7();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__post_expr_5Context* aux_rule__post_expr_5();


private:
  static std::vector<antlr4::dfa::DFA> _decisionToDFA;
  static antlr4::atn::PredictionContextCache _sharedContextCache;
  static std::vector<std::string> _ruleNames;
  static std::vector<std::string> _tokenNames;

  static std::vector<std::string> _literalNames;
  static std::vector<std::string> _symbolicNames;
  static antlr4::dfa::Vocabulary _vocabulary;
  static antlr4::atn::ATN _atn;
  static std::vector<uint16_t> _serializedATN;


  struct Initializer {
    Initializer();
  };
  static Initializer _init;
};

}  // namespace antlr_rust_perses
