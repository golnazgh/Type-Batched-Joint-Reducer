
// Generated from PnfRust.g4 by ANTLR 4.7.2

#pragma once


#include "antlr4-runtime.h"
#include "PnfRustListener.h"


namespace antlr_rust_perses {

/**
 * This class provides an empty implementation of PnfRustListener,
 * which can be extended to create a listener which only needs to handle a subset
 * of the available methods.
 */
class  PnfRustBaseListener : public PnfRustListener {
public:

  virtual void enterCrate(PnfRustParser::CrateContext * /*ctx*/) override { }
  virtual void exitCrate(PnfRustParser::CrateContext * /*ctx*/) override { }

  virtual void enterMod_body(PnfRustParser::Mod_bodyContext * /*ctx*/) override { }
  virtual void exitMod_body(PnfRustParser::Mod_bodyContext * /*ctx*/) override { }

  virtual void enterVisibility(PnfRustParser::VisibilityContext * /*ctx*/) override { }
  virtual void exitVisibility(PnfRustParser::VisibilityContext * /*ctx*/) override { }

  virtual void enterVisibility_restriction(PnfRustParser::Visibility_restrictionContext * /*ctx*/) override { }
  virtual void exitVisibility_restriction(PnfRustParser::Visibility_restrictionContext * /*ctx*/) override { }

  virtual void enterItem(PnfRustParser::ItemContext * /*ctx*/) override { }
  virtual void exitItem(PnfRustParser::ItemContext * /*ctx*/) override { }

  virtual void enterPub_item(PnfRustParser::Pub_itemContext * /*ctx*/) override { }
  virtual void exitPub_item(PnfRustParser::Pub_itemContext * /*ctx*/) override { }

  virtual void enterExtern_crate(PnfRustParser::Extern_crateContext * /*ctx*/) override { }
  virtual void exitExtern_crate(PnfRustParser::Extern_crateContext * /*ctx*/) override { }

  virtual void enterUse_decl(PnfRustParser::Use_declContext * /*ctx*/) override { }
  virtual void exitUse_decl(PnfRustParser::Use_declContext * /*ctx*/) override { }

  virtual void enterUse_path(PnfRustParser::Use_pathContext * /*ctx*/) override { }
  virtual void exitUse_path(PnfRustParser::Use_pathContext * /*ctx*/) override { }

  virtual void enterUse_suffix(PnfRustParser::Use_suffixContext * /*ctx*/) override { }
  virtual void exitUse_suffix(PnfRustParser::Use_suffixContext * /*ctx*/) override { }

  virtual void enterUse_item(PnfRustParser::Use_itemContext * /*ctx*/) override { }
  virtual void exitUse_item(PnfRustParser::Use_itemContext * /*ctx*/) override { }

  virtual void enterUse_item_list(PnfRustParser::Use_item_listContext * /*ctx*/) override { }
  virtual void exitUse_item_list(PnfRustParser::Use_item_listContext * /*ctx*/) override { }

  virtual void enterRename(PnfRustParser::RenameContext * /*ctx*/) override { }
  virtual void exitRename(PnfRustParser::RenameContext * /*ctx*/) override { }

  virtual void enterMod_decl_short(PnfRustParser::Mod_decl_shortContext * /*ctx*/) override { }
  virtual void exitMod_decl_short(PnfRustParser::Mod_decl_shortContext * /*ctx*/) override { }

  virtual void enterMod_decl(PnfRustParser::Mod_declContext * /*ctx*/) override { }
  virtual void exitMod_decl(PnfRustParser::Mod_declContext * /*ctx*/) override { }

  virtual void enterExtern_mod(PnfRustParser::Extern_modContext * /*ctx*/) override { }
  virtual void exitExtern_mod(PnfRustParser::Extern_modContext * /*ctx*/) override { }

  virtual void enterForeign_item(PnfRustParser::Foreign_itemContext * /*ctx*/) override { }
  virtual void exitForeign_item(PnfRustParser::Foreign_itemContext * /*ctx*/) override { }

  virtual void enterForeign_item_tail(PnfRustParser::Foreign_item_tailContext * /*ctx*/) override { }
  virtual void exitForeign_item_tail(PnfRustParser::Foreign_item_tailContext * /*ctx*/) override { }

  virtual void enterStatic_decl(PnfRustParser::Static_declContext * /*ctx*/) override { }
  virtual void exitStatic_decl(PnfRustParser::Static_declContext * /*ctx*/) override { }

  virtual void enterAssociated_static_decl(PnfRustParser::Associated_static_declContext * /*ctx*/) override { }
  virtual void exitAssociated_static_decl(PnfRustParser::Associated_static_declContext * /*ctx*/) override { }

  virtual void enterConst_decl(PnfRustParser::Const_declContext * /*ctx*/) override { }
  virtual void exitConst_decl(PnfRustParser::Const_declContext * /*ctx*/) override { }

  virtual void enterAssociated_const_decl(PnfRustParser::Associated_const_declContext * /*ctx*/) override { }
  virtual void exitAssociated_const_decl(PnfRustParser::Associated_const_declContext * /*ctx*/) override { }

  virtual void enterFn_decl(PnfRustParser::Fn_declContext * /*ctx*/) override { }
  virtual void exitFn_decl(PnfRustParser::Fn_declContext * /*ctx*/) override { }

  virtual void enterMethod_decl(PnfRustParser::Method_declContext * /*ctx*/) override { }
  virtual void exitMethod_decl(PnfRustParser::Method_declContext * /*ctx*/) override { }

  virtual void enterTrait_method_decl(PnfRustParser::Trait_method_declContext * /*ctx*/) override { }
  virtual void exitTrait_method_decl(PnfRustParser::Trait_method_declContext * /*ctx*/) override { }

  virtual void enterForeign_fn_decl(PnfRustParser::Foreign_fn_declContext * /*ctx*/) override { }
  virtual void exitForeign_fn_decl(PnfRustParser::Foreign_fn_declContext * /*ctx*/) override { }

  virtual void enterMacro_decl(PnfRustParser::Macro_declContext * /*ctx*/) override { }
  virtual void exitMacro_decl(PnfRustParser::Macro_declContext * /*ctx*/) override { }

  virtual void enterMacro_head(PnfRustParser::Macro_headContext * /*ctx*/) override { }
  virtual void exitMacro_head(PnfRustParser::Macro_headContext * /*ctx*/) override { }

  virtual void enterFn_head(PnfRustParser::Fn_headContext * /*ctx*/) override { }
  virtual void exitFn_head(PnfRustParser::Fn_headContext * /*ctx*/) override { }

  virtual void enterParam(PnfRustParser::ParamContext * /*ctx*/) override { }
  virtual void exitParam(PnfRustParser::ParamContext * /*ctx*/) override { }

  virtual void enterParam_list(PnfRustParser::Param_listContext * /*ctx*/) override { }
  virtual void exitParam_list(PnfRustParser::Param_listContext * /*ctx*/) override { }

  virtual void enterVariadic_param_list(PnfRustParser::Variadic_param_listContext * /*ctx*/) override { }
  virtual void exitVariadic_param_list(PnfRustParser::Variadic_param_listContext * /*ctx*/) override { }

  virtual void enterVariadic_param_list_names_optional(PnfRustParser::Variadic_param_list_names_optionalContext * /*ctx*/) override { }
  virtual void exitVariadic_param_list_names_optional(PnfRustParser::Variadic_param_list_names_optionalContext * /*ctx*/) override { }

  virtual void enterSelf_param(PnfRustParser::Self_paramContext * /*ctx*/) override { }
  virtual void exitSelf_param(PnfRustParser::Self_paramContext * /*ctx*/) override { }

  virtual void enterMethod_param_list(PnfRustParser::Method_param_listContext * /*ctx*/) override { }
  virtual void exitMethod_param_list(PnfRustParser::Method_param_listContext * /*ctx*/) override { }

  virtual void enterTrait_method_param(PnfRustParser::Trait_method_paramContext * /*ctx*/) override { }
  virtual void exitTrait_method_param(PnfRustParser::Trait_method_paramContext * /*ctx*/) override { }

  virtual void enterRestricted_pat(PnfRustParser::Restricted_patContext * /*ctx*/) override { }
  virtual void exitRestricted_pat(PnfRustParser::Restricted_patContext * /*ctx*/) override { }

  virtual void enterTrait_method_param_list(PnfRustParser::Trait_method_param_listContext * /*ctx*/) override { }
  virtual void exitTrait_method_param_list(PnfRustParser::Trait_method_param_listContext * /*ctx*/) override { }

  virtual void enterRtype(PnfRustParser::RtypeContext * /*ctx*/) override { }
  virtual void exitRtype(PnfRustParser::RtypeContext * /*ctx*/) override { }

  virtual void enterFn_rtype(PnfRustParser::Fn_rtypeContext * /*ctx*/) override { }
  virtual void exitFn_rtype(PnfRustParser::Fn_rtypeContext * /*ctx*/) override { }

  virtual void enterType_decl(PnfRustParser::Type_declContext * /*ctx*/) override { }
  virtual void exitType_decl(PnfRustParser::Type_declContext * /*ctx*/) override { }

  virtual void enterStruct_decl(PnfRustParser::Struct_declContext * /*ctx*/) override { }
  virtual void exitStruct_decl(PnfRustParser::Struct_declContext * /*ctx*/) override { }

  virtual void enterStruct_tail(PnfRustParser::Struct_tailContext * /*ctx*/) override { }
  virtual void exitStruct_tail(PnfRustParser::Struct_tailContext * /*ctx*/) override { }

  virtual void enterTuple_struct_field(PnfRustParser::Tuple_struct_fieldContext * /*ctx*/) override { }
  virtual void exitTuple_struct_field(PnfRustParser::Tuple_struct_fieldContext * /*ctx*/) override { }

  virtual void enterTuple_struct_field_list(PnfRustParser::Tuple_struct_field_listContext * /*ctx*/) override { }
  virtual void exitTuple_struct_field_list(PnfRustParser::Tuple_struct_field_listContext * /*ctx*/) override { }

  virtual void enterField_decl(PnfRustParser::Field_declContext * /*ctx*/) override { }
  virtual void exitField_decl(PnfRustParser::Field_declContext * /*ctx*/) override { }

  virtual void enterField_decl_list(PnfRustParser::Field_decl_listContext * /*ctx*/) override { }
  virtual void exitField_decl_list(PnfRustParser::Field_decl_listContext * /*ctx*/) override { }

  virtual void enterEnum_decl(PnfRustParser::Enum_declContext * /*ctx*/) override { }
  virtual void exitEnum_decl(PnfRustParser::Enum_declContext * /*ctx*/) override { }

  virtual void enterEnum_variant(PnfRustParser::Enum_variantContext * /*ctx*/) override { }
  virtual void exitEnum_variant(PnfRustParser::Enum_variantContext * /*ctx*/) override { }

  virtual void enterEnum_variant_list(PnfRustParser::Enum_variant_listContext * /*ctx*/) override { }
  virtual void exitEnum_variant_list(PnfRustParser::Enum_variant_listContext * /*ctx*/) override { }

  virtual void enterEnum_variant_main(PnfRustParser::Enum_variant_mainContext * /*ctx*/) override { }
  virtual void exitEnum_variant_main(PnfRustParser::Enum_variant_mainContext * /*ctx*/) override { }

  virtual void enterEnum_tuple_field(PnfRustParser::Enum_tuple_fieldContext * /*ctx*/) override { }
  virtual void exitEnum_tuple_field(PnfRustParser::Enum_tuple_fieldContext * /*ctx*/) override { }

  virtual void enterEnum_tuple_field_list(PnfRustParser::Enum_tuple_field_listContext * /*ctx*/) override { }
  virtual void exitEnum_tuple_field_list(PnfRustParser::Enum_tuple_field_listContext * /*ctx*/) override { }

  virtual void enterUnion_decl(PnfRustParser::Union_declContext * /*ctx*/) override { }
  virtual void exitUnion_decl(PnfRustParser::Union_declContext * /*ctx*/) override { }

  virtual void enterTrait_decl(PnfRustParser::Trait_declContext * /*ctx*/) override { }
  virtual void exitTrait_decl(PnfRustParser::Trait_declContext * /*ctx*/) override { }

  virtual void enterTrait_alias(PnfRustParser::Trait_aliasContext * /*ctx*/) override { }
  virtual void exitTrait_alias(PnfRustParser::Trait_aliasContext * /*ctx*/) override { }

  virtual void enterTrait_item(PnfRustParser::Trait_itemContext * /*ctx*/) override { }
  virtual void exitTrait_item(PnfRustParser::Trait_itemContext * /*ctx*/) override { }

  virtual void enterTy_default(PnfRustParser::Ty_defaultContext * /*ctx*/) override { }
  virtual void exitTy_default(PnfRustParser::Ty_defaultContext * /*ctx*/) override { }

  virtual void enterImpl_block(PnfRustParser::Impl_blockContext * /*ctx*/) override { }
  virtual void exitImpl_block(PnfRustParser::Impl_blockContext * /*ctx*/) override { }

  virtual void enterImpl_what(PnfRustParser::Impl_whatContext * /*ctx*/) override { }
  virtual void exitImpl_what(PnfRustParser::Impl_whatContext * /*ctx*/) override { }

  virtual void enterImpl_item(PnfRustParser::Impl_itemContext * /*ctx*/) override { }
  virtual void exitImpl_item(PnfRustParser::Impl_itemContext * /*ctx*/) override { }

  virtual void enterImpl_item_tail(PnfRustParser::Impl_item_tailContext * /*ctx*/) override { }
  virtual void exitImpl_item_tail(PnfRustParser::Impl_item_tailContext * /*ctx*/) override { }

  virtual void enterAttr(PnfRustParser::AttrContext * /*ctx*/) override { }
  virtual void exitAttr(PnfRustParser::AttrContext * /*ctx*/) override { }

  virtual void enterInner_attr(PnfRustParser::Inner_attrContext * /*ctx*/) override { }
  virtual void exitInner_attr(PnfRustParser::Inner_attrContext * /*ctx*/) override { }

  virtual void enterTt(PnfRustParser::TtContext * /*ctx*/) override { }
  virtual void exitTt(PnfRustParser::TtContext * /*ctx*/) override { }

  virtual void enterTt_delimited(PnfRustParser::Tt_delimitedContext * /*ctx*/) override { }
  virtual void exitTt_delimited(PnfRustParser::Tt_delimitedContext * /*ctx*/) override { }

  virtual void enterTt_brackets(PnfRustParser::Tt_bracketsContext * /*ctx*/) override { }
  virtual void exitTt_brackets(PnfRustParser::Tt_bracketsContext * /*ctx*/) override { }

  virtual void enterTt_block(PnfRustParser::Tt_blockContext * /*ctx*/) override { }
  virtual void exitTt_block(PnfRustParser::Tt_blockContext * /*ctx*/) override { }

  virtual void enterMacro_tail(PnfRustParser::Macro_tailContext * /*ctx*/) override { }
  virtual void exitMacro_tail(PnfRustParser::Macro_tailContext * /*ctx*/) override { }

  virtual void enterPath(PnfRustParser::PathContext * /*ctx*/) override { }
  virtual void exitPath(PnfRustParser::PathContext * /*ctx*/) override { }

  virtual void enterAs_trait(PnfRustParser::As_traitContext * /*ctx*/) override { }
  virtual void exitAs_trait(PnfRustParser::As_traitContext * /*ctx*/) override { }

  virtual void enterPath_segment(PnfRustParser::Path_segmentContext * /*ctx*/) override { }
  virtual void exitPath_segment(PnfRustParser::Path_segmentContext * /*ctx*/) override { }

  virtual void enterPath_segment_no_super(PnfRustParser::Path_segment_no_superContext * /*ctx*/) override { }
  virtual void exitPath_segment_no_super(PnfRustParser::Path_segment_no_superContext * /*ctx*/) override { }

  virtual void enterSimple_path(PnfRustParser::Simple_pathContext * /*ctx*/) override { }
  virtual void exitSimple_path(PnfRustParser::Simple_pathContext * /*ctx*/) override { }

  virtual void enterSimple_path_segment(PnfRustParser::Simple_path_segmentContext * /*ctx*/) override { }
  virtual void exitSimple_path_segment(PnfRustParser::Simple_path_segmentContext * /*ctx*/) override { }

  virtual void enterFor_lifetimes(PnfRustParser::For_lifetimesContext * /*ctx*/) override { }
  virtual void exitFor_lifetimes(PnfRustParser::For_lifetimesContext * /*ctx*/) override { }

  virtual void enterLifetime_def_list(PnfRustParser::Lifetime_def_listContext * /*ctx*/) override { }
  virtual void exitLifetime_def_list(PnfRustParser::Lifetime_def_listContext * /*ctx*/) override { }

  virtual void enterLifetime_def(PnfRustParser::Lifetime_defContext * /*ctx*/) override { }
  virtual void exitLifetime_def(PnfRustParser::Lifetime_defContext * /*ctx*/) override { }

  virtual void enterType_path_main(PnfRustParser::Type_path_mainContext * /*ctx*/) override { }
  virtual void exitType_path_main(PnfRustParser::Type_path_mainContext * /*ctx*/) override { }

  virtual void enterTy_path_tail(PnfRustParser::Ty_path_tailContext * /*ctx*/) override { }
  virtual void exitTy_path_tail(PnfRustParser::Ty_path_tailContext * /*ctx*/) override { }

  virtual void enterType_path_segment(PnfRustParser::Type_path_segmentContext * /*ctx*/) override { }
  virtual void exitType_path_segment(PnfRustParser::Type_path_segmentContext * /*ctx*/) override { }

  virtual void enterTy_path_segment_no_super(PnfRustParser::Ty_path_segment_no_superContext * /*ctx*/) override { }
  virtual void exitTy_path_segment_no_super(PnfRustParser::Ty_path_segment_no_superContext * /*ctx*/) override { }

  virtual void enterWhere_clause(PnfRustParser::Where_clauseContext * /*ctx*/) override { }
  virtual void exitWhere_clause(PnfRustParser::Where_clauseContext * /*ctx*/) override { }

  virtual void enterWhere_bound_list(PnfRustParser::Where_bound_listContext * /*ctx*/) override { }
  virtual void exitWhere_bound_list(PnfRustParser::Where_bound_listContext * /*ctx*/) override { }

  virtual void enterWhere_bound(PnfRustParser::Where_boundContext * /*ctx*/) override { }
  virtual void exitWhere_bound(PnfRustParser::Where_boundContext * /*ctx*/) override { }

  virtual void enterEmpty_ok_colon_bound(PnfRustParser::Empty_ok_colon_boundContext * /*ctx*/) override { }
  virtual void exitEmpty_ok_colon_bound(PnfRustParser::Empty_ok_colon_boundContext * /*ctx*/) override { }

  virtual void enterColon_bound(PnfRustParser::Colon_boundContext * /*ctx*/) override { }
  virtual void exitColon_bound(PnfRustParser::Colon_boundContext * /*ctx*/) override { }

  virtual void enterPrim_bound(PnfRustParser::Prim_boundContext * /*ctx*/) override { }
  virtual void exitPrim_bound(PnfRustParser::Prim_boundContext * /*ctx*/) override { }

  virtual void enterInferred_type(PnfRustParser::Inferred_typeContext * /*ctx*/) override { }
  virtual void exitInferred_type(PnfRustParser::Inferred_typeContext * /*ctx*/) override { }

  virtual void enterArray_or_slice_type(PnfRustParser::Array_or_slice_typeContext * /*ctx*/) override { }
  virtual void exitArray_or_slice_type(PnfRustParser::Array_or_slice_typeContext * /*ctx*/) override { }

  virtual void enterReference_type(PnfRustParser::Reference_typeContext * /*ctx*/) override { }
  virtual void exitReference_type(PnfRustParser::Reference_typeContext * /*ctx*/) override { }

  virtual void enterRaw_pointer_type(PnfRustParser::Raw_pointer_typeContext * /*ctx*/) override { }
  virtual void exitRaw_pointer_type(PnfRustParser::Raw_pointer_typeContext * /*ctx*/) override { }

  virtual void enterNever_type(PnfRustParser::Never_typeContext * /*ctx*/) override { }
  virtual void exitNever_type(PnfRustParser::Never_typeContext * /*ctx*/) override { }

  virtual void enterTuple_type(PnfRustParser::Tuple_typeContext * /*ctx*/) override { }
  virtual void exitTuple_type(PnfRustParser::Tuple_typeContext * /*ctx*/) override { }

  virtual void enterImpl_trait_type(PnfRustParser::Impl_trait_typeContext * /*ctx*/) override { }
  virtual void exitImpl_trait_type(PnfRustParser::Impl_trait_typeContext * /*ctx*/) override { }

  virtual void enterImpl_trait_type_one_bound(PnfRustParser::Impl_trait_type_one_boundContext * /*ctx*/) override { }
  virtual void exitImpl_trait_type_one_bound(PnfRustParser::Impl_trait_type_one_boundContext * /*ctx*/) override { }

  virtual void enterTrait_object_type_one_bound(PnfRustParser::Trait_object_type_one_boundContext * /*ctx*/) override { }
  virtual void exitTrait_object_type_one_bound(PnfRustParser::Trait_object_type_one_boundContext * /*ctx*/) override { }

  virtual void enterType_param_bounds(PnfRustParser::Type_param_boundsContext * /*ctx*/) override { }
  virtual void exitType_param_bounds(PnfRustParser::Type_param_boundsContext * /*ctx*/) override { }

  virtual void enterType_param_bound(PnfRustParser::Type_param_boundContext * /*ctx*/) override { }
  virtual void exitType_param_bound(PnfRustParser::Type_param_boundContext * /*ctx*/) override { }

  virtual void enterTrait_object_type(PnfRustParser::Trait_object_typeContext * /*ctx*/) override { }
  virtual void exitTrait_object_type(PnfRustParser::Trait_object_typeContext * /*ctx*/) override { }

  virtual void enterTrait_bound(PnfRustParser::Trait_boundContext * /*ctx*/) override { }
  virtual void exitTrait_bound(PnfRustParser::Trait_boundContext * /*ctx*/) override { }

  virtual void enterBare_function_type(PnfRustParser::Bare_function_typeContext * /*ctx*/) override { }
  virtual void exitBare_function_type(PnfRustParser::Bare_function_typeContext * /*ctx*/) override { }

  virtual void enterMut_or_const(PnfRustParser::Mut_or_constContext * /*ctx*/) override { }
  virtual void exitMut_or_const(PnfRustParser::Mut_or_constContext * /*ctx*/) override { }

  virtual void enterExtern_abi(PnfRustParser::Extern_abiContext * /*ctx*/) override { }
  virtual void exitExtern_abi(PnfRustParser::Extern_abiContext * /*ctx*/) override { }

  virtual void enterType_arguments(PnfRustParser::Type_argumentsContext * /*ctx*/) override { }
  virtual void exitType_arguments(PnfRustParser::Type_argumentsContext * /*ctx*/) override { }

  virtual void enterType_argument(PnfRustParser::Type_argumentContext * /*ctx*/) override { }
  virtual void exitType_argument(PnfRustParser::Type_argumentContext * /*ctx*/) override { }

  virtual void enterTy_sum(PnfRustParser::Ty_sumContext * /*ctx*/) override { }
  virtual void exitTy_sum(PnfRustParser::Ty_sumContext * /*ctx*/) override { }

  virtual void enterTy_sum_list(PnfRustParser::Ty_sum_listContext * /*ctx*/) override { }
  virtual void exitTy_sum_list(PnfRustParser::Ty_sum_listContext * /*ctx*/) override { }

  virtual void enterType_parameters(PnfRustParser::Type_parametersContext * /*ctx*/) override { }
  virtual void exitType_parameters(PnfRustParser::Type_parametersContext * /*ctx*/) override { }

  virtual void enterLifetime_param(PnfRustParser::Lifetime_paramContext * /*ctx*/) override { }
  virtual void exitLifetime_param(PnfRustParser::Lifetime_paramContext * /*ctx*/) override { }

  virtual void enterLifetime_param_list(PnfRustParser::Lifetime_param_listContext * /*ctx*/) override { }
  virtual void exitLifetime_param_list(PnfRustParser::Lifetime_param_listContext * /*ctx*/) override { }

  virtual void enterType_parameter(PnfRustParser::Type_parameterContext * /*ctx*/) override { }
  virtual void exitType_parameter(PnfRustParser::Type_parameterContext * /*ctx*/) override { }

  virtual void enterType_parameter_list(PnfRustParser::Type_parameter_listContext * /*ctx*/) override { }
  virtual void exitType_parameter_list(PnfRustParser::Type_parameter_listContext * /*ctx*/) override { }

  virtual void enterPattern(PnfRustParser::PatternContext * /*ctx*/) override { }
  virtual void exitPattern(PnfRustParser::PatternContext * /*ctx*/) override { }

  virtual void enterPat_ident(PnfRustParser::Pat_identContext * /*ctx*/) override { }
  virtual void exitPat_ident(PnfRustParser::Pat_identContext * /*ctx*/) override { }

  virtual void enterPat_range_end(PnfRustParser::Pat_range_endContext * /*ctx*/) override { }
  virtual void exitPat_range_end(PnfRustParser::Pat_range_endContext * /*ctx*/) override { }

  virtual void enterPat_lit(PnfRustParser::Pat_litContext * /*ctx*/) override { }
  virtual void exitPat_lit(PnfRustParser::Pat_litContext * /*ctx*/) override { }

  virtual void enterPat_list_with_dots(PnfRustParser::Pat_list_with_dotsContext * /*ctx*/) override { }
  virtual void exitPat_list_with_dots(PnfRustParser::Pat_list_with_dotsContext * /*ctx*/) override { }

  virtual void enterPat_list_dots_tail(PnfRustParser::Pat_list_dots_tailContext * /*ctx*/) override { }
  virtual void exitPat_list_dots_tail(PnfRustParser::Pat_list_dots_tailContext * /*ctx*/) override { }

  virtual void enterPat_fields_left(PnfRustParser::Pat_fields_leftContext * /*ctx*/) override { }
  virtual void exitPat_fields_left(PnfRustParser::Pat_fields_leftContext * /*ctx*/) override { }

  virtual void enterPat_fields(PnfRustParser::Pat_fieldsContext * /*ctx*/) override { }
  virtual void exitPat_fields(PnfRustParser::Pat_fieldsContext * /*ctx*/) override { }

  virtual void enterPat_field(PnfRustParser::Pat_fieldContext * /*ctx*/) override { }
  virtual void exitPat_field(PnfRustParser::Pat_fieldContext * /*ctx*/) override { }

  virtual void enterExpr(PnfRustParser::ExprContext * /*ctx*/) override { }
  virtual void exitExpr(PnfRustParser::ExprContext * /*ctx*/) override { }

  virtual void enterExpr_no_struct(PnfRustParser::Expr_no_structContext * /*ctx*/) override { }
  virtual void exitExpr_no_struct(PnfRustParser::Expr_no_structContext * /*ctx*/) override { }

  virtual void enterExpr_list(PnfRustParser::Expr_listContext * /*ctx*/) override { }
  virtual void exitExpr_list(PnfRustParser::Expr_listContext * /*ctx*/) override { }

  virtual void enterBlock(PnfRustParser::BlockContext * /*ctx*/) override { }
  virtual void exitBlock(PnfRustParser::BlockContext * /*ctx*/) override { }

  virtual void enterBlock_with_inner_attrs(PnfRustParser::Block_with_inner_attrsContext * /*ctx*/) override { }
  virtual void exitBlock_with_inner_attrs(PnfRustParser::Block_with_inner_attrsContext * /*ctx*/) override { }

  virtual void enterStmt(PnfRustParser::StmtContext * /*ctx*/) override { }
  virtual void exitStmt(PnfRustParser::StmtContext * /*ctx*/) override { }

  virtual void enterBlocky_expr(PnfRustParser::Blocky_exprContext * /*ctx*/) override { }
  virtual void exitBlocky_expr(PnfRustParser::Blocky_exprContext * /*ctx*/) override { }

  virtual void enterIf_cond_or_pat(PnfRustParser::If_cond_or_patContext * /*ctx*/) override { }
  virtual void exitIf_cond_or_pat(PnfRustParser::If_cond_or_patContext * /*ctx*/) override { }

  virtual void enterWhile_cond_or_pat(PnfRustParser::While_cond_or_patContext * /*ctx*/) override { }
  virtual void exitWhile_cond_or_pat(PnfRustParser::While_cond_or_patContext * /*ctx*/) override { }

  virtual void enterLoop_label(PnfRustParser::Loop_labelContext * /*ctx*/) override { }
  virtual void exitLoop_label(PnfRustParser::Loop_labelContext * /*ctx*/) override { }

  virtual void enterMatch_arms(PnfRustParser::Match_armsContext * /*ctx*/) override { }
  virtual void exitMatch_arms(PnfRustParser::Match_armsContext * /*ctx*/) override { }

  virtual void enterMatch_arm_intro(PnfRustParser::Match_arm_introContext * /*ctx*/) override { }
  virtual void exitMatch_arm_intro(PnfRustParser::Match_arm_introContext * /*ctx*/) override { }

  virtual void enterMatch_pattern(PnfRustParser::Match_patternContext * /*ctx*/) override { }
  virtual void exitMatch_pattern(PnfRustParser::Match_patternContext * /*ctx*/) override { }

  virtual void enterMatch_if_clause(PnfRustParser::Match_if_clauseContext * /*ctx*/) override { }
  virtual void exitMatch_if_clause(PnfRustParser::Match_if_clauseContext * /*ctx*/) override { }

  virtual void enterExpr_attrs(PnfRustParser::Expr_attrsContext * /*ctx*/) override { }
  virtual void exitExpr_attrs(PnfRustParser::Expr_attrsContext * /*ctx*/) override { }

  virtual void enterExpr_inner_attrs(PnfRustParser::Expr_inner_attrsContext * /*ctx*/) override { }
  virtual void exitExpr_inner_attrs(PnfRustParser::Expr_inner_attrsContext * /*ctx*/) override { }

  virtual void enterPrim_expr(PnfRustParser::Prim_exprContext * /*ctx*/) override { }
  virtual void exitPrim_expr(PnfRustParser::Prim_exprContext * /*ctx*/) override { }

  virtual void enterPrim_expr_no_struct(PnfRustParser::Prim_expr_no_structContext * /*ctx*/) override { }
  virtual void exitPrim_expr_no_struct(PnfRustParser::Prim_expr_no_structContext * /*ctx*/) override { }

  virtual void enterLit(PnfRustParser::LitContext * /*ctx*/) override { }
  virtual void exitLit(PnfRustParser::LitContext * /*ctx*/) override { }

  virtual void enterClosure_params(PnfRustParser::Closure_paramsContext * /*ctx*/) override { }
  virtual void exitClosure_params(PnfRustParser::Closure_paramsContext * /*ctx*/) override { }

  virtual void enterClosure_param(PnfRustParser::Closure_paramContext * /*ctx*/) override { }
  virtual void exitClosure_param(PnfRustParser::Closure_paramContext * /*ctx*/) override { }

  virtual void enterClosure_param_list(PnfRustParser::Closure_param_listContext * /*ctx*/) override { }
  virtual void exitClosure_param_list(PnfRustParser::Closure_param_listContext * /*ctx*/) override { }

  virtual void enterClosure_tail(PnfRustParser::Closure_tailContext * /*ctx*/) override { }
  virtual void exitClosure_tail(PnfRustParser::Closure_tailContext * /*ctx*/) override { }

  virtual void enterLifetime_or_expr(PnfRustParser::Lifetime_or_exprContext * /*ctx*/) override { }
  virtual void exitLifetime_or_expr(PnfRustParser::Lifetime_or_exprContext * /*ctx*/) override { }

  virtual void enterFields(PnfRustParser::FieldsContext * /*ctx*/) override { }
  virtual void exitFields(PnfRustParser::FieldsContext * /*ctx*/) override { }

  virtual void enterStruct_update_base(PnfRustParser::Struct_update_baseContext * /*ctx*/) override { }
  virtual void exitStruct_update_base(PnfRustParser::Struct_update_baseContext * /*ctx*/) override { }

  virtual void enterField(PnfRustParser::FieldContext * /*ctx*/) override { }
  virtual void exitField(PnfRustParser::FieldContext * /*ctx*/) override { }

  virtual void enterField_name(PnfRustParser::Field_nameContext * /*ctx*/) override { }
  virtual void exitField_name(PnfRustParser::Field_nameContext * /*ctx*/) override { }

  virtual void enterPre_expr(PnfRustParser::Pre_exprContext * /*ctx*/) override { }
  virtual void exitPre_expr(PnfRustParser::Pre_exprContext * /*ctx*/) override { }

  virtual void enterCmp_expr(PnfRustParser::Cmp_exprContext * /*ctx*/) override { }
  virtual void exitCmp_expr(PnfRustParser::Cmp_exprContext * /*ctx*/) override { }

  virtual void enterRange_expr(PnfRustParser::Range_exprContext * /*ctx*/) override { }
  virtual void exitRange_expr(PnfRustParser::Range_exprContext * /*ctx*/) override { }

  virtual void enterAssign_expr(PnfRustParser::Assign_exprContext * /*ctx*/) override { }
  virtual void exitAssign_expr(PnfRustParser::Assign_exprContext * /*ctx*/) override { }

  virtual void enterPre_expr_no_struct(PnfRustParser::Pre_expr_no_structContext * /*ctx*/) override { }
  virtual void exitPre_expr_no_struct(PnfRustParser::Pre_expr_no_structContext * /*ctx*/) override { }

  virtual void enterCmp_expr_no_struct(PnfRustParser::Cmp_expr_no_structContext * /*ctx*/) override { }
  virtual void exitCmp_expr_no_struct(PnfRustParser::Cmp_expr_no_structContext * /*ctx*/) override { }

  virtual void enterRange_expr_no_struct(PnfRustParser::Range_expr_no_structContext * /*ctx*/) override { }
  virtual void exitRange_expr_no_struct(PnfRustParser::Range_expr_no_structContext * /*ctx*/) override { }

  virtual void enterAssign_expr_no_struct(PnfRustParser::Assign_expr_no_structContext * /*ctx*/) override { }
  virtual void exitAssign_expr_no_struct(PnfRustParser::Assign_expr_no_structContext * /*ctx*/) override { }

  virtual void enterIdent(PnfRustParser::IdentContext * /*ctx*/) override { }
  virtual void exitIdent(PnfRustParser::IdentContext * /*ctx*/) override { }

  virtual void enterAny_ident(PnfRustParser::Any_identContext * /*ctx*/) override { }
  virtual void exitAny_ident(PnfRustParser::Any_identContext * /*ctx*/) override { }

  virtual void enterTokens_no_delimiters_cash(PnfRustParser::Tokens_no_delimiters_cashContext * /*ctx*/) override { }
  virtual void exitTokens_no_delimiters_cash(PnfRustParser::Tokens_no_delimiters_cashContext * /*ctx*/) override { }

  virtual void enterTokens_no_delimiters_repetition_operators(PnfRustParser::Tokens_no_delimiters_repetition_operatorsContext * /*ctx*/) override { }
  virtual void exitTokens_no_delimiters_repetition_operators(PnfRustParser::Tokens_no_delimiters_repetition_operatorsContext * /*ctx*/) override { }

  virtual void enterMacro_rules_definition(PnfRustParser::Macro_rules_definitionContext * /*ctx*/) override { }
  virtual void exitMacro_rules_definition(PnfRustParser::Macro_rules_definitionContext * /*ctx*/) override { }

  virtual void enterMacro_rules_def(PnfRustParser::Macro_rules_defContext * /*ctx*/) override { }
  virtual void exitMacro_rules_def(PnfRustParser::Macro_rules_defContext * /*ctx*/) override { }

  virtual void enterMacro_rules(PnfRustParser::Macro_rulesContext * /*ctx*/) override { }
  virtual void exitMacro_rules(PnfRustParser::Macro_rulesContext * /*ctx*/) override { }

  virtual void enterMacro_rule(PnfRustParser::Macro_ruleContext * /*ctx*/) override { }
  virtual void exitMacro_rule(PnfRustParser::Macro_ruleContext * /*ctx*/) override { }

  virtual void enterMacro_matcher(PnfRustParser::Macro_matcherContext * /*ctx*/) override { }
  virtual void exitMacro_matcher(PnfRustParser::Macro_matcherContext * /*ctx*/) override { }

  virtual void enterMacro_match(PnfRustParser::Macro_matchContext * /*ctx*/) override { }
  virtual void exitMacro_match(PnfRustParser::Macro_matchContext * /*ctx*/) override { }

  virtual void enterMacro_rep_sep(PnfRustParser::Macro_rep_sepContext * /*ctx*/) override { }
  virtual void exitMacro_rep_sep(PnfRustParser::Macro_rep_sepContext * /*ctx*/) override { }

  virtual void enterMacro_rep_op(PnfRustParser::Macro_rep_opContext * /*ctx*/) override { }
  virtual void exitMacro_rep_op(PnfRustParser::Macro_rep_opContext * /*ctx*/) override { }

  virtual void enterMacro_transcriber(PnfRustParser::Macro_transcriberContext * /*ctx*/) override { }
  virtual void exitMacro_transcriber(PnfRustParser::Macro_transcriberContext * /*ctx*/) override { }

  virtual void enterDelim_token_tree(PnfRustParser::Delim_token_treeContext * /*ctx*/) override { }
  virtual void exitDelim_token_tree(PnfRustParser::Delim_token_treeContext * /*ctx*/) override { }

  virtual void enterMacro_invocation_semi(PnfRustParser::Macro_invocation_semiContext * /*ctx*/) override { }
  virtual void exitMacro_invocation_semi(PnfRustParser::Macro_invocation_semiContext * /*ctx*/) override { }

  virtual void enterMacro_invocation(PnfRustParser::Macro_invocationContext * /*ctx*/) override { }
  virtual void exitMacro_invocation(PnfRustParser::Macro_invocationContext * /*ctx*/) override { }

  virtual void enterLifetime(PnfRustParser::LifetimeContext * /*ctx*/) override { }
  virtual void exitLifetime(PnfRustParser::LifetimeContext * /*ctx*/) override { }

  virtual void enterKleene_star__mod_body_1(PnfRustParser::Kleene_star__mod_body_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__mod_body_1(PnfRustParser::Kleene_star__mod_body_1Context * /*ctx*/) override { }

  virtual void enterKleene_star__mod_body_2(PnfRustParser::Kleene_star__mod_body_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__mod_body_2(PnfRustParser::Kleene_star__mod_body_2Context * /*ctx*/) override { }

  virtual void enterOptional__visibility_1(PnfRustParser::Optional__visibility_1Context * /*ctx*/) override { }
  virtual void exitOptional__visibility_1(PnfRustParser::Optional__visibility_1Context * /*ctx*/) override { }

  virtual void enterKleene_star__item_1(PnfRustParser::Kleene_star__item_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__item_1(PnfRustParser::Kleene_star__item_1Context * /*ctx*/) override { }

  virtual void enterOptional__item_2(PnfRustParser::Optional__item_2Context * /*ctx*/) override { }
  virtual void exitOptional__item_2(PnfRustParser::Optional__item_2Context * /*ctx*/) override { }

  virtual void enterOptional__extern_crate_1(PnfRustParser::Optional__extern_crate_1Context * /*ctx*/) override { }
  virtual void exitOptional__extern_crate_1(PnfRustParser::Optional__extern_crate_1Context * /*ctx*/) override { }

  virtual void enterOptional__use_path_2(PnfRustParser::Optional__use_path_2Context * /*ctx*/) override { }
  virtual void exitOptional__use_path_2(PnfRustParser::Optional__use_path_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__use_path_4(PnfRustParser::Aux_rule__use_path_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__use_path_4(PnfRustParser::Aux_rule__use_path_4Context * /*ctx*/) override { }

  virtual void enterKleene_star__use_path_5(PnfRustParser::Kleene_star__use_path_5Context * /*ctx*/) override { }
  virtual void exitKleene_star__use_path_5(PnfRustParser::Kleene_star__use_path_5Context * /*ctx*/) override { }

  virtual void enterOptional__use_path_6(PnfRustParser::Optional__use_path_6Context * /*ctx*/) override { }
  virtual void exitOptional__use_path_6(PnfRustParser::Optional__use_path_6Context * /*ctx*/) override { }

  virtual void enterAux_rule__use_item_list_1(PnfRustParser::Aux_rule__use_item_list_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__use_item_list_1(PnfRustParser::Aux_rule__use_item_list_1Context * /*ctx*/) override { }

  virtual void enterKleene_star__use_item_list_2(PnfRustParser::Kleene_star__use_item_list_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__use_item_list_2(PnfRustParser::Kleene_star__use_item_list_2Context * /*ctx*/) override { }

  virtual void enterOptional__use_item_list_3(PnfRustParser::Optional__use_item_list_3Context * /*ctx*/) override { }
  virtual void exitOptional__use_item_list_3(PnfRustParser::Optional__use_item_list_3Context * /*ctx*/) override { }

  virtual void enterKleene_star__extern_mod_2(PnfRustParser::Kleene_star__extern_mod_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__extern_mod_2(PnfRustParser::Kleene_star__extern_mod_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__foreign_item_tail_2(PnfRustParser::Aux_rule__foreign_item_tail_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__foreign_item_tail_2(PnfRustParser::Aux_rule__foreign_item_tail_2Context * /*ctx*/) override { }

  virtual void enterOptional__foreign_item_tail_3(PnfRustParser::Optional__foreign_item_tail_3Context * /*ctx*/) override { }
  virtual void exitOptional__foreign_item_tail_3(PnfRustParser::Optional__foreign_item_tail_3Context * /*ctx*/) override { }

  virtual void enterOptional__static_decl_1(PnfRustParser::Optional__static_decl_1Context * /*ctx*/) override { }
  virtual void exitOptional__static_decl_1(PnfRustParser::Optional__static_decl_1Context * /*ctx*/) override { }

  virtual void enterAux_rule__associated_const_decl_1(PnfRustParser::Aux_rule__associated_const_decl_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__associated_const_decl_1(PnfRustParser::Aux_rule__associated_const_decl_1Context * /*ctx*/) override { }

  virtual void enterOptional__associated_const_decl_2(PnfRustParser::Optional__associated_const_decl_2Context * /*ctx*/) override { }
  virtual void exitOptional__associated_const_decl_2(PnfRustParser::Optional__associated_const_decl_2Context * /*ctx*/) override { }

  virtual void enterOptional__fn_decl_1(PnfRustParser::Optional__fn_decl_1Context * /*ctx*/) override { }
  virtual void exitOptional__fn_decl_1(PnfRustParser::Optional__fn_decl_1Context * /*ctx*/) override { }

  virtual void enterOptional__fn_decl_2(PnfRustParser::Optional__fn_decl_2Context * /*ctx*/) override { }
  virtual void exitOptional__fn_decl_2(PnfRustParser::Optional__fn_decl_2Context * /*ctx*/) override { }

  virtual void enterOptional__method_decl_1(PnfRustParser::Optional__method_decl_1Context * /*ctx*/) override { }
  virtual void exitOptional__method_decl_1(PnfRustParser::Optional__method_decl_1Context * /*ctx*/) override { }

  virtual void enterOptional__trait_method_decl_1(PnfRustParser::Optional__trait_method_decl_1Context * /*ctx*/) override { }
  virtual void exitOptional__trait_method_decl_1(PnfRustParser::Optional__trait_method_decl_1Context * /*ctx*/) override { }

  virtual void enterOptional__foreign_fn_decl_1(PnfRustParser::Optional__foreign_fn_decl_1Context * /*ctx*/) override { }
  virtual void exitOptional__foreign_fn_decl_1(PnfRustParser::Optional__foreign_fn_decl_1Context * /*ctx*/) override { }

  virtual void enterOptional__foreign_fn_decl_2(PnfRustParser::Optional__foreign_fn_decl_2Context * /*ctx*/) override { }
  virtual void exitOptional__foreign_fn_decl_2(PnfRustParser::Optional__foreign_fn_decl_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__macro_decl_2(PnfRustParser::Aux_rule__macro_decl_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__macro_decl_2(PnfRustParser::Aux_rule__macro_decl_2Context * /*ctx*/) override { }

  virtual void enterOptional__macro_decl_3(PnfRustParser::Optional__macro_decl_3Context * /*ctx*/) override { }
  virtual void exitOptional__macro_decl_3(PnfRustParser::Optional__macro_decl_3Context * /*ctx*/) override { }

  virtual void enterOptional__macro_head_1(PnfRustParser::Optional__macro_head_1Context * /*ctx*/) override { }
  virtual void exitOptional__macro_head_1(PnfRustParser::Optional__macro_head_1Context * /*ctx*/) override { }

  virtual void enterAux_rule__fn_head_1(PnfRustParser::Aux_rule__fn_head_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__fn_head_1(PnfRustParser::Aux_rule__fn_head_1Context * /*ctx*/) override { }

  virtual void enterKleene_star__fn_head_2(PnfRustParser::Kleene_star__fn_head_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__fn_head_2(PnfRustParser::Kleene_star__fn_head_2Context * /*ctx*/) override { }

  virtual void enterOptional__fn_head_3(PnfRustParser::Optional__fn_head_3Context * /*ctx*/) override { }
  virtual void exitOptional__fn_head_3(PnfRustParser::Optional__fn_head_3Context * /*ctx*/) override { }

  virtual void enterAux_rule__param_3(PnfRustParser::Aux_rule__param_3Context * /*ctx*/) override { }
  virtual void exitAux_rule__param_3(PnfRustParser::Aux_rule__param_3Context * /*ctx*/) override { }

  virtual void enterOptional__param_4(PnfRustParser::Optional__param_4Context * /*ctx*/) override { }
  virtual void exitOptional__param_4(PnfRustParser::Optional__param_4Context * /*ctx*/) override { }

  virtual void enterOptional__param_6(PnfRustParser::Optional__param_6Context * /*ctx*/) override { }
  virtual void exitOptional__param_6(PnfRustParser::Optional__param_6Context * /*ctx*/) override { }

  virtual void enterAux_rule__param_list_1(PnfRustParser::Aux_rule__param_list_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__param_list_1(PnfRustParser::Aux_rule__param_list_1Context * /*ctx*/) override { }

  virtual void enterKleene_star__param_list_2(PnfRustParser::Kleene_star__param_list_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__param_list_2(PnfRustParser::Kleene_star__param_list_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__param_list_4(PnfRustParser::Aux_rule__param_list_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__param_list_4(PnfRustParser::Aux_rule__param_list_4Context * /*ctx*/) override { }

  virtual void enterOptional__param_list_5(PnfRustParser::Optional__param_list_5Context * /*ctx*/) override { }
  virtual void exitOptional__param_list_5(PnfRustParser::Optional__param_list_5Context * /*ctx*/) override { }

  virtual void enterAux_rule__variadic_param_list_4(PnfRustParser::Aux_rule__variadic_param_list_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__variadic_param_list_4(PnfRustParser::Aux_rule__variadic_param_list_4Context * /*ctx*/) override { }

  virtual void enterOptional__variadic_param_list_5(PnfRustParser::Optional__variadic_param_list_5Context * /*ctx*/) override { }
  virtual void exitOptional__variadic_param_list_5(PnfRustParser::Optional__variadic_param_list_5Context * /*ctx*/) override { }

  virtual void enterAux_rule__trait_method_param_2(PnfRustParser::Aux_rule__trait_method_param_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__trait_method_param_2(PnfRustParser::Aux_rule__trait_method_param_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__trait_method_param_3(PnfRustParser::Kleene_star__trait_method_param_3Context * /*ctx*/) override { }
  virtual void exitKleene_star__trait_method_param_3(PnfRustParser::Kleene_star__trait_method_param_3Context * /*ctx*/) override { }

  virtual void enterOptional__restricted_pat_1(PnfRustParser::Optional__restricted_pat_1Context * /*ctx*/) override { }
  virtual void exitOptional__restricted_pat_1(PnfRustParser::Optional__restricted_pat_1Context * /*ctx*/) override { }

  virtual void enterAux_rule__restricted_pat_2(PnfRustParser::Aux_rule__restricted_pat_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__restricted_pat_2(PnfRustParser::Aux_rule__restricted_pat_2Context * /*ctx*/) override { }

  virtual void enterOptional__restricted_pat_3(PnfRustParser::Optional__restricted_pat_3Context * /*ctx*/) override { }
  virtual void exitOptional__restricted_pat_3(PnfRustParser::Optional__restricted_pat_3Context * /*ctx*/) override { }

  virtual void enterAux_rule__trait_method_param_list_2(PnfRustParser::Aux_rule__trait_method_param_list_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__trait_method_param_list_2(PnfRustParser::Aux_rule__trait_method_param_list_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__trait_method_param_list_3(PnfRustParser::Kleene_star__trait_method_param_list_3Context * /*ctx*/) override { }
  virtual void exitKleene_star__trait_method_param_list_3(PnfRustParser::Kleene_star__trait_method_param_list_3Context * /*ctx*/) override { }

  virtual void enterOptional__type_decl_4(PnfRustParser::Optional__type_decl_4Context * /*ctx*/) override { }
  virtual void exitOptional__type_decl_4(PnfRustParser::Optional__type_decl_4Context * /*ctx*/) override { }

  virtual void enterAux_rule__type_decl_6(PnfRustParser::Aux_rule__type_decl_6Context * /*ctx*/) override { }
  virtual void exitAux_rule__type_decl_6(PnfRustParser::Aux_rule__type_decl_6Context * /*ctx*/) override { }

  virtual void enterOptional__type_decl_7(PnfRustParser::Optional__type_decl_7Context * /*ctx*/) override { }
  virtual void exitOptional__type_decl_7(PnfRustParser::Optional__type_decl_7Context * /*ctx*/) override { }

  virtual void enterAux_rule__type_decl_8(PnfRustParser::Aux_rule__type_decl_8Context * /*ctx*/) override { }
  virtual void exitAux_rule__type_decl_8(PnfRustParser::Aux_rule__type_decl_8Context * /*ctx*/) override { }

  virtual void enterOptional__type_decl_9(PnfRustParser::Optional__type_decl_9Context * /*ctx*/) override { }
  virtual void exitOptional__type_decl_9(PnfRustParser::Optional__type_decl_9Context * /*ctx*/) override { }

  virtual void enterOptional__struct_tail_2(PnfRustParser::Optional__struct_tail_2Context * /*ctx*/) override { }
  virtual void exitOptional__struct_tail_2(PnfRustParser::Optional__struct_tail_2Context * /*ctx*/) override { }

  virtual void enterOptional__struct_tail_5(PnfRustParser::Optional__struct_tail_5Context * /*ctx*/) override { }
  virtual void exitOptional__struct_tail_5(PnfRustParser::Optional__struct_tail_5Context * /*ctx*/) override { }

  virtual void enterAux_rule__tuple_struct_field_list_1(PnfRustParser::Aux_rule__tuple_struct_field_list_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__tuple_struct_field_list_1(PnfRustParser::Aux_rule__tuple_struct_field_list_1Context * /*ctx*/) override { }

  virtual void enterKleene_star__tuple_struct_field_list_2(PnfRustParser::Kleene_star__tuple_struct_field_list_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__tuple_struct_field_list_2(PnfRustParser::Kleene_star__tuple_struct_field_list_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__field_decl_list_1(PnfRustParser::Aux_rule__field_decl_list_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__field_decl_list_1(PnfRustParser::Aux_rule__field_decl_list_1Context * /*ctx*/) override { }

  virtual void enterKleene_star__field_decl_list_2(PnfRustParser::Kleene_star__field_decl_list_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__field_decl_list_2(PnfRustParser::Kleene_star__field_decl_list_2Context * /*ctx*/) override { }

  virtual void enterOptional__enum_decl_3(PnfRustParser::Optional__enum_decl_3Context * /*ctx*/) override { }
  virtual void exitOptional__enum_decl_3(PnfRustParser::Optional__enum_decl_3Context * /*ctx*/) override { }

  virtual void enterAux_rule__enum_variant_3(PnfRustParser::Aux_rule__enum_variant_3Context * /*ctx*/) override { }
  virtual void exitAux_rule__enum_variant_3(PnfRustParser::Aux_rule__enum_variant_3Context * /*ctx*/) override { }

  virtual void enterOptional__enum_variant_4(PnfRustParser::Optional__enum_variant_4Context * /*ctx*/) override { }
  virtual void exitOptional__enum_variant_4(PnfRustParser::Optional__enum_variant_4Context * /*ctx*/) override { }

  virtual void enterAux_rule__enum_variant_list_1(PnfRustParser::Aux_rule__enum_variant_list_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__enum_variant_list_1(PnfRustParser::Aux_rule__enum_variant_list_1Context * /*ctx*/) override { }

  virtual void enterKleene_star__enum_variant_list_2(PnfRustParser::Kleene_star__enum_variant_list_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__enum_variant_list_2(PnfRustParser::Kleene_star__enum_variant_list_2Context * /*ctx*/) override { }

  virtual void enterOptional__enum_variant_main_1(PnfRustParser::Optional__enum_variant_main_1Context * /*ctx*/) override { }
  virtual void exitOptional__enum_variant_main_1(PnfRustParser::Optional__enum_variant_main_1Context * /*ctx*/) override { }

  virtual void enterAux_rule__enum_tuple_field_list_1(PnfRustParser::Aux_rule__enum_tuple_field_list_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__enum_tuple_field_list_1(PnfRustParser::Aux_rule__enum_tuple_field_list_1Context * /*ctx*/) override { }

  virtual void enterKleene_star__enum_tuple_field_list_2(PnfRustParser::Kleene_star__enum_tuple_field_list_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__enum_tuple_field_list_2(PnfRustParser::Kleene_star__enum_tuple_field_list_2Context * /*ctx*/) override { }

  virtual void enterOptional__trait_decl_2(PnfRustParser::Optional__trait_decl_2Context * /*ctx*/) override { }
  virtual void exitOptional__trait_decl_2(PnfRustParser::Optional__trait_decl_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__trait_decl_7(PnfRustParser::Kleene_star__trait_decl_7Context * /*ctx*/) override { }
  virtual void exitKleene_star__trait_decl_7(PnfRustParser::Kleene_star__trait_decl_7Context * /*ctx*/) override { }

  virtual void enterOptional__impl_block_1(PnfRustParser::Optional__impl_block_1Context * /*ctx*/) override { }
  virtual void exitOptional__impl_block_1(PnfRustParser::Optional__impl_block_1Context * /*ctx*/) override { }

  virtual void enterOptional__impl_block_2(PnfRustParser::Optional__impl_block_2Context * /*ctx*/) override { }
  virtual void exitOptional__impl_block_2(PnfRustParser::Optional__impl_block_2Context * /*ctx*/) override { }

  virtual void enterOptional__impl_block_3(PnfRustParser::Optional__impl_block_3Context * /*ctx*/) override { }
  virtual void exitOptional__impl_block_3(PnfRustParser::Optional__impl_block_3Context * /*ctx*/) override { }

  virtual void enterOptional__impl_block_4(PnfRustParser::Optional__impl_block_4Context * /*ctx*/) override { }
  virtual void exitOptional__impl_block_4(PnfRustParser::Optional__impl_block_4Context * /*ctx*/) override { }

  virtual void enterOptional__impl_block_5(PnfRustParser::Optional__impl_block_5Context * /*ctx*/) override { }
  virtual void exitOptional__impl_block_5(PnfRustParser::Optional__impl_block_5Context * /*ctx*/) override { }

  virtual void enterOptional__impl_block_6(PnfRustParser::Optional__impl_block_6Context * /*ctx*/) override { }
  virtual void exitOptional__impl_block_6(PnfRustParser::Optional__impl_block_6Context * /*ctx*/) override { }

  virtual void enterKleene_star__impl_block_7(PnfRustParser::Kleene_star__impl_block_7Context * /*ctx*/) override { }
  virtual void exitKleene_star__impl_block_7(PnfRustParser::Kleene_star__impl_block_7Context * /*ctx*/) override { }

  virtual void enterAux_rule__impl_item_1(PnfRustParser::Aux_rule__impl_item_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__impl_item_1(PnfRustParser::Aux_rule__impl_item_1Context * /*ctx*/) override { }

  virtual void enterKleene_star__impl_item_2(PnfRustParser::Kleene_star__impl_item_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__impl_item_2(PnfRustParser::Kleene_star__impl_item_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__impl_item_tail_11(PnfRustParser::Aux_rule__impl_item_tail_11Context * /*ctx*/) override { }
  virtual void exitAux_rule__impl_item_tail_11(PnfRustParser::Aux_rule__impl_item_tail_11Context * /*ctx*/) override { }

  virtual void enterOptional__impl_item_tail_12(PnfRustParser::Optional__impl_item_tail_12Context * /*ctx*/) override { }
  virtual void exitOptional__impl_item_tail_12(PnfRustParser::Optional__impl_item_tail_12Context * /*ctx*/) override { }

  virtual void enterKleene_star__inner_attr_1(PnfRustParser::Kleene_star__inner_attr_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__inner_attr_1(PnfRustParser::Kleene_star__inner_attr_1Context * /*ctx*/) override { }

  virtual void enterOptional__path_1(PnfRustParser::Optional__path_1Context * /*ctx*/) override { }
  virtual void exitOptional__path_1(PnfRustParser::Optional__path_1Context * /*ctx*/) override { }

  virtual void enterOptional__path_parent_1(PnfRustParser::Optional__path_parent_1Context * /*ctx*/) override { }
  virtual void exitOptional__path_parent_1(PnfRustParser::Optional__path_parent_1Context * /*ctx*/) override { }

  virtual void enterAux_rule__path_segment_no_super_1(PnfRustParser::Aux_rule__path_segment_no_super_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__path_segment_no_super_1(PnfRustParser::Aux_rule__path_segment_no_super_1Context * /*ctx*/) override { }

  virtual void enterOptional__path_segment_no_super_2(PnfRustParser::Optional__path_segment_no_super_2Context * /*ctx*/) override { }
  virtual void exitOptional__path_segment_no_super_2(PnfRustParser::Optional__path_segment_no_super_2Context * /*ctx*/) override { }

  virtual void enterOptional__simple_path_1(PnfRustParser::Optional__simple_path_1Context * /*ctx*/) override { }
  virtual void exitOptional__simple_path_1(PnfRustParser::Optional__simple_path_1Context * /*ctx*/) override { }

  virtual void enterAux_rule__simple_path_2(PnfRustParser::Aux_rule__simple_path_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__simple_path_2(PnfRustParser::Aux_rule__simple_path_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__simple_path_3(PnfRustParser::Kleene_star__simple_path_3Context * /*ctx*/) override { }
  virtual void exitKleene_star__simple_path_3(PnfRustParser::Kleene_star__simple_path_3Context * /*ctx*/) override { }

  virtual void enterOptional__for_lifetimes_1(PnfRustParser::Optional__for_lifetimes_1Context * /*ctx*/) override { }
  virtual void exitOptional__for_lifetimes_1(PnfRustParser::Optional__for_lifetimes_1Context * /*ctx*/) override { }

  virtual void enterAux_rule__lifetime_def_list_1(PnfRustParser::Aux_rule__lifetime_def_list_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__lifetime_def_list_1(PnfRustParser::Aux_rule__lifetime_def_list_1Context * /*ctx*/) override { }

  virtual void enterKleene_star__lifetime_def_list_2(PnfRustParser::Kleene_star__lifetime_def_list_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__lifetime_def_list_2(PnfRustParser::Kleene_star__lifetime_def_list_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__lifetime_def_1(PnfRustParser::Aux_rule__lifetime_def_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__lifetime_def_1(PnfRustParser::Aux_rule__lifetime_def_1Context * /*ctx*/) override { }

  virtual void enterOptional__lifetime_def_2(PnfRustParser::Optional__lifetime_def_2Context * /*ctx*/) override { }
  virtual void exitOptional__lifetime_def_2(PnfRustParser::Optional__lifetime_def_2Context * /*ctx*/) override { }

  virtual void enterOptional__type_path_main_1(PnfRustParser::Optional__type_path_main_1Context * /*ctx*/) override { }
  virtual void exitOptional__type_path_main_1(PnfRustParser::Optional__type_path_main_1Context * /*ctx*/) override { }

  virtual void enterOptional__ty_path_tail_1(PnfRustParser::Optional__ty_path_tail_1Context * /*ctx*/) override { }
  virtual void exitOptional__ty_path_tail_1(PnfRustParser::Optional__ty_path_tail_1Context * /*ctx*/) override { }

  virtual void enterOptional__ty_path_segment_no_super_2(PnfRustParser::Optional__ty_path_segment_no_super_2Context * /*ctx*/) override { }
  virtual void exitOptional__ty_path_segment_no_super_2(PnfRustParser::Optional__ty_path_segment_no_super_2Context * /*ctx*/) override { }

  virtual void enterOptional__ty_path_segment_no_super_3(PnfRustParser::Optional__ty_path_segment_no_super_3Context * /*ctx*/) override { }
  virtual void exitOptional__ty_path_segment_no_super_3(PnfRustParser::Optional__ty_path_segment_no_super_3Context * /*ctx*/) override { }

  virtual void enterAux_rule__where_bound_list_1(PnfRustParser::Aux_rule__where_bound_list_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__where_bound_list_1(PnfRustParser::Aux_rule__where_bound_list_1Context * /*ctx*/) override { }

  virtual void enterKleene_star__where_bound_list_2(PnfRustParser::Kleene_star__where_bound_list_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__where_bound_list_2(PnfRustParser::Kleene_star__where_bound_list_2Context * /*ctx*/) override { }

  virtual void enterOptional__where_bound_1(PnfRustParser::Optional__where_bound_1Context * /*ctx*/) override { }
  virtual void exitOptional__where_bound_1(PnfRustParser::Optional__where_bound_1Context * /*ctx*/) override { }

  virtual void enterOptional__where_bound_2(PnfRustParser::Optional__where_bound_2Context * /*ctx*/) override { }
  virtual void exitOptional__where_bound_2(PnfRustParser::Optional__where_bound_2Context * /*ctx*/) override { }

  virtual void enterOptional__empty_ok_colon_bound_1(PnfRustParser::Optional__empty_ok_colon_bound_1Context * /*ctx*/) override { }
  virtual void exitOptional__empty_ok_colon_bound_1(PnfRustParser::Optional__empty_ok_colon_bound_1Context * /*ctx*/) override { }

  virtual void enterAux_rule__prim_bound_3(PnfRustParser::Aux_rule__prim_bound_3Context * /*ctx*/) override { }
  virtual void exitAux_rule__prim_bound_3(PnfRustParser::Aux_rule__prim_bound_3Context * /*ctx*/) override { }

  virtual void enterOptional__prim_bound_4(PnfRustParser::Optional__prim_bound_4Context * /*ctx*/) override { }
  virtual void exitOptional__prim_bound_4(PnfRustParser::Optional__prim_bound_4Context * /*ctx*/) override { }

  virtual void enterAux_rule__prim_bound_5(PnfRustParser::Aux_rule__prim_bound_5Context * /*ctx*/) override { }
  virtual void exitAux_rule__prim_bound_5(PnfRustParser::Aux_rule__prim_bound_5Context * /*ctx*/) override { }

  virtual void enterOptional__type_1(PnfRustParser::Optional__type_1Context * /*ctx*/) override { }
  virtual void exitOptional__type_1(PnfRustParser::Optional__type_1Context * /*ctx*/) override { }

  virtual void enterAux_rule__array_or_slice_type_1(PnfRustParser::Aux_rule__array_or_slice_type_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__array_or_slice_type_1(PnfRustParser::Aux_rule__array_or_slice_type_1Context * /*ctx*/) override { }

  virtual void enterOptional__array_or_slice_type_2(PnfRustParser::Optional__array_or_slice_type_2Context * /*ctx*/) override { }
  virtual void exitOptional__array_or_slice_type_2(PnfRustParser::Optional__array_or_slice_type_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__type_param_bounds_1(PnfRustParser::Aux_rule__type_param_bounds_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__type_param_bounds_1(PnfRustParser::Aux_rule__type_param_bounds_1Context * /*ctx*/) override { }

  virtual void enterKleene_star__type_param_bounds_2(PnfRustParser::Kleene_star__type_param_bounds_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__type_param_bounds_2(PnfRustParser::Kleene_star__type_param_bounds_2Context * /*ctx*/) override { }

  virtual void enterOptional__type_param_bounds_3(PnfRustParser::Optional__type_param_bounds_3Context * /*ctx*/) override { }
  virtual void exitOptional__type_param_bounds_3(PnfRustParser::Optional__type_param_bounds_3Context * /*ctx*/) override { }

  virtual void enterOptional__trait_object_type_2(PnfRustParser::Optional__trait_object_type_2Context * /*ctx*/) override { }
  virtual void exitOptional__trait_object_type_2(PnfRustParser::Optional__trait_object_type_2Context * /*ctx*/) override { }

  virtual void enterOptional__bare_function_type_4(PnfRustParser::Optional__bare_function_type_4Context * /*ctx*/) override { }
  virtual void exitOptional__bare_function_type_4(PnfRustParser::Optional__bare_function_type_4Context * /*ctx*/) override { }

  virtual void enterOptional__extern_abi_1(PnfRustParser::Optional__extern_abi_1Context * /*ctx*/) override { }
  virtual void exitOptional__extern_abi_1(PnfRustParser::Optional__extern_abi_1Context * /*ctx*/) override { }

  virtual void enterAux_rule__type_arguments_1(PnfRustParser::Aux_rule__type_arguments_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__type_arguments_1(PnfRustParser::Aux_rule__type_arguments_1Context * /*ctx*/) override { }

  virtual void enterKleene_star__type_arguments_2(PnfRustParser::Kleene_star__type_arguments_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__type_arguments_2(PnfRustParser::Kleene_star__type_arguments_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__type_arguments_4(PnfRustParser::Aux_rule__type_arguments_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__type_arguments_4(PnfRustParser::Aux_rule__type_arguments_4Context * /*ctx*/) override { }

  virtual void enterKleene_star__type_arguments_5(PnfRustParser::Kleene_star__type_arguments_5Context * /*ctx*/) override { }
  virtual void exitKleene_star__type_arguments_5(PnfRustParser::Kleene_star__type_arguments_5Context * /*ctx*/) override { }

  virtual void enterAux_rule__type_arguments_6(PnfRustParser::Aux_rule__type_arguments_6Context * /*ctx*/) override { }
  virtual void exitAux_rule__type_arguments_6(PnfRustParser::Aux_rule__type_arguments_6Context * /*ctx*/) override { }

  virtual void enterKleene_star__type_arguments_7(PnfRustParser::Kleene_star__type_arguments_7Context * /*ctx*/) override { }
  virtual void exitKleene_star__type_arguments_7(PnfRustParser::Kleene_star__type_arguments_7Context * /*ctx*/) override { }

  virtual void enterOptional__ty_sum_1(PnfRustParser::Optional__ty_sum_1Context * /*ctx*/) override { }
  virtual void exitOptional__ty_sum_1(PnfRustParser::Optional__ty_sum_1Context * /*ctx*/) override { }

  virtual void enterAux_rule__ty_sum_2(PnfRustParser::Aux_rule__ty_sum_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__ty_sum_2(PnfRustParser::Aux_rule__ty_sum_2Context * /*ctx*/) override { }

  virtual void enterOptional__ty_sum_3(PnfRustParser::Optional__ty_sum_3Context * /*ctx*/) override { }
  virtual void exitOptional__ty_sum_3(PnfRustParser::Optional__ty_sum_3Context * /*ctx*/) override { }

  virtual void enterAux_rule__ty_sum_list_1(PnfRustParser::Aux_rule__ty_sum_list_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__ty_sum_list_1(PnfRustParser::Aux_rule__ty_sum_list_1Context * /*ctx*/) override { }

  virtual void enterKleene_star__ty_sum_list_2(PnfRustParser::Kleene_star__ty_sum_list_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__ty_sum_list_2(PnfRustParser::Kleene_star__ty_sum_list_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__type_parameters_1(PnfRustParser::Aux_rule__type_parameters_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__type_parameters_1(PnfRustParser::Aux_rule__type_parameters_1Context * /*ctx*/) override { }

  virtual void enterKleene_star__type_parameters_2(PnfRustParser::Kleene_star__type_parameters_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__type_parameters_2(PnfRustParser::Kleene_star__type_parameters_2Context * /*ctx*/) override { }

  virtual void enterOptional__type_parameters_3(PnfRustParser::Optional__type_parameters_3Context * /*ctx*/) override { }
  virtual void exitOptional__type_parameters_3(PnfRustParser::Optional__type_parameters_3Context * /*ctx*/) override { }

  virtual void enterAux_rule__lifetime_param_list_1(PnfRustParser::Aux_rule__lifetime_param_list_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__lifetime_param_list_1(PnfRustParser::Aux_rule__lifetime_param_list_1Context * /*ctx*/) override { }

  virtual void enterKleene_star__lifetime_param_list_2(PnfRustParser::Kleene_star__lifetime_param_list_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__lifetime_param_list_2(PnfRustParser::Kleene_star__lifetime_param_list_2Context * /*ctx*/) override { }

  virtual void enterOptional__type_parameter_4(PnfRustParser::Optional__type_parameter_4Context * /*ctx*/) override { }
  virtual void exitOptional__type_parameter_4(PnfRustParser::Optional__type_parameter_4Context * /*ctx*/) override { }

  virtual void enterAux_rule__type_parameter_list_1(PnfRustParser::Aux_rule__type_parameter_list_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__type_parameter_list_1(PnfRustParser::Aux_rule__type_parameter_list_1Context * /*ctx*/) override { }

  virtual void enterKleene_star__type_parameter_list_2(PnfRustParser::Kleene_star__type_parameter_list_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__type_parameter_list_2(PnfRustParser::Kleene_star__type_parameter_list_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__pattern_1(PnfRustParser::Aux_rule__pattern_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__pattern_1(PnfRustParser::Aux_rule__pattern_1Context * /*ctx*/) override { }

  virtual void enterOptional__pattern_2(PnfRustParser::Optional__pattern_2Context * /*ctx*/) override { }
  virtual void exitOptional__pattern_2(PnfRustParser::Optional__pattern_2Context * /*ctx*/) override { }

  virtual void enterOptional__pattern_without_mut_1(PnfRustParser::Optional__pattern_without_mut_1Context * /*ctx*/) override { }
  virtual void exitOptional__pattern_without_mut_1(PnfRustParser::Optional__pattern_without_mut_1Context * /*ctx*/) override { }

  virtual void enterAux_rule__pattern_without_mut_2(PnfRustParser::Aux_rule__pattern_without_mut_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__pattern_without_mut_2(PnfRustParser::Aux_rule__pattern_without_mut_2Context * /*ctx*/) override { }

  virtual void enterOptional__pattern_without_mut_3(PnfRustParser::Optional__pattern_without_mut_3Context * /*ctx*/) override { }
  virtual void exitOptional__pattern_without_mut_3(PnfRustParser::Optional__pattern_without_mut_3Context * /*ctx*/) override { }

  virtual void enterAux_rule__pattern_without_mut_4(PnfRustParser::Aux_rule__pattern_without_mut_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__pattern_without_mut_4(PnfRustParser::Aux_rule__pattern_without_mut_4Context * /*ctx*/) override { }

  virtual void enterKleene_star__pattern_without_mut_5(PnfRustParser::Kleene_star__pattern_without_mut_5Context * /*ctx*/) override { }
  virtual void exitKleene_star__pattern_without_mut_5(PnfRustParser::Kleene_star__pattern_without_mut_5Context * /*ctx*/) override { }

  virtual void enterOptional__pattern_without_mut_12(PnfRustParser::Optional__pattern_without_mut_12Context * /*ctx*/) override { }
  virtual void exitOptional__pattern_without_mut_12(PnfRustParser::Optional__pattern_without_mut_12Context * /*ctx*/) override { }

  virtual void enterOptional__pattern_without_mut_13(PnfRustParser::Optional__pattern_without_mut_13Context * /*ctx*/) override { }
  virtual void exitOptional__pattern_without_mut_13(PnfRustParser::Optional__pattern_without_mut_13Context * /*ctx*/) override { }

  virtual void enterAux_rule__pattern_without_mut_15(PnfRustParser::Aux_rule__pattern_without_mut_15Context * /*ctx*/) override { }
  virtual void exitAux_rule__pattern_without_mut_15(PnfRustParser::Aux_rule__pattern_without_mut_15Context * /*ctx*/) override { }

  virtual void enterKleene_star__pattern_without_mut_16(PnfRustParser::Kleene_star__pattern_without_mut_16Context * /*ctx*/) override { }
  virtual void exitKleene_star__pattern_without_mut_16(PnfRustParser::Kleene_star__pattern_without_mut_16Context * /*ctx*/) override { }

  virtual void enterOptional__pat_lit_1(PnfRustParser::Optional__pat_lit_1Context * /*ctx*/) override { }
  virtual void exitOptional__pat_lit_1(PnfRustParser::Optional__pat_lit_1Context * /*ctx*/) override { }

  virtual void enterOptional__pat_list_with_dots_3(PnfRustParser::Optional__pat_list_with_dots_3Context * /*ctx*/) override { }
  virtual void exitOptional__pat_list_with_dots_3(PnfRustParser::Optional__pat_list_with_dots_3Context * /*ctx*/) override { }

  virtual void enterAux_rule__pat_list_with_dots_4(PnfRustParser::Aux_rule__pat_list_with_dots_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__pat_list_with_dots_4(PnfRustParser::Aux_rule__pat_list_with_dots_4Context * /*ctx*/) override { }

  virtual void enterOptional__pat_list_with_dots_5(PnfRustParser::Optional__pat_list_with_dots_5Context * /*ctx*/) override { }
  virtual void exitOptional__pat_list_with_dots_5(PnfRustParser::Optional__pat_list_with_dots_5Context * /*ctx*/) override { }

  virtual void enterAux_rule__pat_list_dots_tail_1(PnfRustParser::Aux_rule__pat_list_dots_tail_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__pat_list_dots_tail_1(PnfRustParser::Aux_rule__pat_list_dots_tail_1Context * /*ctx*/) override { }

  virtual void enterOptional__pat_list_dots_tail_2(PnfRustParser::Optional__pat_list_dots_tail_2Context * /*ctx*/) override { }
  virtual void exitOptional__pat_list_dots_tail_2(PnfRustParser::Optional__pat_list_dots_tail_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__pat_fields_1(PnfRustParser::Aux_rule__pat_fields_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__pat_fields_1(PnfRustParser::Aux_rule__pat_fields_1Context * /*ctx*/) override { }

  virtual void enterKleene_star__pat_fields_2(PnfRustParser::Kleene_star__pat_fields_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__pat_fields_2(PnfRustParser::Kleene_star__pat_fields_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__pat_fields_3(PnfRustParser::Aux_rule__pat_fields_3Context * /*ctx*/) override { }
  virtual void exitAux_rule__pat_fields_3(PnfRustParser::Aux_rule__pat_fields_3Context * /*ctx*/) override { }

  virtual void enterKleene_star__pat_fields_4(PnfRustParser::Kleene_star__pat_fields_4Context * /*ctx*/) override { }
  virtual void exitKleene_star__pat_fields_4(PnfRustParser::Kleene_star__pat_fields_4Context * /*ctx*/) override { }

  virtual void enterOptional__pat_field_2(PnfRustParser::Optional__pat_field_2Context * /*ctx*/) override { }
  virtual void exitOptional__pat_field_2(PnfRustParser::Optional__pat_field_2Context * /*ctx*/) override { }

  virtual void enterOptional__expr_1(PnfRustParser::Optional__expr_1Context * /*ctx*/) override { }
  virtual void exitOptional__expr_1(PnfRustParser::Optional__expr_1Context * /*ctx*/) override { }

  virtual void enterOptional__expr_2(PnfRustParser::Optional__expr_2Context * /*ctx*/) override { }
  virtual void exitOptional__expr_2(PnfRustParser::Optional__expr_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__expr_list_1(PnfRustParser::Aux_rule__expr_list_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__expr_list_1(PnfRustParser::Aux_rule__expr_list_1Context * /*ctx*/) override { }

  virtual void enterKleene_star__expr_list_2(PnfRustParser::Kleene_star__expr_list_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__expr_list_2(PnfRustParser::Kleene_star__expr_list_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__block_with_inner_attrs_2(PnfRustParser::Kleene_star__block_with_inner_attrs_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__block_with_inner_attrs_2(PnfRustParser::Kleene_star__block_with_inner_attrs_2Context * /*ctx*/) override { }

  virtual void enterOptional__block_with_inner_attrs_3(PnfRustParser::Optional__block_with_inner_attrs_3Context * /*ctx*/) override { }
  virtual void exitOptional__block_with_inner_attrs_3(PnfRustParser::Optional__block_with_inner_attrs_3Context * /*ctx*/) override { }

  virtual void enterAux_rule__blocky_expr_1(PnfRustParser::Aux_rule__blocky_expr_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__blocky_expr_1(PnfRustParser::Aux_rule__blocky_expr_1Context * /*ctx*/) override { }

  virtual void enterKleene_star__blocky_expr_2(PnfRustParser::Kleene_star__blocky_expr_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__blocky_expr_2(PnfRustParser::Kleene_star__blocky_expr_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__blocky_expr_3(PnfRustParser::Aux_rule__blocky_expr_3Context * /*ctx*/) override { }
  virtual void exitAux_rule__blocky_expr_3(PnfRustParser::Aux_rule__blocky_expr_3Context * /*ctx*/) override { }

  virtual void enterOptional__blocky_expr_4(PnfRustParser::Optional__blocky_expr_4Context * /*ctx*/) override { }
  virtual void exitOptional__blocky_expr_4(PnfRustParser::Optional__blocky_expr_4Context * /*ctx*/) override { }

  virtual void enterOptional__blocky_expr_5(PnfRustParser::Optional__blocky_expr_5Context * /*ctx*/) override { }
  virtual void exitOptional__blocky_expr_5(PnfRustParser::Optional__blocky_expr_5Context * /*ctx*/) override { }

  virtual void enterOptional__blocky_expr_6(PnfRustParser::Optional__blocky_expr_6Context * /*ctx*/) override { }
  virtual void exitOptional__blocky_expr_6(PnfRustParser::Optional__blocky_expr_6Context * /*ctx*/) override { }

  virtual void enterOptional__blocky_expr_7(PnfRustParser::Optional__blocky_expr_7Context * /*ctx*/) override { }
  virtual void exitOptional__blocky_expr_7(PnfRustParser::Optional__blocky_expr_7Context * /*ctx*/) override { }

  virtual void enterAux_rule__match_arms_4(PnfRustParser::Aux_rule__match_arms_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__match_arms_4(PnfRustParser::Aux_rule__match_arms_4Context * /*ctx*/) override { }

  virtual void enterOptional__match_arms_5(PnfRustParser::Optional__match_arms_5Context * /*ctx*/) override { }
  virtual void exitOptional__match_arms_5(PnfRustParser::Optional__match_arms_5Context * /*ctx*/) override { }

  virtual void enterOptional__match_arm_intro_2(PnfRustParser::Optional__match_arm_intro_2Context * /*ctx*/) override { }
  virtual void exitOptional__match_arm_intro_2(PnfRustParser::Optional__match_arm_intro_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__match_pattern_2(PnfRustParser::Aux_rule__match_pattern_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__match_pattern_2(PnfRustParser::Aux_rule__match_pattern_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__match_pattern_3(PnfRustParser::Kleene_star__match_pattern_3Context * /*ctx*/) override { }
  virtual void exitKleene_star__match_pattern_3(PnfRustParser::Kleene_star__match_pattern_3Context * /*ctx*/) override { }

  virtual void enterOptional__prim_expr_1(PnfRustParser::Optional__prim_expr_1Context * /*ctx*/) override { }
  virtual void exitOptional__prim_expr_1(PnfRustParser::Optional__prim_expr_1Context * /*ctx*/) override { }

  virtual void enterOptional__prim_expr_2(PnfRustParser::Optional__prim_expr_2Context * /*ctx*/) override { }
  virtual void exitOptional__prim_expr_2(PnfRustParser::Optional__prim_expr_2Context * /*ctx*/) override { }

  virtual void enterOptional__prim_expr_no_struct_1(PnfRustParser::Optional__prim_expr_no_struct_1Context * /*ctx*/) override { }
  virtual void exitOptional__prim_expr_no_struct_1(PnfRustParser::Optional__prim_expr_no_struct_1Context * /*ctx*/) override { }

  virtual void enterOptional__prim_expr_no_struct_5(PnfRustParser::Optional__prim_expr_no_struct_5Context * /*ctx*/) override { }
  virtual void exitOptional__prim_expr_no_struct_5(PnfRustParser::Optional__prim_expr_no_struct_5Context * /*ctx*/) override { }

  virtual void enterOptional__prim_expr_no_struct_9(PnfRustParser::Optional__prim_expr_no_struct_9Context * /*ctx*/) override { }
  virtual void exitOptional__prim_expr_no_struct_9(PnfRustParser::Optional__prim_expr_no_struct_9Context * /*ctx*/) override { }

  virtual void enterOptional__prim_expr_no_struct_10(PnfRustParser::Optional__prim_expr_no_struct_10Context * /*ctx*/) override { }
  virtual void exitOptional__prim_expr_no_struct_10(PnfRustParser::Optional__prim_expr_no_struct_10Context * /*ctx*/) override { }

  virtual void enterOptional__prim_expr_no_struct_11(PnfRustParser::Optional__prim_expr_no_struct_11Context * /*ctx*/) override { }
  virtual void exitOptional__prim_expr_no_struct_11(PnfRustParser::Optional__prim_expr_no_struct_11Context * /*ctx*/) override { }

  virtual void enterOptional__prim_expr_no_struct_12(PnfRustParser::Optional__prim_expr_no_struct_12Context * /*ctx*/) override { }
  virtual void exitOptional__prim_expr_no_struct_12(PnfRustParser::Optional__prim_expr_no_struct_12Context * /*ctx*/) override { }

  virtual void enterOptional__prim_expr_no_struct_13(PnfRustParser::Optional__prim_expr_no_struct_13Context * /*ctx*/) override { }
  virtual void exitOptional__prim_expr_no_struct_13(PnfRustParser::Optional__prim_expr_no_struct_13Context * /*ctx*/) override { }

  virtual void enterOptional__closure_params_1(PnfRustParser::Optional__closure_params_1Context * /*ctx*/) override { }
  virtual void exitOptional__closure_params_1(PnfRustParser::Optional__closure_params_1Context * /*ctx*/) override { }

  virtual void enterAux_rule__closure_param_list_1(PnfRustParser::Aux_rule__closure_param_list_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__closure_param_list_1(PnfRustParser::Aux_rule__closure_param_list_1Context * /*ctx*/) override { }

  virtual void enterKleene_star__closure_param_list_2(PnfRustParser::Kleene_star__closure_param_list_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__closure_param_list_2(PnfRustParser::Kleene_star__closure_param_list_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__fields_1(PnfRustParser::Aux_rule__fields_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__fields_1(PnfRustParser::Aux_rule__fields_1Context * /*ctx*/) override { }

  virtual void enterKleene_star__fields_2(PnfRustParser::Kleene_star__fields_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__fields_2(PnfRustParser::Kleene_star__fields_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__field_1(PnfRustParser::Kleene_star__field_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__field_1(PnfRustParser::Kleene_star__field_1Context * /*ctx*/) override { }

  virtual void enterAux_rule__post_expr_tail_4(PnfRustParser::Aux_rule__post_expr_tail_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__post_expr_tail_4(PnfRustParser::Aux_rule__post_expr_tail_4Context * /*ctx*/) override { }

  virtual void enterOptional__post_expr_tail_5(PnfRustParser::Optional__post_expr_tail_5Context * /*ctx*/) override { }
  virtual void exitOptional__post_expr_tail_5(PnfRustParser::Optional__post_expr_tail_5Context * /*ctx*/) override { }

  virtual void enterOptional__range_expr_1(PnfRustParser::Optional__range_expr_1Context * /*ctx*/) override { }
  virtual void exitOptional__range_expr_1(PnfRustParser::Optional__range_expr_1Context * /*ctx*/) override { }

  virtual void enterOptional__range_expr_no_struct_1(PnfRustParser::Optional__range_expr_no_struct_1Context * /*ctx*/) override { }
  virtual void exitOptional__range_expr_no_struct_1(PnfRustParser::Optional__range_expr_no_struct_1Context * /*ctx*/) override { }

  virtual void enterOptional__macro_rules_def_1(PnfRustParser::Optional__macro_rules_def_1Context * /*ctx*/) override { }
  virtual void exitOptional__macro_rules_def_1(PnfRustParser::Optional__macro_rules_def_1Context * /*ctx*/) override { }

  virtual void enterAux_rule__macro_rules_1(PnfRustParser::Aux_rule__macro_rules_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__macro_rules_1(PnfRustParser::Aux_rule__macro_rules_1Context * /*ctx*/) override { }

  virtual void enterKleene_star__macro_rules_2(PnfRustParser::Kleene_star__macro_rules_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__macro_rules_2(PnfRustParser::Kleene_star__macro_rules_2Context * /*ctx*/) override { }

  virtual void enterOptional__macro_rules_3(PnfRustParser::Optional__macro_rules_3Context * /*ctx*/) override { }
  virtual void exitOptional__macro_rules_3(PnfRustParser::Optional__macro_rules_3Context * /*ctx*/) override { }

  virtual void enterKleene_star__macro_matcher_1(PnfRustParser::Kleene_star__macro_matcher_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__macro_matcher_1(PnfRustParser::Kleene_star__macro_matcher_1Context * /*ctx*/) override { }

  virtual void enterKleene_plus__macro_match_1(PnfRustParser::Kleene_plus__macro_match_1Context * /*ctx*/) override { }
  virtual void exitKleene_plus__macro_match_1(PnfRustParser::Kleene_plus__macro_match_1Context * /*ctx*/) override { }

  virtual void enterOptional__macro_match_2(PnfRustParser::Optional__macro_match_2Context * /*ctx*/) override { }
  virtual void exitOptional__macro_match_2(PnfRustParser::Optional__macro_match_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__bound_4(PnfRustParser::Aux_rule__bound_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__bound_4(PnfRustParser::Aux_rule__bound_4Context * /*ctx*/) override { }

  virtual void enterKleene_star__bound_3(PnfRustParser::Kleene_star__bound_3Context * /*ctx*/) override { }
  virtual void exitKleene_star__bound_3(PnfRustParser::Kleene_star__bound_3Context * /*ctx*/) override { }

  virtual void enterBound(PnfRustParser::BoundContext * /*ctx*/) override { }
  virtual void exitBound(PnfRustParser::BoundContext * /*ctx*/) override { }

  virtual void enterAux_rule__path_parent_3(PnfRustParser::Aux_rule__path_parent_3Context * /*ctx*/) override { }
  virtual void exitAux_rule__path_parent_3(PnfRustParser::Aux_rule__path_parent_3Context * /*ctx*/) override { }

  virtual void enterKleene_star__path_parent_2(PnfRustParser::Kleene_star__path_parent_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__path_parent_2(PnfRustParser::Kleene_star__path_parent_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__path_parent_4(PnfRustParser::Aux_rule__path_parent_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__path_parent_4(PnfRustParser::Aux_rule__path_parent_4Context * /*ctx*/) override { }

  virtual void enterPath_parent(PnfRustParser::Path_parentContext * /*ctx*/) override { }
  virtual void exitPath_parent(PnfRustParser::Path_parentContext * /*ctx*/) override { }

  virtual void enterAux_rule__lifetime_bound_2(PnfRustParser::Aux_rule__lifetime_bound_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__lifetime_bound_2(PnfRustParser::Aux_rule__lifetime_bound_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__lifetime_bound_1(PnfRustParser::Kleene_star__lifetime_bound_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__lifetime_bound_1(PnfRustParser::Kleene_star__lifetime_bound_1Context * /*ctx*/) override { }

  virtual void enterLifetime_bound(PnfRustParser::Lifetime_boundContext * /*ctx*/) override { }
  virtual void exitLifetime_bound(PnfRustParser::Lifetime_boundContext * /*ctx*/) override { }

  virtual void enterAux_rule__ty_path_parent_3(PnfRustParser::Aux_rule__ty_path_parent_3Context * /*ctx*/) override { }
  virtual void exitAux_rule__ty_path_parent_3(PnfRustParser::Aux_rule__ty_path_parent_3Context * /*ctx*/) override { }

  virtual void enterKleene_star__ty_path_parent_2(PnfRustParser::Kleene_star__ty_path_parent_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__ty_path_parent_2(PnfRustParser::Kleene_star__ty_path_parent_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__ty_path_parent_4(PnfRustParser::Aux_rule__ty_path_parent_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__ty_path_parent_4(PnfRustParser::Aux_rule__ty_path_parent_4Context * /*ctx*/) override { }

  virtual void enterTy_path_parent(PnfRustParser::Ty_path_parentContext * /*ctx*/) override { }
  virtual void exitTy_path_parent(PnfRustParser::Ty_path_parentContext * /*ctx*/) override { }

  virtual void enterAux_rule__pattern_without_mut_19(PnfRustParser::Aux_rule__pattern_without_mut_19Context * /*ctx*/) override { }
  virtual void exitAux_rule__pattern_without_mut_19(PnfRustParser::Aux_rule__pattern_without_mut_19Context * /*ctx*/) override { }

  virtual void enterKleene_star__pattern_without_mut_18(PnfRustParser::Kleene_star__pattern_without_mut_18Context * /*ctx*/) override { }
  virtual void exitKleene_star__pattern_without_mut_18(PnfRustParser::Kleene_star__pattern_without_mut_18Context * /*ctx*/) override { }

  virtual void enterAux_rule__pattern_without_mut_20(PnfRustParser::Aux_rule__pattern_without_mut_20Context * /*ctx*/) override { }
  virtual void exitAux_rule__pattern_without_mut_20(PnfRustParser::Aux_rule__pattern_without_mut_20Context * /*ctx*/) override { }

  virtual void enterPattern_without_mut(PnfRustParser::Pattern_without_mutContext * /*ctx*/) override { }
  virtual void exitPattern_without_mut(PnfRustParser::Pattern_without_mutContext * /*ctx*/) override { }

  virtual void enterKleene_star__post_expr_1(PnfRustParser::Kleene_star__post_expr_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__post_expr_1(PnfRustParser::Kleene_star__post_expr_1Context * /*ctx*/) override { }

  virtual void enterPost_expr(PnfRustParser::Post_exprContext * /*ctx*/) override { }
  virtual void exitPost_expr(PnfRustParser::Post_exprContext * /*ctx*/) override { }

  virtual void enterAux_rule__cast_expr_2(PnfRustParser::Aux_rule__cast_expr_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__cast_expr_2(PnfRustParser::Aux_rule__cast_expr_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__cast_expr_1(PnfRustParser::Kleene_star__cast_expr_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__cast_expr_1(PnfRustParser::Kleene_star__cast_expr_1Context * /*ctx*/) override { }

  virtual void enterCast_expr(PnfRustParser::Cast_exprContext * /*ctx*/) override { }
  virtual void exitCast_expr(PnfRustParser::Cast_exprContext * /*ctx*/) override { }

  virtual void enterAux_rule__mul_expr_2(PnfRustParser::Aux_rule__mul_expr_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__mul_expr_2(PnfRustParser::Aux_rule__mul_expr_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__mul_expr_1(PnfRustParser::Kleene_star__mul_expr_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__mul_expr_1(PnfRustParser::Kleene_star__mul_expr_1Context * /*ctx*/) override { }

  virtual void enterMul_expr(PnfRustParser::Mul_exprContext * /*ctx*/) override { }
  virtual void exitMul_expr(PnfRustParser::Mul_exprContext * /*ctx*/) override { }

  virtual void enterAux_rule__add_expr_2(PnfRustParser::Aux_rule__add_expr_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__add_expr_2(PnfRustParser::Aux_rule__add_expr_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__add_expr_1(PnfRustParser::Kleene_star__add_expr_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__add_expr_1(PnfRustParser::Kleene_star__add_expr_1Context * /*ctx*/) override { }

  virtual void enterAdd_expr(PnfRustParser::Add_exprContext * /*ctx*/) override { }
  virtual void exitAdd_expr(PnfRustParser::Add_exprContext * /*ctx*/) override { }

  virtual void enterAux_rule__shift_expr_2(PnfRustParser::Aux_rule__shift_expr_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__shift_expr_2(PnfRustParser::Aux_rule__shift_expr_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__shift_expr_1(PnfRustParser::Kleene_star__shift_expr_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__shift_expr_1(PnfRustParser::Kleene_star__shift_expr_1Context * /*ctx*/) override { }

  virtual void enterShift_expr(PnfRustParser::Shift_exprContext * /*ctx*/) override { }
  virtual void exitShift_expr(PnfRustParser::Shift_exprContext * /*ctx*/) override { }

  virtual void enterAux_rule__bit_and_expr_2(PnfRustParser::Aux_rule__bit_and_expr_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__bit_and_expr_2(PnfRustParser::Aux_rule__bit_and_expr_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__bit_and_expr_1(PnfRustParser::Kleene_star__bit_and_expr_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__bit_and_expr_1(PnfRustParser::Kleene_star__bit_and_expr_1Context * /*ctx*/) override { }

  virtual void enterBit_and_expr(PnfRustParser::Bit_and_exprContext * /*ctx*/) override { }
  virtual void exitBit_and_expr(PnfRustParser::Bit_and_exprContext * /*ctx*/) override { }

  virtual void enterAux_rule__bit_xor_expr_2(PnfRustParser::Aux_rule__bit_xor_expr_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__bit_xor_expr_2(PnfRustParser::Aux_rule__bit_xor_expr_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__bit_xor_expr_1(PnfRustParser::Kleene_star__bit_xor_expr_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__bit_xor_expr_1(PnfRustParser::Kleene_star__bit_xor_expr_1Context * /*ctx*/) override { }

  virtual void enterBit_xor_expr(PnfRustParser::Bit_xor_exprContext * /*ctx*/) override { }
  virtual void exitBit_xor_expr(PnfRustParser::Bit_xor_exprContext * /*ctx*/) override { }

  virtual void enterAux_rule__bit_or_expr_2(PnfRustParser::Aux_rule__bit_or_expr_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__bit_or_expr_2(PnfRustParser::Aux_rule__bit_or_expr_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__bit_or_expr_1(PnfRustParser::Kleene_star__bit_or_expr_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__bit_or_expr_1(PnfRustParser::Kleene_star__bit_or_expr_1Context * /*ctx*/) override { }

  virtual void enterBit_or_expr(PnfRustParser::Bit_or_exprContext * /*ctx*/) override { }
  virtual void exitBit_or_expr(PnfRustParser::Bit_or_exprContext * /*ctx*/) override { }

  virtual void enterAux_rule__and_expr_2(PnfRustParser::Aux_rule__and_expr_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__and_expr_2(PnfRustParser::Aux_rule__and_expr_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__and_expr_1(PnfRustParser::Kleene_star__and_expr_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__and_expr_1(PnfRustParser::Kleene_star__and_expr_1Context * /*ctx*/) override { }

  virtual void enterAnd_expr(PnfRustParser::And_exprContext * /*ctx*/) override { }
  virtual void exitAnd_expr(PnfRustParser::And_exprContext * /*ctx*/) override { }

  virtual void enterAux_rule__or_expr_2(PnfRustParser::Aux_rule__or_expr_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__or_expr_2(PnfRustParser::Aux_rule__or_expr_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__or_expr_1(PnfRustParser::Kleene_star__or_expr_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__or_expr_1(PnfRustParser::Kleene_star__or_expr_1Context * /*ctx*/) override { }

  virtual void enterOr_expr(PnfRustParser::Or_exprContext * /*ctx*/) override { }
  virtual void exitOr_expr(PnfRustParser::Or_exprContext * /*ctx*/) override { }

  virtual void enterPost_expr_no_struct(PnfRustParser::Post_expr_no_structContext * /*ctx*/) override { }
  virtual void exitPost_expr_no_struct(PnfRustParser::Post_expr_no_structContext * /*ctx*/) override { }

  virtual void enterCast_expr_no_struct(PnfRustParser::Cast_expr_no_structContext * /*ctx*/) override { }
  virtual void exitCast_expr_no_struct(PnfRustParser::Cast_expr_no_structContext * /*ctx*/) override { }

  virtual void enterAux_rule__mul_expr_no_struct_2(PnfRustParser::Aux_rule__mul_expr_no_struct_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__mul_expr_no_struct_2(PnfRustParser::Aux_rule__mul_expr_no_struct_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__mul_expr_no_struct_1(PnfRustParser::Kleene_star__mul_expr_no_struct_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__mul_expr_no_struct_1(PnfRustParser::Kleene_star__mul_expr_no_struct_1Context * /*ctx*/) override { }

  virtual void enterMul_expr_no_struct(PnfRustParser::Mul_expr_no_structContext * /*ctx*/) override { }
  virtual void exitMul_expr_no_struct(PnfRustParser::Mul_expr_no_structContext * /*ctx*/) override { }

  virtual void enterAux_rule__add_expr_no_struct_2(PnfRustParser::Aux_rule__add_expr_no_struct_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__add_expr_no_struct_2(PnfRustParser::Aux_rule__add_expr_no_struct_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__add_expr_no_struct_1(PnfRustParser::Kleene_star__add_expr_no_struct_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__add_expr_no_struct_1(PnfRustParser::Kleene_star__add_expr_no_struct_1Context * /*ctx*/) override { }

  virtual void enterAdd_expr_no_struct(PnfRustParser::Add_expr_no_structContext * /*ctx*/) override { }
  virtual void exitAdd_expr_no_struct(PnfRustParser::Add_expr_no_structContext * /*ctx*/) override { }

  virtual void enterAux_rule__shift_expr_no_struct_2(PnfRustParser::Aux_rule__shift_expr_no_struct_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__shift_expr_no_struct_2(PnfRustParser::Aux_rule__shift_expr_no_struct_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__shift_expr_no_struct_1(PnfRustParser::Kleene_star__shift_expr_no_struct_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__shift_expr_no_struct_1(PnfRustParser::Kleene_star__shift_expr_no_struct_1Context * /*ctx*/) override { }

  virtual void enterShift_expr_no_struct(PnfRustParser::Shift_expr_no_structContext * /*ctx*/) override { }
  virtual void exitShift_expr_no_struct(PnfRustParser::Shift_expr_no_structContext * /*ctx*/) override { }

  virtual void enterAux_rule__bit_and_expr_no_struct_2(PnfRustParser::Aux_rule__bit_and_expr_no_struct_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__bit_and_expr_no_struct_2(PnfRustParser::Aux_rule__bit_and_expr_no_struct_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__bit_and_expr_no_struct_1(PnfRustParser::Kleene_star__bit_and_expr_no_struct_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__bit_and_expr_no_struct_1(PnfRustParser::Kleene_star__bit_and_expr_no_struct_1Context * /*ctx*/) override { }

  virtual void enterBit_and_expr_no_struct(PnfRustParser::Bit_and_expr_no_structContext * /*ctx*/) override { }
  virtual void exitBit_and_expr_no_struct(PnfRustParser::Bit_and_expr_no_structContext * /*ctx*/) override { }

  virtual void enterAux_rule__bit_xor_expr_no_struct_2(PnfRustParser::Aux_rule__bit_xor_expr_no_struct_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__bit_xor_expr_no_struct_2(PnfRustParser::Aux_rule__bit_xor_expr_no_struct_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__bit_xor_expr_no_struct_1(PnfRustParser::Kleene_star__bit_xor_expr_no_struct_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__bit_xor_expr_no_struct_1(PnfRustParser::Kleene_star__bit_xor_expr_no_struct_1Context * /*ctx*/) override { }

  virtual void enterBit_xor_expr_no_struct(PnfRustParser::Bit_xor_expr_no_structContext * /*ctx*/) override { }
  virtual void exitBit_xor_expr_no_struct(PnfRustParser::Bit_xor_expr_no_structContext * /*ctx*/) override { }

  virtual void enterAux_rule__bit_or_expr_no_struct_2(PnfRustParser::Aux_rule__bit_or_expr_no_struct_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__bit_or_expr_no_struct_2(PnfRustParser::Aux_rule__bit_or_expr_no_struct_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__bit_or_expr_no_struct_1(PnfRustParser::Kleene_star__bit_or_expr_no_struct_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__bit_or_expr_no_struct_1(PnfRustParser::Kleene_star__bit_or_expr_no_struct_1Context * /*ctx*/) override { }

  virtual void enterBit_or_expr_no_struct(PnfRustParser::Bit_or_expr_no_structContext * /*ctx*/) override { }
  virtual void exitBit_or_expr_no_struct(PnfRustParser::Bit_or_expr_no_structContext * /*ctx*/) override { }

  virtual void enterAux_rule__and_expr_no_struct_2(PnfRustParser::Aux_rule__and_expr_no_struct_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__and_expr_no_struct_2(PnfRustParser::Aux_rule__and_expr_no_struct_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__and_expr_no_struct_1(PnfRustParser::Kleene_star__and_expr_no_struct_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__and_expr_no_struct_1(PnfRustParser::Kleene_star__and_expr_no_struct_1Context * /*ctx*/) override { }

  virtual void enterAnd_expr_no_struct(PnfRustParser::And_expr_no_structContext * /*ctx*/) override { }
  virtual void exitAnd_expr_no_struct(PnfRustParser::And_expr_no_structContext * /*ctx*/) override { }

  virtual void enterAux_rule__or_expr_no_struct_2(PnfRustParser::Aux_rule__or_expr_no_struct_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__or_expr_no_struct_2(PnfRustParser::Aux_rule__or_expr_no_struct_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__or_expr_no_struct_1(PnfRustParser::Kleene_star__or_expr_no_struct_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__or_expr_no_struct_1(PnfRustParser::Kleene_star__or_expr_no_struct_1Context * /*ctx*/) override { }

  virtual void enterOr_expr_no_struct(PnfRustParser::Or_expr_no_structContext * /*ctx*/) override { }
  virtual void exitOr_expr_no_struct(PnfRustParser::Or_expr_no_structContext * /*ctx*/) override { }

  virtual void enterKleene_plus__expr_attrs_2(PnfRustParser::Kleene_plus__expr_attrs_2Context * /*ctx*/) override { }
  virtual void exitKleene_plus__expr_attrs_2(PnfRustParser::Kleene_plus__expr_attrs_2Context * /*ctx*/) override { }

  virtual void enterKleene_plus__expr_inner_attrs_2(PnfRustParser::Kleene_plus__expr_inner_attrs_2Context * /*ctx*/) override { }
  virtual void exitKleene_plus__expr_inner_attrs_2(PnfRustParser::Kleene_plus__expr_inner_attrs_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__enum_variant_main_3(PnfRustParser::Aux_rule__enum_variant_main_3Context * /*ctx*/) override { }
  virtual void exitAux_rule__enum_variant_main_3(PnfRustParser::Aux_rule__enum_variant_main_3Context * /*ctx*/) override { }

  virtual void enterOptional__enum_variant_main_4(PnfRustParser::Optional__enum_variant_main_4Context * /*ctx*/) override { }
  virtual void exitOptional__enum_variant_main_4(PnfRustParser::Optional__enum_variant_main_4Context * /*ctx*/) override { }

  virtual void enterAux_rule__impl_what_1(PnfRustParser::Aux_rule__impl_what_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__impl_what_1(PnfRustParser::Aux_rule__impl_what_1Context * /*ctx*/) override { }

  virtual void enterOptional__impl_what_2(PnfRustParser::Optional__impl_what_2Context * /*ctx*/) override { }
  virtual void exitOptional__impl_what_2(PnfRustParser::Optional__impl_what_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__path_2(PnfRustParser::Aux_rule__path_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__path_2(PnfRustParser::Aux_rule__path_2Context * /*ctx*/) override { }

  virtual void enterOptional__path_3(PnfRustParser::Optional__path_3Context * /*ctx*/) override { }
  virtual void exitOptional__path_3(PnfRustParser::Optional__path_3Context * /*ctx*/) override { }

  virtual void enterAux_rule__type_path_main_2(PnfRustParser::Aux_rule__type_path_main_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__type_path_main_2(PnfRustParser::Aux_rule__type_path_main_2Context * /*ctx*/) override { }

  virtual void enterOptional__type_path_main_3(PnfRustParser::Optional__type_path_main_3Context * /*ctx*/) override { }
  virtual void exitOptional__type_path_main_3(PnfRustParser::Optional__type_path_main_3Context * /*ctx*/) override { }

  virtual void enterAux_rule__tuple_type_2(PnfRustParser::Aux_rule__tuple_type_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__tuple_type_2(PnfRustParser::Aux_rule__tuple_type_2Context * /*ctx*/) override { }

  virtual void enterOptional__tuple_type_3(PnfRustParser::Optional__tuple_type_3Context * /*ctx*/) override { }
  virtual void exitOptional__tuple_type_3(PnfRustParser::Optional__tuple_type_3Context * /*ctx*/) override { }

  virtual void enterAux_rule__type_argument_1(PnfRustParser::Aux_rule__type_argument_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__type_argument_1(PnfRustParser::Aux_rule__type_argument_1Context * /*ctx*/) override { }

  virtual void enterOptional__type_argument_2(PnfRustParser::Optional__type_argument_2Context * /*ctx*/) override { }
  virtual void exitOptional__type_argument_2(PnfRustParser::Optional__type_argument_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__pattern_without_mut_21(PnfRustParser::Aux_rule__pattern_without_mut_21Context * /*ctx*/) override { }
  virtual void exitAux_rule__pattern_without_mut_21(PnfRustParser::Aux_rule__pattern_without_mut_21Context * /*ctx*/) override { }

  virtual void enterOptional__pattern_without_mut_22(PnfRustParser::Optional__pattern_without_mut_22Context * /*ctx*/) override { }
  virtual void exitOptional__pattern_without_mut_22(PnfRustParser::Optional__pattern_without_mut_22Context * /*ctx*/) override { }

  virtual void enterAux_rule__pattern_without_mut_23(PnfRustParser::Aux_rule__pattern_without_mut_23Context * /*ctx*/) override { }
  virtual void exitAux_rule__pattern_without_mut_23(PnfRustParser::Aux_rule__pattern_without_mut_23Context * /*ctx*/) override { }

  virtual void enterOptional__pattern_without_mut_24(PnfRustParser::Optional__pattern_without_mut_24Context * /*ctx*/) override { }
  virtual void exitOptional__pattern_without_mut_24(PnfRustParser::Optional__pattern_without_mut_24Context * /*ctx*/) override { }

  virtual void enterAux_rule__assign_expr_1(PnfRustParser::Aux_rule__assign_expr_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__assign_expr_1(PnfRustParser::Aux_rule__assign_expr_1Context * /*ctx*/) override { }

  virtual void enterOptional__assign_expr_2(PnfRustParser::Optional__assign_expr_2Context * /*ctx*/) override { }
  virtual void exitOptional__assign_expr_2(PnfRustParser::Optional__assign_expr_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__assign_expr_no_struct_1(PnfRustParser::Aux_rule__assign_expr_no_struct_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__assign_expr_no_struct_1(PnfRustParser::Aux_rule__assign_expr_no_struct_1Context * /*ctx*/) override { }

  virtual void enterOptional__assign_expr_no_struct_2(PnfRustParser::Optional__assign_expr_no_struct_2Context * /*ctx*/) override { }
  virtual void exitOptional__assign_expr_no_struct_2(PnfRustParser::Optional__assign_expr_no_struct_2Context * /*ctx*/) override { }

  virtual void enterOptional__blocky_expr_11(PnfRustParser::Optional__blocky_expr_11Context * /*ctx*/) override { }
  virtual void exitOptional__blocky_expr_11(PnfRustParser::Optional__blocky_expr_11Context * /*ctx*/) override { }

  virtual void enterOptional__closure_params_2(PnfRustParser::Optional__closure_params_2Context * /*ctx*/) override { }
  virtual void exitOptional__closure_params_2(PnfRustParser::Optional__closure_params_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__cmp_expr_1(PnfRustParser::Aux_rule__cmp_expr_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__cmp_expr_1(PnfRustParser::Aux_rule__cmp_expr_1Context * /*ctx*/) override { }

  virtual void enterOptional__cmp_expr_2(PnfRustParser::Optional__cmp_expr_2Context * /*ctx*/) override { }
  virtual void exitOptional__cmp_expr_2(PnfRustParser::Optional__cmp_expr_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__range_expr_5(PnfRustParser::Aux_rule__range_expr_5Context * /*ctx*/) override { }
  virtual void exitAux_rule__range_expr_5(PnfRustParser::Aux_rule__range_expr_5Context * /*ctx*/) override { }

  virtual void enterOptional__range_expr_6(PnfRustParser::Optional__range_expr_6Context * /*ctx*/) override { }
  virtual void exitOptional__range_expr_6(PnfRustParser::Optional__range_expr_6Context * /*ctx*/) override { }

  virtual void enterAux_rule__cmp_expr_no_struct_5(PnfRustParser::Aux_rule__cmp_expr_no_struct_5Context * /*ctx*/) override { }
  virtual void exitAux_rule__cmp_expr_no_struct_5(PnfRustParser::Aux_rule__cmp_expr_no_struct_5Context * /*ctx*/) override { }

  virtual void enterOptional__cmp_expr_no_struct_6(PnfRustParser::Optional__cmp_expr_no_struct_6Context * /*ctx*/) override { }
  virtual void exitOptional__cmp_expr_no_struct_6(PnfRustParser::Optional__cmp_expr_no_struct_6Context * /*ctx*/) override { }

  virtual void enterAux_rule__range_expr_no_struct_5(PnfRustParser::Aux_rule__range_expr_no_struct_5Context * /*ctx*/) override { }
  virtual void exitAux_rule__range_expr_no_struct_5(PnfRustParser::Aux_rule__range_expr_no_struct_5Context * /*ctx*/) override { }

  virtual void enterOptional__range_expr_no_struct_6(PnfRustParser::Optional__range_expr_no_struct_6Context * /*ctx*/) override { }
  virtual void exitOptional__range_expr_no_struct_6(PnfRustParser::Optional__range_expr_no_struct_6Context * /*ctx*/) override { }

  virtual void enterAltnt_block__visibility_restriction_1(PnfRustParser::Altnt_block__visibility_restriction_1Context * /*ctx*/) override { }
  virtual void exitAltnt_block__visibility_restriction_1(PnfRustParser::Altnt_block__visibility_restriction_1Context * /*ctx*/) override { }

  virtual void enterAltnt_block__type_decl_10(PnfRustParser::Altnt_block__type_decl_10Context * /*ctx*/) override { }
  virtual void exitAltnt_block__type_decl_10(PnfRustParser::Altnt_block__type_decl_10Context * /*ctx*/) override { }

  virtual void enterAltnt_block__use_suffix_2(PnfRustParser::Altnt_block__use_suffix_2Context * /*ctx*/) override { }
  virtual void exitAltnt_block__use_suffix_2(PnfRustParser::Altnt_block__use_suffix_2Context * /*ctx*/) override { }

  virtual void enterAltnt_block__foreign_item_tail_11(PnfRustParser::Altnt_block__foreign_item_tail_11Context * /*ctx*/) override { }
  virtual void exitAltnt_block__foreign_item_tail_11(PnfRustParser::Altnt_block__foreign_item_tail_11Context * /*ctx*/) override { }

  virtual void enterAltnt_block__macro_invocation_semi_4(PnfRustParser::Altnt_block__macro_invocation_semi_4Context * /*ctx*/) override { }
  virtual void exitAltnt_block__macro_invocation_semi_4(PnfRustParser::Altnt_block__macro_invocation_semi_4Context * /*ctx*/) override { }

  virtual void enterAltnt_block__type_parameters_4(PnfRustParser::Altnt_block__type_parameters_4Context * /*ctx*/) override { }
  virtual void exitAltnt_block__type_parameters_4(PnfRustParser::Altnt_block__type_parameters_4Context * /*ctx*/) override { }

  virtual void enterAltnt_block__trait_method_param_6(PnfRustParser::Altnt_block__trait_method_param_6Context * /*ctx*/) override { }
  virtual void exitAltnt_block__trait_method_param_6(PnfRustParser::Altnt_block__trait_method_param_6Context * /*ctx*/) override { }

  virtual void enterAltnt_block__struct_tail_6(PnfRustParser::Altnt_block__struct_tail_6Context * /*ctx*/) override { }
  virtual void exitAltnt_block__struct_tail_6(PnfRustParser::Altnt_block__struct_tail_6Context * /*ctx*/) override { }

  virtual void enterAltnt_block__enum_variant_main_5(PnfRustParser::Altnt_block__enum_variant_main_5Context * /*ctx*/) override { }
  virtual void exitAltnt_block__enum_variant_main_5(PnfRustParser::Altnt_block__enum_variant_main_5Context * /*ctx*/) override { }

  virtual void enterAltnt_block__trait_item_19(PnfRustParser::Altnt_block__trait_item_19Context * /*ctx*/) override { }
  virtual void exitAltnt_block__trait_item_19(PnfRustParser::Altnt_block__trait_item_19Context * /*ctx*/) override { }

  virtual void enterAltnt_block__impl_what_3(PnfRustParser::Altnt_block__impl_what_3Context * /*ctx*/) override { }
  virtual void exitAltnt_block__impl_what_3(PnfRustParser::Altnt_block__impl_what_3Context * /*ctx*/) override { }

  virtual void enterAltnt_block__type_arguments_9(PnfRustParser::Altnt_block__type_arguments_9Context * /*ctx*/) override { }
  virtual void exitAltnt_block__type_arguments_9(PnfRustParser::Altnt_block__type_arguments_9Context * /*ctx*/) override { }

  virtual void enterAltnt_block__impl_item_tail_13(PnfRustParser::Altnt_block__impl_item_tail_13Context * /*ctx*/) override { }
  virtual void exitAltnt_block__impl_item_tail_13(PnfRustParser::Altnt_block__impl_item_tail_13Context * /*ctx*/) override { }

  virtual void enterAltnt_block__pattern_without_mut_25(PnfRustParser::Altnt_block__pattern_without_mut_25Context * /*ctx*/) override { }
  virtual void exitAltnt_block__pattern_without_mut_25(PnfRustParser::Altnt_block__pattern_without_mut_25Context * /*ctx*/) override { }

  virtual void enterAltnt_block__pattern_without_mut_26(PnfRustParser::Altnt_block__pattern_without_mut_26Context * /*ctx*/) override { }
  virtual void exitAltnt_block__pattern_without_mut_26(PnfRustParser::Altnt_block__pattern_without_mut_26Context * /*ctx*/) override { }

  virtual void enterAltnt_block__pattern_without_mut_27(PnfRustParser::Altnt_block__pattern_without_mut_27Context * /*ctx*/) override { }
  virtual void exitAltnt_block__pattern_without_mut_27(PnfRustParser::Altnt_block__pattern_without_mut_27Context * /*ctx*/) override { }

  virtual void enterAltnt_block__pattern_without_mut_28(PnfRustParser::Altnt_block__pattern_without_mut_28Context * /*ctx*/) override { }
  virtual void exitAltnt_block__pattern_without_mut_28(PnfRustParser::Altnt_block__pattern_without_mut_28Context * /*ctx*/) override { }

  virtual void enterAltnt_block__pattern_without_mut_29(PnfRustParser::Altnt_block__pattern_without_mut_29Context * /*ctx*/) override { }
  virtual void exitAltnt_block__pattern_without_mut_29(PnfRustParser::Altnt_block__pattern_without_mut_29Context * /*ctx*/) override { }

  virtual void enterAltnt_block__pat_fields_6(PnfRustParser::Altnt_block__pat_fields_6Context * /*ctx*/) override { }
  virtual void exitAltnt_block__pat_fields_6(PnfRustParser::Altnt_block__pat_fields_6Context * /*ctx*/) override { }

  virtual void enterAltnt_block__stmt_8(PnfRustParser::Altnt_block__stmt_8Context * /*ctx*/) override { }
  virtual void exitAltnt_block__stmt_8(PnfRustParser::Altnt_block__stmt_8Context * /*ctx*/) override { }

  virtual void enterAltnt_block__blocky_expr_12(PnfRustParser::Altnt_block__blocky_expr_12Context * /*ctx*/) override { }
  virtual void exitAltnt_block__blocky_expr_12(PnfRustParser::Altnt_block__blocky_expr_12Context * /*ctx*/) override { }

  virtual void enterAltnt_block__if_cond_or_pat_1(PnfRustParser::Altnt_block__if_cond_or_pat_1Context * /*ctx*/) override { }
  virtual void exitAltnt_block__if_cond_or_pat_1(PnfRustParser::Altnt_block__if_cond_or_pat_1Context * /*ctx*/) override { }

  virtual void enterAltnt_block__match_arms_6(PnfRustParser::Altnt_block__match_arms_6Context * /*ctx*/) override { }
  virtual void exitAltnt_block__match_arms_6(PnfRustParser::Altnt_block__match_arms_6Context * /*ctx*/) override { }

  virtual void enterAltnt_block__prim_expr_no_struct_18(PnfRustParser::Altnt_block__prim_expr_no_struct_18Context * /*ctx*/) override { }
  virtual void exitAltnt_block__prim_expr_no_struct_18(PnfRustParser::Altnt_block__prim_expr_no_struct_18Context * /*ctx*/) override { }

  virtual void enterAltnt_block__prim_expr_no_struct_19(PnfRustParser::Altnt_block__prim_expr_no_struct_19Context * /*ctx*/) override { }
  virtual void exitAltnt_block__prim_expr_no_struct_19(PnfRustParser::Altnt_block__prim_expr_no_struct_19Context * /*ctx*/) override { }

  virtual void enterAltnt_block__post_expr_tail_7(PnfRustParser::Altnt_block__post_expr_tail_7Context * /*ctx*/) override { }
  virtual void exitAltnt_block__post_expr_tail_7(PnfRustParser::Altnt_block__post_expr_tail_7Context * /*ctx*/) override { }

  virtual void enterAltnt_block__pre_expr_3(PnfRustParser::Altnt_block__pre_expr_3Context * /*ctx*/) override { }
  virtual void exitAltnt_block__pre_expr_3(PnfRustParser::Altnt_block__pre_expr_3Context * /*ctx*/) override { }

  virtual void enterAltnt_block__cast_expr_3(PnfRustParser::Altnt_block__cast_expr_3Context * /*ctx*/) override { }
  virtual void exitAltnt_block__cast_expr_3(PnfRustParser::Altnt_block__cast_expr_3Context * /*ctx*/) override { }

  virtual void enterAltnt_block__mul_expr_3(PnfRustParser::Altnt_block__mul_expr_3Context * /*ctx*/) override { }
  virtual void exitAltnt_block__mul_expr_3(PnfRustParser::Altnt_block__mul_expr_3Context * /*ctx*/) override { }

  virtual void enterAltnt_block__add_expr_3(PnfRustParser::Altnt_block__add_expr_3Context * /*ctx*/) override { }
  virtual void exitAltnt_block__add_expr_3(PnfRustParser::Altnt_block__add_expr_3Context * /*ctx*/) override { }

  virtual void enterAltnt_block__shift_expr_3(PnfRustParser::Altnt_block__shift_expr_3Context * /*ctx*/) override { }
  virtual void exitAltnt_block__shift_expr_3(PnfRustParser::Altnt_block__shift_expr_3Context * /*ctx*/) override { }

  virtual void enterAltnt_block__range_expr_7(PnfRustParser::Altnt_block__range_expr_7Context * /*ctx*/) override { }
  virtual void exitAltnt_block__range_expr_7(PnfRustParser::Altnt_block__range_expr_7Context * /*ctx*/) override { }

  virtual void enterAltnt_block__range_expr_no_struct_7(PnfRustParser::Altnt_block__range_expr_no_struct_7Context * /*ctx*/) override { }
  virtual void exitAltnt_block__range_expr_no_struct_7(PnfRustParser::Altnt_block__range_expr_no_struct_7Context * /*ctx*/) override { }

  virtual void enterAltnt_block__macro_rules_def_4(PnfRustParser::Altnt_block__macro_rules_def_4Context * /*ctx*/) override { }
  virtual void exitAltnt_block__macro_rules_def_4(PnfRustParser::Altnt_block__macro_rules_def_4Context * /*ctx*/) override { }

  virtual void enterAltnt_block__macro_match_3(PnfRustParser::Altnt_block__macro_match_3Context * /*ctx*/) override { }
  virtual void exitAltnt_block__macro_match_3(PnfRustParser::Altnt_block__macro_match_3Context * /*ctx*/) override { }

  virtual void enterAltnt_block__macro_invocation_semi_5(PnfRustParser::Altnt_block__macro_invocation_semi_5Context * /*ctx*/) override { }
  virtual void exitAltnt_block__macro_invocation_semi_5(PnfRustParser::Altnt_block__macro_invocation_semi_5Context * /*ctx*/) override { }

  virtual void enterType(PnfRustParser::TypeContext * /*ctx*/) override { }
  virtual void exitType(PnfRustParser::TypeContext * /*ctx*/) override { }

  virtual void enterAltnt_block__extern_crate_2(PnfRustParser::Altnt_block__extern_crate_2Context * /*ctx*/) override { }
  virtual void exitAltnt_block__extern_crate_2(PnfRustParser::Altnt_block__extern_crate_2Context * /*ctx*/) override { }

  virtual void enterAltnt_block__use_path_7(PnfRustParser::Altnt_block__use_path_7Context * /*ctx*/) override { }
  virtual void exitAltnt_block__use_path_7(PnfRustParser::Altnt_block__use_path_7Context * /*ctx*/) override { }

  virtual void enterAltnt_block__use_item_2(PnfRustParser::Altnt_block__use_item_2Context * /*ctx*/) override { }
  virtual void exitAltnt_block__use_item_2(PnfRustParser::Altnt_block__use_item_2Context * /*ctx*/) override { }

  virtual void enterAltnt_block__const_decl_2(PnfRustParser::Altnt_block__const_decl_2Context * /*ctx*/) override { }
  virtual void exitAltnt_block__const_decl_2(PnfRustParser::Altnt_block__const_decl_2Context * /*ctx*/) override { }

  virtual void enterAltnt_block__fn_decl_4(PnfRustParser::Altnt_block__fn_decl_4Context * /*ctx*/) override { }
  virtual void exitAltnt_block__fn_decl_4(PnfRustParser::Altnt_block__fn_decl_4Context * /*ctx*/) override { }

  virtual void enterAltnt_block__method_param_list_4(PnfRustParser::Altnt_block__method_param_list_4Context * /*ctx*/) override { }
  virtual void exitAltnt_block__method_param_list_4(PnfRustParser::Altnt_block__method_param_list_4Context * /*ctx*/) override { }

  virtual void enterAltnt_block__restricted_pat_4(PnfRustParser::Altnt_block__restricted_pat_4Context * /*ctx*/) override { }
  virtual void exitAltnt_block__restricted_pat_4(PnfRustParser::Altnt_block__restricted_pat_4Context * /*ctx*/) override { }

  virtual void enterAltnt_block__trait_method_param_list_5(PnfRustParser::Altnt_block__trait_method_param_list_5Context * /*ctx*/) override { }
  virtual void exitAltnt_block__trait_method_param_list_5(PnfRustParser::Altnt_block__trait_method_param_list_5Context * /*ctx*/) override { }

  virtual void enterAltnt_block__fn_rtype_1(PnfRustParser::Altnt_block__fn_rtype_1Context * /*ctx*/) override { }
  virtual void exitAltnt_block__fn_rtype_1(PnfRustParser::Altnt_block__fn_rtype_1Context * /*ctx*/) override { }

  virtual void enterAltnt_block__trait_alias_3(PnfRustParser::Altnt_block__trait_alias_3Context * /*ctx*/) override { }
  virtual void exitAltnt_block__trait_alias_3(PnfRustParser::Altnt_block__trait_alias_3Context * /*ctx*/) override { }

  virtual void enterAltnt_block__trait_item_20(PnfRustParser::Altnt_block__trait_item_20Context * /*ctx*/) override { }
  virtual void exitAltnt_block__trait_item_20(PnfRustParser::Altnt_block__trait_item_20Context * /*ctx*/) override { }

  virtual void enterAltnt_block__ty_path_tail_3(PnfRustParser::Altnt_block__ty_path_tail_3Context * /*ctx*/) override { }
  virtual void exitAltnt_block__ty_path_tail_3(PnfRustParser::Altnt_block__ty_path_tail_3Context * /*ctx*/) override { }

  virtual void enterAltnt_block__pat_fields_7(PnfRustParser::Altnt_block__pat_fields_7Context * /*ctx*/) override { }
  virtual void exitAltnt_block__pat_fields_7(PnfRustParser::Altnt_block__pat_fields_7Context * /*ctx*/) override { }

  virtual void enterAltnt_block__prim_expr_no_struct_20(PnfRustParser::Altnt_block__prim_expr_no_struct_20Context * /*ctx*/) override { }
  virtual void exitAltnt_block__prim_expr_no_struct_20(PnfRustParser::Altnt_block__prim_expr_no_struct_20Context * /*ctx*/) override { }

  virtual void enterAltnt_block__fields_4(PnfRustParser::Altnt_block__fields_4Context * /*ctx*/) override { }
  virtual void exitAltnt_block__fields_4(PnfRustParser::Altnt_block__fields_4Context * /*ctx*/) override { }

  virtual void enterAltnt_block__type_arguments_10(PnfRustParser::Altnt_block__type_arguments_10Context * /*ctx*/) override { }
  virtual void exitAltnt_block__type_arguments_10(PnfRustParser::Altnt_block__type_arguments_10Context * /*ctx*/) override { }

  virtual void enterAltnt_block__assign_expr_3(PnfRustParser::Altnt_block__assign_expr_3Context * /*ctx*/) override { }
  virtual void exitAltnt_block__assign_expr_3(PnfRustParser::Altnt_block__assign_expr_3Context * /*ctx*/) override { }

  virtual void enterAltnt_block__assign_expr_no_struct_3(PnfRustParser::Altnt_block__assign_expr_no_struct_3Context * /*ctx*/) override { }
  virtual void exitAltnt_block__assign_expr_no_struct_3(PnfRustParser::Altnt_block__assign_expr_no_struct_3Context * /*ctx*/) override { }

  virtual void enterAltnt_block__cmp_expr_3(PnfRustParser::Altnt_block__cmp_expr_3Context * /*ctx*/) override { }
  virtual void exitAltnt_block__cmp_expr_3(PnfRustParser::Altnt_block__cmp_expr_3Context * /*ctx*/) override { }

  virtual void enterAltnt_block__cmp_expr_no_struct_7(PnfRustParser::Altnt_block__cmp_expr_no_struct_7Context * /*ctx*/) override { }
  virtual void exitAltnt_block__cmp_expr_no_struct_7(PnfRustParser::Altnt_block__cmp_expr_no_struct_7Context * /*ctx*/) override { }

  virtual void enterAltnt_block__trait_method_param_7(PnfRustParser::Altnt_block__trait_method_param_7Context * /*ctx*/) override { }
  virtual void exitAltnt_block__trait_method_param_7(PnfRustParser::Altnt_block__trait_method_param_7Context * /*ctx*/) override { }

  virtual void enterAux_rule__trait_method_param_8(PnfRustParser::Aux_rule__trait_method_param_8Context * /*ctx*/) override { }
  virtual void exitAux_rule__trait_method_param_8(PnfRustParser::Aux_rule__trait_method_param_8Context * /*ctx*/) override { }

  virtual void enterOptional__trait_method_param_9(PnfRustParser::Optional__trait_method_param_9Context * /*ctx*/) override { }
  virtual void exitOptional__trait_method_param_9(PnfRustParser::Optional__trait_method_param_9Context * /*ctx*/) override { }

  virtual void enterAux_rule__struct_tail_7(PnfRustParser::Aux_rule__struct_tail_7Context * /*ctx*/) override { }
  virtual void exitAux_rule__struct_tail_7(PnfRustParser::Aux_rule__struct_tail_7Context * /*ctx*/) override { }

  virtual void enterOptional__struct_tail_8(PnfRustParser::Optional__struct_tail_8Context * /*ctx*/) override { }
  virtual void exitOptional__struct_tail_8(PnfRustParser::Optional__struct_tail_8Context * /*ctx*/) override { }

  virtual void enterAux_rule__assign_expr_no_struct_4(PnfRustParser::Aux_rule__assign_expr_no_struct_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__assign_expr_no_struct_4(PnfRustParser::Aux_rule__assign_expr_no_struct_4Context * /*ctx*/) override { }

  virtual void enterOptional__assign_expr_no_struct_5(PnfRustParser::Optional__assign_expr_no_struct_5Context * /*ctx*/) override { }
  virtual void exitOptional__assign_expr_no_struct_5(PnfRustParser::Optional__assign_expr_no_struct_5Context * /*ctx*/) override { }

  virtual void enterAux_rule__blocky_expr_13(PnfRustParser::Aux_rule__blocky_expr_13Context * /*ctx*/) override { }
  virtual void exitAux_rule__blocky_expr_13(PnfRustParser::Aux_rule__blocky_expr_13Context * /*ctx*/) override { }

  virtual void enterOptional__blocky_expr_14(PnfRustParser::Optional__blocky_expr_14Context * /*ctx*/) override { }
  virtual void exitOptional__blocky_expr_14(PnfRustParser::Optional__blocky_expr_14Context * /*ctx*/) override { }

  virtual void enterOptional__cmp_expr_no_struct_8(PnfRustParser::Optional__cmp_expr_no_struct_8Context * /*ctx*/) override { }
  virtual void exitOptional__cmp_expr_no_struct_8(PnfRustParser::Optional__cmp_expr_no_struct_8Context * /*ctx*/) override { }

  virtual void enterAltnt_block__type_decl_11(PnfRustParser::Altnt_block__type_decl_11Context * /*ctx*/) override { }
  virtual void exitAltnt_block__type_decl_11(PnfRustParser::Altnt_block__type_decl_11Context * /*ctx*/) override { }

  virtual void enterAltnt_block__use_path_8(PnfRustParser::Altnt_block__use_path_8Context * /*ctx*/) override { }
  virtual void exitAltnt_block__use_path_8(PnfRustParser::Altnt_block__use_path_8Context * /*ctx*/) override { }

  virtual void enterAltnt_block__foreign_item_4(PnfRustParser::Altnt_block__foreign_item_4Context * /*ctx*/) override { }
  virtual void exitAltnt_block__foreign_item_4(PnfRustParser::Altnt_block__foreign_item_4Context * /*ctx*/) override { }

  virtual void enterAltnt_block__param_12(PnfRustParser::Altnt_block__param_12Context * /*ctx*/) override { }
  virtual void exitAltnt_block__param_12(PnfRustParser::Altnt_block__param_12Context * /*ctx*/) override { }

  virtual void enterAltnt_block__trait_item_21(PnfRustParser::Altnt_block__trait_item_21Context * /*ctx*/) override { }
  virtual void exitAltnt_block__trait_item_21(PnfRustParser::Altnt_block__trait_item_21Context * /*ctx*/) override { }

  virtual void enterAltnt_block__trait_item_22(PnfRustParser::Altnt_block__trait_item_22Context * /*ctx*/) override { }
  virtual void exitAltnt_block__trait_item_22(PnfRustParser::Altnt_block__trait_item_22Context * /*ctx*/) override { }

  virtual void enterAltnt_block__type_arguments_11(PnfRustParser::Altnt_block__type_arguments_11Context * /*ctx*/) override { }
  virtual void exitAltnt_block__type_arguments_11(PnfRustParser::Altnt_block__type_arguments_11Context * /*ctx*/) override { }

  virtual void enterAltnt_block__pattern_without_mut_31(PnfRustParser::Altnt_block__pattern_without_mut_31Context * /*ctx*/) override { }
  virtual void exitAltnt_block__pattern_without_mut_31(PnfRustParser::Altnt_block__pattern_without_mut_31Context * /*ctx*/) override { }

  virtual void enterAltnt_block__pat_field_6(PnfRustParser::Altnt_block__pat_field_6Context * /*ctx*/) override { }
  virtual void exitAltnt_block__pat_field_6(PnfRustParser::Altnt_block__pat_field_6Context * /*ctx*/) override { }

  virtual void enterAltnt_block__blocky_expr_15(PnfRustParser::Altnt_block__blocky_expr_15Context * /*ctx*/) override { }
  virtual void exitAltnt_block__blocky_expr_15(PnfRustParser::Altnt_block__blocky_expr_15Context * /*ctx*/) override { }

  virtual void enterAltnt_block__prim_expr_no_struct_22(PnfRustParser::Altnt_block__prim_expr_no_struct_22Context * /*ctx*/) override { }
  virtual void exitAltnt_block__prim_expr_no_struct_22(PnfRustParser::Altnt_block__prim_expr_no_struct_22Context * /*ctx*/) override { }

  virtual void enterAltnt_block__prim_expr_no_struct_23(PnfRustParser::Altnt_block__prim_expr_no_struct_23Context * /*ctx*/) override { }
  virtual void exitAltnt_block__prim_expr_no_struct_23(PnfRustParser::Altnt_block__prim_expr_no_struct_23Context * /*ctx*/) override { }

  virtual void enterAltnt_block__prim_expr_no_struct_24(PnfRustParser::Altnt_block__prim_expr_no_struct_24Context * /*ctx*/) override { }
  virtual void exitAltnt_block__prim_expr_no_struct_24(PnfRustParser::Altnt_block__prim_expr_no_struct_24Context * /*ctx*/) override { }

  virtual void enterAltnt_block__range_expr_8(PnfRustParser::Altnt_block__range_expr_8Context * /*ctx*/) override { }
  virtual void exitAltnt_block__range_expr_8(PnfRustParser::Altnt_block__range_expr_8Context * /*ctx*/) override { }

  virtual void enterAltnt_block__item_7(PnfRustParser::Altnt_block__item_7Context * /*ctx*/) override { }
  virtual void exitAltnt_block__item_7(PnfRustParser::Altnt_block__item_7Context * /*ctx*/) override { }

  virtual void enterAltnt_block__param_11(PnfRustParser::Altnt_block__param_11Context * /*ctx*/) override { }
  virtual void exitAltnt_block__param_11(PnfRustParser::Altnt_block__param_11Context * /*ctx*/) override { }

  virtual void enterAltnt_block__ty_path_segment_no_super_6(PnfRustParser::Altnt_block__ty_path_segment_no_super_6Context * /*ctx*/) override { }
  virtual void exitAltnt_block__ty_path_segment_no_super_6(PnfRustParser::Altnt_block__ty_path_segment_no_super_6Context * /*ctx*/) override { }

  virtual void enterAux_rule__post_expr_2(PnfRustParser::Aux_rule__post_expr_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__post_expr_2(PnfRustParser::Aux_rule__post_expr_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__visibility_2(PnfRustParser::Aux_rule__visibility_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__visibility_2(PnfRustParser::Aux_rule__visibility_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__use_suffix_3(PnfRustParser::Aux_rule__use_suffix_3Context * /*ctx*/) override { }
  virtual void exitAux_rule__use_suffix_3(PnfRustParser::Aux_rule__use_suffix_3Context * /*ctx*/) override { }

  virtual void enterAux_rule__foreign_item_tail_12(PnfRustParser::Aux_rule__foreign_item_tail_12Context * /*ctx*/) override { }
  virtual void exitAux_rule__foreign_item_tail_12(PnfRustParser::Aux_rule__foreign_item_tail_12Context * /*ctx*/) override { }

  virtual void enterAux_rule__param_13(PnfRustParser::Aux_rule__param_13Context * /*ctx*/) override { }
  virtual void exitAux_rule__param_13(PnfRustParser::Aux_rule__param_13Context * /*ctx*/) override { }

  virtual void enterAux_rule__self_param_6(PnfRustParser::Aux_rule__self_param_6Context * /*ctx*/) override { }
  virtual void exitAux_rule__self_param_6(PnfRustParser::Aux_rule__self_param_6Context * /*ctx*/) override { }

  virtual void enterAux_rule__self_param_7(PnfRustParser::Aux_rule__self_param_7Context * /*ctx*/) override { }
  virtual void exitAux_rule__self_param_7(PnfRustParser::Aux_rule__self_param_7Context * /*ctx*/) override { }

  virtual void enterAux_rule__trait_method_param_10(PnfRustParser::Aux_rule__trait_method_param_10Context * /*ctx*/) override { }
  virtual void exitAux_rule__trait_method_param_10(PnfRustParser::Aux_rule__trait_method_param_10Context * /*ctx*/) override { }

  virtual void enterAux_rule__struct_tail_9(PnfRustParser::Aux_rule__struct_tail_9Context * /*ctx*/) override { }
  virtual void exitAux_rule__struct_tail_9(PnfRustParser::Aux_rule__struct_tail_9Context * /*ctx*/) override { }

  virtual void enterAux_rule__struct_tail_10(PnfRustParser::Aux_rule__struct_tail_10Context * /*ctx*/) override { }
  virtual void exitAux_rule__struct_tail_10(PnfRustParser::Aux_rule__struct_tail_10Context * /*ctx*/) override { }

  virtual void enterAux_rule__trait_item_23(PnfRustParser::Aux_rule__trait_item_23Context * /*ctx*/) override { }
  virtual void exitAux_rule__trait_item_23(PnfRustParser::Aux_rule__trait_item_23Context * /*ctx*/) override { }

  virtual void enterAux_rule__trait_item_24(PnfRustParser::Aux_rule__trait_item_24Context * /*ctx*/) override { }
  virtual void exitAux_rule__trait_item_24(PnfRustParser::Aux_rule__trait_item_24Context * /*ctx*/) override { }

  virtual void enterAux_rule__trait_item_25(PnfRustParser::Aux_rule__trait_item_25Context * /*ctx*/) override { }
  virtual void exitAux_rule__trait_item_25(PnfRustParser::Aux_rule__trait_item_25Context * /*ctx*/) override { }

  virtual void enterAux_rule__impl_what_4(PnfRustParser::Aux_rule__impl_what_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__impl_what_4(PnfRustParser::Aux_rule__impl_what_4Context * /*ctx*/) override { }

  virtual void enterAux_rule__impl_what_5(PnfRustParser::Aux_rule__impl_what_5Context * /*ctx*/) override { }
  virtual void exitAux_rule__impl_what_5(PnfRustParser::Aux_rule__impl_what_5Context * /*ctx*/) override { }

  virtual void enterAux_rule__impl_what_6(PnfRustParser::Aux_rule__impl_what_6Context * /*ctx*/) override { }
  virtual void exitAux_rule__impl_what_6(PnfRustParser::Aux_rule__impl_what_6Context * /*ctx*/) override { }

  virtual void enterAux_rule__impl_item_tail_14(PnfRustParser::Aux_rule__impl_item_tail_14Context * /*ctx*/) override { }
  virtual void exitAux_rule__impl_item_tail_14(PnfRustParser::Aux_rule__impl_item_tail_14Context * /*ctx*/) override { }

  virtual void enterAux_rule__impl_item_tail_15(PnfRustParser::Aux_rule__impl_item_tail_15Context * /*ctx*/) override { }
  virtual void exitAux_rule__impl_item_tail_15(PnfRustParser::Aux_rule__impl_item_tail_15Context * /*ctx*/) override { }

  virtual void enterAux_rule__tt_1(PnfRustParser::Aux_rule__tt_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__tt_1(PnfRustParser::Aux_rule__tt_1Context * /*ctx*/) override { }

  virtual void enterAux_rule__ty_path_tail_4(PnfRustParser::Aux_rule__ty_path_tail_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__ty_path_tail_4(PnfRustParser::Aux_rule__ty_path_tail_4Context * /*ctx*/) override { }

  virtual void enterAux_rule__where_bound_3(PnfRustParser::Aux_rule__where_bound_3Context * /*ctx*/) override { }
  virtual void exitAux_rule__where_bound_3(PnfRustParser::Aux_rule__where_bound_3Context * /*ctx*/) override { }

  virtual void enterAux_rule__where_bound_4(PnfRustParser::Aux_rule__where_bound_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__where_bound_4(PnfRustParser::Aux_rule__where_bound_4Context * /*ctx*/) override { }

  virtual void enterAux_rule__trait_bound_5(PnfRustParser::Aux_rule__trait_bound_5Context * /*ctx*/) override { }
  virtual void exitAux_rule__trait_bound_5(PnfRustParser::Aux_rule__trait_bound_5Context * /*ctx*/) override { }

  virtual void enterAux_rule__trait_bound_6(PnfRustParser::Aux_rule__trait_bound_6Context * /*ctx*/) override { }
  virtual void exitAux_rule__trait_bound_6(PnfRustParser::Aux_rule__trait_bound_6Context * /*ctx*/) override { }

  virtual void enterAux_rule__type_argument_3(PnfRustParser::Aux_rule__type_argument_3Context * /*ctx*/) override { }
  virtual void exitAux_rule__type_argument_3(PnfRustParser::Aux_rule__type_argument_3Context * /*ctx*/) override { }

  virtual void enterAux_rule__type_parameter_5(PnfRustParser::Aux_rule__type_parameter_5Context * /*ctx*/) override { }
  virtual void exitAux_rule__type_parameter_5(PnfRustParser::Aux_rule__type_parameter_5Context * /*ctx*/) override { }

  virtual void enterAux_rule__pattern_3(PnfRustParser::Aux_rule__pattern_3Context * /*ctx*/) override { }
  virtual void exitAux_rule__pattern_3(PnfRustParser::Aux_rule__pattern_3Context * /*ctx*/) override { }

  virtual void enterAux_rule__pat_ident_1(PnfRustParser::Aux_rule__pat_ident_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__pat_ident_1(PnfRustParser::Aux_rule__pat_ident_1Context * /*ctx*/) override { }

  virtual void enterAux_rule__pat_list_with_dots_6(PnfRustParser::Aux_rule__pat_list_with_dots_6Context * /*ctx*/) override { }
  virtual void exitAux_rule__pat_list_with_dots_6(PnfRustParser::Aux_rule__pat_list_with_dots_6Context * /*ctx*/) override { }

  virtual void enterAux_rule__pat_fields_8(PnfRustParser::Aux_rule__pat_fields_8Context * /*ctx*/) override { }
  virtual void exitAux_rule__pat_fields_8(PnfRustParser::Aux_rule__pat_fields_8Context * /*ctx*/) override { }

  virtual void enterAux_rule__pat_fields_9(PnfRustParser::Aux_rule__pat_fields_9Context * /*ctx*/) override { }
  virtual void exitAux_rule__pat_fields_9(PnfRustParser::Aux_rule__pat_fields_9Context * /*ctx*/) override { }

  virtual void enterAux_rule__stmt_9(PnfRustParser::Aux_rule__stmt_9Context * /*ctx*/) override { }
  virtual void exitAux_rule__stmt_9(PnfRustParser::Aux_rule__stmt_9Context * /*ctx*/) override { }

  virtual void enterAux_rule__stmt_10(PnfRustParser::Aux_rule__stmt_10Context * /*ctx*/) override { }
  virtual void exitAux_rule__stmt_10(PnfRustParser::Aux_rule__stmt_10Context * /*ctx*/) override { }

  virtual void enterAux_rule__blocky_expr_16(PnfRustParser::Aux_rule__blocky_expr_16Context * /*ctx*/) override { }
  virtual void exitAux_rule__blocky_expr_16(PnfRustParser::Aux_rule__blocky_expr_16Context * /*ctx*/) override { }

  virtual void enterAux_rule__blocky_expr_17(PnfRustParser::Aux_rule__blocky_expr_17Context * /*ctx*/) override { }
  virtual void exitAux_rule__blocky_expr_17(PnfRustParser::Aux_rule__blocky_expr_17Context * /*ctx*/) override { }

  virtual void enterAux_rule__blocky_expr_18(PnfRustParser::Aux_rule__blocky_expr_18Context * /*ctx*/) override { }
  virtual void exitAux_rule__blocky_expr_18(PnfRustParser::Aux_rule__blocky_expr_18Context * /*ctx*/) override { }

  virtual void enterAux_rule__prim_expr_3(PnfRustParser::Aux_rule__prim_expr_3Context * /*ctx*/) override { }
  virtual void exitAux_rule__prim_expr_3(PnfRustParser::Aux_rule__prim_expr_3Context * /*ctx*/) override { }

  virtual void enterAux_rule__prim_expr_no_struct_25(PnfRustParser::Aux_rule__prim_expr_no_struct_25Context * /*ctx*/) override { }
  virtual void exitAux_rule__prim_expr_no_struct_25(PnfRustParser::Aux_rule__prim_expr_no_struct_25Context * /*ctx*/) override { }

  virtual void enterAux_rule__prim_expr_no_struct_26(PnfRustParser::Aux_rule__prim_expr_no_struct_26Context * /*ctx*/) override { }
  virtual void exitAux_rule__prim_expr_no_struct_26(PnfRustParser::Aux_rule__prim_expr_no_struct_26Context * /*ctx*/) override { }

  virtual void enterAux_rule__prim_expr_no_struct_27(PnfRustParser::Aux_rule__prim_expr_no_struct_27Context * /*ctx*/) override { }
  virtual void exitAux_rule__prim_expr_no_struct_27(PnfRustParser::Aux_rule__prim_expr_no_struct_27Context * /*ctx*/) override { }

  virtual void enterAux_rule__prim_expr_no_struct_28(PnfRustParser::Aux_rule__prim_expr_no_struct_28Context * /*ctx*/) override { }
  virtual void exitAux_rule__prim_expr_no_struct_28(PnfRustParser::Aux_rule__prim_expr_no_struct_28Context * /*ctx*/) override { }

  virtual void enterAux_rule__prim_expr_no_struct_29(PnfRustParser::Aux_rule__prim_expr_no_struct_29Context * /*ctx*/) override { }
  virtual void exitAux_rule__prim_expr_no_struct_29(PnfRustParser::Aux_rule__prim_expr_no_struct_29Context * /*ctx*/) override { }

  virtual void enterAux_rule__prim_expr_no_struct_30(PnfRustParser::Aux_rule__prim_expr_no_struct_30Context * /*ctx*/) override { }
  virtual void exitAux_rule__prim_expr_no_struct_30(PnfRustParser::Aux_rule__prim_expr_no_struct_30Context * /*ctx*/) override { }

  virtual void enterAux_rule__prim_expr_no_struct_31(PnfRustParser::Aux_rule__prim_expr_no_struct_31Context * /*ctx*/) override { }
  virtual void exitAux_rule__prim_expr_no_struct_31(PnfRustParser::Aux_rule__prim_expr_no_struct_31Context * /*ctx*/) override { }

  virtual void enterAux_rule__closure_params_3(PnfRustParser::Aux_rule__closure_params_3Context * /*ctx*/) override { }
  virtual void exitAux_rule__closure_params_3(PnfRustParser::Aux_rule__closure_params_3Context * /*ctx*/) override { }

  virtual void enterAux_rule__closure_tail_2(PnfRustParser::Aux_rule__closure_tail_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__closure_tail_2(PnfRustParser::Aux_rule__closure_tail_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__fields_5(PnfRustParser::Aux_rule__fields_5Context * /*ctx*/) override { }
  virtual void exitAux_rule__fields_5(PnfRustParser::Aux_rule__fields_5Context * /*ctx*/) override { }

  virtual void enterAux_rule__field_2(PnfRustParser::Aux_rule__field_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__field_2(PnfRustParser::Aux_rule__field_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__pre_expr_5(PnfRustParser::Aux_rule__pre_expr_5Context * /*ctx*/) override { }
  virtual void exitAux_rule__pre_expr_5(PnfRustParser::Aux_rule__pre_expr_5Context * /*ctx*/) override { }

  virtual void enterAux_rule__pre_expr_6(PnfRustParser::Aux_rule__pre_expr_6Context * /*ctx*/) override { }
  virtual void exitAux_rule__pre_expr_6(PnfRustParser::Aux_rule__pre_expr_6Context * /*ctx*/) override { }

  virtual void enterAux_rule__range_expr_9(PnfRustParser::Aux_rule__range_expr_9Context * /*ctx*/) override { }
  virtual void exitAux_rule__range_expr_9(PnfRustParser::Aux_rule__range_expr_9Context * /*ctx*/) override { }

  virtual void enterAux_rule__range_expr_10(PnfRustParser::Aux_rule__range_expr_10Context * /*ctx*/) override { }
  virtual void exitAux_rule__range_expr_10(PnfRustParser::Aux_rule__range_expr_10Context * /*ctx*/) override { }

  virtual void enterAux_rule__pre_expr_no_struct_4(PnfRustParser::Aux_rule__pre_expr_no_struct_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__pre_expr_no_struct_4(PnfRustParser::Aux_rule__pre_expr_no_struct_4Context * /*ctx*/) override { }

  virtual void enterAux_rule__range_expr_no_struct_9(PnfRustParser::Aux_rule__range_expr_no_struct_9Context * /*ctx*/) override { }
  virtual void exitAux_rule__range_expr_no_struct_9(PnfRustParser::Aux_rule__range_expr_no_struct_9Context * /*ctx*/) override { }

  virtual void enterAux_rule__range_expr_no_struct_10(PnfRustParser::Aux_rule__range_expr_no_struct_10Context * /*ctx*/) override { }
  virtual void exitAux_rule__range_expr_no_struct_10(PnfRustParser::Aux_rule__range_expr_no_struct_10Context * /*ctx*/) override { }

  virtual void enterAux_rule__macro_rules_def_5(PnfRustParser::Aux_rule__macro_rules_def_5Context * /*ctx*/) override { }
  virtual void exitAux_rule__macro_rules_def_5(PnfRustParser::Aux_rule__macro_rules_def_5Context * /*ctx*/) override { }

  virtual void enterAux_rule__macro_rules_def_6(PnfRustParser::Aux_rule__macro_rules_def_6Context * /*ctx*/) override { }
  virtual void exitAux_rule__macro_rules_def_6(PnfRustParser::Aux_rule__macro_rules_def_6Context * /*ctx*/) override { }

  virtual void enterAux_rule__macro_matcher_4(PnfRustParser::Aux_rule__macro_matcher_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__macro_matcher_4(PnfRustParser::Aux_rule__macro_matcher_4Context * /*ctx*/) override { }

  virtual void enterAux_rule__macro_matcher_5(PnfRustParser::Aux_rule__macro_matcher_5Context * /*ctx*/) override { }
  virtual void exitAux_rule__macro_matcher_5(PnfRustParser::Aux_rule__macro_matcher_5Context * /*ctx*/) override { }

  virtual void enterAux_rule__macro_matcher_6(PnfRustParser::Aux_rule__macro_matcher_6Context * /*ctx*/) override { }
  virtual void exitAux_rule__macro_matcher_6(PnfRustParser::Aux_rule__macro_matcher_6Context * /*ctx*/) override { }

  virtual void enterAux_rule__macro_match_4(PnfRustParser::Aux_rule__macro_match_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__macro_match_4(PnfRustParser::Aux_rule__macro_match_4Context * /*ctx*/) override { }

  virtual void enterAux_rule__delim_token_tree_4(PnfRustParser::Aux_rule__delim_token_tree_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__delim_token_tree_4(PnfRustParser::Aux_rule__delim_token_tree_4Context * /*ctx*/) override { }

  virtual void enterAux_rule__delim_token_tree_5(PnfRustParser::Aux_rule__delim_token_tree_5Context * /*ctx*/) override { }
  virtual void exitAux_rule__delim_token_tree_5(PnfRustParser::Aux_rule__delim_token_tree_5Context * /*ctx*/) override { }

  virtual void enterAux_rule__delim_token_tree_6(PnfRustParser::Aux_rule__delim_token_tree_6Context * /*ctx*/) override { }
  virtual void exitAux_rule__delim_token_tree_6(PnfRustParser::Aux_rule__delim_token_tree_6Context * /*ctx*/) override { }

  virtual void enterAux_rule__prim_bound_6(PnfRustParser::Aux_rule__prim_bound_6Context * /*ctx*/) override { }
  virtual void exitAux_rule__prim_bound_6(PnfRustParser::Aux_rule__prim_bound_6Context * /*ctx*/) override { }

  virtual void enterAux_rule__bound_5(PnfRustParser::Aux_rule__bound_5Context * /*ctx*/) override { }
  virtual void exitAux_rule__bound_5(PnfRustParser::Aux_rule__bound_5Context * /*ctx*/) override { }

  virtual void enterAux_rule__bound_6(PnfRustParser::Aux_rule__bound_6Context * /*ctx*/) override { }
  virtual void exitAux_rule__bound_6(PnfRustParser::Aux_rule__bound_6Context * /*ctx*/) override { }

  virtual void enterAux_rule__path_parent_6(PnfRustParser::Aux_rule__path_parent_6Context * /*ctx*/) override { }
  virtual void exitAux_rule__path_parent_6(PnfRustParser::Aux_rule__path_parent_6Context * /*ctx*/) override { }

  virtual void enterAux_rule__path_parent_7(PnfRustParser::Aux_rule__path_parent_7Context * /*ctx*/) override { }
  virtual void exitAux_rule__path_parent_7(PnfRustParser::Aux_rule__path_parent_7Context * /*ctx*/) override { }

  virtual void enterAux_rule__ty_path_parent_6(PnfRustParser::Aux_rule__ty_path_parent_6Context * /*ctx*/) override { }
  virtual void exitAux_rule__ty_path_parent_6(PnfRustParser::Aux_rule__ty_path_parent_6Context * /*ctx*/) override { }

  virtual void enterAux_rule__ty_path_parent_7(PnfRustParser::Aux_rule__ty_path_parent_7Context * /*ctx*/) override { }
  virtual void exitAux_rule__ty_path_parent_7(PnfRustParser::Aux_rule__ty_path_parent_7Context * /*ctx*/) override { }

  virtual void enterAux_rule__pattern_without_mut_32(PnfRustParser::Aux_rule__pattern_without_mut_32Context * /*ctx*/) override { }
  virtual void exitAux_rule__pattern_without_mut_32(PnfRustParser::Aux_rule__pattern_without_mut_32Context * /*ctx*/) override { }

  virtual void enterAux_rule__pattern_without_mut_33(PnfRustParser::Aux_rule__pattern_without_mut_33Context * /*ctx*/) override { }
  virtual void exitAux_rule__pattern_without_mut_33(PnfRustParser::Aux_rule__pattern_without_mut_33Context * /*ctx*/) override { }

  virtual void enterAux_rule__pattern_without_mut_34(PnfRustParser::Aux_rule__pattern_without_mut_34Context * /*ctx*/) override { }
  virtual void exitAux_rule__pattern_without_mut_34(PnfRustParser::Aux_rule__pattern_without_mut_34Context * /*ctx*/) override { }

  virtual void enterAux_rule__pattern_without_mut_35(PnfRustParser::Aux_rule__pattern_without_mut_35Context * /*ctx*/) override { }
  virtual void exitAux_rule__pattern_without_mut_35(PnfRustParser::Aux_rule__pattern_without_mut_35Context * /*ctx*/) override { }

  virtual void enterAux_rule__pattern_without_mut_36(PnfRustParser::Aux_rule__pattern_without_mut_36Context * /*ctx*/) override { }
  virtual void exitAux_rule__pattern_without_mut_36(PnfRustParser::Aux_rule__pattern_without_mut_36Context * /*ctx*/) override { }

  virtual void enterAux_rule__pattern_without_mut_37(PnfRustParser::Aux_rule__pattern_without_mut_37Context * /*ctx*/) override { }
  virtual void exitAux_rule__pattern_without_mut_37(PnfRustParser::Aux_rule__pattern_without_mut_37Context * /*ctx*/) override { }

  virtual void enterAux_rule__pattern_without_mut_38(PnfRustParser::Aux_rule__pattern_without_mut_38Context * /*ctx*/) override { }
  virtual void exitAux_rule__pattern_without_mut_38(PnfRustParser::Aux_rule__pattern_without_mut_38Context * /*ctx*/) override { }

  virtual void enterAux_rule__pattern_without_mut_39(PnfRustParser::Aux_rule__pattern_without_mut_39Context * /*ctx*/) override { }
  virtual void exitAux_rule__pattern_without_mut_39(PnfRustParser::Aux_rule__pattern_without_mut_39Context * /*ctx*/) override { }

  virtual void enterAux_rule__pattern_without_mut_40(PnfRustParser::Aux_rule__pattern_without_mut_40Context * /*ctx*/) override { }
  virtual void exitAux_rule__pattern_without_mut_40(PnfRustParser::Aux_rule__pattern_without_mut_40Context * /*ctx*/) override { }

  virtual void enterAux_rule__visibility_restriction_2(PnfRustParser::Aux_rule__visibility_restriction_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__visibility_restriction_2(PnfRustParser::Aux_rule__visibility_restriction_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__use_suffix_4(PnfRustParser::Aux_rule__use_suffix_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__use_suffix_4(PnfRustParser::Aux_rule__use_suffix_4Context * /*ctx*/) override { }

  virtual void enterAux_rule__foreign_item_tail_13(PnfRustParser::Aux_rule__foreign_item_tail_13Context * /*ctx*/) override { }
  virtual void exitAux_rule__foreign_item_tail_13(PnfRustParser::Aux_rule__foreign_item_tail_13Context * /*ctx*/) override { }

  virtual void enterAux_rule__foreign_item_tail_14(PnfRustParser::Aux_rule__foreign_item_tail_14Context * /*ctx*/) override { }
  virtual void exitAux_rule__foreign_item_tail_14(PnfRustParser::Aux_rule__foreign_item_tail_14Context * /*ctx*/) override { }

  virtual void enterAux_rule__macro_invocation_semi_6(PnfRustParser::Aux_rule__macro_invocation_semi_6Context * /*ctx*/) override { }
  virtual void exitAux_rule__macro_invocation_semi_6(PnfRustParser::Aux_rule__macro_invocation_semi_6Context * /*ctx*/) override { }

  virtual void enterAux_rule__macro_invocation_semi_7(PnfRustParser::Aux_rule__macro_invocation_semi_7Context * /*ctx*/) override { }
  virtual void exitAux_rule__macro_invocation_semi_7(PnfRustParser::Aux_rule__macro_invocation_semi_7Context * /*ctx*/) override { }

  virtual void enterAux_rule__type_parameters_5(PnfRustParser::Aux_rule__type_parameters_5Context * /*ctx*/) override { }
  virtual void exitAux_rule__type_parameters_5(PnfRustParser::Aux_rule__type_parameters_5Context * /*ctx*/) override { }

  virtual void enterAux_rule__enum_variant_main_6(PnfRustParser::Aux_rule__enum_variant_main_6Context * /*ctx*/) override { }
  virtual void exitAux_rule__enum_variant_main_6(PnfRustParser::Aux_rule__enum_variant_main_6Context * /*ctx*/) override { }

  virtual void enterAux_rule__enum_variant_main_7(PnfRustParser::Aux_rule__enum_variant_main_7Context * /*ctx*/) override { }
  virtual void exitAux_rule__enum_variant_main_7(PnfRustParser::Aux_rule__enum_variant_main_7Context * /*ctx*/) override { }

  virtual void enterAux_rule__impl_item_tail_16(PnfRustParser::Aux_rule__impl_item_tail_16Context * /*ctx*/) override { }
  virtual void exitAux_rule__impl_item_tail_16(PnfRustParser::Aux_rule__impl_item_tail_16Context * /*ctx*/) override { }

  virtual void enterAux_rule__impl_item_tail_17(PnfRustParser::Aux_rule__impl_item_tail_17Context * /*ctx*/) override { }
  virtual void exitAux_rule__impl_item_tail_17(PnfRustParser::Aux_rule__impl_item_tail_17Context * /*ctx*/) override { }

  virtual void enterAux_rule__pattern_without_mut_41(PnfRustParser::Aux_rule__pattern_without_mut_41Context * /*ctx*/) override { }
  virtual void exitAux_rule__pattern_without_mut_41(PnfRustParser::Aux_rule__pattern_without_mut_41Context * /*ctx*/) override { }

  virtual void enterAux_rule__pattern_without_mut_42(PnfRustParser::Aux_rule__pattern_without_mut_42Context * /*ctx*/) override { }
  virtual void exitAux_rule__pattern_without_mut_42(PnfRustParser::Aux_rule__pattern_without_mut_42Context * /*ctx*/) override { }

  virtual void enterAux_rule__pattern_without_mut_43(PnfRustParser::Aux_rule__pattern_without_mut_43Context * /*ctx*/) override { }
  virtual void exitAux_rule__pattern_without_mut_43(PnfRustParser::Aux_rule__pattern_without_mut_43Context * /*ctx*/) override { }

  virtual void enterAux_rule__pat_fields_10(PnfRustParser::Aux_rule__pat_fields_10Context * /*ctx*/) override { }
  virtual void exitAux_rule__pat_fields_10(PnfRustParser::Aux_rule__pat_fields_10Context * /*ctx*/) override { }

  virtual void enterAux_rule__stmt_11(PnfRustParser::Aux_rule__stmt_11Context * /*ctx*/) override { }
  virtual void exitAux_rule__stmt_11(PnfRustParser::Aux_rule__stmt_11Context * /*ctx*/) override { }

  virtual void enterAux_rule__blocky_expr_19(PnfRustParser::Aux_rule__blocky_expr_19Context * /*ctx*/) override { }
  virtual void exitAux_rule__blocky_expr_19(PnfRustParser::Aux_rule__blocky_expr_19Context * /*ctx*/) override { }

  virtual void enterAux_rule__if_cond_or_pat_2(PnfRustParser::Aux_rule__if_cond_or_pat_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__if_cond_or_pat_2(PnfRustParser::Aux_rule__if_cond_or_pat_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__match_arms_7(PnfRustParser::Aux_rule__match_arms_7Context * /*ctx*/) override { }
  virtual void exitAux_rule__match_arms_7(PnfRustParser::Aux_rule__match_arms_7Context * /*ctx*/) override { }

  virtual void enterAux_rule__match_arms_8(PnfRustParser::Aux_rule__match_arms_8Context * /*ctx*/) override { }
  virtual void exitAux_rule__match_arms_8(PnfRustParser::Aux_rule__match_arms_8Context * /*ctx*/) override { }

  virtual void enterAux_rule__post_expr_tail_8(PnfRustParser::Aux_rule__post_expr_tail_8Context * /*ctx*/) override { }
  virtual void exitAux_rule__post_expr_tail_8(PnfRustParser::Aux_rule__post_expr_tail_8Context * /*ctx*/) override { }

  virtual void enterAux_rule__pre_expr_7(PnfRustParser::Aux_rule__pre_expr_7Context * /*ctx*/) override { }
  virtual void exitAux_rule__pre_expr_7(PnfRustParser::Aux_rule__pre_expr_7Context * /*ctx*/) override { }

  virtual void enterAux_rule__shift_expr_4(PnfRustParser::Aux_rule__shift_expr_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__shift_expr_4(PnfRustParser::Aux_rule__shift_expr_4Context * /*ctx*/) override { }

  virtual void enterAux_rule__shift_expr_5(PnfRustParser::Aux_rule__shift_expr_5Context * /*ctx*/) override { }
  virtual void exitAux_rule__shift_expr_5(PnfRustParser::Aux_rule__shift_expr_5Context * /*ctx*/) override { }

  virtual void enterAux_rule__range_expr_11(PnfRustParser::Aux_rule__range_expr_11Context * /*ctx*/) override { }
  virtual void exitAux_rule__range_expr_11(PnfRustParser::Aux_rule__range_expr_11Context * /*ctx*/) override { }

  virtual void enterAux_rule__range_expr_no_struct_11(PnfRustParser::Aux_rule__range_expr_no_struct_11Context * /*ctx*/) override { }
  virtual void exitAux_rule__range_expr_no_struct_11(PnfRustParser::Aux_rule__range_expr_no_struct_11Context * /*ctx*/) override { }

  virtual void enterAux_rule__macro_rules_def_7(PnfRustParser::Aux_rule__macro_rules_def_7Context * /*ctx*/) override { }
  virtual void exitAux_rule__macro_rules_def_7(PnfRustParser::Aux_rule__macro_rules_def_7Context * /*ctx*/) override { }

  virtual void enterAux_rule__macro_rules_def_8(PnfRustParser::Aux_rule__macro_rules_def_8Context * /*ctx*/) override { }
  virtual void exitAux_rule__macro_rules_def_8(PnfRustParser::Aux_rule__macro_rules_def_8Context * /*ctx*/) override { }

  virtual void enterAux_rule__macro_match_5(PnfRustParser::Aux_rule__macro_match_5Context * /*ctx*/) override { }
  virtual void exitAux_rule__macro_match_5(PnfRustParser::Aux_rule__macro_match_5Context * /*ctx*/) override { }

  virtual void enterAux_rule__macro_match_6(PnfRustParser::Aux_rule__macro_match_6Context * /*ctx*/) override { }
  virtual void exitAux_rule__macro_match_6(PnfRustParser::Aux_rule__macro_match_6Context * /*ctx*/) override { }

  virtual void enterAux_rule__macro_invocation_semi_8(PnfRustParser::Aux_rule__macro_invocation_semi_8Context * /*ctx*/) override { }
  virtual void exitAux_rule__macro_invocation_semi_8(PnfRustParser::Aux_rule__macro_invocation_semi_8Context * /*ctx*/) override { }

  virtual void enterAux_rule__macro_invocation_semi_9(PnfRustParser::Aux_rule__macro_invocation_semi_9Context * /*ctx*/) override { }
  virtual void exitAux_rule__macro_invocation_semi_9(PnfRustParser::Aux_rule__macro_invocation_semi_9Context * /*ctx*/) override { }

  virtual void enterAux_rule__type_3(PnfRustParser::Aux_rule__type_3Context * /*ctx*/) override { }
  virtual void exitAux_rule__type_3(PnfRustParser::Aux_rule__type_3Context * /*ctx*/) override { }

  virtual void enterAux_rule__type_4(PnfRustParser::Aux_rule__type_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__type_4(PnfRustParser::Aux_rule__type_4Context * /*ctx*/) override { }

  virtual void enterAux_rule__type_5(PnfRustParser::Aux_rule__type_5Context * /*ctx*/) override { }
  virtual void exitAux_rule__type_5(PnfRustParser::Aux_rule__type_5Context * /*ctx*/) override { }

  virtual void enterAux_rule__fn_rtype_2(PnfRustParser::Aux_rule__fn_rtype_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__fn_rtype_2(PnfRustParser::Aux_rule__fn_rtype_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__trait_alias_4(PnfRustParser::Aux_rule__trait_alias_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__trait_alias_4(PnfRustParser::Aux_rule__trait_alias_4Context * /*ctx*/) override { }

  virtual void enterAux_rule__pat_fields_11(PnfRustParser::Aux_rule__pat_fields_11Context * /*ctx*/) override { }
  virtual void exitAux_rule__pat_fields_11(PnfRustParser::Aux_rule__pat_fields_11Context * /*ctx*/) override { }

  virtual void enterAux_rule__prim_expr_no_struct_32(PnfRustParser::Aux_rule__prim_expr_no_struct_32Context * /*ctx*/) override { }
  virtual void exitAux_rule__prim_expr_no_struct_32(PnfRustParser::Aux_rule__prim_expr_no_struct_32Context * /*ctx*/) override { }

  virtual void enterAux_rule__fields_6(PnfRustParser::Aux_rule__fields_6Context * /*ctx*/) override { }
  virtual void exitAux_rule__fields_6(PnfRustParser::Aux_rule__fields_6Context * /*ctx*/) override { }

  virtual void enterAux_rule__assign_expr_no_struct_6(PnfRustParser::Aux_rule__assign_expr_no_struct_6Context * /*ctx*/) override { }
  virtual void exitAux_rule__assign_expr_no_struct_6(PnfRustParser::Aux_rule__assign_expr_no_struct_6Context * /*ctx*/) override { }

  virtual void enterAux_rule__cmp_expr_no_struct_9(PnfRustParser::Aux_rule__cmp_expr_no_struct_9Context * /*ctx*/) override { }
  virtual void exitAux_rule__cmp_expr_no_struct_9(PnfRustParser::Aux_rule__cmp_expr_no_struct_9Context * /*ctx*/) override { }

  virtual void enterAux_rule__trait_method_param_11(PnfRustParser::Aux_rule__trait_method_param_11Context * /*ctx*/) override { }
  virtual void exitAux_rule__trait_method_param_11(PnfRustParser::Aux_rule__trait_method_param_11Context * /*ctx*/) override { }

  virtual void enterAux_rule__type_decl_12(PnfRustParser::Aux_rule__type_decl_12Context * /*ctx*/) override { }
  virtual void exitAux_rule__type_decl_12(PnfRustParser::Aux_rule__type_decl_12Context * /*ctx*/) override { }

  virtual void enterAux_rule__type_decl_13(PnfRustParser::Aux_rule__type_decl_13Context * /*ctx*/) override { }
  virtual void exitAux_rule__type_decl_13(PnfRustParser::Aux_rule__type_decl_13Context * /*ctx*/) override { }

  virtual void enterAux_rule__use_path_9(PnfRustParser::Aux_rule__use_path_9Context * /*ctx*/) override { }
  virtual void exitAux_rule__use_path_9(PnfRustParser::Aux_rule__use_path_9Context * /*ctx*/) override { }

  virtual void enterAux_rule__use_path_10(PnfRustParser::Aux_rule__use_path_10Context * /*ctx*/) override { }
  virtual void exitAux_rule__use_path_10(PnfRustParser::Aux_rule__use_path_10Context * /*ctx*/) override { }

  virtual void enterAux_rule__foreign_item_5(PnfRustParser::Aux_rule__foreign_item_5Context * /*ctx*/) override { }
  virtual void exitAux_rule__foreign_item_5(PnfRustParser::Aux_rule__foreign_item_5Context * /*ctx*/) override { }

  virtual void enterAux_rule__param_14(PnfRustParser::Aux_rule__param_14Context * /*ctx*/) override { }
  virtual void exitAux_rule__param_14(PnfRustParser::Aux_rule__param_14Context * /*ctx*/) override { }

  virtual void enterAux_rule__param_15(PnfRustParser::Aux_rule__param_15Context * /*ctx*/) override { }
  virtual void exitAux_rule__param_15(PnfRustParser::Aux_rule__param_15Context * /*ctx*/) override { }

  virtual void enterAux_rule__trait_item_26(PnfRustParser::Aux_rule__trait_item_26Context * /*ctx*/) override { }
  virtual void exitAux_rule__trait_item_26(PnfRustParser::Aux_rule__trait_item_26Context * /*ctx*/) override { }

  virtual void enterAux_rule__trait_item_27(PnfRustParser::Aux_rule__trait_item_27Context * /*ctx*/) override { }
  virtual void exitAux_rule__trait_item_27(PnfRustParser::Aux_rule__trait_item_27Context * /*ctx*/) override { }

  virtual void enterAux_rule__type_arguments_12(PnfRustParser::Aux_rule__type_arguments_12Context * /*ctx*/) override { }
  virtual void exitAux_rule__type_arguments_12(PnfRustParser::Aux_rule__type_arguments_12Context * /*ctx*/) override { }

  virtual void enterAux_rule__type_arguments_13(PnfRustParser::Aux_rule__type_arguments_13Context * /*ctx*/) override { }
  virtual void exitAux_rule__type_arguments_13(PnfRustParser::Aux_rule__type_arguments_13Context * /*ctx*/) override { }

  virtual void enterAux_rule__pattern_without_mut_44(PnfRustParser::Aux_rule__pattern_without_mut_44Context * /*ctx*/) override { }
  virtual void exitAux_rule__pattern_without_mut_44(PnfRustParser::Aux_rule__pattern_without_mut_44Context * /*ctx*/) override { }

  virtual void enterAux_rule__pattern_without_mut_45(PnfRustParser::Aux_rule__pattern_without_mut_45Context * /*ctx*/) override { }
  virtual void exitAux_rule__pattern_without_mut_45(PnfRustParser::Aux_rule__pattern_without_mut_45Context * /*ctx*/) override { }

  virtual void enterAux_rule__pat_field_7(PnfRustParser::Aux_rule__pat_field_7Context * /*ctx*/) override { }
  virtual void exitAux_rule__pat_field_7(PnfRustParser::Aux_rule__pat_field_7Context * /*ctx*/) override { }

  virtual void enterAux_rule__pat_field_8(PnfRustParser::Aux_rule__pat_field_8Context * /*ctx*/) override { }
  virtual void exitAux_rule__pat_field_8(PnfRustParser::Aux_rule__pat_field_8Context * /*ctx*/) override { }

  virtual void enterAux_rule__prim_expr_no_struct_33(PnfRustParser::Aux_rule__prim_expr_no_struct_33Context * /*ctx*/) override { }
  virtual void exitAux_rule__prim_expr_no_struct_33(PnfRustParser::Aux_rule__prim_expr_no_struct_33Context * /*ctx*/) override { }

  virtual void enterAux_rule__prim_expr_no_struct_34(PnfRustParser::Aux_rule__prim_expr_no_struct_34Context * /*ctx*/) override { }
  virtual void exitAux_rule__prim_expr_no_struct_34(PnfRustParser::Aux_rule__prim_expr_no_struct_34Context * /*ctx*/) override { }

  virtual void enterAux_rule__prim_expr_no_struct_35(PnfRustParser::Aux_rule__prim_expr_no_struct_35Context * /*ctx*/) override { }
  virtual void exitAux_rule__prim_expr_no_struct_35(PnfRustParser::Aux_rule__prim_expr_no_struct_35Context * /*ctx*/) override { }

  virtual void enterAux_rule__item_8(PnfRustParser::Aux_rule__item_8Context * /*ctx*/) override { }
  virtual void exitAux_rule__item_8(PnfRustParser::Aux_rule__item_8Context * /*ctx*/) override { }

  virtual void enterAux_rule__param_16(PnfRustParser::Aux_rule__param_16Context * /*ctx*/) override { }
  virtual void exitAux_rule__param_16(PnfRustParser::Aux_rule__param_16Context * /*ctx*/) override { }

  virtual void enterAux_rule__ty_path_segment_no_super_7(PnfRustParser::Aux_rule__ty_path_segment_no_super_7Context * /*ctx*/) override { }
  virtual void exitAux_rule__ty_path_segment_no_super_7(PnfRustParser::Aux_rule__ty_path_segment_no_super_7Context * /*ctx*/) override { }

  virtual void enterAux_rule__post_expr_3(PnfRustParser::Aux_rule__post_expr_3Context * /*ctx*/) override { }
  virtual void exitAux_rule__post_expr_3(PnfRustParser::Aux_rule__post_expr_3Context * /*ctx*/) override { }

  virtual void enterAux_rule__post_expr_4(PnfRustParser::Aux_rule__post_expr_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__post_expr_4(PnfRustParser::Aux_rule__post_expr_4Context * /*ctx*/) override { }

  virtual void enterAux_rule__post_expr_5(PnfRustParser::Aux_rule__post_expr_5Context * /*ctx*/) override { }
  virtual void exitAux_rule__post_expr_5(PnfRustParser::Aux_rule__post_expr_5Context * /*ctx*/) override { }


  virtual void enterEveryRule(antlr4::ParserRuleContext * /*ctx*/) override { }
  virtual void exitEveryRule(antlr4::ParserRuleContext * /*ctx*/) override { }
  virtual void visitTerminal(antlr4::tree::TerminalNode * /*node*/) override { }
  virtual void visitErrorNode(antlr4::tree::ErrorNode * /*node*/) override { }

};

}  // namespace antlr_rust_perses
