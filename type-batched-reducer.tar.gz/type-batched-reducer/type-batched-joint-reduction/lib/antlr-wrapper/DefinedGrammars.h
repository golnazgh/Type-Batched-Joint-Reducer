
#ifndef DEFINED_GRAMMARS
#define DEFINED_GRAMMARS


class CGrammar : public AntlrGrammarInfo {
public:
  CGrammar()
    : AntlrGrammarInfo{"", true}
      { }

  std::unique_ptr<ParseTreeValidityChecker>
  getValidityChecker(const antlr4::tree::ParseTree& originalRoot) const override;

  std::unique_ptr<antlr4::Lexer>
  makeLexer(antlr4::CharStream* stream) const override;

  std::unique_ptr<antlr4::Parser>
  makeParser(antlr4::TokenStream* stream) const override;

  antlr4::tree::ParseTree*
  getRoot(antlr4::Parser& parser) const override;

  void
  print(llvm::raw_ostream& out,
        const llvm::ArrayRef<const antlr4::Token*> tokens) const override;

  llvm::ArrayRef<std::vector<std::vector<unsigned>>>
  getNullableRules() const override;

  llvm::ArrayRef<std::vector<std::vector<llvm::StringRef>>>
  getNullableStrings() const override;

  llvm::ArrayRef<std::vector<std::pair<int,std::vector<int>>>>
  getEdits() const override;

  llvm::ArrayRef<bool>
  getAlwaysNullableRules() const override;

  llvm::ArrayRef<const char*>
  getMinimalStrings() const override;

  antlr4::tree::ParseTree*
  parseRule(unsigned ruleID, antlr4::Parser& parser) const override;
};


class CPPGrammar : public AntlrGrammarInfo {
public:
  CPPGrammar()
    : AntlrGrammarInfo{"", true}
      { }

  std::unique_ptr<ParseTreeValidityChecker>
  getValidityChecker(const antlr4::tree::ParseTree& originalRoot) const override;

  std::unique_ptr<antlr4::Lexer>
  makeLexer(antlr4::CharStream* stream) const override;

  std::unique_ptr<antlr4::Parser>
  makeParser(antlr4::TokenStream* stream) const override;

  antlr4::tree::ParseTree*
  getRoot(antlr4::Parser& parser) const override;

  void
  print(llvm::raw_ostream& out,
        const llvm::ArrayRef<const antlr4::Token*> tokens) const override;
 
  llvm::ArrayRef<std::vector<std::vector<unsigned>>>
  getNullableRules() const override;

  llvm::ArrayRef<std::vector<std::vector<llvm::StringRef>>>
  getNullableStrings() const override;

  llvm::ArrayRef<std::vector<std::pair<int,std::vector<int>>>>
  getEdits() const override;

  llvm::ArrayRef<bool>
  getAlwaysNullableRules() const override;

  llvm::ArrayRef<const char*>
  getMinimalStrings() const override;

  antlr4::tree::ParseTree*
  parseRule(unsigned ruleID, antlr4::Parser& parser) const override;
};


class CExplicitGrammar : public AntlrGrammarInfo {
public:
  CExplicitGrammar()
    : AntlrGrammarInfo{"", true}
      { }

  std::unique_ptr<ParseTreeValidityChecker>
  getValidityChecker(const antlr4::tree::ParseTree& originalRoot) const override;

  std::unique_ptr<antlr4::Lexer>
  makeLexer(antlr4::CharStream* stream) const override;

  std::unique_ptr<antlr4::Parser>
  makeParser(antlr4::TokenStream* stream) const override;

  antlr4::tree::ParseTree*
  getRoot(antlr4::Parser& parser) const override;

  void
  print(llvm::raw_ostream& out,
        const llvm::ArrayRef<const antlr4::Token*> tokens) const override;

  llvm::ArrayRef<std::vector<std::vector<unsigned>>>
  getNullableRules() const override;

  llvm::ArrayRef<std::vector<std::vector<llvm::StringRef>>>
  getNullableStrings() const override;

  llvm::ArrayRef<std::vector<std::pair<int,std::vector<int>>>>
  getEdits() const override;

  llvm::ArrayRef<bool>
  getAlwaysNullableRules() const override;

  llvm::ArrayRef<const char*>
  getMinimalStrings() const override;

  antlr4::tree::ParseTree*
  parseRule(unsigned ruleID, antlr4::Parser& parser) const override;
};


class CPNFGrammar : public AntlrGrammarInfo {
public:
  CPNFGrammar()
    : AntlrGrammarInfo{"", true}
      { }

  std::unique_ptr<ParseTreeValidityChecker>
  getValidityChecker(const antlr4::tree::ParseTree& originalRoot) const override;

  std::unique_ptr<antlr4::Lexer>
  makeLexer(antlr4::CharStream* stream) const override;

  std::unique_ptr<antlr4::Parser>
  makeParser(antlr4::TokenStream* stream) const override;

  antlr4::tree::ParseTree*
  getRoot(antlr4::Parser& parser) const override;

  void
  print(llvm::raw_ostream& out,
        const llvm::ArrayRef<const antlr4::Token*> tokens) const override;

  llvm::ArrayRef<std::vector<std::vector<unsigned>>>
  getNullableRules() const override;

  llvm::ArrayRef<std::vector<std::vector<llvm::StringRef>>>
  getNullableStrings() const override;

  llvm::ArrayRef<std::vector<std::pair<int,std::vector<int>>>>
  getEdits() const override;

  llvm::ArrayRef<bool>
  getAlwaysNullableRules() const override;

  llvm::ArrayRef<const char*>
  getMinimalStrings() const override;

  antlr4::tree::ParseTree*
  parseRule(unsigned ruleID, antlr4::Parser& parser) const override;
};


class CPNFOldGrammar : public AntlrGrammarInfo {
public:
  CPNFOldGrammar()
    : AntlrGrammarInfo{"", true}
      { }

  std::unique_ptr<antlr4::Lexer>
  makeLexer(antlr4::CharStream* stream) const override;

  std::unique_ptr<antlr4::Parser>
  makeParser(antlr4::TokenStream* stream) const override;

  antlr4::tree::ParseTree*
  getRoot(antlr4::Parser& parser) const override;

  void
  print(llvm::raw_ostream& out,
        const llvm::ArrayRef<const antlr4::Token*> tokens) const override;

  llvm::ArrayRef<std::vector<std::vector<unsigned>>>
  getNullableRules() const override;

  llvm::ArrayRef<std::vector<std::vector<llvm::StringRef>>>
  getNullableStrings() const override;

  llvm::ArrayRef<std::vector<std::pair<int,std::vector<int>>>>
  getEdits() const override;

  llvm::ArrayRef<bool>
  getAlwaysNullableRules() const override;

  llvm::ArrayRef<const char*>
  getMinimalStrings() const override;

  antlr4::tree::ParseTree*
  parseRule(unsigned ruleID, antlr4::Parser& parser) const override;
};


class CPNFBadGrammar : public AntlrGrammarInfo {
public:
  CPNFBadGrammar()
    : AntlrGrammarInfo{"", true}
      { }

  std::unique_ptr<antlr4::Lexer>
  makeLexer(antlr4::CharStream* stream) const override;

  std::unique_ptr<antlr4::Parser>
  makeParser(antlr4::TokenStream* stream) const override;

  antlr4::tree::ParseTree*
  getRoot(antlr4::Parser& parser) const override;

  void
  print(llvm::raw_ostream& out,
        const llvm::ArrayRef<const antlr4::Token*> tokens) const override;

  llvm::ArrayRef<std::vector<std::vector<unsigned>>>
  getNullableRules() const override;

  llvm::ArrayRef<std::vector<std::vector<llvm::StringRef>>>
  getNullableStrings() const override;

  llvm::ArrayRef<std::vector<std::pair<int,std::vector<int>>>>
  getEdits() const override;

  llvm::ArrayRef<bool>
  getAlwaysNullableRules() const override;

  llvm::ArrayRef<const char*>
  getMinimalStrings() const override;

  antlr4::tree::ParseTree*
  parseRule(unsigned ruleID, antlr4::Parser& parser) const override;
};


class CPNFFactoredGrammar : public AntlrGrammarInfo {
public:
  CPNFFactoredGrammar()
    : AntlrGrammarInfo{"", true}
      { }

  std::unique_ptr<antlr4::Lexer>
  makeLexer(antlr4::CharStream* stream) const override;

  std::unique_ptr<antlr4::Parser>
  makeParser(antlr4::TokenStream* stream) const override;

  antlr4::tree::ParseTree*
  getRoot(antlr4::Parser& parser) const override;

  void
  print(llvm::raw_ostream& out,
        const llvm::ArrayRef<const antlr4::Token*> tokens) const override;

  llvm::ArrayRef<std::vector<std::vector<unsigned>>>
  getNullableRules() const override;

  llvm::ArrayRef<std::vector<std::vector<llvm::StringRef>>>
  getNullableStrings() const override;

  llvm::ArrayRef<std::vector<std::pair<int,std::vector<int>>>>
  getEdits() const override;

  llvm::ArrayRef<bool>
  getAlwaysNullableRules() const override;

  llvm::ArrayRef<const char*>
  getMinimalStrings() const override;

  antlr4::tree::ParseTree*
  parseRule(unsigned ruleID, antlr4::Parser& parser) const override;
};


class PersesCGrammar : public AntlrGrammarInfo {
public:
  PersesCGrammar()
    : AntlrGrammarInfo{"", true}
      { }

  std::unique_ptr<antlr4::Lexer>
  makeLexer(antlr4::CharStream* stream) const override;

  std::unique_ptr<antlr4::Parser>
  makeParser(antlr4::TokenStream* stream) const override;

  antlr4::tree::ParseTree*
  getRoot(antlr4::Parser& parser) const override;

  void
  print(llvm::raw_ostream& out,
        const llvm::ArrayRef<const antlr4::Token*> tokens) const override;

  llvm::ArrayRef<std::vector<std::vector<unsigned>>>
  getNullableRules() const override;

  llvm::ArrayRef<std::vector<std::vector<llvm::StringRef>>>
  getNullableStrings() const override;

  llvm::ArrayRef<std::vector<std::pair<int,std::vector<int>>>>
  getEdits() const override;

  llvm::ArrayRef<bool>
  getAlwaysNullableRules() const override;

  llvm::ArrayRef<const char*>
  getMinimalStrings() const override;

  antlr4::tree::ParseTree*
  parseRule(unsigned ruleID, antlr4::Parser& parser) const override;
};


class ClojureGrammar : public AntlrGrammarInfo {
public:
  ClojureGrammar()
    : AntlrGrammarInfo{"", true}
      { }

  std::unique_ptr<antlr4::Lexer>
  makeLexer(antlr4::CharStream* stream) const override;

  std::unique_ptr<antlr4::Parser>
  makeParser(antlr4::TokenStream* stream) const override;

  antlr4::tree::ParseTree*
  getRoot(antlr4::Parser& parser) const override;

  llvm::ArrayRef<std::vector<std::vector<unsigned>>>
  getNullableRules() const override;

  llvm::ArrayRef<std::vector<std::vector<llvm::StringRef>>>
  getNullableStrings() const override;

  llvm::ArrayRef<std::vector<std::pair<int,std::vector<int>>>>
  getEdits() const override;

  llvm::ArrayRef<bool>
  getAlwaysNullableRules() const override;

  llvm::ArrayRef<const char*>
  getMinimalStrings() const override;

  antlr4::tree::ParseTree*
  parseRule(unsigned ruleID, antlr4::Parser& parser) const override;
};


class GolangGrammar : public AntlrGrammarInfo {
public:
  GolangGrammar()
    : AntlrGrammarInfo{"", true}
      { }

  std::unique_ptr<antlr4::Lexer>
  makeLexer(antlr4::CharStream* stream) const override;

  std::unique_ptr<antlr4::Parser>
  makeParser(antlr4::TokenStream* stream) const override;

  antlr4::tree::ParseTree*
  getRoot(antlr4::Parser& parser) const override;

  void
  print(llvm::raw_ostream& out,
        const llvm::ArrayRef<const antlr4::Token*> tokens) const override;
 
  llvm::ArrayRef<std::vector<std::vector<unsigned>>>
  getNullableRules() const override;

  llvm::ArrayRef<std::vector<std::vector<llvm::StringRef>>>
  getNullableStrings() const override;

  llvm::ArrayRef<std::vector<std::pair<int,std::vector<int>>>>
  getEdits() const override;

  llvm::ArrayRef<bool>
  getAlwaysNullableRules() const override;

  llvm::ArrayRef<const char*>
  getMinimalStrings() const override;

  antlr4::tree::ParseTree*
  parseRule(unsigned ruleID, antlr4::Parser& parser) const override;
};


class GraphvizGrammar : public AntlrGrammarInfo {
public:
  GraphvizGrammar()
    : AntlrGrammarInfo{"", true}
      { }

  std::unique_ptr<antlr4::Lexer>
  makeLexer(antlr4::CharStream* stream) const override;

  std::unique_ptr<antlr4::Parser>
  makeParser(antlr4::TokenStream* stream) const override;

  antlr4::tree::ParseTree*
  getRoot(antlr4::Parser& parser) const override;

  void
  print(llvm::raw_ostream& out,
        const llvm::ArrayRef<const antlr4::Token*> tokens) const override;
 
  llvm::ArrayRef<std::vector<std::vector<unsigned>>>
  getNullableRules() const override;

  llvm::ArrayRef<std::vector<std::vector<llvm::StringRef>>>
  getNullableStrings() const override;

  llvm::ArrayRef<std::vector<std::pair<int,std::vector<int>>>>
  getEdits() const override;

  llvm::ArrayRef<bool>
  getAlwaysNullableRules() const override;

  llvm::ArrayRef<const char*>
  getMinimalStrings() const override;

  antlr4::tree::ParseTree*
  parseRule(unsigned ruleID, antlr4::Parser& parser) const override;
};


class JavaGrammar : public AntlrGrammarInfo {
public:
  JavaGrammar()
    : AntlrGrammarInfo{"", true}
      { }

  std::unique_ptr<antlr4::Lexer>
  makeLexer(antlr4::CharStream* stream) const override;

  std::unique_ptr<antlr4::Parser>
  makeParser(antlr4::TokenStream* stream) const override;

  antlr4::tree::ParseTree*
  getRoot(antlr4::Parser& parser) const override;

  void
  print(llvm::raw_ostream& out,
        const llvm::ArrayRef<const antlr4::Token*> tokens) const override;
 
  llvm::ArrayRef<std::vector<std::vector<unsigned>>>
  getNullableRules() const override;

  llvm::ArrayRef<std::vector<std::vector<llvm::StringRef>>>
  getNullableStrings() const override;

  llvm::ArrayRef<bool>
  getAlwaysNullableRules() const override;

  llvm::ArrayRef<const char*>
  getMinimalStrings() const override;

  antlr4::tree::ParseTree*
  parseRule(unsigned ruleID, antlr4::Parser& parser) const override;
};


class JSONGrammar : public AntlrGrammarInfo {
public:
  JSONGrammar()
    : AntlrGrammarInfo{"", true}
      { }

  std::unique_ptr<antlr4::Lexer>
  makeLexer(antlr4::CharStream* stream) const override;

  std::unique_ptr<antlr4::Parser>
  makeParser(antlr4::TokenStream* stream) const override;

  antlr4::tree::ParseTree*
  getRoot(antlr4::Parser& parser) const override;

  llvm::ArrayRef<std::vector<std::vector<unsigned>>>
  getNullableRules() const override;

  llvm::ArrayRef<std::vector<std::vector<llvm::StringRef>>>
  getNullableStrings() const override;

  llvm::ArrayRef<bool>
  getAlwaysNullableRules() const override;

  llvm::ArrayRef<const char*>
  getMinimalStrings() const override;

  antlr4::tree::ParseTree*
  parseRule(unsigned ruleID, antlr4::Parser& parser) const override;
};


class LuaGrammar : public AntlrGrammarInfo {
public:
  LuaGrammar()
    : AntlrGrammarInfo{"", true}
      { }

  std::unique_ptr<antlr4::Lexer>
  makeLexer(antlr4::CharStream* stream) const override;

  std::unique_ptr<antlr4::Parser>
  makeParser(antlr4::TokenStream* stream) const override;

  antlr4::tree::ParseTree*
  getRoot(antlr4::Parser& parser) const override;

  llvm::ArrayRef<std::vector<std::vector<unsigned>>>
  getNullableRules() const override;

  llvm::ArrayRef<std::vector<std::vector<llvm::StringRef>>>
  getNullableStrings() const override;

  llvm::ArrayRef<bool>
  getAlwaysNullableRules() const override;

  llvm::ArrayRef<const char*>
  getMinimalStrings() const override;

  antlr4::tree::ParseTree*
  parseRule(unsigned ruleID, antlr4::Parser& parser) const override;
};


class PCREGrammar : public AntlrGrammarInfo {
public:
  PCREGrammar()
    : AntlrGrammarInfo{"", true}
      { }

  std::unique_ptr<antlr4::Lexer>
  makeLexer(antlr4::CharStream* stream) const override;

  std::unique_ptr<antlr4::Parser>
  makeParser(antlr4::TokenStream* stream) const override;

  antlr4::tree::ParseTree*
  getRoot(antlr4::Parser& parser) const override;

  void
  print(llvm::raw_ostream& out,
        const llvm::ArrayRef<const antlr4::Token*> tokens) const override;
 
  llvm::ArrayRef<std::vector<std::vector<unsigned>>>
  getNullableRules() const override;

  llvm::ArrayRef<std::vector<std::vector<llvm::StringRef>>>
  getNullableStrings() const override;

  llvm::ArrayRef<bool>
  getAlwaysNullableRules() const override;

  llvm::ArrayRef<const char*>
  getMinimalStrings() const override;

  antlr4::tree::ParseTree*
  parseRule(unsigned ruleID, antlr4::Parser& parser) const override;
};


class RGrammar : public AntlrGrammarInfo {
public:
  RGrammar()
    : AntlrGrammarInfo{"", true}
      { }

  std::unique_ptr<antlr4::Lexer>
  makeLexer(antlr4::CharStream* stream) const override;

  std::unique_ptr<antlr4::Parser>
  makeParser(antlr4::TokenStream* stream) const override;

  antlr4::tree::ParseTree*
  getRoot(antlr4::Parser& parser) const override;

  llvm::ArrayRef<std::vector<std::vector<unsigned>>>
  getNullableRules() const override;

  llvm::ArrayRef<std::vector<std::vector<llvm::StringRef>>>
  getNullableStrings() const override;

  llvm::ArrayRef<bool>
  getAlwaysNullableRules() const override;

  llvm::ArrayRef<const char*>
  getMinimalStrings() const override;

  antlr4::tree::ParseTree*
  parseRule(unsigned ruleID, antlr4::Parser& parser) const override;
};


class RustGrammar : public AntlrGrammarInfo {
public:
  RustGrammar()
    : AntlrGrammarInfo{"", true}
      { }

  std::unique_ptr<antlr4::Lexer>
  makeLexer(antlr4::CharStream* stream) const override;

  std::unique_ptr<antlr4::Parser>
  makeParser(antlr4::TokenStream* stream) const override;

  antlr4::tree::ParseTree*
  getRoot(antlr4::Parser& parser) const override;

  llvm::ArrayRef<std::vector<std::vector<unsigned>>>
  getNullableRules() const override;

  llvm::ArrayRef<std::vector<std::vector<llvm::StringRef>>>
  getNullableStrings() const override;

  llvm::ArrayRef<std::vector<std::pair<int,std::vector<int>>>>
  getEdits() const override;

  llvm::ArrayRef<bool>
  getAlwaysNullableRules() const override;

  llvm::ArrayRef<const char*>
  getMinimalStrings() const override;

  antlr4::tree::ParseTree*
  parseRule(unsigned ruleID, antlr4::Parser& parser) const override;
};


class RustPNFGrammar : public AntlrGrammarInfo {
public:
  RustPNFGrammar()
    : AntlrGrammarInfo{"", true}
      { }

  std::unique_ptr<antlr4::Lexer>
  makeLexer(antlr4::CharStream* stream) const override;

  std::unique_ptr<antlr4::Parser>
  makeParser(antlr4::TokenStream* stream) const override;

  antlr4::tree::ParseTree*
  getRoot(antlr4::Parser& parser) const override;

  llvm::ArrayRef<std::vector<std::vector<unsigned>>>
  getNullableRules() const override;

  llvm::ArrayRef<std::vector<std::vector<llvm::StringRef>>>
  getNullableStrings() const override;

  llvm::ArrayRef<std::vector<std::pair<int,std::vector<int>>>>
  getEdits() const override;

  llvm::ArrayRef<bool>
  getAlwaysNullableRules() const override;

  llvm::ArrayRef<const char*>
  getMinimalStrings() const override;

  antlr4::tree::ParseTree*
  parseRule(unsigned ruleID, antlr4::Parser& parser) const override;
};


class VerilogGrammar : public AntlrGrammarInfo {
public:
  VerilogGrammar()
    : AntlrGrammarInfo{"", true}
      { }

  std::unique_ptr<antlr4::Lexer>
  makeLexer(antlr4::CharStream* stream) const override;

  std::unique_ptr<antlr4::Parser>
  makeParser(antlr4::TokenStream* stream) const override;

  antlr4::tree::ParseTree*
  getRoot(antlr4::Parser& parser) const override;

  llvm::ArrayRef<std::vector<std::vector<unsigned>>>
  getNullableRules() const override;

  llvm::ArrayRef<std::vector<std::vector<llvm::StringRef>>>
  getNullableStrings() const override;

  llvm::ArrayRef<bool>
  getAlwaysNullableRules() const override;

  llvm::ArrayRef<const char*>
  getMinimalStrings() const override;

  antlr4::tree::ParseTree*
  parseRule(unsigned ruleID, antlr4::Parser& parser) const override;
};

// Perses grammar plugins

class PnfCGrammar : public AntlrGrammarInfo {
public:
  PnfCGrammar()
    : AntlrGrammarInfo{"", true}
      { }

  std::unique_ptr<antlr4::Lexer>
  makeLexer(antlr4::CharStream* stream) const override;

  std::unique_ptr<antlr4::Parser>
  makeParser(antlr4::TokenStream* stream) const override;

  antlr4::tree::ParseTree*
  getRoot(antlr4::Parser& parser) const override;

  void
  print(llvm::raw_ostream& out,
        const llvm::ArrayRef<const antlr4::Token*> tokens) const override;

  llvm::ArrayRef<std::vector<std::vector<unsigned>>>
  getNullableRules() const override;

  llvm::ArrayRef<std::vector<std::vector<llvm::StringRef>>>
  getNullableStrings() const override;

  llvm::ArrayRef<std::vector<std::pair<int,std::vector<int>>>>
  getEdits() const override;

  llvm::ArrayRef<bool>
  getAlwaysNullableRules() const override;

  llvm::ArrayRef<const char*>
  getMinimalStrings() const override;

  antlr4::tree::ParseTree*
  parseRule(unsigned ruleID, antlr4::Parser& parser) const override;
};


class PnfCPP14Grammar : public AntlrGrammarInfo {
public:
  PnfCPP14Grammar()
    : AntlrGrammarInfo{"", true}
      { }

  std::unique_ptr<antlr4::Lexer>
  makeLexer(antlr4::CharStream* stream) const override;

  std::unique_ptr<antlr4::Parser>
  makeParser(antlr4::TokenStream* stream) const override;

  antlr4::tree::ParseTree*
  getRoot(antlr4::Parser& parser) const override;

  void
  print(llvm::raw_ostream& out,
        const llvm::ArrayRef<const antlr4::Token*> tokens) const override;

  llvm::ArrayRef<std::vector<std::vector<unsigned>>>
  getNullableRules() const override;

  llvm::ArrayRef<std::vector<std::vector<llvm::StringRef>>>
  getNullableStrings() const override;

  llvm::ArrayRef<std::vector<std::pair<int,std::vector<int>>>>
  getEdits() const override;

  llvm::ArrayRef<bool>
  getAlwaysNullableRules() const override;

  llvm::ArrayRef<const char*>
  getMinimalStrings() const override;

  antlr4::tree::ParseTree*
  parseRule(unsigned ruleID, antlr4::Parser& parser) const override;
};


class PnfGoGrammar : public AntlrGrammarInfo {
public:
  PnfGoGrammar()
    : AntlrGrammarInfo{"", true}
      { }

  std::unique_ptr<antlr4::Lexer>
  makeLexer(antlr4::CharStream* stream) const override;

  std::unique_ptr<antlr4::Parser>
  makeParser(antlr4::TokenStream* stream) const override;

  antlr4::tree::ParseTree*
  getRoot(antlr4::Parser& parser) const override;

  void
  print(llvm::raw_ostream& out,
        const llvm::ArrayRef<const antlr4::Token*> tokens) const override;

  llvm::ArrayRef<std::vector<std::vector<unsigned>>>
  getNullableRules() const override;

  llvm::ArrayRef<std::vector<std::vector<llvm::StringRef>>>
  getNullableStrings() const override;

  llvm::ArrayRef<std::vector<std::pair<int,std::vector<int>>>>
  getEdits() const override;

  llvm::ArrayRef<bool>
  getAlwaysNullableRules() const override;

  llvm::ArrayRef<const char*>
  getMinimalStrings() const override;

  antlr4::tree::ParseTree*
  parseRule(unsigned ruleID, antlr4::Parser& parser) const override;
};


class PnfJava8Grammar : public AntlrGrammarInfo {
public:
  PnfJava8Grammar()
    : AntlrGrammarInfo{"", true}
      { }

  std::unique_ptr<antlr4::Lexer>
  makeLexer(antlr4::CharStream* stream) const override;

  std::unique_ptr<antlr4::Parser>
  makeParser(antlr4::TokenStream* stream) const override;

  antlr4::tree::ParseTree*
  getRoot(antlr4::Parser& parser) const override;

  void
  print(llvm::raw_ostream& out,
        const llvm::ArrayRef<const antlr4::Token*> tokens) const override;

  llvm::ArrayRef<std::vector<std::vector<unsigned>>>
  getNullableRules() const override;

  llvm::ArrayRef<std::vector<std::vector<llvm::StringRef>>>
  getNullableStrings() const override;

  llvm::ArrayRef<std::vector<std::pair<int,std::vector<int>>>>
  getEdits() const override;

  llvm::ArrayRef<bool>
  getAlwaysNullableRules() const override;

  llvm::ArrayRef<const char*>
  getMinimalStrings() const override;

  antlr4::tree::ParseTree*
  parseRule(unsigned ruleID, antlr4::Parser& parser) const override;
};


class PnfRustGrammar : public AntlrGrammarInfo {
public:
  PnfRustGrammar()
    : AntlrGrammarInfo{"", true}
      { }

  std::unique_ptr<antlr4::Lexer>
  makeLexer(antlr4::CharStream* stream) const override;

  std::unique_ptr<antlr4::Parser>
  makeParser(antlr4::TokenStream* stream) const override;

  antlr4::tree::ParseTree*
  getRoot(antlr4::Parser& parser) const override;

  void
  print(llvm::raw_ostream& out,
        const llvm::ArrayRef<const antlr4::Token*> tokens) const override;

  llvm::ArrayRef<std::vector<std::vector<unsigned>>>
  getNullableRules() const override;

  llvm::ArrayRef<std::vector<std::vector<llvm::StringRef>>>
  getNullableStrings() const override;

  llvm::ArrayRef<std::vector<std::pair<int,std::vector<int>>>>
  getEdits() const override;

  llvm::ArrayRef<bool>
  getAlwaysNullableRules() const override;

  llvm::ArrayRef<const char*>
  getMinimalStrings() const override;

  antlr4::tree::ParseTree*
  parseRule(unsigned ruleID, antlr4::Parser& parser) const override;
};





#endif
