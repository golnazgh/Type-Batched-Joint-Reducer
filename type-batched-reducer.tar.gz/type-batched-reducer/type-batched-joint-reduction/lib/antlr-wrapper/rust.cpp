#include "antlr-plugins.h"
#include "antlr-wrapper.h"

#include "antlr4-runtime.h"
#include "RuleContextWithAltNum.h"

#include "PnfRustLexer.h"
#include "PnfRustParser.h"

#include "DefinedGrammars.h"

#include <llvm/ADT/DenseMap.h>
#include <llvm/ADT/DenseSet.h>
#include <llvm/ADT/StringMap.h>


using namespace antlr4;
using namespace llvm;


using LocalGrammar = PnfRustGrammar;


void
printCStyleTokens(llvm::raw_ostream& out,
                  const llvm::ArrayRef<const antlr4::Token*> tokens);

std::unique_ptr<antlr4::Lexer>
LocalGrammar::makeLexer(antlr4::CharStream* stream) const {
  return std::make_unique<antlr_rust_perses::PnfRustLexer>(stream);
}
std::unique_ptr<antlr4::Parser>
LocalGrammar::makeParser(antlr4::TokenStream* stream) const {
  return std::make_unique<antlr_rust_perses::PnfRustParser>(stream);
}
antlr4::tree::ParseTree*
LocalGrammar::getRoot(antlr4::Parser& parser) const {
  return static_cast<antlr_rust_perses::PnfRustParser&>(parser).crate();
}


void
LocalGrammar::print(llvm::raw_ostream& out,
    const llvm::ArrayRef<const antlr4::Token*> tokens) const {
  printCStyleTokens(out, tokens);
}


static std::vector<std::vector<unsigned>> nullableRulesOptC[] = { {} };
static std::vector<std::vector<llvm::StringRef>> nullableStringsOptC[] = { {} };
static std::vector<std::pair<int,std::vector<int>>> editsOptC[] = {};


llvm::ArrayRef<std::vector<std::vector<unsigned>>>
LocalGrammar::getNullableRules() const {
  printf("Unsupported nullable rule operation.\n");
  abort();
  return llvm::ArrayRef<std::vector<std::vector<unsigned>>>();
}

llvm::ArrayRef<std::vector<std::vector<llvm::StringRef>>>
LocalGrammar::getNullableStrings() const {
  printf("Unsupported nullable string operation.\n");
  abort();
  return llvm::ArrayRef<std::vector<std::vector<llvm::StringRef>>>();
}

llvm::ArrayRef<std::vector<std::pair<int,std::vector<int>>>>
LocalGrammar::getEdits() const {
  printf("Unsupported edits operation.\n");
  abort();
  return llvm::ArrayRef<std::vector<std::pair<int,std::vector<int>>>>();
}

llvm::ArrayRef<bool>
LocalGrammar::getAlwaysNullableRules() const {
  printf("Unsupported nullable rule operation.\n");
  abort();
  return llvm::ArrayRef<bool>();
}

antlr4::tree::ParseTree*
LocalGrammar::parseRule(unsigned ruleID, antlr4::Parser& parser) const {
  printf("Unsupported parsing operation.\n");
  abort();
  return nullptr;
}

llvm::ArrayRef<const char*>
LocalGrammar::getMinimalStrings() const {
  printf("Unsupported string minima operation.\n");
  abort();
  return llvm::ArrayRef<const char*>();
}
