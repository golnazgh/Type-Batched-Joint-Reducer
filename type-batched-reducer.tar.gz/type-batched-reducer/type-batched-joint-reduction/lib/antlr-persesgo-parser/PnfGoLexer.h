
// Generated from PnfGoLexer.g4 by ANTLR 4.7.2

#pragma once


#include "antlr4-runtime.h"


namespace antlr_go_perses {


class  PnfGoLexer : public antlr4::Lexer {
public:
  enum {
    BREAK = 1, DEFAULT = 2, FUNC = 3, INTERFACE = 4, SELECT = 5, CASE = 6, 
    DEFER = 7, GO = 8, MAP = 9, STRUCT = 10, CHAN = 11, ELSE = 12, GOTO = 13, 
    PACKAGE = 14, SWITCH = 15, CONST = 16, FALLTHROUGH = 17, IF = 18, RANGE = 19, 
    TYPE = 20, CONTINUE = 21, FOR = 22, IMPORT = 23, RETURN = 24, VAR = 25, 
    NIL_LIT = 26, IDENTIFIER = 27, L_PAREN = 28, R_PAREN = 29, L_CURLY = 30, 
    R_CURLY = 31, L_BRACKET = 32, R_BRACKET = 33, ASSIGN = 34, COMMA = 35, 
    SEMI = 36, COLON = 37, DOT = 38, PLUS_PLUS = 39, MINUS_MINUS = 40, DECLARE_ASSIGN = 41, 
    ELLIPSIS = 42, LOGICAL_OR = 43, LOGICAL_AND = 44, EQUALS = 45, NOT_EQUALS = 46, 
    LESS = 47, LESS_OR_EQUALS = 48, GREATER = 49, GREATER_OR_EQUALS = 50, 
    OR = 51, DIV = 52, MOD = 53, LSHIFT = 54, RSHIFT = 55, BIT_CLEAR = 56, 
    EXCLAMATION = 57, PLUS = 58, MINUS = 59, CARET = 60, STAR = 61, AMPERSAND = 62, 
    RECEIVE = 63, DECIMAL_LIT = 64, OCTAL_LIT = 65, HEX_LIT = 66, FLOAT_LIT = 67, 
    IMAGINARY_LIT = 68, RUNE_LIT = 69, RAW_STRING_LIT = 70, INTERPRETED_STRING_LIT = 71, 
    WS = 72, COMMENT = 73, TERMINATOR = 74, LINE_COMMENT = 75
  };

  PnfGoLexer(antlr4::CharStream *input);
  ~PnfGoLexer();


      antlr4::Token* previousToken = nullptr;
      std::unique_ptr<antlr4::Token> continueToken = nullptr;

      std::unique_ptr<antlr4::Token>
      nextToken() override {
          std::unique_ptr<antlr4::Token> result;

          if (continueToken) {
              result = std::move(continueToken);
              continueToken.reset();
              previousToken = nullptr;

          } else {
              result = Lexer::nextToken();

              if (result->getChannel() == antlr4::Token::DEFAULT_CHANNEL) {
                  previousToken = result.get();

              } else if (previousToken != nullptr) {
                  // Test if newline, and if previousToken matches,
                  // return a semicolon and shelve the newline.
                  // Note that line-comments and general comments containing newlines
                  // act as newlines.
                  if (result->getType() == TERMINATOR ||
                      result->getType() == LINE_COMMENT ||
                      result->getType() == (COMMENT && (result->getText().find('\n') != std::string::npos))) {
                      switch (previousToken->getType()) {
                          case IDENTIFIER:
                          case NIL_LIT:
                          case DECIMAL_LIT:
                          case FLOAT_LIT:
                          case OCTAL_LIT:
                          case HEX_LIT:
                          case IMAGINARY_LIT:
                          case RUNE_LIT:
                          case RAW_STRING_LIT:
                          case INTERPRETED_STRING_LIT:
                          case BREAK:
                          case CONTINUE:
                          case FALLTHROUGH:
                          case RETURN:
                          case PLUS_PLUS:
                          case MINUS_MINUS:
                          case R_CURLY:
                          case R_BRACKET:
                          case R_PAREN:
                              continueToken = std::move(result);
                              result = _factory->create(std::make_pair(nullptr, nullptr), SEMI, ";",
                                                       antlr4::Token::DEFAULT_CHANNEL, continueToken->getStartIndex(),
                                                       continueToken->getStopIndex(), continueToken->getLine(),
                                                       continueToken->getCharPositionInLine());
                              previousToken = nullptr;
                              break;
                          default:
                              break;
                      }
                  }
              }
          }

          return result;
      }

  virtual std::string getGrammarFileName() const override;
  virtual const std::vector<std::string>& getRuleNames() const override;

  virtual const std::vector<std::string>& getChannelNames() const override;
  virtual const std::vector<std::string>& getModeNames() const override;
  virtual const std::vector<std::string>& getTokenNames() const override; // deprecated, use vocabulary instead
  virtual antlr4::dfa::Vocabulary& getVocabulary() const override;

  virtual const std::vector<uint16_t> getSerializedATN() const override;
  virtual const antlr4::atn::ATN& getATN() const override;

private:
  static std::vector<antlr4::dfa::DFA> _decisionToDFA;
  static antlr4::atn::PredictionContextCache _sharedContextCache;
  static std::vector<std::string> _ruleNames;
  static std::vector<std::string> _tokenNames;
  static std::vector<std::string> _channelNames;
  static std::vector<std::string> _modeNames;

  static std::vector<std::string> _literalNames;
  static std::vector<std::string> _symbolicNames;
  static antlr4::dfa::Vocabulary _vocabulary;
  static antlr4::atn::ATN _atn;
  static std::vector<uint16_t> _serializedATN;


  // Individual action functions triggered by action() above.

  // Individual semantic predicate functions triggered by sempred() above.

  struct Initializer {
    Initializer();
  };
  static Initializer _init;
};

}  // namespace antlr_go_perses
