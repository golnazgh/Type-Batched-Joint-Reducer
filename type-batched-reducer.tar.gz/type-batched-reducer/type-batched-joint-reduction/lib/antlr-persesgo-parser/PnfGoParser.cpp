
// Generated from PnfGoParser.g4 by ANTLR 4.7.2


#include "PnfGoParserListener.h"
#include "PnfGoParserVisitor.h"

#include "PnfGoParser.h"


using namespace antlrcpp;
using namespace antlr_go_perses;
using namespace antlr4;

PnfGoParser::PnfGoParser(TokenStream *input) : Parser(input) {
  _interpreter = new atn::ParserATNSimulator(this, _atn, _decisionToDFA, _sharedContextCache);
}

PnfGoParser::~PnfGoParser() {
  delete _interpreter;
}

std::string PnfGoParser::getGrammarFileName() const {
  return "PnfGoParser.g4";
}

const std::vector<std::string>& PnfGoParser::getRuleNames() const {
  return _ruleNames;
}

dfa::Vocabulary& PnfGoParser::getVocabulary() const {
  return _vocabulary;
}


//----------------- SourceFileContext ------------------------------------------------------------------

PnfGoParser::SourceFileContext::SourceFileContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Aux_rule__sourceFile_6Context* PnfGoParser::SourceFileContext::aux_rule__sourceFile_6() {
  return getRuleContext<PnfGoParser::Aux_rule__sourceFile_6Context>(0);
}

tree::TerminalNode* PnfGoParser::SourceFileContext::EOF() {
  return getToken(PnfGoParser::EOF, 0);
}


size_t PnfGoParser::SourceFileContext::getRuleIndex() const {
  return PnfGoParser::RuleSourceFile;
}

void PnfGoParser::SourceFileContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterSourceFile(this);
}

void PnfGoParser::SourceFileContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitSourceFile(this);
}


antlrcpp::Any PnfGoParser::SourceFileContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitSourceFile(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::SourceFileContext* PnfGoParser::sourceFile() {
  SourceFileContext *_localctx = _tracker.createInstance<SourceFileContext>(_ctx, getState());
  enterRule(_localctx, 0, PnfGoParser::RuleSourceFile);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(428);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case PnfGoParser::PACKAGE: {
        enterOuterAlt(_localctx, 1);
        setState(426);
        aux_rule__sourceFile_6();
        break;
      }

      case PnfGoParser::EOF: {
        enterOuterAlt(_localctx, 2);
        setState(427);
        match(PnfGoParser::EOF);
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- PackageClauseContext ------------------------------------------------------------------

PnfGoParser::PackageClauseContext::PackageClauseContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::PackageClauseContext::PACKAGE() {
  return getToken(PnfGoParser::PACKAGE, 0);
}

tree::TerminalNode* PnfGoParser::PackageClauseContext::IDENTIFIER() {
  return getToken(PnfGoParser::IDENTIFIER, 0);
}


size_t PnfGoParser::PackageClauseContext::getRuleIndex() const {
  return PnfGoParser::RulePackageClause;
}

void PnfGoParser::PackageClauseContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterPackageClause(this);
}

void PnfGoParser::PackageClauseContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitPackageClause(this);
}


antlrcpp::Any PnfGoParser::PackageClauseContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitPackageClause(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::PackageClauseContext* PnfGoParser::packageClause() {
  PackageClauseContext *_localctx = _tracker.createInstance<PackageClauseContext>(_ctx, getState());
  enterRule(_localctx, 2, PnfGoParser::RulePackageClause);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(430);
    match(PnfGoParser::PACKAGE);
    setState(431);
    match(PnfGoParser::IDENTIFIER);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ImportDeclContext ------------------------------------------------------------------

PnfGoParser::ImportDeclContext::ImportDeclContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::ImportDeclContext::IMPORT() {
  return getToken(PnfGoParser::IMPORT, 0);
}

PnfGoParser::Altnt_block__importDecl_3Context* PnfGoParser::ImportDeclContext::altnt_block__importDecl_3() {
  return getRuleContext<PnfGoParser::Altnt_block__importDecl_3Context>(0);
}


size_t PnfGoParser::ImportDeclContext::getRuleIndex() const {
  return PnfGoParser::RuleImportDecl;
}

void PnfGoParser::ImportDeclContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterImportDecl(this);
}

void PnfGoParser::ImportDeclContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitImportDecl(this);
}


antlrcpp::Any PnfGoParser::ImportDeclContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitImportDecl(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::ImportDeclContext* PnfGoParser::importDecl() {
  ImportDeclContext *_localctx = _tracker.createInstance<ImportDeclContext>(_ctx, getState());
  enterRule(_localctx, 4, PnfGoParser::RuleImportDecl);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(433);
    match(PnfGoParser::IMPORT);
    setState(434);
    altnt_block__importDecl_3();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ImportSpecContext ------------------------------------------------------------------

PnfGoParser::ImportSpecContext::ImportSpecContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Optional__importSpec_2Context* PnfGoParser::ImportSpecContext::optional__importSpec_2() {
  return getRuleContext<PnfGoParser::Optional__importSpec_2Context>(0);
}

PnfGoParser::ImportPathContext* PnfGoParser::ImportSpecContext::importPath() {
  return getRuleContext<PnfGoParser::ImportPathContext>(0);
}


size_t PnfGoParser::ImportSpecContext::getRuleIndex() const {
  return PnfGoParser::RuleImportSpec;
}

void PnfGoParser::ImportSpecContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterImportSpec(this);
}

void PnfGoParser::ImportSpecContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitImportSpec(this);
}


antlrcpp::Any PnfGoParser::ImportSpecContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitImportSpec(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::ImportSpecContext* PnfGoParser::importSpec() {
  ImportSpecContext *_localctx = _tracker.createInstance<ImportSpecContext>(_ctx, getState());
  enterRule(_localctx, 6, PnfGoParser::RuleImportSpec);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(436);
    optional__importSpec_2();
    setState(437);
    importPath();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ImportPathContext ------------------------------------------------------------------

PnfGoParser::ImportPathContext::ImportPathContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::String_Context* PnfGoParser::ImportPathContext::string_() {
  return getRuleContext<PnfGoParser::String_Context>(0);
}


size_t PnfGoParser::ImportPathContext::getRuleIndex() const {
  return PnfGoParser::RuleImportPath;
}

void PnfGoParser::ImportPathContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterImportPath(this);
}

void PnfGoParser::ImportPathContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitImportPath(this);
}


antlrcpp::Any PnfGoParser::ImportPathContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitImportPath(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::ImportPathContext* PnfGoParser::importPath() {
  ImportPathContext *_localctx = _tracker.createInstance<ImportPathContext>(_ctx, getState());
  enterRule(_localctx, 8, PnfGoParser::RuleImportPath);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(439);
    string_();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- DeclarationContext ------------------------------------------------------------------

PnfGoParser::DeclarationContext::DeclarationContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::ConstDeclContext* PnfGoParser::DeclarationContext::constDecl() {
  return getRuleContext<PnfGoParser::ConstDeclContext>(0);
}

PnfGoParser::TypeDeclContext* PnfGoParser::DeclarationContext::typeDecl() {
  return getRuleContext<PnfGoParser::TypeDeclContext>(0);
}

PnfGoParser::VarDeclContext* PnfGoParser::DeclarationContext::varDecl() {
  return getRuleContext<PnfGoParser::VarDeclContext>(0);
}


size_t PnfGoParser::DeclarationContext::getRuleIndex() const {
  return PnfGoParser::RuleDeclaration;
}

void PnfGoParser::DeclarationContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterDeclaration(this);
}

void PnfGoParser::DeclarationContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitDeclaration(this);
}


antlrcpp::Any PnfGoParser::DeclarationContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitDeclaration(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::DeclarationContext* PnfGoParser::declaration() {
  DeclarationContext *_localctx = _tracker.createInstance<DeclarationContext>(_ctx, getState());
  enterRule(_localctx, 10, PnfGoParser::RuleDeclaration);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(444);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case PnfGoParser::CONST: {
        enterOuterAlt(_localctx, 1);
        setState(441);
        constDecl();
        break;
      }

      case PnfGoParser::TYPE: {
        enterOuterAlt(_localctx, 2);
        setState(442);
        typeDecl();
        break;
      }

      case PnfGoParser::VAR: {
        enterOuterAlt(_localctx, 3);
        setState(443);
        varDecl();
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ConstDeclContext ------------------------------------------------------------------

PnfGoParser::ConstDeclContext::ConstDeclContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::ConstDeclContext::CONST() {
  return getToken(PnfGoParser::CONST, 0);
}

PnfGoParser::Altnt_block__constDecl_3Context* PnfGoParser::ConstDeclContext::altnt_block__constDecl_3() {
  return getRuleContext<PnfGoParser::Altnt_block__constDecl_3Context>(0);
}


size_t PnfGoParser::ConstDeclContext::getRuleIndex() const {
  return PnfGoParser::RuleConstDecl;
}

void PnfGoParser::ConstDeclContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterConstDecl(this);
}

void PnfGoParser::ConstDeclContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitConstDecl(this);
}


antlrcpp::Any PnfGoParser::ConstDeclContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitConstDecl(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::ConstDeclContext* PnfGoParser::constDecl() {
  ConstDeclContext *_localctx = _tracker.createInstance<ConstDeclContext>(_ctx, getState());
  enterRule(_localctx, 12, PnfGoParser::RuleConstDecl);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(446);
    match(PnfGoParser::CONST);
    setState(447);
    altnt_block__constDecl_3();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ConstSpecContext ------------------------------------------------------------------

PnfGoParser::ConstSpecContext::ConstSpecContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::IdentifierListContext* PnfGoParser::ConstSpecContext::identifierList() {
  return getRuleContext<PnfGoParser::IdentifierListContext>(0);
}

PnfGoParser::Optional__constSpec_3Context* PnfGoParser::ConstSpecContext::optional__constSpec_3() {
  return getRuleContext<PnfGoParser::Optional__constSpec_3Context>(0);
}


size_t PnfGoParser::ConstSpecContext::getRuleIndex() const {
  return PnfGoParser::RuleConstSpec;
}

void PnfGoParser::ConstSpecContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterConstSpec(this);
}

void PnfGoParser::ConstSpecContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitConstSpec(this);
}


antlrcpp::Any PnfGoParser::ConstSpecContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitConstSpec(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::ConstSpecContext* PnfGoParser::constSpec() {
  ConstSpecContext *_localctx = _tracker.createInstance<ConstSpecContext>(_ctx, getState());
  enterRule(_localctx, 14, PnfGoParser::RuleConstSpec);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(449);
    identifierList();
    setState(450);
    optional__constSpec_3();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- IdentifierListContext ------------------------------------------------------------------

PnfGoParser::IdentifierListContext::IdentifierListContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::IdentifierListContext::IDENTIFIER() {
  return getToken(PnfGoParser::IDENTIFIER, 0);
}

PnfGoParser::Kleene_star__identifierList_2Context* PnfGoParser::IdentifierListContext::kleene_star__identifierList_2() {
  return getRuleContext<PnfGoParser::Kleene_star__identifierList_2Context>(0);
}


size_t PnfGoParser::IdentifierListContext::getRuleIndex() const {
  return PnfGoParser::RuleIdentifierList;
}

void PnfGoParser::IdentifierListContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterIdentifierList(this);
}

void PnfGoParser::IdentifierListContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitIdentifierList(this);
}


antlrcpp::Any PnfGoParser::IdentifierListContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitIdentifierList(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::IdentifierListContext* PnfGoParser::identifierList() {
  IdentifierListContext *_localctx = _tracker.createInstance<IdentifierListContext>(_ctx, getState());
  enterRule(_localctx, 16, PnfGoParser::RuleIdentifierList);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(452);
    match(PnfGoParser::IDENTIFIER);
    setState(453);
    kleene_star__identifierList_2();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ExpressionListContext ------------------------------------------------------------------

PnfGoParser::ExpressionListContext::ExpressionListContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::ExpressionContext* PnfGoParser::ExpressionListContext::expression() {
  return getRuleContext<PnfGoParser::ExpressionContext>(0);
}

PnfGoParser::Kleene_star__expressionList_2Context* PnfGoParser::ExpressionListContext::kleene_star__expressionList_2() {
  return getRuleContext<PnfGoParser::Kleene_star__expressionList_2Context>(0);
}


size_t PnfGoParser::ExpressionListContext::getRuleIndex() const {
  return PnfGoParser::RuleExpressionList;
}

void PnfGoParser::ExpressionListContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterExpressionList(this);
}

void PnfGoParser::ExpressionListContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitExpressionList(this);
}


antlrcpp::Any PnfGoParser::ExpressionListContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitExpressionList(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::ExpressionListContext* PnfGoParser::expressionList() {
  ExpressionListContext *_localctx = _tracker.createInstance<ExpressionListContext>(_ctx, getState());
  enterRule(_localctx, 18, PnfGoParser::RuleExpressionList);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(455);
    expression();
    setState(456);
    kleene_star__expressionList_2();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- TypeDeclContext ------------------------------------------------------------------

PnfGoParser::TypeDeclContext::TypeDeclContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::TypeDeclContext::TYPE() {
  return getToken(PnfGoParser::TYPE, 0);
}

PnfGoParser::Altnt_block__typeDecl_3Context* PnfGoParser::TypeDeclContext::altnt_block__typeDecl_3() {
  return getRuleContext<PnfGoParser::Altnt_block__typeDecl_3Context>(0);
}


size_t PnfGoParser::TypeDeclContext::getRuleIndex() const {
  return PnfGoParser::RuleTypeDecl;
}

void PnfGoParser::TypeDeclContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterTypeDecl(this);
}

void PnfGoParser::TypeDeclContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitTypeDecl(this);
}


antlrcpp::Any PnfGoParser::TypeDeclContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitTypeDecl(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::TypeDeclContext* PnfGoParser::typeDecl() {
  TypeDeclContext *_localctx = _tracker.createInstance<TypeDeclContext>(_ctx, getState());
  enterRule(_localctx, 20, PnfGoParser::RuleTypeDecl);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(458);
    match(PnfGoParser::TYPE);
    setState(459);
    altnt_block__typeDecl_3();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- TypeSpecContext ------------------------------------------------------------------

PnfGoParser::TypeSpecContext::TypeSpecContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::TypeSpecContext::IDENTIFIER() {
  return getToken(PnfGoParser::IDENTIFIER, 0);
}

PnfGoParser::Optional__typeSpec_1Context* PnfGoParser::TypeSpecContext::optional__typeSpec_1() {
  return getRuleContext<PnfGoParser::Optional__typeSpec_1Context>(0);
}

PnfGoParser::Type_Context* PnfGoParser::TypeSpecContext::type_() {
  return getRuleContext<PnfGoParser::Type_Context>(0);
}


size_t PnfGoParser::TypeSpecContext::getRuleIndex() const {
  return PnfGoParser::RuleTypeSpec;
}

void PnfGoParser::TypeSpecContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterTypeSpec(this);
}

void PnfGoParser::TypeSpecContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitTypeSpec(this);
}


antlrcpp::Any PnfGoParser::TypeSpecContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitTypeSpec(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::TypeSpecContext* PnfGoParser::typeSpec() {
  TypeSpecContext *_localctx = _tracker.createInstance<TypeSpecContext>(_ctx, getState());
  enterRule(_localctx, 22, PnfGoParser::RuleTypeSpec);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(461);
    match(PnfGoParser::IDENTIFIER);
    setState(462);
    optional__typeSpec_1();
    setState(463);
    type_();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- FunctionDeclContext ------------------------------------------------------------------

PnfGoParser::FunctionDeclContext::FunctionDeclContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::FunctionDeclContext::FUNC() {
  return getToken(PnfGoParser::FUNC, 0);
}

tree::TerminalNode* PnfGoParser::FunctionDeclContext::IDENTIFIER() {
  return getToken(PnfGoParser::IDENTIFIER, 0);
}

PnfGoParser::SignatureContext* PnfGoParser::FunctionDeclContext::signature() {
  return getRuleContext<PnfGoParser::SignatureContext>(0);
}

PnfGoParser::Optional__functionDecl_1Context* PnfGoParser::FunctionDeclContext::optional__functionDecl_1() {
  return getRuleContext<PnfGoParser::Optional__functionDecl_1Context>(0);
}


size_t PnfGoParser::FunctionDeclContext::getRuleIndex() const {
  return PnfGoParser::RuleFunctionDecl;
}

void PnfGoParser::FunctionDeclContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterFunctionDecl(this);
}

void PnfGoParser::FunctionDeclContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitFunctionDecl(this);
}


antlrcpp::Any PnfGoParser::FunctionDeclContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitFunctionDecl(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::FunctionDeclContext* PnfGoParser::functionDecl() {
  FunctionDeclContext *_localctx = _tracker.createInstance<FunctionDeclContext>(_ctx, getState());
  enterRule(_localctx, 24, PnfGoParser::RuleFunctionDecl);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(465);
    match(PnfGoParser::FUNC);
    setState(466);
    match(PnfGoParser::IDENTIFIER);
    setState(467);
    signature();
    setState(468);
    optional__functionDecl_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- MethodDeclContext ------------------------------------------------------------------

PnfGoParser::MethodDeclContext::MethodDeclContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::MethodDeclContext::FUNC() {
  return getToken(PnfGoParser::FUNC, 0);
}

PnfGoParser::ReceiverContext* PnfGoParser::MethodDeclContext::receiver() {
  return getRuleContext<PnfGoParser::ReceiverContext>(0);
}

tree::TerminalNode* PnfGoParser::MethodDeclContext::IDENTIFIER() {
  return getToken(PnfGoParser::IDENTIFIER, 0);
}

PnfGoParser::SignatureContext* PnfGoParser::MethodDeclContext::signature() {
  return getRuleContext<PnfGoParser::SignatureContext>(0);
}

PnfGoParser::Optional__functionDecl_1Context* PnfGoParser::MethodDeclContext::optional__functionDecl_1() {
  return getRuleContext<PnfGoParser::Optional__functionDecl_1Context>(0);
}


size_t PnfGoParser::MethodDeclContext::getRuleIndex() const {
  return PnfGoParser::RuleMethodDecl;
}

void PnfGoParser::MethodDeclContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterMethodDecl(this);
}

void PnfGoParser::MethodDeclContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitMethodDecl(this);
}


antlrcpp::Any PnfGoParser::MethodDeclContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitMethodDecl(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::MethodDeclContext* PnfGoParser::methodDecl() {
  MethodDeclContext *_localctx = _tracker.createInstance<MethodDeclContext>(_ctx, getState());
  enterRule(_localctx, 26, PnfGoParser::RuleMethodDecl);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(470);
    match(PnfGoParser::FUNC);
    setState(471);
    receiver();
    setState(472);
    match(PnfGoParser::IDENTIFIER);
    setState(473);
    signature();
    setState(474);
    optional__functionDecl_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ReceiverContext ------------------------------------------------------------------

PnfGoParser::ReceiverContext::ReceiverContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::ParametersContext* PnfGoParser::ReceiverContext::parameters() {
  return getRuleContext<PnfGoParser::ParametersContext>(0);
}


size_t PnfGoParser::ReceiverContext::getRuleIndex() const {
  return PnfGoParser::RuleReceiver;
}

void PnfGoParser::ReceiverContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterReceiver(this);
}

void PnfGoParser::ReceiverContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitReceiver(this);
}


antlrcpp::Any PnfGoParser::ReceiverContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitReceiver(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::ReceiverContext* PnfGoParser::receiver() {
  ReceiverContext *_localctx = _tracker.createInstance<ReceiverContext>(_ctx, getState());
  enterRule(_localctx, 28, PnfGoParser::RuleReceiver);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(476);
    parameters();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- VarDeclContext ------------------------------------------------------------------

PnfGoParser::VarDeclContext::VarDeclContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::VarDeclContext::VAR() {
  return getToken(PnfGoParser::VAR, 0);
}

PnfGoParser::Altnt_block__varDecl_3Context* PnfGoParser::VarDeclContext::altnt_block__varDecl_3() {
  return getRuleContext<PnfGoParser::Altnt_block__varDecl_3Context>(0);
}


size_t PnfGoParser::VarDeclContext::getRuleIndex() const {
  return PnfGoParser::RuleVarDecl;
}

void PnfGoParser::VarDeclContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterVarDecl(this);
}

void PnfGoParser::VarDeclContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitVarDecl(this);
}


antlrcpp::Any PnfGoParser::VarDeclContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitVarDecl(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::VarDeclContext* PnfGoParser::varDecl() {
  VarDeclContext *_localctx = _tracker.createInstance<VarDeclContext>(_ctx, getState());
  enterRule(_localctx, 30, PnfGoParser::RuleVarDecl);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(478);
    match(PnfGoParser::VAR);
    setState(479);
    altnt_block__varDecl_3();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- VarSpecContext ------------------------------------------------------------------

PnfGoParser::VarSpecContext::VarSpecContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::IdentifierListContext* PnfGoParser::VarSpecContext::identifierList() {
  return getRuleContext<PnfGoParser::IdentifierListContext>(0);
}

PnfGoParser::Altnt_block__varSpec_3Context* PnfGoParser::VarSpecContext::altnt_block__varSpec_3() {
  return getRuleContext<PnfGoParser::Altnt_block__varSpec_3Context>(0);
}


size_t PnfGoParser::VarSpecContext::getRuleIndex() const {
  return PnfGoParser::RuleVarSpec;
}

void PnfGoParser::VarSpecContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterVarSpec(this);
}

void PnfGoParser::VarSpecContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitVarSpec(this);
}


antlrcpp::Any PnfGoParser::VarSpecContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitVarSpec(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::VarSpecContext* PnfGoParser::varSpec() {
  VarSpecContext *_localctx = _tracker.createInstance<VarSpecContext>(_ctx, getState());
  enterRule(_localctx, 32, PnfGoParser::RuleVarSpec);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(481);
    identifierList();
    setState(482);
    altnt_block__varSpec_3();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- BlockContext ------------------------------------------------------------------

PnfGoParser::BlockContext::BlockContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::BlockContext::L_CURLY() {
  return getToken(PnfGoParser::L_CURLY, 0);
}

PnfGoParser::Optional__block_1Context* PnfGoParser::BlockContext::optional__block_1() {
  return getRuleContext<PnfGoParser::Optional__block_1Context>(0);
}

tree::TerminalNode* PnfGoParser::BlockContext::R_CURLY() {
  return getToken(PnfGoParser::R_CURLY, 0);
}


size_t PnfGoParser::BlockContext::getRuleIndex() const {
  return PnfGoParser::RuleBlock;
}

void PnfGoParser::BlockContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterBlock(this);
}

void PnfGoParser::BlockContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitBlock(this);
}


antlrcpp::Any PnfGoParser::BlockContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitBlock(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::BlockContext* PnfGoParser::block() {
  BlockContext *_localctx = _tracker.createInstance<BlockContext>(_ctx, getState());
  enterRule(_localctx, 34, PnfGoParser::RuleBlock);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(484);
    match(PnfGoParser::L_CURLY);
    setState(485);
    optional__block_1();
    setState(486);
    match(PnfGoParser::R_CURLY);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- StatementListContext ------------------------------------------------------------------

PnfGoParser::StatementListContext::StatementListContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfGoParser::Aux_rule__statementList_1Context *> PnfGoParser::StatementListContext::aux_rule__statementList_1() {
  return getRuleContexts<PnfGoParser::Aux_rule__statementList_1Context>();
}

PnfGoParser::Aux_rule__statementList_1Context* PnfGoParser::StatementListContext::aux_rule__statementList_1(size_t i) {
  return getRuleContext<PnfGoParser::Aux_rule__statementList_1Context>(i);
}


size_t PnfGoParser::StatementListContext::getRuleIndex() const {
  return PnfGoParser::RuleStatementList;
}

void PnfGoParser::StatementListContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterStatementList(this);
}

void PnfGoParser::StatementListContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitStatementList(this);
}


antlrcpp::Any PnfGoParser::StatementListContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitStatementList(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::StatementListContext* PnfGoParser::statementList() {
  StatementListContext *_localctx = _tracker.createInstance<StatementListContext>(_ctx, getState());
  enterRule(_localctx, 36, PnfGoParser::RuleStatementList);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(489); 
    _errHandler->sync(this);
    _la = _input->LA(1);
    do {
      setState(488);
      aux_rule__statementList_1();
      setState(491); 
      _errHandler->sync(this);
      _la = _input->LA(1);
    } while ((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << PnfGoParser::BREAK)
      | (1ULL << PnfGoParser::FUNC)
      | (1ULL << PnfGoParser::INTERFACE)
      | (1ULL << PnfGoParser::SELECT)
      | (1ULL << PnfGoParser::DEFER)
      | (1ULL << PnfGoParser::GO)
      | (1ULL << PnfGoParser::MAP)
      | (1ULL << PnfGoParser::STRUCT)
      | (1ULL << PnfGoParser::CHAN)
      | (1ULL << PnfGoParser::GOTO)
      | (1ULL << PnfGoParser::SWITCH)
      | (1ULL << PnfGoParser::CONST)
      | (1ULL << PnfGoParser::FALLTHROUGH)
      | (1ULL << PnfGoParser::IF)
      | (1ULL << PnfGoParser::TYPE)
      | (1ULL << PnfGoParser::CONTINUE)
      | (1ULL << PnfGoParser::FOR)
      | (1ULL << PnfGoParser::RETURN)
      | (1ULL << PnfGoParser::VAR)
      | (1ULL << PnfGoParser::NIL_LIT)
      | (1ULL << PnfGoParser::IDENTIFIER)
      | (1ULL << PnfGoParser::L_PAREN)
      | (1ULL << PnfGoParser::L_CURLY)
      | (1ULL << PnfGoParser::L_BRACKET)
      | (1ULL << PnfGoParser::SEMI)
      | (1ULL << PnfGoParser::EXCLAMATION)
      | (1ULL << PnfGoParser::PLUS)
      | (1ULL << PnfGoParser::MINUS)
      | (1ULL << PnfGoParser::CARET)
      | (1ULL << PnfGoParser::STAR)
      | (1ULL << PnfGoParser::AMPERSAND)
      | (1ULL << PnfGoParser::RECEIVE))) != 0) || ((((_la - 64) & ~ 0x3fULL) == 0) &&
      ((1ULL << (_la - 64)) & ((1ULL << (PnfGoParser::DECIMAL_LIT - 64))
      | (1ULL << (PnfGoParser::OCTAL_LIT - 64))
      | (1ULL << (PnfGoParser::HEX_LIT - 64))
      | (1ULL << (PnfGoParser::FLOAT_LIT - 64))
      | (1ULL << (PnfGoParser::IMAGINARY_LIT - 64))
      | (1ULL << (PnfGoParser::RUNE_LIT - 64))
      | (1ULL << (PnfGoParser::RAW_STRING_LIT - 64))
      | (1ULL << (PnfGoParser::INTERPRETED_STRING_LIT - 64)))) != 0));
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- StatementContext ------------------------------------------------------------------

PnfGoParser::StatementContext::StatementContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::RealStatementContext* PnfGoParser::StatementContext::realStatement() {
  return getRuleContext<PnfGoParser::RealStatementContext>(0);
}


size_t PnfGoParser::StatementContext::getRuleIndex() const {
  return PnfGoParser::RuleStatement;
}

void PnfGoParser::StatementContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterStatement(this);
}

void PnfGoParser::StatementContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitStatement(this);
}


antlrcpp::Any PnfGoParser::StatementContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitStatement(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::StatementContext* PnfGoParser::statement() {
  StatementContext *_localctx = _tracker.createInstance<StatementContext>(_ctx, getState());
  enterRule(_localctx, 38, PnfGoParser::RuleStatement);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(494);
    _errHandler->sync(this);

    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 3, _ctx)) {
    case 1: {
      setState(493);
      realStatement();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- SimpleStmtContext ------------------------------------------------------------------

PnfGoParser::SimpleStmtContext::SimpleStmtContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::RealSimpleStmtContext* PnfGoParser::SimpleStmtContext::realSimpleStmt() {
  return getRuleContext<PnfGoParser::RealSimpleStmtContext>(0);
}


size_t PnfGoParser::SimpleStmtContext::getRuleIndex() const {
  return PnfGoParser::RuleSimpleStmt;
}

void PnfGoParser::SimpleStmtContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterSimpleStmt(this);
}

void PnfGoParser::SimpleStmtContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitSimpleStmt(this);
}


antlrcpp::Any PnfGoParser::SimpleStmtContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitSimpleStmt(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::SimpleStmtContext* PnfGoParser::simpleStmt() {
  SimpleStmtContext *_localctx = _tracker.createInstance<SimpleStmtContext>(_ctx, getState());
  enterRule(_localctx, 40, PnfGoParser::RuleSimpleStmt);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(497);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if ((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << PnfGoParser::FUNC)
      | (1ULL << PnfGoParser::INTERFACE)
      | (1ULL << PnfGoParser::MAP)
      | (1ULL << PnfGoParser::STRUCT)
      | (1ULL << PnfGoParser::CHAN)
      | (1ULL << PnfGoParser::NIL_LIT)
      | (1ULL << PnfGoParser::IDENTIFIER)
      | (1ULL << PnfGoParser::L_PAREN)
      | (1ULL << PnfGoParser::L_BRACKET)
      | (1ULL << PnfGoParser::EXCLAMATION)
      | (1ULL << PnfGoParser::PLUS)
      | (1ULL << PnfGoParser::MINUS)
      | (1ULL << PnfGoParser::CARET)
      | (1ULL << PnfGoParser::STAR)
      | (1ULL << PnfGoParser::AMPERSAND)
      | (1ULL << PnfGoParser::RECEIVE))) != 0) || ((((_la - 64) & ~ 0x3fULL) == 0) &&
      ((1ULL << (_la - 64)) & ((1ULL << (PnfGoParser::DECIMAL_LIT - 64))
      | (1ULL << (PnfGoParser::OCTAL_LIT - 64))
      | (1ULL << (PnfGoParser::HEX_LIT - 64))
      | (1ULL << (PnfGoParser::FLOAT_LIT - 64))
      | (1ULL << (PnfGoParser::IMAGINARY_LIT - 64))
      | (1ULL << (PnfGoParser::RUNE_LIT - 64))
      | (1ULL << (PnfGoParser::RAW_STRING_LIT - 64))
      | (1ULL << (PnfGoParser::INTERPRETED_STRING_LIT - 64)))) != 0)) {
      setState(496);
      realSimpleStmt();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- RealSimpleStmtContext ------------------------------------------------------------------

PnfGoParser::RealSimpleStmtContext::RealSimpleStmtContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::SendStmtContext* PnfGoParser::RealSimpleStmtContext::sendStmt() {
  return getRuleContext<PnfGoParser::SendStmtContext>(0);
}

PnfGoParser::AssignmentContext* PnfGoParser::RealSimpleStmtContext::assignment() {
  return getRuleContext<PnfGoParser::AssignmentContext>(0);
}

PnfGoParser::ExpressionStmtContext* PnfGoParser::RealSimpleStmtContext::expressionStmt() {
  return getRuleContext<PnfGoParser::ExpressionStmtContext>(0);
}

PnfGoParser::IncDecStmtContext* PnfGoParser::RealSimpleStmtContext::incDecStmt() {
  return getRuleContext<PnfGoParser::IncDecStmtContext>(0);
}

PnfGoParser::ShortVarDeclContext* PnfGoParser::RealSimpleStmtContext::shortVarDecl() {
  return getRuleContext<PnfGoParser::ShortVarDeclContext>(0);
}


size_t PnfGoParser::RealSimpleStmtContext::getRuleIndex() const {
  return PnfGoParser::RuleRealSimpleStmt;
}

void PnfGoParser::RealSimpleStmtContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterRealSimpleStmt(this);
}

void PnfGoParser::RealSimpleStmtContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitRealSimpleStmt(this);
}


antlrcpp::Any PnfGoParser::RealSimpleStmtContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitRealSimpleStmt(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::RealSimpleStmtContext* PnfGoParser::realSimpleStmt() {
  RealSimpleStmtContext *_localctx = _tracker.createInstance<RealSimpleStmtContext>(_ctx, getState());
  enterRule(_localctx, 42, PnfGoParser::RuleRealSimpleStmt);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(504);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 5, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(499);
      sendStmt();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(500);
      assignment();
      break;
    }

    case 3: {
      enterOuterAlt(_localctx, 3);
      setState(501);
      expressionStmt();
      break;
    }

    case 4: {
      enterOuterAlt(_localctx, 4);
      setState(502);
      incDecStmt();
      break;
    }

    case 5: {
      enterOuterAlt(_localctx, 5);
      setState(503);
      shortVarDecl();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ExpressionStmtContext ------------------------------------------------------------------

PnfGoParser::ExpressionStmtContext::ExpressionStmtContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::ExpressionContext* PnfGoParser::ExpressionStmtContext::expression() {
  return getRuleContext<PnfGoParser::ExpressionContext>(0);
}


size_t PnfGoParser::ExpressionStmtContext::getRuleIndex() const {
  return PnfGoParser::RuleExpressionStmt;
}

void PnfGoParser::ExpressionStmtContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterExpressionStmt(this);
}

void PnfGoParser::ExpressionStmtContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitExpressionStmt(this);
}


antlrcpp::Any PnfGoParser::ExpressionStmtContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitExpressionStmt(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::ExpressionStmtContext* PnfGoParser::expressionStmt() {
  ExpressionStmtContext *_localctx = _tracker.createInstance<ExpressionStmtContext>(_ctx, getState());
  enterRule(_localctx, 44, PnfGoParser::RuleExpressionStmt);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(506);
    expression();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- SendStmtContext ------------------------------------------------------------------

PnfGoParser::SendStmtContext::SendStmtContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfGoParser::ExpressionContext *> PnfGoParser::SendStmtContext::expression() {
  return getRuleContexts<PnfGoParser::ExpressionContext>();
}

PnfGoParser::ExpressionContext* PnfGoParser::SendStmtContext::expression(size_t i) {
  return getRuleContext<PnfGoParser::ExpressionContext>(i);
}

tree::TerminalNode* PnfGoParser::SendStmtContext::RECEIVE() {
  return getToken(PnfGoParser::RECEIVE, 0);
}


size_t PnfGoParser::SendStmtContext::getRuleIndex() const {
  return PnfGoParser::RuleSendStmt;
}

void PnfGoParser::SendStmtContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterSendStmt(this);
}

void PnfGoParser::SendStmtContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitSendStmt(this);
}


antlrcpp::Any PnfGoParser::SendStmtContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitSendStmt(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::SendStmtContext* PnfGoParser::sendStmt() {
  SendStmtContext *_localctx = _tracker.createInstance<SendStmtContext>(_ctx, getState());
  enterRule(_localctx, 46, PnfGoParser::RuleSendStmt);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(508);
    expression();
    setState(509);
    match(PnfGoParser::RECEIVE);
    setState(510);
    expression();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- IncDecStmtContext ------------------------------------------------------------------

PnfGoParser::IncDecStmtContext::IncDecStmtContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::ExpressionContext* PnfGoParser::IncDecStmtContext::expression() {
  return getRuleContext<PnfGoParser::ExpressionContext>(0);
}

PnfGoParser::Altnt_block__incDecStmt_1Context* PnfGoParser::IncDecStmtContext::altnt_block__incDecStmt_1() {
  return getRuleContext<PnfGoParser::Altnt_block__incDecStmt_1Context>(0);
}


size_t PnfGoParser::IncDecStmtContext::getRuleIndex() const {
  return PnfGoParser::RuleIncDecStmt;
}

void PnfGoParser::IncDecStmtContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterIncDecStmt(this);
}

void PnfGoParser::IncDecStmtContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitIncDecStmt(this);
}


antlrcpp::Any PnfGoParser::IncDecStmtContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitIncDecStmt(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::IncDecStmtContext* PnfGoParser::incDecStmt() {
  IncDecStmtContext *_localctx = _tracker.createInstance<IncDecStmtContext>(_ctx, getState());
  enterRule(_localctx, 48, PnfGoParser::RuleIncDecStmt);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(512);
    expression();
    setState(513);
    altnt_block__incDecStmt_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- AssignmentContext ------------------------------------------------------------------

PnfGoParser::AssignmentContext::AssignmentContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfGoParser::ExpressionListContext *> PnfGoParser::AssignmentContext::expressionList() {
  return getRuleContexts<PnfGoParser::ExpressionListContext>();
}

PnfGoParser::ExpressionListContext* PnfGoParser::AssignmentContext::expressionList(size_t i) {
  return getRuleContext<PnfGoParser::ExpressionListContext>(i);
}

PnfGoParser::Assign_opContext* PnfGoParser::AssignmentContext::assign_op() {
  return getRuleContext<PnfGoParser::Assign_opContext>(0);
}


size_t PnfGoParser::AssignmentContext::getRuleIndex() const {
  return PnfGoParser::RuleAssignment;
}

void PnfGoParser::AssignmentContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAssignment(this);
}

void PnfGoParser::AssignmentContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAssignment(this);
}


antlrcpp::Any PnfGoParser::AssignmentContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAssignment(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::AssignmentContext* PnfGoParser::assignment() {
  AssignmentContext *_localctx = _tracker.createInstance<AssignmentContext>(_ctx, getState());
  enterRule(_localctx, 50, PnfGoParser::RuleAssignment);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(515);
    expressionList();
    setState(516);
    assign_op();
    setState(517);
    expressionList();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Assign_opContext ------------------------------------------------------------------

PnfGoParser::Assign_opContext::Assign_opContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Optional__assign_op_2Context* PnfGoParser::Assign_opContext::optional__assign_op_2() {
  return getRuleContext<PnfGoParser::Optional__assign_op_2Context>(0);
}

tree::TerminalNode* PnfGoParser::Assign_opContext::ASSIGN() {
  return getToken(PnfGoParser::ASSIGN, 0);
}


size_t PnfGoParser::Assign_opContext::getRuleIndex() const {
  return PnfGoParser::RuleAssign_op;
}

void PnfGoParser::Assign_opContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAssign_op(this);
}

void PnfGoParser::Assign_opContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAssign_op(this);
}


antlrcpp::Any PnfGoParser::Assign_opContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAssign_op(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Assign_opContext* PnfGoParser::assign_op() {
  Assign_opContext *_localctx = _tracker.createInstance<Assign_opContext>(_ctx, getState());
  enterRule(_localctx, 52, PnfGoParser::RuleAssign_op);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(519);
    optional__assign_op_2();
    setState(520);
    match(PnfGoParser::ASSIGN);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ShortVarDeclContext ------------------------------------------------------------------

PnfGoParser::ShortVarDeclContext::ShortVarDeclContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::IdentifierListContext* PnfGoParser::ShortVarDeclContext::identifierList() {
  return getRuleContext<PnfGoParser::IdentifierListContext>(0);
}

tree::TerminalNode* PnfGoParser::ShortVarDeclContext::DECLARE_ASSIGN() {
  return getToken(PnfGoParser::DECLARE_ASSIGN, 0);
}

PnfGoParser::ExpressionListContext* PnfGoParser::ShortVarDeclContext::expressionList() {
  return getRuleContext<PnfGoParser::ExpressionListContext>(0);
}


size_t PnfGoParser::ShortVarDeclContext::getRuleIndex() const {
  return PnfGoParser::RuleShortVarDecl;
}

void PnfGoParser::ShortVarDeclContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterShortVarDecl(this);
}

void PnfGoParser::ShortVarDeclContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitShortVarDecl(this);
}


antlrcpp::Any PnfGoParser::ShortVarDeclContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitShortVarDecl(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::ShortVarDeclContext* PnfGoParser::shortVarDecl() {
  ShortVarDeclContext *_localctx = _tracker.createInstance<ShortVarDeclContext>(_ctx, getState());
  enterRule(_localctx, 54, PnfGoParser::RuleShortVarDecl);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(522);
    identifierList();
    setState(523);
    match(PnfGoParser::DECLARE_ASSIGN);
    setState(524);
    expressionList();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- LabeledStmtContext ------------------------------------------------------------------

PnfGoParser::LabeledStmtContext::LabeledStmtContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::LabeledStmtContext::IDENTIFIER() {
  return getToken(PnfGoParser::IDENTIFIER, 0);
}

tree::TerminalNode* PnfGoParser::LabeledStmtContext::COLON() {
  return getToken(PnfGoParser::COLON, 0);
}

PnfGoParser::StatementContext* PnfGoParser::LabeledStmtContext::statement() {
  return getRuleContext<PnfGoParser::StatementContext>(0);
}


size_t PnfGoParser::LabeledStmtContext::getRuleIndex() const {
  return PnfGoParser::RuleLabeledStmt;
}

void PnfGoParser::LabeledStmtContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterLabeledStmt(this);
}

void PnfGoParser::LabeledStmtContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitLabeledStmt(this);
}


antlrcpp::Any PnfGoParser::LabeledStmtContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitLabeledStmt(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::LabeledStmtContext* PnfGoParser::labeledStmt() {
  LabeledStmtContext *_localctx = _tracker.createInstance<LabeledStmtContext>(_ctx, getState());
  enterRule(_localctx, 56, PnfGoParser::RuleLabeledStmt);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(526);
    match(PnfGoParser::IDENTIFIER);
    setState(527);
    match(PnfGoParser::COLON);
    setState(528);
    statement();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ReturnStmtContext ------------------------------------------------------------------

PnfGoParser::ReturnStmtContext::ReturnStmtContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::ReturnStmtContext::RETURN() {
  return getToken(PnfGoParser::RETURN, 0);
}

PnfGoParser::Optional__returnStmt_1Context* PnfGoParser::ReturnStmtContext::optional__returnStmt_1() {
  return getRuleContext<PnfGoParser::Optional__returnStmt_1Context>(0);
}


size_t PnfGoParser::ReturnStmtContext::getRuleIndex() const {
  return PnfGoParser::RuleReturnStmt;
}

void PnfGoParser::ReturnStmtContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterReturnStmt(this);
}

void PnfGoParser::ReturnStmtContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitReturnStmt(this);
}


antlrcpp::Any PnfGoParser::ReturnStmtContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitReturnStmt(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::ReturnStmtContext* PnfGoParser::returnStmt() {
  ReturnStmtContext *_localctx = _tracker.createInstance<ReturnStmtContext>(_ctx, getState());
  enterRule(_localctx, 58, PnfGoParser::RuleReturnStmt);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(530);
    match(PnfGoParser::RETURN);
    setState(531);
    optional__returnStmt_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- BreakStmtContext ------------------------------------------------------------------

PnfGoParser::BreakStmtContext::BreakStmtContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::BreakStmtContext::BREAK() {
  return getToken(PnfGoParser::BREAK, 0);
}

PnfGoParser::Optional__breakStmt_1Context* PnfGoParser::BreakStmtContext::optional__breakStmt_1() {
  return getRuleContext<PnfGoParser::Optional__breakStmt_1Context>(0);
}


size_t PnfGoParser::BreakStmtContext::getRuleIndex() const {
  return PnfGoParser::RuleBreakStmt;
}

void PnfGoParser::BreakStmtContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterBreakStmt(this);
}

void PnfGoParser::BreakStmtContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitBreakStmt(this);
}


antlrcpp::Any PnfGoParser::BreakStmtContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitBreakStmt(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::BreakStmtContext* PnfGoParser::breakStmt() {
  BreakStmtContext *_localctx = _tracker.createInstance<BreakStmtContext>(_ctx, getState());
  enterRule(_localctx, 60, PnfGoParser::RuleBreakStmt);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(533);
    match(PnfGoParser::BREAK);
    setState(534);
    optional__breakStmt_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ContinueStmtContext ------------------------------------------------------------------

PnfGoParser::ContinueStmtContext::ContinueStmtContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::ContinueStmtContext::CONTINUE() {
  return getToken(PnfGoParser::CONTINUE, 0);
}

PnfGoParser::Optional__breakStmt_1Context* PnfGoParser::ContinueStmtContext::optional__breakStmt_1() {
  return getRuleContext<PnfGoParser::Optional__breakStmt_1Context>(0);
}


size_t PnfGoParser::ContinueStmtContext::getRuleIndex() const {
  return PnfGoParser::RuleContinueStmt;
}

void PnfGoParser::ContinueStmtContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterContinueStmt(this);
}

void PnfGoParser::ContinueStmtContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitContinueStmt(this);
}


antlrcpp::Any PnfGoParser::ContinueStmtContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitContinueStmt(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::ContinueStmtContext* PnfGoParser::continueStmt() {
  ContinueStmtContext *_localctx = _tracker.createInstance<ContinueStmtContext>(_ctx, getState());
  enterRule(_localctx, 62, PnfGoParser::RuleContinueStmt);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(536);
    match(PnfGoParser::CONTINUE);
    setState(537);
    optional__breakStmt_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- GotoStmtContext ------------------------------------------------------------------

PnfGoParser::GotoStmtContext::GotoStmtContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::GotoStmtContext::GOTO() {
  return getToken(PnfGoParser::GOTO, 0);
}

tree::TerminalNode* PnfGoParser::GotoStmtContext::IDENTIFIER() {
  return getToken(PnfGoParser::IDENTIFIER, 0);
}


size_t PnfGoParser::GotoStmtContext::getRuleIndex() const {
  return PnfGoParser::RuleGotoStmt;
}

void PnfGoParser::GotoStmtContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterGotoStmt(this);
}

void PnfGoParser::GotoStmtContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitGotoStmt(this);
}


antlrcpp::Any PnfGoParser::GotoStmtContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitGotoStmt(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::GotoStmtContext* PnfGoParser::gotoStmt() {
  GotoStmtContext *_localctx = _tracker.createInstance<GotoStmtContext>(_ctx, getState());
  enterRule(_localctx, 64, PnfGoParser::RuleGotoStmt);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(539);
    match(PnfGoParser::GOTO);
    setState(540);
    match(PnfGoParser::IDENTIFIER);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- FallthroughStmtContext ------------------------------------------------------------------

PnfGoParser::FallthroughStmtContext::FallthroughStmtContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::FallthroughStmtContext::FALLTHROUGH() {
  return getToken(PnfGoParser::FALLTHROUGH, 0);
}


size_t PnfGoParser::FallthroughStmtContext::getRuleIndex() const {
  return PnfGoParser::RuleFallthroughStmt;
}

void PnfGoParser::FallthroughStmtContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterFallthroughStmt(this);
}

void PnfGoParser::FallthroughStmtContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitFallthroughStmt(this);
}


antlrcpp::Any PnfGoParser::FallthroughStmtContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitFallthroughStmt(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::FallthroughStmtContext* PnfGoParser::fallthroughStmt() {
  FallthroughStmtContext *_localctx = _tracker.createInstance<FallthroughStmtContext>(_ctx, getState());
  enterRule(_localctx, 66, PnfGoParser::RuleFallthroughStmt);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(542);
    match(PnfGoParser::FALLTHROUGH);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- DeferStmtContext ------------------------------------------------------------------

PnfGoParser::DeferStmtContext::DeferStmtContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::DeferStmtContext::DEFER() {
  return getToken(PnfGoParser::DEFER, 0);
}

PnfGoParser::ExpressionContext* PnfGoParser::DeferStmtContext::expression() {
  return getRuleContext<PnfGoParser::ExpressionContext>(0);
}


size_t PnfGoParser::DeferStmtContext::getRuleIndex() const {
  return PnfGoParser::RuleDeferStmt;
}

void PnfGoParser::DeferStmtContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterDeferStmt(this);
}

void PnfGoParser::DeferStmtContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitDeferStmt(this);
}


antlrcpp::Any PnfGoParser::DeferStmtContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitDeferStmt(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::DeferStmtContext* PnfGoParser::deferStmt() {
  DeferStmtContext *_localctx = _tracker.createInstance<DeferStmtContext>(_ctx, getState());
  enterRule(_localctx, 68, PnfGoParser::RuleDeferStmt);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(544);
    match(PnfGoParser::DEFER);
    setState(545);
    expression();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- IfStmtContext ------------------------------------------------------------------

PnfGoParser::IfStmtContext::IfStmtContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::IfStmtContext::IF() {
  return getToken(PnfGoParser::IF, 0);
}

PnfGoParser::Optional__ifStmt_2Context* PnfGoParser::IfStmtContext::optional__ifStmt_2() {
  return getRuleContext<PnfGoParser::Optional__ifStmt_2Context>(0);
}

PnfGoParser::ExpressionContext* PnfGoParser::IfStmtContext::expression() {
  return getRuleContext<PnfGoParser::ExpressionContext>(0);
}

PnfGoParser::BlockContext* PnfGoParser::IfStmtContext::block() {
  return getRuleContext<PnfGoParser::BlockContext>(0);
}

PnfGoParser::Optional__ifStmt_4Context* PnfGoParser::IfStmtContext::optional__ifStmt_4() {
  return getRuleContext<PnfGoParser::Optional__ifStmt_4Context>(0);
}


size_t PnfGoParser::IfStmtContext::getRuleIndex() const {
  return PnfGoParser::RuleIfStmt;
}

void PnfGoParser::IfStmtContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterIfStmt(this);
}

void PnfGoParser::IfStmtContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitIfStmt(this);
}


antlrcpp::Any PnfGoParser::IfStmtContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitIfStmt(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::IfStmtContext* PnfGoParser::ifStmt() {
  IfStmtContext *_localctx = _tracker.createInstance<IfStmtContext>(_ctx, getState());
  enterRule(_localctx, 70, PnfGoParser::RuleIfStmt);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(547);
    match(PnfGoParser::IF);
    setState(548);
    optional__ifStmt_2();
    setState(549);
    expression();
    setState(550);
    block();
    setState(551);
    optional__ifStmt_4();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ExprSwitchStmtContext ------------------------------------------------------------------

PnfGoParser::ExprSwitchStmtContext::ExprSwitchStmtContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::ExprSwitchStmtContext::SWITCH() {
  return getToken(PnfGoParser::SWITCH, 0);
}

PnfGoParser::Optional__ifStmt_2Context* PnfGoParser::ExprSwitchStmtContext::optional__ifStmt_2() {
  return getRuleContext<PnfGoParser::Optional__ifStmt_2Context>(0);
}

PnfGoParser::Optional__exprSwitchStmt_3Context* PnfGoParser::ExprSwitchStmtContext::optional__exprSwitchStmt_3() {
  return getRuleContext<PnfGoParser::Optional__exprSwitchStmt_3Context>(0);
}

tree::TerminalNode* PnfGoParser::ExprSwitchStmtContext::L_CURLY() {
  return getToken(PnfGoParser::L_CURLY, 0);
}

PnfGoParser::Kleene_star__exprSwitchStmt_4Context* PnfGoParser::ExprSwitchStmtContext::kleene_star__exprSwitchStmt_4() {
  return getRuleContext<PnfGoParser::Kleene_star__exprSwitchStmt_4Context>(0);
}

tree::TerminalNode* PnfGoParser::ExprSwitchStmtContext::R_CURLY() {
  return getToken(PnfGoParser::R_CURLY, 0);
}


size_t PnfGoParser::ExprSwitchStmtContext::getRuleIndex() const {
  return PnfGoParser::RuleExprSwitchStmt;
}

void PnfGoParser::ExprSwitchStmtContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterExprSwitchStmt(this);
}

void PnfGoParser::ExprSwitchStmtContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitExprSwitchStmt(this);
}


antlrcpp::Any PnfGoParser::ExprSwitchStmtContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitExprSwitchStmt(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::ExprSwitchStmtContext* PnfGoParser::exprSwitchStmt() {
  ExprSwitchStmtContext *_localctx = _tracker.createInstance<ExprSwitchStmtContext>(_ctx, getState());
  enterRule(_localctx, 72, PnfGoParser::RuleExprSwitchStmt);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(553);
    match(PnfGoParser::SWITCH);
    setState(554);
    optional__ifStmt_2();
    setState(555);
    optional__exprSwitchStmt_3();
    setState(556);
    match(PnfGoParser::L_CURLY);
    setState(557);
    kleene_star__exprSwitchStmt_4();
    setState(558);
    match(PnfGoParser::R_CURLY);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ExprCaseClauseContext ------------------------------------------------------------------

PnfGoParser::ExprCaseClauseContext::ExprCaseClauseContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::ExprSwitchCaseContext* PnfGoParser::ExprCaseClauseContext::exprSwitchCase() {
  return getRuleContext<PnfGoParser::ExprSwitchCaseContext>(0);
}

tree::TerminalNode* PnfGoParser::ExprCaseClauseContext::COLON() {
  return getToken(PnfGoParser::COLON, 0);
}

PnfGoParser::Optional__block_1Context* PnfGoParser::ExprCaseClauseContext::optional__block_1() {
  return getRuleContext<PnfGoParser::Optional__block_1Context>(0);
}


size_t PnfGoParser::ExprCaseClauseContext::getRuleIndex() const {
  return PnfGoParser::RuleExprCaseClause;
}

void PnfGoParser::ExprCaseClauseContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterExprCaseClause(this);
}

void PnfGoParser::ExprCaseClauseContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitExprCaseClause(this);
}


antlrcpp::Any PnfGoParser::ExprCaseClauseContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitExprCaseClause(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::ExprCaseClauseContext* PnfGoParser::exprCaseClause() {
  ExprCaseClauseContext *_localctx = _tracker.createInstance<ExprCaseClauseContext>(_ctx, getState());
  enterRule(_localctx, 74, PnfGoParser::RuleExprCaseClause);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(560);
    exprSwitchCase();
    setState(561);
    match(PnfGoParser::COLON);
    setState(562);
    optional__block_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ExprSwitchCaseContext ------------------------------------------------------------------

PnfGoParser::ExprSwitchCaseContext::ExprSwitchCaseContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Aux_rule__exprSwitchCase_1Context* PnfGoParser::ExprSwitchCaseContext::aux_rule__exprSwitchCase_1() {
  return getRuleContext<PnfGoParser::Aux_rule__exprSwitchCase_1Context>(0);
}

tree::TerminalNode* PnfGoParser::ExprSwitchCaseContext::DEFAULT() {
  return getToken(PnfGoParser::DEFAULT, 0);
}


size_t PnfGoParser::ExprSwitchCaseContext::getRuleIndex() const {
  return PnfGoParser::RuleExprSwitchCase;
}

void PnfGoParser::ExprSwitchCaseContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterExprSwitchCase(this);
}

void PnfGoParser::ExprSwitchCaseContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitExprSwitchCase(this);
}


antlrcpp::Any PnfGoParser::ExprSwitchCaseContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitExprSwitchCase(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::ExprSwitchCaseContext* PnfGoParser::exprSwitchCase() {
  ExprSwitchCaseContext *_localctx = _tracker.createInstance<ExprSwitchCaseContext>(_ctx, getState());
  enterRule(_localctx, 76, PnfGoParser::RuleExprSwitchCase);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(566);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case PnfGoParser::CASE: {
        enterOuterAlt(_localctx, 1);
        setState(564);
        aux_rule__exprSwitchCase_1();
        break;
      }

      case PnfGoParser::DEFAULT: {
        enterOuterAlt(_localctx, 2);
        setState(565);
        match(PnfGoParser::DEFAULT);
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- TypeSwitchStmtContext ------------------------------------------------------------------

PnfGoParser::TypeSwitchStmtContext::TypeSwitchStmtContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::TypeSwitchStmtContext::SWITCH() {
  return getToken(PnfGoParser::SWITCH, 0);
}

PnfGoParser::Optional__ifStmt_2Context* PnfGoParser::TypeSwitchStmtContext::optional__ifStmt_2() {
  return getRuleContext<PnfGoParser::Optional__ifStmt_2Context>(0);
}

PnfGoParser::TypeSwitchGuardContext* PnfGoParser::TypeSwitchStmtContext::typeSwitchGuard() {
  return getRuleContext<PnfGoParser::TypeSwitchGuardContext>(0);
}

tree::TerminalNode* PnfGoParser::TypeSwitchStmtContext::L_CURLY() {
  return getToken(PnfGoParser::L_CURLY, 0);
}

PnfGoParser::Kleene_star__typeSwitchStmt_3Context* PnfGoParser::TypeSwitchStmtContext::kleene_star__typeSwitchStmt_3() {
  return getRuleContext<PnfGoParser::Kleene_star__typeSwitchStmt_3Context>(0);
}

tree::TerminalNode* PnfGoParser::TypeSwitchStmtContext::R_CURLY() {
  return getToken(PnfGoParser::R_CURLY, 0);
}


size_t PnfGoParser::TypeSwitchStmtContext::getRuleIndex() const {
  return PnfGoParser::RuleTypeSwitchStmt;
}

void PnfGoParser::TypeSwitchStmtContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterTypeSwitchStmt(this);
}

void PnfGoParser::TypeSwitchStmtContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitTypeSwitchStmt(this);
}


antlrcpp::Any PnfGoParser::TypeSwitchStmtContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitTypeSwitchStmt(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::TypeSwitchStmtContext* PnfGoParser::typeSwitchStmt() {
  TypeSwitchStmtContext *_localctx = _tracker.createInstance<TypeSwitchStmtContext>(_ctx, getState());
  enterRule(_localctx, 78, PnfGoParser::RuleTypeSwitchStmt);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(568);
    match(PnfGoParser::SWITCH);
    setState(569);
    optional__ifStmt_2();
    setState(570);
    typeSwitchGuard();
    setState(571);
    match(PnfGoParser::L_CURLY);
    setState(572);
    kleene_star__typeSwitchStmt_3();
    setState(573);
    match(PnfGoParser::R_CURLY);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- TypeSwitchGuardContext ------------------------------------------------------------------

PnfGoParser::TypeSwitchGuardContext::TypeSwitchGuardContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Optional__typeSwitchGuard_2Context* PnfGoParser::TypeSwitchGuardContext::optional__typeSwitchGuard_2() {
  return getRuleContext<PnfGoParser::Optional__typeSwitchGuard_2Context>(0);
}

PnfGoParser::PrimaryExprContext* PnfGoParser::TypeSwitchGuardContext::primaryExpr() {
  return getRuleContext<PnfGoParser::PrimaryExprContext>(0);
}

tree::TerminalNode* PnfGoParser::TypeSwitchGuardContext::DOT() {
  return getToken(PnfGoParser::DOT, 0);
}

tree::TerminalNode* PnfGoParser::TypeSwitchGuardContext::L_PAREN() {
  return getToken(PnfGoParser::L_PAREN, 0);
}

tree::TerminalNode* PnfGoParser::TypeSwitchGuardContext::TYPE() {
  return getToken(PnfGoParser::TYPE, 0);
}

tree::TerminalNode* PnfGoParser::TypeSwitchGuardContext::R_PAREN() {
  return getToken(PnfGoParser::R_PAREN, 0);
}


size_t PnfGoParser::TypeSwitchGuardContext::getRuleIndex() const {
  return PnfGoParser::RuleTypeSwitchGuard;
}

void PnfGoParser::TypeSwitchGuardContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterTypeSwitchGuard(this);
}

void PnfGoParser::TypeSwitchGuardContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitTypeSwitchGuard(this);
}


antlrcpp::Any PnfGoParser::TypeSwitchGuardContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitTypeSwitchGuard(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::TypeSwitchGuardContext* PnfGoParser::typeSwitchGuard() {
  TypeSwitchGuardContext *_localctx = _tracker.createInstance<TypeSwitchGuardContext>(_ctx, getState());
  enterRule(_localctx, 80, PnfGoParser::RuleTypeSwitchGuard);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(575);
    optional__typeSwitchGuard_2();
    setState(576);
    primaryExpr();
    setState(577);
    match(PnfGoParser::DOT);
    setState(578);
    match(PnfGoParser::L_PAREN);
    setState(579);
    match(PnfGoParser::TYPE);
    setState(580);
    match(PnfGoParser::R_PAREN);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- TypeCaseClauseContext ------------------------------------------------------------------

PnfGoParser::TypeCaseClauseContext::TypeCaseClauseContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::TypeSwitchCaseContext* PnfGoParser::TypeCaseClauseContext::typeSwitchCase() {
  return getRuleContext<PnfGoParser::TypeSwitchCaseContext>(0);
}

tree::TerminalNode* PnfGoParser::TypeCaseClauseContext::COLON() {
  return getToken(PnfGoParser::COLON, 0);
}

PnfGoParser::Optional__block_1Context* PnfGoParser::TypeCaseClauseContext::optional__block_1() {
  return getRuleContext<PnfGoParser::Optional__block_1Context>(0);
}


size_t PnfGoParser::TypeCaseClauseContext::getRuleIndex() const {
  return PnfGoParser::RuleTypeCaseClause;
}

void PnfGoParser::TypeCaseClauseContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterTypeCaseClause(this);
}

void PnfGoParser::TypeCaseClauseContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitTypeCaseClause(this);
}


antlrcpp::Any PnfGoParser::TypeCaseClauseContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitTypeCaseClause(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::TypeCaseClauseContext* PnfGoParser::typeCaseClause() {
  TypeCaseClauseContext *_localctx = _tracker.createInstance<TypeCaseClauseContext>(_ctx, getState());
  enterRule(_localctx, 82, PnfGoParser::RuleTypeCaseClause);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(582);
    typeSwitchCase();
    setState(583);
    match(PnfGoParser::COLON);
    setState(584);
    optional__block_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- TypeSwitchCaseContext ------------------------------------------------------------------

PnfGoParser::TypeSwitchCaseContext::TypeSwitchCaseContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Aux_rule__typeSwitchCase_1Context* PnfGoParser::TypeSwitchCaseContext::aux_rule__typeSwitchCase_1() {
  return getRuleContext<PnfGoParser::Aux_rule__typeSwitchCase_1Context>(0);
}

tree::TerminalNode* PnfGoParser::TypeSwitchCaseContext::DEFAULT() {
  return getToken(PnfGoParser::DEFAULT, 0);
}


size_t PnfGoParser::TypeSwitchCaseContext::getRuleIndex() const {
  return PnfGoParser::RuleTypeSwitchCase;
}

void PnfGoParser::TypeSwitchCaseContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterTypeSwitchCase(this);
}

void PnfGoParser::TypeSwitchCaseContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitTypeSwitchCase(this);
}


antlrcpp::Any PnfGoParser::TypeSwitchCaseContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitTypeSwitchCase(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::TypeSwitchCaseContext* PnfGoParser::typeSwitchCase() {
  TypeSwitchCaseContext *_localctx = _tracker.createInstance<TypeSwitchCaseContext>(_ctx, getState());
  enterRule(_localctx, 84, PnfGoParser::RuleTypeSwitchCase);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(588);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case PnfGoParser::CASE: {
        enterOuterAlt(_localctx, 1);
        setState(586);
        aux_rule__typeSwitchCase_1();
        break;
      }

      case PnfGoParser::DEFAULT: {
        enterOuterAlt(_localctx, 2);
        setState(587);
        match(PnfGoParser::DEFAULT);
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- TypeListContext ------------------------------------------------------------------

PnfGoParser::TypeListContext::TypeListContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Altnt_block__typeList_3Context* PnfGoParser::TypeListContext::altnt_block__typeList_3() {
  return getRuleContext<PnfGoParser::Altnt_block__typeList_3Context>(0);
}

PnfGoParser::Kleene_star__typeList_2Context* PnfGoParser::TypeListContext::kleene_star__typeList_2() {
  return getRuleContext<PnfGoParser::Kleene_star__typeList_2Context>(0);
}


size_t PnfGoParser::TypeListContext::getRuleIndex() const {
  return PnfGoParser::RuleTypeList;
}

void PnfGoParser::TypeListContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterTypeList(this);
}

void PnfGoParser::TypeListContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitTypeList(this);
}


antlrcpp::Any PnfGoParser::TypeListContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitTypeList(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::TypeListContext* PnfGoParser::typeList() {
  TypeListContext *_localctx = _tracker.createInstance<TypeListContext>(_ctx, getState());
  enterRule(_localctx, 86, PnfGoParser::RuleTypeList);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(590);
    altnt_block__typeList_3();
    setState(591);
    kleene_star__typeList_2();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- SelectStmtContext ------------------------------------------------------------------

PnfGoParser::SelectStmtContext::SelectStmtContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::SelectStmtContext::SELECT() {
  return getToken(PnfGoParser::SELECT, 0);
}

tree::TerminalNode* PnfGoParser::SelectStmtContext::L_CURLY() {
  return getToken(PnfGoParser::L_CURLY, 0);
}

PnfGoParser::Kleene_star__selectStmt_1Context* PnfGoParser::SelectStmtContext::kleene_star__selectStmt_1() {
  return getRuleContext<PnfGoParser::Kleene_star__selectStmt_1Context>(0);
}

tree::TerminalNode* PnfGoParser::SelectStmtContext::R_CURLY() {
  return getToken(PnfGoParser::R_CURLY, 0);
}


size_t PnfGoParser::SelectStmtContext::getRuleIndex() const {
  return PnfGoParser::RuleSelectStmt;
}

void PnfGoParser::SelectStmtContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterSelectStmt(this);
}

void PnfGoParser::SelectStmtContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitSelectStmt(this);
}


antlrcpp::Any PnfGoParser::SelectStmtContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitSelectStmt(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::SelectStmtContext* PnfGoParser::selectStmt() {
  SelectStmtContext *_localctx = _tracker.createInstance<SelectStmtContext>(_ctx, getState());
  enterRule(_localctx, 88, PnfGoParser::RuleSelectStmt);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(593);
    match(PnfGoParser::SELECT);
    setState(594);
    match(PnfGoParser::L_CURLY);
    setState(595);
    kleene_star__selectStmt_1();
    setState(596);
    match(PnfGoParser::R_CURLY);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- CommClauseContext ------------------------------------------------------------------

PnfGoParser::CommClauseContext::CommClauseContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::CommCaseContext* PnfGoParser::CommClauseContext::commCase() {
  return getRuleContext<PnfGoParser::CommCaseContext>(0);
}

tree::TerminalNode* PnfGoParser::CommClauseContext::COLON() {
  return getToken(PnfGoParser::COLON, 0);
}

PnfGoParser::Optional__block_1Context* PnfGoParser::CommClauseContext::optional__block_1() {
  return getRuleContext<PnfGoParser::Optional__block_1Context>(0);
}


size_t PnfGoParser::CommClauseContext::getRuleIndex() const {
  return PnfGoParser::RuleCommClause;
}

void PnfGoParser::CommClauseContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterCommClause(this);
}

void PnfGoParser::CommClauseContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitCommClause(this);
}


antlrcpp::Any PnfGoParser::CommClauseContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitCommClause(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::CommClauseContext* PnfGoParser::commClause() {
  CommClauseContext *_localctx = _tracker.createInstance<CommClauseContext>(_ctx, getState());
  enterRule(_localctx, 90, PnfGoParser::RuleCommClause);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(598);
    commCase();
    setState(599);
    match(PnfGoParser::COLON);
    setState(600);
    optional__block_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- CommCaseContext ------------------------------------------------------------------

PnfGoParser::CommCaseContext::CommCaseContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Aux_rule__commCase_2Context* PnfGoParser::CommCaseContext::aux_rule__commCase_2() {
  return getRuleContext<PnfGoParser::Aux_rule__commCase_2Context>(0);
}

tree::TerminalNode* PnfGoParser::CommCaseContext::DEFAULT() {
  return getToken(PnfGoParser::DEFAULT, 0);
}


size_t PnfGoParser::CommCaseContext::getRuleIndex() const {
  return PnfGoParser::RuleCommCase;
}

void PnfGoParser::CommCaseContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterCommCase(this);
}

void PnfGoParser::CommCaseContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitCommCase(this);
}


antlrcpp::Any PnfGoParser::CommCaseContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitCommCase(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::CommCaseContext* PnfGoParser::commCase() {
  CommCaseContext *_localctx = _tracker.createInstance<CommCaseContext>(_ctx, getState());
  enterRule(_localctx, 92, PnfGoParser::RuleCommCase);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(604);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case PnfGoParser::CASE: {
        enterOuterAlt(_localctx, 1);
        setState(602);
        aux_rule__commCase_2();
        break;
      }

      case PnfGoParser::DEFAULT: {
        enterOuterAlt(_localctx, 2);
        setState(603);
        match(PnfGoParser::DEFAULT);
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- RecvStmtContext ------------------------------------------------------------------

PnfGoParser::RecvStmtContext::RecvStmtContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Optional__recvStmt_2Context* PnfGoParser::RecvStmtContext::optional__recvStmt_2() {
  return getRuleContext<PnfGoParser::Optional__recvStmt_2Context>(0);
}

PnfGoParser::ExpressionContext* PnfGoParser::RecvStmtContext::expression() {
  return getRuleContext<PnfGoParser::ExpressionContext>(0);
}


size_t PnfGoParser::RecvStmtContext::getRuleIndex() const {
  return PnfGoParser::RuleRecvStmt;
}

void PnfGoParser::RecvStmtContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterRecvStmt(this);
}

void PnfGoParser::RecvStmtContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitRecvStmt(this);
}


antlrcpp::Any PnfGoParser::RecvStmtContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitRecvStmt(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::RecvStmtContext* PnfGoParser::recvStmt() {
  RecvStmtContext *_localctx = _tracker.createInstance<RecvStmtContext>(_ctx, getState());
  enterRule(_localctx, 94, PnfGoParser::RuleRecvStmt);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(606);
    optional__recvStmt_2();
    setState(607);
    expression();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ForStmtContext ------------------------------------------------------------------

PnfGoParser::ForStmtContext::ForStmtContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::ForStmtContext::FOR() {
  return getToken(PnfGoParser::FOR, 0);
}

PnfGoParser::Optional__forStmt_2Context* PnfGoParser::ForStmtContext::optional__forStmt_2() {
  return getRuleContext<PnfGoParser::Optional__forStmt_2Context>(0);
}

PnfGoParser::BlockContext* PnfGoParser::ForStmtContext::block() {
  return getRuleContext<PnfGoParser::BlockContext>(0);
}


size_t PnfGoParser::ForStmtContext::getRuleIndex() const {
  return PnfGoParser::RuleForStmt;
}

void PnfGoParser::ForStmtContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterForStmt(this);
}

void PnfGoParser::ForStmtContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitForStmt(this);
}


antlrcpp::Any PnfGoParser::ForStmtContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitForStmt(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::ForStmtContext* PnfGoParser::forStmt() {
  ForStmtContext *_localctx = _tracker.createInstance<ForStmtContext>(_ctx, getState());
  enterRule(_localctx, 96, PnfGoParser::RuleForStmt);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(609);
    match(PnfGoParser::FOR);
    setState(610);
    optional__forStmt_2();
    setState(611);
    block();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ForClauseContext ------------------------------------------------------------------

PnfGoParser::ForClauseContext::ForClauseContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfGoParser::Optional__forClause_1Context *> PnfGoParser::ForClauseContext::optional__forClause_1() {
  return getRuleContexts<PnfGoParser::Optional__forClause_1Context>();
}

PnfGoParser::Optional__forClause_1Context* PnfGoParser::ForClauseContext::optional__forClause_1(size_t i) {
  return getRuleContext<PnfGoParser::Optional__forClause_1Context>(i);
}

std::vector<tree::TerminalNode *> PnfGoParser::ForClauseContext::SEMI() {
  return getTokens(PnfGoParser::SEMI);
}

tree::TerminalNode* PnfGoParser::ForClauseContext::SEMI(size_t i) {
  return getToken(PnfGoParser::SEMI, i);
}

PnfGoParser::Optional__exprSwitchStmt_3Context* PnfGoParser::ForClauseContext::optional__exprSwitchStmt_3() {
  return getRuleContext<PnfGoParser::Optional__exprSwitchStmt_3Context>(0);
}


size_t PnfGoParser::ForClauseContext::getRuleIndex() const {
  return PnfGoParser::RuleForClause;
}

void PnfGoParser::ForClauseContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterForClause(this);
}

void PnfGoParser::ForClauseContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitForClause(this);
}


antlrcpp::Any PnfGoParser::ForClauseContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitForClause(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::ForClauseContext* PnfGoParser::forClause() {
  ForClauseContext *_localctx = _tracker.createInstance<ForClauseContext>(_ctx, getState());
  enterRule(_localctx, 98, PnfGoParser::RuleForClause);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(613);
    optional__forClause_1();
    setState(614);
    match(PnfGoParser::SEMI);
    setState(615);
    optional__exprSwitchStmt_3();
    setState(616);
    match(PnfGoParser::SEMI);
    setState(617);
    optional__forClause_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- RangeClauseContext ------------------------------------------------------------------

PnfGoParser::RangeClauseContext::RangeClauseContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Optional__recvStmt_2Context* PnfGoParser::RangeClauseContext::optional__recvStmt_2() {
  return getRuleContext<PnfGoParser::Optional__recvStmt_2Context>(0);
}

tree::TerminalNode* PnfGoParser::RangeClauseContext::RANGE() {
  return getToken(PnfGoParser::RANGE, 0);
}

PnfGoParser::ExpressionContext* PnfGoParser::RangeClauseContext::expression() {
  return getRuleContext<PnfGoParser::ExpressionContext>(0);
}


size_t PnfGoParser::RangeClauseContext::getRuleIndex() const {
  return PnfGoParser::RuleRangeClause;
}

void PnfGoParser::RangeClauseContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterRangeClause(this);
}

void PnfGoParser::RangeClauseContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitRangeClause(this);
}


antlrcpp::Any PnfGoParser::RangeClauseContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitRangeClause(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::RangeClauseContext* PnfGoParser::rangeClause() {
  RangeClauseContext *_localctx = _tracker.createInstance<RangeClauseContext>(_ctx, getState());
  enterRule(_localctx, 100, PnfGoParser::RuleRangeClause);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(619);
    optional__recvStmt_2();
    setState(620);
    match(PnfGoParser::RANGE);
    setState(621);
    expression();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- GoStmtContext ------------------------------------------------------------------

PnfGoParser::GoStmtContext::GoStmtContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::GoStmtContext::GO() {
  return getToken(PnfGoParser::GO, 0);
}

PnfGoParser::ExpressionContext* PnfGoParser::GoStmtContext::expression() {
  return getRuleContext<PnfGoParser::ExpressionContext>(0);
}


size_t PnfGoParser::GoStmtContext::getRuleIndex() const {
  return PnfGoParser::RuleGoStmt;
}

void PnfGoParser::GoStmtContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterGoStmt(this);
}

void PnfGoParser::GoStmtContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitGoStmt(this);
}


antlrcpp::Any PnfGoParser::GoStmtContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitGoStmt(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::GoStmtContext* PnfGoParser::goStmt() {
  GoStmtContext *_localctx = _tracker.createInstance<GoStmtContext>(_ctx, getState());
  enterRule(_localctx, 102, PnfGoParser::RuleGoStmt);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(623);
    match(PnfGoParser::GO);
    setState(624);
    expression();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- TypeNameContext ------------------------------------------------------------------

PnfGoParser::TypeNameContext::TypeNameContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::TypeNameContext::IDENTIFIER() {
  return getToken(PnfGoParser::IDENTIFIER, 0);
}

PnfGoParser::QualifiedIdentContext* PnfGoParser::TypeNameContext::qualifiedIdent() {
  return getRuleContext<PnfGoParser::QualifiedIdentContext>(0);
}


size_t PnfGoParser::TypeNameContext::getRuleIndex() const {
  return PnfGoParser::RuleTypeName;
}

void PnfGoParser::TypeNameContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterTypeName(this);
}

void PnfGoParser::TypeNameContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitTypeName(this);
}


antlrcpp::Any PnfGoParser::TypeNameContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitTypeName(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::TypeNameContext* PnfGoParser::typeName() {
  TypeNameContext *_localctx = _tracker.createInstance<TypeNameContext>(_ctx, getState());
  enterRule(_localctx, 104, PnfGoParser::RuleTypeName);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(628);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 9, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(626);
      match(PnfGoParser::IDENTIFIER);
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(627);
      qualifiedIdent();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ArrayTypeContext ------------------------------------------------------------------

PnfGoParser::ArrayTypeContext::ArrayTypeContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::ArrayTypeContext::L_BRACKET() {
  return getToken(PnfGoParser::L_BRACKET, 0);
}

PnfGoParser::ExpressionStmtContext* PnfGoParser::ArrayTypeContext::expressionStmt() {
  return getRuleContext<PnfGoParser::ExpressionStmtContext>(0);
}

tree::TerminalNode* PnfGoParser::ArrayTypeContext::R_BRACKET() {
  return getToken(PnfGoParser::R_BRACKET, 0);
}

PnfGoParser::ElementTypeContext* PnfGoParser::ArrayTypeContext::elementType() {
  return getRuleContext<PnfGoParser::ElementTypeContext>(0);
}


size_t PnfGoParser::ArrayTypeContext::getRuleIndex() const {
  return PnfGoParser::RuleArrayType;
}

void PnfGoParser::ArrayTypeContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterArrayType(this);
}

void PnfGoParser::ArrayTypeContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitArrayType(this);
}


antlrcpp::Any PnfGoParser::ArrayTypeContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitArrayType(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::ArrayTypeContext* PnfGoParser::arrayType() {
  ArrayTypeContext *_localctx = _tracker.createInstance<ArrayTypeContext>(_ctx, getState());
  enterRule(_localctx, 106, PnfGoParser::RuleArrayType);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(630);
    match(PnfGoParser::L_BRACKET);
    setState(631);
    expressionStmt();
    setState(632);
    match(PnfGoParser::R_BRACKET);
    setState(633);
    elementType();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ElementTypeContext ------------------------------------------------------------------

PnfGoParser::ElementTypeContext::ElementTypeContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Type_Context* PnfGoParser::ElementTypeContext::type_() {
  return getRuleContext<PnfGoParser::Type_Context>(0);
}


size_t PnfGoParser::ElementTypeContext::getRuleIndex() const {
  return PnfGoParser::RuleElementType;
}

void PnfGoParser::ElementTypeContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterElementType(this);
}

void PnfGoParser::ElementTypeContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitElementType(this);
}


antlrcpp::Any PnfGoParser::ElementTypeContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitElementType(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::ElementTypeContext* PnfGoParser::elementType() {
  ElementTypeContext *_localctx = _tracker.createInstance<ElementTypeContext>(_ctx, getState());
  enterRule(_localctx, 108, PnfGoParser::RuleElementType);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(635);
    type_();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- PointerTypeContext ------------------------------------------------------------------

PnfGoParser::PointerTypeContext::PointerTypeContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::PointerTypeContext::STAR() {
  return getToken(PnfGoParser::STAR, 0);
}

PnfGoParser::Type_Context* PnfGoParser::PointerTypeContext::type_() {
  return getRuleContext<PnfGoParser::Type_Context>(0);
}


size_t PnfGoParser::PointerTypeContext::getRuleIndex() const {
  return PnfGoParser::RulePointerType;
}

void PnfGoParser::PointerTypeContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterPointerType(this);
}

void PnfGoParser::PointerTypeContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitPointerType(this);
}


antlrcpp::Any PnfGoParser::PointerTypeContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitPointerType(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::PointerTypeContext* PnfGoParser::pointerType() {
  PointerTypeContext *_localctx = _tracker.createInstance<PointerTypeContext>(_ctx, getState());
  enterRule(_localctx, 110, PnfGoParser::RulePointerType);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(637);
    match(PnfGoParser::STAR);
    setState(638);
    type_();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- InterfaceTypeContext ------------------------------------------------------------------

PnfGoParser::InterfaceTypeContext::InterfaceTypeContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::InterfaceTypeContext::INTERFACE() {
  return getToken(PnfGoParser::INTERFACE, 0);
}

tree::TerminalNode* PnfGoParser::InterfaceTypeContext::L_CURLY() {
  return getToken(PnfGoParser::L_CURLY, 0);
}

PnfGoParser::Kleene_star__interfaceType_2Context* PnfGoParser::InterfaceTypeContext::kleene_star__interfaceType_2() {
  return getRuleContext<PnfGoParser::Kleene_star__interfaceType_2Context>(0);
}

tree::TerminalNode* PnfGoParser::InterfaceTypeContext::R_CURLY() {
  return getToken(PnfGoParser::R_CURLY, 0);
}


size_t PnfGoParser::InterfaceTypeContext::getRuleIndex() const {
  return PnfGoParser::RuleInterfaceType;
}

void PnfGoParser::InterfaceTypeContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterInterfaceType(this);
}

void PnfGoParser::InterfaceTypeContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitInterfaceType(this);
}


antlrcpp::Any PnfGoParser::InterfaceTypeContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitInterfaceType(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::InterfaceTypeContext* PnfGoParser::interfaceType() {
  InterfaceTypeContext *_localctx = _tracker.createInstance<InterfaceTypeContext>(_ctx, getState());
  enterRule(_localctx, 112, PnfGoParser::RuleInterfaceType);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(640);
    match(PnfGoParser::INTERFACE);
    setState(641);
    match(PnfGoParser::L_CURLY);
    setState(642);
    kleene_star__interfaceType_2();
    setState(643);
    match(PnfGoParser::R_CURLY);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- SliceTypeContext ------------------------------------------------------------------

PnfGoParser::SliceTypeContext::SliceTypeContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::SliceTypeContext::L_BRACKET() {
  return getToken(PnfGoParser::L_BRACKET, 0);
}

tree::TerminalNode* PnfGoParser::SliceTypeContext::R_BRACKET() {
  return getToken(PnfGoParser::R_BRACKET, 0);
}

PnfGoParser::ElementTypeContext* PnfGoParser::SliceTypeContext::elementType() {
  return getRuleContext<PnfGoParser::ElementTypeContext>(0);
}


size_t PnfGoParser::SliceTypeContext::getRuleIndex() const {
  return PnfGoParser::RuleSliceType;
}

void PnfGoParser::SliceTypeContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterSliceType(this);
}

void PnfGoParser::SliceTypeContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitSliceType(this);
}


antlrcpp::Any PnfGoParser::SliceTypeContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitSliceType(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::SliceTypeContext* PnfGoParser::sliceType() {
  SliceTypeContext *_localctx = _tracker.createInstance<SliceTypeContext>(_ctx, getState());
  enterRule(_localctx, 114, PnfGoParser::RuleSliceType);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(645);
    match(PnfGoParser::L_BRACKET);
    setState(646);
    match(PnfGoParser::R_BRACKET);
    setState(647);
    elementType();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- MapTypeContext ------------------------------------------------------------------

PnfGoParser::MapTypeContext::MapTypeContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::MapTypeContext::MAP() {
  return getToken(PnfGoParser::MAP, 0);
}

tree::TerminalNode* PnfGoParser::MapTypeContext::L_BRACKET() {
  return getToken(PnfGoParser::L_BRACKET, 0);
}

PnfGoParser::Type_Context* PnfGoParser::MapTypeContext::type_() {
  return getRuleContext<PnfGoParser::Type_Context>(0);
}

tree::TerminalNode* PnfGoParser::MapTypeContext::R_BRACKET() {
  return getToken(PnfGoParser::R_BRACKET, 0);
}

PnfGoParser::ElementTypeContext* PnfGoParser::MapTypeContext::elementType() {
  return getRuleContext<PnfGoParser::ElementTypeContext>(0);
}


size_t PnfGoParser::MapTypeContext::getRuleIndex() const {
  return PnfGoParser::RuleMapType;
}

void PnfGoParser::MapTypeContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterMapType(this);
}

void PnfGoParser::MapTypeContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitMapType(this);
}


antlrcpp::Any PnfGoParser::MapTypeContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitMapType(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::MapTypeContext* PnfGoParser::mapType() {
  MapTypeContext *_localctx = _tracker.createInstance<MapTypeContext>(_ctx, getState());
  enterRule(_localctx, 116, PnfGoParser::RuleMapType);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(649);
    match(PnfGoParser::MAP);
    setState(650);
    match(PnfGoParser::L_BRACKET);
    setState(651);
    type_();
    setState(652);
    match(PnfGoParser::R_BRACKET);
    setState(653);
    elementType();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ChannelTypeContext ------------------------------------------------------------------

PnfGoParser::ChannelTypeContext::ChannelTypeContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Altnt_block__channelType_1Context* PnfGoParser::ChannelTypeContext::altnt_block__channelType_1() {
  return getRuleContext<PnfGoParser::Altnt_block__channelType_1Context>(0);
}

PnfGoParser::ElementTypeContext* PnfGoParser::ChannelTypeContext::elementType() {
  return getRuleContext<PnfGoParser::ElementTypeContext>(0);
}


size_t PnfGoParser::ChannelTypeContext::getRuleIndex() const {
  return PnfGoParser::RuleChannelType;
}

void PnfGoParser::ChannelTypeContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterChannelType(this);
}

void PnfGoParser::ChannelTypeContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitChannelType(this);
}


antlrcpp::Any PnfGoParser::ChannelTypeContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitChannelType(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::ChannelTypeContext* PnfGoParser::channelType() {
  ChannelTypeContext *_localctx = _tracker.createInstance<ChannelTypeContext>(_ctx, getState());
  enterRule(_localctx, 118, PnfGoParser::RuleChannelType);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(655);
    altnt_block__channelType_1();
    setState(656);
    elementType();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- MethodSpecContext ------------------------------------------------------------------

PnfGoParser::MethodSpecContext::MethodSpecContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Aux_rule__methodSpec_2Context* PnfGoParser::MethodSpecContext::aux_rule__methodSpec_2() {
  return getRuleContext<PnfGoParser::Aux_rule__methodSpec_2Context>(0);
}

PnfGoParser::TypeNameContext* PnfGoParser::MethodSpecContext::typeName() {
  return getRuleContext<PnfGoParser::TypeNameContext>(0);
}


size_t PnfGoParser::MethodSpecContext::getRuleIndex() const {
  return PnfGoParser::RuleMethodSpec;
}

void PnfGoParser::MethodSpecContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterMethodSpec(this);
}

void PnfGoParser::MethodSpecContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitMethodSpec(this);
}


antlrcpp::Any PnfGoParser::MethodSpecContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitMethodSpec(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::MethodSpecContext* PnfGoParser::methodSpec() {
  MethodSpecContext *_localctx = _tracker.createInstance<MethodSpecContext>(_ctx, getState());
  enterRule(_localctx, 120, PnfGoParser::RuleMethodSpec);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(660);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 10, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(658);
      aux_rule__methodSpec_2();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(659);
      typeName();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- FunctionTypeContext ------------------------------------------------------------------

PnfGoParser::FunctionTypeContext::FunctionTypeContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::FunctionTypeContext::FUNC() {
  return getToken(PnfGoParser::FUNC, 0);
}

PnfGoParser::SignatureContext* PnfGoParser::FunctionTypeContext::signature() {
  return getRuleContext<PnfGoParser::SignatureContext>(0);
}


size_t PnfGoParser::FunctionTypeContext::getRuleIndex() const {
  return PnfGoParser::RuleFunctionType;
}

void PnfGoParser::FunctionTypeContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterFunctionType(this);
}

void PnfGoParser::FunctionTypeContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitFunctionType(this);
}


antlrcpp::Any PnfGoParser::FunctionTypeContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitFunctionType(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::FunctionTypeContext* PnfGoParser::functionType() {
  FunctionTypeContext *_localctx = _tracker.createInstance<FunctionTypeContext>(_ctx, getState());
  enterRule(_localctx, 122, PnfGoParser::RuleFunctionType);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(662);
    match(PnfGoParser::FUNC);
    setState(663);
    signature();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- SignatureContext ------------------------------------------------------------------

PnfGoParser::SignatureContext::SignatureContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::ParametersContext* PnfGoParser::SignatureContext::parameters() {
  return getRuleContext<PnfGoParser::ParametersContext>(0);
}

PnfGoParser::Optional__signature_1Context* PnfGoParser::SignatureContext::optional__signature_1() {
  return getRuleContext<PnfGoParser::Optional__signature_1Context>(0);
}


size_t PnfGoParser::SignatureContext::getRuleIndex() const {
  return PnfGoParser::RuleSignature;
}

void PnfGoParser::SignatureContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterSignature(this);
}

void PnfGoParser::SignatureContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitSignature(this);
}


antlrcpp::Any PnfGoParser::SignatureContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitSignature(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::SignatureContext* PnfGoParser::signature() {
  SignatureContext *_localctx = _tracker.createInstance<SignatureContext>(_ctx, getState());
  enterRule(_localctx, 124, PnfGoParser::RuleSignature);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(665);
    parameters();
    setState(666);
    optional__signature_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ResultContext ------------------------------------------------------------------

PnfGoParser::ResultContext::ResultContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::ParametersContext* PnfGoParser::ResultContext::parameters() {
  return getRuleContext<PnfGoParser::ParametersContext>(0);
}

PnfGoParser::Type_Context* PnfGoParser::ResultContext::type_() {
  return getRuleContext<PnfGoParser::Type_Context>(0);
}


size_t PnfGoParser::ResultContext::getRuleIndex() const {
  return PnfGoParser::RuleResult;
}

void PnfGoParser::ResultContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterResult(this);
}

void PnfGoParser::ResultContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitResult(this);
}


antlrcpp::Any PnfGoParser::ResultContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitResult(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::ResultContext* PnfGoParser::result() {
  ResultContext *_localctx = _tracker.createInstance<ResultContext>(_ctx, getState());
  enterRule(_localctx, 126, PnfGoParser::RuleResult);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(670);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 11, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(668);
      parameters();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(669);
      type_();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ParametersContext ------------------------------------------------------------------

PnfGoParser::ParametersContext::ParametersContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::ParametersContext::L_PAREN() {
  return getToken(PnfGoParser::L_PAREN, 0);
}

PnfGoParser::Optional__parameters_5Context* PnfGoParser::ParametersContext::optional__parameters_5() {
  return getRuleContext<PnfGoParser::Optional__parameters_5Context>(0);
}

tree::TerminalNode* PnfGoParser::ParametersContext::R_PAREN() {
  return getToken(PnfGoParser::R_PAREN, 0);
}


size_t PnfGoParser::ParametersContext::getRuleIndex() const {
  return PnfGoParser::RuleParameters;
}

void PnfGoParser::ParametersContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterParameters(this);
}

void PnfGoParser::ParametersContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitParameters(this);
}


antlrcpp::Any PnfGoParser::ParametersContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitParameters(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::ParametersContext* PnfGoParser::parameters() {
  ParametersContext *_localctx = _tracker.createInstance<ParametersContext>(_ctx, getState());
  enterRule(_localctx, 128, PnfGoParser::RuleParameters);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(672);
    match(PnfGoParser::L_PAREN);
    setState(673);
    optional__parameters_5();
    setState(674);
    match(PnfGoParser::R_PAREN);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ParameterDeclContext ------------------------------------------------------------------

PnfGoParser::ParameterDeclContext::ParameterDeclContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Optional__parameterDecl_1Context* PnfGoParser::ParameterDeclContext::optional__parameterDecl_1() {
  return getRuleContext<PnfGoParser::Optional__parameterDecl_1Context>(0);
}

PnfGoParser::Optional__parameterDecl_2Context* PnfGoParser::ParameterDeclContext::optional__parameterDecl_2() {
  return getRuleContext<PnfGoParser::Optional__parameterDecl_2Context>(0);
}

PnfGoParser::Type_Context* PnfGoParser::ParameterDeclContext::type_() {
  return getRuleContext<PnfGoParser::Type_Context>(0);
}


size_t PnfGoParser::ParameterDeclContext::getRuleIndex() const {
  return PnfGoParser::RuleParameterDecl;
}

void PnfGoParser::ParameterDeclContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterParameterDecl(this);
}

void PnfGoParser::ParameterDeclContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitParameterDecl(this);
}


antlrcpp::Any PnfGoParser::ParameterDeclContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitParameterDecl(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::ParameterDeclContext* PnfGoParser::parameterDecl() {
  ParameterDeclContext *_localctx = _tracker.createInstance<ParameterDeclContext>(_ctx, getState());
  enterRule(_localctx, 130, PnfGoParser::RuleParameterDecl);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(676);
    optional__parameterDecl_1();
    setState(677);
    optional__parameterDecl_2();
    setState(678);
    type_();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- UnaryExprContext ------------------------------------------------------------------

PnfGoParser::UnaryExprContext::UnaryExprContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::PrimaryExprContext* PnfGoParser::UnaryExprContext::primaryExpr() {
  return getRuleContext<PnfGoParser::PrimaryExprContext>(0);
}

PnfGoParser::Aux_rule__unaryExpr_2Context* PnfGoParser::UnaryExprContext::aux_rule__unaryExpr_2() {
  return getRuleContext<PnfGoParser::Aux_rule__unaryExpr_2Context>(0);
}


size_t PnfGoParser::UnaryExprContext::getRuleIndex() const {
  return PnfGoParser::RuleUnaryExpr;
}

void PnfGoParser::UnaryExprContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterUnaryExpr(this);
}

void PnfGoParser::UnaryExprContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitUnaryExpr(this);
}


antlrcpp::Any PnfGoParser::UnaryExprContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitUnaryExpr(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::UnaryExprContext* PnfGoParser::unaryExpr() {
  UnaryExprContext *_localctx = _tracker.createInstance<UnaryExprContext>(_ctx, getState());
  enterRule(_localctx, 132, PnfGoParser::RuleUnaryExpr);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(682);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 12, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(680);
      primaryExpr();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(681);
      aux_rule__unaryExpr_2();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ConversionContext ------------------------------------------------------------------

PnfGoParser::ConversionContext::ConversionContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Type_Context* PnfGoParser::ConversionContext::type_() {
  return getRuleContext<PnfGoParser::Type_Context>(0);
}

tree::TerminalNode* PnfGoParser::ConversionContext::L_PAREN() {
  return getToken(PnfGoParser::L_PAREN, 0);
}

PnfGoParser::ExpressionContext* PnfGoParser::ConversionContext::expression() {
  return getRuleContext<PnfGoParser::ExpressionContext>(0);
}

PnfGoParser::Optional__conversion_1Context* PnfGoParser::ConversionContext::optional__conversion_1() {
  return getRuleContext<PnfGoParser::Optional__conversion_1Context>(0);
}

tree::TerminalNode* PnfGoParser::ConversionContext::R_PAREN() {
  return getToken(PnfGoParser::R_PAREN, 0);
}


size_t PnfGoParser::ConversionContext::getRuleIndex() const {
  return PnfGoParser::RuleConversion;
}

void PnfGoParser::ConversionContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterConversion(this);
}

void PnfGoParser::ConversionContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitConversion(this);
}


antlrcpp::Any PnfGoParser::ConversionContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitConversion(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::ConversionContext* PnfGoParser::conversion() {
  ConversionContext *_localctx = _tracker.createInstance<ConversionContext>(_ctx, getState());
  enterRule(_localctx, 134, PnfGoParser::RuleConversion);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(684);
    type_();
    setState(685);
    match(PnfGoParser::L_PAREN);
    setState(686);
    expression();
    setState(687);
    optional__conversion_1();
    setState(688);
    match(PnfGoParser::R_PAREN);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- QualifiedIdentContext ------------------------------------------------------------------

PnfGoParser::QualifiedIdentContext::QualifiedIdentContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<tree::TerminalNode *> PnfGoParser::QualifiedIdentContext::IDENTIFIER() {
  return getTokens(PnfGoParser::IDENTIFIER);
}

tree::TerminalNode* PnfGoParser::QualifiedIdentContext::IDENTIFIER(size_t i) {
  return getToken(PnfGoParser::IDENTIFIER, i);
}

tree::TerminalNode* PnfGoParser::QualifiedIdentContext::DOT() {
  return getToken(PnfGoParser::DOT, 0);
}


size_t PnfGoParser::QualifiedIdentContext::getRuleIndex() const {
  return PnfGoParser::RuleQualifiedIdent;
}

void PnfGoParser::QualifiedIdentContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterQualifiedIdent(this);
}

void PnfGoParser::QualifiedIdentContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitQualifiedIdent(this);
}


antlrcpp::Any PnfGoParser::QualifiedIdentContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitQualifiedIdent(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::QualifiedIdentContext* PnfGoParser::qualifiedIdent() {
  QualifiedIdentContext *_localctx = _tracker.createInstance<QualifiedIdentContext>(_ctx, getState());
  enterRule(_localctx, 136, PnfGoParser::RuleQualifiedIdent);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(690);
    match(PnfGoParser::IDENTIFIER);
    setState(691);
    match(PnfGoParser::DOT);
    setState(692);
    match(PnfGoParser::IDENTIFIER);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- CompositeLitContext ------------------------------------------------------------------

PnfGoParser::CompositeLitContext::CompositeLitContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::LiteralTypeContext* PnfGoParser::CompositeLitContext::literalType() {
  return getRuleContext<PnfGoParser::LiteralTypeContext>(0);
}

PnfGoParser::LiteralValueContext* PnfGoParser::CompositeLitContext::literalValue() {
  return getRuleContext<PnfGoParser::LiteralValueContext>(0);
}


size_t PnfGoParser::CompositeLitContext::getRuleIndex() const {
  return PnfGoParser::RuleCompositeLit;
}

void PnfGoParser::CompositeLitContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterCompositeLit(this);
}

void PnfGoParser::CompositeLitContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitCompositeLit(this);
}


antlrcpp::Any PnfGoParser::CompositeLitContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitCompositeLit(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::CompositeLitContext* PnfGoParser::compositeLit() {
  CompositeLitContext *_localctx = _tracker.createInstance<CompositeLitContext>(_ctx, getState());
  enterRule(_localctx, 138, PnfGoParser::RuleCompositeLit);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(694);
    literalType();
    setState(695);
    literalValue();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- LiteralTypeContext ------------------------------------------------------------------

PnfGoParser::LiteralTypeContext::LiteralTypeContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::StructTypeContext* PnfGoParser::LiteralTypeContext::structType() {
  return getRuleContext<PnfGoParser::StructTypeContext>(0);
}

PnfGoParser::ArrayTypeContext* PnfGoParser::LiteralTypeContext::arrayType() {
  return getRuleContext<PnfGoParser::ArrayTypeContext>(0);
}

PnfGoParser::Aux_rule__literalType_1Context* PnfGoParser::LiteralTypeContext::aux_rule__literalType_1() {
  return getRuleContext<PnfGoParser::Aux_rule__literalType_1Context>(0);
}

PnfGoParser::SliceTypeContext* PnfGoParser::LiteralTypeContext::sliceType() {
  return getRuleContext<PnfGoParser::SliceTypeContext>(0);
}

PnfGoParser::MapTypeContext* PnfGoParser::LiteralTypeContext::mapType() {
  return getRuleContext<PnfGoParser::MapTypeContext>(0);
}

PnfGoParser::TypeNameContext* PnfGoParser::LiteralTypeContext::typeName() {
  return getRuleContext<PnfGoParser::TypeNameContext>(0);
}


size_t PnfGoParser::LiteralTypeContext::getRuleIndex() const {
  return PnfGoParser::RuleLiteralType;
}

void PnfGoParser::LiteralTypeContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterLiteralType(this);
}

void PnfGoParser::LiteralTypeContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitLiteralType(this);
}


antlrcpp::Any PnfGoParser::LiteralTypeContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitLiteralType(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::LiteralTypeContext* PnfGoParser::literalType() {
  LiteralTypeContext *_localctx = _tracker.createInstance<LiteralTypeContext>(_ctx, getState());
  enterRule(_localctx, 140, PnfGoParser::RuleLiteralType);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(703);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 13, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(697);
      structType();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(698);
      arrayType();
      break;
    }

    case 3: {
      enterOuterAlt(_localctx, 3);
      setState(699);
      aux_rule__literalType_1();
      break;
    }

    case 4: {
      enterOuterAlt(_localctx, 4);
      setState(700);
      sliceType();
      break;
    }

    case 5: {
      enterOuterAlt(_localctx, 5);
      setState(701);
      mapType();
      break;
    }

    case 6: {
      enterOuterAlt(_localctx, 6);
      setState(702);
      typeName();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- LiteralValueContext ------------------------------------------------------------------

PnfGoParser::LiteralValueContext::LiteralValueContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::LiteralValueContext::L_CURLY() {
  return getToken(PnfGoParser::L_CURLY, 0);
}

PnfGoParser::Optional__literalValue_3Context* PnfGoParser::LiteralValueContext::optional__literalValue_3() {
  return getRuleContext<PnfGoParser::Optional__literalValue_3Context>(0);
}

tree::TerminalNode* PnfGoParser::LiteralValueContext::R_CURLY() {
  return getToken(PnfGoParser::R_CURLY, 0);
}


size_t PnfGoParser::LiteralValueContext::getRuleIndex() const {
  return PnfGoParser::RuleLiteralValue;
}

void PnfGoParser::LiteralValueContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterLiteralValue(this);
}

void PnfGoParser::LiteralValueContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitLiteralValue(this);
}


antlrcpp::Any PnfGoParser::LiteralValueContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitLiteralValue(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::LiteralValueContext* PnfGoParser::literalValue() {
  LiteralValueContext *_localctx = _tracker.createInstance<LiteralValueContext>(_ctx, getState());
  enterRule(_localctx, 142, PnfGoParser::RuleLiteralValue);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(705);
    match(PnfGoParser::L_CURLY);
    setState(706);
    optional__literalValue_3();
    setState(707);
    match(PnfGoParser::R_CURLY);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ElementListContext ------------------------------------------------------------------

PnfGoParser::ElementListContext::ElementListContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::KeyedElementContext* PnfGoParser::ElementListContext::keyedElement() {
  return getRuleContext<PnfGoParser::KeyedElementContext>(0);
}

PnfGoParser::Kleene_star__elementList_2Context* PnfGoParser::ElementListContext::kleene_star__elementList_2() {
  return getRuleContext<PnfGoParser::Kleene_star__elementList_2Context>(0);
}


size_t PnfGoParser::ElementListContext::getRuleIndex() const {
  return PnfGoParser::RuleElementList;
}

void PnfGoParser::ElementListContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterElementList(this);
}

void PnfGoParser::ElementListContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitElementList(this);
}


antlrcpp::Any PnfGoParser::ElementListContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitElementList(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::ElementListContext* PnfGoParser::elementList() {
  ElementListContext *_localctx = _tracker.createInstance<ElementListContext>(_ctx, getState());
  enterRule(_localctx, 144, PnfGoParser::RuleElementList);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(709);
    keyedElement();
    setState(710);
    kleene_star__elementList_2();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- KeyedElementContext ------------------------------------------------------------------

PnfGoParser::KeyedElementContext::KeyedElementContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Optional__keyedElement_2Context* PnfGoParser::KeyedElementContext::optional__keyedElement_2() {
  return getRuleContext<PnfGoParser::Optional__keyedElement_2Context>(0);
}

PnfGoParser::ElementContext* PnfGoParser::KeyedElementContext::element() {
  return getRuleContext<PnfGoParser::ElementContext>(0);
}


size_t PnfGoParser::KeyedElementContext::getRuleIndex() const {
  return PnfGoParser::RuleKeyedElement;
}

void PnfGoParser::KeyedElementContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKeyedElement(this);
}

void PnfGoParser::KeyedElementContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKeyedElement(this);
}


antlrcpp::Any PnfGoParser::KeyedElementContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitKeyedElement(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::KeyedElementContext* PnfGoParser::keyedElement() {
  KeyedElementContext *_localctx = _tracker.createInstance<KeyedElementContext>(_ctx, getState());
  enterRule(_localctx, 146, PnfGoParser::RuleKeyedElement);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(712);
    optional__keyedElement_2();
    setState(713);
    element();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- KeyContext ------------------------------------------------------------------

PnfGoParser::KeyContext::KeyContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::KeyContext::IDENTIFIER() {
  return getToken(PnfGoParser::IDENTIFIER, 0);
}

PnfGoParser::ExpressionContext* PnfGoParser::KeyContext::expression() {
  return getRuleContext<PnfGoParser::ExpressionContext>(0);
}

PnfGoParser::LiteralValueContext* PnfGoParser::KeyContext::literalValue() {
  return getRuleContext<PnfGoParser::LiteralValueContext>(0);
}


size_t PnfGoParser::KeyContext::getRuleIndex() const {
  return PnfGoParser::RuleKey;
}

void PnfGoParser::KeyContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKey(this);
}

void PnfGoParser::KeyContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKey(this);
}


antlrcpp::Any PnfGoParser::KeyContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitKey(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::KeyContext* PnfGoParser::key() {
  KeyContext *_localctx = _tracker.createInstance<KeyContext>(_ctx, getState());
  enterRule(_localctx, 148, PnfGoParser::RuleKey);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(718);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 14, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(715);
      match(PnfGoParser::IDENTIFIER);
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(716);
      expression();
      break;
    }

    case 3: {
      enterOuterAlt(_localctx, 3);
      setState(717);
      literalValue();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ElementContext ------------------------------------------------------------------

PnfGoParser::ElementContext::ElementContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::ExpressionContext* PnfGoParser::ElementContext::expression() {
  return getRuleContext<PnfGoParser::ExpressionContext>(0);
}

PnfGoParser::LiteralValueContext* PnfGoParser::ElementContext::literalValue() {
  return getRuleContext<PnfGoParser::LiteralValueContext>(0);
}


size_t PnfGoParser::ElementContext::getRuleIndex() const {
  return PnfGoParser::RuleElement;
}

void PnfGoParser::ElementContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterElement(this);
}

void PnfGoParser::ElementContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitElement(this);
}


antlrcpp::Any PnfGoParser::ElementContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitElement(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::ElementContext* PnfGoParser::element() {
  ElementContext *_localctx = _tracker.createInstance<ElementContext>(_ctx, getState());
  enterRule(_localctx, 150, PnfGoParser::RuleElement);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(722);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case PnfGoParser::FUNC:
      case PnfGoParser::INTERFACE:
      case PnfGoParser::MAP:
      case PnfGoParser::STRUCT:
      case PnfGoParser::CHAN:
      case PnfGoParser::NIL_LIT:
      case PnfGoParser::IDENTIFIER:
      case PnfGoParser::L_PAREN:
      case PnfGoParser::L_BRACKET:
      case PnfGoParser::EXCLAMATION:
      case PnfGoParser::PLUS:
      case PnfGoParser::MINUS:
      case PnfGoParser::CARET:
      case PnfGoParser::STAR:
      case PnfGoParser::AMPERSAND:
      case PnfGoParser::RECEIVE:
      case PnfGoParser::DECIMAL_LIT:
      case PnfGoParser::OCTAL_LIT:
      case PnfGoParser::HEX_LIT:
      case PnfGoParser::FLOAT_LIT:
      case PnfGoParser::IMAGINARY_LIT:
      case PnfGoParser::RUNE_LIT:
      case PnfGoParser::RAW_STRING_LIT:
      case PnfGoParser::INTERPRETED_STRING_LIT: {
        enterOuterAlt(_localctx, 1);
        setState(720);
        expression();
        break;
      }

      case PnfGoParser::L_CURLY: {
        enterOuterAlt(_localctx, 2);
        setState(721);
        literalValue();
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- StructTypeContext ------------------------------------------------------------------

PnfGoParser::StructTypeContext::StructTypeContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::StructTypeContext::STRUCT() {
  return getToken(PnfGoParser::STRUCT, 0);
}

tree::TerminalNode* PnfGoParser::StructTypeContext::L_CURLY() {
  return getToken(PnfGoParser::L_CURLY, 0);
}

PnfGoParser::Kleene_star__structType_2Context* PnfGoParser::StructTypeContext::kleene_star__structType_2() {
  return getRuleContext<PnfGoParser::Kleene_star__structType_2Context>(0);
}

tree::TerminalNode* PnfGoParser::StructTypeContext::R_CURLY() {
  return getToken(PnfGoParser::R_CURLY, 0);
}


size_t PnfGoParser::StructTypeContext::getRuleIndex() const {
  return PnfGoParser::RuleStructType;
}

void PnfGoParser::StructTypeContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterStructType(this);
}

void PnfGoParser::StructTypeContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitStructType(this);
}


antlrcpp::Any PnfGoParser::StructTypeContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitStructType(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::StructTypeContext* PnfGoParser::structType() {
  StructTypeContext *_localctx = _tracker.createInstance<StructTypeContext>(_ctx, getState());
  enterRule(_localctx, 152, PnfGoParser::RuleStructType);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(724);
    match(PnfGoParser::STRUCT);
    setState(725);
    match(PnfGoParser::L_CURLY);
    setState(726);
    kleene_star__structType_2();
    setState(727);
    match(PnfGoParser::R_CURLY);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- FieldDeclContext ------------------------------------------------------------------

PnfGoParser::FieldDeclContext::FieldDeclContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Altnt_block__fieldDecl_2Context* PnfGoParser::FieldDeclContext::altnt_block__fieldDecl_2() {
  return getRuleContext<PnfGoParser::Altnt_block__fieldDecl_2Context>(0);
}

PnfGoParser::Optional__fieldDecl_1Context* PnfGoParser::FieldDeclContext::optional__fieldDecl_1() {
  return getRuleContext<PnfGoParser::Optional__fieldDecl_1Context>(0);
}


size_t PnfGoParser::FieldDeclContext::getRuleIndex() const {
  return PnfGoParser::RuleFieldDecl;
}

void PnfGoParser::FieldDeclContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterFieldDecl(this);
}

void PnfGoParser::FieldDeclContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitFieldDecl(this);
}


antlrcpp::Any PnfGoParser::FieldDeclContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitFieldDecl(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::FieldDeclContext* PnfGoParser::fieldDecl() {
  FieldDeclContext *_localctx = _tracker.createInstance<FieldDeclContext>(_ctx, getState());
  enterRule(_localctx, 154, PnfGoParser::RuleFieldDecl);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(729);
    altnt_block__fieldDecl_2();
    setState(730);
    optional__fieldDecl_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- String_Context ------------------------------------------------------------------

PnfGoParser::String_Context::String_Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::String_Context::RAW_STRING_LIT() {
  return getToken(PnfGoParser::RAW_STRING_LIT, 0);
}

tree::TerminalNode* PnfGoParser::String_Context::INTERPRETED_STRING_LIT() {
  return getToken(PnfGoParser::INTERPRETED_STRING_LIT, 0);
}


size_t PnfGoParser::String_Context::getRuleIndex() const {
  return PnfGoParser::RuleString_;
}

void PnfGoParser::String_Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterString_(this);
}

void PnfGoParser::String_Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitString_(this);
}


antlrcpp::Any PnfGoParser::String_Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitString_(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::String_Context* PnfGoParser::string_() {
  String_Context *_localctx = _tracker.createInstance<String_Context>(_ctx, getState());
  enterRule(_localctx, 156, PnfGoParser::RuleString_);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(732);
    _la = _input->LA(1);
    if (!(_la == PnfGoParser::RAW_STRING_LIT

    || _la == PnfGoParser::INTERPRETED_STRING_LIT)) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- AnonymousFieldContext ------------------------------------------------------------------

PnfGoParser::AnonymousFieldContext::AnonymousFieldContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Optional__anonymousField_1Context* PnfGoParser::AnonymousFieldContext::optional__anonymousField_1() {
  return getRuleContext<PnfGoParser::Optional__anonymousField_1Context>(0);
}

PnfGoParser::TypeNameContext* PnfGoParser::AnonymousFieldContext::typeName() {
  return getRuleContext<PnfGoParser::TypeNameContext>(0);
}


size_t PnfGoParser::AnonymousFieldContext::getRuleIndex() const {
  return PnfGoParser::RuleAnonymousField;
}

void PnfGoParser::AnonymousFieldContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAnonymousField(this);
}

void PnfGoParser::AnonymousFieldContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAnonymousField(this);
}


antlrcpp::Any PnfGoParser::AnonymousFieldContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAnonymousField(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::AnonymousFieldContext* PnfGoParser::anonymousField() {
  AnonymousFieldContext *_localctx = _tracker.createInstance<AnonymousFieldContext>(_ctx, getState());
  enterRule(_localctx, 158, PnfGoParser::RuleAnonymousField);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(734);
    optional__anonymousField_1();
    setState(735);
    typeName();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- FunctionLitContext ------------------------------------------------------------------

PnfGoParser::FunctionLitContext::FunctionLitContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::FunctionLitContext::FUNC() {
  return getToken(PnfGoParser::FUNC, 0);
}

PnfGoParser::SignatureContext* PnfGoParser::FunctionLitContext::signature() {
  return getRuleContext<PnfGoParser::SignatureContext>(0);
}

PnfGoParser::BlockContext* PnfGoParser::FunctionLitContext::block() {
  return getRuleContext<PnfGoParser::BlockContext>(0);
}


size_t PnfGoParser::FunctionLitContext::getRuleIndex() const {
  return PnfGoParser::RuleFunctionLit;
}

void PnfGoParser::FunctionLitContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterFunctionLit(this);
}

void PnfGoParser::FunctionLitContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitFunctionLit(this);
}


antlrcpp::Any PnfGoParser::FunctionLitContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitFunctionLit(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::FunctionLitContext* PnfGoParser::functionLit() {
  FunctionLitContext *_localctx = _tracker.createInstance<FunctionLitContext>(_ctx, getState());
  enterRule(_localctx, 160, PnfGoParser::RuleFunctionLit);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(737);
    match(PnfGoParser::FUNC);
    setState(738);
    signature();
    setState(739);
    block();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- IndexContext ------------------------------------------------------------------

PnfGoParser::IndexContext::IndexContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::IndexContext::L_BRACKET() {
  return getToken(PnfGoParser::L_BRACKET, 0);
}

PnfGoParser::ExpressionContext* PnfGoParser::IndexContext::expression() {
  return getRuleContext<PnfGoParser::ExpressionContext>(0);
}

tree::TerminalNode* PnfGoParser::IndexContext::R_BRACKET() {
  return getToken(PnfGoParser::R_BRACKET, 0);
}


size_t PnfGoParser::IndexContext::getRuleIndex() const {
  return PnfGoParser::RuleIndex;
}

void PnfGoParser::IndexContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterIndex(this);
}

void PnfGoParser::IndexContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitIndex(this);
}


antlrcpp::Any PnfGoParser::IndexContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitIndex(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::IndexContext* PnfGoParser::index() {
  IndexContext *_localctx = _tracker.createInstance<IndexContext>(_ctx, getState());
  enterRule(_localctx, 162, PnfGoParser::RuleIndex);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(741);
    match(PnfGoParser::L_BRACKET);
    setState(742);
    expression();
    setState(743);
    match(PnfGoParser::R_BRACKET);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- SliceContext ------------------------------------------------------------------

PnfGoParser::SliceContext::SliceContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::SliceContext::L_BRACKET() {
  return getToken(PnfGoParser::L_BRACKET, 0);
}

PnfGoParser::Altnt_block__slice_4Context* PnfGoParser::SliceContext::altnt_block__slice_4() {
  return getRuleContext<PnfGoParser::Altnt_block__slice_4Context>(0);
}

tree::TerminalNode* PnfGoParser::SliceContext::R_BRACKET() {
  return getToken(PnfGoParser::R_BRACKET, 0);
}


size_t PnfGoParser::SliceContext::getRuleIndex() const {
  return PnfGoParser::RuleSlice;
}

void PnfGoParser::SliceContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterSlice(this);
}

void PnfGoParser::SliceContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitSlice(this);
}


antlrcpp::Any PnfGoParser::SliceContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitSlice(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::SliceContext* PnfGoParser::slice() {
  SliceContext *_localctx = _tracker.createInstance<SliceContext>(_ctx, getState());
  enterRule(_localctx, 164, PnfGoParser::RuleSlice);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(745);
    match(PnfGoParser::L_BRACKET);
    setState(746);
    altnt_block__slice_4();
    setState(747);
    match(PnfGoParser::R_BRACKET);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- TypeAssertionContext ------------------------------------------------------------------

PnfGoParser::TypeAssertionContext::TypeAssertionContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::TypeAssertionContext::DOT() {
  return getToken(PnfGoParser::DOT, 0);
}

tree::TerminalNode* PnfGoParser::TypeAssertionContext::L_PAREN() {
  return getToken(PnfGoParser::L_PAREN, 0);
}

PnfGoParser::Type_Context* PnfGoParser::TypeAssertionContext::type_() {
  return getRuleContext<PnfGoParser::Type_Context>(0);
}

tree::TerminalNode* PnfGoParser::TypeAssertionContext::R_PAREN() {
  return getToken(PnfGoParser::R_PAREN, 0);
}


size_t PnfGoParser::TypeAssertionContext::getRuleIndex() const {
  return PnfGoParser::RuleTypeAssertion;
}

void PnfGoParser::TypeAssertionContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterTypeAssertion(this);
}

void PnfGoParser::TypeAssertionContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitTypeAssertion(this);
}


antlrcpp::Any PnfGoParser::TypeAssertionContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitTypeAssertion(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::TypeAssertionContext* PnfGoParser::typeAssertion() {
  TypeAssertionContext *_localctx = _tracker.createInstance<TypeAssertionContext>(_ctx, getState());
  enterRule(_localctx, 166, PnfGoParser::RuleTypeAssertion);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(749);
    match(PnfGoParser::DOT);
    setState(750);
    match(PnfGoParser::L_PAREN);
    setState(751);
    type_();
    setState(752);
    match(PnfGoParser::R_PAREN);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ArgumentsContext ------------------------------------------------------------------

PnfGoParser::ArgumentsContext::ArgumentsContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::ArgumentsContext::L_PAREN() {
  return getToken(PnfGoParser::L_PAREN, 0);
}

PnfGoParser::Optional__arguments_6Context* PnfGoParser::ArgumentsContext::optional__arguments_6() {
  return getRuleContext<PnfGoParser::Optional__arguments_6Context>(0);
}

tree::TerminalNode* PnfGoParser::ArgumentsContext::R_PAREN() {
  return getToken(PnfGoParser::R_PAREN, 0);
}


size_t PnfGoParser::ArgumentsContext::getRuleIndex() const {
  return PnfGoParser::RuleArguments;
}

void PnfGoParser::ArgumentsContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterArguments(this);
}

void PnfGoParser::ArgumentsContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitArguments(this);
}


antlrcpp::Any PnfGoParser::ArgumentsContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitArguments(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::ArgumentsContext* PnfGoParser::arguments() {
  ArgumentsContext *_localctx = _tracker.createInstance<ArgumentsContext>(_ctx, getState());
  enterRule(_localctx, 168, PnfGoParser::RuleArguments);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(754);
    match(PnfGoParser::L_PAREN);
    setState(755);
    optional__arguments_6();
    setState(756);
    match(PnfGoParser::R_PAREN);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- MethodExprContext ------------------------------------------------------------------

PnfGoParser::MethodExprContext::MethodExprContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::ElementTypeContext* PnfGoParser::MethodExprContext::elementType() {
  return getRuleContext<PnfGoParser::ElementTypeContext>(0);
}

tree::TerminalNode* PnfGoParser::MethodExprContext::DOT() {
  return getToken(PnfGoParser::DOT, 0);
}

tree::TerminalNode* PnfGoParser::MethodExprContext::IDENTIFIER() {
  return getToken(PnfGoParser::IDENTIFIER, 0);
}


size_t PnfGoParser::MethodExprContext::getRuleIndex() const {
  return PnfGoParser::RuleMethodExpr;
}

void PnfGoParser::MethodExprContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterMethodExpr(this);
}

void PnfGoParser::MethodExprContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitMethodExpr(this);
}


antlrcpp::Any PnfGoParser::MethodExprContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitMethodExpr(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::MethodExprContext* PnfGoParser::methodExpr() {
  MethodExprContext *_localctx = _tracker.createInstance<MethodExprContext>(_ctx, getState());
  enterRule(_localctx, 170, PnfGoParser::RuleMethodExpr);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(758);
    elementType();
    setState(759);
    match(PnfGoParser::DOT);
    setState(760);
    match(PnfGoParser::IDENTIFIER);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- EosContext ------------------------------------------------------------------

PnfGoParser::EosContext::EosContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::EosContext::SEMI() {
  return getToken(PnfGoParser::SEMI, 0);
}

tree::TerminalNode* PnfGoParser::EosContext::EOF() {
  return getToken(PnfGoParser::EOF, 0);
}

PnfGoParser::Aux_rule__eos_1Context* PnfGoParser::EosContext::aux_rule__eos_1() {
  return getRuleContext<PnfGoParser::Aux_rule__eos_1Context>(0);
}

PnfGoParser::Aux_rule__eos_2Context* PnfGoParser::EosContext::aux_rule__eos_2() {
  return getRuleContext<PnfGoParser::Aux_rule__eos_2Context>(0);
}


size_t PnfGoParser::EosContext::getRuleIndex() const {
  return PnfGoParser::RuleEos;
}

void PnfGoParser::EosContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterEos(this);
}

void PnfGoParser::EosContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitEos(this);
}


antlrcpp::Any PnfGoParser::EosContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitEos(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::EosContext* PnfGoParser::eos() {
  EosContext *_localctx = _tracker.createInstance<EosContext>(_ctx, getState());
  enterRule(_localctx, 172, PnfGoParser::RuleEos);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(766);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 16, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(762);
      match(PnfGoParser::SEMI);
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(763);
      match(PnfGoParser::EOF);
      break;
    }

    case 3: {
      enterOuterAlt(_localctx, 3);
      setState(764);
      aux_rule__eos_1();
      break;
    }

    case 4: {
      enterOuterAlt(_localctx, 4);
      setState(765);
      aux_rule__eos_2();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__sourceFile_1Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__sourceFile_1Context::Aux_rule__sourceFile_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::ImportDeclContext* PnfGoParser::Aux_rule__sourceFile_1Context::importDecl() {
  return getRuleContext<PnfGoParser::ImportDeclContext>(0);
}

PnfGoParser::EosContext* PnfGoParser::Aux_rule__sourceFile_1Context::eos() {
  return getRuleContext<PnfGoParser::EosContext>(0);
}


size_t PnfGoParser::Aux_rule__sourceFile_1Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__sourceFile_1;
}

void PnfGoParser::Aux_rule__sourceFile_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__sourceFile_1(this);
}

void PnfGoParser::Aux_rule__sourceFile_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__sourceFile_1(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__sourceFile_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__sourceFile_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__sourceFile_1Context* PnfGoParser::aux_rule__sourceFile_1() {
  Aux_rule__sourceFile_1Context *_localctx = _tracker.createInstance<Aux_rule__sourceFile_1Context>(_ctx, getState());
  enterRule(_localctx, 174, PnfGoParser::RuleAux_rule__sourceFile_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(768);
    importDecl();
    setState(769);
    eos();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__sourceFile_2Context ------------------------------------------------------------------

PnfGoParser::Kleene_star__sourceFile_2Context::Kleene_star__sourceFile_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfGoParser::Aux_rule__sourceFile_1Context *> PnfGoParser::Kleene_star__sourceFile_2Context::aux_rule__sourceFile_1() {
  return getRuleContexts<PnfGoParser::Aux_rule__sourceFile_1Context>();
}

PnfGoParser::Aux_rule__sourceFile_1Context* PnfGoParser::Kleene_star__sourceFile_2Context::aux_rule__sourceFile_1(size_t i) {
  return getRuleContext<PnfGoParser::Aux_rule__sourceFile_1Context>(i);
}


size_t PnfGoParser::Kleene_star__sourceFile_2Context::getRuleIndex() const {
  return PnfGoParser::RuleKleene_star__sourceFile_2;
}

void PnfGoParser::Kleene_star__sourceFile_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__sourceFile_2(this);
}

void PnfGoParser::Kleene_star__sourceFile_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__sourceFile_2(this);
}


antlrcpp::Any PnfGoParser::Kleene_star__sourceFile_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitKleene_star__sourceFile_2(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Kleene_star__sourceFile_2Context* PnfGoParser::kleene_star__sourceFile_2() {
  Kleene_star__sourceFile_2Context *_localctx = _tracker.createInstance<Kleene_star__sourceFile_2Context>(_ctx, getState());
  enterRule(_localctx, 176, PnfGoParser::RuleKleene_star__sourceFile_2);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(774);
    _errHandler->sync(this);
    _la = _input->LA(1);
    while (_la == PnfGoParser::IMPORT) {
      setState(771);
      aux_rule__sourceFile_1();
      setState(776);
      _errHandler->sync(this);
      _la = _input->LA(1);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__sourceFile_3Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__sourceFile_3Context::Aux_rule__sourceFile_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Altnt_block__sourceFile_5Context* PnfGoParser::Aux_rule__sourceFile_3Context::altnt_block__sourceFile_5() {
  return getRuleContext<PnfGoParser::Altnt_block__sourceFile_5Context>(0);
}

PnfGoParser::EosContext* PnfGoParser::Aux_rule__sourceFile_3Context::eos() {
  return getRuleContext<PnfGoParser::EosContext>(0);
}


size_t PnfGoParser::Aux_rule__sourceFile_3Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__sourceFile_3;
}

void PnfGoParser::Aux_rule__sourceFile_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__sourceFile_3(this);
}

void PnfGoParser::Aux_rule__sourceFile_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__sourceFile_3(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__sourceFile_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__sourceFile_3(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__sourceFile_3Context* PnfGoParser::aux_rule__sourceFile_3() {
  Aux_rule__sourceFile_3Context *_localctx = _tracker.createInstance<Aux_rule__sourceFile_3Context>(_ctx, getState());
  enterRule(_localctx, 178, PnfGoParser::RuleAux_rule__sourceFile_3);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(777);
    altnt_block__sourceFile_5();
    setState(778);
    eos();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__sourceFile_4Context ------------------------------------------------------------------

PnfGoParser::Kleene_star__sourceFile_4Context::Kleene_star__sourceFile_4Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfGoParser::Aux_rule__sourceFile_3Context *> PnfGoParser::Kleene_star__sourceFile_4Context::aux_rule__sourceFile_3() {
  return getRuleContexts<PnfGoParser::Aux_rule__sourceFile_3Context>();
}

PnfGoParser::Aux_rule__sourceFile_3Context* PnfGoParser::Kleene_star__sourceFile_4Context::aux_rule__sourceFile_3(size_t i) {
  return getRuleContext<PnfGoParser::Aux_rule__sourceFile_3Context>(i);
}


size_t PnfGoParser::Kleene_star__sourceFile_4Context::getRuleIndex() const {
  return PnfGoParser::RuleKleene_star__sourceFile_4;
}

void PnfGoParser::Kleene_star__sourceFile_4Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__sourceFile_4(this);
}

void PnfGoParser::Kleene_star__sourceFile_4Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__sourceFile_4(this);
}


antlrcpp::Any PnfGoParser::Kleene_star__sourceFile_4Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitKleene_star__sourceFile_4(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Kleene_star__sourceFile_4Context* PnfGoParser::kleene_star__sourceFile_4() {
  Kleene_star__sourceFile_4Context *_localctx = _tracker.createInstance<Kleene_star__sourceFile_4Context>(_ctx, getState());
  enterRule(_localctx, 180, PnfGoParser::RuleKleene_star__sourceFile_4);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(783);
    _errHandler->sync(this);
    _la = _input->LA(1);
    while ((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << PnfGoParser::FUNC)
      | (1ULL << PnfGoParser::CONST)
      | (1ULL << PnfGoParser::TYPE)
      | (1ULL << PnfGoParser::VAR))) != 0)) {
      setState(780);
      aux_rule__sourceFile_3();
      setState(785);
      _errHandler->sync(this);
      _la = _input->LA(1);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__importDecl_1Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__importDecl_1Context::Aux_rule__importDecl_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::ImportSpecContext* PnfGoParser::Aux_rule__importDecl_1Context::importSpec() {
  return getRuleContext<PnfGoParser::ImportSpecContext>(0);
}

PnfGoParser::EosContext* PnfGoParser::Aux_rule__importDecl_1Context::eos() {
  return getRuleContext<PnfGoParser::EosContext>(0);
}


size_t PnfGoParser::Aux_rule__importDecl_1Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__importDecl_1;
}

void PnfGoParser::Aux_rule__importDecl_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__importDecl_1(this);
}

void PnfGoParser::Aux_rule__importDecl_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__importDecl_1(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__importDecl_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__importDecl_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__importDecl_1Context* PnfGoParser::aux_rule__importDecl_1() {
  Aux_rule__importDecl_1Context *_localctx = _tracker.createInstance<Aux_rule__importDecl_1Context>(_ctx, getState());
  enterRule(_localctx, 182, PnfGoParser::RuleAux_rule__importDecl_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(786);
    importSpec();
    setState(787);
    eos();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__importDecl_2Context ------------------------------------------------------------------

PnfGoParser::Kleene_star__importDecl_2Context::Kleene_star__importDecl_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfGoParser::Aux_rule__importDecl_1Context *> PnfGoParser::Kleene_star__importDecl_2Context::aux_rule__importDecl_1() {
  return getRuleContexts<PnfGoParser::Aux_rule__importDecl_1Context>();
}

PnfGoParser::Aux_rule__importDecl_1Context* PnfGoParser::Kleene_star__importDecl_2Context::aux_rule__importDecl_1(size_t i) {
  return getRuleContext<PnfGoParser::Aux_rule__importDecl_1Context>(i);
}


size_t PnfGoParser::Kleene_star__importDecl_2Context::getRuleIndex() const {
  return PnfGoParser::RuleKleene_star__importDecl_2;
}

void PnfGoParser::Kleene_star__importDecl_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__importDecl_2(this);
}

void PnfGoParser::Kleene_star__importDecl_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__importDecl_2(this);
}


antlrcpp::Any PnfGoParser::Kleene_star__importDecl_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitKleene_star__importDecl_2(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Kleene_star__importDecl_2Context* PnfGoParser::kleene_star__importDecl_2() {
  Kleene_star__importDecl_2Context *_localctx = _tracker.createInstance<Kleene_star__importDecl_2Context>(_ctx, getState());
  enterRule(_localctx, 184, PnfGoParser::RuleKleene_star__importDecl_2);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(792);
    _errHandler->sync(this);
    _la = _input->LA(1);
    while (((((_la - 27) & ~ 0x3fULL) == 0) &&
      ((1ULL << (_la - 27)) & ((1ULL << (PnfGoParser::IDENTIFIER - 27))
      | (1ULL << (PnfGoParser::DOT - 27))
      | (1ULL << (PnfGoParser::RAW_STRING_LIT - 27))
      | (1ULL << (PnfGoParser::INTERPRETED_STRING_LIT - 27)))) != 0)) {
      setState(789);
      aux_rule__importDecl_1();
      setState(794);
      _errHandler->sync(this);
      _la = _input->LA(1);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__importSpec_1Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__importSpec_1Context::Aux_rule__importSpec_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::Aux_rule__importSpec_1Context::DOT() {
  return getToken(PnfGoParser::DOT, 0);
}

tree::TerminalNode* PnfGoParser::Aux_rule__importSpec_1Context::IDENTIFIER() {
  return getToken(PnfGoParser::IDENTIFIER, 0);
}


size_t PnfGoParser::Aux_rule__importSpec_1Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__importSpec_1;
}

void PnfGoParser::Aux_rule__importSpec_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__importSpec_1(this);
}

void PnfGoParser::Aux_rule__importSpec_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__importSpec_1(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__importSpec_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__importSpec_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__importSpec_1Context* PnfGoParser::aux_rule__importSpec_1() {
  Aux_rule__importSpec_1Context *_localctx = _tracker.createInstance<Aux_rule__importSpec_1Context>(_ctx, getState());
  enterRule(_localctx, 186, PnfGoParser::RuleAux_rule__importSpec_1);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(795);
    _la = _input->LA(1);
    if (!(_la == PnfGoParser::IDENTIFIER

    || _la == PnfGoParser::DOT)) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__importSpec_2Context ------------------------------------------------------------------

PnfGoParser::Optional__importSpec_2Context::Optional__importSpec_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Aux_rule__importSpec_1Context* PnfGoParser::Optional__importSpec_2Context::aux_rule__importSpec_1() {
  return getRuleContext<PnfGoParser::Aux_rule__importSpec_1Context>(0);
}


size_t PnfGoParser::Optional__importSpec_2Context::getRuleIndex() const {
  return PnfGoParser::RuleOptional__importSpec_2;
}

void PnfGoParser::Optional__importSpec_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__importSpec_2(this);
}

void PnfGoParser::Optional__importSpec_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__importSpec_2(this);
}


antlrcpp::Any PnfGoParser::Optional__importSpec_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitOptional__importSpec_2(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Optional__importSpec_2Context* PnfGoParser::optional__importSpec_2() {
  Optional__importSpec_2Context *_localctx = _tracker.createInstance<Optional__importSpec_2Context>(_ctx, getState());
  enterRule(_localctx, 188, PnfGoParser::RuleOptional__importSpec_2);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(798);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if (_la == PnfGoParser::IDENTIFIER

    || _la == PnfGoParser::DOT) {
      setState(797);
      aux_rule__importSpec_1();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__constDecl_1Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__constDecl_1Context::Aux_rule__constDecl_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::ConstSpecContext* PnfGoParser::Aux_rule__constDecl_1Context::constSpec() {
  return getRuleContext<PnfGoParser::ConstSpecContext>(0);
}

PnfGoParser::EosContext* PnfGoParser::Aux_rule__constDecl_1Context::eos() {
  return getRuleContext<PnfGoParser::EosContext>(0);
}


size_t PnfGoParser::Aux_rule__constDecl_1Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__constDecl_1;
}

void PnfGoParser::Aux_rule__constDecl_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__constDecl_1(this);
}

void PnfGoParser::Aux_rule__constDecl_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__constDecl_1(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__constDecl_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__constDecl_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__constDecl_1Context* PnfGoParser::aux_rule__constDecl_1() {
  Aux_rule__constDecl_1Context *_localctx = _tracker.createInstance<Aux_rule__constDecl_1Context>(_ctx, getState());
  enterRule(_localctx, 190, PnfGoParser::RuleAux_rule__constDecl_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(800);
    constSpec();
    setState(801);
    eos();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__constDecl_2Context ------------------------------------------------------------------

PnfGoParser::Kleene_star__constDecl_2Context::Kleene_star__constDecl_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfGoParser::Aux_rule__constDecl_1Context *> PnfGoParser::Kleene_star__constDecl_2Context::aux_rule__constDecl_1() {
  return getRuleContexts<PnfGoParser::Aux_rule__constDecl_1Context>();
}

PnfGoParser::Aux_rule__constDecl_1Context* PnfGoParser::Kleene_star__constDecl_2Context::aux_rule__constDecl_1(size_t i) {
  return getRuleContext<PnfGoParser::Aux_rule__constDecl_1Context>(i);
}


size_t PnfGoParser::Kleene_star__constDecl_2Context::getRuleIndex() const {
  return PnfGoParser::RuleKleene_star__constDecl_2;
}

void PnfGoParser::Kleene_star__constDecl_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__constDecl_2(this);
}

void PnfGoParser::Kleene_star__constDecl_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__constDecl_2(this);
}


antlrcpp::Any PnfGoParser::Kleene_star__constDecl_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitKleene_star__constDecl_2(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Kleene_star__constDecl_2Context* PnfGoParser::kleene_star__constDecl_2() {
  Kleene_star__constDecl_2Context *_localctx = _tracker.createInstance<Kleene_star__constDecl_2Context>(_ctx, getState());
  enterRule(_localctx, 192, PnfGoParser::RuleKleene_star__constDecl_2);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(806);
    _errHandler->sync(this);
    _la = _input->LA(1);
    while (_la == PnfGoParser::IDENTIFIER) {
      setState(803);
      aux_rule__constDecl_1();
      setState(808);
      _errHandler->sync(this);
      _la = _input->LA(1);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__constSpec_1Context ------------------------------------------------------------------

PnfGoParser::Optional__constSpec_1Context::Optional__constSpec_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Type_Context* PnfGoParser::Optional__constSpec_1Context::type_() {
  return getRuleContext<PnfGoParser::Type_Context>(0);
}


size_t PnfGoParser::Optional__constSpec_1Context::getRuleIndex() const {
  return PnfGoParser::RuleOptional__constSpec_1;
}

void PnfGoParser::Optional__constSpec_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__constSpec_1(this);
}

void PnfGoParser::Optional__constSpec_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__constSpec_1(this);
}


antlrcpp::Any PnfGoParser::Optional__constSpec_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitOptional__constSpec_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Optional__constSpec_1Context* PnfGoParser::optional__constSpec_1() {
  Optional__constSpec_1Context *_localctx = _tracker.createInstance<Optional__constSpec_1Context>(_ctx, getState());
  enterRule(_localctx, 194, PnfGoParser::RuleOptional__constSpec_1);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(810);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if ((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << PnfGoParser::FUNC)
      | (1ULL << PnfGoParser::INTERFACE)
      | (1ULL << PnfGoParser::MAP)
      | (1ULL << PnfGoParser::STRUCT)
      | (1ULL << PnfGoParser::CHAN)
      | (1ULL << PnfGoParser::IDENTIFIER)
      | (1ULL << PnfGoParser::L_PAREN)
      | (1ULL << PnfGoParser::L_BRACKET)
      | (1ULL << PnfGoParser::STAR)
      | (1ULL << PnfGoParser::RECEIVE))) != 0)) {
      setState(809);
      type_();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__constSpec_2Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__constSpec_2Context::Aux_rule__constSpec_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Optional__constSpec_1Context* PnfGoParser::Aux_rule__constSpec_2Context::optional__constSpec_1() {
  return getRuleContext<PnfGoParser::Optional__constSpec_1Context>(0);
}

tree::TerminalNode* PnfGoParser::Aux_rule__constSpec_2Context::ASSIGN() {
  return getToken(PnfGoParser::ASSIGN, 0);
}

PnfGoParser::ExpressionListContext* PnfGoParser::Aux_rule__constSpec_2Context::expressionList() {
  return getRuleContext<PnfGoParser::ExpressionListContext>(0);
}


size_t PnfGoParser::Aux_rule__constSpec_2Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__constSpec_2;
}

void PnfGoParser::Aux_rule__constSpec_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__constSpec_2(this);
}

void PnfGoParser::Aux_rule__constSpec_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__constSpec_2(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__constSpec_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__constSpec_2(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__constSpec_2Context* PnfGoParser::aux_rule__constSpec_2() {
  Aux_rule__constSpec_2Context *_localctx = _tracker.createInstance<Aux_rule__constSpec_2Context>(_ctx, getState());
  enterRule(_localctx, 196, PnfGoParser::RuleAux_rule__constSpec_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(812);
    optional__constSpec_1();
    setState(813);
    match(PnfGoParser::ASSIGN);
    setState(814);
    expressionList();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__constSpec_3Context ------------------------------------------------------------------

PnfGoParser::Optional__constSpec_3Context::Optional__constSpec_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Aux_rule__constSpec_2Context* PnfGoParser::Optional__constSpec_3Context::aux_rule__constSpec_2() {
  return getRuleContext<PnfGoParser::Aux_rule__constSpec_2Context>(0);
}


size_t PnfGoParser::Optional__constSpec_3Context::getRuleIndex() const {
  return PnfGoParser::RuleOptional__constSpec_3;
}

void PnfGoParser::Optional__constSpec_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__constSpec_3(this);
}

void PnfGoParser::Optional__constSpec_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__constSpec_3(this);
}


antlrcpp::Any PnfGoParser::Optional__constSpec_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitOptional__constSpec_3(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Optional__constSpec_3Context* PnfGoParser::optional__constSpec_3() {
  Optional__constSpec_3Context *_localctx = _tracker.createInstance<Optional__constSpec_3Context>(_ctx, getState());
  enterRule(_localctx, 198, PnfGoParser::RuleOptional__constSpec_3);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(817);
    _errHandler->sync(this);

    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 23, _ctx)) {
    case 1: {
      setState(816);
      aux_rule__constSpec_2();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__identifierList_1Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__identifierList_1Context::Aux_rule__identifierList_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::Aux_rule__identifierList_1Context::COMMA() {
  return getToken(PnfGoParser::COMMA, 0);
}

tree::TerminalNode* PnfGoParser::Aux_rule__identifierList_1Context::IDENTIFIER() {
  return getToken(PnfGoParser::IDENTIFIER, 0);
}


size_t PnfGoParser::Aux_rule__identifierList_1Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__identifierList_1;
}

void PnfGoParser::Aux_rule__identifierList_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__identifierList_1(this);
}

void PnfGoParser::Aux_rule__identifierList_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__identifierList_1(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__identifierList_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__identifierList_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__identifierList_1Context* PnfGoParser::aux_rule__identifierList_1() {
  Aux_rule__identifierList_1Context *_localctx = _tracker.createInstance<Aux_rule__identifierList_1Context>(_ctx, getState());
  enterRule(_localctx, 200, PnfGoParser::RuleAux_rule__identifierList_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(819);
    match(PnfGoParser::COMMA);
    setState(820);
    match(PnfGoParser::IDENTIFIER);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__identifierList_2Context ------------------------------------------------------------------

PnfGoParser::Kleene_star__identifierList_2Context::Kleene_star__identifierList_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfGoParser::Aux_rule__identifierList_1Context *> PnfGoParser::Kleene_star__identifierList_2Context::aux_rule__identifierList_1() {
  return getRuleContexts<PnfGoParser::Aux_rule__identifierList_1Context>();
}

PnfGoParser::Aux_rule__identifierList_1Context* PnfGoParser::Kleene_star__identifierList_2Context::aux_rule__identifierList_1(size_t i) {
  return getRuleContext<PnfGoParser::Aux_rule__identifierList_1Context>(i);
}


size_t PnfGoParser::Kleene_star__identifierList_2Context::getRuleIndex() const {
  return PnfGoParser::RuleKleene_star__identifierList_2;
}

void PnfGoParser::Kleene_star__identifierList_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__identifierList_2(this);
}

void PnfGoParser::Kleene_star__identifierList_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__identifierList_2(this);
}


antlrcpp::Any PnfGoParser::Kleene_star__identifierList_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitKleene_star__identifierList_2(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Kleene_star__identifierList_2Context* PnfGoParser::kleene_star__identifierList_2() {
  Kleene_star__identifierList_2Context *_localctx = _tracker.createInstance<Kleene_star__identifierList_2Context>(_ctx, getState());
  enterRule(_localctx, 202, PnfGoParser::RuleKleene_star__identifierList_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    size_t alt;
    enterOuterAlt(_localctx, 1);
    setState(825);
    _errHandler->sync(this);
    alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 24, _ctx);
    while (alt != 2 && alt != atn::ATN::INVALID_ALT_NUMBER) {
      if (alt == 1) {
        setState(822);
        aux_rule__identifierList_1(); 
      }
      setState(827);
      _errHandler->sync(this);
      alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 24, _ctx);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__expressionList_1Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__expressionList_1Context::Aux_rule__expressionList_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::Aux_rule__expressionList_1Context::COMMA() {
  return getToken(PnfGoParser::COMMA, 0);
}

PnfGoParser::ExpressionContext* PnfGoParser::Aux_rule__expressionList_1Context::expression() {
  return getRuleContext<PnfGoParser::ExpressionContext>(0);
}


size_t PnfGoParser::Aux_rule__expressionList_1Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__expressionList_1;
}

void PnfGoParser::Aux_rule__expressionList_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__expressionList_1(this);
}

void PnfGoParser::Aux_rule__expressionList_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__expressionList_1(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__expressionList_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__expressionList_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__expressionList_1Context* PnfGoParser::aux_rule__expressionList_1() {
  Aux_rule__expressionList_1Context *_localctx = _tracker.createInstance<Aux_rule__expressionList_1Context>(_ctx, getState());
  enterRule(_localctx, 204, PnfGoParser::RuleAux_rule__expressionList_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(828);
    match(PnfGoParser::COMMA);
    setState(829);
    expression();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__expressionList_2Context ------------------------------------------------------------------

PnfGoParser::Kleene_star__expressionList_2Context::Kleene_star__expressionList_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfGoParser::Aux_rule__expressionList_1Context *> PnfGoParser::Kleene_star__expressionList_2Context::aux_rule__expressionList_1() {
  return getRuleContexts<PnfGoParser::Aux_rule__expressionList_1Context>();
}

PnfGoParser::Aux_rule__expressionList_1Context* PnfGoParser::Kleene_star__expressionList_2Context::aux_rule__expressionList_1(size_t i) {
  return getRuleContext<PnfGoParser::Aux_rule__expressionList_1Context>(i);
}


size_t PnfGoParser::Kleene_star__expressionList_2Context::getRuleIndex() const {
  return PnfGoParser::RuleKleene_star__expressionList_2;
}

void PnfGoParser::Kleene_star__expressionList_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__expressionList_2(this);
}

void PnfGoParser::Kleene_star__expressionList_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__expressionList_2(this);
}


antlrcpp::Any PnfGoParser::Kleene_star__expressionList_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitKleene_star__expressionList_2(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Kleene_star__expressionList_2Context* PnfGoParser::kleene_star__expressionList_2() {
  Kleene_star__expressionList_2Context *_localctx = _tracker.createInstance<Kleene_star__expressionList_2Context>(_ctx, getState());
  enterRule(_localctx, 206, PnfGoParser::RuleKleene_star__expressionList_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    size_t alt;
    enterOuterAlt(_localctx, 1);
    setState(834);
    _errHandler->sync(this);
    alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 25, _ctx);
    while (alt != 2 && alt != atn::ATN::INVALID_ALT_NUMBER) {
      if (alt == 1) {
        setState(831);
        aux_rule__expressionList_1(); 
      }
      setState(836);
      _errHandler->sync(this);
      alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 25, _ctx);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__typeDecl_1Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__typeDecl_1Context::Aux_rule__typeDecl_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::TypeSpecContext* PnfGoParser::Aux_rule__typeDecl_1Context::typeSpec() {
  return getRuleContext<PnfGoParser::TypeSpecContext>(0);
}

PnfGoParser::EosContext* PnfGoParser::Aux_rule__typeDecl_1Context::eos() {
  return getRuleContext<PnfGoParser::EosContext>(0);
}


size_t PnfGoParser::Aux_rule__typeDecl_1Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__typeDecl_1;
}

void PnfGoParser::Aux_rule__typeDecl_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__typeDecl_1(this);
}

void PnfGoParser::Aux_rule__typeDecl_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__typeDecl_1(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__typeDecl_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__typeDecl_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__typeDecl_1Context* PnfGoParser::aux_rule__typeDecl_1() {
  Aux_rule__typeDecl_1Context *_localctx = _tracker.createInstance<Aux_rule__typeDecl_1Context>(_ctx, getState());
  enterRule(_localctx, 208, PnfGoParser::RuleAux_rule__typeDecl_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(837);
    typeSpec();
    setState(838);
    eos();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__typeDecl_2Context ------------------------------------------------------------------

PnfGoParser::Kleene_star__typeDecl_2Context::Kleene_star__typeDecl_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfGoParser::Aux_rule__typeDecl_1Context *> PnfGoParser::Kleene_star__typeDecl_2Context::aux_rule__typeDecl_1() {
  return getRuleContexts<PnfGoParser::Aux_rule__typeDecl_1Context>();
}

PnfGoParser::Aux_rule__typeDecl_1Context* PnfGoParser::Kleene_star__typeDecl_2Context::aux_rule__typeDecl_1(size_t i) {
  return getRuleContext<PnfGoParser::Aux_rule__typeDecl_1Context>(i);
}


size_t PnfGoParser::Kleene_star__typeDecl_2Context::getRuleIndex() const {
  return PnfGoParser::RuleKleene_star__typeDecl_2;
}

void PnfGoParser::Kleene_star__typeDecl_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__typeDecl_2(this);
}

void PnfGoParser::Kleene_star__typeDecl_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__typeDecl_2(this);
}


antlrcpp::Any PnfGoParser::Kleene_star__typeDecl_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitKleene_star__typeDecl_2(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Kleene_star__typeDecl_2Context* PnfGoParser::kleene_star__typeDecl_2() {
  Kleene_star__typeDecl_2Context *_localctx = _tracker.createInstance<Kleene_star__typeDecl_2Context>(_ctx, getState());
  enterRule(_localctx, 210, PnfGoParser::RuleKleene_star__typeDecl_2);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(843);
    _errHandler->sync(this);
    _la = _input->LA(1);
    while (_la == PnfGoParser::IDENTIFIER) {
      setState(840);
      aux_rule__typeDecl_1();
      setState(845);
      _errHandler->sync(this);
      _la = _input->LA(1);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__typeSpec_1Context ------------------------------------------------------------------

PnfGoParser::Optional__typeSpec_1Context::Optional__typeSpec_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::Optional__typeSpec_1Context::ASSIGN() {
  return getToken(PnfGoParser::ASSIGN, 0);
}


size_t PnfGoParser::Optional__typeSpec_1Context::getRuleIndex() const {
  return PnfGoParser::RuleOptional__typeSpec_1;
}

void PnfGoParser::Optional__typeSpec_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__typeSpec_1(this);
}

void PnfGoParser::Optional__typeSpec_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__typeSpec_1(this);
}


antlrcpp::Any PnfGoParser::Optional__typeSpec_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitOptional__typeSpec_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Optional__typeSpec_1Context* PnfGoParser::optional__typeSpec_1() {
  Optional__typeSpec_1Context *_localctx = _tracker.createInstance<Optional__typeSpec_1Context>(_ctx, getState());
  enterRule(_localctx, 212, PnfGoParser::RuleOptional__typeSpec_1);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(847);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if (_la == PnfGoParser::ASSIGN) {
      setState(846);
      match(PnfGoParser::ASSIGN);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__functionDecl_1Context ------------------------------------------------------------------

PnfGoParser::Optional__functionDecl_1Context::Optional__functionDecl_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::BlockContext* PnfGoParser::Optional__functionDecl_1Context::block() {
  return getRuleContext<PnfGoParser::BlockContext>(0);
}


size_t PnfGoParser::Optional__functionDecl_1Context::getRuleIndex() const {
  return PnfGoParser::RuleOptional__functionDecl_1;
}

void PnfGoParser::Optional__functionDecl_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__functionDecl_1(this);
}

void PnfGoParser::Optional__functionDecl_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__functionDecl_1(this);
}


antlrcpp::Any PnfGoParser::Optional__functionDecl_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitOptional__functionDecl_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Optional__functionDecl_1Context* PnfGoParser::optional__functionDecl_1() {
  Optional__functionDecl_1Context *_localctx = _tracker.createInstance<Optional__functionDecl_1Context>(_ctx, getState());
  enterRule(_localctx, 214, PnfGoParser::RuleOptional__functionDecl_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(850);
    _errHandler->sync(this);

    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 28, _ctx)) {
    case 1: {
      setState(849);
      block();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__varDecl_1Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__varDecl_1Context::Aux_rule__varDecl_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::VarSpecContext* PnfGoParser::Aux_rule__varDecl_1Context::varSpec() {
  return getRuleContext<PnfGoParser::VarSpecContext>(0);
}

PnfGoParser::EosContext* PnfGoParser::Aux_rule__varDecl_1Context::eos() {
  return getRuleContext<PnfGoParser::EosContext>(0);
}


size_t PnfGoParser::Aux_rule__varDecl_1Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__varDecl_1;
}

void PnfGoParser::Aux_rule__varDecl_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__varDecl_1(this);
}

void PnfGoParser::Aux_rule__varDecl_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__varDecl_1(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__varDecl_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__varDecl_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__varDecl_1Context* PnfGoParser::aux_rule__varDecl_1() {
  Aux_rule__varDecl_1Context *_localctx = _tracker.createInstance<Aux_rule__varDecl_1Context>(_ctx, getState());
  enterRule(_localctx, 216, PnfGoParser::RuleAux_rule__varDecl_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(852);
    varSpec();
    setState(853);
    eos();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__varDecl_2Context ------------------------------------------------------------------

PnfGoParser::Kleene_star__varDecl_2Context::Kleene_star__varDecl_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfGoParser::Aux_rule__varDecl_1Context *> PnfGoParser::Kleene_star__varDecl_2Context::aux_rule__varDecl_1() {
  return getRuleContexts<PnfGoParser::Aux_rule__varDecl_1Context>();
}

PnfGoParser::Aux_rule__varDecl_1Context* PnfGoParser::Kleene_star__varDecl_2Context::aux_rule__varDecl_1(size_t i) {
  return getRuleContext<PnfGoParser::Aux_rule__varDecl_1Context>(i);
}


size_t PnfGoParser::Kleene_star__varDecl_2Context::getRuleIndex() const {
  return PnfGoParser::RuleKleene_star__varDecl_2;
}

void PnfGoParser::Kleene_star__varDecl_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__varDecl_2(this);
}

void PnfGoParser::Kleene_star__varDecl_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__varDecl_2(this);
}


antlrcpp::Any PnfGoParser::Kleene_star__varDecl_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitKleene_star__varDecl_2(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Kleene_star__varDecl_2Context* PnfGoParser::kleene_star__varDecl_2() {
  Kleene_star__varDecl_2Context *_localctx = _tracker.createInstance<Kleene_star__varDecl_2Context>(_ctx, getState());
  enterRule(_localctx, 218, PnfGoParser::RuleKleene_star__varDecl_2);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(858);
    _errHandler->sync(this);
    _la = _input->LA(1);
    while (_la == PnfGoParser::IDENTIFIER) {
      setState(855);
      aux_rule__varDecl_1();
      setState(860);
      _errHandler->sync(this);
      _la = _input->LA(1);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__varSpec_1Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__varSpec_1Context::Aux_rule__varSpec_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::Aux_rule__varSpec_1Context::ASSIGN() {
  return getToken(PnfGoParser::ASSIGN, 0);
}

PnfGoParser::ExpressionListContext* PnfGoParser::Aux_rule__varSpec_1Context::expressionList() {
  return getRuleContext<PnfGoParser::ExpressionListContext>(0);
}


size_t PnfGoParser::Aux_rule__varSpec_1Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__varSpec_1;
}

void PnfGoParser::Aux_rule__varSpec_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__varSpec_1(this);
}

void PnfGoParser::Aux_rule__varSpec_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__varSpec_1(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__varSpec_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__varSpec_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__varSpec_1Context* PnfGoParser::aux_rule__varSpec_1() {
  Aux_rule__varSpec_1Context *_localctx = _tracker.createInstance<Aux_rule__varSpec_1Context>(_ctx, getState());
  enterRule(_localctx, 220, PnfGoParser::RuleAux_rule__varSpec_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(861);
    match(PnfGoParser::ASSIGN);
    setState(862);
    expressionList();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__varSpec_2Context ------------------------------------------------------------------

PnfGoParser::Optional__varSpec_2Context::Optional__varSpec_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Aux_rule__varSpec_1Context* PnfGoParser::Optional__varSpec_2Context::aux_rule__varSpec_1() {
  return getRuleContext<PnfGoParser::Aux_rule__varSpec_1Context>(0);
}


size_t PnfGoParser::Optional__varSpec_2Context::getRuleIndex() const {
  return PnfGoParser::RuleOptional__varSpec_2;
}

void PnfGoParser::Optional__varSpec_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__varSpec_2(this);
}

void PnfGoParser::Optional__varSpec_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__varSpec_2(this);
}


antlrcpp::Any PnfGoParser::Optional__varSpec_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitOptional__varSpec_2(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Optional__varSpec_2Context* PnfGoParser::optional__varSpec_2() {
  Optional__varSpec_2Context *_localctx = _tracker.createInstance<Optional__varSpec_2Context>(_ctx, getState());
  enterRule(_localctx, 222, PnfGoParser::RuleOptional__varSpec_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(865);
    _errHandler->sync(this);

    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 30, _ctx)) {
    case 1: {
      setState(864);
      aux_rule__varSpec_1();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__block_1Context ------------------------------------------------------------------

PnfGoParser::Optional__block_1Context::Optional__block_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::StatementListContext* PnfGoParser::Optional__block_1Context::statementList() {
  return getRuleContext<PnfGoParser::StatementListContext>(0);
}


size_t PnfGoParser::Optional__block_1Context::getRuleIndex() const {
  return PnfGoParser::RuleOptional__block_1;
}

void PnfGoParser::Optional__block_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__block_1(this);
}

void PnfGoParser::Optional__block_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__block_1(this);
}


antlrcpp::Any PnfGoParser::Optional__block_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitOptional__block_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Optional__block_1Context* PnfGoParser::optional__block_1() {
  Optional__block_1Context *_localctx = _tracker.createInstance<Optional__block_1Context>(_ctx, getState());
  enterRule(_localctx, 224, PnfGoParser::RuleOptional__block_1);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(868);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if ((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << PnfGoParser::BREAK)
      | (1ULL << PnfGoParser::FUNC)
      | (1ULL << PnfGoParser::INTERFACE)
      | (1ULL << PnfGoParser::SELECT)
      | (1ULL << PnfGoParser::DEFER)
      | (1ULL << PnfGoParser::GO)
      | (1ULL << PnfGoParser::MAP)
      | (1ULL << PnfGoParser::STRUCT)
      | (1ULL << PnfGoParser::CHAN)
      | (1ULL << PnfGoParser::GOTO)
      | (1ULL << PnfGoParser::SWITCH)
      | (1ULL << PnfGoParser::CONST)
      | (1ULL << PnfGoParser::FALLTHROUGH)
      | (1ULL << PnfGoParser::IF)
      | (1ULL << PnfGoParser::TYPE)
      | (1ULL << PnfGoParser::CONTINUE)
      | (1ULL << PnfGoParser::FOR)
      | (1ULL << PnfGoParser::RETURN)
      | (1ULL << PnfGoParser::VAR)
      | (1ULL << PnfGoParser::NIL_LIT)
      | (1ULL << PnfGoParser::IDENTIFIER)
      | (1ULL << PnfGoParser::L_PAREN)
      | (1ULL << PnfGoParser::L_CURLY)
      | (1ULL << PnfGoParser::L_BRACKET)
      | (1ULL << PnfGoParser::SEMI)
      | (1ULL << PnfGoParser::EXCLAMATION)
      | (1ULL << PnfGoParser::PLUS)
      | (1ULL << PnfGoParser::MINUS)
      | (1ULL << PnfGoParser::CARET)
      | (1ULL << PnfGoParser::STAR)
      | (1ULL << PnfGoParser::AMPERSAND)
      | (1ULL << PnfGoParser::RECEIVE))) != 0) || ((((_la - 64) & ~ 0x3fULL) == 0) &&
      ((1ULL << (_la - 64)) & ((1ULL << (PnfGoParser::DECIMAL_LIT - 64))
      | (1ULL << (PnfGoParser::OCTAL_LIT - 64))
      | (1ULL << (PnfGoParser::HEX_LIT - 64))
      | (1ULL << (PnfGoParser::FLOAT_LIT - 64))
      | (1ULL << (PnfGoParser::IMAGINARY_LIT - 64))
      | (1ULL << (PnfGoParser::RUNE_LIT - 64))
      | (1ULL << (PnfGoParser::RAW_STRING_LIT - 64))
      | (1ULL << (PnfGoParser::INTERPRETED_STRING_LIT - 64)))) != 0)) {
      setState(867);
      statementList();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__statementList_1Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__statementList_1Context::Aux_rule__statementList_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Aux_rule__statementList_2Context* PnfGoParser::Aux_rule__statementList_1Context::aux_rule__statementList_2() {
  return getRuleContext<PnfGoParser::Aux_rule__statementList_2Context>(0);
}

tree::TerminalNode* PnfGoParser::Aux_rule__statementList_1Context::SEMI() {
  return getToken(PnfGoParser::SEMI, 0);
}


size_t PnfGoParser::Aux_rule__statementList_1Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__statementList_1;
}

void PnfGoParser::Aux_rule__statementList_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__statementList_1(this);
}

void PnfGoParser::Aux_rule__statementList_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__statementList_1(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__statementList_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__statementList_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__statementList_1Context* PnfGoParser::aux_rule__statementList_1() {
  Aux_rule__statementList_1Context *_localctx = _tracker.createInstance<Aux_rule__statementList_1Context>(_ctx, getState());
  enterRule(_localctx, 226, PnfGoParser::RuleAux_rule__statementList_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(872);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case PnfGoParser::BREAK:
      case PnfGoParser::FUNC:
      case PnfGoParser::INTERFACE:
      case PnfGoParser::SELECT:
      case PnfGoParser::DEFER:
      case PnfGoParser::GO:
      case PnfGoParser::MAP:
      case PnfGoParser::STRUCT:
      case PnfGoParser::CHAN:
      case PnfGoParser::GOTO:
      case PnfGoParser::SWITCH:
      case PnfGoParser::CONST:
      case PnfGoParser::FALLTHROUGH:
      case PnfGoParser::IF:
      case PnfGoParser::TYPE:
      case PnfGoParser::CONTINUE:
      case PnfGoParser::FOR:
      case PnfGoParser::RETURN:
      case PnfGoParser::VAR:
      case PnfGoParser::NIL_LIT:
      case PnfGoParser::IDENTIFIER:
      case PnfGoParser::L_PAREN:
      case PnfGoParser::L_CURLY:
      case PnfGoParser::L_BRACKET:
      case PnfGoParser::EXCLAMATION:
      case PnfGoParser::PLUS:
      case PnfGoParser::MINUS:
      case PnfGoParser::CARET:
      case PnfGoParser::STAR:
      case PnfGoParser::AMPERSAND:
      case PnfGoParser::RECEIVE:
      case PnfGoParser::DECIMAL_LIT:
      case PnfGoParser::OCTAL_LIT:
      case PnfGoParser::HEX_LIT:
      case PnfGoParser::FLOAT_LIT:
      case PnfGoParser::IMAGINARY_LIT:
      case PnfGoParser::RUNE_LIT:
      case PnfGoParser::RAW_STRING_LIT:
      case PnfGoParser::INTERPRETED_STRING_LIT: {
        enterOuterAlt(_localctx, 1);
        setState(870);
        aux_rule__statementList_2();
        break;
      }

      case PnfGoParser::SEMI: {
        enterOuterAlt(_localctx, 2);
        setState(871);
        match(PnfGoParser::SEMI);
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__assign_op_1Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__assign_op_1Context::Aux_rule__assign_op_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::Aux_rule__assign_op_1Context::PLUS() {
  return getToken(PnfGoParser::PLUS, 0);
}

tree::TerminalNode* PnfGoParser::Aux_rule__assign_op_1Context::MINUS() {
  return getToken(PnfGoParser::MINUS, 0);
}

tree::TerminalNode* PnfGoParser::Aux_rule__assign_op_1Context::OR() {
  return getToken(PnfGoParser::OR, 0);
}

tree::TerminalNode* PnfGoParser::Aux_rule__assign_op_1Context::CARET() {
  return getToken(PnfGoParser::CARET, 0);
}

tree::TerminalNode* PnfGoParser::Aux_rule__assign_op_1Context::STAR() {
  return getToken(PnfGoParser::STAR, 0);
}

tree::TerminalNode* PnfGoParser::Aux_rule__assign_op_1Context::DIV() {
  return getToken(PnfGoParser::DIV, 0);
}

tree::TerminalNode* PnfGoParser::Aux_rule__assign_op_1Context::MOD() {
  return getToken(PnfGoParser::MOD, 0);
}

tree::TerminalNode* PnfGoParser::Aux_rule__assign_op_1Context::LSHIFT() {
  return getToken(PnfGoParser::LSHIFT, 0);
}

tree::TerminalNode* PnfGoParser::Aux_rule__assign_op_1Context::RSHIFT() {
  return getToken(PnfGoParser::RSHIFT, 0);
}

tree::TerminalNode* PnfGoParser::Aux_rule__assign_op_1Context::AMPERSAND() {
  return getToken(PnfGoParser::AMPERSAND, 0);
}

tree::TerminalNode* PnfGoParser::Aux_rule__assign_op_1Context::BIT_CLEAR() {
  return getToken(PnfGoParser::BIT_CLEAR, 0);
}


size_t PnfGoParser::Aux_rule__assign_op_1Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__assign_op_1;
}

void PnfGoParser::Aux_rule__assign_op_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__assign_op_1(this);
}

void PnfGoParser::Aux_rule__assign_op_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__assign_op_1(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__assign_op_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__assign_op_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__assign_op_1Context* PnfGoParser::aux_rule__assign_op_1() {
  Aux_rule__assign_op_1Context *_localctx = _tracker.createInstance<Aux_rule__assign_op_1Context>(_ctx, getState());
  enterRule(_localctx, 228, PnfGoParser::RuleAux_rule__assign_op_1);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(874);
    _la = _input->LA(1);
    if (!((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << PnfGoParser::OR)
      | (1ULL << PnfGoParser::DIV)
      | (1ULL << PnfGoParser::MOD)
      | (1ULL << PnfGoParser::LSHIFT)
      | (1ULL << PnfGoParser::RSHIFT)
      | (1ULL << PnfGoParser::BIT_CLEAR)
      | (1ULL << PnfGoParser::PLUS)
      | (1ULL << PnfGoParser::MINUS)
      | (1ULL << PnfGoParser::CARET)
      | (1ULL << PnfGoParser::STAR)
      | (1ULL << PnfGoParser::AMPERSAND))) != 0))) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__assign_op_2Context ------------------------------------------------------------------

PnfGoParser::Optional__assign_op_2Context::Optional__assign_op_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Aux_rule__assign_op_1Context* PnfGoParser::Optional__assign_op_2Context::aux_rule__assign_op_1() {
  return getRuleContext<PnfGoParser::Aux_rule__assign_op_1Context>(0);
}


size_t PnfGoParser::Optional__assign_op_2Context::getRuleIndex() const {
  return PnfGoParser::RuleOptional__assign_op_2;
}

void PnfGoParser::Optional__assign_op_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__assign_op_2(this);
}

void PnfGoParser::Optional__assign_op_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__assign_op_2(this);
}


antlrcpp::Any PnfGoParser::Optional__assign_op_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitOptional__assign_op_2(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Optional__assign_op_2Context* PnfGoParser::optional__assign_op_2() {
  Optional__assign_op_2Context *_localctx = _tracker.createInstance<Optional__assign_op_2Context>(_ctx, getState());
  enterRule(_localctx, 230, PnfGoParser::RuleOptional__assign_op_2);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(877);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if ((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << PnfGoParser::OR)
      | (1ULL << PnfGoParser::DIV)
      | (1ULL << PnfGoParser::MOD)
      | (1ULL << PnfGoParser::LSHIFT)
      | (1ULL << PnfGoParser::RSHIFT)
      | (1ULL << PnfGoParser::BIT_CLEAR)
      | (1ULL << PnfGoParser::PLUS)
      | (1ULL << PnfGoParser::MINUS)
      | (1ULL << PnfGoParser::CARET)
      | (1ULL << PnfGoParser::STAR)
      | (1ULL << PnfGoParser::AMPERSAND))) != 0)) {
      setState(876);
      aux_rule__assign_op_1();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__returnStmt_1Context ------------------------------------------------------------------

PnfGoParser::Optional__returnStmt_1Context::Optional__returnStmt_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::ExpressionListContext* PnfGoParser::Optional__returnStmt_1Context::expressionList() {
  return getRuleContext<PnfGoParser::ExpressionListContext>(0);
}


size_t PnfGoParser::Optional__returnStmt_1Context::getRuleIndex() const {
  return PnfGoParser::RuleOptional__returnStmt_1;
}

void PnfGoParser::Optional__returnStmt_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__returnStmt_1(this);
}

void PnfGoParser::Optional__returnStmt_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__returnStmt_1(this);
}


antlrcpp::Any PnfGoParser::Optional__returnStmt_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitOptional__returnStmt_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Optional__returnStmt_1Context* PnfGoParser::optional__returnStmt_1() {
  Optional__returnStmt_1Context *_localctx = _tracker.createInstance<Optional__returnStmt_1Context>(_ctx, getState());
  enterRule(_localctx, 232, PnfGoParser::RuleOptional__returnStmt_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(880);
    _errHandler->sync(this);

    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 34, _ctx)) {
    case 1: {
      setState(879);
      expressionList();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__breakStmt_1Context ------------------------------------------------------------------

PnfGoParser::Optional__breakStmt_1Context::Optional__breakStmt_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::Optional__breakStmt_1Context::IDENTIFIER() {
  return getToken(PnfGoParser::IDENTIFIER, 0);
}


size_t PnfGoParser::Optional__breakStmt_1Context::getRuleIndex() const {
  return PnfGoParser::RuleOptional__breakStmt_1;
}

void PnfGoParser::Optional__breakStmt_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__breakStmt_1(this);
}

void PnfGoParser::Optional__breakStmt_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__breakStmt_1(this);
}


antlrcpp::Any PnfGoParser::Optional__breakStmt_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitOptional__breakStmt_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Optional__breakStmt_1Context* PnfGoParser::optional__breakStmt_1() {
  Optional__breakStmt_1Context *_localctx = _tracker.createInstance<Optional__breakStmt_1Context>(_ctx, getState());
  enterRule(_localctx, 234, PnfGoParser::RuleOptional__breakStmt_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(883);
    _errHandler->sync(this);

    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 35, _ctx)) {
    case 1: {
      setState(882);
      match(PnfGoParser::IDENTIFIER);
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__ifStmt_1Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__ifStmt_1Context::Aux_rule__ifStmt_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::SimpleStmtContext* PnfGoParser::Aux_rule__ifStmt_1Context::simpleStmt() {
  return getRuleContext<PnfGoParser::SimpleStmtContext>(0);
}

tree::TerminalNode* PnfGoParser::Aux_rule__ifStmt_1Context::SEMI() {
  return getToken(PnfGoParser::SEMI, 0);
}


size_t PnfGoParser::Aux_rule__ifStmt_1Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__ifStmt_1;
}

void PnfGoParser::Aux_rule__ifStmt_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__ifStmt_1(this);
}

void PnfGoParser::Aux_rule__ifStmt_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__ifStmt_1(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__ifStmt_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__ifStmt_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__ifStmt_1Context* PnfGoParser::aux_rule__ifStmt_1() {
  Aux_rule__ifStmt_1Context *_localctx = _tracker.createInstance<Aux_rule__ifStmt_1Context>(_ctx, getState());
  enterRule(_localctx, 236, PnfGoParser::RuleAux_rule__ifStmt_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(885);
    simpleStmt();
    setState(886);
    match(PnfGoParser::SEMI);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__ifStmt_2Context ------------------------------------------------------------------

PnfGoParser::Optional__ifStmt_2Context::Optional__ifStmt_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Aux_rule__ifStmt_1Context* PnfGoParser::Optional__ifStmt_2Context::aux_rule__ifStmt_1() {
  return getRuleContext<PnfGoParser::Aux_rule__ifStmt_1Context>(0);
}


size_t PnfGoParser::Optional__ifStmt_2Context::getRuleIndex() const {
  return PnfGoParser::RuleOptional__ifStmt_2;
}

void PnfGoParser::Optional__ifStmt_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__ifStmt_2(this);
}

void PnfGoParser::Optional__ifStmt_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__ifStmt_2(this);
}


antlrcpp::Any PnfGoParser::Optional__ifStmt_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitOptional__ifStmt_2(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Optional__ifStmt_2Context* PnfGoParser::optional__ifStmt_2() {
  Optional__ifStmt_2Context *_localctx = _tracker.createInstance<Optional__ifStmt_2Context>(_ctx, getState());
  enterRule(_localctx, 238, PnfGoParser::RuleOptional__ifStmt_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(889);
    _errHandler->sync(this);

    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 36, _ctx)) {
    case 1: {
      setState(888);
      aux_rule__ifStmt_1();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__ifStmt_3Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__ifStmt_3Context::Aux_rule__ifStmt_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::Aux_rule__ifStmt_3Context::ELSE() {
  return getToken(PnfGoParser::ELSE, 0);
}

PnfGoParser::Altnt_block__ifStmt_5Context* PnfGoParser::Aux_rule__ifStmt_3Context::altnt_block__ifStmt_5() {
  return getRuleContext<PnfGoParser::Altnt_block__ifStmt_5Context>(0);
}


size_t PnfGoParser::Aux_rule__ifStmt_3Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__ifStmt_3;
}

void PnfGoParser::Aux_rule__ifStmt_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__ifStmt_3(this);
}

void PnfGoParser::Aux_rule__ifStmt_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__ifStmt_3(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__ifStmt_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__ifStmt_3(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__ifStmt_3Context* PnfGoParser::aux_rule__ifStmt_3() {
  Aux_rule__ifStmt_3Context *_localctx = _tracker.createInstance<Aux_rule__ifStmt_3Context>(_ctx, getState());
  enterRule(_localctx, 240, PnfGoParser::RuleAux_rule__ifStmt_3);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(891);
    match(PnfGoParser::ELSE);
    setState(892);
    altnt_block__ifStmt_5();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__ifStmt_4Context ------------------------------------------------------------------

PnfGoParser::Optional__ifStmt_4Context::Optional__ifStmt_4Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Aux_rule__ifStmt_3Context* PnfGoParser::Optional__ifStmt_4Context::aux_rule__ifStmt_3() {
  return getRuleContext<PnfGoParser::Aux_rule__ifStmt_3Context>(0);
}


size_t PnfGoParser::Optional__ifStmt_4Context::getRuleIndex() const {
  return PnfGoParser::RuleOptional__ifStmt_4;
}

void PnfGoParser::Optional__ifStmt_4Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__ifStmt_4(this);
}

void PnfGoParser::Optional__ifStmt_4Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__ifStmt_4(this);
}


antlrcpp::Any PnfGoParser::Optional__ifStmt_4Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitOptional__ifStmt_4(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Optional__ifStmt_4Context* PnfGoParser::optional__ifStmt_4() {
  Optional__ifStmt_4Context *_localctx = _tracker.createInstance<Optional__ifStmt_4Context>(_ctx, getState());
  enterRule(_localctx, 242, PnfGoParser::RuleOptional__ifStmt_4);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(895);
    _errHandler->sync(this);

    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 37, _ctx)) {
    case 1: {
      setState(894);
      aux_rule__ifStmt_3();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__exprSwitchStmt_3Context ------------------------------------------------------------------

PnfGoParser::Optional__exprSwitchStmt_3Context::Optional__exprSwitchStmt_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::ExpressionContext* PnfGoParser::Optional__exprSwitchStmt_3Context::expression() {
  return getRuleContext<PnfGoParser::ExpressionContext>(0);
}


size_t PnfGoParser::Optional__exprSwitchStmt_3Context::getRuleIndex() const {
  return PnfGoParser::RuleOptional__exprSwitchStmt_3;
}

void PnfGoParser::Optional__exprSwitchStmt_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__exprSwitchStmt_3(this);
}

void PnfGoParser::Optional__exprSwitchStmt_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__exprSwitchStmt_3(this);
}


antlrcpp::Any PnfGoParser::Optional__exprSwitchStmt_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitOptional__exprSwitchStmt_3(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Optional__exprSwitchStmt_3Context* PnfGoParser::optional__exprSwitchStmt_3() {
  Optional__exprSwitchStmt_3Context *_localctx = _tracker.createInstance<Optional__exprSwitchStmt_3Context>(_ctx, getState());
  enterRule(_localctx, 244, PnfGoParser::RuleOptional__exprSwitchStmt_3);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(898);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if ((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << PnfGoParser::FUNC)
      | (1ULL << PnfGoParser::INTERFACE)
      | (1ULL << PnfGoParser::MAP)
      | (1ULL << PnfGoParser::STRUCT)
      | (1ULL << PnfGoParser::CHAN)
      | (1ULL << PnfGoParser::NIL_LIT)
      | (1ULL << PnfGoParser::IDENTIFIER)
      | (1ULL << PnfGoParser::L_PAREN)
      | (1ULL << PnfGoParser::L_BRACKET)
      | (1ULL << PnfGoParser::EXCLAMATION)
      | (1ULL << PnfGoParser::PLUS)
      | (1ULL << PnfGoParser::MINUS)
      | (1ULL << PnfGoParser::CARET)
      | (1ULL << PnfGoParser::STAR)
      | (1ULL << PnfGoParser::AMPERSAND)
      | (1ULL << PnfGoParser::RECEIVE))) != 0) || ((((_la - 64) & ~ 0x3fULL) == 0) &&
      ((1ULL << (_la - 64)) & ((1ULL << (PnfGoParser::DECIMAL_LIT - 64))
      | (1ULL << (PnfGoParser::OCTAL_LIT - 64))
      | (1ULL << (PnfGoParser::HEX_LIT - 64))
      | (1ULL << (PnfGoParser::FLOAT_LIT - 64))
      | (1ULL << (PnfGoParser::IMAGINARY_LIT - 64))
      | (1ULL << (PnfGoParser::RUNE_LIT - 64))
      | (1ULL << (PnfGoParser::RAW_STRING_LIT - 64))
      | (1ULL << (PnfGoParser::INTERPRETED_STRING_LIT - 64)))) != 0)) {
      setState(897);
      expression();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__exprSwitchStmt_4Context ------------------------------------------------------------------

PnfGoParser::Kleene_star__exprSwitchStmt_4Context::Kleene_star__exprSwitchStmt_4Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfGoParser::ExprCaseClauseContext *> PnfGoParser::Kleene_star__exprSwitchStmt_4Context::exprCaseClause() {
  return getRuleContexts<PnfGoParser::ExprCaseClauseContext>();
}

PnfGoParser::ExprCaseClauseContext* PnfGoParser::Kleene_star__exprSwitchStmt_4Context::exprCaseClause(size_t i) {
  return getRuleContext<PnfGoParser::ExprCaseClauseContext>(i);
}


size_t PnfGoParser::Kleene_star__exprSwitchStmt_4Context::getRuleIndex() const {
  return PnfGoParser::RuleKleene_star__exprSwitchStmt_4;
}

void PnfGoParser::Kleene_star__exprSwitchStmt_4Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__exprSwitchStmt_4(this);
}

void PnfGoParser::Kleene_star__exprSwitchStmt_4Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__exprSwitchStmt_4(this);
}


antlrcpp::Any PnfGoParser::Kleene_star__exprSwitchStmt_4Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitKleene_star__exprSwitchStmt_4(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Kleene_star__exprSwitchStmt_4Context* PnfGoParser::kleene_star__exprSwitchStmt_4() {
  Kleene_star__exprSwitchStmt_4Context *_localctx = _tracker.createInstance<Kleene_star__exprSwitchStmt_4Context>(_ctx, getState());
  enterRule(_localctx, 246, PnfGoParser::RuleKleene_star__exprSwitchStmt_4);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(903);
    _errHandler->sync(this);
    _la = _input->LA(1);
    while (_la == PnfGoParser::DEFAULT

    || _la == PnfGoParser::CASE) {
      setState(900);
      exprCaseClause();
      setState(905);
      _errHandler->sync(this);
      _la = _input->LA(1);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__typeSwitchStmt_3Context ------------------------------------------------------------------

PnfGoParser::Kleene_star__typeSwitchStmt_3Context::Kleene_star__typeSwitchStmt_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfGoParser::TypeCaseClauseContext *> PnfGoParser::Kleene_star__typeSwitchStmt_3Context::typeCaseClause() {
  return getRuleContexts<PnfGoParser::TypeCaseClauseContext>();
}

PnfGoParser::TypeCaseClauseContext* PnfGoParser::Kleene_star__typeSwitchStmt_3Context::typeCaseClause(size_t i) {
  return getRuleContext<PnfGoParser::TypeCaseClauseContext>(i);
}


size_t PnfGoParser::Kleene_star__typeSwitchStmt_3Context::getRuleIndex() const {
  return PnfGoParser::RuleKleene_star__typeSwitchStmt_3;
}

void PnfGoParser::Kleene_star__typeSwitchStmt_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__typeSwitchStmt_3(this);
}

void PnfGoParser::Kleene_star__typeSwitchStmt_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__typeSwitchStmt_3(this);
}


antlrcpp::Any PnfGoParser::Kleene_star__typeSwitchStmt_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitKleene_star__typeSwitchStmt_3(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Kleene_star__typeSwitchStmt_3Context* PnfGoParser::kleene_star__typeSwitchStmt_3() {
  Kleene_star__typeSwitchStmt_3Context *_localctx = _tracker.createInstance<Kleene_star__typeSwitchStmt_3Context>(_ctx, getState());
  enterRule(_localctx, 248, PnfGoParser::RuleKleene_star__typeSwitchStmt_3);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(909);
    _errHandler->sync(this);
    _la = _input->LA(1);
    while (_la == PnfGoParser::DEFAULT

    || _la == PnfGoParser::CASE) {
      setState(906);
      typeCaseClause();
      setState(911);
      _errHandler->sync(this);
      _la = _input->LA(1);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__typeSwitchGuard_1Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__typeSwitchGuard_1Context::Aux_rule__typeSwitchGuard_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::Aux_rule__typeSwitchGuard_1Context::IDENTIFIER() {
  return getToken(PnfGoParser::IDENTIFIER, 0);
}

tree::TerminalNode* PnfGoParser::Aux_rule__typeSwitchGuard_1Context::DECLARE_ASSIGN() {
  return getToken(PnfGoParser::DECLARE_ASSIGN, 0);
}


size_t PnfGoParser::Aux_rule__typeSwitchGuard_1Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__typeSwitchGuard_1;
}

void PnfGoParser::Aux_rule__typeSwitchGuard_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__typeSwitchGuard_1(this);
}

void PnfGoParser::Aux_rule__typeSwitchGuard_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__typeSwitchGuard_1(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__typeSwitchGuard_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__typeSwitchGuard_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__typeSwitchGuard_1Context* PnfGoParser::aux_rule__typeSwitchGuard_1() {
  Aux_rule__typeSwitchGuard_1Context *_localctx = _tracker.createInstance<Aux_rule__typeSwitchGuard_1Context>(_ctx, getState());
  enterRule(_localctx, 250, PnfGoParser::RuleAux_rule__typeSwitchGuard_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(912);
    match(PnfGoParser::IDENTIFIER);
    setState(913);
    match(PnfGoParser::DECLARE_ASSIGN);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__typeSwitchGuard_2Context ------------------------------------------------------------------

PnfGoParser::Optional__typeSwitchGuard_2Context::Optional__typeSwitchGuard_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Aux_rule__typeSwitchGuard_1Context* PnfGoParser::Optional__typeSwitchGuard_2Context::aux_rule__typeSwitchGuard_1() {
  return getRuleContext<PnfGoParser::Aux_rule__typeSwitchGuard_1Context>(0);
}


size_t PnfGoParser::Optional__typeSwitchGuard_2Context::getRuleIndex() const {
  return PnfGoParser::RuleOptional__typeSwitchGuard_2;
}

void PnfGoParser::Optional__typeSwitchGuard_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__typeSwitchGuard_2(this);
}

void PnfGoParser::Optional__typeSwitchGuard_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__typeSwitchGuard_2(this);
}


antlrcpp::Any PnfGoParser::Optional__typeSwitchGuard_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitOptional__typeSwitchGuard_2(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Optional__typeSwitchGuard_2Context* PnfGoParser::optional__typeSwitchGuard_2() {
  Optional__typeSwitchGuard_2Context *_localctx = _tracker.createInstance<Optional__typeSwitchGuard_2Context>(_ctx, getState());
  enterRule(_localctx, 252, PnfGoParser::RuleOptional__typeSwitchGuard_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(916);
    _errHandler->sync(this);

    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 41, _ctx)) {
    case 1: {
      setState(915);
      aux_rule__typeSwitchGuard_1();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__typeList_1Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__typeList_1Context::Aux_rule__typeList_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::Aux_rule__typeList_1Context::COMMA() {
  return getToken(PnfGoParser::COMMA, 0);
}

PnfGoParser::Altnt_block__typeList_3Context* PnfGoParser::Aux_rule__typeList_1Context::altnt_block__typeList_3() {
  return getRuleContext<PnfGoParser::Altnt_block__typeList_3Context>(0);
}


size_t PnfGoParser::Aux_rule__typeList_1Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__typeList_1;
}

void PnfGoParser::Aux_rule__typeList_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__typeList_1(this);
}

void PnfGoParser::Aux_rule__typeList_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__typeList_1(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__typeList_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__typeList_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__typeList_1Context* PnfGoParser::aux_rule__typeList_1() {
  Aux_rule__typeList_1Context *_localctx = _tracker.createInstance<Aux_rule__typeList_1Context>(_ctx, getState());
  enterRule(_localctx, 254, PnfGoParser::RuleAux_rule__typeList_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(918);
    match(PnfGoParser::COMMA);
    setState(919);
    altnt_block__typeList_3();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__typeList_2Context ------------------------------------------------------------------

PnfGoParser::Kleene_star__typeList_2Context::Kleene_star__typeList_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfGoParser::Aux_rule__typeList_1Context *> PnfGoParser::Kleene_star__typeList_2Context::aux_rule__typeList_1() {
  return getRuleContexts<PnfGoParser::Aux_rule__typeList_1Context>();
}

PnfGoParser::Aux_rule__typeList_1Context* PnfGoParser::Kleene_star__typeList_2Context::aux_rule__typeList_1(size_t i) {
  return getRuleContext<PnfGoParser::Aux_rule__typeList_1Context>(i);
}


size_t PnfGoParser::Kleene_star__typeList_2Context::getRuleIndex() const {
  return PnfGoParser::RuleKleene_star__typeList_2;
}

void PnfGoParser::Kleene_star__typeList_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__typeList_2(this);
}

void PnfGoParser::Kleene_star__typeList_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__typeList_2(this);
}


antlrcpp::Any PnfGoParser::Kleene_star__typeList_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitKleene_star__typeList_2(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Kleene_star__typeList_2Context* PnfGoParser::kleene_star__typeList_2() {
  Kleene_star__typeList_2Context *_localctx = _tracker.createInstance<Kleene_star__typeList_2Context>(_ctx, getState());
  enterRule(_localctx, 256, PnfGoParser::RuleKleene_star__typeList_2);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(924);
    _errHandler->sync(this);
    _la = _input->LA(1);
    while (_la == PnfGoParser::COMMA) {
      setState(921);
      aux_rule__typeList_1();
      setState(926);
      _errHandler->sync(this);
      _la = _input->LA(1);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__selectStmt_1Context ------------------------------------------------------------------

PnfGoParser::Kleene_star__selectStmt_1Context::Kleene_star__selectStmt_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfGoParser::CommClauseContext *> PnfGoParser::Kleene_star__selectStmt_1Context::commClause() {
  return getRuleContexts<PnfGoParser::CommClauseContext>();
}

PnfGoParser::CommClauseContext* PnfGoParser::Kleene_star__selectStmt_1Context::commClause(size_t i) {
  return getRuleContext<PnfGoParser::CommClauseContext>(i);
}


size_t PnfGoParser::Kleene_star__selectStmt_1Context::getRuleIndex() const {
  return PnfGoParser::RuleKleene_star__selectStmt_1;
}

void PnfGoParser::Kleene_star__selectStmt_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__selectStmt_1(this);
}

void PnfGoParser::Kleene_star__selectStmt_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__selectStmt_1(this);
}


antlrcpp::Any PnfGoParser::Kleene_star__selectStmt_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitKleene_star__selectStmt_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Kleene_star__selectStmt_1Context* PnfGoParser::kleene_star__selectStmt_1() {
  Kleene_star__selectStmt_1Context *_localctx = _tracker.createInstance<Kleene_star__selectStmt_1Context>(_ctx, getState());
  enterRule(_localctx, 258, PnfGoParser::RuleKleene_star__selectStmt_1);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(930);
    _errHandler->sync(this);
    _la = _input->LA(1);
    while (_la == PnfGoParser::DEFAULT

    || _la == PnfGoParser::CASE) {
      setState(927);
      commClause();
      setState(932);
      _errHandler->sync(this);
      _la = _input->LA(1);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__recvStmt_1Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__recvStmt_1Context::Aux_rule__recvStmt_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Aux_rule__recvStmt_3Context* PnfGoParser::Aux_rule__recvStmt_1Context::aux_rule__recvStmt_3() {
  return getRuleContext<PnfGoParser::Aux_rule__recvStmt_3Context>(0);
}

PnfGoParser::Aux_rule__recvStmt_4Context* PnfGoParser::Aux_rule__recvStmt_1Context::aux_rule__recvStmt_4() {
  return getRuleContext<PnfGoParser::Aux_rule__recvStmt_4Context>(0);
}


size_t PnfGoParser::Aux_rule__recvStmt_1Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__recvStmt_1;
}

void PnfGoParser::Aux_rule__recvStmt_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__recvStmt_1(this);
}

void PnfGoParser::Aux_rule__recvStmt_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__recvStmt_1(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__recvStmt_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__recvStmt_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__recvStmt_1Context* PnfGoParser::aux_rule__recvStmt_1() {
  Aux_rule__recvStmt_1Context *_localctx = _tracker.createInstance<Aux_rule__recvStmt_1Context>(_ctx, getState());
  enterRule(_localctx, 260, PnfGoParser::RuleAux_rule__recvStmt_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(935);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 44, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(933);
      aux_rule__recvStmt_3();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(934);
      aux_rule__recvStmt_4();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__recvStmt_2Context ------------------------------------------------------------------

PnfGoParser::Optional__recvStmt_2Context::Optional__recvStmt_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Aux_rule__recvStmt_1Context* PnfGoParser::Optional__recvStmt_2Context::aux_rule__recvStmt_1() {
  return getRuleContext<PnfGoParser::Aux_rule__recvStmt_1Context>(0);
}


size_t PnfGoParser::Optional__recvStmt_2Context::getRuleIndex() const {
  return PnfGoParser::RuleOptional__recvStmt_2;
}

void PnfGoParser::Optional__recvStmt_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__recvStmt_2(this);
}

void PnfGoParser::Optional__recvStmt_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__recvStmt_2(this);
}


antlrcpp::Any PnfGoParser::Optional__recvStmt_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitOptional__recvStmt_2(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Optional__recvStmt_2Context* PnfGoParser::optional__recvStmt_2() {
  Optional__recvStmt_2Context *_localctx = _tracker.createInstance<Optional__recvStmt_2Context>(_ctx, getState());
  enterRule(_localctx, 262, PnfGoParser::RuleOptional__recvStmt_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(938);
    _errHandler->sync(this);

    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 45, _ctx)) {
    case 1: {
      setState(937);
      aux_rule__recvStmt_1();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__forStmt_1Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__forStmt_1Context::Aux_rule__forStmt_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::ExpressionContext* PnfGoParser::Aux_rule__forStmt_1Context::expression() {
  return getRuleContext<PnfGoParser::ExpressionContext>(0);
}

PnfGoParser::ForClauseContext* PnfGoParser::Aux_rule__forStmt_1Context::forClause() {
  return getRuleContext<PnfGoParser::ForClauseContext>(0);
}

PnfGoParser::RangeClauseContext* PnfGoParser::Aux_rule__forStmt_1Context::rangeClause() {
  return getRuleContext<PnfGoParser::RangeClauseContext>(0);
}


size_t PnfGoParser::Aux_rule__forStmt_1Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__forStmt_1;
}

void PnfGoParser::Aux_rule__forStmt_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__forStmt_1(this);
}

void PnfGoParser::Aux_rule__forStmt_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__forStmt_1(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__forStmt_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__forStmt_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__forStmt_1Context* PnfGoParser::aux_rule__forStmt_1() {
  Aux_rule__forStmt_1Context *_localctx = _tracker.createInstance<Aux_rule__forStmt_1Context>(_ctx, getState());
  enterRule(_localctx, 264, PnfGoParser::RuleAux_rule__forStmt_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(943);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 46, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(940);
      expression();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(941);
      forClause();
      break;
    }

    case 3: {
      enterOuterAlt(_localctx, 3);
      setState(942);
      rangeClause();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__forStmt_2Context ------------------------------------------------------------------

PnfGoParser::Optional__forStmt_2Context::Optional__forStmt_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Aux_rule__forStmt_1Context* PnfGoParser::Optional__forStmt_2Context::aux_rule__forStmt_1() {
  return getRuleContext<PnfGoParser::Aux_rule__forStmt_1Context>(0);
}


size_t PnfGoParser::Optional__forStmt_2Context::getRuleIndex() const {
  return PnfGoParser::RuleOptional__forStmt_2;
}

void PnfGoParser::Optional__forStmt_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__forStmt_2(this);
}

void PnfGoParser::Optional__forStmt_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__forStmt_2(this);
}


antlrcpp::Any PnfGoParser::Optional__forStmt_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitOptional__forStmt_2(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Optional__forStmt_2Context* PnfGoParser::optional__forStmt_2() {
  Optional__forStmt_2Context *_localctx = _tracker.createInstance<Optional__forStmt_2Context>(_ctx, getState());
  enterRule(_localctx, 266, PnfGoParser::RuleOptional__forStmt_2);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(946);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if ((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << PnfGoParser::FUNC)
      | (1ULL << PnfGoParser::INTERFACE)
      | (1ULL << PnfGoParser::MAP)
      | (1ULL << PnfGoParser::STRUCT)
      | (1ULL << PnfGoParser::CHAN)
      | (1ULL << PnfGoParser::RANGE)
      | (1ULL << PnfGoParser::NIL_LIT)
      | (1ULL << PnfGoParser::IDENTIFIER)
      | (1ULL << PnfGoParser::L_PAREN)
      | (1ULL << PnfGoParser::L_BRACKET)
      | (1ULL << PnfGoParser::SEMI)
      | (1ULL << PnfGoParser::EXCLAMATION)
      | (1ULL << PnfGoParser::PLUS)
      | (1ULL << PnfGoParser::MINUS)
      | (1ULL << PnfGoParser::CARET)
      | (1ULL << PnfGoParser::STAR)
      | (1ULL << PnfGoParser::AMPERSAND)
      | (1ULL << PnfGoParser::RECEIVE))) != 0) || ((((_la - 64) & ~ 0x3fULL) == 0) &&
      ((1ULL << (_la - 64)) & ((1ULL << (PnfGoParser::DECIMAL_LIT - 64))
      | (1ULL << (PnfGoParser::OCTAL_LIT - 64))
      | (1ULL << (PnfGoParser::HEX_LIT - 64))
      | (1ULL << (PnfGoParser::FLOAT_LIT - 64))
      | (1ULL << (PnfGoParser::IMAGINARY_LIT - 64))
      | (1ULL << (PnfGoParser::RUNE_LIT - 64))
      | (1ULL << (PnfGoParser::RAW_STRING_LIT - 64))
      | (1ULL << (PnfGoParser::INTERPRETED_STRING_LIT - 64)))) != 0)) {
      setState(945);
      aux_rule__forStmt_1();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__forClause_1Context ------------------------------------------------------------------

PnfGoParser::Optional__forClause_1Context::Optional__forClause_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::SimpleStmtContext* PnfGoParser::Optional__forClause_1Context::simpleStmt() {
  return getRuleContext<PnfGoParser::SimpleStmtContext>(0);
}


size_t PnfGoParser::Optional__forClause_1Context::getRuleIndex() const {
  return PnfGoParser::RuleOptional__forClause_1;
}

void PnfGoParser::Optional__forClause_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__forClause_1(this);
}

void PnfGoParser::Optional__forClause_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__forClause_1(this);
}


antlrcpp::Any PnfGoParser::Optional__forClause_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitOptional__forClause_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Optional__forClause_1Context* PnfGoParser::optional__forClause_1() {
  Optional__forClause_1Context *_localctx = _tracker.createInstance<Optional__forClause_1Context>(_ctx, getState());
  enterRule(_localctx, 268, PnfGoParser::RuleOptional__forClause_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(949);
    _errHandler->sync(this);

    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 48, _ctx)) {
    case 1: {
      setState(948);
      simpleStmt();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__interfaceType_1Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__interfaceType_1Context::Aux_rule__interfaceType_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::MethodSpecContext* PnfGoParser::Aux_rule__interfaceType_1Context::methodSpec() {
  return getRuleContext<PnfGoParser::MethodSpecContext>(0);
}

PnfGoParser::EosContext* PnfGoParser::Aux_rule__interfaceType_1Context::eos() {
  return getRuleContext<PnfGoParser::EosContext>(0);
}


size_t PnfGoParser::Aux_rule__interfaceType_1Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__interfaceType_1;
}

void PnfGoParser::Aux_rule__interfaceType_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__interfaceType_1(this);
}

void PnfGoParser::Aux_rule__interfaceType_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__interfaceType_1(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__interfaceType_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__interfaceType_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__interfaceType_1Context* PnfGoParser::aux_rule__interfaceType_1() {
  Aux_rule__interfaceType_1Context *_localctx = _tracker.createInstance<Aux_rule__interfaceType_1Context>(_ctx, getState());
  enterRule(_localctx, 270, PnfGoParser::RuleAux_rule__interfaceType_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(951);
    methodSpec();
    setState(952);
    eos();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__interfaceType_2Context ------------------------------------------------------------------

PnfGoParser::Kleene_star__interfaceType_2Context::Kleene_star__interfaceType_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfGoParser::Aux_rule__interfaceType_1Context *> PnfGoParser::Kleene_star__interfaceType_2Context::aux_rule__interfaceType_1() {
  return getRuleContexts<PnfGoParser::Aux_rule__interfaceType_1Context>();
}

PnfGoParser::Aux_rule__interfaceType_1Context* PnfGoParser::Kleene_star__interfaceType_2Context::aux_rule__interfaceType_1(size_t i) {
  return getRuleContext<PnfGoParser::Aux_rule__interfaceType_1Context>(i);
}


size_t PnfGoParser::Kleene_star__interfaceType_2Context::getRuleIndex() const {
  return PnfGoParser::RuleKleene_star__interfaceType_2;
}

void PnfGoParser::Kleene_star__interfaceType_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__interfaceType_2(this);
}

void PnfGoParser::Kleene_star__interfaceType_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__interfaceType_2(this);
}


antlrcpp::Any PnfGoParser::Kleene_star__interfaceType_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitKleene_star__interfaceType_2(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Kleene_star__interfaceType_2Context* PnfGoParser::kleene_star__interfaceType_2() {
  Kleene_star__interfaceType_2Context *_localctx = _tracker.createInstance<Kleene_star__interfaceType_2Context>(_ctx, getState());
  enterRule(_localctx, 272, PnfGoParser::RuleKleene_star__interfaceType_2);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(957);
    _errHandler->sync(this);
    _la = _input->LA(1);
    while (_la == PnfGoParser::IDENTIFIER) {
      setState(954);
      aux_rule__interfaceType_1();
      setState(959);
      _errHandler->sync(this);
      _la = _input->LA(1);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__parameters_1Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__parameters_1Context::Aux_rule__parameters_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::Aux_rule__parameters_1Context::COMMA() {
  return getToken(PnfGoParser::COMMA, 0);
}

PnfGoParser::ParameterDeclContext* PnfGoParser::Aux_rule__parameters_1Context::parameterDecl() {
  return getRuleContext<PnfGoParser::ParameterDeclContext>(0);
}


size_t PnfGoParser::Aux_rule__parameters_1Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__parameters_1;
}

void PnfGoParser::Aux_rule__parameters_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__parameters_1(this);
}

void PnfGoParser::Aux_rule__parameters_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__parameters_1(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__parameters_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__parameters_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__parameters_1Context* PnfGoParser::aux_rule__parameters_1() {
  Aux_rule__parameters_1Context *_localctx = _tracker.createInstance<Aux_rule__parameters_1Context>(_ctx, getState());
  enterRule(_localctx, 274, PnfGoParser::RuleAux_rule__parameters_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(960);
    match(PnfGoParser::COMMA);
    setState(961);
    parameterDecl();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__parameters_2Context ------------------------------------------------------------------

PnfGoParser::Kleene_star__parameters_2Context::Kleene_star__parameters_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfGoParser::Aux_rule__parameters_1Context *> PnfGoParser::Kleene_star__parameters_2Context::aux_rule__parameters_1() {
  return getRuleContexts<PnfGoParser::Aux_rule__parameters_1Context>();
}

PnfGoParser::Aux_rule__parameters_1Context* PnfGoParser::Kleene_star__parameters_2Context::aux_rule__parameters_1(size_t i) {
  return getRuleContext<PnfGoParser::Aux_rule__parameters_1Context>(i);
}


size_t PnfGoParser::Kleene_star__parameters_2Context::getRuleIndex() const {
  return PnfGoParser::RuleKleene_star__parameters_2;
}

void PnfGoParser::Kleene_star__parameters_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__parameters_2(this);
}

void PnfGoParser::Kleene_star__parameters_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__parameters_2(this);
}


antlrcpp::Any PnfGoParser::Kleene_star__parameters_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitKleene_star__parameters_2(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Kleene_star__parameters_2Context* PnfGoParser::kleene_star__parameters_2() {
  Kleene_star__parameters_2Context *_localctx = _tracker.createInstance<Kleene_star__parameters_2Context>(_ctx, getState());
  enterRule(_localctx, 276, PnfGoParser::RuleKleene_star__parameters_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    size_t alt;
    enterOuterAlt(_localctx, 1);
    setState(966);
    _errHandler->sync(this);
    alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 50, _ctx);
    while (alt != 2 && alt != atn::ATN::INVALID_ALT_NUMBER) {
      if (alt == 1) {
        setState(963);
        aux_rule__parameters_1(); 
      }
      setState(968);
      _errHandler->sync(this);
      alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 50, _ctx);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__parameters_3Context ------------------------------------------------------------------

PnfGoParser::Optional__parameters_3Context::Optional__parameters_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::Optional__parameters_3Context::COMMA() {
  return getToken(PnfGoParser::COMMA, 0);
}


size_t PnfGoParser::Optional__parameters_3Context::getRuleIndex() const {
  return PnfGoParser::RuleOptional__parameters_3;
}

void PnfGoParser::Optional__parameters_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__parameters_3(this);
}

void PnfGoParser::Optional__parameters_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__parameters_3(this);
}


antlrcpp::Any PnfGoParser::Optional__parameters_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitOptional__parameters_3(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Optional__parameters_3Context* PnfGoParser::optional__parameters_3() {
  Optional__parameters_3Context *_localctx = _tracker.createInstance<Optional__parameters_3Context>(_ctx, getState());
  enterRule(_localctx, 278, PnfGoParser::RuleOptional__parameters_3);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(970);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if (_la == PnfGoParser::COMMA) {
      setState(969);
      match(PnfGoParser::COMMA);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__parameters_4Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__parameters_4Context::Aux_rule__parameters_4Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::ParameterDeclContext* PnfGoParser::Aux_rule__parameters_4Context::parameterDecl() {
  return getRuleContext<PnfGoParser::ParameterDeclContext>(0);
}

PnfGoParser::Kleene_star__parameters_2Context* PnfGoParser::Aux_rule__parameters_4Context::kleene_star__parameters_2() {
  return getRuleContext<PnfGoParser::Kleene_star__parameters_2Context>(0);
}

PnfGoParser::Optional__parameters_3Context* PnfGoParser::Aux_rule__parameters_4Context::optional__parameters_3() {
  return getRuleContext<PnfGoParser::Optional__parameters_3Context>(0);
}


size_t PnfGoParser::Aux_rule__parameters_4Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__parameters_4;
}

void PnfGoParser::Aux_rule__parameters_4Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__parameters_4(this);
}

void PnfGoParser::Aux_rule__parameters_4Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__parameters_4(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__parameters_4Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__parameters_4(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__parameters_4Context* PnfGoParser::aux_rule__parameters_4() {
  Aux_rule__parameters_4Context *_localctx = _tracker.createInstance<Aux_rule__parameters_4Context>(_ctx, getState());
  enterRule(_localctx, 280, PnfGoParser::RuleAux_rule__parameters_4);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(972);
    parameterDecl();
    setState(973);
    kleene_star__parameters_2();
    setState(974);
    optional__parameters_3();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__parameters_5Context ------------------------------------------------------------------

PnfGoParser::Optional__parameters_5Context::Optional__parameters_5Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Aux_rule__parameters_4Context* PnfGoParser::Optional__parameters_5Context::aux_rule__parameters_4() {
  return getRuleContext<PnfGoParser::Aux_rule__parameters_4Context>(0);
}


size_t PnfGoParser::Optional__parameters_5Context::getRuleIndex() const {
  return PnfGoParser::RuleOptional__parameters_5;
}

void PnfGoParser::Optional__parameters_5Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__parameters_5(this);
}

void PnfGoParser::Optional__parameters_5Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__parameters_5(this);
}


antlrcpp::Any PnfGoParser::Optional__parameters_5Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitOptional__parameters_5(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Optional__parameters_5Context* PnfGoParser::optional__parameters_5() {
  Optional__parameters_5Context *_localctx = _tracker.createInstance<Optional__parameters_5Context>(_ctx, getState());
  enterRule(_localctx, 282, PnfGoParser::RuleOptional__parameters_5);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(977);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if ((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << PnfGoParser::FUNC)
      | (1ULL << PnfGoParser::INTERFACE)
      | (1ULL << PnfGoParser::MAP)
      | (1ULL << PnfGoParser::STRUCT)
      | (1ULL << PnfGoParser::CHAN)
      | (1ULL << PnfGoParser::IDENTIFIER)
      | (1ULL << PnfGoParser::L_PAREN)
      | (1ULL << PnfGoParser::L_BRACKET)
      | (1ULL << PnfGoParser::ELLIPSIS)
      | (1ULL << PnfGoParser::STAR)
      | (1ULL << PnfGoParser::RECEIVE))) != 0)) {
      setState(976);
      aux_rule__parameters_4();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__parameterDecl_1Context ------------------------------------------------------------------

PnfGoParser::Optional__parameterDecl_1Context::Optional__parameterDecl_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::IdentifierListContext* PnfGoParser::Optional__parameterDecl_1Context::identifierList() {
  return getRuleContext<PnfGoParser::IdentifierListContext>(0);
}


size_t PnfGoParser::Optional__parameterDecl_1Context::getRuleIndex() const {
  return PnfGoParser::RuleOptional__parameterDecl_1;
}

void PnfGoParser::Optional__parameterDecl_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__parameterDecl_1(this);
}

void PnfGoParser::Optional__parameterDecl_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__parameterDecl_1(this);
}


antlrcpp::Any PnfGoParser::Optional__parameterDecl_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitOptional__parameterDecl_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Optional__parameterDecl_1Context* PnfGoParser::optional__parameterDecl_1() {
  Optional__parameterDecl_1Context *_localctx = _tracker.createInstance<Optional__parameterDecl_1Context>(_ctx, getState());
  enterRule(_localctx, 284, PnfGoParser::RuleOptional__parameterDecl_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(980);
    _errHandler->sync(this);

    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 53, _ctx)) {
    case 1: {
      setState(979);
      identifierList();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__parameterDecl_2Context ------------------------------------------------------------------

PnfGoParser::Optional__parameterDecl_2Context::Optional__parameterDecl_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::Optional__parameterDecl_2Context::ELLIPSIS() {
  return getToken(PnfGoParser::ELLIPSIS, 0);
}


size_t PnfGoParser::Optional__parameterDecl_2Context::getRuleIndex() const {
  return PnfGoParser::RuleOptional__parameterDecl_2;
}

void PnfGoParser::Optional__parameterDecl_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__parameterDecl_2(this);
}

void PnfGoParser::Optional__parameterDecl_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__parameterDecl_2(this);
}


antlrcpp::Any PnfGoParser::Optional__parameterDecl_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitOptional__parameterDecl_2(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Optional__parameterDecl_2Context* PnfGoParser::optional__parameterDecl_2() {
  Optional__parameterDecl_2Context *_localctx = _tracker.createInstance<Optional__parameterDecl_2Context>(_ctx, getState());
  enterRule(_localctx, 286, PnfGoParser::RuleOptional__parameterDecl_2);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(983);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if (_la == PnfGoParser::ELLIPSIS) {
      setState(982);
      match(PnfGoParser::ELLIPSIS);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__conversion_1Context ------------------------------------------------------------------

PnfGoParser::Optional__conversion_1Context::Optional__conversion_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::Optional__conversion_1Context::COMMA() {
  return getToken(PnfGoParser::COMMA, 0);
}


size_t PnfGoParser::Optional__conversion_1Context::getRuleIndex() const {
  return PnfGoParser::RuleOptional__conversion_1;
}

void PnfGoParser::Optional__conversion_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__conversion_1(this);
}

void PnfGoParser::Optional__conversion_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__conversion_1(this);
}


antlrcpp::Any PnfGoParser::Optional__conversion_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitOptional__conversion_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Optional__conversion_1Context* PnfGoParser::optional__conversion_1() {
  Optional__conversion_1Context *_localctx = _tracker.createInstance<Optional__conversion_1Context>(_ctx, getState());
  enterRule(_localctx, 288, PnfGoParser::RuleOptional__conversion_1);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(986);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if (_la == PnfGoParser::COMMA) {
      setState(985);
      match(PnfGoParser::COMMA);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__literalValue_2Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__literalValue_2Context::Aux_rule__literalValue_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::ElementListContext* PnfGoParser::Aux_rule__literalValue_2Context::elementList() {
  return getRuleContext<PnfGoParser::ElementListContext>(0);
}

PnfGoParser::Optional__conversion_1Context* PnfGoParser::Aux_rule__literalValue_2Context::optional__conversion_1() {
  return getRuleContext<PnfGoParser::Optional__conversion_1Context>(0);
}


size_t PnfGoParser::Aux_rule__literalValue_2Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__literalValue_2;
}

void PnfGoParser::Aux_rule__literalValue_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__literalValue_2(this);
}

void PnfGoParser::Aux_rule__literalValue_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__literalValue_2(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__literalValue_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__literalValue_2(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__literalValue_2Context* PnfGoParser::aux_rule__literalValue_2() {
  Aux_rule__literalValue_2Context *_localctx = _tracker.createInstance<Aux_rule__literalValue_2Context>(_ctx, getState());
  enterRule(_localctx, 290, PnfGoParser::RuleAux_rule__literalValue_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(988);
    elementList();
    setState(989);
    optional__conversion_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__literalValue_3Context ------------------------------------------------------------------

PnfGoParser::Optional__literalValue_3Context::Optional__literalValue_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Aux_rule__literalValue_2Context* PnfGoParser::Optional__literalValue_3Context::aux_rule__literalValue_2() {
  return getRuleContext<PnfGoParser::Aux_rule__literalValue_2Context>(0);
}


size_t PnfGoParser::Optional__literalValue_3Context::getRuleIndex() const {
  return PnfGoParser::RuleOptional__literalValue_3;
}

void PnfGoParser::Optional__literalValue_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__literalValue_3(this);
}

void PnfGoParser::Optional__literalValue_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__literalValue_3(this);
}


antlrcpp::Any PnfGoParser::Optional__literalValue_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitOptional__literalValue_3(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Optional__literalValue_3Context* PnfGoParser::optional__literalValue_3() {
  Optional__literalValue_3Context *_localctx = _tracker.createInstance<Optional__literalValue_3Context>(_ctx, getState());
  enterRule(_localctx, 292, PnfGoParser::RuleOptional__literalValue_3);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(992);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if ((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << PnfGoParser::FUNC)
      | (1ULL << PnfGoParser::INTERFACE)
      | (1ULL << PnfGoParser::MAP)
      | (1ULL << PnfGoParser::STRUCT)
      | (1ULL << PnfGoParser::CHAN)
      | (1ULL << PnfGoParser::NIL_LIT)
      | (1ULL << PnfGoParser::IDENTIFIER)
      | (1ULL << PnfGoParser::L_PAREN)
      | (1ULL << PnfGoParser::L_CURLY)
      | (1ULL << PnfGoParser::L_BRACKET)
      | (1ULL << PnfGoParser::EXCLAMATION)
      | (1ULL << PnfGoParser::PLUS)
      | (1ULL << PnfGoParser::MINUS)
      | (1ULL << PnfGoParser::CARET)
      | (1ULL << PnfGoParser::STAR)
      | (1ULL << PnfGoParser::AMPERSAND)
      | (1ULL << PnfGoParser::RECEIVE))) != 0) || ((((_la - 64) & ~ 0x3fULL) == 0) &&
      ((1ULL << (_la - 64)) & ((1ULL << (PnfGoParser::DECIMAL_LIT - 64))
      | (1ULL << (PnfGoParser::OCTAL_LIT - 64))
      | (1ULL << (PnfGoParser::HEX_LIT - 64))
      | (1ULL << (PnfGoParser::FLOAT_LIT - 64))
      | (1ULL << (PnfGoParser::IMAGINARY_LIT - 64))
      | (1ULL << (PnfGoParser::RUNE_LIT - 64))
      | (1ULL << (PnfGoParser::RAW_STRING_LIT - 64))
      | (1ULL << (PnfGoParser::INTERPRETED_STRING_LIT - 64)))) != 0)) {
      setState(991);
      aux_rule__literalValue_2();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__elementList_1Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__elementList_1Context::Aux_rule__elementList_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::Aux_rule__elementList_1Context::COMMA() {
  return getToken(PnfGoParser::COMMA, 0);
}

PnfGoParser::KeyedElementContext* PnfGoParser::Aux_rule__elementList_1Context::keyedElement() {
  return getRuleContext<PnfGoParser::KeyedElementContext>(0);
}


size_t PnfGoParser::Aux_rule__elementList_1Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__elementList_1;
}

void PnfGoParser::Aux_rule__elementList_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__elementList_1(this);
}

void PnfGoParser::Aux_rule__elementList_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__elementList_1(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__elementList_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__elementList_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__elementList_1Context* PnfGoParser::aux_rule__elementList_1() {
  Aux_rule__elementList_1Context *_localctx = _tracker.createInstance<Aux_rule__elementList_1Context>(_ctx, getState());
  enterRule(_localctx, 294, PnfGoParser::RuleAux_rule__elementList_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(994);
    match(PnfGoParser::COMMA);
    setState(995);
    keyedElement();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__elementList_2Context ------------------------------------------------------------------

PnfGoParser::Kleene_star__elementList_2Context::Kleene_star__elementList_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfGoParser::Aux_rule__elementList_1Context *> PnfGoParser::Kleene_star__elementList_2Context::aux_rule__elementList_1() {
  return getRuleContexts<PnfGoParser::Aux_rule__elementList_1Context>();
}

PnfGoParser::Aux_rule__elementList_1Context* PnfGoParser::Kleene_star__elementList_2Context::aux_rule__elementList_1(size_t i) {
  return getRuleContext<PnfGoParser::Aux_rule__elementList_1Context>(i);
}


size_t PnfGoParser::Kleene_star__elementList_2Context::getRuleIndex() const {
  return PnfGoParser::RuleKleene_star__elementList_2;
}

void PnfGoParser::Kleene_star__elementList_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__elementList_2(this);
}

void PnfGoParser::Kleene_star__elementList_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__elementList_2(this);
}


antlrcpp::Any PnfGoParser::Kleene_star__elementList_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitKleene_star__elementList_2(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Kleene_star__elementList_2Context* PnfGoParser::kleene_star__elementList_2() {
  Kleene_star__elementList_2Context *_localctx = _tracker.createInstance<Kleene_star__elementList_2Context>(_ctx, getState());
  enterRule(_localctx, 296, PnfGoParser::RuleKleene_star__elementList_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    size_t alt;
    enterOuterAlt(_localctx, 1);
    setState(1000);
    _errHandler->sync(this);
    alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 57, _ctx);
    while (alt != 2 && alt != atn::ATN::INVALID_ALT_NUMBER) {
      if (alt == 1) {
        setState(997);
        aux_rule__elementList_1(); 
      }
      setState(1002);
      _errHandler->sync(this);
      alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 57, _ctx);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__keyedElement_1Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__keyedElement_1Context::Aux_rule__keyedElement_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::KeyContext* PnfGoParser::Aux_rule__keyedElement_1Context::key() {
  return getRuleContext<PnfGoParser::KeyContext>(0);
}

tree::TerminalNode* PnfGoParser::Aux_rule__keyedElement_1Context::COLON() {
  return getToken(PnfGoParser::COLON, 0);
}


size_t PnfGoParser::Aux_rule__keyedElement_1Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__keyedElement_1;
}

void PnfGoParser::Aux_rule__keyedElement_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__keyedElement_1(this);
}

void PnfGoParser::Aux_rule__keyedElement_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__keyedElement_1(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__keyedElement_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__keyedElement_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__keyedElement_1Context* PnfGoParser::aux_rule__keyedElement_1() {
  Aux_rule__keyedElement_1Context *_localctx = _tracker.createInstance<Aux_rule__keyedElement_1Context>(_ctx, getState());
  enterRule(_localctx, 298, PnfGoParser::RuleAux_rule__keyedElement_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1003);
    key();
    setState(1004);
    match(PnfGoParser::COLON);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__keyedElement_2Context ------------------------------------------------------------------

PnfGoParser::Optional__keyedElement_2Context::Optional__keyedElement_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Aux_rule__keyedElement_1Context* PnfGoParser::Optional__keyedElement_2Context::aux_rule__keyedElement_1() {
  return getRuleContext<PnfGoParser::Aux_rule__keyedElement_1Context>(0);
}


size_t PnfGoParser::Optional__keyedElement_2Context::getRuleIndex() const {
  return PnfGoParser::RuleOptional__keyedElement_2;
}

void PnfGoParser::Optional__keyedElement_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__keyedElement_2(this);
}

void PnfGoParser::Optional__keyedElement_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__keyedElement_2(this);
}


antlrcpp::Any PnfGoParser::Optional__keyedElement_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitOptional__keyedElement_2(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Optional__keyedElement_2Context* PnfGoParser::optional__keyedElement_2() {
  Optional__keyedElement_2Context *_localctx = _tracker.createInstance<Optional__keyedElement_2Context>(_ctx, getState());
  enterRule(_localctx, 300, PnfGoParser::RuleOptional__keyedElement_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1007);
    _errHandler->sync(this);

    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 58, _ctx)) {
    case 1: {
      setState(1006);
      aux_rule__keyedElement_1();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__structType_1Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__structType_1Context::Aux_rule__structType_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::FieldDeclContext* PnfGoParser::Aux_rule__structType_1Context::fieldDecl() {
  return getRuleContext<PnfGoParser::FieldDeclContext>(0);
}

PnfGoParser::EosContext* PnfGoParser::Aux_rule__structType_1Context::eos() {
  return getRuleContext<PnfGoParser::EosContext>(0);
}


size_t PnfGoParser::Aux_rule__structType_1Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__structType_1;
}

void PnfGoParser::Aux_rule__structType_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__structType_1(this);
}

void PnfGoParser::Aux_rule__structType_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__structType_1(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__structType_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__structType_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__structType_1Context* PnfGoParser::aux_rule__structType_1() {
  Aux_rule__structType_1Context *_localctx = _tracker.createInstance<Aux_rule__structType_1Context>(_ctx, getState());
  enterRule(_localctx, 302, PnfGoParser::RuleAux_rule__structType_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1009);
    fieldDecl();
    setState(1010);
    eos();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__structType_2Context ------------------------------------------------------------------

PnfGoParser::Kleene_star__structType_2Context::Kleene_star__structType_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfGoParser::Aux_rule__structType_1Context *> PnfGoParser::Kleene_star__structType_2Context::aux_rule__structType_1() {
  return getRuleContexts<PnfGoParser::Aux_rule__structType_1Context>();
}

PnfGoParser::Aux_rule__structType_1Context* PnfGoParser::Kleene_star__structType_2Context::aux_rule__structType_1(size_t i) {
  return getRuleContext<PnfGoParser::Aux_rule__structType_1Context>(i);
}


size_t PnfGoParser::Kleene_star__structType_2Context::getRuleIndex() const {
  return PnfGoParser::RuleKleene_star__structType_2;
}

void PnfGoParser::Kleene_star__structType_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__structType_2(this);
}

void PnfGoParser::Kleene_star__structType_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__structType_2(this);
}


antlrcpp::Any PnfGoParser::Kleene_star__structType_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitKleene_star__structType_2(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Kleene_star__structType_2Context* PnfGoParser::kleene_star__structType_2() {
  Kleene_star__structType_2Context *_localctx = _tracker.createInstance<Kleene_star__structType_2Context>(_ctx, getState());
  enterRule(_localctx, 304, PnfGoParser::RuleKleene_star__structType_2);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1015);
    _errHandler->sync(this);
    _la = _input->LA(1);
    while (_la == PnfGoParser::IDENTIFIER

    || _la == PnfGoParser::STAR) {
      setState(1012);
      aux_rule__structType_1();
      setState(1017);
      _errHandler->sync(this);
      _la = _input->LA(1);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__fieldDecl_1Context ------------------------------------------------------------------

PnfGoParser::Optional__fieldDecl_1Context::Optional__fieldDecl_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::String_Context* PnfGoParser::Optional__fieldDecl_1Context::string_() {
  return getRuleContext<PnfGoParser::String_Context>(0);
}


size_t PnfGoParser::Optional__fieldDecl_1Context::getRuleIndex() const {
  return PnfGoParser::RuleOptional__fieldDecl_1;
}

void PnfGoParser::Optional__fieldDecl_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__fieldDecl_1(this);
}

void PnfGoParser::Optional__fieldDecl_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__fieldDecl_1(this);
}


antlrcpp::Any PnfGoParser::Optional__fieldDecl_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitOptional__fieldDecl_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Optional__fieldDecl_1Context* PnfGoParser::optional__fieldDecl_1() {
  Optional__fieldDecl_1Context *_localctx = _tracker.createInstance<Optional__fieldDecl_1Context>(_ctx, getState());
  enterRule(_localctx, 306, PnfGoParser::RuleOptional__fieldDecl_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1019);
    _errHandler->sync(this);

    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 60, _ctx)) {
    case 1: {
      setState(1018);
      string_();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__anonymousField_1Context ------------------------------------------------------------------

PnfGoParser::Optional__anonymousField_1Context::Optional__anonymousField_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::Optional__anonymousField_1Context::STAR() {
  return getToken(PnfGoParser::STAR, 0);
}


size_t PnfGoParser::Optional__anonymousField_1Context::getRuleIndex() const {
  return PnfGoParser::RuleOptional__anonymousField_1;
}

void PnfGoParser::Optional__anonymousField_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__anonymousField_1(this);
}

void PnfGoParser::Optional__anonymousField_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__anonymousField_1(this);
}


antlrcpp::Any PnfGoParser::Optional__anonymousField_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitOptional__anonymousField_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Optional__anonymousField_1Context* PnfGoParser::optional__anonymousField_1() {
  Optional__anonymousField_1Context *_localctx = _tracker.createInstance<Optional__anonymousField_1Context>(_ctx, getState());
  enterRule(_localctx, 308, PnfGoParser::RuleOptional__anonymousField_1);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1022);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if (_la == PnfGoParser::STAR) {
      setState(1021);
      match(PnfGoParser::STAR);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__arguments_1Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__arguments_1Context::Aux_rule__arguments_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::Aux_rule__arguments_1Context::COMMA() {
  return getToken(PnfGoParser::COMMA, 0);
}

PnfGoParser::ExpressionListContext* PnfGoParser::Aux_rule__arguments_1Context::expressionList() {
  return getRuleContext<PnfGoParser::ExpressionListContext>(0);
}


size_t PnfGoParser::Aux_rule__arguments_1Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__arguments_1;
}

void PnfGoParser::Aux_rule__arguments_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__arguments_1(this);
}

void PnfGoParser::Aux_rule__arguments_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__arguments_1(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__arguments_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__arguments_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__arguments_1Context* PnfGoParser::aux_rule__arguments_1() {
  Aux_rule__arguments_1Context *_localctx = _tracker.createInstance<Aux_rule__arguments_1Context>(_ctx, getState());
  enterRule(_localctx, 310, PnfGoParser::RuleAux_rule__arguments_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1024);
    match(PnfGoParser::COMMA);
    setState(1025);
    expressionList();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__arguments_2Context ------------------------------------------------------------------

PnfGoParser::Optional__arguments_2Context::Optional__arguments_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Aux_rule__arguments_1Context* PnfGoParser::Optional__arguments_2Context::aux_rule__arguments_1() {
  return getRuleContext<PnfGoParser::Aux_rule__arguments_1Context>(0);
}


size_t PnfGoParser::Optional__arguments_2Context::getRuleIndex() const {
  return PnfGoParser::RuleOptional__arguments_2;
}

void PnfGoParser::Optional__arguments_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__arguments_2(this);
}

void PnfGoParser::Optional__arguments_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__arguments_2(this);
}


antlrcpp::Any PnfGoParser::Optional__arguments_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitOptional__arguments_2(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Optional__arguments_2Context* PnfGoParser::optional__arguments_2() {
  Optional__arguments_2Context *_localctx = _tracker.createInstance<Optional__arguments_2Context>(_ctx, getState());
  enterRule(_localctx, 312, PnfGoParser::RuleOptional__arguments_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1028);
    _errHandler->sync(this);

    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 62, _ctx)) {
    case 1: {
      setState(1027);
      aux_rule__arguments_1();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__arguments_5Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__arguments_5Context::Aux_rule__arguments_5Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Altnt_block__arguments_7Context* PnfGoParser::Aux_rule__arguments_5Context::altnt_block__arguments_7() {
  return getRuleContext<PnfGoParser::Altnt_block__arguments_7Context>(0);
}

PnfGoParser::Optional__parameterDecl_2Context* PnfGoParser::Aux_rule__arguments_5Context::optional__parameterDecl_2() {
  return getRuleContext<PnfGoParser::Optional__parameterDecl_2Context>(0);
}

PnfGoParser::Optional__conversion_1Context* PnfGoParser::Aux_rule__arguments_5Context::optional__conversion_1() {
  return getRuleContext<PnfGoParser::Optional__conversion_1Context>(0);
}


size_t PnfGoParser::Aux_rule__arguments_5Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__arguments_5;
}

void PnfGoParser::Aux_rule__arguments_5Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__arguments_5(this);
}

void PnfGoParser::Aux_rule__arguments_5Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__arguments_5(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__arguments_5Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__arguments_5(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__arguments_5Context* PnfGoParser::aux_rule__arguments_5() {
  Aux_rule__arguments_5Context *_localctx = _tracker.createInstance<Aux_rule__arguments_5Context>(_ctx, getState());
  enterRule(_localctx, 314, PnfGoParser::RuleAux_rule__arguments_5);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1030);
    altnt_block__arguments_7();
    setState(1031);
    optional__parameterDecl_2();
    setState(1032);
    optional__conversion_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__arguments_6Context ------------------------------------------------------------------

PnfGoParser::Optional__arguments_6Context::Optional__arguments_6Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Aux_rule__arguments_5Context* PnfGoParser::Optional__arguments_6Context::aux_rule__arguments_5() {
  return getRuleContext<PnfGoParser::Aux_rule__arguments_5Context>(0);
}


size_t PnfGoParser::Optional__arguments_6Context::getRuleIndex() const {
  return PnfGoParser::RuleOptional__arguments_6;
}

void PnfGoParser::Optional__arguments_6Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__arguments_6(this);
}

void PnfGoParser::Optional__arguments_6Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__arguments_6(this);
}


antlrcpp::Any PnfGoParser::Optional__arguments_6Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitOptional__arguments_6(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Optional__arguments_6Context* PnfGoParser::optional__arguments_6() {
  Optional__arguments_6Context *_localctx = _tracker.createInstance<Optional__arguments_6Context>(_ctx, getState());
  enterRule(_localctx, 316, PnfGoParser::RuleOptional__arguments_6);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1035);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if ((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << PnfGoParser::FUNC)
      | (1ULL << PnfGoParser::INTERFACE)
      | (1ULL << PnfGoParser::MAP)
      | (1ULL << PnfGoParser::STRUCT)
      | (1ULL << PnfGoParser::CHAN)
      | (1ULL << PnfGoParser::NIL_LIT)
      | (1ULL << PnfGoParser::IDENTIFIER)
      | (1ULL << PnfGoParser::L_PAREN)
      | (1ULL << PnfGoParser::L_BRACKET)
      | (1ULL << PnfGoParser::EXCLAMATION)
      | (1ULL << PnfGoParser::PLUS)
      | (1ULL << PnfGoParser::MINUS)
      | (1ULL << PnfGoParser::CARET)
      | (1ULL << PnfGoParser::STAR)
      | (1ULL << PnfGoParser::AMPERSAND)
      | (1ULL << PnfGoParser::RECEIVE))) != 0) || ((((_la - 64) & ~ 0x3fULL) == 0) &&
      ((1ULL << (_la - 64)) & ((1ULL << (PnfGoParser::DECIMAL_LIT - 64))
      | (1ULL << (PnfGoParser::OCTAL_LIT - 64))
      | (1ULL << (PnfGoParser::HEX_LIT - 64))
      | (1ULL << (PnfGoParser::FLOAT_LIT - 64))
      | (1ULL << (PnfGoParser::IMAGINARY_LIT - 64))
      | (1ULL << (PnfGoParser::RUNE_LIT - 64))
      | (1ULL << (PnfGoParser::RAW_STRING_LIT - 64))
      | (1ULL << (PnfGoParser::INTERPRETED_STRING_LIT - 64)))) != 0)) {
      setState(1034);
      aux_rule__arguments_5();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__expression_2Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__expression_2Context::Aux_rule__expression_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Altnt_block__expression_3Context* PnfGoParser::Aux_rule__expression_2Context::altnt_block__expression_3() {
  return getRuleContext<PnfGoParser::Altnt_block__expression_3Context>(0);
}

PnfGoParser::ExpressionContext* PnfGoParser::Aux_rule__expression_2Context::expression() {
  return getRuleContext<PnfGoParser::ExpressionContext>(0);
}


size_t PnfGoParser::Aux_rule__expression_2Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__expression_2;
}

void PnfGoParser::Aux_rule__expression_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__expression_2(this);
}

void PnfGoParser::Aux_rule__expression_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__expression_2(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__expression_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__expression_2(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__expression_2Context* PnfGoParser::aux_rule__expression_2() {
  Aux_rule__expression_2Context *_localctx = _tracker.createInstance<Aux_rule__expression_2Context>(_ctx, getState());
  enterRule(_localctx, 318, PnfGoParser::RuleAux_rule__expression_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1037);
    altnt_block__expression_3();
    setState(1038);
    expression();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__expression_1Context ------------------------------------------------------------------

PnfGoParser::Kleene_star__expression_1Context::Kleene_star__expression_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfGoParser::Aux_rule__expression_2Context *> PnfGoParser::Kleene_star__expression_1Context::aux_rule__expression_2() {
  return getRuleContexts<PnfGoParser::Aux_rule__expression_2Context>();
}

PnfGoParser::Aux_rule__expression_2Context* PnfGoParser::Kleene_star__expression_1Context::aux_rule__expression_2(size_t i) {
  return getRuleContext<PnfGoParser::Aux_rule__expression_2Context>(i);
}


size_t PnfGoParser::Kleene_star__expression_1Context::getRuleIndex() const {
  return PnfGoParser::RuleKleene_star__expression_1;
}

void PnfGoParser::Kleene_star__expression_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__expression_1(this);
}

void PnfGoParser::Kleene_star__expression_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__expression_1(this);
}


antlrcpp::Any PnfGoParser::Kleene_star__expression_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitKleene_star__expression_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Kleene_star__expression_1Context* PnfGoParser::kleene_star__expression_1() {
  Kleene_star__expression_1Context *_localctx = _tracker.createInstance<Kleene_star__expression_1Context>(_ctx, getState());
  enterRule(_localctx, 320, PnfGoParser::RuleKleene_star__expression_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    size_t alt;
    enterOuterAlt(_localctx, 1);
    setState(1043);
    _errHandler->sync(this);
    alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 64, _ctx);
    while (alt != 2 && alt != atn::ATN::INVALID_ALT_NUMBER) {
      if (alt == 1) {
        setState(1040);
        aux_rule__expression_2(); 
      }
      setState(1045);
      _errHandler->sync(this);
      alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 64, _ctx);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- ExpressionContext ------------------------------------------------------------------

PnfGoParser::ExpressionContext::ExpressionContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::UnaryExprContext* PnfGoParser::ExpressionContext::unaryExpr() {
  return getRuleContext<PnfGoParser::UnaryExprContext>(0);
}

PnfGoParser::Kleene_star__expression_1Context* PnfGoParser::ExpressionContext::kleene_star__expression_1() {
  return getRuleContext<PnfGoParser::Kleene_star__expression_1Context>(0);
}


size_t PnfGoParser::ExpressionContext::getRuleIndex() const {
  return PnfGoParser::RuleExpression;
}

void PnfGoParser::ExpressionContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterExpression(this);
}

void PnfGoParser::ExpressionContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitExpression(this);
}


antlrcpp::Any PnfGoParser::ExpressionContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitExpression(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::ExpressionContext* PnfGoParser::expression() {
  ExpressionContext *_localctx = _tracker.createInstance<ExpressionContext>(_ctx, getState());
  enterRule(_localctx, 322, PnfGoParser::RuleExpression);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1046);
    unaryExpr();
    setState(1047);
    kleene_star__expression_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__primaryExpr_2Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__primaryExpr_2Context::Aux_rule__primaryExpr_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Aux_rule__primaryExpr_4Context* PnfGoParser::Aux_rule__primaryExpr_2Context::aux_rule__primaryExpr_4() {
  return getRuleContext<PnfGoParser::Aux_rule__primaryExpr_4Context>(0);
}

PnfGoParser::IndexContext* PnfGoParser::Aux_rule__primaryExpr_2Context::index() {
  return getRuleContext<PnfGoParser::IndexContext>(0);
}

PnfGoParser::SliceContext* PnfGoParser::Aux_rule__primaryExpr_2Context::slice() {
  return getRuleContext<PnfGoParser::SliceContext>(0);
}

PnfGoParser::TypeAssertionContext* PnfGoParser::Aux_rule__primaryExpr_2Context::typeAssertion() {
  return getRuleContext<PnfGoParser::TypeAssertionContext>(0);
}

PnfGoParser::ArgumentsContext* PnfGoParser::Aux_rule__primaryExpr_2Context::arguments() {
  return getRuleContext<PnfGoParser::ArgumentsContext>(0);
}


size_t PnfGoParser::Aux_rule__primaryExpr_2Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__primaryExpr_2;
}

void PnfGoParser::Aux_rule__primaryExpr_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__primaryExpr_2(this);
}

void PnfGoParser::Aux_rule__primaryExpr_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__primaryExpr_2(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__primaryExpr_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__primaryExpr_2(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__primaryExpr_2Context* PnfGoParser::aux_rule__primaryExpr_2() {
  Aux_rule__primaryExpr_2Context *_localctx = _tracker.createInstance<Aux_rule__primaryExpr_2Context>(_ctx, getState());
  enterRule(_localctx, 324, PnfGoParser::RuleAux_rule__primaryExpr_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1054);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 65, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(1049);
      aux_rule__primaryExpr_4();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(1050);
      index();
      break;
    }

    case 3: {
      enterOuterAlt(_localctx, 3);
      setState(1051);
      slice();
      break;
    }

    case 4: {
      enterOuterAlt(_localctx, 4);
      setState(1052);
      typeAssertion();
      break;
    }

    case 5: {
      enterOuterAlt(_localctx, 5);
      setState(1053);
      arguments();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Kleene_star__primaryExpr_1Context ------------------------------------------------------------------

PnfGoParser::Kleene_star__primaryExpr_1Context::Kleene_star__primaryExpr_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfGoParser::Aux_rule__primaryExpr_2Context *> PnfGoParser::Kleene_star__primaryExpr_1Context::aux_rule__primaryExpr_2() {
  return getRuleContexts<PnfGoParser::Aux_rule__primaryExpr_2Context>();
}

PnfGoParser::Aux_rule__primaryExpr_2Context* PnfGoParser::Kleene_star__primaryExpr_1Context::aux_rule__primaryExpr_2(size_t i) {
  return getRuleContext<PnfGoParser::Aux_rule__primaryExpr_2Context>(i);
}


size_t PnfGoParser::Kleene_star__primaryExpr_1Context::getRuleIndex() const {
  return PnfGoParser::RuleKleene_star__primaryExpr_1;
}

void PnfGoParser::Kleene_star__primaryExpr_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterKleene_star__primaryExpr_1(this);
}

void PnfGoParser::Kleene_star__primaryExpr_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitKleene_star__primaryExpr_1(this);
}


antlrcpp::Any PnfGoParser::Kleene_star__primaryExpr_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitKleene_star__primaryExpr_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Kleene_star__primaryExpr_1Context* PnfGoParser::kleene_star__primaryExpr_1() {
  Kleene_star__primaryExpr_1Context *_localctx = _tracker.createInstance<Kleene_star__primaryExpr_1Context>(_ctx, getState());
  enterRule(_localctx, 326, PnfGoParser::RuleKleene_star__primaryExpr_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    size_t alt;
    enterOuterAlt(_localctx, 1);
    setState(1059);
    _errHandler->sync(this);
    alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 66, _ctx);
    while (alt != 2 && alt != atn::ATN::INVALID_ALT_NUMBER) {
      if (alt == 1) {
        setState(1056);
        aux_rule__primaryExpr_2(); 
      }
      setState(1061);
      _errHandler->sync(this);
      alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 66, _ctx);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- PrimaryExprContext ------------------------------------------------------------------

PnfGoParser::PrimaryExprContext::PrimaryExprContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Aux_rule__primaryExpr_3Context* PnfGoParser::PrimaryExprContext::aux_rule__primaryExpr_3() {
  return getRuleContext<PnfGoParser::Aux_rule__primaryExpr_3Context>(0);
}

PnfGoParser::Kleene_star__primaryExpr_1Context* PnfGoParser::PrimaryExprContext::kleene_star__primaryExpr_1() {
  return getRuleContext<PnfGoParser::Kleene_star__primaryExpr_1Context>(0);
}


size_t PnfGoParser::PrimaryExprContext::getRuleIndex() const {
  return PnfGoParser::RulePrimaryExpr;
}

void PnfGoParser::PrimaryExprContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterPrimaryExpr(this);
}

void PnfGoParser::PrimaryExprContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitPrimaryExpr(this);
}


antlrcpp::Any PnfGoParser::PrimaryExprContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitPrimaryExpr(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::PrimaryExprContext* PnfGoParser::primaryExpr() {
  PrimaryExprContext *_localctx = _tracker.createInstance<PrimaryExprContext>(_ctx, getState());
  enterRule(_localctx, 328, PnfGoParser::RulePrimaryExpr);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1062);
    aux_rule__primaryExpr_3();
    setState(1063);
    kleene_star__primaryExpr_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__signature_1Context ------------------------------------------------------------------

PnfGoParser::Optional__signature_1Context::Optional__signature_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::ResultContext* PnfGoParser::Optional__signature_1Context::result() {
  return getRuleContext<PnfGoParser::ResultContext>(0);
}


size_t PnfGoParser::Optional__signature_1Context::getRuleIndex() const {
  return PnfGoParser::RuleOptional__signature_1;
}

void PnfGoParser::Optional__signature_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__signature_1(this);
}

void PnfGoParser::Optional__signature_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__signature_1(this);
}


antlrcpp::Any PnfGoParser::Optional__signature_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitOptional__signature_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Optional__signature_1Context* PnfGoParser::optional__signature_1() {
  Optional__signature_1Context *_localctx = _tracker.createInstance<Optional__signature_1Context>(_ctx, getState());
  enterRule(_localctx, 330, PnfGoParser::RuleOptional__signature_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1066);
    _errHandler->sync(this);

    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 67, _ctx)) {
    case 1: {
      setState(1065);
      result();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__expression_3Context ------------------------------------------------------------------

PnfGoParser::Altnt_block__expression_3Context::Altnt_block__expression_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::Altnt_block__expression_3Context::STAR() {
  return getToken(PnfGoParser::STAR, 0);
}

tree::TerminalNode* PnfGoParser::Altnt_block__expression_3Context::DIV() {
  return getToken(PnfGoParser::DIV, 0);
}

tree::TerminalNode* PnfGoParser::Altnt_block__expression_3Context::MOD() {
  return getToken(PnfGoParser::MOD, 0);
}

tree::TerminalNode* PnfGoParser::Altnt_block__expression_3Context::LSHIFT() {
  return getToken(PnfGoParser::LSHIFT, 0);
}

tree::TerminalNode* PnfGoParser::Altnt_block__expression_3Context::RSHIFT() {
  return getToken(PnfGoParser::RSHIFT, 0);
}

tree::TerminalNode* PnfGoParser::Altnt_block__expression_3Context::AMPERSAND() {
  return getToken(PnfGoParser::AMPERSAND, 0);
}

tree::TerminalNode* PnfGoParser::Altnt_block__expression_3Context::BIT_CLEAR() {
  return getToken(PnfGoParser::BIT_CLEAR, 0);
}

tree::TerminalNode* PnfGoParser::Altnt_block__expression_3Context::PLUS() {
  return getToken(PnfGoParser::PLUS, 0);
}

tree::TerminalNode* PnfGoParser::Altnt_block__expression_3Context::MINUS() {
  return getToken(PnfGoParser::MINUS, 0);
}

tree::TerminalNode* PnfGoParser::Altnt_block__expression_3Context::OR() {
  return getToken(PnfGoParser::OR, 0);
}

tree::TerminalNode* PnfGoParser::Altnt_block__expression_3Context::CARET() {
  return getToken(PnfGoParser::CARET, 0);
}

tree::TerminalNode* PnfGoParser::Altnt_block__expression_3Context::EQUALS() {
  return getToken(PnfGoParser::EQUALS, 0);
}

tree::TerminalNode* PnfGoParser::Altnt_block__expression_3Context::NOT_EQUALS() {
  return getToken(PnfGoParser::NOT_EQUALS, 0);
}

tree::TerminalNode* PnfGoParser::Altnt_block__expression_3Context::LESS() {
  return getToken(PnfGoParser::LESS, 0);
}

tree::TerminalNode* PnfGoParser::Altnt_block__expression_3Context::LESS_OR_EQUALS() {
  return getToken(PnfGoParser::LESS_OR_EQUALS, 0);
}

tree::TerminalNode* PnfGoParser::Altnt_block__expression_3Context::GREATER() {
  return getToken(PnfGoParser::GREATER, 0);
}

tree::TerminalNode* PnfGoParser::Altnt_block__expression_3Context::GREATER_OR_EQUALS() {
  return getToken(PnfGoParser::GREATER_OR_EQUALS, 0);
}

tree::TerminalNode* PnfGoParser::Altnt_block__expression_3Context::LOGICAL_AND() {
  return getToken(PnfGoParser::LOGICAL_AND, 0);
}

tree::TerminalNode* PnfGoParser::Altnt_block__expression_3Context::LOGICAL_OR() {
  return getToken(PnfGoParser::LOGICAL_OR, 0);
}


size_t PnfGoParser::Altnt_block__expression_3Context::getRuleIndex() const {
  return PnfGoParser::RuleAltnt_block__expression_3;
}

void PnfGoParser::Altnt_block__expression_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__expression_3(this);
}

void PnfGoParser::Altnt_block__expression_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__expression_3(this);
}


antlrcpp::Any PnfGoParser::Altnt_block__expression_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__expression_3(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Altnt_block__expression_3Context* PnfGoParser::altnt_block__expression_3() {
  Altnt_block__expression_3Context *_localctx = _tracker.createInstance<Altnt_block__expression_3Context>(_ctx, getState());
  enterRule(_localctx, 332, PnfGoParser::RuleAltnt_block__expression_3);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1068);
    _la = _input->LA(1);
    if (!((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << PnfGoParser::LOGICAL_OR)
      | (1ULL << PnfGoParser::LOGICAL_AND)
      | (1ULL << PnfGoParser::EQUALS)
      | (1ULL << PnfGoParser::NOT_EQUALS)
      | (1ULL << PnfGoParser::LESS)
      | (1ULL << PnfGoParser::LESS_OR_EQUALS)
      | (1ULL << PnfGoParser::GREATER)
      | (1ULL << PnfGoParser::GREATER_OR_EQUALS)
      | (1ULL << PnfGoParser::OR)
      | (1ULL << PnfGoParser::DIV)
      | (1ULL << PnfGoParser::MOD)
      | (1ULL << PnfGoParser::LSHIFT)
      | (1ULL << PnfGoParser::RSHIFT)
      | (1ULL << PnfGoParser::BIT_CLEAR)
      | (1ULL << PnfGoParser::PLUS)
      | (1ULL << PnfGoParser::MINUS)
      | (1ULL << PnfGoParser::CARET)
      | (1ULL << PnfGoParser::STAR)
      | (1ULL << PnfGoParser::AMPERSAND))) != 0))) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Type_Context ------------------------------------------------------------------

PnfGoParser::Type_Context::Type_Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::TypeNameContext* PnfGoParser::Type_Context::typeName() {
  return getRuleContext<PnfGoParser::TypeNameContext>(0);
}

PnfGoParser::ArrayTypeContext* PnfGoParser::Type_Context::arrayType() {
  return getRuleContext<PnfGoParser::ArrayTypeContext>(0);
}

PnfGoParser::StructTypeContext* PnfGoParser::Type_Context::structType() {
  return getRuleContext<PnfGoParser::StructTypeContext>(0);
}

PnfGoParser::PointerTypeContext* PnfGoParser::Type_Context::pointerType() {
  return getRuleContext<PnfGoParser::PointerTypeContext>(0);
}

PnfGoParser::FunctionTypeContext* PnfGoParser::Type_Context::functionType() {
  return getRuleContext<PnfGoParser::FunctionTypeContext>(0);
}

PnfGoParser::InterfaceTypeContext* PnfGoParser::Type_Context::interfaceType() {
  return getRuleContext<PnfGoParser::InterfaceTypeContext>(0);
}

PnfGoParser::SliceTypeContext* PnfGoParser::Type_Context::sliceType() {
  return getRuleContext<PnfGoParser::SliceTypeContext>(0);
}

PnfGoParser::MapTypeContext* PnfGoParser::Type_Context::mapType() {
  return getRuleContext<PnfGoParser::MapTypeContext>(0);
}

PnfGoParser::ChannelTypeContext* PnfGoParser::Type_Context::channelType() {
  return getRuleContext<PnfGoParser::ChannelTypeContext>(0);
}

PnfGoParser::Aux_rule__type__1Context* PnfGoParser::Type_Context::aux_rule__type__1() {
  return getRuleContext<PnfGoParser::Aux_rule__type__1Context>(0);
}


size_t PnfGoParser::Type_Context::getRuleIndex() const {
  return PnfGoParser::RuleType_;
}

void PnfGoParser::Type_Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterType_(this);
}

void PnfGoParser::Type_Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitType_(this);
}


antlrcpp::Any PnfGoParser::Type_Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitType_(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Type_Context* PnfGoParser::type_() {
  Type_Context *_localctx = _tracker.createInstance<Type_Context>(_ctx, getState());
  enterRule(_localctx, 334, PnfGoParser::RuleType_);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1080);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 68, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(1070);
      typeName();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(1071);
      arrayType();
      break;
    }

    case 3: {
      enterOuterAlt(_localctx, 3);
      setState(1072);
      structType();
      break;
    }

    case 4: {
      enterOuterAlt(_localctx, 4);
      setState(1073);
      pointerType();
      break;
    }

    case 5: {
      enterOuterAlt(_localctx, 5);
      setState(1074);
      functionType();
      break;
    }

    case 6: {
      enterOuterAlt(_localctx, 6);
      setState(1075);
      interfaceType();
      break;
    }

    case 7: {
      enterOuterAlt(_localctx, 7);
      setState(1076);
      sliceType();
      break;
    }

    case 8: {
      enterOuterAlt(_localctx, 8);
      setState(1077);
      mapType();
      break;
    }

    case 9: {
      enterOuterAlt(_localctx, 9);
      setState(1078);
      channelType();
      break;
    }

    case 10: {
      enterOuterAlt(_localctx, 10);
      setState(1079);
      aux_rule__type__1();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- RealStatementContext ------------------------------------------------------------------

PnfGoParser::RealStatementContext::RealStatementContext(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::DeclarationContext* PnfGoParser::RealStatementContext::declaration() {
  return getRuleContext<PnfGoParser::DeclarationContext>(0);
}

PnfGoParser::LabeledStmtContext* PnfGoParser::RealStatementContext::labeledStmt() {
  return getRuleContext<PnfGoParser::LabeledStmtContext>(0);
}

PnfGoParser::RealSimpleStmtContext* PnfGoParser::RealStatementContext::realSimpleStmt() {
  return getRuleContext<PnfGoParser::RealSimpleStmtContext>(0);
}

PnfGoParser::GoStmtContext* PnfGoParser::RealStatementContext::goStmt() {
  return getRuleContext<PnfGoParser::GoStmtContext>(0);
}

PnfGoParser::ReturnStmtContext* PnfGoParser::RealStatementContext::returnStmt() {
  return getRuleContext<PnfGoParser::ReturnStmtContext>(0);
}

PnfGoParser::BreakStmtContext* PnfGoParser::RealStatementContext::breakStmt() {
  return getRuleContext<PnfGoParser::BreakStmtContext>(0);
}

PnfGoParser::ContinueStmtContext* PnfGoParser::RealStatementContext::continueStmt() {
  return getRuleContext<PnfGoParser::ContinueStmtContext>(0);
}

PnfGoParser::GotoStmtContext* PnfGoParser::RealStatementContext::gotoStmt() {
  return getRuleContext<PnfGoParser::GotoStmtContext>(0);
}

PnfGoParser::FallthroughStmtContext* PnfGoParser::RealStatementContext::fallthroughStmt() {
  return getRuleContext<PnfGoParser::FallthroughStmtContext>(0);
}

PnfGoParser::BlockContext* PnfGoParser::RealStatementContext::block() {
  return getRuleContext<PnfGoParser::BlockContext>(0);
}

PnfGoParser::IfStmtContext* PnfGoParser::RealStatementContext::ifStmt() {
  return getRuleContext<PnfGoParser::IfStmtContext>(0);
}

PnfGoParser::ExprSwitchStmtContext* PnfGoParser::RealStatementContext::exprSwitchStmt() {
  return getRuleContext<PnfGoParser::ExprSwitchStmtContext>(0);
}

PnfGoParser::TypeSwitchStmtContext* PnfGoParser::RealStatementContext::typeSwitchStmt() {
  return getRuleContext<PnfGoParser::TypeSwitchStmtContext>(0);
}

PnfGoParser::SelectStmtContext* PnfGoParser::RealStatementContext::selectStmt() {
  return getRuleContext<PnfGoParser::SelectStmtContext>(0);
}

PnfGoParser::ForStmtContext* PnfGoParser::RealStatementContext::forStmt() {
  return getRuleContext<PnfGoParser::ForStmtContext>(0);
}

PnfGoParser::DeferStmtContext* PnfGoParser::RealStatementContext::deferStmt() {
  return getRuleContext<PnfGoParser::DeferStmtContext>(0);
}


size_t PnfGoParser::RealStatementContext::getRuleIndex() const {
  return PnfGoParser::RuleRealStatement;
}

void PnfGoParser::RealStatementContext::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterRealStatement(this);
}

void PnfGoParser::RealStatementContext::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitRealStatement(this);
}


antlrcpp::Any PnfGoParser::RealStatementContext::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitRealStatement(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::RealStatementContext* PnfGoParser::realStatement() {
  RealStatementContext *_localctx = _tracker.createInstance<RealStatementContext>(_ctx, getState());
  enterRule(_localctx, 336, PnfGoParser::RuleRealStatement);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1098);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 69, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(1082);
      declaration();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(1083);
      labeledStmt();
      break;
    }

    case 3: {
      enterOuterAlt(_localctx, 3);
      setState(1084);
      realSimpleStmt();
      break;
    }

    case 4: {
      enterOuterAlt(_localctx, 4);
      setState(1085);
      goStmt();
      break;
    }

    case 5: {
      enterOuterAlt(_localctx, 5);
      setState(1086);
      returnStmt();
      break;
    }

    case 6: {
      enterOuterAlt(_localctx, 6);
      setState(1087);
      breakStmt();
      break;
    }

    case 7: {
      enterOuterAlt(_localctx, 7);
      setState(1088);
      continueStmt();
      break;
    }

    case 8: {
      enterOuterAlt(_localctx, 8);
      setState(1089);
      gotoStmt();
      break;
    }

    case 9: {
      enterOuterAlt(_localctx, 9);
      setState(1090);
      fallthroughStmt();
      break;
    }

    case 10: {
      enterOuterAlt(_localctx, 10);
      setState(1091);
      block();
      break;
    }

    case 11: {
      enterOuterAlt(_localctx, 11);
      setState(1092);
      ifStmt();
      break;
    }

    case 12: {
      enterOuterAlt(_localctx, 12);
      setState(1093);
      exprSwitchStmt();
      break;
    }

    case 13: {
      enterOuterAlt(_localctx, 13);
      setState(1094);
      typeSwitchStmt();
      break;
    }

    case 14: {
      enterOuterAlt(_localctx, 14);
      setState(1095);
      selectStmt();
      break;
    }

    case 15: {
      enterOuterAlt(_localctx, 15);
      setState(1096);
      forStmt();
      break;
    }

    case 16: {
      enterOuterAlt(_localctx, 16);
      setState(1097);
      deferStmt();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__importDecl_3Context ------------------------------------------------------------------

PnfGoParser::Altnt_block__importDecl_3Context::Altnt_block__importDecl_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::ImportSpecContext* PnfGoParser::Altnt_block__importDecl_3Context::importSpec() {
  return getRuleContext<PnfGoParser::ImportSpecContext>(0);
}

PnfGoParser::Aux_rule__importDecl_4Context* PnfGoParser::Altnt_block__importDecl_3Context::aux_rule__importDecl_4() {
  return getRuleContext<PnfGoParser::Aux_rule__importDecl_4Context>(0);
}


size_t PnfGoParser::Altnt_block__importDecl_3Context::getRuleIndex() const {
  return PnfGoParser::RuleAltnt_block__importDecl_3;
}

void PnfGoParser::Altnt_block__importDecl_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__importDecl_3(this);
}

void PnfGoParser::Altnt_block__importDecl_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__importDecl_3(this);
}


antlrcpp::Any PnfGoParser::Altnt_block__importDecl_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__importDecl_3(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Altnt_block__importDecl_3Context* PnfGoParser::altnt_block__importDecl_3() {
  Altnt_block__importDecl_3Context *_localctx = _tracker.createInstance<Altnt_block__importDecl_3Context>(_ctx, getState());
  enterRule(_localctx, 338, PnfGoParser::RuleAltnt_block__importDecl_3);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1102);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case PnfGoParser::IDENTIFIER:
      case PnfGoParser::DOT:
      case PnfGoParser::RAW_STRING_LIT:
      case PnfGoParser::INTERPRETED_STRING_LIT: {
        enterOuterAlt(_localctx, 1);
        setState(1100);
        importSpec();
        break;
      }

      case PnfGoParser::L_PAREN: {
        enterOuterAlt(_localctx, 2);
        setState(1101);
        aux_rule__importDecl_4();
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__constDecl_3Context ------------------------------------------------------------------

PnfGoParser::Altnt_block__constDecl_3Context::Altnt_block__constDecl_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::ConstSpecContext* PnfGoParser::Altnt_block__constDecl_3Context::constSpec() {
  return getRuleContext<PnfGoParser::ConstSpecContext>(0);
}

PnfGoParser::Aux_rule__constDecl_4Context* PnfGoParser::Altnt_block__constDecl_3Context::aux_rule__constDecl_4() {
  return getRuleContext<PnfGoParser::Aux_rule__constDecl_4Context>(0);
}


size_t PnfGoParser::Altnt_block__constDecl_3Context::getRuleIndex() const {
  return PnfGoParser::RuleAltnt_block__constDecl_3;
}

void PnfGoParser::Altnt_block__constDecl_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__constDecl_3(this);
}

void PnfGoParser::Altnt_block__constDecl_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__constDecl_3(this);
}


antlrcpp::Any PnfGoParser::Altnt_block__constDecl_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__constDecl_3(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Altnt_block__constDecl_3Context* PnfGoParser::altnt_block__constDecl_3() {
  Altnt_block__constDecl_3Context *_localctx = _tracker.createInstance<Altnt_block__constDecl_3Context>(_ctx, getState());
  enterRule(_localctx, 340, PnfGoParser::RuleAltnt_block__constDecl_3);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1106);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case PnfGoParser::IDENTIFIER: {
        enterOuterAlt(_localctx, 1);
        setState(1104);
        constSpec();
        break;
      }

      case PnfGoParser::L_PAREN: {
        enterOuterAlt(_localctx, 2);
        setState(1105);
        aux_rule__constDecl_4();
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__typeDecl_3Context ------------------------------------------------------------------

PnfGoParser::Altnt_block__typeDecl_3Context::Altnt_block__typeDecl_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::TypeSpecContext* PnfGoParser::Altnt_block__typeDecl_3Context::typeSpec() {
  return getRuleContext<PnfGoParser::TypeSpecContext>(0);
}

PnfGoParser::Aux_rule__typeDecl_4Context* PnfGoParser::Altnt_block__typeDecl_3Context::aux_rule__typeDecl_4() {
  return getRuleContext<PnfGoParser::Aux_rule__typeDecl_4Context>(0);
}


size_t PnfGoParser::Altnt_block__typeDecl_3Context::getRuleIndex() const {
  return PnfGoParser::RuleAltnt_block__typeDecl_3;
}

void PnfGoParser::Altnt_block__typeDecl_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__typeDecl_3(this);
}

void PnfGoParser::Altnt_block__typeDecl_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__typeDecl_3(this);
}


antlrcpp::Any PnfGoParser::Altnt_block__typeDecl_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__typeDecl_3(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Altnt_block__typeDecl_3Context* PnfGoParser::altnt_block__typeDecl_3() {
  Altnt_block__typeDecl_3Context *_localctx = _tracker.createInstance<Altnt_block__typeDecl_3Context>(_ctx, getState());
  enterRule(_localctx, 342, PnfGoParser::RuleAltnt_block__typeDecl_3);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1110);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case PnfGoParser::IDENTIFIER: {
        enterOuterAlt(_localctx, 1);
        setState(1108);
        typeSpec();
        break;
      }

      case PnfGoParser::L_PAREN: {
        enterOuterAlt(_localctx, 2);
        setState(1109);
        aux_rule__typeDecl_4();
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__varDecl_3Context ------------------------------------------------------------------

PnfGoParser::Altnt_block__varDecl_3Context::Altnt_block__varDecl_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::VarSpecContext* PnfGoParser::Altnt_block__varDecl_3Context::varSpec() {
  return getRuleContext<PnfGoParser::VarSpecContext>(0);
}

PnfGoParser::Aux_rule__varDecl_4Context* PnfGoParser::Altnt_block__varDecl_3Context::aux_rule__varDecl_4() {
  return getRuleContext<PnfGoParser::Aux_rule__varDecl_4Context>(0);
}


size_t PnfGoParser::Altnt_block__varDecl_3Context::getRuleIndex() const {
  return PnfGoParser::RuleAltnt_block__varDecl_3;
}

void PnfGoParser::Altnt_block__varDecl_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__varDecl_3(this);
}

void PnfGoParser::Altnt_block__varDecl_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__varDecl_3(this);
}


antlrcpp::Any PnfGoParser::Altnt_block__varDecl_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__varDecl_3(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Altnt_block__varDecl_3Context* PnfGoParser::altnt_block__varDecl_3() {
  Altnt_block__varDecl_3Context *_localctx = _tracker.createInstance<Altnt_block__varDecl_3Context>(_ctx, getState());
  enterRule(_localctx, 344, PnfGoParser::RuleAltnt_block__varDecl_3);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1114);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case PnfGoParser::IDENTIFIER: {
        enterOuterAlt(_localctx, 1);
        setState(1112);
        varSpec();
        break;
      }

      case PnfGoParser::L_PAREN: {
        enterOuterAlt(_localctx, 2);
        setState(1113);
        aux_rule__varDecl_4();
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__varSpec_3Context ------------------------------------------------------------------

PnfGoParser::Altnt_block__varSpec_3Context::Altnt_block__varSpec_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Aux_rule__varSpec_4Context* PnfGoParser::Altnt_block__varSpec_3Context::aux_rule__varSpec_4() {
  return getRuleContext<PnfGoParser::Aux_rule__varSpec_4Context>(0);
}

PnfGoParser::Aux_rule__varSpec_5Context* PnfGoParser::Altnt_block__varSpec_3Context::aux_rule__varSpec_5() {
  return getRuleContext<PnfGoParser::Aux_rule__varSpec_5Context>(0);
}


size_t PnfGoParser::Altnt_block__varSpec_3Context::getRuleIndex() const {
  return PnfGoParser::RuleAltnt_block__varSpec_3;
}

void PnfGoParser::Altnt_block__varSpec_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__varSpec_3(this);
}

void PnfGoParser::Altnt_block__varSpec_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__varSpec_3(this);
}


antlrcpp::Any PnfGoParser::Altnt_block__varSpec_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__varSpec_3(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Altnt_block__varSpec_3Context* PnfGoParser::altnt_block__varSpec_3() {
  Altnt_block__varSpec_3Context *_localctx = _tracker.createInstance<Altnt_block__varSpec_3Context>(_ctx, getState());
  enterRule(_localctx, 346, PnfGoParser::RuleAltnt_block__varSpec_3);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1118);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case PnfGoParser::FUNC:
      case PnfGoParser::INTERFACE:
      case PnfGoParser::MAP:
      case PnfGoParser::STRUCT:
      case PnfGoParser::CHAN:
      case PnfGoParser::IDENTIFIER:
      case PnfGoParser::L_PAREN:
      case PnfGoParser::L_BRACKET:
      case PnfGoParser::STAR:
      case PnfGoParser::RECEIVE: {
        enterOuterAlt(_localctx, 1);
        setState(1116);
        aux_rule__varSpec_4();
        break;
      }

      case PnfGoParser::ASSIGN: {
        enterOuterAlt(_localctx, 2);
        setState(1117);
        aux_rule__varSpec_5();
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__incDecStmt_1Context ------------------------------------------------------------------

PnfGoParser::Altnt_block__incDecStmt_1Context::Altnt_block__incDecStmt_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::Altnt_block__incDecStmt_1Context::PLUS_PLUS() {
  return getToken(PnfGoParser::PLUS_PLUS, 0);
}

tree::TerminalNode* PnfGoParser::Altnt_block__incDecStmt_1Context::MINUS_MINUS() {
  return getToken(PnfGoParser::MINUS_MINUS, 0);
}


size_t PnfGoParser::Altnt_block__incDecStmt_1Context::getRuleIndex() const {
  return PnfGoParser::RuleAltnt_block__incDecStmt_1;
}

void PnfGoParser::Altnt_block__incDecStmt_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__incDecStmt_1(this);
}

void PnfGoParser::Altnt_block__incDecStmt_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__incDecStmt_1(this);
}


antlrcpp::Any PnfGoParser::Altnt_block__incDecStmt_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__incDecStmt_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Altnt_block__incDecStmt_1Context* PnfGoParser::altnt_block__incDecStmt_1() {
  Altnt_block__incDecStmt_1Context *_localctx = _tracker.createInstance<Altnt_block__incDecStmt_1Context>(_ctx, getState());
  enterRule(_localctx, 348, PnfGoParser::RuleAltnt_block__incDecStmt_1);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1120);
    _la = _input->LA(1);
    if (!(_la == PnfGoParser::PLUS_PLUS

    || _la == PnfGoParser::MINUS_MINUS)) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__typeList_3Context ------------------------------------------------------------------

PnfGoParser::Altnt_block__typeList_3Context::Altnt_block__typeList_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Type_Context* PnfGoParser::Altnt_block__typeList_3Context::type_() {
  return getRuleContext<PnfGoParser::Type_Context>(0);
}

tree::TerminalNode* PnfGoParser::Altnt_block__typeList_3Context::NIL_LIT() {
  return getToken(PnfGoParser::NIL_LIT, 0);
}


size_t PnfGoParser::Altnt_block__typeList_3Context::getRuleIndex() const {
  return PnfGoParser::RuleAltnt_block__typeList_3;
}

void PnfGoParser::Altnt_block__typeList_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__typeList_3(this);
}

void PnfGoParser::Altnt_block__typeList_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__typeList_3(this);
}


antlrcpp::Any PnfGoParser::Altnt_block__typeList_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__typeList_3(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Altnt_block__typeList_3Context* PnfGoParser::altnt_block__typeList_3() {
  Altnt_block__typeList_3Context *_localctx = _tracker.createInstance<Altnt_block__typeList_3Context>(_ctx, getState());
  enterRule(_localctx, 350, PnfGoParser::RuleAltnt_block__typeList_3);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1124);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case PnfGoParser::FUNC:
      case PnfGoParser::INTERFACE:
      case PnfGoParser::MAP:
      case PnfGoParser::STRUCT:
      case PnfGoParser::CHAN:
      case PnfGoParser::IDENTIFIER:
      case PnfGoParser::L_PAREN:
      case PnfGoParser::L_BRACKET:
      case PnfGoParser::STAR:
      case PnfGoParser::RECEIVE: {
        enterOuterAlt(_localctx, 1);
        setState(1122);
        type_();
        break;
      }

      case PnfGoParser::NIL_LIT: {
        enterOuterAlt(_localctx, 2);
        setState(1123);
        match(PnfGoParser::NIL_LIT);
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__commCase_1Context ------------------------------------------------------------------

PnfGoParser::Altnt_block__commCase_1Context::Altnt_block__commCase_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::SendStmtContext* PnfGoParser::Altnt_block__commCase_1Context::sendStmt() {
  return getRuleContext<PnfGoParser::SendStmtContext>(0);
}

PnfGoParser::RecvStmtContext* PnfGoParser::Altnt_block__commCase_1Context::recvStmt() {
  return getRuleContext<PnfGoParser::RecvStmtContext>(0);
}


size_t PnfGoParser::Altnt_block__commCase_1Context::getRuleIndex() const {
  return PnfGoParser::RuleAltnt_block__commCase_1;
}

void PnfGoParser::Altnt_block__commCase_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__commCase_1(this);
}

void PnfGoParser::Altnt_block__commCase_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__commCase_1(this);
}


antlrcpp::Any PnfGoParser::Altnt_block__commCase_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__commCase_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Altnt_block__commCase_1Context* PnfGoParser::altnt_block__commCase_1() {
  Altnt_block__commCase_1Context *_localctx = _tracker.createInstance<Altnt_block__commCase_1Context>(_ctx, getState());
  enterRule(_localctx, 352, PnfGoParser::RuleAltnt_block__commCase_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1128);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 76, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(1126);
      sendStmt();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(1127);
      recvStmt();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__channelType_1Context ------------------------------------------------------------------

PnfGoParser::Altnt_block__channelType_1Context::Altnt_block__channelType_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Aux_rule__channelType_3Context* PnfGoParser::Altnt_block__channelType_1Context::aux_rule__channelType_3() {
  return getRuleContext<PnfGoParser::Aux_rule__channelType_3Context>(0);
}

PnfGoParser::Aux_rule__channelType_4Context* PnfGoParser::Altnt_block__channelType_1Context::aux_rule__channelType_4() {
  return getRuleContext<PnfGoParser::Aux_rule__channelType_4Context>(0);
}


size_t PnfGoParser::Altnt_block__channelType_1Context::getRuleIndex() const {
  return PnfGoParser::RuleAltnt_block__channelType_1;
}

void PnfGoParser::Altnt_block__channelType_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__channelType_1(this);
}

void PnfGoParser::Altnt_block__channelType_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__channelType_1(this);
}


antlrcpp::Any PnfGoParser::Altnt_block__channelType_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__channelType_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Altnt_block__channelType_1Context* PnfGoParser::altnt_block__channelType_1() {
  Altnt_block__channelType_1Context *_localctx = _tracker.createInstance<Altnt_block__channelType_1Context>(_ctx, getState());
  enterRule(_localctx, 354, PnfGoParser::RuleAltnt_block__channelType_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1132);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 77, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(1130);
      aux_rule__channelType_3();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(1131);
      aux_rule__channelType_4();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__unaryExpr_1Context ------------------------------------------------------------------

PnfGoParser::Altnt_block__unaryExpr_1Context::Altnt_block__unaryExpr_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::Altnt_block__unaryExpr_1Context::PLUS() {
  return getToken(PnfGoParser::PLUS, 0);
}

tree::TerminalNode* PnfGoParser::Altnt_block__unaryExpr_1Context::MINUS() {
  return getToken(PnfGoParser::MINUS, 0);
}

tree::TerminalNode* PnfGoParser::Altnt_block__unaryExpr_1Context::EXCLAMATION() {
  return getToken(PnfGoParser::EXCLAMATION, 0);
}

tree::TerminalNode* PnfGoParser::Altnt_block__unaryExpr_1Context::CARET() {
  return getToken(PnfGoParser::CARET, 0);
}

tree::TerminalNode* PnfGoParser::Altnt_block__unaryExpr_1Context::STAR() {
  return getToken(PnfGoParser::STAR, 0);
}

tree::TerminalNode* PnfGoParser::Altnt_block__unaryExpr_1Context::AMPERSAND() {
  return getToken(PnfGoParser::AMPERSAND, 0);
}

tree::TerminalNode* PnfGoParser::Altnt_block__unaryExpr_1Context::RECEIVE() {
  return getToken(PnfGoParser::RECEIVE, 0);
}


size_t PnfGoParser::Altnt_block__unaryExpr_1Context::getRuleIndex() const {
  return PnfGoParser::RuleAltnt_block__unaryExpr_1;
}

void PnfGoParser::Altnt_block__unaryExpr_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__unaryExpr_1(this);
}

void PnfGoParser::Altnt_block__unaryExpr_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__unaryExpr_1(this);
}


antlrcpp::Any PnfGoParser::Altnt_block__unaryExpr_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__unaryExpr_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Altnt_block__unaryExpr_1Context* PnfGoParser::altnt_block__unaryExpr_1() {
  Altnt_block__unaryExpr_1Context *_localctx = _tracker.createInstance<Altnt_block__unaryExpr_1Context>(_ctx, getState());
  enterRule(_localctx, 356, PnfGoParser::RuleAltnt_block__unaryExpr_1);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1134);
    _la = _input->LA(1);
    if (!((((_la & ~ 0x3fULL) == 0) &&
      ((1ULL << _la) & ((1ULL << PnfGoParser::EXCLAMATION)
      | (1ULL << PnfGoParser::PLUS)
      | (1ULL << PnfGoParser::MINUS)
      | (1ULL << PnfGoParser::CARET)
      | (1ULL << PnfGoParser::STAR)
      | (1ULL << PnfGoParser::AMPERSAND)
      | (1ULL << PnfGoParser::RECEIVE))) != 0))) {
    _errHandler->recoverInline(this);
    }
    else {
      _errHandler->reportMatch(this);
      consume();
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__fieldDecl_2Context ------------------------------------------------------------------

PnfGoParser::Altnt_block__fieldDecl_2Context::Altnt_block__fieldDecl_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Aux_rule__fieldDecl_3Context* PnfGoParser::Altnt_block__fieldDecl_2Context::aux_rule__fieldDecl_3() {
  return getRuleContext<PnfGoParser::Aux_rule__fieldDecl_3Context>(0);
}

PnfGoParser::AnonymousFieldContext* PnfGoParser::Altnt_block__fieldDecl_2Context::anonymousField() {
  return getRuleContext<PnfGoParser::AnonymousFieldContext>(0);
}


size_t PnfGoParser::Altnt_block__fieldDecl_2Context::getRuleIndex() const {
  return PnfGoParser::RuleAltnt_block__fieldDecl_2;
}

void PnfGoParser::Altnt_block__fieldDecl_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__fieldDecl_2(this);
}

void PnfGoParser::Altnt_block__fieldDecl_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__fieldDecl_2(this);
}


antlrcpp::Any PnfGoParser::Altnt_block__fieldDecl_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__fieldDecl_2(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Altnt_block__fieldDecl_2Context* PnfGoParser::altnt_block__fieldDecl_2() {
  Altnt_block__fieldDecl_2Context *_localctx = _tracker.createInstance<Altnt_block__fieldDecl_2Context>(_ctx, getState());
  enterRule(_localctx, 358, PnfGoParser::RuleAltnt_block__fieldDecl_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1138);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 78, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(1136);
      aux_rule__fieldDecl_3();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(1137);
      anonymousField();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__slice_4Context ------------------------------------------------------------------

PnfGoParser::Altnt_block__slice_4Context::Altnt_block__slice_4Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Optional__exprSwitchStmt_3Context* PnfGoParser::Altnt_block__slice_4Context::optional__exprSwitchStmt_3() {
  return getRuleContext<PnfGoParser::Optional__exprSwitchStmt_3Context>(0);
}

tree::TerminalNode* PnfGoParser::Altnt_block__slice_4Context::COLON() {
  return getToken(PnfGoParser::COLON, 0);
}

PnfGoParser::Altnt_block__slice_5Context* PnfGoParser::Altnt_block__slice_4Context::altnt_block__slice_5() {
  return getRuleContext<PnfGoParser::Altnt_block__slice_5Context>(0);
}


size_t PnfGoParser::Altnt_block__slice_4Context::getRuleIndex() const {
  return PnfGoParser::RuleAltnt_block__slice_4;
}

void PnfGoParser::Altnt_block__slice_4Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__slice_4(this);
}

void PnfGoParser::Altnt_block__slice_4Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__slice_4(this);
}


antlrcpp::Any PnfGoParser::Altnt_block__slice_4Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__slice_4(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Altnt_block__slice_4Context* PnfGoParser::altnt_block__slice_4() {
  Altnt_block__slice_4Context *_localctx = _tracker.createInstance<Altnt_block__slice_4Context>(_ctx, getState());
  enterRule(_localctx, 360, PnfGoParser::RuleAltnt_block__slice_4);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1140);
    optional__exprSwitchStmt_3();
    setState(1141);
    match(PnfGoParser::COLON);
    setState(1142);
    altnt_block__slice_5();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__sourceFile_5Context ------------------------------------------------------------------

PnfGoParser::Altnt_block__sourceFile_5Context::Altnt_block__sourceFile_5Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::FunctionDeclContext* PnfGoParser::Altnt_block__sourceFile_5Context::functionDecl() {
  return getRuleContext<PnfGoParser::FunctionDeclContext>(0);
}

PnfGoParser::MethodDeclContext* PnfGoParser::Altnt_block__sourceFile_5Context::methodDecl() {
  return getRuleContext<PnfGoParser::MethodDeclContext>(0);
}

PnfGoParser::DeclarationContext* PnfGoParser::Altnt_block__sourceFile_5Context::declaration() {
  return getRuleContext<PnfGoParser::DeclarationContext>(0);
}


size_t PnfGoParser::Altnt_block__sourceFile_5Context::getRuleIndex() const {
  return PnfGoParser::RuleAltnt_block__sourceFile_5;
}

void PnfGoParser::Altnt_block__sourceFile_5Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__sourceFile_5(this);
}

void PnfGoParser::Altnt_block__sourceFile_5Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__sourceFile_5(this);
}


antlrcpp::Any PnfGoParser::Altnt_block__sourceFile_5Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__sourceFile_5(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Altnt_block__sourceFile_5Context* PnfGoParser::altnt_block__sourceFile_5() {
  Altnt_block__sourceFile_5Context *_localctx = _tracker.createInstance<Altnt_block__sourceFile_5Context>(_ctx, getState());
  enterRule(_localctx, 362, PnfGoParser::RuleAltnt_block__sourceFile_5);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1147);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 79, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(1144);
      functionDecl();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(1145);
      methodDecl();
      break;
    }

    case 3: {
      enterOuterAlt(_localctx, 3);
      setState(1146);
      declaration();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__ifStmt_5Context ------------------------------------------------------------------

PnfGoParser::Altnt_block__ifStmt_5Context::Altnt_block__ifStmt_5Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::IfStmtContext* PnfGoParser::Altnt_block__ifStmt_5Context::ifStmt() {
  return getRuleContext<PnfGoParser::IfStmtContext>(0);
}

PnfGoParser::BlockContext* PnfGoParser::Altnt_block__ifStmt_5Context::block() {
  return getRuleContext<PnfGoParser::BlockContext>(0);
}


size_t PnfGoParser::Altnt_block__ifStmt_5Context::getRuleIndex() const {
  return PnfGoParser::RuleAltnt_block__ifStmt_5;
}

void PnfGoParser::Altnt_block__ifStmt_5Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__ifStmt_5(this);
}

void PnfGoParser::Altnt_block__ifStmt_5Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__ifStmt_5(this);
}


antlrcpp::Any PnfGoParser::Altnt_block__ifStmt_5Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__ifStmt_5(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Altnt_block__ifStmt_5Context* PnfGoParser::altnt_block__ifStmt_5() {
  Altnt_block__ifStmt_5Context *_localctx = _tracker.createInstance<Altnt_block__ifStmt_5Context>(_ctx, getState());
  enterRule(_localctx, 364, PnfGoParser::RuleAltnt_block__ifStmt_5);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1151);
    _errHandler->sync(this);
    switch (_input->LA(1)) {
      case PnfGoParser::IF: {
        enterOuterAlt(_localctx, 1);
        setState(1149);
        ifStmt();
        break;
      }

      case PnfGoParser::L_CURLY: {
        enterOuterAlt(_localctx, 2);
        setState(1150);
        block();
        break;
      }

    default:
      throw NoViableAltException(this);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__arguments_7Context ------------------------------------------------------------------

PnfGoParser::Altnt_block__arguments_7Context::Altnt_block__arguments_7Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::ExpressionListContext* PnfGoParser::Altnt_block__arguments_7Context::expressionList() {
  return getRuleContext<PnfGoParser::ExpressionListContext>(0);
}

PnfGoParser::Aux_rule__arguments_8Context* PnfGoParser::Altnt_block__arguments_7Context::aux_rule__arguments_8() {
  return getRuleContext<PnfGoParser::Aux_rule__arguments_8Context>(0);
}


size_t PnfGoParser::Altnt_block__arguments_7Context::getRuleIndex() const {
  return PnfGoParser::RuleAltnt_block__arguments_7;
}

void PnfGoParser::Altnt_block__arguments_7Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__arguments_7(this);
}

void PnfGoParser::Altnt_block__arguments_7Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__arguments_7(this);
}


antlrcpp::Any PnfGoParser::Altnt_block__arguments_7Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__arguments_7(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Altnt_block__arguments_7Context* PnfGoParser::altnt_block__arguments_7() {
  Altnt_block__arguments_7Context *_localctx = _tracker.createInstance<Altnt_block__arguments_7Context>(_ctx, getState());
  enterRule(_localctx, 366, PnfGoParser::RuleAltnt_block__arguments_7);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1155);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 81, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(1153);
      expressionList();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(1154);
      aux_rule__arguments_8();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Optional__channelType_2Context ------------------------------------------------------------------

PnfGoParser::Optional__channelType_2Context::Optional__channelType_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::Optional__channelType_2Context::RECEIVE() {
  return getToken(PnfGoParser::RECEIVE, 0);
}


size_t PnfGoParser::Optional__channelType_2Context::getRuleIndex() const {
  return PnfGoParser::RuleOptional__channelType_2;
}

void PnfGoParser::Optional__channelType_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterOptional__channelType_2(this);
}

void PnfGoParser::Optional__channelType_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitOptional__channelType_2(this);
}


antlrcpp::Any PnfGoParser::Optional__channelType_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitOptional__channelType_2(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Optional__channelType_2Context* PnfGoParser::optional__channelType_2() {
  Optional__channelType_2Context *_localctx = _tracker.createInstance<Optional__channelType_2Context>(_ctx, getState());
  enterRule(_localctx, 368, PnfGoParser::RuleOptional__channelType_2);
  size_t _la = 0;

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1158);
    _errHandler->sync(this);

    _la = _input->LA(1);
    if (_la == PnfGoParser::RECEIVE) {
      setState(1157);
      match(PnfGoParser::RECEIVE);
    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Altnt_block__slice_5Context ------------------------------------------------------------------

PnfGoParser::Altnt_block__slice_5Context::Altnt_block__slice_5Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Optional__exprSwitchStmt_3Context* PnfGoParser::Altnt_block__slice_5Context::optional__exprSwitchStmt_3() {
  return getRuleContext<PnfGoParser::Optional__exprSwitchStmt_3Context>(0);
}

PnfGoParser::Aux_rule__slice_6Context* PnfGoParser::Altnt_block__slice_5Context::aux_rule__slice_6() {
  return getRuleContext<PnfGoParser::Aux_rule__slice_6Context>(0);
}


size_t PnfGoParser::Altnt_block__slice_5Context::getRuleIndex() const {
  return PnfGoParser::RuleAltnt_block__slice_5;
}

void PnfGoParser::Altnt_block__slice_5Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAltnt_block__slice_5(this);
}

void PnfGoParser::Altnt_block__slice_5Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAltnt_block__slice_5(this);
}


antlrcpp::Any PnfGoParser::Altnt_block__slice_5Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAltnt_block__slice_5(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Altnt_block__slice_5Context* PnfGoParser::altnt_block__slice_5() {
  Altnt_block__slice_5Context *_localctx = _tracker.createInstance<Altnt_block__slice_5Context>(_ctx, getState());
  enterRule(_localctx, 370, PnfGoParser::RuleAltnt_block__slice_5);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1162);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 83, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(1160);
      optional__exprSwitchStmt_3();
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(1161);
      aux_rule__slice_6();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__primaryExpr_3Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__primaryExpr_3Context::Aux_rule__primaryExpr_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::Aux_rule__primaryExpr_3Context::NIL_LIT() {
  return getToken(PnfGoParser::NIL_LIT, 0);
}

tree::TerminalNode* PnfGoParser::Aux_rule__primaryExpr_3Context::DECIMAL_LIT() {
  return getToken(PnfGoParser::DECIMAL_LIT, 0);
}

tree::TerminalNode* PnfGoParser::Aux_rule__primaryExpr_3Context::OCTAL_LIT() {
  return getToken(PnfGoParser::OCTAL_LIT, 0);
}

tree::TerminalNode* PnfGoParser::Aux_rule__primaryExpr_3Context::HEX_LIT() {
  return getToken(PnfGoParser::HEX_LIT, 0);
}

tree::TerminalNode* PnfGoParser::Aux_rule__primaryExpr_3Context::IMAGINARY_LIT() {
  return getToken(PnfGoParser::IMAGINARY_LIT, 0);
}

tree::TerminalNode* PnfGoParser::Aux_rule__primaryExpr_3Context::RUNE_LIT() {
  return getToken(PnfGoParser::RUNE_LIT, 0);
}

PnfGoParser::String_Context* PnfGoParser::Aux_rule__primaryExpr_3Context::string_() {
  return getRuleContext<PnfGoParser::String_Context>(0);
}

tree::TerminalNode* PnfGoParser::Aux_rule__primaryExpr_3Context::FLOAT_LIT() {
  return getToken(PnfGoParser::FLOAT_LIT, 0);
}

PnfGoParser::CompositeLitContext* PnfGoParser::Aux_rule__primaryExpr_3Context::compositeLit() {
  return getRuleContext<PnfGoParser::CompositeLitContext>(0);
}

PnfGoParser::FunctionLitContext* PnfGoParser::Aux_rule__primaryExpr_3Context::functionLit() {
  return getRuleContext<PnfGoParser::FunctionLitContext>(0);
}

PnfGoParser::TypeNameContext* PnfGoParser::Aux_rule__primaryExpr_3Context::typeName() {
  return getRuleContext<PnfGoParser::TypeNameContext>(0);
}

PnfGoParser::MethodExprContext* PnfGoParser::Aux_rule__primaryExpr_3Context::methodExpr() {
  return getRuleContext<PnfGoParser::MethodExprContext>(0);
}

PnfGoParser::Aux_rule__primaryExpr_5Context* PnfGoParser::Aux_rule__primaryExpr_3Context::aux_rule__primaryExpr_5() {
  return getRuleContext<PnfGoParser::Aux_rule__primaryExpr_5Context>(0);
}

PnfGoParser::ConversionContext* PnfGoParser::Aux_rule__primaryExpr_3Context::conversion() {
  return getRuleContext<PnfGoParser::ConversionContext>(0);
}


size_t PnfGoParser::Aux_rule__primaryExpr_3Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__primaryExpr_3;
}

void PnfGoParser::Aux_rule__primaryExpr_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__primaryExpr_3(this);
}

void PnfGoParser::Aux_rule__primaryExpr_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__primaryExpr_3(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__primaryExpr_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__primaryExpr_3(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__primaryExpr_3Context* PnfGoParser::aux_rule__primaryExpr_3() {
  Aux_rule__primaryExpr_3Context *_localctx = _tracker.createInstance<Aux_rule__primaryExpr_3Context>(_ctx, getState());
  enterRule(_localctx, 372, PnfGoParser::RuleAux_rule__primaryExpr_3);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    setState(1178);
    _errHandler->sync(this);
    switch (getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 84, _ctx)) {
    case 1: {
      enterOuterAlt(_localctx, 1);
      setState(1164);
      match(PnfGoParser::NIL_LIT);
      break;
    }

    case 2: {
      enterOuterAlt(_localctx, 2);
      setState(1165);
      match(PnfGoParser::DECIMAL_LIT);
      break;
    }

    case 3: {
      enterOuterAlt(_localctx, 3);
      setState(1166);
      match(PnfGoParser::OCTAL_LIT);
      break;
    }

    case 4: {
      enterOuterAlt(_localctx, 4);
      setState(1167);
      match(PnfGoParser::HEX_LIT);
      break;
    }

    case 5: {
      enterOuterAlt(_localctx, 5);
      setState(1168);
      match(PnfGoParser::IMAGINARY_LIT);
      break;
    }

    case 6: {
      enterOuterAlt(_localctx, 6);
      setState(1169);
      match(PnfGoParser::RUNE_LIT);
      break;
    }

    case 7: {
      enterOuterAlt(_localctx, 7);
      setState(1170);
      string_();
      break;
    }

    case 8: {
      enterOuterAlt(_localctx, 8);
      setState(1171);
      match(PnfGoParser::FLOAT_LIT);
      break;
    }

    case 9: {
      enterOuterAlt(_localctx, 9);
      setState(1172);
      compositeLit();
      break;
    }

    case 10: {
      enterOuterAlt(_localctx, 10);
      setState(1173);
      functionLit();
      break;
    }

    case 11: {
      enterOuterAlt(_localctx, 11);
      setState(1174);
      typeName();
      break;
    }

    case 12: {
      enterOuterAlt(_localctx, 12);
      setState(1175);
      methodExpr();
      break;
    }

    case 13: {
      enterOuterAlt(_localctx, 13);
      setState(1176);
      aux_rule__primaryExpr_5();
      break;
    }

    case 14: {
      enterOuterAlt(_localctx, 14);
      setState(1177);
      conversion();
      break;
    }

    }
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__sourceFile_6Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__sourceFile_6Context::Aux_rule__sourceFile_6Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::PackageClauseContext* PnfGoParser::Aux_rule__sourceFile_6Context::packageClause() {
  return getRuleContext<PnfGoParser::PackageClauseContext>(0);
}

PnfGoParser::EosContext* PnfGoParser::Aux_rule__sourceFile_6Context::eos() {
  return getRuleContext<PnfGoParser::EosContext>(0);
}

PnfGoParser::Kleene_star__sourceFile_2Context* PnfGoParser::Aux_rule__sourceFile_6Context::kleene_star__sourceFile_2() {
  return getRuleContext<PnfGoParser::Kleene_star__sourceFile_2Context>(0);
}

PnfGoParser::Kleene_star__sourceFile_4Context* PnfGoParser::Aux_rule__sourceFile_6Context::kleene_star__sourceFile_4() {
  return getRuleContext<PnfGoParser::Kleene_star__sourceFile_4Context>(0);
}


size_t PnfGoParser::Aux_rule__sourceFile_6Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__sourceFile_6;
}

void PnfGoParser::Aux_rule__sourceFile_6Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__sourceFile_6(this);
}

void PnfGoParser::Aux_rule__sourceFile_6Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__sourceFile_6(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__sourceFile_6Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__sourceFile_6(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__sourceFile_6Context* PnfGoParser::aux_rule__sourceFile_6() {
  Aux_rule__sourceFile_6Context *_localctx = _tracker.createInstance<Aux_rule__sourceFile_6Context>(_ctx, getState());
  enterRule(_localctx, 374, PnfGoParser::RuleAux_rule__sourceFile_6);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1180);
    packageClause();
    setState(1181);
    eos();
    setState(1182);
    kleene_star__sourceFile_2();
    setState(1183);
    kleene_star__sourceFile_4();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__exprSwitchCase_1Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__exprSwitchCase_1Context::Aux_rule__exprSwitchCase_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::Aux_rule__exprSwitchCase_1Context::CASE() {
  return getToken(PnfGoParser::CASE, 0);
}

PnfGoParser::ExpressionListContext* PnfGoParser::Aux_rule__exprSwitchCase_1Context::expressionList() {
  return getRuleContext<PnfGoParser::ExpressionListContext>(0);
}


size_t PnfGoParser::Aux_rule__exprSwitchCase_1Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__exprSwitchCase_1;
}

void PnfGoParser::Aux_rule__exprSwitchCase_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__exprSwitchCase_1(this);
}

void PnfGoParser::Aux_rule__exprSwitchCase_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__exprSwitchCase_1(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__exprSwitchCase_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__exprSwitchCase_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__exprSwitchCase_1Context* PnfGoParser::aux_rule__exprSwitchCase_1() {
  Aux_rule__exprSwitchCase_1Context *_localctx = _tracker.createInstance<Aux_rule__exprSwitchCase_1Context>(_ctx, getState());
  enterRule(_localctx, 376, PnfGoParser::RuleAux_rule__exprSwitchCase_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1185);
    match(PnfGoParser::CASE);
    setState(1186);
    expressionList();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__typeSwitchCase_1Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__typeSwitchCase_1Context::Aux_rule__typeSwitchCase_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::Aux_rule__typeSwitchCase_1Context::CASE() {
  return getToken(PnfGoParser::CASE, 0);
}

PnfGoParser::TypeListContext* PnfGoParser::Aux_rule__typeSwitchCase_1Context::typeList() {
  return getRuleContext<PnfGoParser::TypeListContext>(0);
}


size_t PnfGoParser::Aux_rule__typeSwitchCase_1Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__typeSwitchCase_1;
}

void PnfGoParser::Aux_rule__typeSwitchCase_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__typeSwitchCase_1(this);
}

void PnfGoParser::Aux_rule__typeSwitchCase_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__typeSwitchCase_1(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__typeSwitchCase_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__typeSwitchCase_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__typeSwitchCase_1Context* PnfGoParser::aux_rule__typeSwitchCase_1() {
  Aux_rule__typeSwitchCase_1Context *_localctx = _tracker.createInstance<Aux_rule__typeSwitchCase_1Context>(_ctx, getState());
  enterRule(_localctx, 378, PnfGoParser::RuleAux_rule__typeSwitchCase_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1188);
    match(PnfGoParser::CASE);
    setState(1189);
    typeList();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__commCase_2Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__commCase_2Context::Aux_rule__commCase_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::Aux_rule__commCase_2Context::CASE() {
  return getToken(PnfGoParser::CASE, 0);
}

PnfGoParser::Altnt_block__commCase_1Context* PnfGoParser::Aux_rule__commCase_2Context::altnt_block__commCase_1() {
  return getRuleContext<PnfGoParser::Altnt_block__commCase_1Context>(0);
}


size_t PnfGoParser::Aux_rule__commCase_2Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__commCase_2;
}

void PnfGoParser::Aux_rule__commCase_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__commCase_2(this);
}

void PnfGoParser::Aux_rule__commCase_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__commCase_2(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__commCase_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__commCase_2(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__commCase_2Context* PnfGoParser::aux_rule__commCase_2() {
  Aux_rule__commCase_2Context *_localctx = _tracker.createInstance<Aux_rule__commCase_2Context>(_ctx, getState());
  enterRule(_localctx, 380, PnfGoParser::RuleAux_rule__commCase_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1191);
    match(PnfGoParser::CASE);
    setState(1192);
    altnt_block__commCase_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__methodSpec_2Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__methodSpec_2Context::Aux_rule__methodSpec_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::Aux_rule__methodSpec_2Context::IDENTIFIER() {
  return getToken(PnfGoParser::IDENTIFIER, 0);
}

PnfGoParser::ParametersContext* PnfGoParser::Aux_rule__methodSpec_2Context::parameters() {
  return getRuleContext<PnfGoParser::ParametersContext>(0);
}

PnfGoParser::Optional__signature_1Context* PnfGoParser::Aux_rule__methodSpec_2Context::optional__signature_1() {
  return getRuleContext<PnfGoParser::Optional__signature_1Context>(0);
}


size_t PnfGoParser::Aux_rule__methodSpec_2Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__methodSpec_2;
}

void PnfGoParser::Aux_rule__methodSpec_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__methodSpec_2(this);
}

void PnfGoParser::Aux_rule__methodSpec_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__methodSpec_2(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__methodSpec_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__methodSpec_2(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__methodSpec_2Context* PnfGoParser::aux_rule__methodSpec_2() {
  Aux_rule__methodSpec_2Context *_localctx = _tracker.createInstance<Aux_rule__methodSpec_2Context>(_ctx, getState());
  enterRule(_localctx, 382, PnfGoParser::RuleAux_rule__methodSpec_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1194);
    match(PnfGoParser::IDENTIFIER);
    setState(1195);
    parameters();
    setState(1196);
    optional__signature_1();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__unaryExpr_2Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__unaryExpr_2Context::Aux_rule__unaryExpr_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Altnt_block__unaryExpr_1Context* PnfGoParser::Aux_rule__unaryExpr_2Context::altnt_block__unaryExpr_1() {
  return getRuleContext<PnfGoParser::Altnt_block__unaryExpr_1Context>(0);
}

PnfGoParser::UnaryExprContext* PnfGoParser::Aux_rule__unaryExpr_2Context::unaryExpr() {
  return getRuleContext<PnfGoParser::UnaryExprContext>(0);
}


size_t PnfGoParser::Aux_rule__unaryExpr_2Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__unaryExpr_2;
}

void PnfGoParser::Aux_rule__unaryExpr_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__unaryExpr_2(this);
}

void PnfGoParser::Aux_rule__unaryExpr_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__unaryExpr_2(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__unaryExpr_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__unaryExpr_2(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__unaryExpr_2Context* PnfGoParser::aux_rule__unaryExpr_2() {
  Aux_rule__unaryExpr_2Context *_localctx = _tracker.createInstance<Aux_rule__unaryExpr_2Context>(_ctx, getState());
  enterRule(_localctx, 384, PnfGoParser::RuleAux_rule__unaryExpr_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1198);
    altnt_block__unaryExpr_1();
    setState(1199);
    unaryExpr();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__literalType_1Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__literalType_1Context::Aux_rule__literalType_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::Aux_rule__literalType_1Context::L_BRACKET() {
  return getToken(PnfGoParser::L_BRACKET, 0);
}

tree::TerminalNode* PnfGoParser::Aux_rule__literalType_1Context::ELLIPSIS() {
  return getToken(PnfGoParser::ELLIPSIS, 0);
}

tree::TerminalNode* PnfGoParser::Aux_rule__literalType_1Context::R_BRACKET() {
  return getToken(PnfGoParser::R_BRACKET, 0);
}

PnfGoParser::ElementTypeContext* PnfGoParser::Aux_rule__literalType_1Context::elementType() {
  return getRuleContext<PnfGoParser::ElementTypeContext>(0);
}


size_t PnfGoParser::Aux_rule__literalType_1Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__literalType_1;
}

void PnfGoParser::Aux_rule__literalType_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__literalType_1(this);
}

void PnfGoParser::Aux_rule__literalType_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__literalType_1(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__literalType_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__literalType_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__literalType_1Context* PnfGoParser::aux_rule__literalType_1() {
  Aux_rule__literalType_1Context *_localctx = _tracker.createInstance<Aux_rule__literalType_1Context>(_ctx, getState());
  enterRule(_localctx, 386, PnfGoParser::RuleAux_rule__literalType_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1201);
    match(PnfGoParser::L_BRACKET);
    setState(1202);
    match(PnfGoParser::ELLIPSIS);
    setState(1203);
    match(PnfGoParser::R_BRACKET);
    setState(1204);
    elementType();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__eos_1Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__eos_1Context::Aux_rule__eos_1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t PnfGoParser::Aux_rule__eos_1Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__eos_1;
}

void PnfGoParser::Aux_rule__eos_1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__eos_1(this);
}

void PnfGoParser::Aux_rule__eos_1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__eos_1(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__eos_1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__eos_1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__eos_1Context* PnfGoParser::aux_rule__eos_1() {
  Aux_rule__eos_1Context *_localctx = _tracker.createInstance<Aux_rule__eos_1Context>(_ctx, getState());
  enterRule(_localctx, 388, PnfGoParser::RuleAux_rule__eos_1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1206);

    if (!(_localctx->start->getType() != SEMI && checkPreviousTokenText("}"))) throw FailedPredicateException(this, "$ctx->start->getType() != SEMI && checkPreviousTokenText(\"}\")");
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__eos_2Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__eos_2Context::Aux_rule__eos_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}


size_t PnfGoParser::Aux_rule__eos_2Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__eos_2;
}

void PnfGoParser::Aux_rule__eos_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__eos_2(this);
}

void PnfGoParser::Aux_rule__eos_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__eos_2(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__eos_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__eos_2(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__eos_2Context* PnfGoParser::aux_rule__eos_2() {
  Aux_rule__eos_2Context *_localctx = _tracker.createInstance<Aux_rule__eos_2Context>(_ctx, getState());
  enterRule(_localctx, 390, PnfGoParser::RuleAux_rule__eos_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1208);

    if (!(_localctx->start->getType() != SEMI && checkPreviousTokenText(")"))) throw FailedPredicateException(this, "$ctx->start->getType() != SEMI && checkPreviousTokenText(\")\")");
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__statementList_2Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__statementList_2Context::Aux_rule__statementList_2Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::RealStatementContext* PnfGoParser::Aux_rule__statementList_2Context::realStatement() {
  return getRuleContext<PnfGoParser::RealStatementContext>(0);
}

PnfGoParser::EosContext* PnfGoParser::Aux_rule__statementList_2Context::eos() {
  return getRuleContext<PnfGoParser::EosContext>(0);
}


size_t PnfGoParser::Aux_rule__statementList_2Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__statementList_2;
}

void PnfGoParser::Aux_rule__statementList_2Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__statementList_2(this);
}

void PnfGoParser::Aux_rule__statementList_2Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__statementList_2(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__statementList_2Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__statementList_2(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__statementList_2Context* PnfGoParser::aux_rule__statementList_2() {
  Aux_rule__statementList_2Context *_localctx = _tracker.createInstance<Aux_rule__statementList_2Context>(_ctx, getState());
  enterRule(_localctx, 392, PnfGoParser::RuleAux_rule__statementList_2);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1210);
    realStatement();
    setState(1211);
    eos();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__recvStmt_3Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__recvStmt_3Context::Aux_rule__recvStmt_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::ExpressionListContext* PnfGoParser::Aux_rule__recvStmt_3Context::expressionList() {
  return getRuleContext<PnfGoParser::ExpressionListContext>(0);
}

tree::TerminalNode* PnfGoParser::Aux_rule__recvStmt_3Context::ASSIGN() {
  return getToken(PnfGoParser::ASSIGN, 0);
}


size_t PnfGoParser::Aux_rule__recvStmt_3Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__recvStmt_3;
}

void PnfGoParser::Aux_rule__recvStmt_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__recvStmt_3(this);
}

void PnfGoParser::Aux_rule__recvStmt_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__recvStmt_3(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__recvStmt_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__recvStmt_3(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__recvStmt_3Context* PnfGoParser::aux_rule__recvStmt_3() {
  Aux_rule__recvStmt_3Context *_localctx = _tracker.createInstance<Aux_rule__recvStmt_3Context>(_ctx, getState());
  enterRule(_localctx, 394, PnfGoParser::RuleAux_rule__recvStmt_3);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1213);
    expressionList();
    setState(1214);
    match(PnfGoParser::ASSIGN);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__recvStmt_4Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__recvStmt_4Context::Aux_rule__recvStmt_4Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::IdentifierListContext* PnfGoParser::Aux_rule__recvStmt_4Context::identifierList() {
  return getRuleContext<PnfGoParser::IdentifierListContext>(0);
}

tree::TerminalNode* PnfGoParser::Aux_rule__recvStmt_4Context::DECLARE_ASSIGN() {
  return getToken(PnfGoParser::DECLARE_ASSIGN, 0);
}


size_t PnfGoParser::Aux_rule__recvStmt_4Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__recvStmt_4;
}

void PnfGoParser::Aux_rule__recvStmt_4Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__recvStmt_4(this);
}

void PnfGoParser::Aux_rule__recvStmt_4Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__recvStmt_4(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__recvStmt_4Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__recvStmt_4(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__recvStmt_4Context* PnfGoParser::aux_rule__recvStmt_4() {
  Aux_rule__recvStmt_4Context *_localctx = _tracker.createInstance<Aux_rule__recvStmt_4Context>(_ctx, getState());
  enterRule(_localctx, 396, PnfGoParser::RuleAux_rule__recvStmt_4);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1216);
    identifierList();
    setState(1217);
    match(PnfGoParser::DECLARE_ASSIGN);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__primaryExpr_4Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__primaryExpr_4Context::Aux_rule__primaryExpr_4Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::Aux_rule__primaryExpr_4Context::DOT() {
  return getToken(PnfGoParser::DOT, 0);
}

tree::TerminalNode* PnfGoParser::Aux_rule__primaryExpr_4Context::IDENTIFIER() {
  return getToken(PnfGoParser::IDENTIFIER, 0);
}


size_t PnfGoParser::Aux_rule__primaryExpr_4Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__primaryExpr_4;
}

void PnfGoParser::Aux_rule__primaryExpr_4Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__primaryExpr_4(this);
}

void PnfGoParser::Aux_rule__primaryExpr_4Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__primaryExpr_4(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__primaryExpr_4Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__primaryExpr_4(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__primaryExpr_4Context* PnfGoParser::aux_rule__primaryExpr_4() {
  Aux_rule__primaryExpr_4Context *_localctx = _tracker.createInstance<Aux_rule__primaryExpr_4Context>(_ctx, getState());
  enterRule(_localctx, 398, PnfGoParser::RuleAux_rule__primaryExpr_4);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1219);
    match(PnfGoParser::DOT);
    setState(1220);
    match(PnfGoParser::IDENTIFIER);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__type__1Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__type__1Context::Aux_rule__type__1Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::Aux_rule__type__1Context::L_PAREN() {
  return getToken(PnfGoParser::L_PAREN, 0);
}

PnfGoParser::Type_Context* PnfGoParser::Aux_rule__type__1Context::type_() {
  return getRuleContext<PnfGoParser::Type_Context>(0);
}

tree::TerminalNode* PnfGoParser::Aux_rule__type__1Context::R_PAREN() {
  return getToken(PnfGoParser::R_PAREN, 0);
}


size_t PnfGoParser::Aux_rule__type__1Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__type__1;
}

void PnfGoParser::Aux_rule__type__1Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__type__1(this);
}

void PnfGoParser::Aux_rule__type__1Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__type__1(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__type__1Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__type__1(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__type__1Context* PnfGoParser::aux_rule__type__1() {
  Aux_rule__type__1Context *_localctx = _tracker.createInstance<Aux_rule__type__1Context>(_ctx, getState());
  enterRule(_localctx, 400, PnfGoParser::RuleAux_rule__type__1);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1222);
    match(PnfGoParser::L_PAREN);
    setState(1223);
    type_();
    setState(1224);
    match(PnfGoParser::R_PAREN);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__importDecl_4Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__importDecl_4Context::Aux_rule__importDecl_4Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::Aux_rule__importDecl_4Context::L_PAREN() {
  return getToken(PnfGoParser::L_PAREN, 0);
}

PnfGoParser::Kleene_star__importDecl_2Context* PnfGoParser::Aux_rule__importDecl_4Context::kleene_star__importDecl_2() {
  return getRuleContext<PnfGoParser::Kleene_star__importDecl_2Context>(0);
}

tree::TerminalNode* PnfGoParser::Aux_rule__importDecl_4Context::R_PAREN() {
  return getToken(PnfGoParser::R_PAREN, 0);
}


size_t PnfGoParser::Aux_rule__importDecl_4Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__importDecl_4;
}

void PnfGoParser::Aux_rule__importDecl_4Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__importDecl_4(this);
}

void PnfGoParser::Aux_rule__importDecl_4Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__importDecl_4(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__importDecl_4Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__importDecl_4(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__importDecl_4Context* PnfGoParser::aux_rule__importDecl_4() {
  Aux_rule__importDecl_4Context *_localctx = _tracker.createInstance<Aux_rule__importDecl_4Context>(_ctx, getState());
  enterRule(_localctx, 402, PnfGoParser::RuleAux_rule__importDecl_4);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1226);
    match(PnfGoParser::L_PAREN);
    setState(1227);
    kleene_star__importDecl_2();
    setState(1228);
    match(PnfGoParser::R_PAREN);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__constDecl_4Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__constDecl_4Context::Aux_rule__constDecl_4Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::Aux_rule__constDecl_4Context::L_PAREN() {
  return getToken(PnfGoParser::L_PAREN, 0);
}

PnfGoParser::Kleene_star__constDecl_2Context* PnfGoParser::Aux_rule__constDecl_4Context::kleene_star__constDecl_2() {
  return getRuleContext<PnfGoParser::Kleene_star__constDecl_2Context>(0);
}

tree::TerminalNode* PnfGoParser::Aux_rule__constDecl_4Context::R_PAREN() {
  return getToken(PnfGoParser::R_PAREN, 0);
}


size_t PnfGoParser::Aux_rule__constDecl_4Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__constDecl_4;
}

void PnfGoParser::Aux_rule__constDecl_4Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__constDecl_4(this);
}

void PnfGoParser::Aux_rule__constDecl_4Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__constDecl_4(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__constDecl_4Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__constDecl_4(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__constDecl_4Context* PnfGoParser::aux_rule__constDecl_4() {
  Aux_rule__constDecl_4Context *_localctx = _tracker.createInstance<Aux_rule__constDecl_4Context>(_ctx, getState());
  enterRule(_localctx, 404, PnfGoParser::RuleAux_rule__constDecl_4);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1230);
    match(PnfGoParser::L_PAREN);
    setState(1231);
    kleene_star__constDecl_2();
    setState(1232);
    match(PnfGoParser::R_PAREN);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__typeDecl_4Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__typeDecl_4Context::Aux_rule__typeDecl_4Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::Aux_rule__typeDecl_4Context::L_PAREN() {
  return getToken(PnfGoParser::L_PAREN, 0);
}

PnfGoParser::Kleene_star__typeDecl_2Context* PnfGoParser::Aux_rule__typeDecl_4Context::kleene_star__typeDecl_2() {
  return getRuleContext<PnfGoParser::Kleene_star__typeDecl_2Context>(0);
}

tree::TerminalNode* PnfGoParser::Aux_rule__typeDecl_4Context::R_PAREN() {
  return getToken(PnfGoParser::R_PAREN, 0);
}


size_t PnfGoParser::Aux_rule__typeDecl_4Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__typeDecl_4;
}

void PnfGoParser::Aux_rule__typeDecl_4Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__typeDecl_4(this);
}

void PnfGoParser::Aux_rule__typeDecl_4Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__typeDecl_4(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__typeDecl_4Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__typeDecl_4(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__typeDecl_4Context* PnfGoParser::aux_rule__typeDecl_4() {
  Aux_rule__typeDecl_4Context *_localctx = _tracker.createInstance<Aux_rule__typeDecl_4Context>(_ctx, getState());
  enterRule(_localctx, 406, PnfGoParser::RuleAux_rule__typeDecl_4);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1234);
    match(PnfGoParser::L_PAREN);
    setState(1235);
    kleene_star__typeDecl_2();
    setState(1236);
    match(PnfGoParser::R_PAREN);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__varDecl_4Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__varDecl_4Context::Aux_rule__varDecl_4Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::Aux_rule__varDecl_4Context::L_PAREN() {
  return getToken(PnfGoParser::L_PAREN, 0);
}

PnfGoParser::Kleene_star__varDecl_2Context* PnfGoParser::Aux_rule__varDecl_4Context::kleene_star__varDecl_2() {
  return getRuleContext<PnfGoParser::Kleene_star__varDecl_2Context>(0);
}

tree::TerminalNode* PnfGoParser::Aux_rule__varDecl_4Context::R_PAREN() {
  return getToken(PnfGoParser::R_PAREN, 0);
}


size_t PnfGoParser::Aux_rule__varDecl_4Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__varDecl_4;
}

void PnfGoParser::Aux_rule__varDecl_4Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__varDecl_4(this);
}

void PnfGoParser::Aux_rule__varDecl_4Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__varDecl_4(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__varDecl_4Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__varDecl_4(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__varDecl_4Context* PnfGoParser::aux_rule__varDecl_4() {
  Aux_rule__varDecl_4Context *_localctx = _tracker.createInstance<Aux_rule__varDecl_4Context>(_ctx, getState());
  enterRule(_localctx, 408, PnfGoParser::RuleAux_rule__varDecl_4);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1238);
    match(PnfGoParser::L_PAREN);
    setState(1239);
    kleene_star__varDecl_2();
    setState(1240);
    match(PnfGoParser::R_PAREN);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__varSpec_4Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__varSpec_4Context::Aux_rule__varSpec_4Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Type_Context* PnfGoParser::Aux_rule__varSpec_4Context::type_() {
  return getRuleContext<PnfGoParser::Type_Context>(0);
}

PnfGoParser::Optional__varSpec_2Context* PnfGoParser::Aux_rule__varSpec_4Context::optional__varSpec_2() {
  return getRuleContext<PnfGoParser::Optional__varSpec_2Context>(0);
}


size_t PnfGoParser::Aux_rule__varSpec_4Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__varSpec_4;
}

void PnfGoParser::Aux_rule__varSpec_4Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__varSpec_4(this);
}

void PnfGoParser::Aux_rule__varSpec_4Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__varSpec_4(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__varSpec_4Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__varSpec_4(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__varSpec_4Context* PnfGoParser::aux_rule__varSpec_4() {
  Aux_rule__varSpec_4Context *_localctx = _tracker.createInstance<Aux_rule__varSpec_4Context>(_ctx, getState());
  enterRule(_localctx, 410, PnfGoParser::RuleAux_rule__varSpec_4);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1242);
    type_();
    setState(1243);
    optional__varSpec_2();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__varSpec_5Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__varSpec_5Context::Aux_rule__varSpec_5Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::Aux_rule__varSpec_5Context::ASSIGN() {
  return getToken(PnfGoParser::ASSIGN, 0);
}

PnfGoParser::ExpressionListContext* PnfGoParser::Aux_rule__varSpec_5Context::expressionList() {
  return getRuleContext<PnfGoParser::ExpressionListContext>(0);
}


size_t PnfGoParser::Aux_rule__varSpec_5Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__varSpec_5;
}

void PnfGoParser::Aux_rule__varSpec_5Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__varSpec_5(this);
}

void PnfGoParser::Aux_rule__varSpec_5Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__varSpec_5(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__varSpec_5Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__varSpec_5(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__varSpec_5Context* PnfGoParser::aux_rule__varSpec_5() {
  Aux_rule__varSpec_5Context *_localctx = _tracker.createInstance<Aux_rule__varSpec_5Context>(_ctx, getState());
  enterRule(_localctx, 412, PnfGoParser::RuleAux_rule__varSpec_5);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1245);
    match(PnfGoParser::ASSIGN);
    setState(1246);
    expressionList();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__channelType_3Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__channelType_3Context::Aux_rule__channelType_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::Aux_rule__channelType_3Context::CHAN() {
  return getToken(PnfGoParser::CHAN, 0);
}

tree::TerminalNode* PnfGoParser::Aux_rule__channelType_3Context::RECEIVE() {
  return getToken(PnfGoParser::RECEIVE, 0);
}


size_t PnfGoParser::Aux_rule__channelType_3Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__channelType_3;
}

void PnfGoParser::Aux_rule__channelType_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__channelType_3(this);
}

void PnfGoParser::Aux_rule__channelType_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__channelType_3(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__channelType_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__channelType_3(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__channelType_3Context* PnfGoParser::aux_rule__channelType_3() {
  Aux_rule__channelType_3Context *_localctx = _tracker.createInstance<Aux_rule__channelType_3Context>(_ctx, getState());
  enterRule(_localctx, 414, PnfGoParser::RuleAux_rule__channelType_3);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1248);
    match(PnfGoParser::CHAN);
    setState(1249);
    match(PnfGoParser::RECEIVE);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__channelType_4Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__channelType_4Context::Aux_rule__channelType_4Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Optional__channelType_2Context* PnfGoParser::Aux_rule__channelType_4Context::optional__channelType_2() {
  return getRuleContext<PnfGoParser::Optional__channelType_2Context>(0);
}

tree::TerminalNode* PnfGoParser::Aux_rule__channelType_4Context::CHAN() {
  return getToken(PnfGoParser::CHAN, 0);
}


size_t PnfGoParser::Aux_rule__channelType_4Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__channelType_4;
}

void PnfGoParser::Aux_rule__channelType_4Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__channelType_4(this);
}

void PnfGoParser::Aux_rule__channelType_4Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__channelType_4(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__channelType_4Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__channelType_4(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__channelType_4Context* PnfGoParser::aux_rule__channelType_4() {
  Aux_rule__channelType_4Context *_localctx = _tracker.createInstance<Aux_rule__channelType_4Context>(_ctx, getState());
  enterRule(_localctx, 416, PnfGoParser::RuleAux_rule__channelType_4);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1251);
    optional__channelType_2();
    setState(1252);
    match(PnfGoParser::CHAN);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__fieldDecl_3Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__fieldDecl_3Context::Aux_rule__fieldDecl_3Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::IdentifierListContext* PnfGoParser::Aux_rule__fieldDecl_3Context::identifierList() {
  return getRuleContext<PnfGoParser::IdentifierListContext>(0);
}

PnfGoParser::Type_Context* PnfGoParser::Aux_rule__fieldDecl_3Context::type_() {
  return getRuleContext<PnfGoParser::Type_Context>(0);
}


size_t PnfGoParser::Aux_rule__fieldDecl_3Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__fieldDecl_3;
}

void PnfGoParser::Aux_rule__fieldDecl_3Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__fieldDecl_3(this);
}

void PnfGoParser::Aux_rule__fieldDecl_3Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__fieldDecl_3(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__fieldDecl_3Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__fieldDecl_3(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__fieldDecl_3Context* PnfGoParser::aux_rule__fieldDecl_3() {
  Aux_rule__fieldDecl_3Context *_localctx = _tracker.createInstance<Aux_rule__fieldDecl_3Context>(_ctx, getState());
  enterRule(_localctx, 418, PnfGoParser::RuleAux_rule__fieldDecl_3);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1254);
    identifierList();
    setState(1255);
    type_();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__arguments_8Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__arguments_8Context::Aux_rule__arguments_8Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

PnfGoParser::Type_Context* PnfGoParser::Aux_rule__arguments_8Context::type_() {
  return getRuleContext<PnfGoParser::Type_Context>(0);
}

PnfGoParser::Optional__arguments_2Context* PnfGoParser::Aux_rule__arguments_8Context::optional__arguments_2() {
  return getRuleContext<PnfGoParser::Optional__arguments_2Context>(0);
}


size_t PnfGoParser::Aux_rule__arguments_8Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__arguments_8;
}

void PnfGoParser::Aux_rule__arguments_8Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__arguments_8(this);
}

void PnfGoParser::Aux_rule__arguments_8Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__arguments_8(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__arguments_8Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__arguments_8(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__arguments_8Context* PnfGoParser::aux_rule__arguments_8() {
  Aux_rule__arguments_8Context *_localctx = _tracker.createInstance<Aux_rule__arguments_8Context>(_ctx, getState());
  enterRule(_localctx, 420, PnfGoParser::RuleAux_rule__arguments_8);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1257);
    type_();
    setState(1258);
    optional__arguments_2();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__slice_6Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__slice_6Context::Aux_rule__slice_6Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

std::vector<PnfGoParser::ExpressionContext *> PnfGoParser::Aux_rule__slice_6Context::expression() {
  return getRuleContexts<PnfGoParser::ExpressionContext>();
}

PnfGoParser::ExpressionContext* PnfGoParser::Aux_rule__slice_6Context::expression(size_t i) {
  return getRuleContext<PnfGoParser::ExpressionContext>(i);
}

tree::TerminalNode* PnfGoParser::Aux_rule__slice_6Context::COLON() {
  return getToken(PnfGoParser::COLON, 0);
}


size_t PnfGoParser::Aux_rule__slice_6Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__slice_6;
}

void PnfGoParser::Aux_rule__slice_6Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__slice_6(this);
}

void PnfGoParser::Aux_rule__slice_6Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__slice_6(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__slice_6Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__slice_6(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__slice_6Context* PnfGoParser::aux_rule__slice_6() {
  Aux_rule__slice_6Context *_localctx = _tracker.createInstance<Aux_rule__slice_6Context>(_ctx, getState());
  enterRule(_localctx, 422, PnfGoParser::RuleAux_rule__slice_6);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1260);
    expression();
    setState(1261);
    match(PnfGoParser::COLON);
    setState(1262);
    expression();
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

//----------------- Aux_rule__primaryExpr_5Context ------------------------------------------------------------------

PnfGoParser::Aux_rule__primaryExpr_5Context::Aux_rule__primaryExpr_5Context(ParserRuleContext *parent, size_t invokingState)
  : ParserRuleContext(parent, invokingState) {
}

tree::TerminalNode* PnfGoParser::Aux_rule__primaryExpr_5Context::L_PAREN() {
  return getToken(PnfGoParser::L_PAREN, 0);
}

PnfGoParser::ExpressionContext* PnfGoParser::Aux_rule__primaryExpr_5Context::expression() {
  return getRuleContext<PnfGoParser::ExpressionContext>(0);
}

tree::TerminalNode* PnfGoParser::Aux_rule__primaryExpr_5Context::R_PAREN() {
  return getToken(PnfGoParser::R_PAREN, 0);
}


size_t PnfGoParser::Aux_rule__primaryExpr_5Context::getRuleIndex() const {
  return PnfGoParser::RuleAux_rule__primaryExpr_5;
}

void PnfGoParser::Aux_rule__primaryExpr_5Context::enterRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->enterAux_rule__primaryExpr_5(this);
}

void PnfGoParser::Aux_rule__primaryExpr_5Context::exitRule(tree::ParseTreeListener *listener) {
  auto parserListener = dynamic_cast<PnfGoParserListener *>(listener);
  if (parserListener != nullptr)
    parserListener->exitAux_rule__primaryExpr_5(this);
}


antlrcpp::Any PnfGoParser::Aux_rule__primaryExpr_5Context::accept(tree::ParseTreeVisitor *visitor) {
  if (auto parserVisitor = dynamic_cast<PnfGoParserVisitor*>(visitor))
    return parserVisitor->visitAux_rule__primaryExpr_5(this);
  else
    return visitor->visitChildren(this);
}

PnfGoParser::Aux_rule__primaryExpr_5Context* PnfGoParser::aux_rule__primaryExpr_5() {
  Aux_rule__primaryExpr_5Context *_localctx = _tracker.createInstance<Aux_rule__primaryExpr_5Context>(_ctx, getState());
  enterRule(_localctx, 424, PnfGoParser::RuleAux_rule__primaryExpr_5);

  auto onExit = finally([=] {
    exitRule();
  });
  try {
    enterOuterAlt(_localctx, 1);
    setState(1264);
    match(PnfGoParser::L_PAREN);
    setState(1265);
    expression();
    setState(1266);
    match(PnfGoParser::R_PAREN);
   
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }

  return _localctx;
}

bool PnfGoParser::sempred(RuleContext *context, size_t ruleIndex, size_t predicateIndex) {
  switch (ruleIndex) {
    case 194: return aux_rule__eos_1Sempred(dynamic_cast<Aux_rule__eos_1Context *>(context), predicateIndex);
    case 195: return aux_rule__eos_2Sempred(dynamic_cast<Aux_rule__eos_2Context *>(context), predicateIndex);

  default:
    break;
  }
  return true;
}

bool PnfGoParser::aux_rule__eos_1Sempred(Aux_rule__eos_1Context *_localctx, size_t predicateIndex) {
  switch (predicateIndex) {
    case 0: return _localctx->start->getType() != SEMI && checkPreviousTokenText("}");

  default:
    break;
  }
  return true;
}

bool PnfGoParser::aux_rule__eos_2Sempred(Aux_rule__eos_2Context *_localctx, size_t predicateIndex) {
  switch (predicateIndex) {
    case 1: return _localctx->start->getType() != SEMI && checkPreviousTokenText(")");

  default:
    break;
  }
  return true;
}

// Static vars and initialization.
std::vector<dfa::DFA> PnfGoParser::_decisionToDFA;
atn::PredictionContextCache PnfGoParser::_sharedContextCache;

// We own the ATN which in turn owns the ATN states.
atn::ATN PnfGoParser::_atn;
std::vector<uint16_t> PnfGoParser::_serializedATN;

std::vector<std::string> PnfGoParser::_ruleNames = {
  "sourceFile", "packageClause", "importDecl", "importSpec", "importPath", 
  "declaration", "constDecl", "constSpec", "identifierList", "expressionList", 
  "typeDecl", "typeSpec", "functionDecl", "methodDecl", "receiver", "varDecl", 
  "varSpec", "block", "statementList", "statement", "simpleStmt", "realSimpleStmt", 
  "expressionStmt", "sendStmt", "incDecStmt", "assignment", "assign_op", 
  "shortVarDecl", "labeledStmt", "returnStmt", "breakStmt", "continueStmt", 
  "gotoStmt", "fallthroughStmt", "deferStmt", "ifStmt", "exprSwitchStmt", 
  "exprCaseClause", "exprSwitchCase", "typeSwitchStmt", "typeSwitchGuard", 
  "typeCaseClause", "typeSwitchCase", "typeList", "selectStmt", "commClause", 
  "commCase", "recvStmt", "forStmt", "forClause", "rangeClause", "goStmt", 
  "typeName", "arrayType", "elementType", "pointerType", "interfaceType", 
  "sliceType", "mapType", "channelType", "methodSpec", "functionType", "signature", 
  "result", "parameters", "parameterDecl", "unaryExpr", "conversion", "qualifiedIdent", 
  "compositeLit", "literalType", "literalValue", "elementList", "keyedElement", 
  "key", "element", "structType", "fieldDecl", "string_", "anonymousField", 
  "functionLit", "index", "slice", "typeAssertion", "arguments", "methodExpr", 
  "eos", "aux_rule__sourceFile_1", "kleene_star__sourceFile_2", "aux_rule__sourceFile_3", 
  "kleene_star__sourceFile_4", "aux_rule__importDecl_1", "kleene_star__importDecl_2", 
  "aux_rule__importSpec_1", "optional__importSpec_2", "aux_rule__constDecl_1", 
  "kleene_star__constDecl_2", "optional__constSpec_1", "aux_rule__constSpec_2", 
  "optional__constSpec_3", "aux_rule__identifierList_1", "kleene_star__identifierList_2", 
  "aux_rule__expressionList_1", "kleene_star__expressionList_2", "aux_rule__typeDecl_1", 
  "kleene_star__typeDecl_2", "optional__typeSpec_1", "optional__functionDecl_1", 
  "aux_rule__varDecl_1", "kleene_star__varDecl_2", "aux_rule__varSpec_1", 
  "optional__varSpec_2", "optional__block_1", "aux_rule__statementList_1", 
  "aux_rule__assign_op_1", "optional__assign_op_2", "optional__returnStmt_1", 
  "optional__breakStmt_1", "aux_rule__ifStmt_1", "optional__ifStmt_2", "aux_rule__ifStmt_3", 
  "optional__ifStmt_4", "optional__exprSwitchStmt_3", "kleene_star__exprSwitchStmt_4", 
  "kleene_star__typeSwitchStmt_3", "aux_rule__typeSwitchGuard_1", "optional__typeSwitchGuard_2", 
  "aux_rule__typeList_1", "kleene_star__typeList_2", "kleene_star__selectStmt_1", 
  "aux_rule__recvStmt_1", "optional__recvStmt_2", "aux_rule__forStmt_1", 
  "optional__forStmt_2", "optional__forClause_1", "aux_rule__interfaceType_1", 
  "kleene_star__interfaceType_2", "aux_rule__parameters_1", "kleene_star__parameters_2", 
  "optional__parameters_3", "aux_rule__parameters_4", "optional__parameters_5", 
  "optional__parameterDecl_1", "optional__parameterDecl_2", "optional__conversion_1", 
  "aux_rule__literalValue_2", "optional__literalValue_3", "aux_rule__elementList_1", 
  "kleene_star__elementList_2", "aux_rule__keyedElement_1", "optional__keyedElement_2", 
  "aux_rule__structType_1", "kleene_star__structType_2", "optional__fieldDecl_1", 
  "optional__anonymousField_1", "aux_rule__arguments_1", "optional__arguments_2", 
  "aux_rule__arguments_5", "optional__arguments_6", "aux_rule__expression_2", 
  "kleene_star__expression_1", "expression", "aux_rule__primaryExpr_2", 
  "kleene_star__primaryExpr_1", "primaryExpr", "optional__signature_1", 
  "altnt_block__expression_3", "type_", "realStatement", "altnt_block__importDecl_3", 
  "altnt_block__constDecl_3", "altnt_block__typeDecl_3", "altnt_block__varDecl_3", 
  "altnt_block__varSpec_3", "altnt_block__incDecStmt_1", "altnt_block__typeList_3", 
  "altnt_block__commCase_1", "altnt_block__channelType_1", "altnt_block__unaryExpr_1", 
  "altnt_block__fieldDecl_2", "altnt_block__slice_4", "altnt_block__sourceFile_5", 
  "altnt_block__ifStmt_5", "altnt_block__arguments_7", "optional__channelType_2", 
  "altnt_block__slice_5", "aux_rule__primaryExpr_3", "aux_rule__sourceFile_6", 
  "aux_rule__exprSwitchCase_1", "aux_rule__typeSwitchCase_1", "aux_rule__commCase_2", 
  "aux_rule__methodSpec_2", "aux_rule__unaryExpr_2", "aux_rule__literalType_1", 
  "aux_rule__eos_1", "aux_rule__eos_2", "aux_rule__statementList_2", "aux_rule__recvStmt_3", 
  "aux_rule__recvStmt_4", "aux_rule__primaryExpr_4", "aux_rule__type__1", 
  "aux_rule__importDecl_4", "aux_rule__constDecl_4", "aux_rule__typeDecl_4", 
  "aux_rule__varDecl_4", "aux_rule__varSpec_4", "aux_rule__varSpec_5", "aux_rule__channelType_3", 
  "aux_rule__channelType_4", "aux_rule__fieldDecl_3", "aux_rule__arguments_8", 
  "aux_rule__slice_6", "aux_rule__primaryExpr_5"
};

std::vector<std::string> PnfGoParser::_literalNames = {
  "", "'break'", "'default'", "'func'", "'interface'", "'select'", "'case'", 
  "'defer'", "'go'", "'map'", "'struct'", "'chan'", "'else'", "'goto'", 
  "'package'", "'switch'", "'const'", "'fallthrough'", "'if'", "'range'", 
  "'type'", "'continue'", "'for'", "'import'", "'return'", "'var'", "'nil'", 
  "", "'('", "')'", "'{'", "'}'", "'['", "']'", "'='", "','", "';'", "':'", 
  "'.'", "'++'", "'--'", "':='", "'...'", "'||'", "'&&'", "'=='", "'!='", 
  "'<'", "'<='", "'>'", "'>='", "'|'", "'/'", "'%'", "'<<'", "'>>'", "'&^'", 
  "'!'", "'+'", "'-'", "'^'", "'*'", "'&'", "'<-'"
};

std::vector<std::string> PnfGoParser::_symbolicNames = {
  "", "BREAK", "DEFAULT", "FUNC", "INTERFACE", "SELECT", "CASE", "DEFER", 
  "GO", "MAP", "STRUCT", "CHAN", "ELSE", "GOTO", "PACKAGE", "SWITCH", "CONST", 
  "FALLTHROUGH", "IF", "RANGE", "TYPE", "CONTINUE", "FOR", "IMPORT", "RETURN", 
  "VAR", "NIL_LIT", "IDENTIFIER", "L_PAREN", "R_PAREN", "L_CURLY", "R_CURLY", 
  "L_BRACKET", "R_BRACKET", "ASSIGN", "COMMA", "SEMI", "COLON", "DOT", "PLUS_PLUS", 
  "MINUS_MINUS", "DECLARE_ASSIGN", "ELLIPSIS", "LOGICAL_OR", "LOGICAL_AND", 
  "EQUALS", "NOT_EQUALS", "LESS", "LESS_OR_EQUALS", "GREATER", "GREATER_OR_EQUALS", 
  "OR", "DIV", "MOD", "LSHIFT", "RSHIFT", "BIT_CLEAR", "EXCLAMATION", "PLUS", 
  "MINUS", "CARET", "STAR", "AMPERSAND", "RECEIVE", "DECIMAL_LIT", "OCTAL_LIT", 
  "HEX_LIT", "FLOAT_LIT", "IMAGINARY_LIT", "RUNE_LIT", "RAW_STRING_LIT", 
  "INTERPRETED_STRING_LIT", "WS", "COMMENT", "TERMINATOR", "LINE_COMMENT"
};

dfa::Vocabulary PnfGoParser::_vocabulary(_literalNames, _symbolicNames);

std::vector<std::string> PnfGoParser::_tokenNames;

PnfGoParser::Initializer::Initializer() {
	for (size_t i = 0; i < _symbolicNames.size(); ++i) {
		std::string name = _vocabulary.getLiteralName(i);
		if (name.empty()) {
			name = _vocabulary.getSymbolicName(i);
		}

		if (name.empty()) {
			_tokenNames.push_back("<INVALID>");
		} else {
      _tokenNames.push_back(name);
    }
	}

  _serializedATN = {
    0x3, 0x608b, 0xa72a, 0x8133, 0xb9ed, 0x417c, 0x3be7, 0x7786, 0x5964, 
    0x3, 0x4d, 0x4f7, 0x4, 0x2, 0x9, 0x2, 0x4, 0x3, 0x9, 0x3, 0x4, 0x4, 
    0x9, 0x4, 0x4, 0x5, 0x9, 0x5, 0x4, 0x6, 0x9, 0x6, 0x4, 0x7, 0x9, 0x7, 
    0x4, 0x8, 0x9, 0x8, 0x4, 0x9, 0x9, 0x9, 0x4, 0xa, 0x9, 0xa, 0x4, 0xb, 
    0x9, 0xb, 0x4, 0xc, 0x9, 0xc, 0x4, 0xd, 0x9, 0xd, 0x4, 0xe, 0x9, 0xe, 
    0x4, 0xf, 0x9, 0xf, 0x4, 0x10, 0x9, 0x10, 0x4, 0x11, 0x9, 0x11, 0x4, 
    0x12, 0x9, 0x12, 0x4, 0x13, 0x9, 0x13, 0x4, 0x14, 0x9, 0x14, 0x4, 0x15, 
    0x9, 0x15, 0x4, 0x16, 0x9, 0x16, 0x4, 0x17, 0x9, 0x17, 0x4, 0x18, 0x9, 
    0x18, 0x4, 0x19, 0x9, 0x19, 0x4, 0x1a, 0x9, 0x1a, 0x4, 0x1b, 0x9, 0x1b, 
    0x4, 0x1c, 0x9, 0x1c, 0x4, 0x1d, 0x9, 0x1d, 0x4, 0x1e, 0x9, 0x1e, 0x4, 
    0x1f, 0x9, 0x1f, 0x4, 0x20, 0x9, 0x20, 0x4, 0x21, 0x9, 0x21, 0x4, 0x22, 
    0x9, 0x22, 0x4, 0x23, 0x9, 0x23, 0x4, 0x24, 0x9, 0x24, 0x4, 0x25, 0x9, 
    0x25, 0x4, 0x26, 0x9, 0x26, 0x4, 0x27, 0x9, 0x27, 0x4, 0x28, 0x9, 0x28, 
    0x4, 0x29, 0x9, 0x29, 0x4, 0x2a, 0x9, 0x2a, 0x4, 0x2b, 0x9, 0x2b, 0x4, 
    0x2c, 0x9, 0x2c, 0x4, 0x2d, 0x9, 0x2d, 0x4, 0x2e, 0x9, 0x2e, 0x4, 0x2f, 
    0x9, 0x2f, 0x4, 0x30, 0x9, 0x30, 0x4, 0x31, 0x9, 0x31, 0x4, 0x32, 0x9, 
    0x32, 0x4, 0x33, 0x9, 0x33, 0x4, 0x34, 0x9, 0x34, 0x4, 0x35, 0x9, 0x35, 
    0x4, 0x36, 0x9, 0x36, 0x4, 0x37, 0x9, 0x37, 0x4, 0x38, 0x9, 0x38, 0x4, 
    0x39, 0x9, 0x39, 0x4, 0x3a, 0x9, 0x3a, 0x4, 0x3b, 0x9, 0x3b, 0x4, 0x3c, 
    0x9, 0x3c, 0x4, 0x3d, 0x9, 0x3d, 0x4, 0x3e, 0x9, 0x3e, 0x4, 0x3f, 0x9, 
    0x3f, 0x4, 0x40, 0x9, 0x40, 0x4, 0x41, 0x9, 0x41, 0x4, 0x42, 0x9, 0x42, 
    0x4, 0x43, 0x9, 0x43, 0x4, 0x44, 0x9, 0x44, 0x4, 0x45, 0x9, 0x45, 0x4, 
    0x46, 0x9, 0x46, 0x4, 0x47, 0x9, 0x47, 0x4, 0x48, 0x9, 0x48, 0x4, 0x49, 
    0x9, 0x49, 0x4, 0x4a, 0x9, 0x4a, 0x4, 0x4b, 0x9, 0x4b, 0x4, 0x4c, 0x9, 
    0x4c, 0x4, 0x4d, 0x9, 0x4d, 0x4, 0x4e, 0x9, 0x4e, 0x4, 0x4f, 0x9, 0x4f, 
    0x4, 0x50, 0x9, 0x50, 0x4, 0x51, 0x9, 0x51, 0x4, 0x52, 0x9, 0x52, 0x4, 
    0x53, 0x9, 0x53, 0x4, 0x54, 0x9, 0x54, 0x4, 0x55, 0x9, 0x55, 0x4, 0x56, 
    0x9, 0x56, 0x4, 0x57, 0x9, 0x57, 0x4, 0x58, 0x9, 0x58, 0x4, 0x59, 0x9, 
    0x59, 0x4, 0x5a, 0x9, 0x5a, 0x4, 0x5b, 0x9, 0x5b, 0x4, 0x5c, 0x9, 0x5c, 
    0x4, 0x5d, 0x9, 0x5d, 0x4, 0x5e, 0x9, 0x5e, 0x4, 0x5f, 0x9, 0x5f, 0x4, 
    0x60, 0x9, 0x60, 0x4, 0x61, 0x9, 0x61, 0x4, 0x62, 0x9, 0x62, 0x4, 0x63, 
    0x9, 0x63, 0x4, 0x64, 0x9, 0x64, 0x4, 0x65, 0x9, 0x65, 0x4, 0x66, 0x9, 
    0x66, 0x4, 0x67, 0x9, 0x67, 0x4, 0x68, 0x9, 0x68, 0x4, 0x69, 0x9, 0x69, 
    0x4, 0x6a, 0x9, 0x6a, 0x4, 0x6b, 0x9, 0x6b, 0x4, 0x6c, 0x9, 0x6c, 0x4, 
    0x6d, 0x9, 0x6d, 0x4, 0x6e, 0x9, 0x6e, 0x4, 0x6f, 0x9, 0x6f, 0x4, 0x70, 
    0x9, 0x70, 0x4, 0x71, 0x9, 0x71, 0x4, 0x72, 0x9, 0x72, 0x4, 0x73, 0x9, 
    0x73, 0x4, 0x74, 0x9, 0x74, 0x4, 0x75, 0x9, 0x75, 0x4, 0x76, 0x9, 0x76, 
    0x4, 0x77, 0x9, 0x77, 0x4, 0x78, 0x9, 0x78, 0x4, 0x79, 0x9, 0x79, 0x4, 
    0x7a, 0x9, 0x7a, 0x4, 0x7b, 0x9, 0x7b, 0x4, 0x7c, 0x9, 0x7c, 0x4, 0x7d, 
    0x9, 0x7d, 0x4, 0x7e, 0x9, 0x7e, 0x4, 0x7f, 0x9, 0x7f, 0x4, 0x80, 0x9, 
    0x80, 0x4, 0x81, 0x9, 0x81, 0x4, 0x82, 0x9, 0x82, 0x4, 0x83, 0x9, 0x83, 
    0x4, 0x84, 0x9, 0x84, 0x4, 0x85, 0x9, 0x85, 0x4, 0x86, 0x9, 0x86, 0x4, 
    0x87, 0x9, 0x87, 0x4, 0x88, 0x9, 0x88, 0x4, 0x89, 0x9, 0x89, 0x4, 0x8a, 
    0x9, 0x8a, 0x4, 0x8b, 0x9, 0x8b, 0x4, 0x8c, 0x9, 0x8c, 0x4, 0x8d, 0x9, 
    0x8d, 0x4, 0x8e, 0x9, 0x8e, 0x4, 0x8f, 0x9, 0x8f, 0x4, 0x90, 0x9, 0x90, 
    0x4, 0x91, 0x9, 0x91, 0x4, 0x92, 0x9, 0x92, 0x4, 0x93, 0x9, 0x93, 0x4, 
    0x94, 0x9, 0x94, 0x4, 0x95, 0x9, 0x95, 0x4, 0x96, 0x9, 0x96, 0x4, 0x97, 
    0x9, 0x97, 0x4, 0x98, 0x9, 0x98, 0x4, 0x99, 0x9, 0x99, 0x4, 0x9a, 0x9, 
    0x9a, 0x4, 0x9b, 0x9, 0x9b, 0x4, 0x9c, 0x9, 0x9c, 0x4, 0x9d, 0x9, 0x9d, 
    0x4, 0x9e, 0x9, 0x9e, 0x4, 0x9f, 0x9, 0x9f, 0x4, 0xa0, 0x9, 0xa0, 0x4, 
    0xa1, 0x9, 0xa1, 0x4, 0xa2, 0x9, 0xa2, 0x4, 0xa3, 0x9, 0xa3, 0x4, 0xa4, 
    0x9, 0xa4, 0x4, 0xa5, 0x9, 0xa5, 0x4, 0xa6, 0x9, 0xa6, 0x4, 0xa7, 0x9, 
    0xa7, 0x4, 0xa8, 0x9, 0xa8, 0x4, 0xa9, 0x9, 0xa9, 0x4, 0xaa, 0x9, 0xaa, 
    0x4, 0xab, 0x9, 0xab, 0x4, 0xac, 0x9, 0xac, 0x4, 0xad, 0x9, 0xad, 0x4, 
    0xae, 0x9, 0xae, 0x4, 0xaf, 0x9, 0xaf, 0x4, 0xb0, 0x9, 0xb0, 0x4, 0xb1, 
    0x9, 0xb1, 0x4, 0xb2, 0x9, 0xb2, 0x4, 0xb3, 0x9, 0xb3, 0x4, 0xb4, 0x9, 
    0xb4, 0x4, 0xb5, 0x9, 0xb5, 0x4, 0xb6, 0x9, 0xb6, 0x4, 0xb7, 0x9, 0xb7, 
    0x4, 0xb8, 0x9, 0xb8, 0x4, 0xb9, 0x9, 0xb9, 0x4, 0xba, 0x9, 0xba, 0x4, 
    0xbb, 0x9, 0xbb, 0x4, 0xbc, 0x9, 0xbc, 0x4, 0xbd, 0x9, 0xbd, 0x4, 0xbe, 
    0x9, 0xbe, 0x4, 0xbf, 0x9, 0xbf, 0x4, 0xc0, 0x9, 0xc0, 0x4, 0xc1, 0x9, 
    0xc1, 0x4, 0xc2, 0x9, 0xc2, 0x4, 0xc3, 0x9, 0xc3, 0x4, 0xc4, 0x9, 0xc4, 
    0x4, 0xc5, 0x9, 0xc5, 0x4, 0xc6, 0x9, 0xc6, 0x4, 0xc7, 0x9, 0xc7, 0x4, 
    0xc8, 0x9, 0xc8, 0x4, 0xc9, 0x9, 0xc9, 0x4, 0xca, 0x9, 0xca, 0x4, 0xcb, 
    0x9, 0xcb, 0x4, 0xcc, 0x9, 0xcc, 0x4, 0xcd, 0x9, 0xcd, 0x4, 0xce, 0x9, 
    0xce, 0x4, 0xcf, 0x9, 0xcf, 0x4, 0xd0, 0x9, 0xd0, 0x4, 0xd1, 0x9, 0xd1, 
    0x4, 0xd2, 0x9, 0xd2, 0x4, 0xd3, 0x9, 0xd3, 0x4, 0xd4, 0x9, 0xd4, 0x4, 
    0xd5, 0x9, 0xd5, 0x4, 0xd6, 0x9, 0xd6, 0x3, 0x2, 0x3, 0x2, 0x5, 0x2, 
    0x1af, 0xa, 0x2, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x3, 0x4, 0x3, 0x4, 0x3, 
    0x4, 0x3, 0x5, 0x3, 0x5, 0x3, 0x5, 0x3, 0x6, 0x3, 0x6, 0x3, 0x7, 0x3, 
    0x7, 0x3, 0x7, 0x5, 0x7, 0x1bf, 0xa, 0x7, 0x3, 0x8, 0x3, 0x8, 0x3, 0x8, 
    0x3, 0x9, 0x3, 0x9, 0x3, 0x9, 0x3, 0xa, 0x3, 0xa, 0x3, 0xa, 0x3, 0xb, 
    0x3, 0xb, 0x3, 0xb, 0x3, 0xc, 0x3, 0xc, 0x3, 0xc, 0x3, 0xd, 0x3, 0xd, 
    0x3, 0xd, 0x3, 0xd, 0x3, 0xe, 0x3, 0xe, 0x3, 0xe, 0x3, 0xe, 0x3, 0xe, 
    0x3, 0xf, 0x3, 0xf, 0x3, 0xf, 0x3, 0xf, 0x3, 0xf, 0x3, 0xf, 0x3, 0x10, 
    0x3, 0x10, 0x3, 0x11, 0x3, 0x11, 0x3, 0x11, 0x3, 0x12, 0x3, 0x12, 0x3, 
    0x12, 0x3, 0x13, 0x3, 0x13, 0x3, 0x13, 0x3, 0x13, 0x3, 0x14, 0x6, 0x14, 
    0x1ec, 0xa, 0x14, 0xd, 0x14, 0xe, 0x14, 0x1ed, 0x3, 0x15, 0x5, 0x15, 
    0x1f1, 0xa, 0x15, 0x3, 0x16, 0x5, 0x16, 0x1f4, 0xa, 0x16, 0x3, 0x17, 
    0x3, 0x17, 0x3, 0x17, 0x3, 0x17, 0x3, 0x17, 0x5, 0x17, 0x1fb, 0xa, 0x17, 
    0x3, 0x18, 0x3, 0x18, 0x3, 0x19, 0x3, 0x19, 0x3, 0x19, 0x3, 0x19, 0x3, 
    0x1a, 0x3, 0x1a, 0x3, 0x1a, 0x3, 0x1b, 0x3, 0x1b, 0x3, 0x1b, 0x3, 0x1b, 
    0x3, 0x1c, 0x3, 0x1c, 0x3, 0x1c, 0x3, 0x1d, 0x3, 0x1d, 0x3, 0x1d, 0x3, 
    0x1d, 0x3, 0x1e, 0x3, 0x1e, 0x3, 0x1e, 0x3, 0x1e, 0x3, 0x1f, 0x3, 0x1f, 
    0x3, 0x1f, 0x3, 0x20, 0x3, 0x20, 0x3, 0x20, 0x3, 0x21, 0x3, 0x21, 0x3, 
    0x21, 0x3, 0x22, 0x3, 0x22, 0x3, 0x22, 0x3, 0x23, 0x3, 0x23, 0x3, 0x24, 
    0x3, 0x24, 0x3, 0x24, 0x3, 0x25, 0x3, 0x25, 0x3, 0x25, 0x3, 0x25, 0x3, 
    0x25, 0x3, 0x25, 0x3, 0x26, 0x3, 0x26, 0x3, 0x26, 0x3, 0x26, 0x3, 0x26, 
    0x3, 0x26, 0x3, 0x26, 0x3, 0x27, 0x3, 0x27, 0x3, 0x27, 0x3, 0x27, 0x3, 
    0x28, 0x3, 0x28, 0x5, 0x28, 0x239, 0xa, 0x28, 0x3, 0x29, 0x3, 0x29, 
    0x3, 0x29, 0x3, 0x29, 0x3, 0x29, 0x3, 0x29, 0x3, 0x29, 0x3, 0x2a, 0x3, 
    0x2a, 0x3, 0x2a, 0x3, 0x2a, 0x3, 0x2a, 0x3, 0x2a, 0x3, 0x2a, 0x3, 0x2b, 
    0x3, 0x2b, 0x3, 0x2b, 0x3, 0x2b, 0x3, 0x2c, 0x3, 0x2c, 0x5, 0x2c, 0x24f, 
    0xa, 0x2c, 0x3, 0x2d, 0x3, 0x2d, 0x3, 0x2d, 0x3, 0x2e, 0x3, 0x2e, 0x3, 
    0x2e, 0x3, 0x2e, 0x3, 0x2e, 0x3, 0x2f, 0x3, 0x2f, 0x3, 0x2f, 0x3, 0x2f, 
    0x3, 0x30, 0x3, 0x30, 0x5, 0x30, 0x25f, 0xa, 0x30, 0x3, 0x31, 0x3, 0x31, 
    0x3, 0x31, 0x3, 0x32, 0x3, 0x32, 0x3, 0x32, 0x3, 0x32, 0x3, 0x33, 0x3, 
    0x33, 0x3, 0x33, 0x3, 0x33, 0x3, 0x33, 0x3, 0x33, 0x3, 0x34, 0x3, 0x34, 
    0x3, 0x34, 0x3, 0x34, 0x3, 0x35, 0x3, 0x35, 0x3, 0x35, 0x3, 0x36, 0x3, 
    0x36, 0x5, 0x36, 0x277, 0xa, 0x36, 0x3, 0x37, 0x3, 0x37, 0x3, 0x37, 
    0x3, 0x37, 0x3, 0x37, 0x3, 0x38, 0x3, 0x38, 0x3, 0x39, 0x3, 0x39, 0x3, 
    0x39, 0x3, 0x3a, 0x3, 0x3a, 0x3, 0x3a, 0x3, 0x3a, 0x3, 0x3a, 0x3, 0x3b, 
    0x3, 0x3b, 0x3, 0x3b, 0x3, 0x3b, 0x3, 0x3c, 0x3, 0x3c, 0x3, 0x3c, 0x3, 
    0x3c, 0x3, 0x3c, 0x3, 0x3c, 0x3, 0x3d, 0x3, 0x3d, 0x3, 0x3d, 0x3, 0x3e, 
    0x3, 0x3e, 0x5, 0x3e, 0x297, 0xa, 0x3e, 0x3, 0x3f, 0x3, 0x3f, 0x3, 0x3f, 
    0x3, 0x40, 0x3, 0x40, 0x3, 0x40, 0x3, 0x41, 0x3, 0x41, 0x5, 0x41, 0x2a1, 
    0xa, 0x41, 0x3, 0x42, 0x3, 0x42, 0x3, 0x42, 0x3, 0x42, 0x3, 0x43, 0x3, 
    0x43, 0x3, 0x43, 0x3, 0x43, 0x3, 0x44, 0x3, 0x44, 0x5, 0x44, 0x2ad, 
    0xa, 0x44, 0x3, 0x45, 0x3, 0x45, 0x3, 0x45, 0x3, 0x45, 0x3, 0x45, 0x3, 
    0x45, 0x3, 0x46, 0x3, 0x46, 0x3, 0x46, 0x3, 0x46, 0x3, 0x47, 0x3, 0x47, 
    0x3, 0x47, 0x3, 0x48, 0x3, 0x48, 0x3, 0x48, 0x3, 0x48, 0x3, 0x48, 0x3, 
    0x48, 0x5, 0x48, 0x2c2, 0xa, 0x48, 0x3, 0x49, 0x3, 0x49, 0x3, 0x49, 
    0x3, 0x49, 0x3, 0x4a, 0x3, 0x4a, 0x3, 0x4a, 0x3, 0x4b, 0x3, 0x4b, 0x3, 
    0x4b, 0x3, 0x4c, 0x3, 0x4c, 0x3, 0x4c, 0x5, 0x4c, 0x2d1, 0xa, 0x4c, 
    0x3, 0x4d, 0x3, 0x4d, 0x5, 0x4d, 0x2d5, 0xa, 0x4d, 0x3, 0x4e, 0x3, 0x4e, 
    0x3, 0x4e, 0x3, 0x4e, 0x3, 0x4e, 0x3, 0x4f, 0x3, 0x4f, 0x3, 0x4f, 0x3, 
    0x50, 0x3, 0x50, 0x3, 0x51, 0x3, 0x51, 0x3, 0x51, 0x3, 0x52, 0x3, 0x52, 
    0x3, 0x52, 0x3, 0x52, 0x3, 0x53, 0x3, 0x53, 0x3, 0x53, 0x3, 0x53, 0x3, 
    0x54, 0x3, 0x54, 0x3, 0x54, 0x3, 0x54, 0x3, 0x55, 0x3, 0x55, 0x3, 0x55, 
    0x3, 0x55, 0x3, 0x55, 0x3, 0x56, 0x3, 0x56, 0x3, 0x56, 0x3, 0x56, 0x3, 
    0x57, 0x3, 0x57, 0x3, 0x57, 0x3, 0x57, 0x3, 0x58, 0x3, 0x58, 0x3, 0x58, 
    0x3, 0x58, 0x5, 0x58, 0x301, 0xa, 0x58, 0x3, 0x59, 0x3, 0x59, 0x3, 0x59, 
    0x3, 0x5a, 0x7, 0x5a, 0x307, 0xa, 0x5a, 0xc, 0x5a, 0xe, 0x5a, 0x30a, 
    0xb, 0x5a, 0x3, 0x5b, 0x3, 0x5b, 0x3, 0x5b, 0x3, 0x5c, 0x7, 0x5c, 0x310, 
    0xa, 0x5c, 0xc, 0x5c, 0xe, 0x5c, 0x313, 0xb, 0x5c, 0x3, 0x5d, 0x3, 0x5d, 
    0x3, 0x5d, 0x3, 0x5e, 0x7, 0x5e, 0x319, 0xa, 0x5e, 0xc, 0x5e, 0xe, 0x5e, 
    0x31c, 0xb, 0x5e, 0x3, 0x5f, 0x3, 0x5f, 0x3, 0x60, 0x5, 0x60, 0x321, 
    0xa, 0x60, 0x3, 0x61, 0x3, 0x61, 0x3, 0x61, 0x3, 0x62, 0x7, 0x62, 0x327, 
    0xa, 0x62, 0xc, 0x62, 0xe, 0x62, 0x32a, 0xb, 0x62, 0x3, 0x63, 0x5, 0x63, 
    0x32d, 0xa, 0x63, 0x3, 0x64, 0x3, 0x64, 0x3, 0x64, 0x3, 0x64, 0x3, 0x65, 
    0x5, 0x65, 0x334, 0xa, 0x65, 0x3, 0x66, 0x3, 0x66, 0x3, 0x66, 0x3, 0x67, 
    0x7, 0x67, 0x33a, 0xa, 0x67, 0xc, 0x67, 0xe, 0x67, 0x33d, 0xb, 0x67, 
    0x3, 0x68, 0x3, 0x68, 0x3, 0x68, 0x3, 0x69, 0x7, 0x69, 0x343, 0xa, 0x69, 
    0xc, 0x69, 0xe, 0x69, 0x346, 0xb, 0x69, 0x3, 0x6a, 0x3, 0x6a, 0x3, 0x6a, 
    0x3, 0x6b, 0x7, 0x6b, 0x34c, 0xa, 0x6b, 0xc, 0x6b, 0xe, 0x6b, 0x34f, 
    0xb, 0x6b, 0x3, 0x6c, 0x5, 0x6c, 0x352, 0xa, 0x6c, 0x3, 0x6d, 0x5, 0x6d, 
    0x355, 0xa, 0x6d, 0x3, 0x6e, 0x3, 0x6e, 0x3, 0x6e, 0x3, 0x6f, 0x7, 0x6f, 
    0x35b, 0xa, 0x6f, 0xc, 0x6f, 0xe, 0x6f, 0x35e, 0xb, 0x6f, 0x3, 0x70, 
    0x3, 0x70, 0x3, 0x70, 0x3, 0x71, 0x5, 0x71, 0x364, 0xa, 0x71, 0x3, 0x72, 
    0x5, 0x72, 0x367, 0xa, 0x72, 0x3, 0x73, 0x3, 0x73, 0x5, 0x73, 0x36b, 
    0xa, 0x73, 0x3, 0x74, 0x3, 0x74, 0x3, 0x75, 0x5, 0x75, 0x370, 0xa, 0x75, 
    0x3, 0x76, 0x5, 0x76, 0x373, 0xa, 0x76, 0x3, 0x77, 0x5, 0x77, 0x376, 
    0xa, 0x77, 0x3, 0x78, 0x3, 0x78, 0x3, 0x78, 0x3, 0x79, 0x5, 0x79, 0x37c, 
    0xa, 0x79, 0x3, 0x7a, 0x3, 0x7a, 0x3, 0x7a, 0x3, 0x7b, 0x5, 0x7b, 0x382, 
    0xa, 0x7b, 0x3, 0x7c, 0x5, 0x7c, 0x385, 0xa, 0x7c, 0x3, 0x7d, 0x7, 0x7d, 
    0x388, 0xa, 0x7d, 0xc, 0x7d, 0xe, 0x7d, 0x38b, 0xb, 0x7d, 0x3, 0x7e, 
    0x7, 0x7e, 0x38e, 0xa, 0x7e, 0xc, 0x7e, 0xe, 0x7e, 0x391, 0xb, 0x7e, 
    0x3, 0x7f, 0x3, 0x7f, 0x3, 0x7f, 0x3, 0x80, 0x5, 0x80, 0x397, 0xa, 0x80, 
    0x3, 0x81, 0x3, 0x81, 0x3, 0x81, 0x3, 0x82, 0x7, 0x82, 0x39d, 0xa, 0x82, 
    0xc, 0x82, 0xe, 0x82, 0x3a0, 0xb, 0x82, 0x3, 0x83, 0x7, 0x83, 0x3a3, 
    0xa, 0x83, 0xc, 0x83, 0xe, 0x83, 0x3a6, 0xb, 0x83, 0x3, 0x84, 0x3, 0x84, 
    0x5, 0x84, 0x3aa, 0xa, 0x84, 0x3, 0x85, 0x5, 0x85, 0x3ad, 0xa, 0x85, 
    0x3, 0x86, 0x3, 0x86, 0x3, 0x86, 0x5, 0x86, 0x3b2, 0xa, 0x86, 0x3, 0x87, 
    0x5, 0x87, 0x3b5, 0xa, 0x87, 0x3, 0x88, 0x5, 0x88, 0x3b8, 0xa, 0x88, 
    0x3, 0x89, 0x3, 0x89, 0x3, 0x89, 0x3, 0x8a, 0x7, 0x8a, 0x3be, 0xa, 0x8a, 
    0xc, 0x8a, 0xe, 0x8a, 0x3c1, 0xb, 0x8a, 0x3, 0x8b, 0x3, 0x8b, 0x3, 0x8b, 
    0x3, 0x8c, 0x7, 0x8c, 0x3c7, 0xa, 0x8c, 0xc, 0x8c, 0xe, 0x8c, 0x3ca, 
    0xb, 0x8c, 0x3, 0x8d, 0x5, 0x8d, 0x3cd, 0xa, 0x8d, 0x3, 0x8e, 0x3, 0x8e, 
    0x3, 0x8e, 0x3, 0x8e, 0x3, 0x8f, 0x5, 0x8f, 0x3d4, 0xa, 0x8f, 0x3, 0x90, 
    0x5, 0x90, 0x3d7, 0xa, 0x90, 0x3, 0x91, 0x5, 0x91, 0x3da, 0xa, 0x91, 
    0x3, 0x92, 0x5, 0x92, 0x3dd, 0xa, 0x92, 0x3, 0x93, 0x3, 0x93, 0x3, 0x93, 
    0x3, 0x94, 0x5, 0x94, 0x3e3, 0xa, 0x94, 0x3, 0x95, 0x3, 0x95, 0x3, 0x95, 
    0x3, 0x96, 0x7, 0x96, 0x3e9, 0xa, 0x96, 0xc, 0x96, 0xe, 0x96, 0x3ec, 
    0xb, 0x96, 0x3, 0x97, 0x3, 0x97, 0x3, 0x97, 0x3, 0x98, 0x5, 0x98, 0x3f2, 
    0xa, 0x98, 0x3, 0x99, 0x3, 0x99, 0x3, 0x99, 0x3, 0x9a, 0x7, 0x9a, 0x3f8, 
    0xa, 0x9a, 0xc, 0x9a, 0xe, 0x9a, 0x3fb, 0xb, 0x9a, 0x3, 0x9b, 0x5, 0x9b, 
    0x3fe, 0xa, 0x9b, 0x3, 0x9c, 0x5, 0x9c, 0x401, 0xa, 0x9c, 0x3, 0x9d, 
    0x3, 0x9d, 0x3, 0x9d, 0x3, 0x9e, 0x5, 0x9e, 0x407, 0xa, 0x9e, 0x3, 0x9f, 
    0x3, 0x9f, 0x3, 0x9f, 0x3, 0x9f, 0x3, 0xa0, 0x5, 0xa0, 0x40e, 0xa, 0xa0, 
    0x3, 0xa1, 0x3, 0xa1, 0x3, 0xa1, 0x3, 0xa2, 0x7, 0xa2, 0x414, 0xa, 0xa2, 
    0xc, 0xa2, 0xe, 0xa2, 0x417, 0xb, 0xa2, 0x3, 0xa3, 0x3, 0xa3, 0x3, 0xa3, 
    0x3, 0xa4, 0x3, 0xa4, 0x3, 0xa4, 0x3, 0xa4, 0x3, 0xa4, 0x5, 0xa4, 0x421, 
    0xa, 0xa4, 0x3, 0xa5, 0x7, 0xa5, 0x424, 0xa, 0xa5, 0xc, 0xa5, 0xe, 0xa5, 
    0x427, 0xb, 0xa5, 0x3, 0xa6, 0x3, 0xa6, 0x3, 0xa6, 0x3, 0xa7, 0x5, 0xa7, 
    0x42d, 0xa, 0xa7, 0x3, 0xa8, 0x3, 0xa8, 0x3, 0xa9, 0x3, 0xa9, 0x3, 0xa9, 
    0x3, 0xa9, 0x3, 0xa9, 0x3, 0xa9, 0x3, 0xa9, 0x3, 0xa9, 0x3, 0xa9, 0x3, 
    0xa9, 0x5, 0xa9, 0x43b, 0xa, 0xa9, 0x3, 0xaa, 0x3, 0xaa, 0x3, 0xaa, 
    0x3, 0xaa, 0x3, 0xaa, 0x3, 0xaa, 0x3, 0xaa, 0x3, 0xaa, 0x3, 0xaa, 0x3, 
    0xaa, 0x3, 0xaa, 0x3, 0xaa, 0x3, 0xaa, 0x3, 0xaa, 0x3, 0xaa, 0x3, 0xaa, 
    0x5, 0xaa, 0x44d, 0xa, 0xaa, 0x3, 0xab, 0x3, 0xab, 0x5, 0xab, 0x451, 
    0xa, 0xab, 0x3, 0xac, 0x3, 0xac, 0x5, 0xac, 0x455, 0xa, 0xac, 0x3, 0xad, 
    0x3, 0xad, 0x5, 0xad, 0x459, 0xa, 0xad, 0x3, 0xae, 0x3, 0xae, 0x5, 0xae, 
    0x45d, 0xa, 0xae, 0x3, 0xaf, 0x3, 0xaf, 0x5, 0xaf, 0x461, 0xa, 0xaf, 
    0x3, 0xb0, 0x3, 0xb0, 0x3, 0xb1, 0x3, 0xb1, 0x5, 0xb1, 0x467, 0xa, 0xb1, 
    0x3, 0xb2, 0x3, 0xb2, 0x5, 0xb2, 0x46b, 0xa, 0xb2, 0x3, 0xb3, 0x3, 0xb3, 
    0x5, 0xb3, 0x46f, 0xa, 0xb3, 0x3, 0xb4, 0x3, 0xb4, 0x3, 0xb5, 0x3, 0xb5, 
    0x5, 0xb5, 0x475, 0xa, 0xb5, 0x3, 0xb6, 0x3, 0xb6, 0x3, 0xb6, 0x3, 0xb6, 
    0x3, 0xb7, 0x3, 0xb7, 0x3, 0xb7, 0x5, 0xb7, 0x47e, 0xa, 0xb7, 0x3, 0xb8, 
    0x3, 0xb8, 0x5, 0xb8, 0x482, 0xa, 0xb8, 0x3, 0xb9, 0x3, 0xb9, 0x5, 0xb9, 
    0x486, 0xa, 0xb9, 0x3, 0xba, 0x5, 0xba, 0x489, 0xa, 0xba, 0x3, 0xbb, 
    0x3, 0xbb, 0x5, 0xbb, 0x48d, 0xa, 0xbb, 0x3, 0xbc, 0x3, 0xbc, 0x3, 0xbc, 
    0x3, 0xbc, 0x3, 0xbc, 0x3, 0xbc, 0x3, 0xbc, 0x3, 0xbc, 0x3, 0xbc, 0x3, 
    0xbc, 0x3, 0xbc, 0x3, 0xbc, 0x3, 0xbc, 0x3, 0xbc, 0x5, 0xbc, 0x49d, 
    0xa, 0xbc, 0x3, 0xbd, 0x3, 0xbd, 0x3, 0xbd, 0x3, 0xbd, 0x3, 0xbd, 0x3, 
    0xbe, 0x3, 0xbe, 0x3, 0xbe, 0x3, 0xbf, 0x3, 0xbf, 0x3, 0xbf, 0x3, 0xc0, 
    0x3, 0xc0, 0x3, 0xc0, 0x3, 0xc1, 0x3, 0xc1, 0x3, 0xc1, 0x3, 0xc1, 0x3, 
    0xc2, 0x3, 0xc2, 0x3, 0xc2, 0x3, 0xc3, 0x3, 0xc3, 0x3, 0xc3, 0x3, 0xc3, 
    0x3, 0xc3, 0x3, 0xc4, 0x3, 0xc4, 0x3, 0xc5, 0x3, 0xc5, 0x3, 0xc6, 0x3, 
    0xc6, 0x3, 0xc6, 0x3, 0xc7, 0x3, 0xc7, 0x3, 0xc7, 0x3, 0xc8, 0x3, 0xc8, 
    0x3, 0xc8, 0x3, 0xc9, 0x3, 0xc9, 0x3, 0xc9, 0x3, 0xca, 0x3, 0xca, 0x3, 
    0xca, 0x3, 0xca, 0x3, 0xcb, 0x3, 0xcb, 0x3, 0xcb, 0x3, 0xcb, 0x3, 0xcc, 
    0x3, 0xcc, 0x3, 0xcc, 0x3, 0xcc, 0x3, 0xcd, 0x3, 0xcd, 0x3, 0xcd, 0x3, 
    0xcd, 0x3, 0xce, 0x3, 0xce, 0x3, 0xce, 0x3, 0xce, 0x3, 0xcf, 0x3, 0xcf, 
    0x3, 0xcf, 0x3, 0xd0, 0x3, 0xd0, 0x3, 0xd0, 0x3, 0xd1, 0x3, 0xd1, 0x3, 
    0xd1, 0x3, 0xd2, 0x3, 0xd2, 0x3, 0xd2, 0x3, 0xd3, 0x3, 0xd3, 0x3, 0xd3, 
    0x3, 0xd4, 0x3, 0xd4, 0x3, 0xd4, 0x3, 0xd5, 0x3, 0xd5, 0x3, 0xd5, 0x3, 
    0xd5, 0x3, 0xd6, 0x3, 0xd6, 0x3, 0xd6, 0x3, 0xd6, 0x3, 0xd6, 0x2, 0x2, 
    0xd7, 0x2, 0x4, 0x6, 0x8, 0xa, 0xc, 0xe, 0x10, 0x12, 0x14, 0x16, 0x18, 
    0x1a, 0x1c, 0x1e, 0x20, 0x22, 0x24, 0x26, 0x28, 0x2a, 0x2c, 0x2e, 0x30, 
    0x32, 0x34, 0x36, 0x38, 0x3a, 0x3c, 0x3e, 0x40, 0x42, 0x44, 0x46, 0x48, 
    0x4a, 0x4c, 0x4e, 0x50, 0x52, 0x54, 0x56, 0x58, 0x5a, 0x5c, 0x5e, 0x60, 
    0x62, 0x64, 0x66, 0x68, 0x6a, 0x6c, 0x6e, 0x70, 0x72, 0x74, 0x76, 0x78, 
    0x7a, 0x7c, 0x7e, 0x80, 0x82, 0x84, 0x86, 0x88, 0x8a, 0x8c, 0x8e, 0x90, 
    0x92, 0x94, 0x96, 0x98, 0x9a, 0x9c, 0x9e, 0xa0, 0xa2, 0xa4, 0xa6, 0xa8, 
    0xaa, 0xac, 0xae, 0xb0, 0xb2, 0xb4, 0xb6, 0xb8, 0xba, 0xbc, 0xbe, 0xc0, 
    0xc2, 0xc4, 0xc6, 0xc8, 0xca, 0xcc, 0xce, 0xd0, 0xd2, 0xd4, 0xd6, 0xd8, 
    0xda, 0xdc, 0xde, 0xe0, 0xe2, 0xe4, 0xe6, 0xe8, 0xea, 0xec, 0xee, 0xf0, 
    0xf2, 0xf4, 0xf6, 0xf8, 0xfa, 0xfc, 0xfe, 0x100, 0x102, 0x104, 0x106, 
    0x108, 0x10a, 0x10c, 0x10e, 0x110, 0x112, 0x114, 0x116, 0x118, 0x11a, 
    0x11c, 0x11e, 0x120, 0x122, 0x124, 0x126, 0x128, 0x12a, 0x12c, 0x12e, 
    0x130, 0x132, 0x134, 0x136, 0x138, 0x13a, 0x13c, 0x13e, 0x140, 0x142, 
    0x144, 0x146, 0x148, 0x14a, 0x14c, 0x14e, 0x150, 0x152, 0x154, 0x156, 
    0x158, 0x15a, 0x15c, 0x15e, 0x160, 0x162, 0x164, 0x166, 0x168, 0x16a, 
    0x16c, 0x16e, 0x170, 0x172, 0x174, 0x176, 0x178, 0x17a, 0x17c, 0x17e, 
    0x180, 0x182, 0x184, 0x186, 0x188, 0x18a, 0x18c, 0x18e, 0x190, 0x192, 
    0x194, 0x196, 0x198, 0x19a, 0x19c, 0x19e, 0x1a0, 0x1a2, 0x1a4, 0x1a6, 
    0x1a8, 0x1aa, 0x2, 0x8, 0x3, 0x2, 0x48, 0x49, 0x4, 0x2, 0x1d, 0x1d, 
    0x28, 0x28, 0x4, 0x2, 0x35, 0x3a, 0x3c, 0x40, 0x4, 0x2, 0x2d, 0x3a, 
    0x3c, 0x40, 0x3, 0x2, 0x29, 0x2a, 0x3, 0x2, 0x3b, 0x41, 0x2, 0x4a8, 
    0x2, 0x1ae, 0x3, 0x2, 0x2, 0x2, 0x4, 0x1b0, 0x3, 0x2, 0x2, 0x2, 0x6, 
    0x1b3, 0x3, 0x2, 0x2, 0x2, 0x8, 0x1b6, 0x3, 0x2, 0x2, 0x2, 0xa, 0x1b9, 
    0x3, 0x2, 0x2, 0x2, 0xc, 0x1be, 0x3, 0x2, 0x2, 0x2, 0xe, 0x1c0, 0x3, 
    0x2, 0x2, 0x2, 0x10, 0x1c3, 0x3, 0x2, 0x2, 0x2, 0x12, 0x1c6, 0x3, 0x2, 
    0x2, 0x2, 0x14, 0x1c9, 0x3, 0x2, 0x2, 0x2, 0x16, 0x1cc, 0x3, 0x2, 0x2, 
    0x2, 0x18, 0x1cf, 0x3, 0x2, 0x2, 0x2, 0x1a, 0x1d3, 0x3, 0x2, 0x2, 0x2, 
    0x1c, 0x1d8, 0x3, 0x2, 0x2, 0x2, 0x1e, 0x1de, 0x3, 0x2, 0x2, 0x2, 0x20, 
    0x1e0, 0x3, 0x2, 0x2, 0x2, 0x22, 0x1e3, 0x3, 0x2, 0x2, 0x2, 0x24, 0x1e6, 
    0x3, 0x2, 0x2, 0x2, 0x26, 0x1eb, 0x3, 0x2, 0x2, 0x2, 0x28, 0x1f0, 0x3, 
    0x2, 0x2, 0x2, 0x2a, 0x1f3, 0x3, 0x2, 0x2, 0x2, 0x2c, 0x1fa, 0x3, 0x2, 
    0x2, 0x2, 0x2e, 0x1fc, 0x3, 0x2, 0x2, 0x2, 0x30, 0x1fe, 0x3, 0x2, 0x2, 
    0x2, 0x32, 0x202, 0x3, 0x2, 0x2, 0x2, 0x34, 0x205, 0x3, 0x2, 0x2, 0x2, 
    0x36, 0x209, 0x3, 0x2, 0x2, 0x2, 0x38, 0x20c, 0x3, 0x2, 0x2, 0x2, 0x3a, 
    0x210, 0x3, 0x2, 0x2, 0x2, 0x3c, 0x214, 0x3, 0x2, 0x2, 0x2, 0x3e, 0x217, 
    0x3, 0x2, 0x2, 0x2, 0x40, 0x21a, 0x3, 0x2, 0x2, 0x2, 0x42, 0x21d, 0x3, 
    0x2, 0x2, 0x2, 0x44, 0x220, 0x3, 0x2, 0x2, 0x2, 0x46, 0x222, 0x3, 0x2, 
    0x2, 0x2, 0x48, 0x225, 0x3, 0x2, 0x2, 0x2, 0x4a, 0x22b, 0x3, 0x2, 0x2, 
    0x2, 0x4c, 0x232, 0x3, 0x2, 0x2, 0x2, 0x4e, 0x238, 0x3, 0x2, 0x2, 0x2, 
    0x50, 0x23a, 0x3, 0x2, 0x2, 0x2, 0x52, 0x241, 0x3, 0x2, 0x2, 0x2, 0x54, 
    0x248, 0x3, 0x2, 0x2, 0x2, 0x56, 0x24e, 0x3, 0x2, 0x2, 0x2, 0x58, 0x250, 
    0x3, 0x2, 0x2, 0x2, 0x5a, 0x253, 0x3, 0x2, 0x2, 0x2, 0x5c, 0x258, 0x3, 
    0x2, 0x2, 0x2, 0x5e, 0x25e, 0x3, 0x2, 0x2, 0x2, 0x60, 0x260, 0x3, 0x2, 
    0x2, 0x2, 0x62, 0x263, 0x3, 0x2, 0x2, 0x2, 0x64, 0x267, 0x3, 0x2, 0x2, 
    0x2, 0x66, 0x26d, 0x3, 0x2, 0x2, 0x2, 0x68, 0x271, 0x3, 0x2, 0x2, 0x2, 
    0x6a, 0x276, 0x3, 0x2, 0x2, 0x2, 0x6c, 0x278, 0x3, 0x2, 0x2, 0x2, 0x6e, 
    0x27d, 0x3, 0x2, 0x2, 0x2, 0x70, 0x27f, 0x3, 0x2, 0x2, 0x2, 0x72, 0x282, 
    0x3, 0x2, 0x2, 0x2, 0x74, 0x287, 0x3, 0x2, 0x2, 0x2, 0x76, 0x28b, 0x3, 
    0x2, 0x2, 0x2, 0x78, 0x291, 0x3, 0x2, 0x2, 0x2, 0x7a, 0x296, 0x3, 0x2, 
    0x2, 0x2, 0x7c, 0x298, 0x3, 0x2, 0x2, 0x2, 0x7e, 0x29b, 0x3, 0x2, 0x2, 
    0x2, 0x80, 0x2a0, 0x3, 0x2, 0x2, 0x2, 0x82, 0x2a2, 0x3, 0x2, 0x2, 0x2, 
    0x84, 0x2a6, 0x3, 0x2, 0x2, 0x2, 0x86, 0x2ac, 0x3, 0x2, 0x2, 0x2, 0x88, 
    0x2ae, 0x3, 0x2, 0x2, 0x2, 0x8a, 0x2b4, 0x3, 0x2, 0x2, 0x2, 0x8c, 0x2b8, 
    0x3, 0x2, 0x2, 0x2, 0x8e, 0x2c1, 0x3, 0x2, 0x2, 0x2, 0x90, 0x2c3, 0x3, 
    0x2, 0x2, 0x2, 0x92, 0x2c7, 0x3, 0x2, 0x2, 0x2, 0x94, 0x2ca, 0x3, 0x2, 
    0x2, 0x2, 0x96, 0x2d0, 0x3, 0x2, 0x2, 0x2, 0x98, 0x2d4, 0x3, 0x2, 0x2, 
    0x2, 0x9a, 0x2d6, 0x3, 0x2, 0x2, 0x2, 0x9c, 0x2db, 0x3, 0x2, 0x2, 0x2, 
    0x9e, 0x2de, 0x3, 0x2, 0x2, 0x2, 0xa0, 0x2e0, 0x3, 0x2, 0x2, 0x2, 0xa2, 
    0x2e3, 0x3, 0x2, 0x2, 0x2, 0xa4, 0x2e7, 0x3, 0x2, 0x2, 0x2, 0xa6, 0x2eb, 
    0x3, 0x2, 0x2, 0x2, 0xa8, 0x2ef, 0x3, 0x2, 0x2, 0x2, 0xaa, 0x2f4, 0x3, 
    0x2, 0x2, 0x2, 0xac, 0x2f8, 0x3, 0x2, 0x2, 0x2, 0xae, 0x300, 0x3, 0x2, 
    0x2, 0x2, 0xb0, 0x302, 0x3, 0x2, 0x2, 0x2, 0xb2, 0x308, 0x3, 0x2, 0x2, 
    0x2, 0xb4, 0x30b, 0x3, 0x2, 0x2, 0x2, 0xb6, 0x311, 0x3, 0x2, 0x2, 0x2, 
    0xb8, 0x314, 0x3, 0x2, 0x2, 0x2, 0xba, 0x31a, 0x3, 0x2, 0x2, 0x2, 0xbc, 
    0x31d, 0x3, 0x2, 0x2, 0x2, 0xbe, 0x320, 0x3, 0x2, 0x2, 0x2, 0xc0, 0x322, 
    0x3, 0x2, 0x2, 0x2, 0xc2, 0x328, 0x3, 0x2, 0x2, 0x2, 0xc4, 0x32c, 0x3, 
    0x2, 0x2, 0x2, 0xc6, 0x32e, 0x3, 0x2, 0x2, 0x2, 0xc8, 0x333, 0x3, 0x2, 
    0x2, 0x2, 0xca, 0x335, 0x3, 0x2, 0x2, 0x2, 0xcc, 0x33b, 0x3, 0x2, 0x2, 
    0x2, 0xce, 0x33e, 0x3, 0x2, 0x2, 0x2, 0xd0, 0x344, 0x3, 0x2, 0x2, 0x2, 
    0xd2, 0x347, 0x3, 0x2, 0x2, 0x2, 0xd4, 0x34d, 0x3, 0x2, 0x2, 0x2, 0xd6, 
    0x351, 0x3, 0x2, 0x2, 0x2, 0xd8, 0x354, 0x3, 0x2, 0x2, 0x2, 0xda, 0x356, 
    0x3, 0x2, 0x2, 0x2, 0xdc, 0x35c, 0x3, 0x2, 0x2, 0x2, 0xde, 0x35f, 0x3, 
    0x2, 0x2, 0x2, 0xe0, 0x363, 0x3, 0x2, 0x2, 0x2, 0xe2, 0x366, 0x3, 0x2, 
    0x2, 0x2, 0xe4, 0x36a, 0x3, 0x2, 0x2, 0x2, 0xe6, 0x36c, 0x3, 0x2, 0x2, 
    0x2, 0xe8, 0x36f, 0x3, 0x2, 0x2, 0x2, 0xea, 0x372, 0x3, 0x2, 0x2, 0x2, 
    0xec, 0x375, 0x3, 0x2, 0x2, 0x2, 0xee, 0x377, 0x3, 0x2, 0x2, 0x2, 0xf0, 
    0x37b, 0x3, 0x2, 0x2, 0x2, 0xf2, 0x37d, 0x3, 0x2, 0x2, 0x2, 0xf4, 0x381, 
    0x3, 0x2, 0x2, 0x2, 0xf6, 0x384, 0x3, 0x2, 0x2, 0x2, 0xf8, 0x389, 0x3, 
    0x2, 0x2, 0x2, 0xfa, 0x38f, 0x3, 0x2, 0x2, 0x2, 0xfc, 0x392, 0x3, 0x2, 
    0x2, 0x2, 0xfe, 0x396, 0x3, 0x2, 0x2, 0x2, 0x100, 0x398, 0x3, 0x2, 0x2, 
    0x2, 0x102, 0x39e, 0x3, 0x2, 0x2, 0x2, 0x104, 0x3a4, 0x3, 0x2, 0x2, 
    0x2, 0x106, 0x3a9, 0x3, 0x2, 0x2, 0x2, 0x108, 0x3ac, 0x3, 0x2, 0x2, 
    0x2, 0x10a, 0x3b1, 0x3, 0x2, 0x2, 0x2, 0x10c, 0x3b4, 0x3, 0x2, 0x2, 
    0x2, 0x10e, 0x3b7, 0x3, 0x2, 0x2, 0x2, 0x110, 0x3b9, 0x3, 0x2, 0x2, 
    0x2, 0x112, 0x3bf, 0x3, 0x2, 0x2, 0x2, 0x114, 0x3c2, 0x3, 0x2, 0x2, 
    0x2, 0x116, 0x3c8, 0x3, 0x2, 0x2, 0x2, 0x118, 0x3cc, 0x3, 0x2, 0x2, 
    0x2, 0x11a, 0x3ce, 0x3, 0x2, 0x2, 0x2, 0x11c, 0x3d3, 0x3, 0x2, 0x2, 
    0x2, 0x11e, 0x3d6, 0x3, 0x2, 0x2, 0x2, 0x120, 0x3d9, 0x3, 0x2, 0x2, 
    0x2, 0x122, 0x3dc, 0x3, 0x2, 0x2, 0x2, 0x124, 0x3de, 0x3, 0x2, 0x2, 
    0x2, 0x126, 0x3e2, 0x3, 0x2, 0x2, 0x2, 0x128, 0x3e4, 0x3, 0x2, 0x2, 
    0x2, 0x12a, 0x3ea, 0x3, 0x2, 0x2, 0x2, 0x12c, 0x3ed, 0x3, 0x2, 0x2, 
    0x2, 0x12e, 0x3f1, 0x3, 0x2, 0x2, 0x2, 0x130, 0x3f3, 0x3, 0x2, 0x2, 
    0x2, 0x132, 0x3f9, 0x3, 0x2, 0x2, 0x2, 0x134, 0x3fd, 0x3, 0x2, 0x2, 
    0x2, 0x136, 0x400, 0x3, 0x2, 0x2, 0x2, 0x138, 0x402, 0x3, 0x2, 0x2, 
    0x2, 0x13a, 0x406, 0x3, 0x2, 0x2, 0x2, 0x13c, 0x408, 0x3, 0x2, 0x2, 
    0x2, 0x13e, 0x40d, 0x3, 0x2, 0x2, 0x2, 0x140, 0x40f, 0x3, 0x2, 0x2, 
    0x2, 0x142, 0x415, 0x3, 0x2, 0x2, 0x2, 0x144, 0x418, 0x3, 0x2, 0x2, 
    0x2, 0x146, 0x420, 0x3, 0x2, 0x2, 0x2, 0x148, 0x425, 0x3, 0x2, 0x2, 
    0x2, 0x14a, 0x428, 0x3, 0x2, 0x2, 0x2, 0x14c, 0x42c, 0x3, 0x2, 0x2, 
    0x2, 0x14e, 0x42e, 0x3, 0x2, 0x2, 0x2, 0x150, 0x43a, 0x3, 0x2, 0x2, 
    0x2, 0x152, 0x44c, 0x3, 0x2, 0x2, 0x2, 0x154, 0x450, 0x3, 0x2, 0x2, 
    0x2, 0x156, 0x454, 0x3, 0x2, 0x2, 0x2, 0x158, 0x458, 0x3, 0x2, 0x2, 
    0x2, 0x15a, 0x45c, 0x3, 0x2, 0x2, 0x2, 0x15c, 0x460, 0x3, 0x2, 0x2, 
    0x2, 0x15e, 0x462, 0x3, 0x2, 0x2, 0x2, 0x160, 0x466, 0x3, 0x2, 0x2, 
    0x2, 0x162, 0x46a, 0x3, 0x2, 0x2, 0x2, 0x164, 0x46e, 0x3, 0x2, 0x2, 
    0x2, 0x166, 0x470, 0x3, 0x2, 0x2, 0x2, 0x168, 0x474, 0x3, 0x2, 0x2, 
    0x2, 0x16a, 0x476, 0x3, 0x2, 0x2, 0x2, 0x16c, 0x47d, 0x3, 0x2, 0x2, 
    0x2, 0x16e, 0x481, 0x3, 0x2, 0x2, 0x2, 0x170, 0x485, 0x3, 0x2, 0x2, 
    0x2, 0x172, 0x488, 0x3, 0x2, 0x2, 0x2, 0x174, 0x48c, 0x3, 0x2, 0x2, 
    0x2, 0x176, 0x49c, 0x3, 0x2, 0x2, 0x2, 0x178, 0x49e, 0x3, 0x2, 0x2, 
    0x2, 0x17a, 0x4a3, 0x3, 0x2, 0x2, 0x2, 0x17c, 0x4a6, 0x3, 0x2, 0x2, 
    0x2, 0x17e, 0x4a9, 0x3, 0x2, 0x2, 0x2, 0x180, 0x4ac, 0x3, 0x2, 0x2, 
    0x2, 0x182, 0x4b0, 0x3, 0x2, 0x2, 0x2, 0x184, 0x4b3, 0x3, 0x2, 0x2, 
    0x2, 0x186, 0x4b8, 0x3, 0x2, 0x2, 0x2, 0x188, 0x4ba, 0x3, 0x2, 0x2, 
    0x2, 0x18a, 0x4bc, 0x3, 0x2, 0x2, 0x2, 0x18c, 0x4bf, 0x3, 0x2, 0x2, 
    0x2, 0x18e, 0x4c2, 0x3, 0x2, 0x2, 0x2, 0x190, 0x4c5, 0x3, 0x2, 0x2, 
    0x2, 0x192, 0x4c8, 0x3, 0x2, 0x2, 0x2, 0x194, 0x4cc, 0x3, 0x2, 0x2, 
    0x2, 0x196, 0x4d0, 0x3, 0x2, 0x2, 0x2, 0x198, 0x4d4, 0x3, 0x2, 0x2, 
    0x2, 0x19a, 0x4d8, 0x3, 0x2, 0x2, 0x2, 0x19c, 0x4dc, 0x3, 0x2, 0x2, 
    0x2, 0x19e, 0x4df, 0x3, 0x2, 0x2, 0x2, 0x1a0, 0x4e2, 0x3, 0x2, 0x2, 
    0x2, 0x1a2, 0x4e5, 0x3, 0x2, 0x2, 0x2, 0x1a4, 0x4e8, 0x3, 0x2, 0x2, 
    0x2, 0x1a6, 0x4eb, 0x3, 0x2, 0x2, 0x2, 0x1a8, 0x4ee, 0x3, 0x2, 0x2, 
    0x2, 0x1aa, 0x4f2, 0x3, 0x2, 0x2, 0x2, 0x1ac, 0x1af, 0x5, 0x178, 0xbd, 
    0x2, 0x1ad, 0x1af, 0x7, 0x2, 0x2, 0x3, 0x1ae, 0x1ac, 0x3, 0x2, 0x2, 
    0x2, 0x1ae, 0x1ad, 0x3, 0x2, 0x2, 0x2, 0x1af, 0x3, 0x3, 0x2, 0x2, 0x2, 
    0x1b0, 0x1b1, 0x7, 0x10, 0x2, 0x2, 0x1b1, 0x1b2, 0x7, 0x1d, 0x2, 0x2, 
    0x1b2, 0x5, 0x3, 0x2, 0x2, 0x2, 0x1b3, 0x1b4, 0x7, 0x19, 0x2, 0x2, 0x1b4, 
    0x1b5, 0x5, 0x154, 0xab, 0x2, 0x1b5, 0x7, 0x3, 0x2, 0x2, 0x2, 0x1b6, 
    0x1b7, 0x5, 0xbe, 0x60, 0x2, 0x1b7, 0x1b8, 0x5, 0xa, 0x6, 0x2, 0x1b8, 
    0x9, 0x3, 0x2, 0x2, 0x2, 0x1b9, 0x1ba, 0x5, 0x9e, 0x50, 0x2, 0x1ba, 
    0xb, 0x3, 0x2, 0x2, 0x2, 0x1bb, 0x1bf, 0x5, 0xe, 0x8, 0x2, 0x1bc, 0x1bf, 
    0x5, 0x16, 0xc, 0x2, 0x1bd, 0x1bf, 0x5, 0x20, 0x11, 0x2, 0x1be, 0x1bb, 
    0x3, 0x2, 0x2, 0x2, 0x1be, 0x1bc, 0x3, 0x2, 0x2, 0x2, 0x1be, 0x1bd, 
    0x3, 0x2, 0x2, 0x2, 0x1bf, 0xd, 0x3, 0x2, 0x2, 0x2, 0x1c0, 0x1c1, 0x7, 
    0x12, 0x2, 0x2, 0x1c1, 0x1c2, 0x5, 0x156, 0xac, 0x2, 0x1c2, 0xf, 0x3, 
    0x2, 0x2, 0x2, 0x1c3, 0x1c4, 0x5, 0x12, 0xa, 0x2, 0x1c4, 0x1c5, 0x5, 
    0xc8, 0x65, 0x2, 0x1c5, 0x11, 0x3, 0x2, 0x2, 0x2, 0x1c6, 0x1c7, 0x7, 
    0x1d, 0x2, 0x2, 0x1c7, 0x1c8, 0x5, 0xcc, 0x67, 0x2, 0x1c8, 0x13, 0x3, 
    0x2, 0x2, 0x2, 0x1c9, 0x1ca, 0x5, 0x144, 0xa3, 0x2, 0x1ca, 0x1cb, 0x5, 
    0xd0, 0x69, 0x2, 0x1cb, 0x15, 0x3, 0x2, 0x2, 0x2, 0x1cc, 0x1cd, 0x7, 
    0x16, 0x2, 0x2, 0x1cd, 0x1ce, 0x5, 0x158, 0xad, 0x2, 0x1ce, 0x17, 0x3, 
    0x2, 0x2, 0x2, 0x1cf, 0x1d0, 0x7, 0x1d, 0x2, 0x2, 0x1d0, 0x1d1, 0x5, 
    0xd6, 0x6c, 0x2, 0x1d1, 0x1d2, 0x5, 0x150, 0xa9, 0x2, 0x1d2, 0x19, 0x3, 
    0x2, 0x2, 0x2, 0x1d3, 0x1d4, 0x7, 0x5, 0x2, 0x2, 0x1d4, 0x1d5, 0x7, 
    0x1d, 0x2, 0x2, 0x1d5, 0x1d6, 0x5, 0x7e, 0x40, 0x2, 0x1d6, 0x1d7, 0x5, 
    0xd8, 0x6d, 0x2, 0x1d7, 0x1b, 0x3, 0x2, 0x2, 0x2, 0x1d8, 0x1d9, 0x7, 
    0x5, 0x2, 0x2, 0x1d9, 0x1da, 0x5, 0x1e, 0x10, 0x2, 0x1da, 0x1db, 0x7, 
    0x1d, 0x2, 0x2, 0x1db, 0x1dc, 0x5, 0x7e, 0x40, 0x2, 0x1dc, 0x1dd, 0x5, 
    0xd8, 0x6d, 0x2, 0x1dd, 0x1d, 0x3, 0x2, 0x2, 0x2, 0x1de, 0x1df, 0x5, 
    0x82, 0x42, 0x2, 0x1df, 0x1f, 0x3, 0x2, 0x2, 0x2, 0x1e0, 0x1e1, 0x7, 
    0x1b, 0x2, 0x2, 0x1e1, 0x1e2, 0x5, 0x15a, 0xae, 0x2, 0x1e2, 0x21, 0x3, 
    0x2, 0x2, 0x2, 0x1e3, 0x1e4, 0x5, 0x12, 0xa, 0x2, 0x1e4, 0x1e5, 0x5, 
    0x15c, 0xaf, 0x2, 0x1e5, 0x23, 0x3, 0x2, 0x2, 0x2, 0x1e6, 0x1e7, 0x7, 
    0x20, 0x2, 0x2, 0x1e7, 0x1e8, 0x5, 0xe2, 0x72, 0x2, 0x1e8, 0x1e9, 0x7, 
    0x21, 0x2, 0x2, 0x1e9, 0x25, 0x3, 0x2, 0x2, 0x2, 0x1ea, 0x1ec, 0x5, 
    0xe4, 0x73, 0x2, 0x1eb, 0x1ea, 0x3, 0x2, 0x2, 0x2, 0x1ec, 0x1ed, 0x3, 
    0x2, 0x2, 0x2, 0x1ed, 0x1eb, 0x3, 0x2, 0x2, 0x2, 0x1ed, 0x1ee, 0x3, 
    0x2, 0x2, 0x2, 0x1ee, 0x27, 0x3, 0x2, 0x2, 0x2, 0x1ef, 0x1f1, 0x5, 0x152, 
    0xaa, 0x2, 0x1f0, 0x1ef, 0x3, 0x2, 0x2, 0x2, 0x1f0, 0x1f1, 0x3, 0x2, 
    0x2, 0x2, 0x1f1, 0x29, 0x3, 0x2, 0x2, 0x2, 0x1f2, 0x1f4, 0x5, 0x2c, 
    0x17, 0x2, 0x1f3, 0x1f2, 0x3, 0x2, 0x2, 0x2, 0x1f3, 0x1f4, 0x3, 0x2, 
    0x2, 0x2, 0x1f4, 0x2b, 0x3, 0x2, 0x2, 0x2, 0x1f5, 0x1fb, 0x5, 0x30, 
    0x19, 0x2, 0x1f6, 0x1fb, 0x5, 0x34, 0x1b, 0x2, 0x1f7, 0x1fb, 0x5, 0x2e, 
    0x18, 0x2, 0x1f8, 0x1fb, 0x5, 0x32, 0x1a, 0x2, 0x1f9, 0x1fb, 0x5, 0x38, 
    0x1d, 0x2, 0x1fa, 0x1f5, 0x3, 0x2, 0x2, 0x2, 0x1fa, 0x1f6, 0x3, 0x2, 
    0x2, 0x2, 0x1fa, 0x1f7, 0x3, 0x2, 0x2, 0x2, 0x1fa, 0x1f8, 0x3, 0x2, 
    0x2, 0x2, 0x1fa, 0x1f9, 0x3, 0x2, 0x2, 0x2, 0x1fb, 0x2d, 0x3, 0x2, 0x2, 
    0x2, 0x1fc, 0x1fd, 0x5, 0x144, 0xa3, 0x2, 0x1fd, 0x2f, 0x3, 0x2, 0x2, 
    0x2, 0x1fe, 0x1ff, 0x5, 0x144, 0xa3, 0x2, 0x1ff, 0x200, 0x7, 0x41, 0x2, 
    0x2, 0x200, 0x201, 0x5, 0x144, 0xa3, 0x2, 0x201, 0x31, 0x3, 0x2, 0x2, 
    0x2, 0x202, 0x203, 0x5, 0x144, 0xa3, 0x2, 0x203, 0x204, 0x5, 0x15e, 
    0xb0, 0x2, 0x204, 0x33, 0x3, 0x2, 0x2, 0x2, 0x205, 0x206, 0x5, 0x14, 
    0xb, 0x2, 0x206, 0x207, 0x5, 0x36, 0x1c, 0x2, 0x207, 0x208, 0x5, 0x14, 
    0xb, 0x2, 0x208, 0x35, 0x3, 0x2, 0x2, 0x2, 0x209, 0x20a, 0x5, 0xe8, 
    0x75, 0x2, 0x20a, 0x20b, 0x7, 0x24, 0x2, 0x2, 0x20b, 0x37, 0x3, 0x2, 
    0x2, 0x2, 0x20c, 0x20d, 0x5, 0x12, 0xa, 0x2, 0x20d, 0x20e, 0x7, 0x2b, 
    0x2, 0x2, 0x20e, 0x20f, 0x5, 0x14, 0xb, 0x2, 0x20f, 0x39, 0x3, 0x2, 
    0x2, 0x2, 0x210, 0x211, 0x7, 0x1d, 0x2, 0x2, 0x211, 0x212, 0x7, 0x27, 
    0x2, 0x2, 0x212, 0x213, 0x5, 0x28, 0x15, 0x2, 0x213, 0x3b, 0x3, 0x2, 
    0x2, 0x2, 0x214, 0x215, 0x7, 0x1a, 0x2, 0x2, 0x215, 0x216, 0x5, 0xea, 
    0x76, 0x2, 0x216, 0x3d, 0x3, 0x2, 0x2, 0x2, 0x217, 0x218, 0x7, 0x3, 
    0x2, 0x2, 0x218, 0x219, 0x5, 0xec, 0x77, 0x2, 0x219, 0x3f, 0x3, 0x2, 
    0x2, 0x2, 0x21a, 0x21b, 0x7, 0x17, 0x2, 0x2, 0x21b, 0x21c, 0x5, 0xec, 
    0x77, 0x2, 0x21c, 0x41, 0x3, 0x2, 0x2, 0x2, 0x21d, 0x21e, 0x7, 0xf, 
    0x2, 0x2, 0x21e, 0x21f, 0x7, 0x1d, 0x2, 0x2, 0x21f, 0x43, 0x3, 0x2, 
    0x2, 0x2, 0x220, 0x221, 0x7, 0x13, 0x2, 0x2, 0x221, 0x45, 0x3, 0x2, 
    0x2, 0x2, 0x222, 0x223, 0x7, 0x9, 0x2, 0x2, 0x223, 0x224, 0x5, 0x144, 
    0xa3, 0x2, 0x224, 0x47, 0x3, 0x2, 0x2, 0x2, 0x225, 0x226, 0x7, 0x14, 
    0x2, 0x2, 0x226, 0x227, 0x5, 0xf0, 0x79, 0x2, 0x227, 0x228, 0x5, 0x144, 
    0xa3, 0x2, 0x228, 0x229, 0x5, 0x24, 0x13, 0x2, 0x229, 0x22a, 0x5, 0xf4, 
    0x7b, 0x2, 0x22a, 0x49, 0x3, 0x2, 0x2, 0x2, 0x22b, 0x22c, 0x7, 0x11, 
    0x2, 0x2, 0x22c, 0x22d, 0x5, 0xf0, 0x79, 0x2, 0x22d, 0x22e, 0x5, 0xf6, 
    0x7c, 0x2, 0x22e, 0x22f, 0x7, 0x20, 0x2, 0x2, 0x22f, 0x230, 0x5, 0xf8, 
    0x7d, 0x2, 0x230, 0x231, 0x7, 0x21, 0x2, 0x2, 0x231, 0x4b, 0x3, 0x2, 
    0x2, 0x2, 0x232, 0x233, 0x5, 0x4e, 0x28, 0x2, 0x233, 0x234, 0x7, 0x27, 
    0x2, 0x2, 0x234, 0x235, 0x5, 0xe2, 0x72, 0x2, 0x235, 0x4d, 0x3, 0x2, 
    0x2, 0x2, 0x236, 0x239, 0x5, 0x17a, 0xbe, 0x2, 0x237, 0x239, 0x7, 0x4, 
    0x2, 0x2, 0x238, 0x236, 0x3, 0x2, 0x2, 0x2, 0x238, 0x237, 0x3, 0x2, 
    0x2, 0x2, 0x239, 0x4f, 0x3, 0x2, 0x2, 0x2, 0x23a, 0x23b, 0x7, 0x11, 
    0x2, 0x2, 0x23b, 0x23c, 0x5, 0xf0, 0x79, 0x2, 0x23c, 0x23d, 0x5, 0x52, 
    0x2a, 0x2, 0x23d, 0x23e, 0x7, 0x20, 0x2, 0x2, 0x23e, 0x23f, 0x5, 0xfa, 
    0x7e, 0x2, 0x23f, 0x240, 0x7, 0x21, 0x2, 0x2, 0x240, 0x51, 0x3, 0x2, 
    0x2, 0x2, 0x241, 0x242, 0x5, 0xfe, 0x80, 0x2, 0x242, 0x243, 0x5, 0x14a, 
    0xa6, 0x2, 0x243, 0x244, 0x7, 0x28, 0x2, 0x2, 0x244, 0x245, 0x7, 0x1e, 
    0x2, 0x2, 0x245, 0x246, 0x7, 0x16, 0x2, 0x2, 0x246, 0x247, 0x7, 0x1f, 
    0x2, 0x2, 0x247, 0x53, 0x3, 0x2, 0x2, 0x2, 0x248, 0x249, 0x5, 0x56, 
    0x2c, 0x2, 0x249, 0x24a, 0x7, 0x27, 0x2, 0x2, 0x24a, 0x24b, 0x5, 0xe2, 
    0x72, 0x2, 0x24b, 0x55, 0x3, 0x2, 0x2, 0x2, 0x24c, 0x24f, 0x5, 0x17c, 
    0xbf, 0x2, 0x24d, 0x24f, 0x7, 0x4, 0x2, 0x2, 0x24e, 0x24c, 0x3, 0x2, 
    0x2, 0x2, 0x24e, 0x24d, 0x3, 0x2, 0x2, 0x2, 0x24f, 0x57, 0x3, 0x2, 0x2, 
    0x2, 0x250, 0x251, 0x5, 0x160, 0xb1, 0x2, 0x251, 0x252, 0x5, 0x102, 
    0x82, 0x2, 0x252, 0x59, 0x3, 0x2, 0x2, 0x2, 0x253, 0x254, 0x7, 0x7, 
    0x2, 0x2, 0x254, 0x255, 0x7, 0x20, 0x2, 0x2, 0x255, 0x256, 0x5, 0x104, 
    0x83, 0x2, 0x256, 0x257, 0x7, 0x21, 0x2, 0x2, 0x257, 0x5b, 0x3, 0x2, 
    0x2, 0x2, 0x258, 0x259, 0x5, 0x5e, 0x30, 0x2, 0x259, 0x25a, 0x7, 0x27, 
    0x2, 0x2, 0x25a, 0x25b, 0x5, 0xe2, 0x72, 0x2, 0x25b, 0x5d, 0x3, 0x2, 
    0x2, 0x2, 0x25c, 0x25f, 0x5, 0x17e, 0xc0, 0x2, 0x25d, 0x25f, 0x7, 0x4, 
    0x2, 0x2, 0x25e, 0x25c, 0x3, 0x2, 0x2, 0x2, 0x25e, 0x25d, 0x3, 0x2, 
    0x2, 0x2, 0x25f, 0x5f, 0x3, 0x2, 0x2, 0x2, 0x260, 0x261, 0x5, 0x108, 
    0x85, 0x2, 0x261, 0x262, 0x5, 0x144, 0xa3, 0x2, 0x262, 0x61, 0x3, 0x2, 
    0x2, 0x2, 0x263, 0x264, 0x7, 0x18, 0x2, 0x2, 0x264, 0x265, 0x5, 0x10c, 
    0x87, 0x2, 0x265, 0x266, 0x5, 0x24, 0x13, 0x2, 0x266, 0x63, 0x3, 0x2, 
    0x2, 0x2, 0x267, 0x268, 0x5, 0x10e, 0x88, 0x2, 0x268, 0x269, 0x7, 0x26, 
    0x2, 0x2, 0x269, 0x26a, 0x5, 0xf6, 0x7c, 0x2, 0x26a, 0x26b, 0x7, 0x26, 
    0x2, 0x2, 0x26b, 0x26c, 0x5, 0x10e, 0x88, 0x2, 0x26c, 0x65, 0x3, 0x2, 
    0x2, 0x2, 0x26d, 0x26e, 0x5, 0x108, 0x85, 0x2, 0x26e, 0x26f, 0x7, 0x15, 
    0x2, 0x2, 0x26f, 0x270, 0x5, 0x144, 0xa3, 0x2, 0x270, 0x67, 0x3, 0x2, 
    0x2, 0x2, 0x271, 0x272, 0x7, 0xa, 0x2, 0x2, 0x272, 0x273, 0x5, 0x144, 
    0xa3, 0x2, 0x273, 0x69, 0x3, 0x2, 0x2, 0x2, 0x274, 0x277, 0x7, 0x1d, 
    0x2, 0x2, 0x275, 0x277, 0x5, 0x8a, 0x46, 0x2, 0x276, 0x274, 0x3, 0x2, 
    0x2, 0x2, 0x276, 0x275, 0x3, 0x2, 0x2, 0x2, 0x277, 0x6b, 0x3, 0x2, 0x2, 
    0x2, 0x278, 0x279, 0x7, 0x22, 0x2, 0x2, 0x279, 0x27a, 0x5, 0x2e, 0x18, 
    0x2, 0x27a, 0x27b, 0x7, 0x23, 0x2, 0x2, 0x27b, 0x27c, 0x5, 0x6e, 0x38, 
    0x2, 0x27c, 0x6d, 0x3, 0x2, 0x2, 0x2, 0x27d, 0x27e, 0x5, 0x150, 0xa9, 
    0x2, 0x27e, 0x6f, 0x3, 0x2, 0x2, 0x2, 0x27f, 0x280, 0x7, 0x3f, 0x2, 
    0x2, 0x280, 0x281, 0x5, 0x150, 0xa9, 0x2, 0x281, 0x71, 0x3, 0x2, 0x2, 
    0x2, 0x282, 0x283, 0x7, 0x6, 0x2, 0x2, 0x283, 0x284, 0x7, 0x20, 0x2, 
    0x2, 0x284, 0x285, 0x5, 0x112, 0x8a, 0x2, 0x285, 0x286, 0x7, 0x21, 0x2, 
    0x2, 0x286, 0x73, 0x3, 0x2, 0x2, 0x2, 0x287, 0x288, 0x7, 0x22, 0x2, 
    0x2, 0x288, 0x289, 0x7, 0x23, 0x2, 0x2, 0x289, 0x28a, 0x5, 0x6e, 0x38, 
    0x2, 0x28a, 0x75, 0x3, 0x2, 0x2, 0x2, 0x28b, 0x28c, 0x7, 0xb, 0x2, 0x2, 
    0x28c, 0x28d, 0x7, 0x22, 0x2, 0x2, 0x28d, 0x28e, 0x5, 0x150, 0xa9, 0x2, 
    0x28e, 0x28f, 0x7, 0x23, 0x2, 0x2, 0x28f, 0x290, 0x5, 0x6e, 0x38, 0x2, 
    0x290, 0x77, 0x3, 0x2, 0x2, 0x2, 0x291, 0x292, 0x5, 0x164, 0xb3, 0x2, 
    0x292, 0x293, 0x5, 0x6e, 0x38, 0x2, 0x293, 0x79, 0x3, 0x2, 0x2, 0x2, 
    0x294, 0x297, 0x5, 0x180, 0xc1, 0x2, 0x295, 0x297, 0x5, 0x6a, 0x36, 
    0x2, 0x296, 0x294, 0x3, 0x2, 0x2, 0x2, 0x296, 0x295, 0x3, 0x2, 0x2, 
    0x2, 0x297, 0x7b, 0x3, 0x2, 0x2, 0x2, 0x298, 0x299, 0x7, 0x5, 0x2, 0x2, 
    0x299, 0x29a, 0x5, 0x7e, 0x40, 0x2, 0x29a, 0x7d, 0x3, 0x2, 0x2, 0x2, 
    0x29b, 0x29c, 0x5, 0x82, 0x42, 0x2, 0x29c, 0x29d, 0x5, 0x14c, 0xa7, 
    0x2, 0x29d, 0x7f, 0x3, 0x2, 0x2, 0x2, 0x29e, 0x2a1, 0x5, 0x82, 0x42, 
    0x2, 0x29f, 0x2a1, 0x5, 0x150, 0xa9, 0x2, 0x2a0, 0x29e, 0x3, 0x2, 0x2, 
    0x2, 0x2a0, 0x29f, 0x3, 0x2, 0x2, 0x2, 0x2a1, 0x81, 0x3, 0x2, 0x2, 0x2, 
    0x2a2, 0x2a3, 0x7, 0x1e, 0x2, 0x2, 0x2a3, 0x2a4, 0x5, 0x11c, 0x8f, 0x2, 
    0x2a4, 0x2a5, 0x7, 0x1f, 0x2, 0x2, 0x2a5, 0x83, 0x3, 0x2, 0x2, 0x2, 
    0x2a6, 0x2a7, 0x5, 0x11e, 0x90, 0x2, 0x2a7, 0x2a8, 0x5, 0x120, 0x91, 
    0x2, 0x2a8, 0x2a9, 0x5, 0x150, 0xa9, 0x2, 0x2a9, 0x85, 0x3, 0x2, 0x2, 
    0x2, 0x2aa, 0x2ad, 0x5, 0x14a, 0xa6, 0x2, 0x2ab, 0x2ad, 0x5, 0x182, 
    0xc2, 0x2, 0x2ac, 0x2aa, 0x3, 0x2, 0x2, 0x2, 0x2ac, 0x2ab, 0x3, 0x2, 
    0x2, 0x2, 0x2ad, 0x87, 0x3, 0x2, 0x2, 0x2, 0x2ae, 0x2af, 0x5, 0x150, 
    0xa9, 0x2, 0x2af, 0x2b0, 0x7, 0x1e, 0x2, 0x2, 0x2b0, 0x2b1, 0x5, 0x144, 
    0xa3, 0x2, 0x2b1, 0x2b2, 0x5, 0x122, 0x92, 0x2, 0x2b2, 0x2b3, 0x7, 0x1f, 
    0x2, 0x2, 0x2b3, 0x89, 0x3, 0x2, 0x2, 0x2, 0x2b4, 0x2b5, 0x7, 0x1d, 
    0x2, 0x2, 0x2b5, 0x2b6, 0x7, 0x28, 0x2, 0x2, 0x2b6, 0x2b7, 0x7, 0x1d, 
    0x2, 0x2, 0x2b7, 0x8b, 0x3, 0x2, 0x2, 0x2, 0x2b8, 0x2b9, 0x5, 0x8e, 
    0x48, 0x2, 0x2b9, 0x2ba, 0x5, 0x90, 0x49, 0x2, 0x2ba, 0x8d, 0x3, 0x2, 
    0x2, 0x2, 0x2bb, 0x2c2, 0x5, 0x9a, 0x4e, 0x2, 0x2bc, 0x2c2, 0x5, 0x6c, 
    0x37, 0x2, 0x2bd, 0x2c2, 0x5, 0x184, 0xc3, 0x2, 0x2be, 0x2c2, 0x5, 0x74, 
    0x3b, 0x2, 0x2bf, 0x2c2, 0x5, 0x76, 0x3c, 0x2, 0x2c0, 0x2c2, 0x5, 0x6a, 
    0x36, 0x2, 0x2c1, 0x2bb, 0x3, 0x2, 0x2, 0x2, 0x2c1, 0x2bc, 0x3, 0x2, 
    0x2, 0x2, 0x2c1, 0x2bd, 0x3, 0x2, 0x2, 0x2, 0x2c1, 0x2be, 0x3, 0x2, 
    0x2, 0x2, 0x2c1, 0x2bf, 0x3, 0x2, 0x2, 0x2, 0x2c1, 0x2c0, 0x3, 0x2, 
    0x2, 0x2, 0x2c2, 0x8f, 0x3, 0x2, 0x2, 0x2, 0x2c3, 0x2c4, 0x7, 0x20, 
    0x2, 0x2, 0x2c4, 0x2c5, 0x5, 0x126, 0x94, 0x2, 0x2c5, 0x2c6, 0x7, 0x21, 
    0x2, 0x2, 0x2c6, 0x91, 0x3, 0x2, 0x2, 0x2, 0x2c7, 0x2c8, 0x5, 0x94, 
    0x4b, 0x2, 0x2c8, 0x2c9, 0x5, 0x12a, 0x96, 0x2, 0x2c9, 0x93, 0x3, 0x2, 
    0x2, 0x2, 0x2ca, 0x2cb, 0x5, 0x12e, 0x98, 0x2, 0x2cb, 0x2cc, 0x5, 0x98, 
    0x4d, 0x2, 0x2cc, 0x95, 0x3, 0x2, 0x2, 0x2, 0x2cd, 0x2d1, 0x7, 0x1d, 
    0x2, 0x2, 0x2ce, 0x2d1, 0x5, 0x144, 0xa3, 0x2, 0x2cf, 0x2d1, 0x5, 0x90, 
    0x49, 0x2, 0x2d0, 0x2cd, 0x3, 0x2, 0x2, 0x2, 0x2d0, 0x2ce, 0x3, 0x2, 
    0x2, 0x2, 0x2d0, 0x2cf, 0x3, 0x2, 0x2, 0x2, 0x2d1, 0x97, 0x3, 0x2, 0x2, 
    0x2, 0x2d2, 0x2d5, 0x5, 0x144, 0xa3, 0x2, 0x2d3, 0x2d5, 0x5, 0x90, 0x49, 
    0x2, 0x2d4, 0x2d2, 0x3, 0x2, 0x2, 0x2, 0x2d4, 0x2d3, 0x3, 0x2, 0x2, 
    0x2, 0x2d5, 0x99, 0x3, 0x2, 0x2, 0x2, 0x2d6, 0x2d7, 0x7, 0xc, 0x2, 0x2, 
    0x2d7, 0x2d8, 0x7, 0x20, 0x2, 0x2, 0x2d8, 0x2d9, 0x5, 0x132, 0x9a, 0x2, 
    0x2d9, 0x2da, 0x7, 0x21, 0x2, 0x2, 0x2da, 0x9b, 0x3, 0x2, 0x2, 0x2, 
    0x2db, 0x2dc, 0x5, 0x168, 0xb5, 0x2, 0x2dc, 0x2dd, 0x5, 0x134, 0x9b, 
    0x2, 0x2dd, 0x9d, 0x3, 0x2, 0x2, 0x2, 0x2de, 0x2df, 0x9, 0x2, 0x2, 0x2, 
    0x2df, 0x9f, 0x3, 0x2, 0x2, 0x2, 0x2e0, 0x2e1, 0x5, 0x136, 0x9c, 0x2, 
    0x2e1, 0x2e2, 0x5, 0x6a, 0x36, 0x2, 0x2e2, 0xa1, 0x3, 0x2, 0x2, 0x2, 
    0x2e3, 0x2e4, 0x7, 0x5, 0x2, 0x2, 0x2e4, 0x2e5, 0x5, 0x7e, 0x40, 0x2, 
    0x2e5, 0x2e6, 0x5, 0x24, 0x13, 0x2, 0x2e6, 0xa3, 0x3, 0x2, 0x2, 0x2, 
    0x2e7, 0x2e8, 0x7, 0x22, 0x2, 0x2, 0x2e8, 0x2e9, 0x5, 0x144, 0xa3, 0x2, 
    0x2e9, 0x2ea, 0x7, 0x23, 0x2, 0x2, 0x2ea, 0xa5, 0x3, 0x2, 0x2, 0x2, 
    0x2eb, 0x2ec, 0x7, 0x22, 0x2, 0x2, 0x2ec, 0x2ed, 0x5, 0x16a, 0xb6, 0x2, 
    0x2ed, 0x2ee, 0x7, 0x23, 0x2, 0x2, 0x2ee, 0xa7, 0x3, 0x2, 0x2, 0x2, 
    0x2ef, 0x2f0, 0x7, 0x28, 0x2, 0x2, 0x2f0, 0x2f1, 0x7, 0x1e, 0x2, 0x2, 
    0x2f1, 0x2f2, 0x5, 0x150, 0xa9, 0x2, 0x2f2, 0x2f3, 0x7, 0x1f, 0x2, 0x2, 
    0x2f3, 0xa9, 0x3, 0x2, 0x2, 0x2, 0x2f4, 0x2f5, 0x7, 0x1e, 0x2, 0x2, 
    0x2f5, 0x2f6, 0x5, 0x13e, 0xa0, 0x2, 0x2f6, 0x2f7, 0x7, 0x1f, 0x2, 0x2, 
    0x2f7, 0xab, 0x3, 0x2, 0x2, 0x2, 0x2f8, 0x2f9, 0x5, 0x6e, 0x38, 0x2, 
    0x2f9, 0x2fa, 0x7, 0x28, 0x2, 0x2, 0x2fa, 0x2fb, 0x7, 0x1d, 0x2, 0x2, 
    0x2fb, 0xad, 0x3, 0x2, 0x2, 0x2, 0x2fc, 0x301, 0x7, 0x26, 0x2, 0x2, 
    0x2fd, 0x301, 0x7, 0x2, 0x2, 0x3, 0x2fe, 0x301, 0x5, 0x186, 0xc4, 0x2, 
    0x2ff, 0x301, 0x5, 0x188, 0xc5, 0x2, 0x300, 0x2fc, 0x3, 0x2, 0x2, 0x2, 
    0x300, 0x2fd, 0x3, 0x2, 0x2, 0x2, 0x300, 0x2fe, 0x3, 0x2, 0x2, 0x2, 
    0x300, 0x2ff, 0x3, 0x2, 0x2, 0x2, 0x301, 0xaf, 0x3, 0x2, 0x2, 0x2, 0x302, 
    0x303, 0x5, 0x6, 0x4, 0x2, 0x303, 0x304, 0x5, 0xae, 0x58, 0x2, 0x304, 
    0xb1, 0x3, 0x2, 0x2, 0x2, 0x305, 0x307, 0x5, 0xb0, 0x59, 0x2, 0x306, 
    0x305, 0x3, 0x2, 0x2, 0x2, 0x307, 0x30a, 0x3, 0x2, 0x2, 0x2, 0x308, 
    0x306, 0x3, 0x2, 0x2, 0x2, 0x308, 0x309, 0x3, 0x2, 0x2, 0x2, 0x309, 
    0xb3, 0x3, 0x2, 0x2, 0x2, 0x30a, 0x308, 0x3, 0x2, 0x2, 0x2, 0x30b, 0x30c, 
    0x5, 0x16c, 0xb7, 0x2, 0x30c, 0x30d, 0x5, 0xae, 0x58, 0x2, 0x30d, 0xb5, 
    0x3, 0x2, 0x2, 0x2, 0x30e, 0x310, 0x5, 0xb4, 0x5b, 0x2, 0x30f, 0x30e, 
    0x3, 0x2, 0x2, 0x2, 0x310, 0x313, 0x3, 0x2, 0x2, 0x2, 0x311, 0x30f, 
    0x3, 0x2, 0x2, 0x2, 0x311, 0x312, 0x3, 0x2, 0x2, 0x2, 0x312, 0xb7, 0x3, 
    0x2, 0x2, 0x2, 0x313, 0x311, 0x3, 0x2, 0x2, 0x2, 0x314, 0x315, 0x5, 
    0x8, 0x5, 0x2, 0x315, 0x316, 0x5, 0xae, 0x58, 0x2, 0x316, 0xb9, 0x3, 
    0x2, 0x2, 0x2, 0x317, 0x319, 0x5, 0xb8, 0x5d, 0x2, 0x318, 0x317, 0x3, 
    0x2, 0x2, 0x2, 0x319, 0x31c, 0x3, 0x2, 0x2, 0x2, 0x31a, 0x318, 0x3, 
    0x2, 0x2, 0x2, 0x31a, 0x31b, 0x3, 0x2, 0x2, 0x2, 0x31b, 0xbb, 0x3, 0x2, 
    0x2, 0x2, 0x31c, 0x31a, 0x3, 0x2, 0x2, 0x2, 0x31d, 0x31e, 0x9, 0x3, 
    0x2, 0x2, 0x31e, 0xbd, 0x3, 0x2, 0x2, 0x2, 0x31f, 0x321, 0x5, 0xbc, 
    0x5f, 0x2, 0x320, 0x31f, 0x3, 0x2, 0x2, 0x2, 0x320, 0x321, 0x3, 0x2, 
    0x2, 0x2, 0x321, 0xbf, 0x3, 0x2, 0x2, 0x2, 0x322, 0x323, 0x5, 0x10, 
    0x9, 0x2, 0x323, 0x324, 0x5, 0xae, 0x58, 0x2, 0x324, 0xc1, 0x3, 0x2, 
    0x2, 0x2, 0x325, 0x327, 0x5, 0xc0, 0x61, 0x2, 0x326, 0x325, 0x3, 0x2, 
    0x2, 0x2, 0x327, 0x32a, 0x3, 0x2, 0x2, 0x2, 0x328, 0x326, 0x3, 0x2, 
    0x2, 0x2, 0x328, 0x329, 0x3, 0x2, 0x2, 0x2, 0x329, 0xc3, 0x3, 0x2, 0x2, 
    0x2, 0x32a, 0x328, 0x3, 0x2, 0x2, 0x2, 0x32b, 0x32d, 0x5, 0x150, 0xa9, 
    0x2, 0x32c, 0x32b, 0x3, 0x2, 0x2, 0x2, 0x32c, 0x32d, 0x3, 0x2, 0x2, 
    0x2, 0x32d, 0xc5, 0x3, 0x2, 0x2, 0x2, 0x32e, 0x32f, 0x5, 0xc4, 0x63, 
    0x2, 0x32f, 0x330, 0x7, 0x24, 0x2, 0x2, 0x330, 0x331, 0x5, 0x14, 0xb, 
    0x2, 0x331, 0xc7, 0x3, 0x2, 0x2, 0x2, 0x332, 0x334, 0x5, 0xc6, 0x64, 
    0x2, 0x333, 0x332, 0x3, 0x2, 0x2, 0x2, 0x333, 0x334, 0x3, 0x2, 0x2, 
    0x2, 0x334, 0xc9, 0x3, 0x2, 0x2, 0x2, 0x335, 0x336, 0x7, 0x25, 0x2, 
    0x2, 0x336, 0x337, 0x7, 0x1d, 0x2, 0x2, 0x337, 0xcb, 0x3, 0x2, 0x2, 
    0x2, 0x338, 0x33a, 0x5, 0xca, 0x66, 0x2, 0x339, 0x338, 0x3, 0x2, 0x2, 
    0x2, 0x33a, 0x33d, 0x3, 0x2, 0x2, 0x2, 0x33b, 0x339, 0x3, 0x2, 0x2, 
    0x2, 0x33b, 0x33c, 0x3, 0x2, 0x2, 0x2, 0x33c, 0xcd, 0x3, 0x2, 0x2, 0x2, 
    0x33d, 0x33b, 0x3, 0x2, 0x2, 0x2, 0x33e, 0x33f, 0x7, 0x25, 0x2, 0x2, 
    0x33f, 0x340, 0x5, 0x144, 0xa3, 0x2, 0x340, 0xcf, 0x3, 0x2, 0x2, 0x2, 
    0x341, 0x343, 0x5, 0xce, 0x68, 0x2, 0x342, 0x341, 0x3, 0x2, 0x2, 0x2, 
    0x343, 0x346, 0x3, 0x2, 0x2, 0x2, 0x344, 0x342, 0x3, 0x2, 0x2, 0x2, 
    0x344, 0x345, 0x3, 0x2, 0x2, 0x2, 0x345, 0xd1, 0x3, 0x2, 0x2, 0x2, 0x346, 
    0x344, 0x3, 0x2, 0x2, 0x2, 0x347, 0x348, 0x5, 0x18, 0xd, 0x2, 0x348, 
    0x349, 0x5, 0xae, 0x58, 0x2, 0x349, 0xd3, 0x3, 0x2, 0x2, 0x2, 0x34a, 
    0x34c, 0x5, 0xd2, 0x6a, 0x2, 0x34b, 0x34a, 0x3, 0x2, 0x2, 0x2, 0x34c, 
    0x34f, 0x3, 0x2, 0x2, 0x2, 0x34d, 0x34b, 0x3, 0x2, 0x2, 0x2, 0x34d, 
    0x34e, 0x3, 0x2, 0x2, 0x2, 0x34e, 0xd5, 0x3, 0x2, 0x2, 0x2, 0x34f, 0x34d, 
    0x3, 0x2, 0x2, 0x2, 0x350, 0x352, 0x7, 0x24, 0x2, 0x2, 0x351, 0x350, 
    0x3, 0x2, 0x2, 0x2, 0x351, 0x352, 0x3, 0x2, 0x2, 0x2, 0x352, 0xd7, 0x3, 
    0x2, 0x2, 0x2, 0x353, 0x355, 0x5, 0x24, 0x13, 0x2, 0x354, 0x353, 0x3, 
    0x2, 0x2, 0x2, 0x354, 0x355, 0x3, 0x2, 0x2, 0x2, 0x355, 0xd9, 0x3, 0x2, 
    0x2, 0x2, 0x356, 0x357, 0x5, 0x22, 0x12, 0x2, 0x357, 0x358, 0x5, 0xae, 
    0x58, 0x2, 0x358, 0xdb, 0x3, 0x2, 0x2, 0x2, 0x359, 0x35b, 0x5, 0xda, 
    0x6e, 0x2, 0x35a, 0x359, 0x3, 0x2, 0x2, 0x2, 0x35b, 0x35e, 0x3, 0x2, 
    0x2, 0x2, 0x35c, 0x35a, 0x3, 0x2, 0x2, 0x2, 0x35c, 0x35d, 0x3, 0x2, 
    0x2, 0x2, 0x35d, 0xdd, 0x3, 0x2, 0x2, 0x2, 0x35e, 0x35c, 0x3, 0x2, 0x2, 
    0x2, 0x35f, 0x360, 0x7, 0x24, 0x2, 0x2, 0x360, 0x361, 0x5, 0x14, 0xb, 
    0x2, 0x361, 0xdf, 0x3, 0x2, 0x2, 0x2, 0x362, 0x364, 0x5, 0xde, 0x70, 
    0x2, 0x363, 0x362, 0x3, 0x2, 0x2, 0x2, 0x363, 0x364, 0x3, 0x2, 0x2, 
    0x2, 0x364, 0xe1, 0x3, 0x2, 0x2, 0x2, 0x365, 0x367, 0x5, 0x26, 0x14, 
    0x2, 0x366, 0x365, 0x3, 0x2, 0x2, 0x2, 0x366, 0x367, 0x3, 0x2, 0x2, 
    0x2, 0x367, 0xe3, 0x3, 0x2, 0x2, 0x2, 0x368, 0x36b, 0x5, 0x18a, 0xc6, 
    0x2, 0x369, 0x36b, 0x7, 0x26, 0x2, 0x2, 0x36a, 0x368, 0x3, 0x2, 0x2, 
    0x2, 0x36a, 0x369, 0x3, 0x2, 0x2, 0x2, 0x36b, 0xe5, 0x3, 0x2, 0x2, 0x2, 
    0x36c, 0x36d, 0x9, 0x4, 0x2, 0x2, 0x36d, 0xe7, 0x3, 0x2, 0x2, 0x2, 0x36e, 
    0x370, 0x5, 0xe6, 0x74, 0x2, 0x36f, 0x36e, 0x3, 0x2, 0x2, 0x2, 0x36f, 
    0x370, 0x3, 0x2, 0x2, 0x2, 0x370, 0xe9, 0x3, 0x2, 0x2, 0x2, 0x371, 0x373, 
    0x5, 0x14, 0xb, 0x2, 0x372, 0x371, 0x3, 0x2, 0x2, 0x2, 0x372, 0x373, 
    0x3, 0x2, 0x2, 0x2, 0x373, 0xeb, 0x3, 0x2, 0x2, 0x2, 0x374, 0x376, 0x7, 
    0x1d, 0x2, 0x2, 0x375, 0x374, 0x3, 0x2, 0x2, 0x2, 0x375, 0x376, 0x3, 
    0x2, 0x2, 0x2, 0x376, 0xed, 0x3, 0x2, 0x2, 0x2, 0x377, 0x378, 0x5, 0x2a, 
    0x16, 0x2, 0x378, 0x379, 0x7, 0x26, 0x2, 0x2, 0x379, 0xef, 0x3, 0x2, 
    0x2, 0x2, 0x37a, 0x37c, 0x5, 0xee, 0x78, 0x2, 0x37b, 0x37a, 0x3, 0x2, 
    0x2, 0x2, 0x37b, 0x37c, 0x3, 0x2, 0x2, 0x2, 0x37c, 0xf1, 0x3, 0x2, 0x2, 
    0x2, 0x37d, 0x37e, 0x7, 0xe, 0x2, 0x2, 0x37e, 0x37f, 0x5, 0x16e, 0xb8, 
    0x2, 0x37f, 0xf3, 0x3, 0x2, 0x2, 0x2, 0x380, 0x382, 0x5, 0xf2, 0x7a, 
    0x2, 0x381, 0x380, 0x3, 0x2, 0x2, 0x2, 0x381, 0x382, 0x3, 0x2, 0x2, 
    0x2, 0x382, 0xf5, 0x3, 0x2, 0x2, 0x2, 0x383, 0x385, 0x5, 0x144, 0xa3, 
    0x2, 0x384, 0x383, 0x3, 0x2, 0x2, 0x2, 0x384, 0x385, 0x3, 0x2, 0x2, 
    0x2, 0x385, 0xf7, 0x3, 0x2, 0x2, 0x2, 0x386, 0x388, 0x5, 0x4c, 0x27, 
    0x2, 0x387, 0x386, 0x3, 0x2, 0x2, 0x2, 0x388, 0x38b, 0x3, 0x2, 0x2, 
    0x2, 0x389, 0x387, 0x3, 0x2, 0x2, 0x2, 0x389, 0x38a, 0x3, 0x2, 0x2, 
    0x2, 0x38a, 0xf9, 0x3, 0x2, 0x2, 0x2, 0x38b, 0x389, 0x3, 0x2, 0x2, 0x2, 
    0x38c, 0x38e, 0x5, 0x54, 0x2b, 0x2, 0x38d, 0x38c, 0x3, 0x2, 0x2, 0x2, 
    0x38e, 0x391, 0x3, 0x2, 0x2, 0x2, 0x38f, 0x38d, 0x3, 0x2, 0x2, 0x2, 
    0x38f, 0x390, 0x3, 0x2, 0x2, 0x2, 0x390, 0xfb, 0x3, 0x2, 0x2, 0x2, 0x391, 
    0x38f, 0x3, 0x2, 0x2, 0x2, 0x392, 0x393, 0x7, 0x1d, 0x2, 0x2, 0x393, 
    0x394, 0x7, 0x2b, 0x2, 0x2, 0x394, 0xfd, 0x3, 0x2, 0x2, 0x2, 0x395, 
    0x397, 0x5, 0xfc, 0x7f, 0x2, 0x396, 0x395, 0x3, 0x2, 0x2, 0x2, 0x396, 
    0x397, 0x3, 0x2, 0x2, 0x2, 0x397, 0xff, 0x3, 0x2, 0x2, 0x2, 0x398, 0x399, 
    0x7, 0x25, 0x2, 0x2, 0x399, 0x39a, 0x5, 0x160, 0xb1, 0x2, 0x39a, 0x101, 
    0x3, 0x2, 0x2, 0x2, 0x39b, 0x39d, 0x5, 0x100, 0x81, 0x2, 0x39c, 0x39b, 
    0x3, 0x2, 0x2, 0x2, 0x39d, 0x3a0, 0x3, 0x2, 0x2, 0x2, 0x39e, 0x39c, 
    0x3, 0x2, 0x2, 0x2, 0x39e, 0x39f, 0x3, 0x2, 0x2, 0x2, 0x39f, 0x103, 
    0x3, 0x2, 0x2, 0x2, 0x3a0, 0x39e, 0x3, 0x2, 0x2, 0x2, 0x3a1, 0x3a3, 
    0x5, 0x5c, 0x2f, 0x2, 0x3a2, 0x3a1, 0x3, 0x2, 0x2, 0x2, 0x3a3, 0x3a6, 
    0x3, 0x2, 0x2, 0x2, 0x3a4, 0x3a2, 0x3, 0x2, 0x2, 0x2, 0x3a4, 0x3a5, 
    0x3, 0x2, 0x2, 0x2, 0x3a5, 0x105, 0x3, 0x2, 0x2, 0x2, 0x3a6, 0x3a4, 
    0x3, 0x2, 0x2, 0x2, 0x3a7, 0x3aa, 0x5, 0x18c, 0xc7, 0x2, 0x3a8, 0x3aa, 
    0x5, 0x18e, 0xc8, 0x2, 0x3a9, 0x3a7, 0x3, 0x2, 0x2, 0x2, 0x3a9, 0x3a8, 
    0x3, 0x2, 0x2, 0x2, 0x3aa, 0x107, 0x3, 0x2, 0x2, 0x2, 0x3ab, 0x3ad, 
    0x5, 0x106, 0x84, 0x2, 0x3ac, 0x3ab, 0x3, 0x2, 0x2, 0x2, 0x3ac, 0x3ad, 
    0x3, 0x2, 0x2, 0x2, 0x3ad, 0x109, 0x3, 0x2, 0x2, 0x2, 0x3ae, 0x3b2, 
    0x5, 0x144, 0xa3, 0x2, 0x3af, 0x3b2, 0x5, 0x64, 0x33, 0x2, 0x3b0, 0x3b2, 
    0x5, 0x66, 0x34, 0x2, 0x3b1, 0x3ae, 0x3, 0x2, 0x2, 0x2, 0x3b1, 0x3af, 
    0x3, 0x2, 0x2, 0x2, 0x3b1, 0x3b0, 0x3, 0x2, 0x2, 0x2, 0x3b2, 0x10b, 
    0x3, 0x2, 0x2, 0x2, 0x3b3, 0x3b5, 0x5, 0x10a, 0x86, 0x2, 0x3b4, 0x3b3, 
    0x3, 0x2, 0x2, 0x2, 0x3b4, 0x3b5, 0x3, 0x2, 0x2, 0x2, 0x3b5, 0x10d, 
    0x3, 0x2, 0x2, 0x2, 0x3b6, 0x3b8, 0x5, 0x2a, 0x16, 0x2, 0x3b7, 0x3b6, 
    0x3, 0x2, 0x2, 0x2, 0x3b7, 0x3b8, 0x3, 0x2, 0x2, 0x2, 0x3b8, 0x10f, 
    0x3, 0x2, 0x2, 0x2, 0x3b9, 0x3ba, 0x5, 0x7a, 0x3e, 0x2, 0x3ba, 0x3bb, 
    0x5, 0xae, 0x58, 0x2, 0x3bb, 0x111, 0x3, 0x2, 0x2, 0x2, 0x3bc, 0x3be, 
    0x5, 0x110, 0x89, 0x2, 0x3bd, 0x3bc, 0x3, 0x2, 0x2, 0x2, 0x3be, 0x3c1, 
    0x3, 0x2, 0x2, 0x2, 0x3bf, 0x3bd, 0x3, 0x2, 0x2, 0x2, 0x3bf, 0x3c0, 
    0x3, 0x2, 0x2, 0x2, 0x3c0, 0x113, 0x3, 0x2, 0x2, 0x2, 0x3c1, 0x3bf, 
    0x3, 0x2, 0x2, 0x2, 0x3c2, 0x3c3, 0x7, 0x25, 0x2, 0x2, 0x3c3, 0x3c4, 
    0x5, 0x84, 0x43, 0x2, 0x3c4, 0x115, 0x3, 0x2, 0x2, 0x2, 0x3c5, 0x3c7, 
    0x5, 0x114, 0x8b, 0x2, 0x3c6, 0x3c5, 0x3, 0x2, 0x2, 0x2, 0x3c7, 0x3ca, 
    0x3, 0x2, 0x2, 0x2, 0x3c8, 0x3c6, 0x3, 0x2, 0x2, 0x2, 0x3c8, 0x3c9, 
    0x3, 0x2, 0x2, 0x2, 0x3c9, 0x117, 0x3, 0x2, 0x2, 0x2, 0x3ca, 0x3c8, 
    0x3, 0x2, 0x2, 0x2, 0x3cb, 0x3cd, 0x7, 0x25, 0x2, 0x2, 0x3cc, 0x3cb, 
    0x3, 0x2, 0x2, 0x2, 0x3cc, 0x3cd, 0x3, 0x2, 0x2, 0x2, 0x3cd, 0x119, 
    0x3, 0x2, 0x2, 0x2, 0x3ce, 0x3cf, 0x5, 0x84, 0x43, 0x2, 0x3cf, 0x3d0, 
    0x5, 0x116, 0x8c, 0x2, 0x3d0, 0x3d1, 0x5, 0x118, 0x8d, 0x2, 0x3d1, 0x11b, 
    0x3, 0x2, 0x2, 0x2, 0x3d2, 0x3d4, 0x5, 0x11a, 0x8e, 0x2, 0x3d3, 0x3d2, 
    0x3, 0x2, 0x2, 0x2, 0x3d3, 0x3d4, 0x3, 0x2, 0x2, 0x2, 0x3d4, 0x11d, 
    0x3, 0x2, 0x2, 0x2, 0x3d5, 0x3d7, 0x5, 0x12, 0xa, 0x2, 0x3d6, 0x3d5, 
    0x3, 0x2, 0x2, 0x2, 0x3d6, 0x3d7, 0x3, 0x2, 0x2, 0x2, 0x3d7, 0x11f, 
    0x3, 0x2, 0x2, 0x2, 0x3d8, 0x3da, 0x7, 0x2c, 0x2, 0x2, 0x3d9, 0x3d8, 
    0x3, 0x2, 0x2, 0x2, 0x3d9, 0x3da, 0x3, 0x2, 0x2, 0x2, 0x3da, 0x121, 
    0x3, 0x2, 0x2, 0x2, 0x3db, 0x3dd, 0x7, 0x25, 0x2, 0x2, 0x3dc, 0x3db, 
    0x3, 0x2, 0x2, 0x2, 0x3dc, 0x3dd, 0x3, 0x2, 0x2, 0x2, 0x3dd, 0x123, 
    0x3, 0x2, 0x2, 0x2, 0x3de, 0x3df, 0x5, 0x92, 0x4a, 0x2, 0x3df, 0x3e0, 
    0x5, 0x122, 0x92, 0x2, 0x3e0, 0x125, 0x3, 0x2, 0x2, 0x2, 0x3e1, 0x3e3, 
    0x5, 0x124, 0x93, 0x2, 0x3e2, 0x3e1, 0x3, 0x2, 0x2, 0x2, 0x3e2, 0x3e3, 
    0x3, 0x2, 0x2, 0x2, 0x3e3, 0x127, 0x3, 0x2, 0x2, 0x2, 0x3e4, 0x3e5, 
    0x7, 0x25, 0x2, 0x2, 0x3e5, 0x3e6, 0x5, 0x94, 0x4b, 0x2, 0x3e6, 0x129, 
    0x3, 0x2, 0x2, 0x2, 0x3e7, 0x3e9, 0x5, 0x128, 0x95, 0x2, 0x3e8, 0x3e7, 
    0x3, 0x2, 0x2, 0x2, 0x3e9, 0x3ec, 0x3, 0x2, 0x2, 0x2, 0x3ea, 0x3e8, 
    0x3, 0x2, 0x2, 0x2, 0x3ea, 0x3eb, 0x3, 0x2, 0x2, 0x2, 0x3eb, 0x12b, 
    0x3, 0x2, 0x2, 0x2, 0x3ec, 0x3ea, 0x3, 0x2, 0x2, 0x2, 0x3ed, 0x3ee, 
    0x5, 0x96, 0x4c, 0x2, 0x3ee, 0x3ef, 0x7, 0x27, 0x2, 0x2, 0x3ef, 0x12d, 
    0x3, 0x2, 0x2, 0x2, 0x3f0, 0x3f2, 0x5, 0x12c, 0x97, 0x2, 0x3f1, 0x3f0, 
    0x3, 0x2, 0x2, 0x2, 0x3f1, 0x3f2, 0x3, 0x2, 0x2, 0x2, 0x3f2, 0x12f, 
    0x3, 0x2, 0x2, 0x2, 0x3f3, 0x3f4, 0x5, 0x9c, 0x4f, 0x2, 0x3f4, 0x3f5, 
    0x5, 0xae, 0x58, 0x2, 0x3f5, 0x131, 0x3, 0x2, 0x2, 0x2, 0x3f6, 0x3f8, 
    0x5, 0x130, 0x99, 0x2, 0x3f7, 0x3f6, 0x3, 0x2, 0x2, 0x2, 0x3f8, 0x3fb, 
    0x3, 0x2, 0x2, 0x2, 0x3f9, 0x3f7, 0x3, 0x2, 0x2, 0x2, 0x3f9, 0x3fa, 
    0x3, 0x2, 0x2, 0x2, 0x3fa, 0x133, 0x3, 0x2, 0x2, 0x2, 0x3fb, 0x3f9, 
    0x3, 0x2, 0x2, 0x2, 0x3fc, 0x3fe, 0x5, 0x9e, 0x50, 0x2, 0x3fd, 0x3fc, 
    0x3, 0x2, 0x2, 0x2, 0x3fd, 0x3fe, 0x3, 0x2, 0x2, 0x2, 0x3fe, 0x135, 
    0x3, 0x2, 0x2, 0x2, 0x3ff, 0x401, 0x7, 0x3f, 0x2, 0x2, 0x400, 0x3ff, 
    0x3, 0x2, 0x2, 0x2, 0x400, 0x401, 0x3, 0x2, 0x2, 0x2, 0x401, 0x137, 
    0x3, 0x2, 0x2, 0x2, 0x402, 0x403, 0x7, 0x25, 0x2, 0x2, 0x403, 0x404, 
    0x5, 0x14, 0xb, 0x2, 0x404, 0x139, 0x3, 0x2, 0x2, 0x2, 0x405, 0x407, 
    0x5, 0x138, 0x9d, 0x2, 0x406, 0x405, 0x3, 0x2, 0x2, 0x2, 0x406, 0x407, 
    0x3, 0x2, 0x2, 0x2, 0x407, 0x13b, 0x3, 0x2, 0x2, 0x2, 0x408, 0x409, 
    0x5, 0x170, 0xb9, 0x2, 0x409, 0x40a, 0x5, 0x120, 0x91, 0x2, 0x40a, 0x40b, 
    0x5, 0x122, 0x92, 0x2, 0x40b, 0x13d, 0x3, 0x2, 0x2, 0x2, 0x40c, 0x40e, 
    0x5, 0x13c, 0x9f, 0x2, 0x40d, 0x40c, 0x3, 0x2, 0x2, 0x2, 0x40d, 0x40e, 
    0x3, 0x2, 0x2, 0x2, 0x40e, 0x13f, 0x3, 0x2, 0x2, 0x2, 0x40f, 0x410, 
    0x5, 0x14e, 0xa8, 0x2, 0x410, 0x411, 0x5, 0x144, 0xa3, 0x2, 0x411, 0x141, 
    0x3, 0x2, 0x2, 0x2, 0x412, 0x414, 0x5, 0x140, 0xa1, 0x2, 0x413, 0x412, 
    0x3, 0x2, 0x2, 0x2, 0x414, 0x417, 0x3, 0x2, 0x2, 0x2, 0x415, 0x413, 
    0x3, 0x2, 0x2, 0x2, 0x415, 0x416, 0x3, 0x2, 0x2, 0x2, 0x416, 0x143, 
    0x3, 0x2, 0x2, 0x2, 0x417, 0x415, 0x3, 0x2, 0x2, 0x2, 0x418, 0x419, 
    0x5, 0x86, 0x44, 0x2, 0x419, 0x41a, 0x5, 0x142, 0xa2, 0x2, 0x41a, 0x145, 
    0x3, 0x2, 0x2, 0x2, 0x41b, 0x421, 0x5, 0x190, 0xc9, 0x2, 0x41c, 0x421, 
    0x5, 0xa4, 0x53, 0x2, 0x41d, 0x421, 0x5, 0xa6, 0x54, 0x2, 0x41e, 0x421, 
    0x5, 0xa8, 0x55, 0x2, 0x41f, 0x421, 0x5, 0xaa, 0x56, 0x2, 0x420, 0x41b, 
    0x3, 0x2, 0x2, 0x2, 0x420, 0x41c, 0x3, 0x2, 0x2, 0x2, 0x420, 0x41d, 
    0x3, 0x2, 0x2, 0x2, 0x420, 0x41e, 0x3, 0x2, 0x2, 0x2, 0x420, 0x41f, 
    0x3, 0x2, 0x2, 0x2, 0x421, 0x147, 0x3, 0x2, 0x2, 0x2, 0x422, 0x424, 
    0x5, 0x146, 0xa4, 0x2, 0x423, 0x422, 0x3, 0x2, 0x2, 0x2, 0x424, 0x427, 
    0x3, 0x2, 0x2, 0x2, 0x425, 0x423, 0x3, 0x2, 0x2, 0x2, 0x425, 0x426, 
    0x3, 0x2, 0x2, 0x2, 0x426, 0x149, 0x3, 0x2, 0x2, 0x2, 0x427, 0x425, 
    0x3, 0x2, 0x2, 0x2, 0x428, 0x429, 0x5, 0x176, 0xbc, 0x2, 0x429, 0x42a, 
    0x5, 0x148, 0xa5, 0x2, 0x42a, 0x14b, 0x3, 0x2, 0x2, 0x2, 0x42b, 0x42d, 
    0x5, 0x80, 0x41, 0x2, 0x42c, 0x42b, 0x3, 0x2, 0x2, 0x2, 0x42c, 0x42d, 
    0x3, 0x2, 0x2, 0x2, 0x42d, 0x14d, 0x3, 0x2, 0x2, 0x2, 0x42e, 0x42f, 
    0x9, 0x5, 0x2, 0x2, 0x42f, 0x14f, 0x3, 0x2, 0x2, 0x2, 0x430, 0x43b, 
    0x5, 0x6a, 0x36, 0x2, 0x431, 0x43b, 0x5, 0x6c, 0x37, 0x2, 0x432, 0x43b, 
    0x5, 0x9a, 0x4e, 0x2, 0x433, 0x43b, 0x5, 0x70, 0x39, 0x2, 0x434, 0x43b, 
    0x5, 0x7c, 0x3f, 0x2, 0x435, 0x43b, 0x5, 0x72, 0x3a, 0x2, 0x436, 0x43b, 
    0x5, 0x74, 0x3b, 0x2, 0x437, 0x43b, 0x5, 0x76, 0x3c, 0x2, 0x438, 0x43b, 
    0x5, 0x78, 0x3d, 0x2, 0x439, 0x43b, 0x5, 0x192, 0xca, 0x2, 0x43a, 0x430, 
    0x3, 0x2, 0x2, 0x2, 0x43a, 0x431, 0x3, 0x2, 0x2, 0x2, 0x43a, 0x432, 
    0x3, 0x2, 0x2, 0x2, 0x43a, 0x433, 0x3, 0x2, 0x2, 0x2, 0x43a, 0x434, 
    0x3, 0x2, 0x2, 0x2, 0x43a, 0x435, 0x3, 0x2, 0x2, 0x2, 0x43a, 0x436, 
    0x3, 0x2, 0x2, 0x2, 0x43a, 0x437, 0x3, 0x2, 0x2, 0x2, 0x43a, 0x438, 
    0x3, 0x2, 0x2, 0x2, 0x43a, 0x439, 0x3, 0x2, 0x2, 0x2, 0x43b, 0x151, 
    0x3, 0x2, 0x2, 0x2, 0x43c, 0x44d, 0x5, 0xc, 0x7, 0x2, 0x43d, 0x44d, 
    0x5, 0x3a, 0x1e, 0x2, 0x43e, 0x44d, 0x5, 0x2c, 0x17, 0x2, 0x43f, 0x44d, 
    0x5, 0x68, 0x35, 0x2, 0x440, 0x44d, 0x5, 0x3c, 0x1f, 0x2, 0x441, 0x44d, 
    0x5, 0x3e, 0x20, 0x2, 0x442, 0x44d, 0x5, 0x40, 0x21, 0x2, 0x443, 0x44d, 
    0x5, 0x42, 0x22, 0x2, 0x444, 0x44d, 0x5, 0x44, 0x23, 0x2, 0x445, 0x44d, 
    0x5, 0x24, 0x13, 0x2, 0x446, 0x44d, 0x5, 0x48, 0x25, 0x2, 0x447, 0x44d, 
    0x5, 0x4a, 0x26, 0x2, 0x448, 0x44d, 0x5, 0x50, 0x29, 0x2, 0x449, 0x44d, 
    0x5, 0x5a, 0x2e, 0x2, 0x44a, 0x44d, 0x5, 0x62, 0x32, 0x2, 0x44b, 0x44d, 
    0x5, 0x46, 0x24, 0x2, 0x44c, 0x43c, 0x3, 0x2, 0x2, 0x2, 0x44c, 0x43d, 
    0x3, 0x2, 0x2, 0x2, 0x44c, 0x43e, 0x3, 0x2, 0x2, 0x2, 0x44c, 0x43f, 
    0x3, 0x2, 0x2, 0x2, 0x44c, 0x440, 0x3, 0x2, 0x2, 0x2, 0x44c, 0x441, 
    0x3, 0x2, 0x2, 0x2, 0x44c, 0x442, 0x3, 0x2, 0x2, 0x2, 0x44c, 0x443, 
    0x3, 0x2, 0x2, 0x2, 0x44c, 0x444, 0x3, 0x2, 0x2, 0x2, 0x44c, 0x445, 
    0x3, 0x2, 0x2, 0x2, 0x44c, 0x446, 0x3, 0x2, 0x2, 0x2, 0x44c, 0x447, 
    0x3, 0x2, 0x2, 0x2, 0x44c, 0x448, 0x3, 0x2, 0x2, 0x2, 0x44c, 0x449, 
    0x3, 0x2, 0x2, 0x2, 0x44c, 0x44a, 0x3, 0x2, 0x2, 0x2, 0x44c, 0x44b, 
    0x3, 0x2, 0x2, 0x2, 0x44d, 0x153, 0x3, 0x2, 0x2, 0x2, 0x44e, 0x451, 
    0x5, 0x8, 0x5, 0x2, 0x44f, 0x451, 0x5, 0x194, 0xcb, 0x2, 0x450, 0x44e, 
    0x3, 0x2, 0x2, 0x2, 0x450, 0x44f, 0x3, 0x2, 0x2, 0x2, 0x451, 0x155, 
    0x3, 0x2, 0x2, 0x2, 0x452, 0x455, 0x5, 0x10, 0x9, 0x2, 0x453, 0x455, 
    0x5, 0x196, 0xcc, 0x2, 0x454, 0x452, 0x3, 0x2, 0x2, 0x2, 0x454, 0x453, 
    0x3, 0x2, 0x2, 0x2, 0x455, 0x157, 0x3, 0x2, 0x2, 0x2, 0x456, 0x459, 
    0x5, 0x18, 0xd, 0x2, 0x457, 0x459, 0x5, 0x198, 0xcd, 0x2, 0x458, 0x456, 
    0x3, 0x2, 0x2, 0x2, 0x458, 0x457, 0x3, 0x2, 0x2, 0x2, 0x459, 0x159, 
    0x3, 0x2, 0x2, 0x2, 0x45a, 0x45d, 0x5, 0x22, 0x12, 0x2, 0x45b, 0x45d, 
    0x5, 0x19a, 0xce, 0x2, 0x45c, 0x45a, 0x3, 0x2, 0x2, 0x2, 0x45c, 0x45b, 
    0x3, 0x2, 0x2, 0x2, 0x45d, 0x15b, 0x3, 0x2, 0x2, 0x2, 0x45e, 0x461, 
    0x5, 0x19c, 0xcf, 0x2, 0x45f, 0x461, 0x5, 0x19e, 0xd0, 0x2, 0x460, 0x45e, 
    0x3, 0x2, 0x2, 0x2, 0x460, 0x45f, 0x3, 0x2, 0x2, 0x2, 0x461, 0x15d, 
    0x3, 0x2, 0x2, 0x2, 0x462, 0x463, 0x9, 0x6, 0x2, 0x2, 0x463, 0x15f, 
    0x3, 0x2, 0x2, 0x2, 0x464, 0x467, 0x5, 0x150, 0xa9, 0x2, 0x465, 0x467, 
    0x7, 0x1c, 0x2, 0x2, 0x466, 0x464, 0x3, 0x2, 0x2, 0x2, 0x466, 0x465, 
    0x3, 0x2, 0x2, 0x2, 0x467, 0x161, 0x3, 0x2, 0x2, 0x2, 0x468, 0x46b, 
    0x5, 0x30, 0x19, 0x2, 0x469, 0x46b, 0x5, 0x60, 0x31, 0x2, 0x46a, 0x468, 
    0x3, 0x2, 0x2, 0x2, 0x46a, 0x469, 0x3, 0x2, 0x2, 0x2, 0x46b, 0x163, 
    0x3, 0x2, 0x2, 0x2, 0x46c, 0x46f, 0x5, 0x1a0, 0xd1, 0x2, 0x46d, 0x46f, 
    0x5, 0x1a2, 0xd2, 0x2, 0x46e, 0x46c, 0x3, 0x2, 0x2, 0x2, 0x46e, 0x46d, 
    0x3, 0x2, 0x2, 0x2, 0x46f, 0x165, 0x3, 0x2, 0x2, 0x2, 0x470, 0x471, 
    0x9, 0x7, 0x2, 0x2, 0x471, 0x167, 0x3, 0x2, 0x2, 0x2, 0x472, 0x475, 
    0x5, 0x1a4, 0xd3, 0x2, 0x473, 0x475, 0x5, 0xa0, 0x51, 0x2, 0x474, 0x472, 
    0x3, 0x2, 0x2, 0x2, 0x474, 0x473, 0x3, 0x2, 0x2, 0x2, 0x475, 0x169, 
    0x3, 0x2, 0x2, 0x2, 0x476, 0x477, 0x5, 0xf6, 0x7c, 0x2, 0x477, 0x478, 
    0x7, 0x27, 0x2, 0x2, 0x478, 0x479, 0x5, 0x174, 0xbb, 0x2, 0x479, 0x16b, 
    0x3, 0x2, 0x2, 0x2, 0x47a, 0x47e, 0x5, 0x1a, 0xe, 0x2, 0x47b, 0x47e, 
    0x5, 0x1c, 0xf, 0x2, 0x47c, 0x47e, 0x5, 0xc, 0x7, 0x2, 0x47d, 0x47a, 
    0x3, 0x2, 0x2, 0x2, 0x47d, 0x47b, 0x3, 0x2, 0x2, 0x2, 0x47d, 0x47c, 
    0x3, 0x2, 0x2, 0x2, 0x47e, 0x16d, 0x3, 0x2, 0x2, 0x2, 0x47f, 0x482, 
    0x5, 0x48, 0x25, 0x2, 0x480, 0x482, 0x5, 0x24, 0x13, 0x2, 0x481, 0x47f, 
    0x3, 0x2, 0x2, 0x2, 0x481, 0x480, 0x3, 0x2, 0x2, 0x2, 0x482, 0x16f, 
    0x3, 0x2, 0x2, 0x2, 0x483, 0x486, 0x5, 0x14, 0xb, 0x2, 0x484, 0x486, 
    0x5, 0x1a6, 0xd4, 0x2, 0x485, 0x483, 0x3, 0x2, 0x2, 0x2, 0x485, 0x484, 
    0x3, 0x2, 0x2, 0x2, 0x486, 0x171, 0x3, 0x2, 0x2, 0x2, 0x487, 0x489, 
    0x7, 0x41, 0x2, 0x2, 0x488, 0x487, 0x3, 0x2, 0x2, 0x2, 0x488, 0x489, 
    0x3, 0x2, 0x2, 0x2, 0x489, 0x173, 0x3, 0x2, 0x2, 0x2, 0x48a, 0x48d, 
    0x5, 0xf6, 0x7c, 0x2, 0x48b, 0x48d, 0x5, 0x1a8, 0xd5, 0x2, 0x48c, 0x48a, 
    0x3, 0x2, 0x2, 0x2, 0x48c, 0x48b, 0x3, 0x2, 0x2, 0x2, 0x48d, 0x175, 
    0x3, 0x2, 0x2, 0x2, 0x48e, 0x49d, 0x7, 0x1c, 0x2, 0x2, 0x48f, 0x49d, 
    0x7, 0x42, 0x2, 0x2, 0x490, 0x49d, 0x7, 0x43, 0x2, 0x2, 0x491, 0x49d, 
    0x7, 0x44, 0x2, 0x2, 0x492, 0x49d, 0x7, 0x46, 0x2, 0x2, 0x493, 0x49d, 
    0x7, 0x47, 0x2, 0x2, 0x494, 0x49d, 0x5, 0x9e, 0x50, 0x2, 0x495, 0x49d, 
    0x7, 0x45, 0x2, 0x2, 0x496, 0x49d, 0x5, 0x8c, 0x47, 0x2, 0x497, 0x49d, 
    0x5, 0xa2, 0x52, 0x2, 0x498, 0x49d, 0x5, 0x6a, 0x36, 0x2, 0x499, 0x49d, 
    0x5, 0xac, 0x57, 0x2, 0x49a, 0x49d, 0x5, 0x1aa, 0xd6, 0x2, 0x49b, 0x49d, 
    0x5, 0x88, 0x45, 0x2, 0x49c, 0x48e, 0x3, 0x2, 0x2, 0x2, 0x49c, 0x48f, 
    0x3, 0x2, 0x2, 0x2, 0x49c, 0x490, 0x3, 0x2, 0x2, 0x2, 0x49c, 0x491, 
    0x3, 0x2, 0x2, 0x2, 0x49c, 0x492, 0x3, 0x2, 0x2, 0x2, 0x49c, 0x493, 
    0x3, 0x2, 0x2, 0x2, 0x49c, 0x494, 0x3, 0x2, 0x2, 0x2, 0x49c, 0x495, 
    0x3, 0x2, 0x2, 0x2, 0x49c, 0x496, 0x3, 0x2, 0x2, 0x2, 0x49c, 0x497, 
    0x3, 0x2, 0x2, 0x2, 0x49c, 0x498, 0x3, 0x2, 0x2, 0x2, 0x49c, 0x499, 
    0x3, 0x2, 0x2, 0x2, 0x49c, 0x49a, 0x3, 0x2, 0x2, 0x2, 0x49c, 0x49b, 
    0x3, 0x2, 0x2, 0x2, 0x49d, 0x177, 0x3, 0x2, 0x2, 0x2, 0x49e, 0x49f, 
    0x5, 0x4, 0x3, 0x2, 0x49f, 0x4a0, 0x5, 0xae, 0x58, 0x2, 0x4a0, 0x4a1, 
    0x5, 0xb2, 0x5a, 0x2, 0x4a1, 0x4a2, 0x5, 0xb6, 0x5c, 0x2, 0x4a2, 0x179, 
    0x3, 0x2, 0x2, 0x2, 0x4a3, 0x4a4, 0x7, 0x8, 0x2, 0x2, 0x4a4, 0x4a5, 
    0x5, 0x14, 0xb, 0x2, 0x4a5, 0x17b, 0x3, 0x2, 0x2, 0x2, 0x4a6, 0x4a7, 
    0x7, 0x8, 0x2, 0x2, 0x4a7, 0x4a8, 0x5, 0x58, 0x2d, 0x2, 0x4a8, 0x17d, 
    0x3, 0x2, 0x2, 0x2, 0x4a9, 0x4aa, 0x7, 0x8, 0x2, 0x2, 0x4aa, 0x4ab, 
    0x5, 0x162, 0xb2, 0x2, 0x4ab, 0x17f, 0x3, 0x2, 0x2, 0x2, 0x4ac, 0x4ad, 
    0x7, 0x1d, 0x2, 0x2, 0x4ad, 0x4ae, 0x5, 0x82, 0x42, 0x2, 0x4ae, 0x4af, 
    0x5, 0x14c, 0xa7, 0x2, 0x4af, 0x181, 0x3, 0x2, 0x2, 0x2, 0x4b0, 0x4b1, 
    0x5, 0x166, 0xb4, 0x2, 0x4b1, 0x4b2, 0x5, 0x86, 0x44, 0x2, 0x4b2, 0x183, 
    0x3, 0x2, 0x2, 0x2, 0x4b3, 0x4b4, 0x7, 0x22, 0x2, 0x2, 0x4b4, 0x4b5, 
    0x7, 0x2c, 0x2, 0x2, 0x4b5, 0x4b6, 0x7, 0x23, 0x2, 0x2, 0x4b6, 0x4b7, 
    0x5, 0x6e, 0x38, 0x2, 0x4b7, 0x185, 0x3, 0x2, 0x2, 0x2, 0x4b8, 0x4b9, 
    0x6, 0xc4, 0x2, 0x3, 0x4b9, 0x187, 0x3, 0x2, 0x2, 0x2, 0x4ba, 0x4bb, 
    0x6, 0xc5, 0x3, 0x3, 0x4bb, 0x189, 0x3, 0x2, 0x2, 0x2, 0x4bc, 0x4bd, 
    0x5, 0x152, 0xaa, 0x2, 0x4bd, 0x4be, 0x5, 0xae, 0x58, 0x2, 0x4be, 0x18b, 
    0x3, 0x2, 0x2, 0x2, 0x4bf, 0x4c0, 0x5, 0x14, 0xb, 0x2, 0x4c0, 0x4c1, 
    0x7, 0x24, 0x2, 0x2, 0x4c1, 0x18d, 0x3, 0x2, 0x2, 0x2, 0x4c2, 0x4c3, 
    0x5, 0x12, 0xa, 0x2, 0x4c3, 0x4c4, 0x7, 0x2b, 0x2, 0x2, 0x4c4, 0x18f, 
    0x3, 0x2, 0x2, 0x2, 0x4c5, 0x4c6, 0x7, 0x28, 0x2, 0x2, 0x4c6, 0x4c7, 
    0x7, 0x1d, 0x2, 0x2, 0x4c7, 0x191, 0x3, 0x2, 0x2, 0x2, 0x4c8, 0x4c9, 
    0x7, 0x1e, 0x2, 0x2, 0x4c9, 0x4ca, 0x5, 0x150, 0xa9, 0x2, 0x4ca, 0x4cb, 
    0x7, 0x1f, 0x2, 0x2, 0x4cb, 0x193, 0x3, 0x2, 0x2, 0x2, 0x4cc, 0x4cd, 
    0x7, 0x1e, 0x2, 0x2, 0x4cd, 0x4ce, 0x5, 0xba, 0x5e, 0x2, 0x4ce, 0x4cf, 
    0x7, 0x1f, 0x2, 0x2, 0x4cf, 0x195, 0x3, 0x2, 0x2, 0x2, 0x4d0, 0x4d1, 
    0x7, 0x1e, 0x2, 0x2, 0x4d1, 0x4d2, 0x5, 0xc2, 0x62, 0x2, 0x4d2, 0x4d3, 
    0x7, 0x1f, 0x2, 0x2, 0x4d3, 0x197, 0x3, 0x2, 0x2, 0x2, 0x4d4, 0x4d5, 
    0x7, 0x1e, 0x2, 0x2, 0x4d5, 0x4d6, 0x5, 0xd4, 0x6b, 0x2, 0x4d6, 0x4d7, 
    0x7, 0x1f, 0x2, 0x2, 0x4d7, 0x199, 0x3, 0x2, 0x2, 0x2, 0x4d8, 0x4d9, 
    0x7, 0x1e, 0x2, 0x2, 0x4d9, 0x4da, 0x5, 0xdc, 0x6f, 0x2, 0x4da, 0x4db, 
    0x7, 0x1f, 0x2, 0x2, 0x4db, 0x19b, 0x3, 0x2, 0x2, 0x2, 0x4dc, 0x4dd, 
    0x5, 0x150, 0xa9, 0x2, 0x4dd, 0x4de, 0x5, 0xe0, 0x71, 0x2, 0x4de, 0x19d, 
    0x3, 0x2, 0x2, 0x2, 0x4df, 0x4e0, 0x7, 0x24, 0x2, 0x2, 0x4e0, 0x4e1, 
    0x5, 0x14, 0xb, 0x2, 0x4e1, 0x19f, 0x3, 0x2, 0x2, 0x2, 0x4e2, 0x4e3, 
    0x7, 0xd, 0x2, 0x2, 0x4e3, 0x4e4, 0x7, 0x41, 0x2, 0x2, 0x4e4, 0x1a1, 
    0x3, 0x2, 0x2, 0x2, 0x4e5, 0x4e6, 0x5, 0x172, 0xba, 0x2, 0x4e6, 0x4e7, 
    0x7, 0xd, 0x2, 0x2, 0x4e7, 0x1a3, 0x3, 0x2, 0x2, 0x2, 0x4e8, 0x4e9, 
    0x5, 0x12, 0xa, 0x2, 0x4e9, 0x4ea, 0x5, 0x150, 0xa9, 0x2, 0x4ea, 0x1a5, 
    0x3, 0x2, 0x2, 0x2, 0x4eb, 0x4ec, 0x5, 0x150, 0xa9, 0x2, 0x4ec, 0x4ed, 
    0x5, 0x13a, 0x9e, 0x2, 0x4ed, 0x1a7, 0x3, 0x2, 0x2, 0x2, 0x4ee, 0x4ef, 
    0x5, 0x144, 0xa3, 0x2, 0x4ef, 0x4f0, 0x7, 0x27, 0x2, 0x2, 0x4f0, 0x4f1, 
    0x5, 0x144, 0xa3, 0x2, 0x4f1, 0x1a9, 0x3, 0x2, 0x2, 0x2, 0x4f2, 0x4f3, 
    0x7, 0x1e, 0x2, 0x2, 0x4f3, 0x4f4, 0x5, 0x144, 0xa3, 0x2, 0x4f4, 0x4f5, 
    0x7, 0x1f, 0x2, 0x2, 0x4f5, 0x1ab, 0x3, 0x2, 0x2, 0x2, 0x57, 0x1ae, 
    0x1be, 0x1ed, 0x1f0, 0x1f3, 0x1fa, 0x238, 0x24e, 0x25e, 0x276, 0x296, 
    0x2a0, 0x2ac, 0x2c1, 0x2d0, 0x2d4, 0x300, 0x308, 0x311, 0x31a, 0x320, 
    0x328, 0x32c, 0x333, 0x33b, 0x344, 0x34d, 0x351, 0x354, 0x35c, 0x363, 
    0x366, 0x36a, 0x36f, 0x372, 0x375, 0x37b, 0x381, 0x384, 0x389, 0x38f, 
    0x396, 0x39e, 0x3a4, 0x3a9, 0x3ac, 0x3b1, 0x3b4, 0x3b7, 0x3bf, 0x3c8, 
    0x3cc, 0x3d3, 0x3d6, 0x3d9, 0x3dc, 0x3e2, 0x3ea, 0x3f1, 0x3f9, 0x3fd, 
    0x400, 0x406, 0x40d, 0x415, 0x420, 0x425, 0x42c, 0x43a, 0x44c, 0x450, 
    0x454, 0x458, 0x45c, 0x460, 0x466, 0x46a, 0x46e, 0x474, 0x47d, 0x481, 
    0x485, 0x488, 0x48c, 0x49c, 
  };

  atn::ATNDeserializer deserializer;
  _atn = deserializer.deserialize(_serializedATN);

  size_t count = _atn.getNumberOfDecisions();
  _decisionToDFA.reserve(count);
  for (size_t i = 0; i < count; i++) { 
    _decisionToDFA.emplace_back(_atn.getDecisionState(i), i);
  }
}

PnfGoParser::Initializer PnfGoParser::_init;
