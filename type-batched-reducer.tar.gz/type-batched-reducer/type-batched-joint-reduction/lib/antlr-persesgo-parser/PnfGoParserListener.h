
// Generated from PnfGoParser.g4 by ANTLR 4.7.2

#pragma once


#include "antlr4-runtime.h"
#include "PnfGoParser.h"


namespace antlr_go_perses {

/**
 * This interface defines an abstract listener for a parse tree produced by PnfGoParser.
 */
class  PnfGoParserListener : public antlr4::tree::ParseTreeListener {
public:

  virtual void enterSourceFile(PnfGoParser::SourceFileContext *ctx) = 0;
  virtual void exitSourceFile(PnfGoParser::SourceFileContext *ctx) = 0;

  virtual void enterPackageClause(PnfGoParser::PackageClauseContext *ctx) = 0;
  virtual void exitPackageClause(PnfGoParser::PackageClauseContext *ctx) = 0;

  virtual void enterImportDecl(PnfGoParser::ImportDeclContext *ctx) = 0;
  virtual void exitImportDecl(PnfGoParser::ImportDeclContext *ctx) = 0;

  virtual void enterImportSpec(PnfGoParser::ImportSpecContext *ctx) = 0;
  virtual void exitImportSpec(PnfGoParser::ImportSpecContext *ctx) = 0;

  virtual void enterImportPath(PnfGoParser::ImportPathContext *ctx) = 0;
  virtual void exitImportPath(PnfGoParser::ImportPathContext *ctx) = 0;

  virtual void enterDeclaration(PnfGoParser::DeclarationContext *ctx) = 0;
  virtual void exitDeclaration(PnfGoParser::DeclarationContext *ctx) = 0;

  virtual void enterConstDecl(PnfGoParser::ConstDeclContext *ctx) = 0;
  virtual void exitConstDecl(PnfGoParser::ConstDeclContext *ctx) = 0;

  virtual void enterConstSpec(PnfGoParser::ConstSpecContext *ctx) = 0;
  virtual void exitConstSpec(PnfGoParser::ConstSpecContext *ctx) = 0;

  virtual void enterIdentifierList(PnfGoParser::IdentifierListContext *ctx) = 0;
  virtual void exitIdentifierList(PnfGoParser::IdentifierListContext *ctx) = 0;

  virtual void enterExpressionList(PnfGoParser::ExpressionListContext *ctx) = 0;
  virtual void exitExpressionList(PnfGoParser::ExpressionListContext *ctx) = 0;

  virtual void enterTypeDecl(PnfGoParser::TypeDeclContext *ctx) = 0;
  virtual void exitTypeDecl(PnfGoParser::TypeDeclContext *ctx) = 0;

  virtual void enterTypeSpec(PnfGoParser::TypeSpecContext *ctx) = 0;
  virtual void exitTypeSpec(PnfGoParser::TypeSpecContext *ctx) = 0;

  virtual void enterFunctionDecl(PnfGoParser::FunctionDeclContext *ctx) = 0;
  virtual void exitFunctionDecl(PnfGoParser::FunctionDeclContext *ctx) = 0;

  virtual void enterMethodDecl(PnfGoParser::MethodDeclContext *ctx) = 0;
  virtual void exitMethodDecl(PnfGoParser::MethodDeclContext *ctx) = 0;

  virtual void enterReceiver(PnfGoParser::ReceiverContext *ctx) = 0;
  virtual void exitReceiver(PnfGoParser::ReceiverContext *ctx) = 0;

  virtual void enterVarDecl(PnfGoParser::VarDeclContext *ctx) = 0;
  virtual void exitVarDecl(PnfGoParser::VarDeclContext *ctx) = 0;

  virtual void enterVarSpec(PnfGoParser::VarSpecContext *ctx) = 0;
  virtual void exitVarSpec(PnfGoParser::VarSpecContext *ctx) = 0;

  virtual void enterBlock(PnfGoParser::BlockContext *ctx) = 0;
  virtual void exitBlock(PnfGoParser::BlockContext *ctx) = 0;

  virtual void enterStatementList(PnfGoParser::StatementListContext *ctx) = 0;
  virtual void exitStatementList(PnfGoParser::StatementListContext *ctx) = 0;

  virtual void enterStatement(PnfGoParser::StatementContext *ctx) = 0;
  virtual void exitStatement(PnfGoParser::StatementContext *ctx) = 0;

  virtual void enterSimpleStmt(PnfGoParser::SimpleStmtContext *ctx) = 0;
  virtual void exitSimpleStmt(PnfGoParser::SimpleStmtContext *ctx) = 0;

  virtual void enterRealSimpleStmt(PnfGoParser::RealSimpleStmtContext *ctx) = 0;
  virtual void exitRealSimpleStmt(PnfGoParser::RealSimpleStmtContext *ctx) = 0;

  virtual void enterExpressionStmt(PnfGoParser::ExpressionStmtContext *ctx) = 0;
  virtual void exitExpressionStmt(PnfGoParser::ExpressionStmtContext *ctx) = 0;

  virtual void enterSendStmt(PnfGoParser::SendStmtContext *ctx) = 0;
  virtual void exitSendStmt(PnfGoParser::SendStmtContext *ctx) = 0;

  virtual void enterIncDecStmt(PnfGoParser::IncDecStmtContext *ctx) = 0;
  virtual void exitIncDecStmt(PnfGoParser::IncDecStmtContext *ctx) = 0;

  virtual void enterAssignment(PnfGoParser::AssignmentContext *ctx) = 0;
  virtual void exitAssignment(PnfGoParser::AssignmentContext *ctx) = 0;

  virtual void enterAssign_op(PnfGoParser::Assign_opContext *ctx) = 0;
  virtual void exitAssign_op(PnfGoParser::Assign_opContext *ctx) = 0;

  virtual void enterShortVarDecl(PnfGoParser::ShortVarDeclContext *ctx) = 0;
  virtual void exitShortVarDecl(PnfGoParser::ShortVarDeclContext *ctx) = 0;

  virtual void enterLabeledStmt(PnfGoParser::LabeledStmtContext *ctx) = 0;
  virtual void exitLabeledStmt(PnfGoParser::LabeledStmtContext *ctx) = 0;

  virtual void enterReturnStmt(PnfGoParser::ReturnStmtContext *ctx) = 0;
  virtual void exitReturnStmt(PnfGoParser::ReturnStmtContext *ctx) = 0;

  virtual void enterBreakStmt(PnfGoParser::BreakStmtContext *ctx) = 0;
  virtual void exitBreakStmt(PnfGoParser::BreakStmtContext *ctx) = 0;

  virtual void enterContinueStmt(PnfGoParser::ContinueStmtContext *ctx) = 0;
  virtual void exitContinueStmt(PnfGoParser::ContinueStmtContext *ctx) = 0;

  virtual void enterGotoStmt(PnfGoParser::GotoStmtContext *ctx) = 0;
  virtual void exitGotoStmt(PnfGoParser::GotoStmtContext *ctx) = 0;

  virtual void enterFallthroughStmt(PnfGoParser::FallthroughStmtContext *ctx) = 0;
  virtual void exitFallthroughStmt(PnfGoParser::FallthroughStmtContext *ctx) = 0;

  virtual void enterDeferStmt(PnfGoParser::DeferStmtContext *ctx) = 0;
  virtual void exitDeferStmt(PnfGoParser::DeferStmtContext *ctx) = 0;

  virtual void enterIfStmt(PnfGoParser::IfStmtContext *ctx) = 0;
  virtual void exitIfStmt(PnfGoParser::IfStmtContext *ctx) = 0;

  virtual void enterExprSwitchStmt(PnfGoParser::ExprSwitchStmtContext *ctx) = 0;
  virtual void exitExprSwitchStmt(PnfGoParser::ExprSwitchStmtContext *ctx) = 0;

  virtual void enterExprCaseClause(PnfGoParser::ExprCaseClauseContext *ctx) = 0;
  virtual void exitExprCaseClause(PnfGoParser::ExprCaseClauseContext *ctx) = 0;

  virtual void enterExprSwitchCase(PnfGoParser::ExprSwitchCaseContext *ctx) = 0;
  virtual void exitExprSwitchCase(PnfGoParser::ExprSwitchCaseContext *ctx) = 0;

  virtual void enterTypeSwitchStmt(PnfGoParser::TypeSwitchStmtContext *ctx) = 0;
  virtual void exitTypeSwitchStmt(PnfGoParser::TypeSwitchStmtContext *ctx) = 0;

  virtual void enterTypeSwitchGuard(PnfGoParser::TypeSwitchGuardContext *ctx) = 0;
  virtual void exitTypeSwitchGuard(PnfGoParser::TypeSwitchGuardContext *ctx) = 0;

  virtual void enterTypeCaseClause(PnfGoParser::TypeCaseClauseContext *ctx) = 0;
  virtual void exitTypeCaseClause(PnfGoParser::TypeCaseClauseContext *ctx) = 0;

  virtual void enterTypeSwitchCase(PnfGoParser::TypeSwitchCaseContext *ctx) = 0;
  virtual void exitTypeSwitchCase(PnfGoParser::TypeSwitchCaseContext *ctx) = 0;

  virtual void enterTypeList(PnfGoParser::TypeListContext *ctx) = 0;
  virtual void exitTypeList(PnfGoParser::TypeListContext *ctx) = 0;

  virtual void enterSelectStmt(PnfGoParser::SelectStmtContext *ctx) = 0;
  virtual void exitSelectStmt(PnfGoParser::SelectStmtContext *ctx) = 0;

  virtual void enterCommClause(PnfGoParser::CommClauseContext *ctx) = 0;
  virtual void exitCommClause(PnfGoParser::CommClauseContext *ctx) = 0;

  virtual void enterCommCase(PnfGoParser::CommCaseContext *ctx) = 0;
  virtual void exitCommCase(PnfGoParser::CommCaseContext *ctx) = 0;

  virtual void enterRecvStmt(PnfGoParser::RecvStmtContext *ctx) = 0;
  virtual void exitRecvStmt(PnfGoParser::RecvStmtContext *ctx) = 0;

  virtual void enterForStmt(PnfGoParser::ForStmtContext *ctx) = 0;
  virtual void exitForStmt(PnfGoParser::ForStmtContext *ctx) = 0;

  virtual void enterForClause(PnfGoParser::ForClauseContext *ctx) = 0;
  virtual void exitForClause(PnfGoParser::ForClauseContext *ctx) = 0;

  virtual void enterRangeClause(PnfGoParser::RangeClauseContext *ctx) = 0;
  virtual void exitRangeClause(PnfGoParser::RangeClauseContext *ctx) = 0;

  virtual void enterGoStmt(PnfGoParser::GoStmtContext *ctx) = 0;
  virtual void exitGoStmt(PnfGoParser::GoStmtContext *ctx) = 0;

  virtual void enterTypeName(PnfGoParser::TypeNameContext *ctx) = 0;
  virtual void exitTypeName(PnfGoParser::TypeNameContext *ctx) = 0;

  virtual void enterArrayType(PnfGoParser::ArrayTypeContext *ctx) = 0;
  virtual void exitArrayType(PnfGoParser::ArrayTypeContext *ctx) = 0;

  virtual void enterElementType(PnfGoParser::ElementTypeContext *ctx) = 0;
  virtual void exitElementType(PnfGoParser::ElementTypeContext *ctx) = 0;

  virtual void enterPointerType(PnfGoParser::PointerTypeContext *ctx) = 0;
  virtual void exitPointerType(PnfGoParser::PointerTypeContext *ctx) = 0;

  virtual void enterInterfaceType(PnfGoParser::InterfaceTypeContext *ctx) = 0;
  virtual void exitInterfaceType(PnfGoParser::InterfaceTypeContext *ctx) = 0;

  virtual void enterSliceType(PnfGoParser::SliceTypeContext *ctx) = 0;
  virtual void exitSliceType(PnfGoParser::SliceTypeContext *ctx) = 0;

  virtual void enterMapType(PnfGoParser::MapTypeContext *ctx) = 0;
  virtual void exitMapType(PnfGoParser::MapTypeContext *ctx) = 0;

  virtual void enterChannelType(PnfGoParser::ChannelTypeContext *ctx) = 0;
  virtual void exitChannelType(PnfGoParser::ChannelTypeContext *ctx) = 0;

  virtual void enterMethodSpec(PnfGoParser::MethodSpecContext *ctx) = 0;
  virtual void exitMethodSpec(PnfGoParser::MethodSpecContext *ctx) = 0;

  virtual void enterFunctionType(PnfGoParser::FunctionTypeContext *ctx) = 0;
  virtual void exitFunctionType(PnfGoParser::FunctionTypeContext *ctx) = 0;

  virtual void enterSignature(PnfGoParser::SignatureContext *ctx) = 0;
  virtual void exitSignature(PnfGoParser::SignatureContext *ctx) = 0;

  virtual void enterResult(PnfGoParser::ResultContext *ctx) = 0;
  virtual void exitResult(PnfGoParser::ResultContext *ctx) = 0;

  virtual void enterParameters(PnfGoParser::ParametersContext *ctx) = 0;
  virtual void exitParameters(PnfGoParser::ParametersContext *ctx) = 0;

  virtual void enterParameterDecl(PnfGoParser::ParameterDeclContext *ctx) = 0;
  virtual void exitParameterDecl(PnfGoParser::ParameterDeclContext *ctx) = 0;

  virtual void enterUnaryExpr(PnfGoParser::UnaryExprContext *ctx) = 0;
  virtual void exitUnaryExpr(PnfGoParser::UnaryExprContext *ctx) = 0;

  virtual void enterConversion(PnfGoParser::ConversionContext *ctx) = 0;
  virtual void exitConversion(PnfGoParser::ConversionContext *ctx) = 0;

  virtual void enterQualifiedIdent(PnfGoParser::QualifiedIdentContext *ctx) = 0;
  virtual void exitQualifiedIdent(PnfGoParser::QualifiedIdentContext *ctx) = 0;

  virtual void enterCompositeLit(PnfGoParser::CompositeLitContext *ctx) = 0;
  virtual void exitCompositeLit(PnfGoParser::CompositeLitContext *ctx) = 0;

  virtual void enterLiteralType(PnfGoParser::LiteralTypeContext *ctx) = 0;
  virtual void exitLiteralType(PnfGoParser::LiteralTypeContext *ctx) = 0;

  virtual void enterLiteralValue(PnfGoParser::LiteralValueContext *ctx) = 0;
  virtual void exitLiteralValue(PnfGoParser::LiteralValueContext *ctx) = 0;

  virtual void enterElementList(PnfGoParser::ElementListContext *ctx) = 0;
  virtual void exitElementList(PnfGoParser::ElementListContext *ctx) = 0;

  virtual void enterKeyedElement(PnfGoParser::KeyedElementContext *ctx) = 0;
  virtual void exitKeyedElement(PnfGoParser::KeyedElementContext *ctx) = 0;

  virtual void enterKey(PnfGoParser::KeyContext *ctx) = 0;
  virtual void exitKey(PnfGoParser::KeyContext *ctx) = 0;

  virtual void enterElement(PnfGoParser::ElementContext *ctx) = 0;
  virtual void exitElement(PnfGoParser::ElementContext *ctx) = 0;

  virtual void enterStructType(PnfGoParser::StructTypeContext *ctx) = 0;
  virtual void exitStructType(PnfGoParser::StructTypeContext *ctx) = 0;

  virtual void enterFieldDecl(PnfGoParser::FieldDeclContext *ctx) = 0;
  virtual void exitFieldDecl(PnfGoParser::FieldDeclContext *ctx) = 0;

  virtual void enterString_(PnfGoParser::String_Context *ctx) = 0;
  virtual void exitString_(PnfGoParser::String_Context *ctx) = 0;

  virtual void enterAnonymousField(PnfGoParser::AnonymousFieldContext *ctx) = 0;
  virtual void exitAnonymousField(PnfGoParser::AnonymousFieldContext *ctx) = 0;

  virtual void enterFunctionLit(PnfGoParser::FunctionLitContext *ctx) = 0;
  virtual void exitFunctionLit(PnfGoParser::FunctionLitContext *ctx) = 0;

  virtual void enterIndex(PnfGoParser::IndexContext *ctx) = 0;
  virtual void exitIndex(PnfGoParser::IndexContext *ctx) = 0;

  virtual void enterSlice(PnfGoParser::SliceContext *ctx) = 0;
  virtual void exitSlice(PnfGoParser::SliceContext *ctx) = 0;

  virtual void enterTypeAssertion(PnfGoParser::TypeAssertionContext *ctx) = 0;
  virtual void exitTypeAssertion(PnfGoParser::TypeAssertionContext *ctx) = 0;

  virtual void enterArguments(PnfGoParser::ArgumentsContext *ctx) = 0;
  virtual void exitArguments(PnfGoParser::ArgumentsContext *ctx) = 0;

  virtual void enterMethodExpr(PnfGoParser::MethodExprContext *ctx) = 0;
  virtual void exitMethodExpr(PnfGoParser::MethodExprContext *ctx) = 0;

  virtual void enterEos(PnfGoParser::EosContext *ctx) = 0;
  virtual void exitEos(PnfGoParser::EosContext *ctx) = 0;

  virtual void enterAux_rule__sourceFile_1(PnfGoParser::Aux_rule__sourceFile_1Context *ctx) = 0;
  virtual void exitAux_rule__sourceFile_1(PnfGoParser::Aux_rule__sourceFile_1Context *ctx) = 0;

  virtual void enterKleene_star__sourceFile_2(PnfGoParser::Kleene_star__sourceFile_2Context *ctx) = 0;
  virtual void exitKleene_star__sourceFile_2(PnfGoParser::Kleene_star__sourceFile_2Context *ctx) = 0;

  virtual void enterAux_rule__sourceFile_3(PnfGoParser::Aux_rule__sourceFile_3Context *ctx) = 0;
  virtual void exitAux_rule__sourceFile_3(PnfGoParser::Aux_rule__sourceFile_3Context *ctx) = 0;

  virtual void enterKleene_star__sourceFile_4(PnfGoParser::Kleene_star__sourceFile_4Context *ctx) = 0;
  virtual void exitKleene_star__sourceFile_4(PnfGoParser::Kleene_star__sourceFile_4Context *ctx) = 0;

  virtual void enterAux_rule__importDecl_1(PnfGoParser::Aux_rule__importDecl_1Context *ctx) = 0;
  virtual void exitAux_rule__importDecl_1(PnfGoParser::Aux_rule__importDecl_1Context *ctx) = 0;

  virtual void enterKleene_star__importDecl_2(PnfGoParser::Kleene_star__importDecl_2Context *ctx) = 0;
  virtual void exitKleene_star__importDecl_2(PnfGoParser::Kleene_star__importDecl_2Context *ctx) = 0;

  virtual void enterAux_rule__importSpec_1(PnfGoParser::Aux_rule__importSpec_1Context *ctx) = 0;
  virtual void exitAux_rule__importSpec_1(PnfGoParser::Aux_rule__importSpec_1Context *ctx) = 0;

  virtual void enterOptional__importSpec_2(PnfGoParser::Optional__importSpec_2Context *ctx) = 0;
  virtual void exitOptional__importSpec_2(PnfGoParser::Optional__importSpec_2Context *ctx) = 0;

  virtual void enterAux_rule__constDecl_1(PnfGoParser::Aux_rule__constDecl_1Context *ctx) = 0;
  virtual void exitAux_rule__constDecl_1(PnfGoParser::Aux_rule__constDecl_1Context *ctx) = 0;

  virtual void enterKleene_star__constDecl_2(PnfGoParser::Kleene_star__constDecl_2Context *ctx) = 0;
  virtual void exitKleene_star__constDecl_2(PnfGoParser::Kleene_star__constDecl_2Context *ctx) = 0;

  virtual void enterOptional__constSpec_1(PnfGoParser::Optional__constSpec_1Context *ctx) = 0;
  virtual void exitOptional__constSpec_1(PnfGoParser::Optional__constSpec_1Context *ctx) = 0;

  virtual void enterAux_rule__constSpec_2(PnfGoParser::Aux_rule__constSpec_2Context *ctx) = 0;
  virtual void exitAux_rule__constSpec_2(PnfGoParser::Aux_rule__constSpec_2Context *ctx) = 0;

  virtual void enterOptional__constSpec_3(PnfGoParser::Optional__constSpec_3Context *ctx) = 0;
  virtual void exitOptional__constSpec_3(PnfGoParser::Optional__constSpec_3Context *ctx) = 0;

  virtual void enterAux_rule__identifierList_1(PnfGoParser::Aux_rule__identifierList_1Context *ctx) = 0;
  virtual void exitAux_rule__identifierList_1(PnfGoParser::Aux_rule__identifierList_1Context *ctx) = 0;

  virtual void enterKleene_star__identifierList_2(PnfGoParser::Kleene_star__identifierList_2Context *ctx) = 0;
  virtual void exitKleene_star__identifierList_2(PnfGoParser::Kleene_star__identifierList_2Context *ctx) = 0;

  virtual void enterAux_rule__expressionList_1(PnfGoParser::Aux_rule__expressionList_1Context *ctx) = 0;
  virtual void exitAux_rule__expressionList_1(PnfGoParser::Aux_rule__expressionList_1Context *ctx) = 0;

  virtual void enterKleene_star__expressionList_2(PnfGoParser::Kleene_star__expressionList_2Context *ctx) = 0;
  virtual void exitKleene_star__expressionList_2(PnfGoParser::Kleene_star__expressionList_2Context *ctx) = 0;

  virtual void enterAux_rule__typeDecl_1(PnfGoParser::Aux_rule__typeDecl_1Context *ctx) = 0;
  virtual void exitAux_rule__typeDecl_1(PnfGoParser::Aux_rule__typeDecl_1Context *ctx) = 0;

  virtual void enterKleene_star__typeDecl_2(PnfGoParser::Kleene_star__typeDecl_2Context *ctx) = 0;
  virtual void exitKleene_star__typeDecl_2(PnfGoParser::Kleene_star__typeDecl_2Context *ctx) = 0;

  virtual void enterOptional__typeSpec_1(PnfGoParser::Optional__typeSpec_1Context *ctx) = 0;
  virtual void exitOptional__typeSpec_1(PnfGoParser::Optional__typeSpec_1Context *ctx) = 0;

  virtual void enterOptional__functionDecl_1(PnfGoParser::Optional__functionDecl_1Context *ctx) = 0;
  virtual void exitOptional__functionDecl_1(PnfGoParser::Optional__functionDecl_1Context *ctx) = 0;

  virtual void enterAux_rule__varDecl_1(PnfGoParser::Aux_rule__varDecl_1Context *ctx) = 0;
  virtual void exitAux_rule__varDecl_1(PnfGoParser::Aux_rule__varDecl_1Context *ctx) = 0;

  virtual void enterKleene_star__varDecl_2(PnfGoParser::Kleene_star__varDecl_2Context *ctx) = 0;
  virtual void exitKleene_star__varDecl_2(PnfGoParser::Kleene_star__varDecl_2Context *ctx) = 0;

  virtual void enterAux_rule__varSpec_1(PnfGoParser::Aux_rule__varSpec_1Context *ctx) = 0;
  virtual void exitAux_rule__varSpec_1(PnfGoParser::Aux_rule__varSpec_1Context *ctx) = 0;

  virtual void enterOptional__varSpec_2(PnfGoParser::Optional__varSpec_2Context *ctx) = 0;
  virtual void exitOptional__varSpec_2(PnfGoParser::Optional__varSpec_2Context *ctx) = 0;

  virtual void enterOptional__block_1(PnfGoParser::Optional__block_1Context *ctx) = 0;
  virtual void exitOptional__block_1(PnfGoParser::Optional__block_1Context *ctx) = 0;

  virtual void enterAux_rule__statementList_1(PnfGoParser::Aux_rule__statementList_1Context *ctx) = 0;
  virtual void exitAux_rule__statementList_1(PnfGoParser::Aux_rule__statementList_1Context *ctx) = 0;

  virtual void enterAux_rule__assign_op_1(PnfGoParser::Aux_rule__assign_op_1Context *ctx) = 0;
  virtual void exitAux_rule__assign_op_1(PnfGoParser::Aux_rule__assign_op_1Context *ctx) = 0;

  virtual void enterOptional__assign_op_2(PnfGoParser::Optional__assign_op_2Context *ctx) = 0;
  virtual void exitOptional__assign_op_2(PnfGoParser::Optional__assign_op_2Context *ctx) = 0;

  virtual void enterOptional__returnStmt_1(PnfGoParser::Optional__returnStmt_1Context *ctx) = 0;
  virtual void exitOptional__returnStmt_1(PnfGoParser::Optional__returnStmt_1Context *ctx) = 0;

  virtual void enterOptional__breakStmt_1(PnfGoParser::Optional__breakStmt_1Context *ctx) = 0;
  virtual void exitOptional__breakStmt_1(PnfGoParser::Optional__breakStmt_1Context *ctx) = 0;

  virtual void enterAux_rule__ifStmt_1(PnfGoParser::Aux_rule__ifStmt_1Context *ctx) = 0;
  virtual void exitAux_rule__ifStmt_1(PnfGoParser::Aux_rule__ifStmt_1Context *ctx) = 0;

  virtual void enterOptional__ifStmt_2(PnfGoParser::Optional__ifStmt_2Context *ctx) = 0;
  virtual void exitOptional__ifStmt_2(PnfGoParser::Optional__ifStmt_2Context *ctx) = 0;

  virtual void enterAux_rule__ifStmt_3(PnfGoParser::Aux_rule__ifStmt_3Context *ctx) = 0;
  virtual void exitAux_rule__ifStmt_3(PnfGoParser::Aux_rule__ifStmt_3Context *ctx) = 0;

  virtual void enterOptional__ifStmt_4(PnfGoParser::Optional__ifStmt_4Context *ctx) = 0;
  virtual void exitOptional__ifStmt_4(PnfGoParser::Optional__ifStmt_4Context *ctx) = 0;

  virtual void enterOptional__exprSwitchStmt_3(PnfGoParser::Optional__exprSwitchStmt_3Context *ctx) = 0;
  virtual void exitOptional__exprSwitchStmt_3(PnfGoParser::Optional__exprSwitchStmt_3Context *ctx) = 0;

  virtual void enterKleene_star__exprSwitchStmt_4(PnfGoParser::Kleene_star__exprSwitchStmt_4Context *ctx) = 0;
  virtual void exitKleene_star__exprSwitchStmt_4(PnfGoParser::Kleene_star__exprSwitchStmt_4Context *ctx) = 0;

  virtual void enterKleene_star__typeSwitchStmt_3(PnfGoParser::Kleene_star__typeSwitchStmt_3Context *ctx) = 0;
  virtual void exitKleene_star__typeSwitchStmt_3(PnfGoParser::Kleene_star__typeSwitchStmt_3Context *ctx) = 0;

  virtual void enterAux_rule__typeSwitchGuard_1(PnfGoParser::Aux_rule__typeSwitchGuard_1Context *ctx) = 0;
  virtual void exitAux_rule__typeSwitchGuard_1(PnfGoParser::Aux_rule__typeSwitchGuard_1Context *ctx) = 0;

  virtual void enterOptional__typeSwitchGuard_2(PnfGoParser::Optional__typeSwitchGuard_2Context *ctx) = 0;
  virtual void exitOptional__typeSwitchGuard_2(PnfGoParser::Optional__typeSwitchGuard_2Context *ctx) = 0;

  virtual void enterAux_rule__typeList_1(PnfGoParser::Aux_rule__typeList_1Context *ctx) = 0;
  virtual void exitAux_rule__typeList_1(PnfGoParser::Aux_rule__typeList_1Context *ctx) = 0;

  virtual void enterKleene_star__typeList_2(PnfGoParser::Kleene_star__typeList_2Context *ctx) = 0;
  virtual void exitKleene_star__typeList_2(PnfGoParser::Kleene_star__typeList_2Context *ctx) = 0;

  virtual void enterKleene_star__selectStmt_1(PnfGoParser::Kleene_star__selectStmt_1Context *ctx) = 0;
  virtual void exitKleene_star__selectStmt_1(PnfGoParser::Kleene_star__selectStmt_1Context *ctx) = 0;

  virtual void enterAux_rule__recvStmt_1(PnfGoParser::Aux_rule__recvStmt_1Context *ctx) = 0;
  virtual void exitAux_rule__recvStmt_1(PnfGoParser::Aux_rule__recvStmt_1Context *ctx) = 0;

  virtual void enterOptional__recvStmt_2(PnfGoParser::Optional__recvStmt_2Context *ctx) = 0;
  virtual void exitOptional__recvStmt_2(PnfGoParser::Optional__recvStmt_2Context *ctx) = 0;

  virtual void enterAux_rule__forStmt_1(PnfGoParser::Aux_rule__forStmt_1Context *ctx) = 0;
  virtual void exitAux_rule__forStmt_1(PnfGoParser::Aux_rule__forStmt_1Context *ctx) = 0;

  virtual void enterOptional__forStmt_2(PnfGoParser::Optional__forStmt_2Context *ctx) = 0;
  virtual void exitOptional__forStmt_2(PnfGoParser::Optional__forStmt_2Context *ctx) = 0;

  virtual void enterOptional__forClause_1(PnfGoParser::Optional__forClause_1Context *ctx) = 0;
  virtual void exitOptional__forClause_1(PnfGoParser::Optional__forClause_1Context *ctx) = 0;

  virtual void enterAux_rule__interfaceType_1(PnfGoParser::Aux_rule__interfaceType_1Context *ctx) = 0;
  virtual void exitAux_rule__interfaceType_1(PnfGoParser::Aux_rule__interfaceType_1Context *ctx) = 0;

  virtual void enterKleene_star__interfaceType_2(PnfGoParser::Kleene_star__interfaceType_2Context *ctx) = 0;
  virtual void exitKleene_star__interfaceType_2(PnfGoParser::Kleene_star__interfaceType_2Context *ctx) = 0;

  virtual void enterAux_rule__parameters_1(PnfGoParser::Aux_rule__parameters_1Context *ctx) = 0;
  virtual void exitAux_rule__parameters_1(PnfGoParser::Aux_rule__parameters_1Context *ctx) = 0;

  virtual void enterKleene_star__parameters_2(PnfGoParser::Kleene_star__parameters_2Context *ctx) = 0;
  virtual void exitKleene_star__parameters_2(PnfGoParser::Kleene_star__parameters_2Context *ctx) = 0;

  virtual void enterOptional__parameters_3(PnfGoParser::Optional__parameters_3Context *ctx) = 0;
  virtual void exitOptional__parameters_3(PnfGoParser::Optional__parameters_3Context *ctx) = 0;

  virtual void enterAux_rule__parameters_4(PnfGoParser::Aux_rule__parameters_4Context *ctx) = 0;
  virtual void exitAux_rule__parameters_4(PnfGoParser::Aux_rule__parameters_4Context *ctx) = 0;

  virtual void enterOptional__parameters_5(PnfGoParser::Optional__parameters_5Context *ctx) = 0;
  virtual void exitOptional__parameters_5(PnfGoParser::Optional__parameters_5Context *ctx) = 0;

  virtual void enterOptional__parameterDecl_1(PnfGoParser::Optional__parameterDecl_1Context *ctx) = 0;
  virtual void exitOptional__parameterDecl_1(PnfGoParser::Optional__parameterDecl_1Context *ctx) = 0;

  virtual void enterOptional__parameterDecl_2(PnfGoParser::Optional__parameterDecl_2Context *ctx) = 0;
  virtual void exitOptional__parameterDecl_2(PnfGoParser::Optional__parameterDecl_2Context *ctx) = 0;

  virtual void enterOptional__conversion_1(PnfGoParser::Optional__conversion_1Context *ctx) = 0;
  virtual void exitOptional__conversion_1(PnfGoParser::Optional__conversion_1Context *ctx) = 0;

  virtual void enterAux_rule__literalValue_2(PnfGoParser::Aux_rule__literalValue_2Context *ctx) = 0;
  virtual void exitAux_rule__literalValue_2(PnfGoParser::Aux_rule__literalValue_2Context *ctx) = 0;

  virtual void enterOptional__literalValue_3(PnfGoParser::Optional__literalValue_3Context *ctx) = 0;
  virtual void exitOptional__literalValue_3(PnfGoParser::Optional__literalValue_3Context *ctx) = 0;

  virtual void enterAux_rule__elementList_1(PnfGoParser::Aux_rule__elementList_1Context *ctx) = 0;
  virtual void exitAux_rule__elementList_1(PnfGoParser::Aux_rule__elementList_1Context *ctx) = 0;

  virtual void enterKleene_star__elementList_2(PnfGoParser::Kleene_star__elementList_2Context *ctx) = 0;
  virtual void exitKleene_star__elementList_2(PnfGoParser::Kleene_star__elementList_2Context *ctx) = 0;

  virtual void enterAux_rule__keyedElement_1(PnfGoParser::Aux_rule__keyedElement_1Context *ctx) = 0;
  virtual void exitAux_rule__keyedElement_1(PnfGoParser::Aux_rule__keyedElement_1Context *ctx) = 0;

  virtual void enterOptional__keyedElement_2(PnfGoParser::Optional__keyedElement_2Context *ctx) = 0;
  virtual void exitOptional__keyedElement_2(PnfGoParser::Optional__keyedElement_2Context *ctx) = 0;

  virtual void enterAux_rule__structType_1(PnfGoParser::Aux_rule__structType_1Context *ctx) = 0;
  virtual void exitAux_rule__structType_1(PnfGoParser::Aux_rule__structType_1Context *ctx) = 0;

  virtual void enterKleene_star__structType_2(PnfGoParser::Kleene_star__structType_2Context *ctx) = 0;
  virtual void exitKleene_star__structType_2(PnfGoParser::Kleene_star__structType_2Context *ctx) = 0;

  virtual void enterOptional__fieldDecl_1(PnfGoParser::Optional__fieldDecl_1Context *ctx) = 0;
  virtual void exitOptional__fieldDecl_1(PnfGoParser::Optional__fieldDecl_1Context *ctx) = 0;

  virtual void enterOptional__anonymousField_1(PnfGoParser::Optional__anonymousField_1Context *ctx) = 0;
  virtual void exitOptional__anonymousField_1(PnfGoParser::Optional__anonymousField_1Context *ctx) = 0;

  virtual void enterAux_rule__arguments_1(PnfGoParser::Aux_rule__arguments_1Context *ctx) = 0;
  virtual void exitAux_rule__arguments_1(PnfGoParser::Aux_rule__arguments_1Context *ctx) = 0;

  virtual void enterOptional__arguments_2(PnfGoParser::Optional__arguments_2Context *ctx) = 0;
  virtual void exitOptional__arguments_2(PnfGoParser::Optional__arguments_2Context *ctx) = 0;

  virtual void enterAux_rule__arguments_5(PnfGoParser::Aux_rule__arguments_5Context *ctx) = 0;
  virtual void exitAux_rule__arguments_5(PnfGoParser::Aux_rule__arguments_5Context *ctx) = 0;

  virtual void enterOptional__arguments_6(PnfGoParser::Optional__arguments_6Context *ctx) = 0;
  virtual void exitOptional__arguments_6(PnfGoParser::Optional__arguments_6Context *ctx) = 0;

  virtual void enterAux_rule__expression_2(PnfGoParser::Aux_rule__expression_2Context *ctx) = 0;
  virtual void exitAux_rule__expression_2(PnfGoParser::Aux_rule__expression_2Context *ctx) = 0;

  virtual void enterKleene_star__expression_1(PnfGoParser::Kleene_star__expression_1Context *ctx) = 0;
  virtual void exitKleene_star__expression_1(PnfGoParser::Kleene_star__expression_1Context *ctx) = 0;

  virtual void enterExpression(PnfGoParser::ExpressionContext *ctx) = 0;
  virtual void exitExpression(PnfGoParser::ExpressionContext *ctx) = 0;

  virtual void enterAux_rule__primaryExpr_2(PnfGoParser::Aux_rule__primaryExpr_2Context *ctx) = 0;
  virtual void exitAux_rule__primaryExpr_2(PnfGoParser::Aux_rule__primaryExpr_2Context *ctx) = 0;

  virtual void enterKleene_star__primaryExpr_1(PnfGoParser::Kleene_star__primaryExpr_1Context *ctx) = 0;
  virtual void exitKleene_star__primaryExpr_1(PnfGoParser::Kleene_star__primaryExpr_1Context *ctx) = 0;

  virtual void enterPrimaryExpr(PnfGoParser::PrimaryExprContext *ctx) = 0;
  virtual void exitPrimaryExpr(PnfGoParser::PrimaryExprContext *ctx) = 0;

  virtual void enterOptional__signature_1(PnfGoParser::Optional__signature_1Context *ctx) = 0;
  virtual void exitOptional__signature_1(PnfGoParser::Optional__signature_1Context *ctx) = 0;

  virtual void enterAltnt_block__expression_3(PnfGoParser::Altnt_block__expression_3Context *ctx) = 0;
  virtual void exitAltnt_block__expression_3(PnfGoParser::Altnt_block__expression_3Context *ctx) = 0;

  virtual void enterType_(PnfGoParser::Type_Context *ctx) = 0;
  virtual void exitType_(PnfGoParser::Type_Context *ctx) = 0;

  virtual void enterRealStatement(PnfGoParser::RealStatementContext *ctx) = 0;
  virtual void exitRealStatement(PnfGoParser::RealStatementContext *ctx) = 0;

  virtual void enterAltnt_block__importDecl_3(PnfGoParser::Altnt_block__importDecl_3Context *ctx) = 0;
  virtual void exitAltnt_block__importDecl_3(PnfGoParser::Altnt_block__importDecl_3Context *ctx) = 0;

  virtual void enterAltnt_block__constDecl_3(PnfGoParser::Altnt_block__constDecl_3Context *ctx) = 0;
  virtual void exitAltnt_block__constDecl_3(PnfGoParser::Altnt_block__constDecl_3Context *ctx) = 0;

  virtual void enterAltnt_block__typeDecl_3(PnfGoParser::Altnt_block__typeDecl_3Context *ctx) = 0;
  virtual void exitAltnt_block__typeDecl_3(PnfGoParser::Altnt_block__typeDecl_3Context *ctx) = 0;

  virtual void enterAltnt_block__varDecl_3(PnfGoParser::Altnt_block__varDecl_3Context *ctx) = 0;
  virtual void exitAltnt_block__varDecl_3(PnfGoParser::Altnt_block__varDecl_3Context *ctx) = 0;

  virtual void enterAltnt_block__varSpec_3(PnfGoParser::Altnt_block__varSpec_3Context *ctx) = 0;
  virtual void exitAltnt_block__varSpec_3(PnfGoParser::Altnt_block__varSpec_3Context *ctx) = 0;

  virtual void enterAltnt_block__incDecStmt_1(PnfGoParser::Altnt_block__incDecStmt_1Context *ctx) = 0;
  virtual void exitAltnt_block__incDecStmt_1(PnfGoParser::Altnt_block__incDecStmt_1Context *ctx) = 0;

  virtual void enterAltnt_block__typeList_3(PnfGoParser::Altnt_block__typeList_3Context *ctx) = 0;
  virtual void exitAltnt_block__typeList_3(PnfGoParser::Altnt_block__typeList_3Context *ctx) = 0;

  virtual void enterAltnt_block__commCase_1(PnfGoParser::Altnt_block__commCase_1Context *ctx) = 0;
  virtual void exitAltnt_block__commCase_1(PnfGoParser::Altnt_block__commCase_1Context *ctx) = 0;

  virtual void enterAltnt_block__channelType_1(PnfGoParser::Altnt_block__channelType_1Context *ctx) = 0;
  virtual void exitAltnt_block__channelType_1(PnfGoParser::Altnt_block__channelType_1Context *ctx) = 0;

  virtual void enterAltnt_block__unaryExpr_1(PnfGoParser::Altnt_block__unaryExpr_1Context *ctx) = 0;
  virtual void exitAltnt_block__unaryExpr_1(PnfGoParser::Altnt_block__unaryExpr_1Context *ctx) = 0;

  virtual void enterAltnt_block__fieldDecl_2(PnfGoParser::Altnt_block__fieldDecl_2Context *ctx) = 0;
  virtual void exitAltnt_block__fieldDecl_2(PnfGoParser::Altnt_block__fieldDecl_2Context *ctx) = 0;

  virtual void enterAltnt_block__slice_4(PnfGoParser::Altnt_block__slice_4Context *ctx) = 0;
  virtual void exitAltnt_block__slice_4(PnfGoParser::Altnt_block__slice_4Context *ctx) = 0;

  virtual void enterAltnt_block__sourceFile_5(PnfGoParser::Altnt_block__sourceFile_5Context *ctx) = 0;
  virtual void exitAltnt_block__sourceFile_5(PnfGoParser::Altnt_block__sourceFile_5Context *ctx) = 0;

  virtual void enterAltnt_block__ifStmt_5(PnfGoParser::Altnt_block__ifStmt_5Context *ctx) = 0;
  virtual void exitAltnt_block__ifStmt_5(PnfGoParser::Altnt_block__ifStmt_5Context *ctx) = 0;

  virtual void enterAltnt_block__arguments_7(PnfGoParser::Altnt_block__arguments_7Context *ctx) = 0;
  virtual void exitAltnt_block__arguments_7(PnfGoParser::Altnt_block__arguments_7Context *ctx) = 0;

  virtual void enterOptional__channelType_2(PnfGoParser::Optional__channelType_2Context *ctx) = 0;
  virtual void exitOptional__channelType_2(PnfGoParser::Optional__channelType_2Context *ctx) = 0;

  virtual void enterAltnt_block__slice_5(PnfGoParser::Altnt_block__slice_5Context *ctx) = 0;
  virtual void exitAltnt_block__slice_5(PnfGoParser::Altnt_block__slice_5Context *ctx) = 0;

  virtual void enterAux_rule__primaryExpr_3(PnfGoParser::Aux_rule__primaryExpr_3Context *ctx) = 0;
  virtual void exitAux_rule__primaryExpr_3(PnfGoParser::Aux_rule__primaryExpr_3Context *ctx) = 0;

  virtual void enterAux_rule__sourceFile_6(PnfGoParser::Aux_rule__sourceFile_6Context *ctx) = 0;
  virtual void exitAux_rule__sourceFile_6(PnfGoParser::Aux_rule__sourceFile_6Context *ctx) = 0;

  virtual void enterAux_rule__exprSwitchCase_1(PnfGoParser::Aux_rule__exprSwitchCase_1Context *ctx) = 0;
  virtual void exitAux_rule__exprSwitchCase_1(PnfGoParser::Aux_rule__exprSwitchCase_1Context *ctx) = 0;

  virtual void enterAux_rule__typeSwitchCase_1(PnfGoParser::Aux_rule__typeSwitchCase_1Context *ctx) = 0;
  virtual void exitAux_rule__typeSwitchCase_1(PnfGoParser::Aux_rule__typeSwitchCase_1Context *ctx) = 0;

  virtual void enterAux_rule__commCase_2(PnfGoParser::Aux_rule__commCase_2Context *ctx) = 0;
  virtual void exitAux_rule__commCase_2(PnfGoParser::Aux_rule__commCase_2Context *ctx) = 0;

  virtual void enterAux_rule__methodSpec_2(PnfGoParser::Aux_rule__methodSpec_2Context *ctx) = 0;
  virtual void exitAux_rule__methodSpec_2(PnfGoParser::Aux_rule__methodSpec_2Context *ctx) = 0;

  virtual void enterAux_rule__unaryExpr_2(PnfGoParser::Aux_rule__unaryExpr_2Context *ctx) = 0;
  virtual void exitAux_rule__unaryExpr_2(PnfGoParser::Aux_rule__unaryExpr_2Context *ctx) = 0;

  virtual void enterAux_rule__literalType_1(PnfGoParser::Aux_rule__literalType_1Context *ctx) = 0;
  virtual void exitAux_rule__literalType_1(PnfGoParser::Aux_rule__literalType_1Context *ctx) = 0;

  virtual void enterAux_rule__eos_1(PnfGoParser::Aux_rule__eos_1Context *ctx) = 0;
  virtual void exitAux_rule__eos_1(PnfGoParser::Aux_rule__eos_1Context *ctx) = 0;

  virtual void enterAux_rule__eos_2(PnfGoParser::Aux_rule__eos_2Context *ctx) = 0;
  virtual void exitAux_rule__eos_2(PnfGoParser::Aux_rule__eos_2Context *ctx) = 0;

  virtual void enterAux_rule__statementList_2(PnfGoParser::Aux_rule__statementList_2Context *ctx) = 0;
  virtual void exitAux_rule__statementList_2(PnfGoParser::Aux_rule__statementList_2Context *ctx) = 0;

  virtual void enterAux_rule__recvStmt_3(PnfGoParser::Aux_rule__recvStmt_3Context *ctx) = 0;
  virtual void exitAux_rule__recvStmt_3(PnfGoParser::Aux_rule__recvStmt_3Context *ctx) = 0;

  virtual void enterAux_rule__recvStmt_4(PnfGoParser::Aux_rule__recvStmt_4Context *ctx) = 0;
  virtual void exitAux_rule__recvStmt_4(PnfGoParser::Aux_rule__recvStmt_4Context *ctx) = 0;

  virtual void enterAux_rule__primaryExpr_4(PnfGoParser::Aux_rule__primaryExpr_4Context *ctx) = 0;
  virtual void exitAux_rule__primaryExpr_4(PnfGoParser::Aux_rule__primaryExpr_4Context *ctx) = 0;

  virtual void enterAux_rule__type__1(PnfGoParser::Aux_rule__type__1Context *ctx) = 0;
  virtual void exitAux_rule__type__1(PnfGoParser::Aux_rule__type__1Context *ctx) = 0;

  virtual void enterAux_rule__importDecl_4(PnfGoParser::Aux_rule__importDecl_4Context *ctx) = 0;
  virtual void exitAux_rule__importDecl_4(PnfGoParser::Aux_rule__importDecl_4Context *ctx) = 0;

  virtual void enterAux_rule__constDecl_4(PnfGoParser::Aux_rule__constDecl_4Context *ctx) = 0;
  virtual void exitAux_rule__constDecl_4(PnfGoParser::Aux_rule__constDecl_4Context *ctx) = 0;

  virtual void enterAux_rule__typeDecl_4(PnfGoParser::Aux_rule__typeDecl_4Context *ctx) = 0;
  virtual void exitAux_rule__typeDecl_4(PnfGoParser::Aux_rule__typeDecl_4Context *ctx) = 0;

  virtual void enterAux_rule__varDecl_4(PnfGoParser::Aux_rule__varDecl_4Context *ctx) = 0;
  virtual void exitAux_rule__varDecl_4(PnfGoParser::Aux_rule__varDecl_4Context *ctx) = 0;

  virtual void enterAux_rule__varSpec_4(PnfGoParser::Aux_rule__varSpec_4Context *ctx) = 0;
  virtual void exitAux_rule__varSpec_4(PnfGoParser::Aux_rule__varSpec_4Context *ctx) = 0;

  virtual void enterAux_rule__varSpec_5(PnfGoParser::Aux_rule__varSpec_5Context *ctx) = 0;
  virtual void exitAux_rule__varSpec_5(PnfGoParser::Aux_rule__varSpec_5Context *ctx) = 0;

  virtual void enterAux_rule__channelType_3(PnfGoParser::Aux_rule__channelType_3Context *ctx) = 0;
  virtual void exitAux_rule__channelType_3(PnfGoParser::Aux_rule__channelType_3Context *ctx) = 0;

  virtual void enterAux_rule__channelType_4(PnfGoParser::Aux_rule__channelType_4Context *ctx) = 0;
  virtual void exitAux_rule__channelType_4(PnfGoParser::Aux_rule__channelType_4Context *ctx) = 0;

  virtual void enterAux_rule__fieldDecl_3(PnfGoParser::Aux_rule__fieldDecl_3Context *ctx) = 0;
  virtual void exitAux_rule__fieldDecl_3(PnfGoParser::Aux_rule__fieldDecl_3Context *ctx) = 0;

  virtual void enterAux_rule__arguments_8(PnfGoParser::Aux_rule__arguments_8Context *ctx) = 0;
  virtual void exitAux_rule__arguments_8(PnfGoParser::Aux_rule__arguments_8Context *ctx) = 0;

  virtual void enterAux_rule__slice_6(PnfGoParser::Aux_rule__slice_6Context *ctx) = 0;
  virtual void exitAux_rule__slice_6(PnfGoParser::Aux_rule__slice_6Context *ctx) = 0;

  virtual void enterAux_rule__primaryExpr_5(PnfGoParser::Aux_rule__primaryExpr_5Context *ctx) = 0;
  virtual void exitAux_rule__primaryExpr_5(PnfGoParser::Aux_rule__primaryExpr_5Context *ctx) = 0;


};

}  // namespace antlr_go_perses
