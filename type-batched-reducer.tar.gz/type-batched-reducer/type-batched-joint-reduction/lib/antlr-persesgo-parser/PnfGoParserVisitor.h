
// Generated from PnfGoParser.g4 by ANTLR 4.7.2

#pragma once


#include "antlr4-runtime.h"
#include "PnfGoParser.h"


namespace antlr_go_perses {

/**
 * This class defines an abstract visitor for a parse tree
 * produced by PnfGoParser.
 */
class  PnfGoParserVisitor : public antlr4::tree::AbstractParseTreeVisitor {
public:

  /**
   * Visit parse trees produced by PnfGoParser.
   */
    virtual antlrcpp::Any visitSourceFile(PnfGoParser::SourceFileContext *context) = 0;

    virtual antlrcpp::Any visitPackageClause(PnfGoParser::PackageClauseContext *context) = 0;

    virtual antlrcpp::Any visitImportDecl(PnfGoParser::ImportDeclContext *context) = 0;

    virtual antlrcpp::Any visitImportSpec(PnfGoParser::ImportSpecContext *context) = 0;

    virtual antlrcpp::Any visitImportPath(PnfGoParser::ImportPathContext *context) = 0;

    virtual antlrcpp::Any visitDeclaration(PnfGoParser::DeclarationContext *context) = 0;

    virtual antlrcpp::Any visitConstDecl(PnfGoParser::ConstDeclContext *context) = 0;

    virtual antlrcpp::Any visitConstSpec(PnfGoParser::ConstSpecContext *context) = 0;

    virtual antlrcpp::Any visitIdentifierList(PnfGoParser::IdentifierListContext *context) = 0;

    virtual antlrcpp::Any visitExpressionList(PnfGoParser::ExpressionListContext *context) = 0;

    virtual antlrcpp::Any visitTypeDecl(PnfGoParser::TypeDeclContext *context) = 0;

    virtual antlrcpp::Any visitTypeSpec(PnfGoParser::TypeSpecContext *context) = 0;

    virtual antlrcpp::Any visitFunctionDecl(PnfGoParser::FunctionDeclContext *context) = 0;

    virtual antlrcpp::Any visitMethodDecl(PnfGoParser::MethodDeclContext *context) = 0;

    virtual antlrcpp::Any visitReceiver(PnfGoParser::ReceiverContext *context) = 0;

    virtual antlrcpp::Any visitVarDecl(PnfGoParser::VarDeclContext *context) = 0;

    virtual antlrcpp::Any visitVarSpec(PnfGoParser::VarSpecContext *context) = 0;

    virtual antlrcpp::Any visitBlock(PnfGoParser::BlockContext *context) = 0;

    virtual antlrcpp::Any visitStatementList(PnfGoParser::StatementListContext *context) = 0;

    virtual antlrcpp::Any visitStatement(PnfGoParser::StatementContext *context) = 0;

    virtual antlrcpp::Any visitSimpleStmt(PnfGoParser::SimpleStmtContext *context) = 0;

    virtual antlrcpp::Any visitRealSimpleStmt(PnfGoParser::RealSimpleStmtContext *context) = 0;

    virtual antlrcpp::Any visitExpressionStmt(PnfGoParser::ExpressionStmtContext *context) = 0;

    virtual antlrcpp::Any visitSendStmt(PnfGoParser::SendStmtContext *context) = 0;

    virtual antlrcpp::Any visitIncDecStmt(PnfGoParser::IncDecStmtContext *context) = 0;

    virtual antlrcpp::Any visitAssignment(PnfGoParser::AssignmentContext *context) = 0;

    virtual antlrcpp::Any visitAssign_op(PnfGoParser::Assign_opContext *context) = 0;

    virtual antlrcpp::Any visitShortVarDecl(PnfGoParser::ShortVarDeclContext *context) = 0;

    virtual antlrcpp::Any visitLabeledStmt(PnfGoParser::LabeledStmtContext *context) = 0;

    virtual antlrcpp::Any visitReturnStmt(PnfGoParser::ReturnStmtContext *context) = 0;

    virtual antlrcpp::Any visitBreakStmt(PnfGoParser::BreakStmtContext *context) = 0;

    virtual antlrcpp::Any visitContinueStmt(PnfGoParser::ContinueStmtContext *context) = 0;

    virtual antlrcpp::Any visitGotoStmt(PnfGoParser::GotoStmtContext *context) = 0;

    virtual antlrcpp::Any visitFallthroughStmt(PnfGoParser::FallthroughStmtContext *context) = 0;

    virtual antlrcpp::Any visitDeferStmt(PnfGoParser::DeferStmtContext *context) = 0;

    virtual antlrcpp::Any visitIfStmt(PnfGoParser::IfStmtContext *context) = 0;

    virtual antlrcpp::Any visitExprSwitchStmt(PnfGoParser::ExprSwitchStmtContext *context) = 0;

    virtual antlrcpp::Any visitExprCaseClause(PnfGoParser::ExprCaseClauseContext *context) = 0;

    virtual antlrcpp::Any visitExprSwitchCase(PnfGoParser::ExprSwitchCaseContext *context) = 0;

    virtual antlrcpp::Any visitTypeSwitchStmt(PnfGoParser::TypeSwitchStmtContext *context) = 0;

    virtual antlrcpp::Any visitTypeSwitchGuard(PnfGoParser::TypeSwitchGuardContext *context) = 0;

    virtual antlrcpp::Any visitTypeCaseClause(PnfGoParser::TypeCaseClauseContext *context) = 0;

    virtual antlrcpp::Any visitTypeSwitchCase(PnfGoParser::TypeSwitchCaseContext *context) = 0;

    virtual antlrcpp::Any visitTypeList(PnfGoParser::TypeListContext *context) = 0;

    virtual antlrcpp::Any visitSelectStmt(PnfGoParser::SelectStmtContext *context) = 0;

    virtual antlrcpp::Any visitCommClause(PnfGoParser::CommClauseContext *context) = 0;

    virtual antlrcpp::Any visitCommCase(PnfGoParser::CommCaseContext *context) = 0;

    virtual antlrcpp::Any visitRecvStmt(PnfGoParser::RecvStmtContext *context) = 0;

    virtual antlrcpp::Any visitForStmt(PnfGoParser::ForStmtContext *context) = 0;

    virtual antlrcpp::Any visitForClause(PnfGoParser::ForClauseContext *context) = 0;

    virtual antlrcpp::Any visitRangeClause(PnfGoParser::RangeClauseContext *context) = 0;

    virtual antlrcpp::Any visitGoStmt(PnfGoParser::GoStmtContext *context) = 0;

    virtual antlrcpp::Any visitTypeName(PnfGoParser::TypeNameContext *context) = 0;

    virtual antlrcpp::Any visitArrayType(PnfGoParser::ArrayTypeContext *context) = 0;

    virtual antlrcpp::Any visitElementType(PnfGoParser::ElementTypeContext *context) = 0;

    virtual antlrcpp::Any visitPointerType(PnfGoParser::PointerTypeContext *context) = 0;

    virtual antlrcpp::Any visitInterfaceType(PnfGoParser::InterfaceTypeContext *context) = 0;

    virtual antlrcpp::Any visitSliceType(PnfGoParser::SliceTypeContext *context) = 0;

    virtual antlrcpp::Any visitMapType(PnfGoParser::MapTypeContext *context) = 0;

    virtual antlrcpp::Any visitChannelType(PnfGoParser::ChannelTypeContext *context) = 0;

    virtual antlrcpp::Any visitMethodSpec(PnfGoParser::MethodSpecContext *context) = 0;

    virtual antlrcpp::Any visitFunctionType(PnfGoParser::FunctionTypeContext *context) = 0;

    virtual antlrcpp::Any visitSignature(PnfGoParser::SignatureContext *context) = 0;

    virtual antlrcpp::Any visitResult(PnfGoParser::ResultContext *context) = 0;

    virtual antlrcpp::Any visitParameters(PnfGoParser::ParametersContext *context) = 0;

    virtual antlrcpp::Any visitParameterDecl(PnfGoParser::ParameterDeclContext *context) = 0;

    virtual antlrcpp::Any visitUnaryExpr(PnfGoParser::UnaryExprContext *context) = 0;

    virtual antlrcpp::Any visitConversion(PnfGoParser::ConversionContext *context) = 0;

    virtual antlrcpp::Any visitQualifiedIdent(PnfGoParser::QualifiedIdentContext *context) = 0;

    virtual antlrcpp::Any visitCompositeLit(PnfGoParser::CompositeLitContext *context) = 0;

    virtual antlrcpp::Any visitLiteralType(PnfGoParser::LiteralTypeContext *context) = 0;

    virtual antlrcpp::Any visitLiteralValue(PnfGoParser::LiteralValueContext *context) = 0;

    virtual antlrcpp::Any visitElementList(PnfGoParser::ElementListContext *context) = 0;

    virtual antlrcpp::Any visitKeyedElement(PnfGoParser::KeyedElementContext *context) = 0;

    virtual antlrcpp::Any visitKey(PnfGoParser::KeyContext *context) = 0;

    virtual antlrcpp::Any visitElement(PnfGoParser::ElementContext *context) = 0;

    virtual antlrcpp::Any visitStructType(PnfGoParser::StructTypeContext *context) = 0;

    virtual antlrcpp::Any visitFieldDecl(PnfGoParser::FieldDeclContext *context) = 0;

    virtual antlrcpp::Any visitString_(PnfGoParser::String_Context *context) = 0;

    virtual antlrcpp::Any visitAnonymousField(PnfGoParser::AnonymousFieldContext *context) = 0;

    virtual antlrcpp::Any visitFunctionLit(PnfGoParser::FunctionLitContext *context) = 0;

    virtual antlrcpp::Any visitIndex(PnfGoParser::IndexContext *context) = 0;

    virtual antlrcpp::Any visitSlice(PnfGoParser::SliceContext *context) = 0;

    virtual antlrcpp::Any visitTypeAssertion(PnfGoParser::TypeAssertionContext *context) = 0;

    virtual antlrcpp::Any visitArguments(PnfGoParser::ArgumentsContext *context) = 0;

    virtual antlrcpp::Any visitMethodExpr(PnfGoParser::MethodExprContext *context) = 0;

    virtual antlrcpp::Any visitEos(PnfGoParser::EosContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__sourceFile_1(PnfGoParser::Aux_rule__sourceFile_1Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__sourceFile_2(PnfGoParser::Kleene_star__sourceFile_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__sourceFile_3(PnfGoParser::Aux_rule__sourceFile_3Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__sourceFile_4(PnfGoParser::Kleene_star__sourceFile_4Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__importDecl_1(PnfGoParser::Aux_rule__importDecl_1Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__importDecl_2(PnfGoParser::Kleene_star__importDecl_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__importSpec_1(PnfGoParser::Aux_rule__importSpec_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__importSpec_2(PnfGoParser::Optional__importSpec_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__constDecl_1(PnfGoParser::Aux_rule__constDecl_1Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__constDecl_2(PnfGoParser::Kleene_star__constDecl_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__constSpec_1(PnfGoParser::Optional__constSpec_1Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__constSpec_2(PnfGoParser::Aux_rule__constSpec_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__constSpec_3(PnfGoParser::Optional__constSpec_3Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__identifierList_1(PnfGoParser::Aux_rule__identifierList_1Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__identifierList_2(PnfGoParser::Kleene_star__identifierList_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__expressionList_1(PnfGoParser::Aux_rule__expressionList_1Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__expressionList_2(PnfGoParser::Kleene_star__expressionList_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__typeDecl_1(PnfGoParser::Aux_rule__typeDecl_1Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__typeDecl_2(PnfGoParser::Kleene_star__typeDecl_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__typeSpec_1(PnfGoParser::Optional__typeSpec_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__functionDecl_1(PnfGoParser::Optional__functionDecl_1Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__varDecl_1(PnfGoParser::Aux_rule__varDecl_1Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__varDecl_2(PnfGoParser::Kleene_star__varDecl_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__varSpec_1(PnfGoParser::Aux_rule__varSpec_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__varSpec_2(PnfGoParser::Optional__varSpec_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__block_1(PnfGoParser::Optional__block_1Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__statementList_1(PnfGoParser::Aux_rule__statementList_1Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__assign_op_1(PnfGoParser::Aux_rule__assign_op_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__assign_op_2(PnfGoParser::Optional__assign_op_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__returnStmt_1(PnfGoParser::Optional__returnStmt_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__breakStmt_1(PnfGoParser::Optional__breakStmt_1Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__ifStmt_1(PnfGoParser::Aux_rule__ifStmt_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__ifStmt_2(PnfGoParser::Optional__ifStmt_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__ifStmt_3(PnfGoParser::Aux_rule__ifStmt_3Context *context) = 0;

    virtual antlrcpp::Any visitOptional__ifStmt_4(PnfGoParser::Optional__ifStmt_4Context *context) = 0;

    virtual antlrcpp::Any visitOptional__exprSwitchStmt_3(PnfGoParser::Optional__exprSwitchStmt_3Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__exprSwitchStmt_4(PnfGoParser::Kleene_star__exprSwitchStmt_4Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__typeSwitchStmt_3(PnfGoParser::Kleene_star__typeSwitchStmt_3Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__typeSwitchGuard_1(PnfGoParser::Aux_rule__typeSwitchGuard_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__typeSwitchGuard_2(PnfGoParser::Optional__typeSwitchGuard_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__typeList_1(PnfGoParser::Aux_rule__typeList_1Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__typeList_2(PnfGoParser::Kleene_star__typeList_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__selectStmt_1(PnfGoParser::Kleene_star__selectStmt_1Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__recvStmt_1(PnfGoParser::Aux_rule__recvStmt_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__recvStmt_2(PnfGoParser::Optional__recvStmt_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__forStmt_1(PnfGoParser::Aux_rule__forStmt_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__forStmt_2(PnfGoParser::Optional__forStmt_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__forClause_1(PnfGoParser::Optional__forClause_1Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__interfaceType_1(PnfGoParser::Aux_rule__interfaceType_1Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__interfaceType_2(PnfGoParser::Kleene_star__interfaceType_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__parameters_1(PnfGoParser::Aux_rule__parameters_1Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__parameters_2(PnfGoParser::Kleene_star__parameters_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__parameters_3(PnfGoParser::Optional__parameters_3Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__parameters_4(PnfGoParser::Aux_rule__parameters_4Context *context) = 0;

    virtual antlrcpp::Any visitOptional__parameters_5(PnfGoParser::Optional__parameters_5Context *context) = 0;

    virtual antlrcpp::Any visitOptional__parameterDecl_1(PnfGoParser::Optional__parameterDecl_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__parameterDecl_2(PnfGoParser::Optional__parameterDecl_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__conversion_1(PnfGoParser::Optional__conversion_1Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__literalValue_2(PnfGoParser::Aux_rule__literalValue_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__literalValue_3(PnfGoParser::Optional__literalValue_3Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__elementList_1(PnfGoParser::Aux_rule__elementList_1Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__elementList_2(PnfGoParser::Kleene_star__elementList_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__keyedElement_1(PnfGoParser::Aux_rule__keyedElement_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__keyedElement_2(PnfGoParser::Optional__keyedElement_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__structType_1(PnfGoParser::Aux_rule__structType_1Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__structType_2(PnfGoParser::Kleene_star__structType_2Context *context) = 0;

    virtual antlrcpp::Any visitOptional__fieldDecl_1(PnfGoParser::Optional__fieldDecl_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__anonymousField_1(PnfGoParser::Optional__anonymousField_1Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__arguments_1(PnfGoParser::Aux_rule__arguments_1Context *context) = 0;

    virtual antlrcpp::Any visitOptional__arguments_2(PnfGoParser::Optional__arguments_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__arguments_5(PnfGoParser::Aux_rule__arguments_5Context *context) = 0;

    virtual antlrcpp::Any visitOptional__arguments_6(PnfGoParser::Optional__arguments_6Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__expression_2(PnfGoParser::Aux_rule__expression_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__expression_1(PnfGoParser::Kleene_star__expression_1Context *context) = 0;

    virtual antlrcpp::Any visitExpression(PnfGoParser::ExpressionContext *context) = 0;

    virtual antlrcpp::Any visitAux_rule__primaryExpr_2(PnfGoParser::Aux_rule__primaryExpr_2Context *context) = 0;

    virtual antlrcpp::Any visitKleene_star__primaryExpr_1(PnfGoParser::Kleene_star__primaryExpr_1Context *context) = 0;

    virtual antlrcpp::Any visitPrimaryExpr(PnfGoParser::PrimaryExprContext *context) = 0;

    virtual antlrcpp::Any visitOptional__signature_1(PnfGoParser::Optional__signature_1Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__expression_3(PnfGoParser::Altnt_block__expression_3Context *context) = 0;

    virtual antlrcpp::Any visitType_(PnfGoParser::Type_Context *context) = 0;

    virtual antlrcpp::Any visitRealStatement(PnfGoParser::RealStatementContext *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__importDecl_3(PnfGoParser::Altnt_block__importDecl_3Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__constDecl_3(PnfGoParser::Altnt_block__constDecl_3Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__typeDecl_3(PnfGoParser::Altnt_block__typeDecl_3Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__varDecl_3(PnfGoParser::Altnt_block__varDecl_3Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__varSpec_3(PnfGoParser::Altnt_block__varSpec_3Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__incDecStmt_1(PnfGoParser::Altnt_block__incDecStmt_1Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__typeList_3(PnfGoParser::Altnt_block__typeList_3Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__commCase_1(PnfGoParser::Altnt_block__commCase_1Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__channelType_1(PnfGoParser::Altnt_block__channelType_1Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__unaryExpr_1(PnfGoParser::Altnt_block__unaryExpr_1Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__fieldDecl_2(PnfGoParser::Altnt_block__fieldDecl_2Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__slice_4(PnfGoParser::Altnt_block__slice_4Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__sourceFile_5(PnfGoParser::Altnt_block__sourceFile_5Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__ifStmt_5(PnfGoParser::Altnt_block__ifStmt_5Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__arguments_7(PnfGoParser::Altnt_block__arguments_7Context *context) = 0;

    virtual antlrcpp::Any visitOptional__channelType_2(PnfGoParser::Optional__channelType_2Context *context) = 0;

    virtual antlrcpp::Any visitAltnt_block__slice_5(PnfGoParser::Altnt_block__slice_5Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__primaryExpr_3(PnfGoParser::Aux_rule__primaryExpr_3Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__sourceFile_6(PnfGoParser::Aux_rule__sourceFile_6Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__exprSwitchCase_1(PnfGoParser::Aux_rule__exprSwitchCase_1Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__typeSwitchCase_1(PnfGoParser::Aux_rule__typeSwitchCase_1Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__commCase_2(PnfGoParser::Aux_rule__commCase_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__methodSpec_2(PnfGoParser::Aux_rule__methodSpec_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__unaryExpr_2(PnfGoParser::Aux_rule__unaryExpr_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__literalType_1(PnfGoParser::Aux_rule__literalType_1Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__eos_1(PnfGoParser::Aux_rule__eos_1Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__eos_2(PnfGoParser::Aux_rule__eos_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__statementList_2(PnfGoParser::Aux_rule__statementList_2Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__recvStmt_3(PnfGoParser::Aux_rule__recvStmt_3Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__recvStmt_4(PnfGoParser::Aux_rule__recvStmt_4Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__primaryExpr_4(PnfGoParser::Aux_rule__primaryExpr_4Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__type__1(PnfGoParser::Aux_rule__type__1Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__importDecl_4(PnfGoParser::Aux_rule__importDecl_4Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__constDecl_4(PnfGoParser::Aux_rule__constDecl_4Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__typeDecl_4(PnfGoParser::Aux_rule__typeDecl_4Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__varDecl_4(PnfGoParser::Aux_rule__varDecl_4Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__varSpec_4(PnfGoParser::Aux_rule__varSpec_4Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__varSpec_5(PnfGoParser::Aux_rule__varSpec_5Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__channelType_3(PnfGoParser::Aux_rule__channelType_3Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__channelType_4(PnfGoParser::Aux_rule__channelType_4Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__fieldDecl_3(PnfGoParser::Aux_rule__fieldDecl_3Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__arguments_8(PnfGoParser::Aux_rule__arguments_8Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__slice_6(PnfGoParser::Aux_rule__slice_6Context *context) = 0;

    virtual antlrcpp::Any visitAux_rule__primaryExpr_5(PnfGoParser::Aux_rule__primaryExpr_5Context *context) = 0;


};

}  // namespace antlr_go_perses
