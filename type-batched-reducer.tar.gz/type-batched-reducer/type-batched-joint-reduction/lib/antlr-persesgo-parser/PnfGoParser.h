
// Generated from PnfGoParser.g4 by ANTLR 4.7.2

#pragma once


#include "antlr4-runtime.h"


namespace antlr_go_perses {


class  PnfGoParser : public antlr4::Parser {
public:
  enum {
    BREAK = 1, DEFAULT = 2, FUNC = 3, INTERFACE = 4, SELECT = 5, CASE = 6, 
    DEFER = 7, GO = 8, MAP = 9, STRUCT = 10, CHAN = 11, ELSE = 12, GOTO = 13, 
    PACKAGE = 14, SWITCH = 15, CONST = 16, FALLTHROUGH = 17, IF = 18, RANGE = 19, 
    TYPE = 20, CONTINUE = 21, FOR = 22, IMPORT = 23, RETURN = 24, VAR = 25, 
    NIL_LIT = 26, IDENTIFIER = 27, L_PAREN = 28, R_PAREN = 29, L_CURLY = 30, 
    R_CURLY = 31, L_BRACKET = 32, R_BRACKET = 33, ASSIGN = 34, COMMA = 35, 
    SEMI = 36, COLON = 37, DOT = 38, PLUS_PLUS = 39, MINUS_MINUS = 40, DECLARE_ASSIGN = 41, 
    ELLIPSIS = 42, LOGICAL_OR = 43, LOGICAL_AND = 44, EQUALS = 45, NOT_EQUALS = 46, 
    LESS = 47, LESS_OR_EQUALS = 48, GREATER = 49, GREATER_OR_EQUALS = 50, 
    OR = 51, DIV = 52, MOD = 53, LSHIFT = 54, RSHIFT = 55, BIT_CLEAR = 56, 
    EXCLAMATION = 57, PLUS = 58, MINUS = 59, CARET = 60, STAR = 61, AMPERSAND = 62, 
    RECEIVE = 63, DECIMAL_LIT = 64, OCTAL_LIT = 65, HEX_LIT = 66, FLOAT_LIT = 67, 
    IMAGINARY_LIT = 68, RUNE_LIT = 69, RAW_STRING_LIT = 70, INTERPRETED_STRING_LIT = 71, 
    WS = 72, COMMENT = 73, TERMINATOR = 74, LINE_COMMENT = 75
  };

  enum {
    RuleSourceFile = 0, RulePackageClause = 1, RuleImportDecl = 2, RuleImportSpec = 3, 
    RuleImportPath = 4, RuleDeclaration = 5, RuleConstDecl = 6, RuleConstSpec = 7, 
    RuleIdentifierList = 8, RuleExpressionList = 9, RuleTypeDecl = 10, RuleTypeSpec = 11, 
    RuleFunctionDecl = 12, RuleMethodDecl = 13, RuleReceiver = 14, RuleVarDecl = 15, 
    RuleVarSpec = 16, RuleBlock = 17, RuleStatementList = 18, RuleStatement = 19, 
    RuleSimpleStmt = 20, RuleRealSimpleStmt = 21, RuleExpressionStmt = 22, 
    RuleSendStmt = 23, RuleIncDecStmt = 24, RuleAssignment = 25, RuleAssign_op = 26, 
    RuleShortVarDecl = 27, RuleLabeledStmt = 28, RuleReturnStmt = 29, RuleBreakStmt = 30, 
    RuleContinueStmt = 31, RuleGotoStmt = 32, RuleFallthroughStmt = 33, 
    RuleDeferStmt = 34, RuleIfStmt = 35, RuleExprSwitchStmt = 36, RuleExprCaseClause = 37, 
    RuleExprSwitchCase = 38, RuleTypeSwitchStmt = 39, RuleTypeSwitchGuard = 40, 
    RuleTypeCaseClause = 41, RuleTypeSwitchCase = 42, RuleTypeList = 43, 
    RuleSelectStmt = 44, RuleCommClause = 45, RuleCommCase = 46, RuleRecvStmt = 47, 
    RuleForStmt = 48, RuleForClause = 49, RuleRangeClause = 50, RuleGoStmt = 51, 
    RuleTypeName = 52, RuleArrayType = 53, RuleElementType = 54, RulePointerType = 55, 
    RuleInterfaceType = 56, RuleSliceType = 57, RuleMapType = 58, RuleChannelType = 59, 
    RuleMethodSpec = 60, RuleFunctionType = 61, RuleSignature = 62, RuleResult = 63, 
    RuleParameters = 64, RuleParameterDecl = 65, RuleUnaryExpr = 66, RuleConversion = 67, 
    RuleQualifiedIdent = 68, RuleCompositeLit = 69, RuleLiteralType = 70, 
    RuleLiteralValue = 71, RuleElementList = 72, RuleKeyedElement = 73, 
    RuleKey = 74, RuleElement = 75, RuleStructType = 76, RuleFieldDecl = 77, 
    RuleString_ = 78, RuleAnonymousField = 79, RuleFunctionLit = 80, RuleIndex = 81, 
    RuleSlice = 82, RuleTypeAssertion = 83, RuleArguments = 84, RuleMethodExpr = 85, 
    RuleEos = 86, RuleAux_rule__sourceFile_1 = 87, RuleKleene_star__sourceFile_2 = 88, 
    RuleAux_rule__sourceFile_3 = 89, RuleKleene_star__sourceFile_4 = 90, 
    RuleAux_rule__importDecl_1 = 91, RuleKleene_star__importDecl_2 = 92, 
    RuleAux_rule__importSpec_1 = 93, RuleOptional__importSpec_2 = 94, RuleAux_rule__constDecl_1 = 95, 
    RuleKleene_star__constDecl_2 = 96, RuleOptional__constSpec_1 = 97, RuleAux_rule__constSpec_2 = 98, 
    RuleOptional__constSpec_3 = 99, RuleAux_rule__identifierList_1 = 100, 
    RuleKleene_star__identifierList_2 = 101, RuleAux_rule__expressionList_1 = 102, 
    RuleKleene_star__expressionList_2 = 103, RuleAux_rule__typeDecl_1 = 104, 
    RuleKleene_star__typeDecl_2 = 105, RuleOptional__typeSpec_1 = 106, RuleOptional__functionDecl_1 = 107, 
    RuleAux_rule__varDecl_1 = 108, RuleKleene_star__varDecl_2 = 109, RuleAux_rule__varSpec_1 = 110, 
    RuleOptional__varSpec_2 = 111, RuleOptional__block_1 = 112, RuleAux_rule__statementList_1 = 113, 
    RuleAux_rule__assign_op_1 = 114, RuleOptional__assign_op_2 = 115, RuleOptional__returnStmt_1 = 116, 
    RuleOptional__breakStmt_1 = 117, RuleAux_rule__ifStmt_1 = 118, RuleOptional__ifStmt_2 = 119, 
    RuleAux_rule__ifStmt_3 = 120, RuleOptional__ifStmt_4 = 121, RuleOptional__exprSwitchStmt_3 = 122, 
    RuleKleene_star__exprSwitchStmt_4 = 123, RuleKleene_star__typeSwitchStmt_3 = 124, 
    RuleAux_rule__typeSwitchGuard_1 = 125, RuleOptional__typeSwitchGuard_2 = 126, 
    RuleAux_rule__typeList_1 = 127, RuleKleene_star__typeList_2 = 128, RuleKleene_star__selectStmt_1 = 129, 
    RuleAux_rule__recvStmt_1 = 130, RuleOptional__recvStmt_2 = 131, RuleAux_rule__forStmt_1 = 132, 
    RuleOptional__forStmt_2 = 133, RuleOptional__forClause_1 = 134, RuleAux_rule__interfaceType_1 = 135, 
    RuleKleene_star__interfaceType_2 = 136, RuleAux_rule__parameters_1 = 137, 
    RuleKleene_star__parameters_2 = 138, RuleOptional__parameters_3 = 139, 
    RuleAux_rule__parameters_4 = 140, RuleOptional__parameters_5 = 141, 
    RuleOptional__parameterDecl_1 = 142, RuleOptional__parameterDecl_2 = 143, 
    RuleOptional__conversion_1 = 144, RuleAux_rule__literalValue_2 = 145, 
    RuleOptional__literalValue_3 = 146, RuleAux_rule__elementList_1 = 147, 
    RuleKleene_star__elementList_2 = 148, RuleAux_rule__keyedElement_1 = 149, 
    RuleOptional__keyedElement_2 = 150, RuleAux_rule__structType_1 = 151, 
    RuleKleene_star__structType_2 = 152, RuleOptional__fieldDecl_1 = 153, 
    RuleOptional__anonymousField_1 = 154, RuleAux_rule__arguments_1 = 155, 
    RuleOptional__arguments_2 = 156, RuleAux_rule__arguments_5 = 157, RuleOptional__arguments_6 = 158, 
    RuleAux_rule__expression_2 = 159, RuleKleene_star__expression_1 = 160, 
    RuleExpression = 161, RuleAux_rule__primaryExpr_2 = 162, RuleKleene_star__primaryExpr_1 = 163, 
    RulePrimaryExpr = 164, RuleOptional__signature_1 = 165, RuleAltnt_block__expression_3 = 166, 
    RuleType_ = 167, RuleRealStatement = 168, RuleAltnt_block__importDecl_3 = 169, 
    RuleAltnt_block__constDecl_3 = 170, RuleAltnt_block__typeDecl_3 = 171, 
    RuleAltnt_block__varDecl_3 = 172, RuleAltnt_block__varSpec_3 = 173, 
    RuleAltnt_block__incDecStmt_1 = 174, RuleAltnt_block__typeList_3 = 175, 
    RuleAltnt_block__commCase_1 = 176, RuleAltnt_block__channelType_1 = 177, 
    RuleAltnt_block__unaryExpr_1 = 178, RuleAltnt_block__fieldDecl_2 = 179, 
    RuleAltnt_block__slice_4 = 180, RuleAltnt_block__sourceFile_5 = 181, 
    RuleAltnt_block__ifStmt_5 = 182, RuleAltnt_block__arguments_7 = 183, 
    RuleOptional__channelType_2 = 184, RuleAltnt_block__slice_5 = 185, RuleAux_rule__primaryExpr_3 = 186, 
    RuleAux_rule__sourceFile_6 = 187, RuleAux_rule__exprSwitchCase_1 = 188, 
    RuleAux_rule__typeSwitchCase_1 = 189, RuleAux_rule__commCase_2 = 190, 
    RuleAux_rule__methodSpec_2 = 191, RuleAux_rule__unaryExpr_2 = 192, RuleAux_rule__literalType_1 = 193, 
    RuleAux_rule__eos_1 = 194, RuleAux_rule__eos_2 = 195, RuleAux_rule__statementList_2 = 196, 
    RuleAux_rule__recvStmt_3 = 197, RuleAux_rule__recvStmt_4 = 198, RuleAux_rule__primaryExpr_4 = 199, 
    RuleAux_rule__type__1 = 200, RuleAux_rule__importDecl_4 = 201, RuleAux_rule__constDecl_4 = 202, 
    RuleAux_rule__typeDecl_4 = 203, RuleAux_rule__varDecl_4 = 204, RuleAux_rule__varSpec_4 = 205, 
    RuleAux_rule__varSpec_5 = 206, RuleAux_rule__channelType_3 = 207, RuleAux_rule__channelType_4 = 208, 
    RuleAux_rule__fieldDecl_3 = 209, RuleAux_rule__arguments_8 = 210, RuleAux_rule__slice_6 = 211, 
    RuleAux_rule__primaryExpr_5 = 212
  };

  PnfGoParser(antlr4::TokenStream *input);
  ~PnfGoParser();

  virtual std::string getGrammarFileName() const override;
  virtual const antlr4::atn::ATN& getATN() const override { return _atn; };
  virtual const std::vector<std::string>& getTokenNames() const override { return _tokenNames; }; // deprecated: use vocabulary instead.
  virtual const std::vector<std::string>& getRuleNames() const override;
  virtual antlr4::dfa::Vocabulary& getVocabulary() const override;


    bool
    checkPreviousTokenText(std::string text) {
      antlr4::BufferedTokenStream* stream = static_cast<antlr4::BufferedTokenStream*>(_input);
      antlr4::Token* prevToken = stream->LT(1);

      if (prevToken == nullptr) return false;
      
      auto prevTokenText = prevToken->getText();

      return prevTokenText == text;
    }


  class SourceFileContext;
  class PackageClauseContext;
  class ImportDeclContext;
  class ImportSpecContext;
  class ImportPathContext;
  class DeclarationContext;
  class ConstDeclContext;
  class ConstSpecContext;
  class IdentifierListContext;
  class ExpressionListContext;
  class TypeDeclContext;
  class TypeSpecContext;
  class FunctionDeclContext;
  class MethodDeclContext;
  class ReceiverContext;
  class VarDeclContext;
  class VarSpecContext;
  class BlockContext;
  class StatementListContext;
  class StatementContext;
  class SimpleStmtContext;
  class RealSimpleStmtContext;
  class ExpressionStmtContext;
  class SendStmtContext;
  class IncDecStmtContext;
  class AssignmentContext;
  class Assign_opContext;
  class ShortVarDeclContext;
  class LabeledStmtContext;
  class ReturnStmtContext;
  class BreakStmtContext;
  class ContinueStmtContext;
  class GotoStmtContext;
  class FallthroughStmtContext;
  class DeferStmtContext;
  class IfStmtContext;
  class ExprSwitchStmtContext;
  class ExprCaseClauseContext;
  class ExprSwitchCaseContext;
  class TypeSwitchStmtContext;
  class TypeSwitchGuardContext;
  class TypeCaseClauseContext;
  class TypeSwitchCaseContext;
  class TypeListContext;
  class SelectStmtContext;
  class CommClauseContext;
  class CommCaseContext;
  class RecvStmtContext;
  class ForStmtContext;
  class ForClauseContext;
  class RangeClauseContext;
  class GoStmtContext;
  class TypeNameContext;
  class ArrayTypeContext;
  class ElementTypeContext;
  class PointerTypeContext;
  class InterfaceTypeContext;
  class SliceTypeContext;
  class MapTypeContext;
  class ChannelTypeContext;
  class MethodSpecContext;
  class FunctionTypeContext;
  class SignatureContext;
  class ResultContext;
  class ParametersContext;
  class ParameterDeclContext;
  class UnaryExprContext;
  class ConversionContext;
  class QualifiedIdentContext;
  class CompositeLitContext;
  class LiteralTypeContext;
  class LiteralValueContext;
  class ElementListContext;
  class KeyedElementContext;
  class KeyContext;
  class ElementContext;
  class StructTypeContext;
  class FieldDeclContext;
  class String_Context;
  class AnonymousFieldContext;
  class FunctionLitContext;
  class IndexContext;
  class SliceContext;
  class TypeAssertionContext;
  class ArgumentsContext;
  class MethodExprContext;
  class EosContext;
  class Aux_rule__sourceFile_1Context;
  class Kleene_star__sourceFile_2Context;
  class Aux_rule__sourceFile_3Context;
  class Kleene_star__sourceFile_4Context;
  class Aux_rule__importDecl_1Context;
  class Kleene_star__importDecl_2Context;
  class Aux_rule__importSpec_1Context;
  class Optional__importSpec_2Context;
  class Aux_rule__constDecl_1Context;
  class Kleene_star__constDecl_2Context;
  class Optional__constSpec_1Context;
  class Aux_rule__constSpec_2Context;
  class Optional__constSpec_3Context;
  class Aux_rule__identifierList_1Context;
  class Kleene_star__identifierList_2Context;
  class Aux_rule__expressionList_1Context;
  class Kleene_star__expressionList_2Context;
  class Aux_rule__typeDecl_1Context;
  class Kleene_star__typeDecl_2Context;
  class Optional__typeSpec_1Context;
  class Optional__functionDecl_1Context;
  class Aux_rule__varDecl_1Context;
  class Kleene_star__varDecl_2Context;
  class Aux_rule__varSpec_1Context;
  class Optional__varSpec_2Context;
  class Optional__block_1Context;
  class Aux_rule__statementList_1Context;
  class Aux_rule__assign_op_1Context;
  class Optional__assign_op_2Context;
  class Optional__returnStmt_1Context;
  class Optional__breakStmt_1Context;
  class Aux_rule__ifStmt_1Context;
  class Optional__ifStmt_2Context;
  class Aux_rule__ifStmt_3Context;
  class Optional__ifStmt_4Context;
  class Optional__exprSwitchStmt_3Context;
  class Kleene_star__exprSwitchStmt_4Context;
  class Kleene_star__typeSwitchStmt_3Context;
  class Aux_rule__typeSwitchGuard_1Context;
  class Optional__typeSwitchGuard_2Context;
  class Aux_rule__typeList_1Context;
  class Kleene_star__typeList_2Context;
  class Kleene_star__selectStmt_1Context;
  class Aux_rule__recvStmt_1Context;
  class Optional__recvStmt_2Context;
  class Aux_rule__forStmt_1Context;
  class Optional__forStmt_2Context;
  class Optional__forClause_1Context;
  class Aux_rule__interfaceType_1Context;
  class Kleene_star__interfaceType_2Context;
  class Aux_rule__parameters_1Context;
  class Kleene_star__parameters_2Context;
  class Optional__parameters_3Context;
  class Aux_rule__parameters_4Context;
  class Optional__parameters_5Context;
  class Optional__parameterDecl_1Context;
  class Optional__parameterDecl_2Context;
  class Optional__conversion_1Context;
  class Aux_rule__literalValue_2Context;
  class Optional__literalValue_3Context;
  class Aux_rule__elementList_1Context;
  class Kleene_star__elementList_2Context;
  class Aux_rule__keyedElement_1Context;
  class Optional__keyedElement_2Context;
  class Aux_rule__structType_1Context;
  class Kleene_star__structType_2Context;
  class Optional__fieldDecl_1Context;
  class Optional__anonymousField_1Context;
  class Aux_rule__arguments_1Context;
  class Optional__arguments_2Context;
  class Aux_rule__arguments_5Context;
  class Optional__arguments_6Context;
  class Aux_rule__expression_2Context;
  class Kleene_star__expression_1Context;
  class ExpressionContext;
  class Aux_rule__primaryExpr_2Context;
  class Kleene_star__primaryExpr_1Context;
  class PrimaryExprContext;
  class Optional__signature_1Context;
  class Altnt_block__expression_3Context;
  class Type_Context;
  class RealStatementContext;
  class Altnt_block__importDecl_3Context;
  class Altnt_block__constDecl_3Context;
  class Altnt_block__typeDecl_3Context;
  class Altnt_block__varDecl_3Context;
  class Altnt_block__varSpec_3Context;
  class Altnt_block__incDecStmt_1Context;
  class Altnt_block__typeList_3Context;
  class Altnt_block__commCase_1Context;
  class Altnt_block__channelType_1Context;
  class Altnt_block__unaryExpr_1Context;
  class Altnt_block__fieldDecl_2Context;
  class Altnt_block__slice_4Context;
  class Altnt_block__sourceFile_5Context;
  class Altnt_block__ifStmt_5Context;
  class Altnt_block__arguments_7Context;
  class Optional__channelType_2Context;
  class Altnt_block__slice_5Context;
  class Aux_rule__primaryExpr_3Context;
  class Aux_rule__sourceFile_6Context;
  class Aux_rule__exprSwitchCase_1Context;
  class Aux_rule__typeSwitchCase_1Context;
  class Aux_rule__commCase_2Context;
  class Aux_rule__methodSpec_2Context;
  class Aux_rule__unaryExpr_2Context;
  class Aux_rule__literalType_1Context;
  class Aux_rule__eos_1Context;
  class Aux_rule__eos_2Context;
  class Aux_rule__statementList_2Context;
  class Aux_rule__recvStmt_3Context;
  class Aux_rule__recvStmt_4Context;
  class Aux_rule__primaryExpr_4Context;
  class Aux_rule__type__1Context;
  class Aux_rule__importDecl_4Context;
  class Aux_rule__constDecl_4Context;
  class Aux_rule__typeDecl_4Context;
  class Aux_rule__varDecl_4Context;
  class Aux_rule__varSpec_4Context;
  class Aux_rule__varSpec_5Context;
  class Aux_rule__channelType_3Context;
  class Aux_rule__channelType_4Context;
  class Aux_rule__fieldDecl_3Context;
  class Aux_rule__arguments_8Context;
  class Aux_rule__slice_6Context;
  class Aux_rule__primaryExpr_5Context; 

  class  SourceFileContext : public antlr4::ParserRuleContext {
  public:
    SourceFileContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__sourceFile_6Context *aux_rule__sourceFile_6();
    antlr4::tree::TerminalNode *EOF();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  SourceFileContext* sourceFile();

  class  PackageClauseContext : public antlr4::ParserRuleContext {
  public:
    PackageClauseContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *PACKAGE();
    antlr4::tree::TerminalNode *IDENTIFIER();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  PackageClauseContext* packageClause();

  class  ImportDeclContext : public antlr4::ParserRuleContext {
  public:
    ImportDeclContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *IMPORT();
    Altnt_block__importDecl_3Context *altnt_block__importDecl_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ImportDeclContext* importDecl();

  class  ImportSpecContext : public antlr4::ParserRuleContext {
  public:
    ImportSpecContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__importSpec_2Context *optional__importSpec_2();
    ImportPathContext *importPath();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ImportSpecContext* importSpec();

  class  ImportPathContext : public antlr4::ParserRuleContext {
  public:
    ImportPathContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    String_Context *string_();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ImportPathContext* importPath();

  class  DeclarationContext : public antlr4::ParserRuleContext {
  public:
    DeclarationContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ConstDeclContext *constDecl();
    TypeDeclContext *typeDecl();
    VarDeclContext *varDecl();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  DeclarationContext* declaration();

  class  ConstDeclContext : public antlr4::ParserRuleContext {
  public:
    ConstDeclContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *CONST();
    Altnt_block__constDecl_3Context *altnt_block__constDecl_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ConstDeclContext* constDecl();

  class  ConstSpecContext : public antlr4::ParserRuleContext {
  public:
    ConstSpecContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    IdentifierListContext *identifierList();
    Optional__constSpec_3Context *optional__constSpec_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ConstSpecContext* constSpec();

  class  IdentifierListContext : public antlr4::ParserRuleContext {
  public:
    IdentifierListContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *IDENTIFIER();
    Kleene_star__identifierList_2Context *kleene_star__identifierList_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  IdentifierListContext* identifierList();

  class  ExpressionListContext : public antlr4::ParserRuleContext {
  public:
    ExpressionListContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ExpressionContext *expression();
    Kleene_star__expressionList_2Context *kleene_star__expressionList_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ExpressionListContext* expressionList();

  class  TypeDeclContext : public antlr4::ParserRuleContext {
  public:
    TypeDeclContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *TYPE();
    Altnt_block__typeDecl_3Context *altnt_block__typeDecl_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  TypeDeclContext* typeDecl();

  class  TypeSpecContext : public antlr4::ParserRuleContext {
  public:
    TypeSpecContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *IDENTIFIER();
    Optional__typeSpec_1Context *optional__typeSpec_1();
    Type_Context *type_();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  TypeSpecContext* typeSpec();

  class  FunctionDeclContext : public antlr4::ParserRuleContext {
  public:
    FunctionDeclContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *FUNC();
    antlr4::tree::TerminalNode *IDENTIFIER();
    SignatureContext *signature();
    Optional__functionDecl_1Context *optional__functionDecl_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  FunctionDeclContext* functionDecl();

  class  MethodDeclContext : public antlr4::ParserRuleContext {
  public:
    MethodDeclContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *FUNC();
    ReceiverContext *receiver();
    antlr4::tree::TerminalNode *IDENTIFIER();
    SignatureContext *signature();
    Optional__functionDecl_1Context *optional__functionDecl_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  MethodDeclContext* methodDecl();

  class  ReceiverContext : public antlr4::ParserRuleContext {
  public:
    ReceiverContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ParametersContext *parameters();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ReceiverContext* receiver();

  class  VarDeclContext : public antlr4::ParserRuleContext {
  public:
    VarDeclContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *VAR();
    Altnt_block__varDecl_3Context *altnt_block__varDecl_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  VarDeclContext* varDecl();

  class  VarSpecContext : public antlr4::ParserRuleContext {
  public:
    VarSpecContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    IdentifierListContext *identifierList();
    Altnt_block__varSpec_3Context *altnt_block__varSpec_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  VarSpecContext* varSpec();

  class  BlockContext : public antlr4::ParserRuleContext {
  public:
    BlockContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *L_CURLY();
    Optional__block_1Context *optional__block_1();
    antlr4::tree::TerminalNode *R_CURLY();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  BlockContext* block();

  class  StatementListContext : public antlr4::ParserRuleContext {
  public:
    StatementListContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__statementList_1Context *> aux_rule__statementList_1();
    Aux_rule__statementList_1Context* aux_rule__statementList_1(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  StatementListContext* statementList();

  class  StatementContext : public antlr4::ParserRuleContext {
  public:
    StatementContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    RealStatementContext *realStatement();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  StatementContext* statement();

  class  SimpleStmtContext : public antlr4::ParserRuleContext {
  public:
    SimpleStmtContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    RealSimpleStmtContext *realSimpleStmt();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  SimpleStmtContext* simpleStmt();

  class  RealSimpleStmtContext : public antlr4::ParserRuleContext {
  public:
    RealSimpleStmtContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    SendStmtContext *sendStmt();
    AssignmentContext *assignment();
    ExpressionStmtContext *expressionStmt();
    IncDecStmtContext *incDecStmt();
    ShortVarDeclContext *shortVarDecl();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  RealSimpleStmtContext* realSimpleStmt();

  class  ExpressionStmtContext : public antlr4::ParserRuleContext {
  public:
    ExpressionStmtContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ExpressionContext *expression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ExpressionStmtContext* expressionStmt();

  class  SendStmtContext : public antlr4::ParserRuleContext {
  public:
    SendStmtContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<ExpressionContext *> expression();
    ExpressionContext* expression(size_t i);
    antlr4::tree::TerminalNode *RECEIVE();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  SendStmtContext* sendStmt();

  class  IncDecStmtContext : public antlr4::ParserRuleContext {
  public:
    IncDecStmtContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ExpressionContext *expression();
    Altnt_block__incDecStmt_1Context *altnt_block__incDecStmt_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  IncDecStmtContext* incDecStmt();

  class  AssignmentContext : public antlr4::ParserRuleContext {
  public:
    AssignmentContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<ExpressionListContext *> expressionList();
    ExpressionListContext* expressionList(size_t i);
    Assign_opContext *assign_op();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  AssignmentContext* assignment();

  class  Assign_opContext : public antlr4::ParserRuleContext {
  public:
    Assign_opContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__assign_op_2Context *optional__assign_op_2();
    antlr4::tree::TerminalNode *ASSIGN();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Assign_opContext* assign_op();

  class  ShortVarDeclContext : public antlr4::ParserRuleContext {
  public:
    ShortVarDeclContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    IdentifierListContext *identifierList();
    antlr4::tree::TerminalNode *DECLARE_ASSIGN();
    ExpressionListContext *expressionList();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ShortVarDeclContext* shortVarDecl();

  class  LabeledStmtContext : public antlr4::ParserRuleContext {
  public:
    LabeledStmtContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *IDENTIFIER();
    antlr4::tree::TerminalNode *COLON();
    StatementContext *statement();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  LabeledStmtContext* labeledStmt();

  class  ReturnStmtContext : public antlr4::ParserRuleContext {
  public:
    ReturnStmtContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *RETURN();
    Optional__returnStmt_1Context *optional__returnStmt_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ReturnStmtContext* returnStmt();

  class  BreakStmtContext : public antlr4::ParserRuleContext {
  public:
    BreakStmtContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *BREAK();
    Optional__breakStmt_1Context *optional__breakStmt_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  BreakStmtContext* breakStmt();

  class  ContinueStmtContext : public antlr4::ParserRuleContext {
  public:
    ContinueStmtContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *CONTINUE();
    Optional__breakStmt_1Context *optional__breakStmt_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ContinueStmtContext* continueStmt();

  class  GotoStmtContext : public antlr4::ParserRuleContext {
  public:
    GotoStmtContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *GOTO();
    antlr4::tree::TerminalNode *IDENTIFIER();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  GotoStmtContext* gotoStmt();

  class  FallthroughStmtContext : public antlr4::ParserRuleContext {
  public:
    FallthroughStmtContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *FALLTHROUGH();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  FallthroughStmtContext* fallthroughStmt();

  class  DeferStmtContext : public antlr4::ParserRuleContext {
  public:
    DeferStmtContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *DEFER();
    ExpressionContext *expression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  DeferStmtContext* deferStmt();

  class  IfStmtContext : public antlr4::ParserRuleContext {
  public:
    IfStmtContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *IF();
    Optional__ifStmt_2Context *optional__ifStmt_2();
    ExpressionContext *expression();
    BlockContext *block();
    Optional__ifStmt_4Context *optional__ifStmt_4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  IfStmtContext* ifStmt();

  class  ExprSwitchStmtContext : public antlr4::ParserRuleContext {
  public:
    ExprSwitchStmtContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *SWITCH();
    Optional__ifStmt_2Context *optional__ifStmt_2();
    Optional__exprSwitchStmt_3Context *optional__exprSwitchStmt_3();
    antlr4::tree::TerminalNode *L_CURLY();
    Kleene_star__exprSwitchStmt_4Context *kleene_star__exprSwitchStmt_4();
    antlr4::tree::TerminalNode *R_CURLY();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ExprSwitchStmtContext* exprSwitchStmt();

  class  ExprCaseClauseContext : public antlr4::ParserRuleContext {
  public:
    ExprCaseClauseContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ExprSwitchCaseContext *exprSwitchCase();
    antlr4::tree::TerminalNode *COLON();
    Optional__block_1Context *optional__block_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ExprCaseClauseContext* exprCaseClause();

  class  ExprSwitchCaseContext : public antlr4::ParserRuleContext {
  public:
    ExprSwitchCaseContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__exprSwitchCase_1Context *aux_rule__exprSwitchCase_1();
    antlr4::tree::TerminalNode *DEFAULT();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ExprSwitchCaseContext* exprSwitchCase();

  class  TypeSwitchStmtContext : public antlr4::ParserRuleContext {
  public:
    TypeSwitchStmtContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *SWITCH();
    Optional__ifStmt_2Context *optional__ifStmt_2();
    TypeSwitchGuardContext *typeSwitchGuard();
    antlr4::tree::TerminalNode *L_CURLY();
    Kleene_star__typeSwitchStmt_3Context *kleene_star__typeSwitchStmt_3();
    antlr4::tree::TerminalNode *R_CURLY();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  TypeSwitchStmtContext* typeSwitchStmt();

  class  TypeSwitchGuardContext : public antlr4::ParserRuleContext {
  public:
    TypeSwitchGuardContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__typeSwitchGuard_2Context *optional__typeSwitchGuard_2();
    PrimaryExprContext *primaryExpr();
    antlr4::tree::TerminalNode *DOT();
    antlr4::tree::TerminalNode *L_PAREN();
    antlr4::tree::TerminalNode *TYPE();
    antlr4::tree::TerminalNode *R_PAREN();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  TypeSwitchGuardContext* typeSwitchGuard();

  class  TypeCaseClauseContext : public antlr4::ParserRuleContext {
  public:
    TypeCaseClauseContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    TypeSwitchCaseContext *typeSwitchCase();
    antlr4::tree::TerminalNode *COLON();
    Optional__block_1Context *optional__block_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  TypeCaseClauseContext* typeCaseClause();

  class  TypeSwitchCaseContext : public antlr4::ParserRuleContext {
  public:
    TypeSwitchCaseContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__typeSwitchCase_1Context *aux_rule__typeSwitchCase_1();
    antlr4::tree::TerminalNode *DEFAULT();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  TypeSwitchCaseContext* typeSwitchCase();

  class  TypeListContext : public antlr4::ParserRuleContext {
  public:
    TypeListContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__typeList_3Context *altnt_block__typeList_3();
    Kleene_star__typeList_2Context *kleene_star__typeList_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  TypeListContext* typeList();

  class  SelectStmtContext : public antlr4::ParserRuleContext {
  public:
    SelectStmtContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *SELECT();
    antlr4::tree::TerminalNode *L_CURLY();
    Kleene_star__selectStmt_1Context *kleene_star__selectStmt_1();
    antlr4::tree::TerminalNode *R_CURLY();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  SelectStmtContext* selectStmt();

  class  CommClauseContext : public antlr4::ParserRuleContext {
  public:
    CommClauseContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    CommCaseContext *commCase();
    antlr4::tree::TerminalNode *COLON();
    Optional__block_1Context *optional__block_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  CommClauseContext* commClause();

  class  CommCaseContext : public antlr4::ParserRuleContext {
  public:
    CommCaseContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__commCase_2Context *aux_rule__commCase_2();
    antlr4::tree::TerminalNode *DEFAULT();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  CommCaseContext* commCase();

  class  RecvStmtContext : public antlr4::ParserRuleContext {
  public:
    RecvStmtContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__recvStmt_2Context *optional__recvStmt_2();
    ExpressionContext *expression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  RecvStmtContext* recvStmt();

  class  ForStmtContext : public antlr4::ParserRuleContext {
  public:
    ForStmtContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *FOR();
    Optional__forStmt_2Context *optional__forStmt_2();
    BlockContext *block();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ForStmtContext* forStmt();

  class  ForClauseContext : public antlr4::ParserRuleContext {
  public:
    ForClauseContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Optional__forClause_1Context *> optional__forClause_1();
    Optional__forClause_1Context* optional__forClause_1(size_t i);
    std::vector<antlr4::tree::TerminalNode *> SEMI();
    antlr4::tree::TerminalNode* SEMI(size_t i);
    Optional__exprSwitchStmt_3Context *optional__exprSwitchStmt_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ForClauseContext* forClause();

  class  RangeClauseContext : public antlr4::ParserRuleContext {
  public:
    RangeClauseContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__recvStmt_2Context *optional__recvStmt_2();
    antlr4::tree::TerminalNode *RANGE();
    ExpressionContext *expression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  RangeClauseContext* rangeClause();

  class  GoStmtContext : public antlr4::ParserRuleContext {
  public:
    GoStmtContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *GO();
    ExpressionContext *expression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  GoStmtContext* goStmt();

  class  TypeNameContext : public antlr4::ParserRuleContext {
  public:
    TypeNameContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *IDENTIFIER();
    QualifiedIdentContext *qualifiedIdent();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  TypeNameContext* typeName();

  class  ArrayTypeContext : public antlr4::ParserRuleContext {
  public:
    ArrayTypeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *L_BRACKET();
    ExpressionStmtContext *expressionStmt();
    antlr4::tree::TerminalNode *R_BRACKET();
    ElementTypeContext *elementType();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ArrayTypeContext* arrayType();

  class  ElementTypeContext : public antlr4::ParserRuleContext {
  public:
    ElementTypeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Type_Context *type_();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ElementTypeContext* elementType();

  class  PointerTypeContext : public antlr4::ParserRuleContext {
  public:
    PointerTypeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *STAR();
    Type_Context *type_();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  PointerTypeContext* pointerType();

  class  InterfaceTypeContext : public antlr4::ParserRuleContext {
  public:
    InterfaceTypeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *INTERFACE();
    antlr4::tree::TerminalNode *L_CURLY();
    Kleene_star__interfaceType_2Context *kleene_star__interfaceType_2();
    antlr4::tree::TerminalNode *R_CURLY();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  InterfaceTypeContext* interfaceType();

  class  SliceTypeContext : public antlr4::ParserRuleContext {
  public:
    SliceTypeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *L_BRACKET();
    antlr4::tree::TerminalNode *R_BRACKET();
    ElementTypeContext *elementType();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  SliceTypeContext* sliceType();

  class  MapTypeContext : public antlr4::ParserRuleContext {
  public:
    MapTypeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *MAP();
    antlr4::tree::TerminalNode *L_BRACKET();
    Type_Context *type_();
    antlr4::tree::TerminalNode *R_BRACKET();
    ElementTypeContext *elementType();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  MapTypeContext* mapType();

  class  ChannelTypeContext : public antlr4::ParserRuleContext {
  public:
    ChannelTypeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__channelType_1Context *altnt_block__channelType_1();
    ElementTypeContext *elementType();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ChannelTypeContext* channelType();

  class  MethodSpecContext : public antlr4::ParserRuleContext {
  public:
    MethodSpecContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__methodSpec_2Context *aux_rule__methodSpec_2();
    TypeNameContext *typeName();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  MethodSpecContext* methodSpec();

  class  FunctionTypeContext : public antlr4::ParserRuleContext {
  public:
    FunctionTypeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *FUNC();
    SignatureContext *signature();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  FunctionTypeContext* functionType();

  class  SignatureContext : public antlr4::ParserRuleContext {
  public:
    SignatureContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ParametersContext *parameters();
    Optional__signature_1Context *optional__signature_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  SignatureContext* signature();

  class  ResultContext : public antlr4::ParserRuleContext {
  public:
    ResultContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ParametersContext *parameters();
    Type_Context *type_();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ResultContext* result();

  class  ParametersContext : public antlr4::ParserRuleContext {
  public:
    ParametersContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *L_PAREN();
    Optional__parameters_5Context *optional__parameters_5();
    antlr4::tree::TerminalNode *R_PAREN();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ParametersContext* parameters();

  class  ParameterDeclContext : public antlr4::ParserRuleContext {
  public:
    ParameterDeclContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__parameterDecl_1Context *optional__parameterDecl_1();
    Optional__parameterDecl_2Context *optional__parameterDecl_2();
    Type_Context *type_();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ParameterDeclContext* parameterDecl();

  class  UnaryExprContext : public antlr4::ParserRuleContext {
  public:
    UnaryExprContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    PrimaryExprContext *primaryExpr();
    Aux_rule__unaryExpr_2Context *aux_rule__unaryExpr_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  UnaryExprContext* unaryExpr();

  class  ConversionContext : public antlr4::ParserRuleContext {
  public:
    ConversionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Type_Context *type_();
    antlr4::tree::TerminalNode *L_PAREN();
    ExpressionContext *expression();
    Optional__conversion_1Context *optional__conversion_1();
    antlr4::tree::TerminalNode *R_PAREN();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ConversionContext* conversion();

  class  QualifiedIdentContext : public antlr4::ParserRuleContext {
  public:
    QualifiedIdentContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<antlr4::tree::TerminalNode *> IDENTIFIER();
    antlr4::tree::TerminalNode* IDENTIFIER(size_t i);
    antlr4::tree::TerminalNode *DOT();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  QualifiedIdentContext* qualifiedIdent();

  class  CompositeLitContext : public antlr4::ParserRuleContext {
  public:
    CompositeLitContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    LiteralTypeContext *literalType();
    LiteralValueContext *literalValue();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  CompositeLitContext* compositeLit();

  class  LiteralTypeContext : public antlr4::ParserRuleContext {
  public:
    LiteralTypeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    StructTypeContext *structType();
    ArrayTypeContext *arrayType();
    Aux_rule__literalType_1Context *aux_rule__literalType_1();
    SliceTypeContext *sliceType();
    MapTypeContext *mapType();
    TypeNameContext *typeName();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  LiteralTypeContext* literalType();

  class  LiteralValueContext : public antlr4::ParserRuleContext {
  public:
    LiteralValueContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *L_CURLY();
    Optional__literalValue_3Context *optional__literalValue_3();
    antlr4::tree::TerminalNode *R_CURLY();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  LiteralValueContext* literalValue();

  class  ElementListContext : public antlr4::ParserRuleContext {
  public:
    ElementListContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    KeyedElementContext *keyedElement();
    Kleene_star__elementList_2Context *kleene_star__elementList_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ElementListContext* elementList();

  class  KeyedElementContext : public antlr4::ParserRuleContext {
  public:
    KeyedElementContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__keyedElement_2Context *optional__keyedElement_2();
    ElementContext *element();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  KeyedElementContext* keyedElement();

  class  KeyContext : public antlr4::ParserRuleContext {
  public:
    KeyContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *IDENTIFIER();
    ExpressionContext *expression();
    LiteralValueContext *literalValue();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  KeyContext* key();

  class  ElementContext : public antlr4::ParserRuleContext {
  public:
    ElementContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ExpressionContext *expression();
    LiteralValueContext *literalValue();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ElementContext* element();

  class  StructTypeContext : public antlr4::ParserRuleContext {
  public:
    StructTypeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *STRUCT();
    antlr4::tree::TerminalNode *L_CURLY();
    Kleene_star__structType_2Context *kleene_star__structType_2();
    antlr4::tree::TerminalNode *R_CURLY();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  StructTypeContext* structType();

  class  FieldDeclContext : public antlr4::ParserRuleContext {
  public:
    FieldDeclContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__fieldDecl_2Context *altnt_block__fieldDecl_2();
    Optional__fieldDecl_1Context *optional__fieldDecl_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  FieldDeclContext* fieldDecl();

  class  String_Context : public antlr4::ParserRuleContext {
  public:
    String_Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *RAW_STRING_LIT();
    antlr4::tree::TerminalNode *INTERPRETED_STRING_LIT();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  String_Context* string_();

  class  AnonymousFieldContext : public antlr4::ParserRuleContext {
  public:
    AnonymousFieldContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__anonymousField_1Context *optional__anonymousField_1();
    TypeNameContext *typeName();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  AnonymousFieldContext* anonymousField();

  class  FunctionLitContext : public antlr4::ParserRuleContext {
  public:
    FunctionLitContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *FUNC();
    SignatureContext *signature();
    BlockContext *block();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  FunctionLitContext* functionLit();

  class  IndexContext : public antlr4::ParserRuleContext {
  public:
    IndexContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *L_BRACKET();
    ExpressionContext *expression();
    antlr4::tree::TerminalNode *R_BRACKET();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  IndexContext* index();

  class  SliceContext : public antlr4::ParserRuleContext {
  public:
    SliceContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *L_BRACKET();
    Altnt_block__slice_4Context *altnt_block__slice_4();
    antlr4::tree::TerminalNode *R_BRACKET();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  SliceContext* slice();

  class  TypeAssertionContext : public antlr4::ParserRuleContext {
  public:
    TypeAssertionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *DOT();
    antlr4::tree::TerminalNode *L_PAREN();
    Type_Context *type_();
    antlr4::tree::TerminalNode *R_PAREN();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  TypeAssertionContext* typeAssertion();

  class  ArgumentsContext : public antlr4::ParserRuleContext {
  public:
    ArgumentsContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *L_PAREN();
    Optional__arguments_6Context *optional__arguments_6();
    antlr4::tree::TerminalNode *R_PAREN();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ArgumentsContext* arguments();

  class  MethodExprContext : public antlr4::ParserRuleContext {
  public:
    MethodExprContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ElementTypeContext *elementType();
    antlr4::tree::TerminalNode *DOT();
    antlr4::tree::TerminalNode *IDENTIFIER();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  MethodExprContext* methodExpr();

  class  EosContext : public antlr4::ParserRuleContext {
  public:
    EosContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *SEMI();
    antlr4::tree::TerminalNode *EOF();
    Aux_rule__eos_1Context *aux_rule__eos_1();
    Aux_rule__eos_2Context *aux_rule__eos_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  EosContext* eos();

  class  Aux_rule__sourceFile_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__sourceFile_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ImportDeclContext *importDecl();
    EosContext *eos();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__sourceFile_1Context* aux_rule__sourceFile_1();

  class  Kleene_star__sourceFile_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__sourceFile_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__sourceFile_1Context *> aux_rule__sourceFile_1();
    Aux_rule__sourceFile_1Context* aux_rule__sourceFile_1(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__sourceFile_2Context* kleene_star__sourceFile_2();

  class  Aux_rule__sourceFile_3Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__sourceFile_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__sourceFile_5Context *altnt_block__sourceFile_5();
    EosContext *eos();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__sourceFile_3Context* aux_rule__sourceFile_3();

  class  Kleene_star__sourceFile_4Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__sourceFile_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__sourceFile_3Context *> aux_rule__sourceFile_3();
    Aux_rule__sourceFile_3Context* aux_rule__sourceFile_3(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__sourceFile_4Context* kleene_star__sourceFile_4();

  class  Aux_rule__importDecl_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__importDecl_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ImportSpecContext *importSpec();
    EosContext *eos();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__importDecl_1Context* aux_rule__importDecl_1();

  class  Kleene_star__importDecl_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__importDecl_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__importDecl_1Context *> aux_rule__importDecl_1();
    Aux_rule__importDecl_1Context* aux_rule__importDecl_1(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__importDecl_2Context* kleene_star__importDecl_2();

  class  Aux_rule__importSpec_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__importSpec_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *DOT();
    antlr4::tree::TerminalNode *IDENTIFIER();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__importSpec_1Context* aux_rule__importSpec_1();

  class  Optional__importSpec_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__importSpec_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__importSpec_1Context *aux_rule__importSpec_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__importSpec_2Context* optional__importSpec_2();

  class  Aux_rule__constDecl_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__constDecl_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ConstSpecContext *constSpec();
    EosContext *eos();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__constDecl_1Context* aux_rule__constDecl_1();

  class  Kleene_star__constDecl_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__constDecl_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__constDecl_1Context *> aux_rule__constDecl_1();
    Aux_rule__constDecl_1Context* aux_rule__constDecl_1(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__constDecl_2Context* kleene_star__constDecl_2();

  class  Optional__constSpec_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__constSpec_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Type_Context *type_();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__constSpec_1Context* optional__constSpec_1();

  class  Aux_rule__constSpec_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__constSpec_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__constSpec_1Context *optional__constSpec_1();
    antlr4::tree::TerminalNode *ASSIGN();
    ExpressionListContext *expressionList();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__constSpec_2Context* aux_rule__constSpec_2();

  class  Optional__constSpec_3Context : public antlr4::ParserRuleContext {
  public:
    Optional__constSpec_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__constSpec_2Context *aux_rule__constSpec_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__constSpec_3Context* optional__constSpec_3();

  class  Aux_rule__identifierList_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__identifierList_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *COMMA();
    antlr4::tree::TerminalNode *IDENTIFIER();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__identifierList_1Context* aux_rule__identifierList_1();

  class  Kleene_star__identifierList_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__identifierList_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__identifierList_1Context *> aux_rule__identifierList_1();
    Aux_rule__identifierList_1Context* aux_rule__identifierList_1(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__identifierList_2Context* kleene_star__identifierList_2();

  class  Aux_rule__expressionList_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__expressionList_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *COMMA();
    ExpressionContext *expression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__expressionList_1Context* aux_rule__expressionList_1();

  class  Kleene_star__expressionList_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__expressionList_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__expressionList_1Context *> aux_rule__expressionList_1();
    Aux_rule__expressionList_1Context* aux_rule__expressionList_1(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__expressionList_2Context* kleene_star__expressionList_2();

  class  Aux_rule__typeDecl_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__typeDecl_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    TypeSpecContext *typeSpec();
    EosContext *eos();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__typeDecl_1Context* aux_rule__typeDecl_1();

  class  Kleene_star__typeDecl_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__typeDecl_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__typeDecl_1Context *> aux_rule__typeDecl_1();
    Aux_rule__typeDecl_1Context* aux_rule__typeDecl_1(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__typeDecl_2Context* kleene_star__typeDecl_2();

  class  Optional__typeSpec_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__typeSpec_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *ASSIGN();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__typeSpec_1Context* optional__typeSpec_1();

  class  Optional__functionDecl_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__functionDecl_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    BlockContext *block();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__functionDecl_1Context* optional__functionDecl_1();

  class  Aux_rule__varDecl_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__varDecl_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    VarSpecContext *varSpec();
    EosContext *eos();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__varDecl_1Context* aux_rule__varDecl_1();

  class  Kleene_star__varDecl_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__varDecl_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__varDecl_1Context *> aux_rule__varDecl_1();
    Aux_rule__varDecl_1Context* aux_rule__varDecl_1(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__varDecl_2Context* kleene_star__varDecl_2();

  class  Aux_rule__varSpec_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__varSpec_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *ASSIGN();
    ExpressionListContext *expressionList();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__varSpec_1Context* aux_rule__varSpec_1();

  class  Optional__varSpec_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__varSpec_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__varSpec_1Context *aux_rule__varSpec_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__varSpec_2Context* optional__varSpec_2();

  class  Optional__block_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__block_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    StatementListContext *statementList();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__block_1Context* optional__block_1();

  class  Aux_rule__statementList_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__statementList_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__statementList_2Context *aux_rule__statementList_2();
    antlr4::tree::TerminalNode *SEMI();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__statementList_1Context* aux_rule__statementList_1();

  class  Aux_rule__assign_op_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__assign_op_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *PLUS();
    antlr4::tree::TerminalNode *MINUS();
    antlr4::tree::TerminalNode *OR();
    antlr4::tree::TerminalNode *CARET();
    antlr4::tree::TerminalNode *STAR();
    antlr4::tree::TerminalNode *DIV();
    antlr4::tree::TerminalNode *MOD();
    antlr4::tree::TerminalNode *LSHIFT();
    antlr4::tree::TerminalNode *RSHIFT();
    antlr4::tree::TerminalNode *AMPERSAND();
    antlr4::tree::TerminalNode *BIT_CLEAR();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__assign_op_1Context* aux_rule__assign_op_1();

  class  Optional__assign_op_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__assign_op_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__assign_op_1Context *aux_rule__assign_op_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__assign_op_2Context* optional__assign_op_2();

  class  Optional__returnStmt_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__returnStmt_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ExpressionListContext *expressionList();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__returnStmt_1Context* optional__returnStmt_1();

  class  Optional__breakStmt_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__breakStmt_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *IDENTIFIER();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__breakStmt_1Context* optional__breakStmt_1();

  class  Aux_rule__ifStmt_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__ifStmt_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    SimpleStmtContext *simpleStmt();
    antlr4::tree::TerminalNode *SEMI();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__ifStmt_1Context* aux_rule__ifStmt_1();

  class  Optional__ifStmt_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__ifStmt_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__ifStmt_1Context *aux_rule__ifStmt_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__ifStmt_2Context* optional__ifStmt_2();

  class  Aux_rule__ifStmt_3Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__ifStmt_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *ELSE();
    Altnt_block__ifStmt_5Context *altnt_block__ifStmt_5();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__ifStmt_3Context* aux_rule__ifStmt_3();

  class  Optional__ifStmt_4Context : public antlr4::ParserRuleContext {
  public:
    Optional__ifStmt_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__ifStmt_3Context *aux_rule__ifStmt_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__ifStmt_4Context* optional__ifStmt_4();

  class  Optional__exprSwitchStmt_3Context : public antlr4::ParserRuleContext {
  public:
    Optional__exprSwitchStmt_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ExpressionContext *expression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__exprSwitchStmt_3Context* optional__exprSwitchStmt_3();

  class  Kleene_star__exprSwitchStmt_4Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__exprSwitchStmt_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<ExprCaseClauseContext *> exprCaseClause();
    ExprCaseClauseContext* exprCaseClause(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__exprSwitchStmt_4Context* kleene_star__exprSwitchStmt_4();

  class  Kleene_star__typeSwitchStmt_3Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__typeSwitchStmt_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<TypeCaseClauseContext *> typeCaseClause();
    TypeCaseClauseContext* typeCaseClause(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__typeSwitchStmt_3Context* kleene_star__typeSwitchStmt_3();

  class  Aux_rule__typeSwitchGuard_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__typeSwitchGuard_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *IDENTIFIER();
    antlr4::tree::TerminalNode *DECLARE_ASSIGN();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__typeSwitchGuard_1Context* aux_rule__typeSwitchGuard_1();

  class  Optional__typeSwitchGuard_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__typeSwitchGuard_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__typeSwitchGuard_1Context *aux_rule__typeSwitchGuard_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__typeSwitchGuard_2Context* optional__typeSwitchGuard_2();

  class  Aux_rule__typeList_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__typeList_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *COMMA();
    Altnt_block__typeList_3Context *altnt_block__typeList_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__typeList_1Context* aux_rule__typeList_1();

  class  Kleene_star__typeList_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__typeList_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__typeList_1Context *> aux_rule__typeList_1();
    Aux_rule__typeList_1Context* aux_rule__typeList_1(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__typeList_2Context* kleene_star__typeList_2();

  class  Kleene_star__selectStmt_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__selectStmt_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<CommClauseContext *> commClause();
    CommClauseContext* commClause(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__selectStmt_1Context* kleene_star__selectStmt_1();

  class  Aux_rule__recvStmt_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__recvStmt_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__recvStmt_3Context *aux_rule__recvStmt_3();
    Aux_rule__recvStmt_4Context *aux_rule__recvStmt_4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__recvStmt_1Context* aux_rule__recvStmt_1();

  class  Optional__recvStmt_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__recvStmt_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__recvStmt_1Context *aux_rule__recvStmt_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__recvStmt_2Context* optional__recvStmt_2();

  class  Aux_rule__forStmt_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__forStmt_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ExpressionContext *expression();
    ForClauseContext *forClause();
    RangeClauseContext *rangeClause();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__forStmt_1Context* aux_rule__forStmt_1();

  class  Optional__forStmt_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__forStmt_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__forStmt_1Context *aux_rule__forStmt_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__forStmt_2Context* optional__forStmt_2();

  class  Optional__forClause_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__forClause_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    SimpleStmtContext *simpleStmt();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__forClause_1Context* optional__forClause_1();

  class  Aux_rule__interfaceType_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__interfaceType_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    MethodSpecContext *methodSpec();
    EosContext *eos();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__interfaceType_1Context* aux_rule__interfaceType_1();

  class  Kleene_star__interfaceType_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__interfaceType_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__interfaceType_1Context *> aux_rule__interfaceType_1();
    Aux_rule__interfaceType_1Context* aux_rule__interfaceType_1(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__interfaceType_2Context* kleene_star__interfaceType_2();

  class  Aux_rule__parameters_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__parameters_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *COMMA();
    ParameterDeclContext *parameterDecl();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__parameters_1Context* aux_rule__parameters_1();

  class  Kleene_star__parameters_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__parameters_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__parameters_1Context *> aux_rule__parameters_1();
    Aux_rule__parameters_1Context* aux_rule__parameters_1(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__parameters_2Context* kleene_star__parameters_2();

  class  Optional__parameters_3Context : public antlr4::ParserRuleContext {
  public:
    Optional__parameters_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *COMMA();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__parameters_3Context* optional__parameters_3();

  class  Aux_rule__parameters_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__parameters_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ParameterDeclContext *parameterDecl();
    Kleene_star__parameters_2Context *kleene_star__parameters_2();
    Optional__parameters_3Context *optional__parameters_3();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__parameters_4Context* aux_rule__parameters_4();

  class  Optional__parameters_5Context : public antlr4::ParserRuleContext {
  public:
    Optional__parameters_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__parameters_4Context *aux_rule__parameters_4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__parameters_5Context* optional__parameters_5();

  class  Optional__parameterDecl_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__parameterDecl_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    IdentifierListContext *identifierList();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__parameterDecl_1Context* optional__parameterDecl_1();

  class  Optional__parameterDecl_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__parameterDecl_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *ELLIPSIS();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__parameterDecl_2Context* optional__parameterDecl_2();

  class  Optional__conversion_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__conversion_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *COMMA();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__conversion_1Context* optional__conversion_1();

  class  Aux_rule__literalValue_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__literalValue_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ElementListContext *elementList();
    Optional__conversion_1Context *optional__conversion_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__literalValue_2Context* aux_rule__literalValue_2();

  class  Optional__literalValue_3Context : public antlr4::ParserRuleContext {
  public:
    Optional__literalValue_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__literalValue_2Context *aux_rule__literalValue_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__literalValue_3Context* optional__literalValue_3();

  class  Aux_rule__elementList_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__elementList_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *COMMA();
    KeyedElementContext *keyedElement();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__elementList_1Context* aux_rule__elementList_1();

  class  Kleene_star__elementList_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__elementList_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__elementList_1Context *> aux_rule__elementList_1();
    Aux_rule__elementList_1Context* aux_rule__elementList_1(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__elementList_2Context* kleene_star__elementList_2();

  class  Aux_rule__keyedElement_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__keyedElement_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    KeyContext *key();
    antlr4::tree::TerminalNode *COLON();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__keyedElement_1Context* aux_rule__keyedElement_1();

  class  Optional__keyedElement_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__keyedElement_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__keyedElement_1Context *aux_rule__keyedElement_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__keyedElement_2Context* optional__keyedElement_2();

  class  Aux_rule__structType_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__structType_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    FieldDeclContext *fieldDecl();
    EosContext *eos();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__structType_1Context* aux_rule__structType_1();

  class  Kleene_star__structType_2Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__structType_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__structType_1Context *> aux_rule__structType_1();
    Aux_rule__structType_1Context* aux_rule__structType_1(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__structType_2Context* kleene_star__structType_2();

  class  Optional__fieldDecl_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__fieldDecl_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    String_Context *string_();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__fieldDecl_1Context* optional__fieldDecl_1();

  class  Optional__anonymousField_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__anonymousField_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *STAR();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__anonymousField_1Context* optional__anonymousField_1();

  class  Aux_rule__arguments_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__arguments_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *COMMA();
    ExpressionListContext *expressionList();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__arguments_1Context* aux_rule__arguments_1();

  class  Optional__arguments_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__arguments_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__arguments_1Context *aux_rule__arguments_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__arguments_2Context* optional__arguments_2();

  class  Aux_rule__arguments_5Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__arguments_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__arguments_7Context *altnt_block__arguments_7();
    Optional__parameterDecl_2Context *optional__parameterDecl_2();
    Optional__conversion_1Context *optional__conversion_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__arguments_5Context* aux_rule__arguments_5();

  class  Optional__arguments_6Context : public antlr4::ParserRuleContext {
  public:
    Optional__arguments_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__arguments_5Context *aux_rule__arguments_5();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__arguments_6Context* optional__arguments_6();

  class  Aux_rule__expression_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__expression_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__expression_3Context *altnt_block__expression_3();
    ExpressionContext *expression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__expression_2Context* aux_rule__expression_2();

  class  Kleene_star__expression_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__expression_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__expression_2Context *> aux_rule__expression_2();
    Aux_rule__expression_2Context* aux_rule__expression_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__expression_1Context* kleene_star__expression_1();

  class  ExpressionContext : public antlr4::ParserRuleContext {
  public:
    ExpressionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    UnaryExprContext *unaryExpr();
    Kleene_star__expression_1Context *kleene_star__expression_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ExpressionContext* expression();

  class  Aux_rule__primaryExpr_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__primaryExpr_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__primaryExpr_4Context *aux_rule__primaryExpr_4();
    IndexContext *index();
    SliceContext *slice();
    TypeAssertionContext *typeAssertion();
    ArgumentsContext *arguments();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__primaryExpr_2Context* aux_rule__primaryExpr_2();

  class  Kleene_star__primaryExpr_1Context : public antlr4::ParserRuleContext {
  public:
    Kleene_star__primaryExpr_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<Aux_rule__primaryExpr_2Context *> aux_rule__primaryExpr_2();
    Aux_rule__primaryExpr_2Context* aux_rule__primaryExpr_2(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Kleene_star__primaryExpr_1Context* kleene_star__primaryExpr_1();

  class  PrimaryExprContext : public antlr4::ParserRuleContext {
  public:
    PrimaryExprContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__primaryExpr_3Context *aux_rule__primaryExpr_3();
    Kleene_star__primaryExpr_1Context *kleene_star__primaryExpr_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  PrimaryExprContext* primaryExpr();

  class  Optional__signature_1Context : public antlr4::ParserRuleContext {
  public:
    Optional__signature_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ResultContext *result();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__signature_1Context* optional__signature_1();

  class  Altnt_block__expression_3Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__expression_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *STAR();
    antlr4::tree::TerminalNode *DIV();
    antlr4::tree::TerminalNode *MOD();
    antlr4::tree::TerminalNode *LSHIFT();
    antlr4::tree::TerminalNode *RSHIFT();
    antlr4::tree::TerminalNode *AMPERSAND();
    antlr4::tree::TerminalNode *BIT_CLEAR();
    antlr4::tree::TerminalNode *PLUS();
    antlr4::tree::TerminalNode *MINUS();
    antlr4::tree::TerminalNode *OR();
    antlr4::tree::TerminalNode *CARET();
    antlr4::tree::TerminalNode *EQUALS();
    antlr4::tree::TerminalNode *NOT_EQUALS();
    antlr4::tree::TerminalNode *LESS();
    antlr4::tree::TerminalNode *LESS_OR_EQUALS();
    antlr4::tree::TerminalNode *GREATER();
    antlr4::tree::TerminalNode *GREATER_OR_EQUALS();
    antlr4::tree::TerminalNode *LOGICAL_AND();
    antlr4::tree::TerminalNode *LOGICAL_OR();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__expression_3Context* altnt_block__expression_3();

  class  Type_Context : public antlr4::ParserRuleContext {
  public:
    Type_Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    TypeNameContext *typeName();
    ArrayTypeContext *arrayType();
    StructTypeContext *structType();
    PointerTypeContext *pointerType();
    FunctionTypeContext *functionType();
    InterfaceTypeContext *interfaceType();
    SliceTypeContext *sliceType();
    MapTypeContext *mapType();
    ChannelTypeContext *channelType();
    Aux_rule__type__1Context *aux_rule__type__1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Type_Context* type_();

  class  RealStatementContext : public antlr4::ParserRuleContext {
  public:
    RealStatementContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    DeclarationContext *declaration();
    LabeledStmtContext *labeledStmt();
    RealSimpleStmtContext *realSimpleStmt();
    GoStmtContext *goStmt();
    ReturnStmtContext *returnStmt();
    BreakStmtContext *breakStmt();
    ContinueStmtContext *continueStmt();
    GotoStmtContext *gotoStmt();
    FallthroughStmtContext *fallthroughStmt();
    BlockContext *block();
    IfStmtContext *ifStmt();
    ExprSwitchStmtContext *exprSwitchStmt();
    TypeSwitchStmtContext *typeSwitchStmt();
    SelectStmtContext *selectStmt();
    ForStmtContext *forStmt();
    DeferStmtContext *deferStmt();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  RealStatementContext* realStatement();

  class  Altnt_block__importDecl_3Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__importDecl_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ImportSpecContext *importSpec();
    Aux_rule__importDecl_4Context *aux_rule__importDecl_4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__importDecl_3Context* altnt_block__importDecl_3();

  class  Altnt_block__constDecl_3Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__constDecl_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ConstSpecContext *constSpec();
    Aux_rule__constDecl_4Context *aux_rule__constDecl_4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__constDecl_3Context* altnt_block__constDecl_3();

  class  Altnt_block__typeDecl_3Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__typeDecl_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    TypeSpecContext *typeSpec();
    Aux_rule__typeDecl_4Context *aux_rule__typeDecl_4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__typeDecl_3Context* altnt_block__typeDecl_3();

  class  Altnt_block__varDecl_3Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__varDecl_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    VarSpecContext *varSpec();
    Aux_rule__varDecl_4Context *aux_rule__varDecl_4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__varDecl_3Context* altnt_block__varDecl_3();

  class  Altnt_block__varSpec_3Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__varSpec_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__varSpec_4Context *aux_rule__varSpec_4();
    Aux_rule__varSpec_5Context *aux_rule__varSpec_5();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__varSpec_3Context* altnt_block__varSpec_3();

  class  Altnt_block__incDecStmt_1Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__incDecStmt_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *PLUS_PLUS();
    antlr4::tree::TerminalNode *MINUS_MINUS();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__incDecStmt_1Context* altnt_block__incDecStmt_1();

  class  Altnt_block__typeList_3Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__typeList_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Type_Context *type_();
    antlr4::tree::TerminalNode *NIL_LIT();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__typeList_3Context* altnt_block__typeList_3();

  class  Altnt_block__commCase_1Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__commCase_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    SendStmtContext *sendStmt();
    RecvStmtContext *recvStmt();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__commCase_1Context* altnt_block__commCase_1();

  class  Altnt_block__channelType_1Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__channelType_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__channelType_3Context *aux_rule__channelType_3();
    Aux_rule__channelType_4Context *aux_rule__channelType_4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__channelType_1Context* altnt_block__channelType_1();

  class  Altnt_block__unaryExpr_1Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__unaryExpr_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *PLUS();
    antlr4::tree::TerminalNode *MINUS();
    antlr4::tree::TerminalNode *EXCLAMATION();
    antlr4::tree::TerminalNode *CARET();
    antlr4::tree::TerminalNode *STAR();
    antlr4::tree::TerminalNode *AMPERSAND();
    antlr4::tree::TerminalNode *RECEIVE();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__unaryExpr_1Context* altnt_block__unaryExpr_1();

  class  Altnt_block__fieldDecl_2Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__fieldDecl_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Aux_rule__fieldDecl_3Context *aux_rule__fieldDecl_3();
    AnonymousFieldContext *anonymousField();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__fieldDecl_2Context* altnt_block__fieldDecl_2();

  class  Altnt_block__slice_4Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__slice_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__exprSwitchStmt_3Context *optional__exprSwitchStmt_3();
    antlr4::tree::TerminalNode *COLON();
    Altnt_block__slice_5Context *altnt_block__slice_5();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__slice_4Context* altnt_block__slice_4();

  class  Altnt_block__sourceFile_5Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__sourceFile_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    FunctionDeclContext *functionDecl();
    MethodDeclContext *methodDecl();
    DeclarationContext *declaration();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__sourceFile_5Context* altnt_block__sourceFile_5();

  class  Altnt_block__ifStmt_5Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__ifStmt_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    IfStmtContext *ifStmt();
    BlockContext *block();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__ifStmt_5Context* altnt_block__ifStmt_5();

  class  Altnt_block__arguments_7Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__arguments_7Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ExpressionListContext *expressionList();
    Aux_rule__arguments_8Context *aux_rule__arguments_8();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__arguments_7Context* altnt_block__arguments_7();

  class  Optional__channelType_2Context : public antlr4::ParserRuleContext {
  public:
    Optional__channelType_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *RECEIVE();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Optional__channelType_2Context* optional__channelType_2();

  class  Altnt_block__slice_5Context : public antlr4::ParserRuleContext {
  public:
    Altnt_block__slice_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__exprSwitchStmt_3Context *optional__exprSwitchStmt_3();
    Aux_rule__slice_6Context *aux_rule__slice_6();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Altnt_block__slice_5Context* altnt_block__slice_5();

  class  Aux_rule__primaryExpr_3Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__primaryExpr_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *NIL_LIT();
    antlr4::tree::TerminalNode *DECIMAL_LIT();
    antlr4::tree::TerminalNode *OCTAL_LIT();
    antlr4::tree::TerminalNode *HEX_LIT();
    antlr4::tree::TerminalNode *IMAGINARY_LIT();
    antlr4::tree::TerminalNode *RUNE_LIT();
    String_Context *string_();
    antlr4::tree::TerminalNode *FLOAT_LIT();
    CompositeLitContext *compositeLit();
    FunctionLitContext *functionLit();
    TypeNameContext *typeName();
    MethodExprContext *methodExpr();
    Aux_rule__primaryExpr_5Context *aux_rule__primaryExpr_5();
    ConversionContext *conversion();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__primaryExpr_3Context* aux_rule__primaryExpr_3();

  class  Aux_rule__sourceFile_6Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__sourceFile_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    PackageClauseContext *packageClause();
    EosContext *eos();
    Kleene_star__sourceFile_2Context *kleene_star__sourceFile_2();
    Kleene_star__sourceFile_4Context *kleene_star__sourceFile_4();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__sourceFile_6Context* aux_rule__sourceFile_6();

  class  Aux_rule__exprSwitchCase_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__exprSwitchCase_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *CASE();
    ExpressionListContext *expressionList();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__exprSwitchCase_1Context* aux_rule__exprSwitchCase_1();

  class  Aux_rule__typeSwitchCase_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__typeSwitchCase_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *CASE();
    TypeListContext *typeList();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__typeSwitchCase_1Context* aux_rule__typeSwitchCase_1();

  class  Aux_rule__commCase_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__commCase_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *CASE();
    Altnt_block__commCase_1Context *altnt_block__commCase_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__commCase_2Context* aux_rule__commCase_2();

  class  Aux_rule__methodSpec_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__methodSpec_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *IDENTIFIER();
    ParametersContext *parameters();
    Optional__signature_1Context *optional__signature_1();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__methodSpec_2Context* aux_rule__methodSpec_2();

  class  Aux_rule__unaryExpr_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__unaryExpr_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Altnt_block__unaryExpr_1Context *altnt_block__unaryExpr_1();
    UnaryExprContext *unaryExpr();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__unaryExpr_2Context* aux_rule__unaryExpr_2();

  class  Aux_rule__literalType_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__literalType_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *L_BRACKET();
    antlr4::tree::TerminalNode *ELLIPSIS();
    antlr4::tree::TerminalNode *R_BRACKET();
    ElementTypeContext *elementType();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__literalType_1Context* aux_rule__literalType_1();

  class  Aux_rule__eos_1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__eos_1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__eos_1Context* aux_rule__eos_1();

  class  Aux_rule__eos_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__eos_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__eos_2Context* aux_rule__eos_2();

  class  Aux_rule__statementList_2Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__statementList_2Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    RealStatementContext *realStatement();
    EosContext *eos();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__statementList_2Context* aux_rule__statementList_2();

  class  Aux_rule__recvStmt_3Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__recvStmt_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ExpressionListContext *expressionList();
    antlr4::tree::TerminalNode *ASSIGN();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__recvStmt_3Context* aux_rule__recvStmt_3();

  class  Aux_rule__recvStmt_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__recvStmt_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    IdentifierListContext *identifierList();
    antlr4::tree::TerminalNode *DECLARE_ASSIGN();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__recvStmt_4Context* aux_rule__recvStmt_4();

  class  Aux_rule__primaryExpr_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__primaryExpr_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *DOT();
    antlr4::tree::TerminalNode *IDENTIFIER();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__primaryExpr_4Context* aux_rule__primaryExpr_4();

  class  Aux_rule__type__1Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__type__1Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *L_PAREN();
    Type_Context *type_();
    antlr4::tree::TerminalNode *R_PAREN();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__type__1Context* aux_rule__type__1();

  class  Aux_rule__importDecl_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__importDecl_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *L_PAREN();
    Kleene_star__importDecl_2Context *kleene_star__importDecl_2();
    antlr4::tree::TerminalNode *R_PAREN();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__importDecl_4Context* aux_rule__importDecl_4();

  class  Aux_rule__constDecl_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__constDecl_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *L_PAREN();
    Kleene_star__constDecl_2Context *kleene_star__constDecl_2();
    antlr4::tree::TerminalNode *R_PAREN();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__constDecl_4Context* aux_rule__constDecl_4();

  class  Aux_rule__typeDecl_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__typeDecl_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *L_PAREN();
    Kleene_star__typeDecl_2Context *kleene_star__typeDecl_2();
    antlr4::tree::TerminalNode *R_PAREN();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__typeDecl_4Context* aux_rule__typeDecl_4();

  class  Aux_rule__varDecl_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__varDecl_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *L_PAREN();
    Kleene_star__varDecl_2Context *kleene_star__varDecl_2();
    antlr4::tree::TerminalNode *R_PAREN();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__varDecl_4Context* aux_rule__varDecl_4();

  class  Aux_rule__varSpec_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__varSpec_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Type_Context *type_();
    Optional__varSpec_2Context *optional__varSpec_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__varSpec_4Context* aux_rule__varSpec_4();

  class  Aux_rule__varSpec_5Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__varSpec_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *ASSIGN();
    ExpressionListContext *expressionList();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__varSpec_5Context* aux_rule__varSpec_5();

  class  Aux_rule__channelType_3Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__channelType_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *CHAN();
    antlr4::tree::TerminalNode *RECEIVE();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__channelType_3Context* aux_rule__channelType_3();

  class  Aux_rule__channelType_4Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__channelType_4Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Optional__channelType_2Context *optional__channelType_2();
    antlr4::tree::TerminalNode *CHAN();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__channelType_4Context* aux_rule__channelType_4();

  class  Aux_rule__fieldDecl_3Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__fieldDecl_3Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    IdentifierListContext *identifierList();
    Type_Context *type_();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__fieldDecl_3Context* aux_rule__fieldDecl_3();

  class  Aux_rule__arguments_8Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__arguments_8Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    Type_Context *type_();
    Optional__arguments_2Context *optional__arguments_2();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__arguments_8Context* aux_rule__arguments_8();

  class  Aux_rule__slice_6Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__slice_6Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<ExpressionContext *> expression();
    ExpressionContext* expression(size_t i);
    antlr4::tree::TerminalNode *COLON();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__slice_6Context* aux_rule__slice_6();

  class  Aux_rule__primaryExpr_5Context : public antlr4::ParserRuleContext {
  public:
    Aux_rule__primaryExpr_5Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *L_PAREN();
    ExpressionContext *expression();
    antlr4::tree::TerminalNode *R_PAREN();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  Aux_rule__primaryExpr_5Context* aux_rule__primaryExpr_5();


  virtual bool sempred(antlr4::RuleContext *_localctx, size_t ruleIndex, size_t predicateIndex) override;
  bool aux_rule__eos_1Sempred(Aux_rule__eos_1Context *_localctx, size_t predicateIndex);
  bool aux_rule__eos_2Sempred(Aux_rule__eos_2Context *_localctx, size_t predicateIndex);

private:
  static std::vector<antlr4::dfa::DFA> _decisionToDFA;
  static antlr4::atn::PredictionContextCache _sharedContextCache;
  static std::vector<std::string> _ruleNames;
  static std::vector<std::string> _tokenNames;

  static std::vector<std::string> _literalNames;
  static std::vector<std::string> _symbolicNames;
  static antlr4::dfa::Vocabulary _vocabulary;
  static antlr4::atn::ATN _atn;
  static std::vector<uint16_t> _serializedATN;


  struct Initializer {
    Initializer();
  };
  static Initializer _init;
};

}  // namespace antlr_go_perses
