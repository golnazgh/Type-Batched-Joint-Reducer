
// Generated from PnfGoParser.g4 by ANTLR 4.7.2

#pragma once


#include "antlr4-runtime.h"
#include "PnfGoParserListener.h"


namespace antlr_go_perses {

/**
 * This class provides an empty implementation of PnfGoParserListener,
 * which can be extended to create a listener which only needs to handle a subset
 * of the available methods.
 */
class  PnfGoParserBaseListener : public PnfGoParserListener {
public:

  virtual void enterSourceFile(PnfGoParser::SourceFileContext * /*ctx*/) override { }
  virtual void exitSourceFile(PnfGoParser::SourceFileContext * /*ctx*/) override { }

  virtual void enterPackageClause(PnfGoParser::PackageClauseContext * /*ctx*/) override { }
  virtual void exitPackageClause(PnfGoParser::PackageClauseContext * /*ctx*/) override { }

  virtual void enterImportDecl(PnfGoParser::ImportDeclContext * /*ctx*/) override { }
  virtual void exitImportDecl(PnfGoParser::ImportDeclContext * /*ctx*/) override { }

  virtual void enterImportSpec(PnfGoParser::ImportSpecContext * /*ctx*/) override { }
  virtual void exitImportSpec(PnfGoParser::ImportSpecContext * /*ctx*/) override { }

  virtual void enterImportPath(PnfGoParser::ImportPathContext * /*ctx*/) override { }
  virtual void exitImportPath(PnfGoParser::ImportPathContext * /*ctx*/) override { }

  virtual void enterDeclaration(PnfGoParser::DeclarationContext * /*ctx*/) override { }
  virtual void exitDeclaration(PnfGoParser::DeclarationContext * /*ctx*/) override { }

  virtual void enterConstDecl(PnfGoParser::ConstDeclContext * /*ctx*/) override { }
  virtual void exitConstDecl(PnfGoParser::ConstDeclContext * /*ctx*/) override { }

  virtual void enterConstSpec(PnfGoParser::ConstSpecContext * /*ctx*/) override { }
  virtual void exitConstSpec(PnfGoParser::ConstSpecContext * /*ctx*/) override { }

  virtual void enterIdentifierList(PnfGoParser::IdentifierListContext * /*ctx*/) override { }
  virtual void exitIdentifierList(PnfGoParser::IdentifierListContext * /*ctx*/) override { }

  virtual void enterExpressionList(PnfGoParser::ExpressionListContext * /*ctx*/) override { }
  virtual void exitExpressionList(PnfGoParser::ExpressionListContext * /*ctx*/) override { }

  virtual void enterTypeDecl(PnfGoParser::TypeDeclContext * /*ctx*/) override { }
  virtual void exitTypeDecl(PnfGoParser::TypeDeclContext * /*ctx*/) override { }

  virtual void enterTypeSpec(PnfGoParser::TypeSpecContext * /*ctx*/) override { }
  virtual void exitTypeSpec(PnfGoParser::TypeSpecContext * /*ctx*/) override { }

  virtual void enterFunctionDecl(PnfGoParser::FunctionDeclContext * /*ctx*/) override { }
  virtual void exitFunctionDecl(PnfGoParser::FunctionDeclContext * /*ctx*/) override { }

  virtual void enterMethodDecl(PnfGoParser::MethodDeclContext * /*ctx*/) override { }
  virtual void exitMethodDecl(PnfGoParser::MethodDeclContext * /*ctx*/) override { }

  virtual void enterReceiver(PnfGoParser::ReceiverContext * /*ctx*/) override { }
  virtual void exitReceiver(PnfGoParser::ReceiverContext * /*ctx*/) override { }

  virtual void enterVarDecl(PnfGoParser::VarDeclContext * /*ctx*/) override { }
  virtual void exitVarDecl(PnfGoParser::VarDeclContext * /*ctx*/) override { }

  virtual void enterVarSpec(PnfGoParser::VarSpecContext * /*ctx*/) override { }
  virtual void exitVarSpec(PnfGoParser::VarSpecContext * /*ctx*/) override { }

  virtual void enterBlock(PnfGoParser::BlockContext * /*ctx*/) override { }
  virtual void exitBlock(PnfGoParser::BlockContext * /*ctx*/) override { }

  virtual void enterStatementList(PnfGoParser::StatementListContext * /*ctx*/) override { }
  virtual void exitStatementList(PnfGoParser::StatementListContext * /*ctx*/) override { }

  virtual void enterStatement(PnfGoParser::StatementContext * /*ctx*/) override { }
  virtual void exitStatement(PnfGoParser::StatementContext * /*ctx*/) override { }

  virtual void enterSimpleStmt(PnfGoParser::SimpleStmtContext * /*ctx*/) override { }
  virtual void exitSimpleStmt(PnfGoParser::SimpleStmtContext * /*ctx*/) override { }

  virtual void enterRealSimpleStmt(PnfGoParser::RealSimpleStmtContext * /*ctx*/) override { }
  virtual void exitRealSimpleStmt(PnfGoParser::RealSimpleStmtContext * /*ctx*/) override { }

  virtual void enterExpressionStmt(PnfGoParser::ExpressionStmtContext * /*ctx*/) override { }
  virtual void exitExpressionStmt(PnfGoParser::ExpressionStmtContext * /*ctx*/) override { }

  virtual void enterSendStmt(PnfGoParser::SendStmtContext * /*ctx*/) override { }
  virtual void exitSendStmt(PnfGoParser::SendStmtContext * /*ctx*/) override { }

  virtual void enterIncDecStmt(PnfGoParser::IncDecStmtContext * /*ctx*/) override { }
  virtual void exitIncDecStmt(PnfGoParser::IncDecStmtContext * /*ctx*/) override { }

  virtual void enterAssignment(PnfGoParser::AssignmentContext * /*ctx*/) override { }
  virtual void exitAssignment(PnfGoParser::AssignmentContext * /*ctx*/) override { }

  virtual void enterAssign_op(PnfGoParser::Assign_opContext * /*ctx*/) override { }
  virtual void exitAssign_op(PnfGoParser::Assign_opContext * /*ctx*/) override { }

  virtual void enterShortVarDecl(PnfGoParser::ShortVarDeclContext * /*ctx*/) override { }
  virtual void exitShortVarDecl(PnfGoParser::ShortVarDeclContext * /*ctx*/) override { }

  virtual void enterLabeledStmt(PnfGoParser::LabeledStmtContext * /*ctx*/) override { }
  virtual void exitLabeledStmt(PnfGoParser::LabeledStmtContext * /*ctx*/) override { }

  virtual void enterReturnStmt(PnfGoParser::ReturnStmtContext * /*ctx*/) override { }
  virtual void exitReturnStmt(PnfGoParser::ReturnStmtContext * /*ctx*/) override { }

  virtual void enterBreakStmt(PnfGoParser::BreakStmtContext * /*ctx*/) override { }
  virtual void exitBreakStmt(PnfGoParser::BreakStmtContext * /*ctx*/) override { }

  virtual void enterContinueStmt(PnfGoParser::ContinueStmtContext * /*ctx*/) override { }
  virtual void exitContinueStmt(PnfGoParser::ContinueStmtContext * /*ctx*/) override { }

  virtual void enterGotoStmt(PnfGoParser::GotoStmtContext * /*ctx*/) override { }
  virtual void exitGotoStmt(PnfGoParser::GotoStmtContext * /*ctx*/) override { }

  virtual void enterFallthroughStmt(PnfGoParser::FallthroughStmtContext * /*ctx*/) override { }
  virtual void exitFallthroughStmt(PnfGoParser::FallthroughStmtContext * /*ctx*/) override { }

  virtual void enterDeferStmt(PnfGoParser::DeferStmtContext * /*ctx*/) override { }
  virtual void exitDeferStmt(PnfGoParser::DeferStmtContext * /*ctx*/) override { }

  virtual void enterIfStmt(PnfGoParser::IfStmtContext * /*ctx*/) override { }
  virtual void exitIfStmt(PnfGoParser::IfStmtContext * /*ctx*/) override { }

  virtual void enterExprSwitchStmt(PnfGoParser::ExprSwitchStmtContext * /*ctx*/) override { }
  virtual void exitExprSwitchStmt(PnfGoParser::ExprSwitchStmtContext * /*ctx*/) override { }

  virtual void enterExprCaseClause(PnfGoParser::ExprCaseClauseContext * /*ctx*/) override { }
  virtual void exitExprCaseClause(PnfGoParser::ExprCaseClauseContext * /*ctx*/) override { }

  virtual void enterExprSwitchCase(PnfGoParser::ExprSwitchCaseContext * /*ctx*/) override { }
  virtual void exitExprSwitchCase(PnfGoParser::ExprSwitchCaseContext * /*ctx*/) override { }

  virtual void enterTypeSwitchStmt(PnfGoParser::TypeSwitchStmtContext * /*ctx*/) override { }
  virtual void exitTypeSwitchStmt(PnfGoParser::TypeSwitchStmtContext * /*ctx*/) override { }

  virtual void enterTypeSwitchGuard(PnfGoParser::TypeSwitchGuardContext * /*ctx*/) override { }
  virtual void exitTypeSwitchGuard(PnfGoParser::TypeSwitchGuardContext * /*ctx*/) override { }

  virtual void enterTypeCaseClause(PnfGoParser::TypeCaseClauseContext * /*ctx*/) override { }
  virtual void exitTypeCaseClause(PnfGoParser::TypeCaseClauseContext * /*ctx*/) override { }

  virtual void enterTypeSwitchCase(PnfGoParser::TypeSwitchCaseContext * /*ctx*/) override { }
  virtual void exitTypeSwitchCase(PnfGoParser::TypeSwitchCaseContext * /*ctx*/) override { }

  virtual void enterTypeList(PnfGoParser::TypeListContext * /*ctx*/) override { }
  virtual void exitTypeList(PnfGoParser::TypeListContext * /*ctx*/) override { }

  virtual void enterSelectStmt(PnfGoParser::SelectStmtContext * /*ctx*/) override { }
  virtual void exitSelectStmt(PnfGoParser::SelectStmtContext * /*ctx*/) override { }

  virtual void enterCommClause(PnfGoParser::CommClauseContext * /*ctx*/) override { }
  virtual void exitCommClause(PnfGoParser::CommClauseContext * /*ctx*/) override { }

  virtual void enterCommCase(PnfGoParser::CommCaseContext * /*ctx*/) override { }
  virtual void exitCommCase(PnfGoParser::CommCaseContext * /*ctx*/) override { }

  virtual void enterRecvStmt(PnfGoParser::RecvStmtContext * /*ctx*/) override { }
  virtual void exitRecvStmt(PnfGoParser::RecvStmtContext * /*ctx*/) override { }

  virtual void enterForStmt(PnfGoParser::ForStmtContext * /*ctx*/) override { }
  virtual void exitForStmt(PnfGoParser::ForStmtContext * /*ctx*/) override { }

  virtual void enterForClause(PnfGoParser::ForClauseContext * /*ctx*/) override { }
  virtual void exitForClause(PnfGoParser::ForClauseContext * /*ctx*/) override { }

  virtual void enterRangeClause(PnfGoParser::RangeClauseContext * /*ctx*/) override { }
  virtual void exitRangeClause(PnfGoParser::RangeClauseContext * /*ctx*/) override { }

  virtual void enterGoStmt(PnfGoParser::GoStmtContext * /*ctx*/) override { }
  virtual void exitGoStmt(PnfGoParser::GoStmtContext * /*ctx*/) override { }

  virtual void enterTypeName(PnfGoParser::TypeNameContext * /*ctx*/) override { }
  virtual void exitTypeName(PnfGoParser::TypeNameContext * /*ctx*/) override { }

  virtual void enterArrayType(PnfGoParser::ArrayTypeContext * /*ctx*/) override { }
  virtual void exitArrayType(PnfGoParser::ArrayTypeContext * /*ctx*/) override { }

  virtual void enterElementType(PnfGoParser::ElementTypeContext * /*ctx*/) override { }
  virtual void exitElementType(PnfGoParser::ElementTypeContext * /*ctx*/) override { }

  virtual void enterPointerType(PnfGoParser::PointerTypeContext * /*ctx*/) override { }
  virtual void exitPointerType(PnfGoParser::PointerTypeContext * /*ctx*/) override { }

  virtual void enterInterfaceType(PnfGoParser::InterfaceTypeContext * /*ctx*/) override { }
  virtual void exitInterfaceType(PnfGoParser::InterfaceTypeContext * /*ctx*/) override { }

  virtual void enterSliceType(PnfGoParser::SliceTypeContext * /*ctx*/) override { }
  virtual void exitSliceType(PnfGoParser::SliceTypeContext * /*ctx*/) override { }

  virtual void enterMapType(PnfGoParser::MapTypeContext * /*ctx*/) override { }
  virtual void exitMapType(PnfGoParser::MapTypeContext * /*ctx*/) override { }

  virtual void enterChannelType(PnfGoParser::ChannelTypeContext * /*ctx*/) override { }
  virtual void exitChannelType(PnfGoParser::ChannelTypeContext * /*ctx*/) override { }

  virtual void enterMethodSpec(PnfGoParser::MethodSpecContext * /*ctx*/) override { }
  virtual void exitMethodSpec(PnfGoParser::MethodSpecContext * /*ctx*/) override { }

  virtual void enterFunctionType(PnfGoParser::FunctionTypeContext * /*ctx*/) override { }
  virtual void exitFunctionType(PnfGoParser::FunctionTypeContext * /*ctx*/) override { }

  virtual void enterSignature(PnfGoParser::SignatureContext * /*ctx*/) override { }
  virtual void exitSignature(PnfGoParser::SignatureContext * /*ctx*/) override { }

  virtual void enterResult(PnfGoParser::ResultContext * /*ctx*/) override { }
  virtual void exitResult(PnfGoParser::ResultContext * /*ctx*/) override { }

  virtual void enterParameters(PnfGoParser::ParametersContext * /*ctx*/) override { }
  virtual void exitParameters(PnfGoParser::ParametersContext * /*ctx*/) override { }

  virtual void enterParameterDecl(PnfGoParser::ParameterDeclContext * /*ctx*/) override { }
  virtual void exitParameterDecl(PnfGoParser::ParameterDeclContext * /*ctx*/) override { }

  virtual void enterUnaryExpr(PnfGoParser::UnaryExprContext * /*ctx*/) override { }
  virtual void exitUnaryExpr(PnfGoParser::UnaryExprContext * /*ctx*/) override { }

  virtual void enterConversion(PnfGoParser::ConversionContext * /*ctx*/) override { }
  virtual void exitConversion(PnfGoParser::ConversionContext * /*ctx*/) override { }

  virtual void enterQualifiedIdent(PnfGoParser::QualifiedIdentContext * /*ctx*/) override { }
  virtual void exitQualifiedIdent(PnfGoParser::QualifiedIdentContext * /*ctx*/) override { }

  virtual void enterCompositeLit(PnfGoParser::CompositeLitContext * /*ctx*/) override { }
  virtual void exitCompositeLit(PnfGoParser::CompositeLitContext * /*ctx*/) override { }

  virtual void enterLiteralType(PnfGoParser::LiteralTypeContext * /*ctx*/) override { }
  virtual void exitLiteralType(PnfGoParser::LiteralTypeContext * /*ctx*/) override { }

  virtual void enterLiteralValue(PnfGoParser::LiteralValueContext * /*ctx*/) override { }
  virtual void exitLiteralValue(PnfGoParser::LiteralValueContext * /*ctx*/) override { }

  virtual void enterElementList(PnfGoParser::ElementListContext * /*ctx*/) override { }
  virtual void exitElementList(PnfGoParser::ElementListContext * /*ctx*/) override { }

  virtual void enterKeyedElement(PnfGoParser::KeyedElementContext * /*ctx*/) override { }
  virtual void exitKeyedElement(PnfGoParser::KeyedElementContext * /*ctx*/) override { }

  virtual void enterKey(PnfGoParser::KeyContext * /*ctx*/) override { }
  virtual void exitKey(PnfGoParser::KeyContext * /*ctx*/) override { }

  virtual void enterElement(PnfGoParser::ElementContext * /*ctx*/) override { }
  virtual void exitElement(PnfGoParser::ElementContext * /*ctx*/) override { }

  virtual void enterStructType(PnfGoParser::StructTypeContext * /*ctx*/) override { }
  virtual void exitStructType(PnfGoParser::StructTypeContext * /*ctx*/) override { }

  virtual void enterFieldDecl(PnfGoParser::FieldDeclContext * /*ctx*/) override { }
  virtual void exitFieldDecl(PnfGoParser::FieldDeclContext * /*ctx*/) override { }

  virtual void enterString_(PnfGoParser::String_Context * /*ctx*/) override { }
  virtual void exitString_(PnfGoParser::String_Context * /*ctx*/) override { }

  virtual void enterAnonymousField(PnfGoParser::AnonymousFieldContext * /*ctx*/) override { }
  virtual void exitAnonymousField(PnfGoParser::AnonymousFieldContext * /*ctx*/) override { }

  virtual void enterFunctionLit(PnfGoParser::FunctionLitContext * /*ctx*/) override { }
  virtual void exitFunctionLit(PnfGoParser::FunctionLitContext * /*ctx*/) override { }

  virtual void enterIndex(PnfGoParser::IndexContext * /*ctx*/) override { }
  virtual void exitIndex(PnfGoParser::IndexContext * /*ctx*/) override { }

  virtual void enterSlice(PnfGoParser::SliceContext * /*ctx*/) override { }
  virtual void exitSlice(PnfGoParser::SliceContext * /*ctx*/) override { }

  virtual void enterTypeAssertion(PnfGoParser::TypeAssertionContext * /*ctx*/) override { }
  virtual void exitTypeAssertion(PnfGoParser::TypeAssertionContext * /*ctx*/) override { }

  virtual void enterArguments(PnfGoParser::ArgumentsContext * /*ctx*/) override { }
  virtual void exitArguments(PnfGoParser::ArgumentsContext * /*ctx*/) override { }

  virtual void enterMethodExpr(PnfGoParser::MethodExprContext * /*ctx*/) override { }
  virtual void exitMethodExpr(PnfGoParser::MethodExprContext * /*ctx*/) override { }

  virtual void enterEos(PnfGoParser::EosContext * /*ctx*/) override { }
  virtual void exitEos(PnfGoParser::EosContext * /*ctx*/) override { }

  virtual void enterAux_rule__sourceFile_1(PnfGoParser::Aux_rule__sourceFile_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__sourceFile_1(PnfGoParser::Aux_rule__sourceFile_1Context * /*ctx*/) override { }

  virtual void enterKleene_star__sourceFile_2(PnfGoParser::Kleene_star__sourceFile_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__sourceFile_2(PnfGoParser::Kleene_star__sourceFile_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__sourceFile_3(PnfGoParser::Aux_rule__sourceFile_3Context * /*ctx*/) override { }
  virtual void exitAux_rule__sourceFile_3(PnfGoParser::Aux_rule__sourceFile_3Context * /*ctx*/) override { }

  virtual void enterKleene_star__sourceFile_4(PnfGoParser::Kleene_star__sourceFile_4Context * /*ctx*/) override { }
  virtual void exitKleene_star__sourceFile_4(PnfGoParser::Kleene_star__sourceFile_4Context * /*ctx*/) override { }

  virtual void enterAux_rule__importDecl_1(PnfGoParser::Aux_rule__importDecl_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__importDecl_1(PnfGoParser::Aux_rule__importDecl_1Context * /*ctx*/) override { }

  virtual void enterKleene_star__importDecl_2(PnfGoParser::Kleene_star__importDecl_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__importDecl_2(PnfGoParser::Kleene_star__importDecl_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__importSpec_1(PnfGoParser::Aux_rule__importSpec_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__importSpec_1(PnfGoParser::Aux_rule__importSpec_1Context * /*ctx*/) override { }

  virtual void enterOptional__importSpec_2(PnfGoParser::Optional__importSpec_2Context * /*ctx*/) override { }
  virtual void exitOptional__importSpec_2(PnfGoParser::Optional__importSpec_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__constDecl_1(PnfGoParser::Aux_rule__constDecl_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__constDecl_1(PnfGoParser::Aux_rule__constDecl_1Context * /*ctx*/) override { }

  virtual void enterKleene_star__constDecl_2(PnfGoParser::Kleene_star__constDecl_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__constDecl_2(PnfGoParser::Kleene_star__constDecl_2Context * /*ctx*/) override { }

  virtual void enterOptional__constSpec_1(PnfGoParser::Optional__constSpec_1Context * /*ctx*/) override { }
  virtual void exitOptional__constSpec_1(PnfGoParser::Optional__constSpec_1Context * /*ctx*/) override { }

  virtual void enterAux_rule__constSpec_2(PnfGoParser::Aux_rule__constSpec_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__constSpec_2(PnfGoParser::Aux_rule__constSpec_2Context * /*ctx*/) override { }

  virtual void enterOptional__constSpec_3(PnfGoParser::Optional__constSpec_3Context * /*ctx*/) override { }
  virtual void exitOptional__constSpec_3(PnfGoParser::Optional__constSpec_3Context * /*ctx*/) override { }

  virtual void enterAux_rule__identifierList_1(PnfGoParser::Aux_rule__identifierList_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__identifierList_1(PnfGoParser::Aux_rule__identifierList_1Context * /*ctx*/) override { }

  virtual void enterKleene_star__identifierList_2(PnfGoParser::Kleene_star__identifierList_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__identifierList_2(PnfGoParser::Kleene_star__identifierList_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__expressionList_1(PnfGoParser::Aux_rule__expressionList_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__expressionList_1(PnfGoParser::Aux_rule__expressionList_1Context * /*ctx*/) override { }

  virtual void enterKleene_star__expressionList_2(PnfGoParser::Kleene_star__expressionList_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__expressionList_2(PnfGoParser::Kleene_star__expressionList_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__typeDecl_1(PnfGoParser::Aux_rule__typeDecl_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__typeDecl_1(PnfGoParser::Aux_rule__typeDecl_1Context * /*ctx*/) override { }

  virtual void enterKleene_star__typeDecl_2(PnfGoParser::Kleene_star__typeDecl_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__typeDecl_2(PnfGoParser::Kleene_star__typeDecl_2Context * /*ctx*/) override { }

  virtual void enterOptional__typeSpec_1(PnfGoParser::Optional__typeSpec_1Context * /*ctx*/) override { }
  virtual void exitOptional__typeSpec_1(PnfGoParser::Optional__typeSpec_1Context * /*ctx*/) override { }

  virtual void enterOptional__functionDecl_1(PnfGoParser::Optional__functionDecl_1Context * /*ctx*/) override { }
  virtual void exitOptional__functionDecl_1(PnfGoParser::Optional__functionDecl_1Context * /*ctx*/) override { }

  virtual void enterAux_rule__varDecl_1(PnfGoParser::Aux_rule__varDecl_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__varDecl_1(PnfGoParser::Aux_rule__varDecl_1Context * /*ctx*/) override { }

  virtual void enterKleene_star__varDecl_2(PnfGoParser::Kleene_star__varDecl_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__varDecl_2(PnfGoParser::Kleene_star__varDecl_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__varSpec_1(PnfGoParser::Aux_rule__varSpec_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__varSpec_1(PnfGoParser::Aux_rule__varSpec_1Context * /*ctx*/) override { }

  virtual void enterOptional__varSpec_2(PnfGoParser::Optional__varSpec_2Context * /*ctx*/) override { }
  virtual void exitOptional__varSpec_2(PnfGoParser::Optional__varSpec_2Context * /*ctx*/) override { }

  virtual void enterOptional__block_1(PnfGoParser::Optional__block_1Context * /*ctx*/) override { }
  virtual void exitOptional__block_1(PnfGoParser::Optional__block_1Context * /*ctx*/) override { }

  virtual void enterAux_rule__statementList_1(PnfGoParser::Aux_rule__statementList_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__statementList_1(PnfGoParser::Aux_rule__statementList_1Context * /*ctx*/) override { }

  virtual void enterAux_rule__assign_op_1(PnfGoParser::Aux_rule__assign_op_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__assign_op_1(PnfGoParser::Aux_rule__assign_op_1Context * /*ctx*/) override { }

  virtual void enterOptional__assign_op_2(PnfGoParser::Optional__assign_op_2Context * /*ctx*/) override { }
  virtual void exitOptional__assign_op_2(PnfGoParser::Optional__assign_op_2Context * /*ctx*/) override { }

  virtual void enterOptional__returnStmt_1(PnfGoParser::Optional__returnStmt_1Context * /*ctx*/) override { }
  virtual void exitOptional__returnStmt_1(PnfGoParser::Optional__returnStmt_1Context * /*ctx*/) override { }

  virtual void enterOptional__breakStmt_1(PnfGoParser::Optional__breakStmt_1Context * /*ctx*/) override { }
  virtual void exitOptional__breakStmt_1(PnfGoParser::Optional__breakStmt_1Context * /*ctx*/) override { }

  virtual void enterAux_rule__ifStmt_1(PnfGoParser::Aux_rule__ifStmt_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__ifStmt_1(PnfGoParser::Aux_rule__ifStmt_1Context * /*ctx*/) override { }

  virtual void enterOptional__ifStmt_2(PnfGoParser::Optional__ifStmt_2Context * /*ctx*/) override { }
  virtual void exitOptional__ifStmt_2(PnfGoParser::Optional__ifStmt_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__ifStmt_3(PnfGoParser::Aux_rule__ifStmt_3Context * /*ctx*/) override { }
  virtual void exitAux_rule__ifStmt_3(PnfGoParser::Aux_rule__ifStmt_3Context * /*ctx*/) override { }

  virtual void enterOptional__ifStmt_4(PnfGoParser::Optional__ifStmt_4Context * /*ctx*/) override { }
  virtual void exitOptional__ifStmt_4(PnfGoParser::Optional__ifStmt_4Context * /*ctx*/) override { }

  virtual void enterOptional__exprSwitchStmt_3(PnfGoParser::Optional__exprSwitchStmt_3Context * /*ctx*/) override { }
  virtual void exitOptional__exprSwitchStmt_3(PnfGoParser::Optional__exprSwitchStmt_3Context * /*ctx*/) override { }

  virtual void enterKleene_star__exprSwitchStmt_4(PnfGoParser::Kleene_star__exprSwitchStmt_4Context * /*ctx*/) override { }
  virtual void exitKleene_star__exprSwitchStmt_4(PnfGoParser::Kleene_star__exprSwitchStmt_4Context * /*ctx*/) override { }

  virtual void enterKleene_star__typeSwitchStmt_3(PnfGoParser::Kleene_star__typeSwitchStmt_3Context * /*ctx*/) override { }
  virtual void exitKleene_star__typeSwitchStmt_3(PnfGoParser::Kleene_star__typeSwitchStmt_3Context * /*ctx*/) override { }

  virtual void enterAux_rule__typeSwitchGuard_1(PnfGoParser::Aux_rule__typeSwitchGuard_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__typeSwitchGuard_1(PnfGoParser::Aux_rule__typeSwitchGuard_1Context * /*ctx*/) override { }

  virtual void enterOptional__typeSwitchGuard_2(PnfGoParser::Optional__typeSwitchGuard_2Context * /*ctx*/) override { }
  virtual void exitOptional__typeSwitchGuard_2(PnfGoParser::Optional__typeSwitchGuard_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__typeList_1(PnfGoParser::Aux_rule__typeList_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__typeList_1(PnfGoParser::Aux_rule__typeList_1Context * /*ctx*/) override { }

  virtual void enterKleene_star__typeList_2(PnfGoParser::Kleene_star__typeList_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__typeList_2(PnfGoParser::Kleene_star__typeList_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__selectStmt_1(PnfGoParser::Kleene_star__selectStmt_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__selectStmt_1(PnfGoParser::Kleene_star__selectStmt_1Context * /*ctx*/) override { }

  virtual void enterAux_rule__recvStmt_1(PnfGoParser::Aux_rule__recvStmt_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__recvStmt_1(PnfGoParser::Aux_rule__recvStmt_1Context * /*ctx*/) override { }

  virtual void enterOptional__recvStmt_2(PnfGoParser::Optional__recvStmt_2Context * /*ctx*/) override { }
  virtual void exitOptional__recvStmt_2(PnfGoParser::Optional__recvStmt_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__forStmt_1(PnfGoParser::Aux_rule__forStmt_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__forStmt_1(PnfGoParser::Aux_rule__forStmt_1Context * /*ctx*/) override { }

  virtual void enterOptional__forStmt_2(PnfGoParser::Optional__forStmt_2Context * /*ctx*/) override { }
  virtual void exitOptional__forStmt_2(PnfGoParser::Optional__forStmt_2Context * /*ctx*/) override { }

  virtual void enterOptional__forClause_1(PnfGoParser::Optional__forClause_1Context * /*ctx*/) override { }
  virtual void exitOptional__forClause_1(PnfGoParser::Optional__forClause_1Context * /*ctx*/) override { }

  virtual void enterAux_rule__interfaceType_1(PnfGoParser::Aux_rule__interfaceType_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__interfaceType_1(PnfGoParser::Aux_rule__interfaceType_1Context * /*ctx*/) override { }

  virtual void enterKleene_star__interfaceType_2(PnfGoParser::Kleene_star__interfaceType_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__interfaceType_2(PnfGoParser::Kleene_star__interfaceType_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__parameters_1(PnfGoParser::Aux_rule__parameters_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__parameters_1(PnfGoParser::Aux_rule__parameters_1Context * /*ctx*/) override { }

  virtual void enterKleene_star__parameters_2(PnfGoParser::Kleene_star__parameters_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__parameters_2(PnfGoParser::Kleene_star__parameters_2Context * /*ctx*/) override { }

  virtual void enterOptional__parameters_3(PnfGoParser::Optional__parameters_3Context * /*ctx*/) override { }
  virtual void exitOptional__parameters_3(PnfGoParser::Optional__parameters_3Context * /*ctx*/) override { }

  virtual void enterAux_rule__parameters_4(PnfGoParser::Aux_rule__parameters_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__parameters_4(PnfGoParser::Aux_rule__parameters_4Context * /*ctx*/) override { }

  virtual void enterOptional__parameters_5(PnfGoParser::Optional__parameters_5Context * /*ctx*/) override { }
  virtual void exitOptional__parameters_5(PnfGoParser::Optional__parameters_5Context * /*ctx*/) override { }

  virtual void enterOptional__parameterDecl_1(PnfGoParser::Optional__parameterDecl_1Context * /*ctx*/) override { }
  virtual void exitOptional__parameterDecl_1(PnfGoParser::Optional__parameterDecl_1Context * /*ctx*/) override { }

  virtual void enterOptional__parameterDecl_2(PnfGoParser::Optional__parameterDecl_2Context * /*ctx*/) override { }
  virtual void exitOptional__parameterDecl_2(PnfGoParser::Optional__parameterDecl_2Context * /*ctx*/) override { }

  virtual void enterOptional__conversion_1(PnfGoParser::Optional__conversion_1Context * /*ctx*/) override { }
  virtual void exitOptional__conversion_1(PnfGoParser::Optional__conversion_1Context * /*ctx*/) override { }

  virtual void enterAux_rule__literalValue_2(PnfGoParser::Aux_rule__literalValue_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__literalValue_2(PnfGoParser::Aux_rule__literalValue_2Context * /*ctx*/) override { }

  virtual void enterOptional__literalValue_3(PnfGoParser::Optional__literalValue_3Context * /*ctx*/) override { }
  virtual void exitOptional__literalValue_3(PnfGoParser::Optional__literalValue_3Context * /*ctx*/) override { }

  virtual void enterAux_rule__elementList_1(PnfGoParser::Aux_rule__elementList_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__elementList_1(PnfGoParser::Aux_rule__elementList_1Context * /*ctx*/) override { }

  virtual void enterKleene_star__elementList_2(PnfGoParser::Kleene_star__elementList_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__elementList_2(PnfGoParser::Kleene_star__elementList_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__keyedElement_1(PnfGoParser::Aux_rule__keyedElement_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__keyedElement_1(PnfGoParser::Aux_rule__keyedElement_1Context * /*ctx*/) override { }

  virtual void enterOptional__keyedElement_2(PnfGoParser::Optional__keyedElement_2Context * /*ctx*/) override { }
  virtual void exitOptional__keyedElement_2(PnfGoParser::Optional__keyedElement_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__structType_1(PnfGoParser::Aux_rule__structType_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__structType_1(PnfGoParser::Aux_rule__structType_1Context * /*ctx*/) override { }

  virtual void enterKleene_star__structType_2(PnfGoParser::Kleene_star__structType_2Context * /*ctx*/) override { }
  virtual void exitKleene_star__structType_2(PnfGoParser::Kleene_star__structType_2Context * /*ctx*/) override { }

  virtual void enterOptional__fieldDecl_1(PnfGoParser::Optional__fieldDecl_1Context * /*ctx*/) override { }
  virtual void exitOptional__fieldDecl_1(PnfGoParser::Optional__fieldDecl_1Context * /*ctx*/) override { }

  virtual void enterOptional__anonymousField_1(PnfGoParser::Optional__anonymousField_1Context * /*ctx*/) override { }
  virtual void exitOptional__anonymousField_1(PnfGoParser::Optional__anonymousField_1Context * /*ctx*/) override { }

  virtual void enterAux_rule__arguments_1(PnfGoParser::Aux_rule__arguments_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__arguments_1(PnfGoParser::Aux_rule__arguments_1Context * /*ctx*/) override { }

  virtual void enterOptional__arguments_2(PnfGoParser::Optional__arguments_2Context * /*ctx*/) override { }
  virtual void exitOptional__arguments_2(PnfGoParser::Optional__arguments_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__arguments_5(PnfGoParser::Aux_rule__arguments_5Context * /*ctx*/) override { }
  virtual void exitAux_rule__arguments_5(PnfGoParser::Aux_rule__arguments_5Context * /*ctx*/) override { }

  virtual void enterOptional__arguments_6(PnfGoParser::Optional__arguments_6Context * /*ctx*/) override { }
  virtual void exitOptional__arguments_6(PnfGoParser::Optional__arguments_6Context * /*ctx*/) override { }

  virtual void enterAux_rule__expression_2(PnfGoParser::Aux_rule__expression_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__expression_2(PnfGoParser::Aux_rule__expression_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__expression_1(PnfGoParser::Kleene_star__expression_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__expression_1(PnfGoParser::Kleene_star__expression_1Context * /*ctx*/) override { }

  virtual void enterExpression(PnfGoParser::ExpressionContext * /*ctx*/) override { }
  virtual void exitExpression(PnfGoParser::ExpressionContext * /*ctx*/) override { }

  virtual void enterAux_rule__primaryExpr_2(PnfGoParser::Aux_rule__primaryExpr_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__primaryExpr_2(PnfGoParser::Aux_rule__primaryExpr_2Context * /*ctx*/) override { }

  virtual void enterKleene_star__primaryExpr_1(PnfGoParser::Kleene_star__primaryExpr_1Context * /*ctx*/) override { }
  virtual void exitKleene_star__primaryExpr_1(PnfGoParser::Kleene_star__primaryExpr_1Context * /*ctx*/) override { }

  virtual void enterPrimaryExpr(PnfGoParser::PrimaryExprContext * /*ctx*/) override { }
  virtual void exitPrimaryExpr(PnfGoParser::PrimaryExprContext * /*ctx*/) override { }

  virtual void enterOptional__signature_1(PnfGoParser::Optional__signature_1Context * /*ctx*/) override { }
  virtual void exitOptional__signature_1(PnfGoParser::Optional__signature_1Context * /*ctx*/) override { }

  virtual void enterAltnt_block__expression_3(PnfGoParser::Altnt_block__expression_3Context * /*ctx*/) override { }
  virtual void exitAltnt_block__expression_3(PnfGoParser::Altnt_block__expression_3Context * /*ctx*/) override { }

  virtual void enterType_(PnfGoParser::Type_Context * /*ctx*/) override { }
  virtual void exitType_(PnfGoParser::Type_Context * /*ctx*/) override { }

  virtual void enterRealStatement(PnfGoParser::RealStatementContext * /*ctx*/) override { }
  virtual void exitRealStatement(PnfGoParser::RealStatementContext * /*ctx*/) override { }

  virtual void enterAltnt_block__importDecl_3(PnfGoParser::Altnt_block__importDecl_3Context * /*ctx*/) override { }
  virtual void exitAltnt_block__importDecl_3(PnfGoParser::Altnt_block__importDecl_3Context * /*ctx*/) override { }

  virtual void enterAltnt_block__constDecl_3(PnfGoParser::Altnt_block__constDecl_3Context * /*ctx*/) override { }
  virtual void exitAltnt_block__constDecl_3(PnfGoParser::Altnt_block__constDecl_3Context * /*ctx*/) override { }

  virtual void enterAltnt_block__typeDecl_3(PnfGoParser::Altnt_block__typeDecl_3Context * /*ctx*/) override { }
  virtual void exitAltnt_block__typeDecl_3(PnfGoParser::Altnt_block__typeDecl_3Context * /*ctx*/) override { }

  virtual void enterAltnt_block__varDecl_3(PnfGoParser::Altnt_block__varDecl_3Context * /*ctx*/) override { }
  virtual void exitAltnt_block__varDecl_3(PnfGoParser::Altnt_block__varDecl_3Context * /*ctx*/) override { }

  virtual void enterAltnt_block__varSpec_3(PnfGoParser::Altnt_block__varSpec_3Context * /*ctx*/) override { }
  virtual void exitAltnt_block__varSpec_3(PnfGoParser::Altnt_block__varSpec_3Context * /*ctx*/) override { }

  virtual void enterAltnt_block__incDecStmt_1(PnfGoParser::Altnt_block__incDecStmt_1Context * /*ctx*/) override { }
  virtual void exitAltnt_block__incDecStmt_1(PnfGoParser::Altnt_block__incDecStmt_1Context * /*ctx*/) override { }

  virtual void enterAltnt_block__typeList_3(PnfGoParser::Altnt_block__typeList_3Context * /*ctx*/) override { }
  virtual void exitAltnt_block__typeList_3(PnfGoParser::Altnt_block__typeList_3Context * /*ctx*/) override { }

  virtual void enterAltnt_block__commCase_1(PnfGoParser::Altnt_block__commCase_1Context * /*ctx*/) override { }
  virtual void exitAltnt_block__commCase_1(PnfGoParser::Altnt_block__commCase_1Context * /*ctx*/) override { }

  virtual void enterAltnt_block__channelType_1(PnfGoParser::Altnt_block__channelType_1Context * /*ctx*/) override { }
  virtual void exitAltnt_block__channelType_1(PnfGoParser::Altnt_block__channelType_1Context * /*ctx*/) override { }

  virtual void enterAltnt_block__unaryExpr_1(PnfGoParser::Altnt_block__unaryExpr_1Context * /*ctx*/) override { }
  virtual void exitAltnt_block__unaryExpr_1(PnfGoParser::Altnt_block__unaryExpr_1Context * /*ctx*/) override { }

  virtual void enterAltnt_block__fieldDecl_2(PnfGoParser::Altnt_block__fieldDecl_2Context * /*ctx*/) override { }
  virtual void exitAltnt_block__fieldDecl_2(PnfGoParser::Altnt_block__fieldDecl_2Context * /*ctx*/) override { }

  virtual void enterAltnt_block__slice_4(PnfGoParser::Altnt_block__slice_4Context * /*ctx*/) override { }
  virtual void exitAltnt_block__slice_4(PnfGoParser::Altnt_block__slice_4Context * /*ctx*/) override { }

  virtual void enterAltnt_block__sourceFile_5(PnfGoParser::Altnt_block__sourceFile_5Context * /*ctx*/) override { }
  virtual void exitAltnt_block__sourceFile_5(PnfGoParser::Altnt_block__sourceFile_5Context * /*ctx*/) override { }

  virtual void enterAltnt_block__ifStmt_5(PnfGoParser::Altnt_block__ifStmt_5Context * /*ctx*/) override { }
  virtual void exitAltnt_block__ifStmt_5(PnfGoParser::Altnt_block__ifStmt_5Context * /*ctx*/) override { }

  virtual void enterAltnt_block__arguments_7(PnfGoParser::Altnt_block__arguments_7Context * /*ctx*/) override { }
  virtual void exitAltnt_block__arguments_7(PnfGoParser::Altnt_block__arguments_7Context * /*ctx*/) override { }

  virtual void enterOptional__channelType_2(PnfGoParser::Optional__channelType_2Context * /*ctx*/) override { }
  virtual void exitOptional__channelType_2(PnfGoParser::Optional__channelType_2Context * /*ctx*/) override { }

  virtual void enterAltnt_block__slice_5(PnfGoParser::Altnt_block__slice_5Context * /*ctx*/) override { }
  virtual void exitAltnt_block__slice_5(PnfGoParser::Altnt_block__slice_5Context * /*ctx*/) override { }

  virtual void enterAux_rule__primaryExpr_3(PnfGoParser::Aux_rule__primaryExpr_3Context * /*ctx*/) override { }
  virtual void exitAux_rule__primaryExpr_3(PnfGoParser::Aux_rule__primaryExpr_3Context * /*ctx*/) override { }

  virtual void enterAux_rule__sourceFile_6(PnfGoParser::Aux_rule__sourceFile_6Context * /*ctx*/) override { }
  virtual void exitAux_rule__sourceFile_6(PnfGoParser::Aux_rule__sourceFile_6Context * /*ctx*/) override { }

  virtual void enterAux_rule__exprSwitchCase_1(PnfGoParser::Aux_rule__exprSwitchCase_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__exprSwitchCase_1(PnfGoParser::Aux_rule__exprSwitchCase_1Context * /*ctx*/) override { }

  virtual void enterAux_rule__typeSwitchCase_1(PnfGoParser::Aux_rule__typeSwitchCase_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__typeSwitchCase_1(PnfGoParser::Aux_rule__typeSwitchCase_1Context * /*ctx*/) override { }

  virtual void enterAux_rule__commCase_2(PnfGoParser::Aux_rule__commCase_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__commCase_2(PnfGoParser::Aux_rule__commCase_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__methodSpec_2(PnfGoParser::Aux_rule__methodSpec_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__methodSpec_2(PnfGoParser::Aux_rule__methodSpec_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__unaryExpr_2(PnfGoParser::Aux_rule__unaryExpr_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__unaryExpr_2(PnfGoParser::Aux_rule__unaryExpr_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__literalType_1(PnfGoParser::Aux_rule__literalType_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__literalType_1(PnfGoParser::Aux_rule__literalType_1Context * /*ctx*/) override { }

  virtual void enterAux_rule__eos_1(PnfGoParser::Aux_rule__eos_1Context * /*ctx*/) override { }
  virtual void exitAux_rule__eos_1(PnfGoParser::Aux_rule__eos_1Context * /*ctx*/) override { }

  virtual void enterAux_rule__eos_2(PnfGoParser::Aux_rule__eos_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__eos_2(PnfGoParser::Aux_rule__eos_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__statementList_2(PnfGoParser::Aux_rule__statementList_2Context * /*ctx*/) override { }
  virtual void exitAux_rule__statementList_2(PnfGoParser::Aux_rule__statementList_2Context * /*ctx*/) override { }

  virtual void enterAux_rule__recvStmt_3(PnfGoParser::Aux_rule__recvStmt_3Context * /*ctx*/) override { }
  virtual void exitAux_rule__recvStmt_3(PnfGoParser::Aux_rule__recvStmt_3Context * /*ctx*/) override { }

  virtual void enterAux_rule__recvStmt_4(PnfGoParser::Aux_rule__recvStmt_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__recvStmt_4(PnfGoParser::Aux_rule__recvStmt_4Context * /*ctx*/) override { }

  virtual void enterAux_rule__primaryExpr_4(PnfGoParser::Aux_rule__primaryExpr_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__primaryExpr_4(PnfGoParser::Aux_rule__primaryExpr_4Context * /*ctx*/) override { }

  virtual void enterAux_rule__type__1(PnfGoParser::Aux_rule__type__1Context * /*ctx*/) override { }
  virtual void exitAux_rule__type__1(PnfGoParser::Aux_rule__type__1Context * /*ctx*/) override { }

  virtual void enterAux_rule__importDecl_4(PnfGoParser::Aux_rule__importDecl_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__importDecl_4(PnfGoParser::Aux_rule__importDecl_4Context * /*ctx*/) override { }

  virtual void enterAux_rule__constDecl_4(PnfGoParser::Aux_rule__constDecl_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__constDecl_4(PnfGoParser::Aux_rule__constDecl_4Context * /*ctx*/) override { }

  virtual void enterAux_rule__typeDecl_4(PnfGoParser::Aux_rule__typeDecl_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__typeDecl_4(PnfGoParser::Aux_rule__typeDecl_4Context * /*ctx*/) override { }

  virtual void enterAux_rule__varDecl_4(PnfGoParser::Aux_rule__varDecl_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__varDecl_4(PnfGoParser::Aux_rule__varDecl_4Context * /*ctx*/) override { }

  virtual void enterAux_rule__varSpec_4(PnfGoParser::Aux_rule__varSpec_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__varSpec_4(PnfGoParser::Aux_rule__varSpec_4Context * /*ctx*/) override { }

  virtual void enterAux_rule__varSpec_5(PnfGoParser::Aux_rule__varSpec_5Context * /*ctx*/) override { }
  virtual void exitAux_rule__varSpec_5(PnfGoParser::Aux_rule__varSpec_5Context * /*ctx*/) override { }

  virtual void enterAux_rule__channelType_3(PnfGoParser::Aux_rule__channelType_3Context * /*ctx*/) override { }
  virtual void exitAux_rule__channelType_3(PnfGoParser::Aux_rule__channelType_3Context * /*ctx*/) override { }

  virtual void enterAux_rule__channelType_4(PnfGoParser::Aux_rule__channelType_4Context * /*ctx*/) override { }
  virtual void exitAux_rule__channelType_4(PnfGoParser::Aux_rule__channelType_4Context * /*ctx*/) override { }

  virtual void enterAux_rule__fieldDecl_3(PnfGoParser::Aux_rule__fieldDecl_3Context * /*ctx*/) override { }
  virtual void exitAux_rule__fieldDecl_3(PnfGoParser::Aux_rule__fieldDecl_3Context * /*ctx*/) override { }

  virtual void enterAux_rule__arguments_8(PnfGoParser::Aux_rule__arguments_8Context * /*ctx*/) override { }
  virtual void exitAux_rule__arguments_8(PnfGoParser::Aux_rule__arguments_8Context * /*ctx*/) override { }

  virtual void enterAux_rule__slice_6(PnfGoParser::Aux_rule__slice_6Context * /*ctx*/) override { }
  virtual void exitAux_rule__slice_6(PnfGoParser::Aux_rule__slice_6Context * /*ctx*/) override { }

  virtual void enterAux_rule__primaryExpr_5(PnfGoParser::Aux_rule__primaryExpr_5Context * /*ctx*/) override { }
  virtual void exitAux_rule__primaryExpr_5(PnfGoParser::Aux_rule__primaryExpr_5Context * /*ctx*/) override { }


  virtual void enterEveryRule(antlr4::ParserRuleContext * /*ctx*/) override { }
  virtual void exitEveryRule(antlr4::ParserRuleContext * /*ctx*/) override { }
  virtual void visitTerminal(antlr4::tree::TerminalNode * /*node*/) override { }
  virtual void visitErrorNode(antlr4::tree::ErrorNode * /*node*/) override { }

};

}  // namespace antlr_go_perses
