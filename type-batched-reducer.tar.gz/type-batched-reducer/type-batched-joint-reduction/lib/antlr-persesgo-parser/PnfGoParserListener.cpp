
// Generated from PnfGoParser.g4 by ANTLR 4.7.2


#include "PnfGoParserListener.h"


using namespace antlr_go_perses;

