
// Generated from PnfGoParser.g4 by ANTLR 4.7.2

#pragma once


#include "antlr4-runtime.h"
#include "PnfGoParserVisitor.h"


namespace antlr_go_perses {

/**
 * This class provides an empty implementation of PnfGoParserVisitor, which can be
 * extended to create a visitor which only needs to handle a subset of the available methods.
 */
class  PnfGoParserBaseVisitor : public PnfGoParserVisitor {
public:

  virtual antlrcpp::Any visitSourceFile(PnfGoParser::SourceFileContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitPackageClause(PnfGoParser::PackageClauseContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitImportDecl(PnfGoParser::ImportDeclContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitImportSpec(PnfGoParser::ImportSpecContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitImportPath(PnfGoParser::ImportPathContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitDeclaration(PnfGoParser::DeclarationContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitConstDecl(PnfGoParser::ConstDeclContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitConstSpec(PnfGoParser::ConstSpecContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitIdentifierList(PnfGoParser::IdentifierListContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExpressionList(PnfGoParser::ExpressionListContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTypeDecl(PnfGoParser::TypeDeclContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTypeSpec(PnfGoParser::TypeSpecContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitFunctionDecl(PnfGoParser::FunctionDeclContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitMethodDecl(PnfGoParser::MethodDeclContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitReceiver(PnfGoParser::ReceiverContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitVarDecl(PnfGoParser::VarDeclContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitVarSpec(PnfGoParser::VarSpecContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitBlock(PnfGoParser::BlockContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitStatementList(PnfGoParser::StatementListContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitStatement(PnfGoParser::StatementContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitSimpleStmt(PnfGoParser::SimpleStmtContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitRealSimpleStmt(PnfGoParser::RealSimpleStmtContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExpressionStmt(PnfGoParser::ExpressionStmtContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitSendStmt(PnfGoParser::SendStmtContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitIncDecStmt(PnfGoParser::IncDecStmtContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAssignment(PnfGoParser::AssignmentContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAssign_op(PnfGoParser::Assign_opContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitShortVarDecl(PnfGoParser::ShortVarDeclContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitLabeledStmt(PnfGoParser::LabeledStmtContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitReturnStmt(PnfGoParser::ReturnStmtContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitBreakStmt(PnfGoParser::BreakStmtContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitContinueStmt(PnfGoParser::ContinueStmtContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitGotoStmt(PnfGoParser::GotoStmtContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitFallthroughStmt(PnfGoParser::FallthroughStmtContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitDeferStmt(PnfGoParser::DeferStmtContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitIfStmt(PnfGoParser::IfStmtContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprSwitchStmt(PnfGoParser::ExprSwitchStmtContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprCaseClause(PnfGoParser::ExprCaseClauseContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprSwitchCase(PnfGoParser::ExprSwitchCaseContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTypeSwitchStmt(PnfGoParser::TypeSwitchStmtContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTypeSwitchGuard(PnfGoParser::TypeSwitchGuardContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTypeCaseClause(PnfGoParser::TypeCaseClauseContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTypeSwitchCase(PnfGoParser::TypeSwitchCaseContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTypeList(PnfGoParser::TypeListContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitSelectStmt(PnfGoParser::SelectStmtContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitCommClause(PnfGoParser::CommClauseContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitCommCase(PnfGoParser::CommCaseContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitRecvStmt(PnfGoParser::RecvStmtContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitForStmt(PnfGoParser::ForStmtContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitForClause(PnfGoParser::ForClauseContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitRangeClause(PnfGoParser::RangeClauseContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitGoStmt(PnfGoParser::GoStmtContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTypeName(PnfGoParser::TypeNameContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitArrayType(PnfGoParser::ArrayTypeContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitElementType(PnfGoParser::ElementTypeContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitPointerType(PnfGoParser::PointerTypeContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitInterfaceType(PnfGoParser::InterfaceTypeContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitSliceType(PnfGoParser::SliceTypeContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitMapType(PnfGoParser::MapTypeContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitChannelType(PnfGoParser::ChannelTypeContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitMethodSpec(PnfGoParser::MethodSpecContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitFunctionType(PnfGoParser::FunctionTypeContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitSignature(PnfGoParser::SignatureContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitResult(PnfGoParser::ResultContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitParameters(PnfGoParser::ParametersContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitParameterDecl(PnfGoParser::ParameterDeclContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitUnaryExpr(PnfGoParser::UnaryExprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitConversion(PnfGoParser::ConversionContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitQualifiedIdent(PnfGoParser::QualifiedIdentContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitCompositeLit(PnfGoParser::CompositeLitContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitLiteralType(PnfGoParser::LiteralTypeContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitLiteralValue(PnfGoParser::LiteralValueContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitElementList(PnfGoParser::ElementListContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKeyedElement(PnfGoParser::KeyedElementContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKey(PnfGoParser::KeyContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitElement(PnfGoParser::ElementContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitStructType(PnfGoParser::StructTypeContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitFieldDecl(PnfGoParser::FieldDeclContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitString_(PnfGoParser::String_Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAnonymousField(PnfGoParser::AnonymousFieldContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitFunctionLit(PnfGoParser::FunctionLitContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitIndex(PnfGoParser::IndexContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitSlice(PnfGoParser::SliceContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTypeAssertion(PnfGoParser::TypeAssertionContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitArguments(PnfGoParser::ArgumentsContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitMethodExpr(PnfGoParser::MethodExprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitEos(PnfGoParser::EosContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__sourceFile_1(PnfGoParser::Aux_rule__sourceFile_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__sourceFile_2(PnfGoParser::Kleene_star__sourceFile_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__sourceFile_3(PnfGoParser::Aux_rule__sourceFile_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__sourceFile_4(PnfGoParser::Kleene_star__sourceFile_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__importDecl_1(PnfGoParser::Aux_rule__importDecl_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__importDecl_2(PnfGoParser::Kleene_star__importDecl_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__importSpec_1(PnfGoParser::Aux_rule__importSpec_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__importSpec_2(PnfGoParser::Optional__importSpec_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__constDecl_1(PnfGoParser::Aux_rule__constDecl_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__constDecl_2(PnfGoParser::Kleene_star__constDecl_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__constSpec_1(PnfGoParser::Optional__constSpec_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__constSpec_2(PnfGoParser::Aux_rule__constSpec_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__constSpec_3(PnfGoParser::Optional__constSpec_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__identifierList_1(PnfGoParser::Aux_rule__identifierList_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__identifierList_2(PnfGoParser::Kleene_star__identifierList_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__expressionList_1(PnfGoParser::Aux_rule__expressionList_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__expressionList_2(PnfGoParser::Kleene_star__expressionList_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__typeDecl_1(PnfGoParser::Aux_rule__typeDecl_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__typeDecl_2(PnfGoParser::Kleene_star__typeDecl_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__typeSpec_1(PnfGoParser::Optional__typeSpec_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__functionDecl_1(PnfGoParser::Optional__functionDecl_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__varDecl_1(PnfGoParser::Aux_rule__varDecl_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__varDecl_2(PnfGoParser::Kleene_star__varDecl_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__varSpec_1(PnfGoParser::Aux_rule__varSpec_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__varSpec_2(PnfGoParser::Optional__varSpec_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__block_1(PnfGoParser::Optional__block_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__statementList_1(PnfGoParser::Aux_rule__statementList_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__assign_op_1(PnfGoParser::Aux_rule__assign_op_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__assign_op_2(PnfGoParser::Optional__assign_op_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__returnStmt_1(PnfGoParser::Optional__returnStmt_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__breakStmt_1(PnfGoParser::Optional__breakStmt_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__ifStmt_1(PnfGoParser::Aux_rule__ifStmt_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__ifStmt_2(PnfGoParser::Optional__ifStmt_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__ifStmt_3(PnfGoParser::Aux_rule__ifStmt_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__ifStmt_4(PnfGoParser::Optional__ifStmt_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__exprSwitchStmt_3(PnfGoParser::Optional__exprSwitchStmt_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__exprSwitchStmt_4(PnfGoParser::Kleene_star__exprSwitchStmt_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__typeSwitchStmt_3(PnfGoParser::Kleene_star__typeSwitchStmt_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__typeSwitchGuard_1(PnfGoParser::Aux_rule__typeSwitchGuard_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__typeSwitchGuard_2(PnfGoParser::Optional__typeSwitchGuard_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__typeList_1(PnfGoParser::Aux_rule__typeList_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__typeList_2(PnfGoParser::Kleene_star__typeList_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__selectStmt_1(PnfGoParser::Kleene_star__selectStmt_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__recvStmt_1(PnfGoParser::Aux_rule__recvStmt_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__recvStmt_2(PnfGoParser::Optional__recvStmt_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__forStmt_1(PnfGoParser::Aux_rule__forStmt_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__forStmt_2(PnfGoParser::Optional__forStmt_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__forClause_1(PnfGoParser::Optional__forClause_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__interfaceType_1(PnfGoParser::Aux_rule__interfaceType_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__interfaceType_2(PnfGoParser::Kleene_star__interfaceType_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__parameters_1(PnfGoParser::Aux_rule__parameters_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__parameters_2(PnfGoParser::Kleene_star__parameters_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__parameters_3(PnfGoParser::Optional__parameters_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__parameters_4(PnfGoParser::Aux_rule__parameters_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__parameters_5(PnfGoParser::Optional__parameters_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__parameterDecl_1(PnfGoParser::Optional__parameterDecl_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__parameterDecl_2(PnfGoParser::Optional__parameterDecl_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__conversion_1(PnfGoParser::Optional__conversion_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__literalValue_2(PnfGoParser::Aux_rule__literalValue_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__literalValue_3(PnfGoParser::Optional__literalValue_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__elementList_1(PnfGoParser::Aux_rule__elementList_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__elementList_2(PnfGoParser::Kleene_star__elementList_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__keyedElement_1(PnfGoParser::Aux_rule__keyedElement_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__keyedElement_2(PnfGoParser::Optional__keyedElement_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__structType_1(PnfGoParser::Aux_rule__structType_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__structType_2(PnfGoParser::Kleene_star__structType_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__fieldDecl_1(PnfGoParser::Optional__fieldDecl_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__anonymousField_1(PnfGoParser::Optional__anonymousField_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__arguments_1(PnfGoParser::Aux_rule__arguments_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__arguments_2(PnfGoParser::Optional__arguments_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__arguments_5(PnfGoParser::Aux_rule__arguments_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__arguments_6(PnfGoParser::Optional__arguments_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__expression_2(PnfGoParser::Aux_rule__expression_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__expression_1(PnfGoParser::Kleene_star__expression_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExpression(PnfGoParser::ExpressionContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__primaryExpr_2(PnfGoParser::Aux_rule__primaryExpr_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitKleene_star__primaryExpr_1(PnfGoParser::Kleene_star__primaryExpr_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitPrimaryExpr(PnfGoParser::PrimaryExprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__signature_1(PnfGoParser::Optional__signature_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__expression_3(PnfGoParser::Altnt_block__expression_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitType_(PnfGoParser::Type_Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitRealStatement(PnfGoParser::RealStatementContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__importDecl_3(PnfGoParser::Altnt_block__importDecl_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__constDecl_3(PnfGoParser::Altnt_block__constDecl_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__typeDecl_3(PnfGoParser::Altnt_block__typeDecl_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__varDecl_3(PnfGoParser::Altnt_block__varDecl_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__varSpec_3(PnfGoParser::Altnt_block__varSpec_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__incDecStmt_1(PnfGoParser::Altnt_block__incDecStmt_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__typeList_3(PnfGoParser::Altnt_block__typeList_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__commCase_1(PnfGoParser::Altnt_block__commCase_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__channelType_1(PnfGoParser::Altnt_block__channelType_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__unaryExpr_1(PnfGoParser::Altnt_block__unaryExpr_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__fieldDecl_2(PnfGoParser::Altnt_block__fieldDecl_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__slice_4(PnfGoParser::Altnt_block__slice_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__sourceFile_5(PnfGoParser::Altnt_block__sourceFile_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__ifStmt_5(PnfGoParser::Altnt_block__ifStmt_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__arguments_7(PnfGoParser::Altnt_block__arguments_7Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitOptional__channelType_2(PnfGoParser::Optional__channelType_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAltnt_block__slice_5(PnfGoParser::Altnt_block__slice_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__primaryExpr_3(PnfGoParser::Aux_rule__primaryExpr_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__sourceFile_6(PnfGoParser::Aux_rule__sourceFile_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__exprSwitchCase_1(PnfGoParser::Aux_rule__exprSwitchCase_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__typeSwitchCase_1(PnfGoParser::Aux_rule__typeSwitchCase_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__commCase_2(PnfGoParser::Aux_rule__commCase_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__methodSpec_2(PnfGoParser::Aux_rule__methodSpec_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__unaryExpr_2(PnfGoParser::Aux_rule__unaryExpr_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__literalType_1(PnfGoParser::Aux_rule__literalType_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__eos_1(PnfGoParser::Aux_rule__eos_1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__eos_2(PnfGoParser::Aux_rule__eos_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__statementList_2(PnfGoParser::Aux_rule__statementList_2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__recvStmt_3(PnfGoParser::Aux_rule__recvStmt_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__recvStmt_4(PnfGoParser::Aux_rule__recvStmt_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__primaryExpr_4(PnfGoParser::Aux_rule__primaryExpr_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__type__1(PnfGoParser::Aux_rule__type__1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__importDecl_4(PnfGoParser::Aux_rule__importDecl_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__constDecl_4(PnfGoParser::Aux_rule__constDecl_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__typeDecl_4(PnfGoParser::Aux_rule__typeDecl_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__varDecl_4(PnfGoParser::Aux_rule__varDecl_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__varSpec_4(PnfGoParser::Aux_rule__varSpec_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__varSpec_5(PnfGoParser::Aux_rule__varSpec_5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__channelType_3(PnfGoParser::Aux_rule__channelType_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__channelType_4(PnfGoParser::Aux_rule__channelType_4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__fieldDecl_3(PnfGoParser::Aux_rule__fieldDecl_3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__arguments_8(PnfGoParser::Aux_rule__arguments_8Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__slice_6(PnfGoParser::Aux_rule__slice_6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitAux_rule__primaryExpr_5(PnfGoParser::Aux_rule__primaryExpr_5Context *ctx) override {
    return visitChildren(ctx);
  }


};

}  // namespace antlr_go_perses
