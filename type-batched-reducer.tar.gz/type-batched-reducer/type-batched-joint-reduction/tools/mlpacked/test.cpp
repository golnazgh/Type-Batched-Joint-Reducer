
#include <mlpack/core.hpp>
#include <mlpack/methods/logistic_regression/logistic_regression.hpp>
#include <mlpack/core/cv/metrics/accuracy.hpp>

#include <iostream>
#include <string>

using namespace mlpack;
using namespace mlpack::regression;


// NOTE: In ubuntu, this requires:
//   libmlpack-dev
//   libensmallen-dev
//   libopenblas-dev


void
processOneTrainingSet(const std::string& path) {
  arma::mat rows;
  data::Load(path, rows);
  
  // MLPack logistic regression prefers columns of data rather than rows.
  // This means we need to transpose everything.
  arma::mat regressors = rows.row(0);
  const arma::Row<long unsigned int> outcomes = arma::conv_to<arma::Row<long unsigned int>>::from(rows.row(1));
  
  // Notice that we are not training the model.
  // We are just loading it from the file.
  LogisticRegression<> lr{};
  std::string inpath = path + ".model.bin";
  mlpack::data::Load(inpath, "logistic_regression_model", lr, true /* Fatal on errors */);
  
  arma::Row<size_t> predictions;
  lr.Classify(regressors, predictions, 0.5);
  
  std::cout << "Training set: " << path << "\n";
  std::cout << "Accuracy " << mlpack::cv::Accuracy::Evaluate(lr, regressors, outcomes) << "\n";
}


int
main(int argc, char** argv) {
  using namespace std::string_literals;
  
  for (size_t index = 1; index < argc; ++index) {
    processOneTrainingSet(argv[index]);
  }

  return 0;
}
