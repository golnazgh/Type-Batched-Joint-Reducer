
#include "antlr-plugins.h"
#include "antlr-wrapper.h"
#include "TestCaseShrinker.h"
#include "HierarchicalTestCaseShrinker.h"
#include "ReducerTrees.h"

#include <llvm/ADT/DenseSet.h>
#include <llvm/ADT/EquivalenceClasses.h>


enum class VisitAction {
  SKIP_CHILDREN,
  VISIT_CHILDREN,
  VISIT_CHILDREN_OF
};

using VisitResult = llvm::PointerIntPair<antlr4::tree::ParseTree*,3,VisitAction>;

static VisitResult
makeResult(antlr4::tree::ParseTree* tree) {
  return VisitResult(tree, VisitAction::VISIT_CHILDREN_OF);
}


static VisitResult
makeResult(VisitAction action) {
  return VisitResult(nullptr, action);
}


// Performs a standard, stack based DFS of the parse tree. Nodes of the tree
// are visited in a preorder traversal. The `visit` must be callable and
// is invoked on each node of the tree as traversed. It should return
// true if the children of that node are to be visited and false otherwise.
template<typename Visitor>
static void
traverseASTInPreorder(const antlr4::tree::ParseTree& tree, Visitor visit) {
  auto children = getChildren(&tree);
  using iteratorTy = decltype (children.begin());
  std::stack<std::pair<iteratorTy,iteratorTy>> traversalState;
  traversalState.emplace(children.begin(), children.end());

  while (!traversalState.empty()) {
    auto &top = traversalState.top();

    if (top.first == top.second) {
      traversalState.pop();
      continue;
    }

    auto* node = *top.first;
    ++top.first;

    if (!node) {
      continue;
    }

    const VisitResult result = visit(node);
    if (result.getInt() == VisitAction::SKIP_CHILDREN) {
      continue;
    }

    auto* next = (result.getInt() == VisitAction::VISIT_CHILDREN_OF)
               ? result.getPointer() : node;
    auto children = getChildren(next);
    traversalState.emplace(children.begin(), children.end());
  }
}


// Performs a postorder traversal of the AST. The visitor `visit` should be
// callable and will be invoked once for every node in the tree.
template<typename Visitor>
static void
traverseASTInPostorder(const antlr4::tree::ParseTree& tree, Visitor visit) {
  std::stack<antlr4::tree::ParseTree*> preorder;

  traverseASTInPreorder(tree, [&preorder] (auto* node) {
    preorder.push(node);
    return makeResult(VisitAction::VISIT_CHILDREN);
  });

  while (!preorder.empty()) {
    auto* top = preorder.top();
    preorder.pop();
    visit(top);
  }
}


llvm::DenseMap<const antlr4::tree::ParseTree*,size_t>
extractTreeKinds(const antlr4::tree::ParseTree& tree) {
  llvm::DenseMap<const antlr4::tree::ParseTree*,size_t> kinds;

  traverseASTInPreorder(tree, [&kinds] (auto* node) {
    if (auto* rule = asRuleContext(node)) {
      kinds[node] = getRuleIndex(rule);
      return makeResult(VisitAction::VISIT_CHILDREN);
    }
    return makeResult(VisitAction::SKIP_CHILDREN);
  });

  return kinds;
}


static void
writeNodeLabel(llvm::raw_ostream& out, antlr4::tree::ParseTree* node) {
  out << 'n' << node;
}


static void
writeNodeEdge(llvm::raw_ostream& out,
              antlr4::tree::ParseTree* from,
              antlr4::tree::ParseTree* to) {
  writeNodeLabel(out, from);
  out << " -> ";
  writeNodeLabel(out, to);
}


void
printGraphvizTree(llvm::raw_ostream& out,
                  antlr4::tree::ParseTree& tree,
                  antlr4::Parser& parser) {
  auto ruleNames = getRuleNames(parser);
  auto printOneNode = [&out,&parser,ruleNames] (auto* node) {
    out << "  ";
    writeNodeLabel(out, node);
    out << "[label=\"";
    if (auto* rule = asRuleContext(node)) {
      auto kind = getRuleIndex(rule);
      out << kind << " " << getAlternativeIndex(rule) << " " << ruleNames[kind];
    } else if (auto* token = getToken(node)) {
      out.write_escaped(getText(token));
    }
    out << "\"];\n";
    for (auto& child : getChildren(node)) {
      out << "  ";
      writeNodeEdge(out, node, child);
      out << ";\n";
    }
    return makeResult(VisitAction::VISIT_CHILDREN);
  };

  out << "digraph {\n";
  printOneNode(&tree);
  traverseASTInPreorder(tree, printOneNode);
  out << "}\n";
}


void
ParseTreePrinter::visitTree(antlr4::tree::ParseTree& tree,
                            antlr4::Parser& parser,
                            AntlrGrammarInfo& info) {
  printGraphvizTree(out, tree, parser);
}


static void
setParent(TreeNode* parent, const TreeNode::ChildList& children) {
  for (auto* child : children) {
    child->setParent(parent);
  }
}


class ChainNodeClassifier :
  public testshrinker::CompatibleNodeClassifier<const antlr4::tree::ParseTree*> {
public:
  size_t
  getClass(const Node* node) const override {
    auto* element = node->getElement();
    auto isRule = getRuleIndex(element).first;
    auto ruleIndex =  getRuleIndex(element).second;
    auto entry = classes.find(isRule ? ruleIndex : -1);
    if (entry != classes.end()) {
      return entry->second;
    }
    return -1;
  }
  llvm::DenseMap<int, int> classes;
};


class RuleIndexClassifier :
  public testshrinker::CompatibleNodeClassifier<const antlr4::tree::ParseTree*> {
public:
  size_t
  getClass(const Node* node) const override {
    auto isRule = getRuleIndex(node->getElement()).first;
    auto ruleIndex = getRuleIndex(node->getElement()).second;
    if (isRule) {
      return ruleIndex;
    } else {
      return -1;
    }
  }
};


static std::unique_ptr<testshrinker::CompatibleNodeClassifier<const antlr4::tree::ParseTree*>>
createClassifier(testshrinker::Tree<const antlr4::tree::ParseTree*>& tree,
                 RuleEquivalence equivalence) {
  switch (equivalence) {
    case RuleEquivalence::OBSERVED_CHAIN: {
      llvm::EquivalenceClasses<int> classes;
      auto findClasses = [&classes] (auto* node) {
        auto& children = node->getChildren();
        if (!node->isAttr(TreeNode::IS_RULE)) {
          return;
        }
        auto asRule = (const antlr4::RuleContext*)(node->getElement());
        classes.insert(getRuleIndex(asRule));
        if (children.size() != 1 || !children.front()->isAttr(TreeNode::IS_RULE)) {
          return;
        }
        auto asChildRule =
          (const antlr4::RuleContext*)(children.front()->getElement());
        classes.unionSets(getRuleIndex(asRule), getRuleIndex(asChildRule));
      };
      tree.visitPostorder(findClasses);

      auto classifier = std::make_unique<ChainNodeClassifier>();
      size_t nextID = 0;
      for (auto& eqClass : classes) {
        if (!eqClass.isLeader()) {
          continue;
        }
        auto* member = &eqClass;
        while (member) {
          classifier->classes[member->getData()] = nextID;
          member = member->getNext();
        }
        ++nextID;
      }
      return std::move(classifier);
    }
    case RuleEquivalence::RULE_INDEX:
    default:
      return std::make_unique<RuleIndexClassifier>();
  }
}


template<class NullableRules>
static bool
isAlwaysNullable(const antlr4::RuleContext* rule, const NullableRules alwaysNullable) {
  return alwaysNullable[getRuleIndex(rule)];
}

template<class NullableRules>
static bool
isLocallyNullable(const antlr4::RuleContext* rule,
                  const antlr4::RuleContext* parentRule,
                  const NullableRules locallyNullable) {
  auto parentIndex = getRuleIndex(parentRule);
  auto altNumber   = getAlternativeIndex(parentRule);
  auto ruleIndex   = getRuleIndex(rule);
  if (!altNumber) {
    return true;
  }
  auto& ruleTable = locallyNullable[parentIndex][altNumber - 1];
  auto found = std::find(ruleTable.begin(), ruleTable.end(), ruleIndex);
  return ruleTable.end() != found;
}

template<class NullableStrings>
static bool
isNullableString(const antlr4::tree::ParseTree* tree,
                 const antlr4::RuleContext* parentRule,
                 const NullableStrings nullableStrings) {
  // const_cast is ugly, but the present API make text retrieval non const....
  auto text        = getText(const_cast<antlr4::tree::ParseTree*>(tree));
  auto parentIndex = getRuleIndex(parentRule);
  auto altNumber   = getAlternativeIndex(parentRule);
  if (!text.empty() && parentIndex && altNumber != 0) {
    auto& strTable = nullableStrings[parentIndex][altNumber - 1];
    auto found = std::find_if(strTable.begin(), strTable.end(),
      [&text] (llvm::StringRef str) { return str == text; });
    return strTable.end() != found;
  }
  return false;
}


testshrinker::Tree<const antlr4::tree::ParseTree*>
createReducerTree(const antlr4::tree::ParseTree& tree,
                  AntlrGrammarInfo const& grammar,
                  RuleEquivalence equivalence) {
  using Element  = const antlr4::tree::ParseTree*;
  using TreeNode = testshrinker::TreeNode<Element>;
  testshrinker::Tree<Element> shrinkerTree;
  llvm::DenseMap<Element, TreeNode*> trees;
//  auto alwaysNullable  = grammar.getAlwaysNullableRules();
//  auto nullable = grammar.getNullableRules();
//  auto nullableStrings = grammar.getNullableStrings();
  auto visit = [&trees, &shrinkerTree] (auto* parseTree) {
    TreeNode::ChildList children;
    children.reserve(getChildren(parseTree).size());
    for (auto* child : getChildren(parseTree)) {
      children.push_back(trees[child]);
    }
    auto* newNode = shrinkerTree.createNode(parseTree, std::move(children));
    trees[parseTree] = newNode;
    setParent(newNode, newNode->getChildren());

    if (auto* rule = asRuleContext(parseTree)) {
      newNode->setAttr(TreeNode::IS_RULE);
    }
  };
  traverseASTInPostorder(tree, visit);
  visit(&tree);
  shrinkerTree.root = trees[&tree];
  shrinkerTree.setClassifier(createClassifier(shrinkerTree, equivalence));
  return shrinkerTree;
}


/*void
coarseHDDFlattening(testshrinker::Tree<const antlr4::tree::ParseTree*>& tree,
                    antlr4::Parser& parser) {
  auto visit = [&tree](auto* node) -> void {
    using RuleContext = const antlr4::RuleContext;
    auto* element = node->getElement();
    auto* rule = asRuleContext(element);
    auto& children = getChildren(node);
    auto gone = std::remove_if(children.begin(), children.end(),
      [] (auto* child) {
        return child->getChildren().empty() && !asRuleContext(child->getElement());
      });
    children.erase(gone, children.end());
    if (!rule || children.size() < 2) {
      return;
    }
    auto* first = asRuleContext(children.front()->getElement());
    auto* last  = asRuleContext(children.back()->getElement());
    auto ruleID = rule->getRuleIndex();

    if (first && first->getRuleIndex() == ruleID) {
      TreeNode::ChildList kids(children.begin() + 1, children.end());
      auto* newNode = tree.createNode(node, nullptr, kids);
      newNode->setAttr(TreeNode::IS_ALWAYS_NULLABLE);
      newNode->setAttr(TreeNode::IS_RULE);
      children = children.front()->getChildren();
      children.push_back(newNode);
      setParent(newNode, kids);
      setParent(node, children);

    } else if (last && last->getRuleIndex() == ruleID) {
      TreeNode::ChildList kids(children.begin(), children.end() - 1);
      auto* newNode = tree.createNode(node, nullptr, kids);
      newNode->setAttr(TreeNode::IS_ALWAYS_NULLABLE);
      newNode->setAttr(TreeNode::IS_RULE);
      children = children.back()->getChildren();
      children.insert(children.begin(), newNode);
      setParent(newNode, kids);
      setParent(node, children);
    }
  };
  tree.visitPostorder(visit);

  auto& ruleNames = parser.getRuleNames();
  llvm::StringRef prefix("arborist_synthetic_");
  auto markNullable = [&ruleNames, prefix] (auto* node) -> void {
    auto ruleIndex = getRuleIndex(node->getElement());
    if (ruleIndex.first) {
      llvm::StringRef name{ruleNames[ruleIndex.second]};
      if (name.startswith(prefix)
          && !name.drop_front(prefix.size()).startswith("block")) {
        for (auto* child : node->getChildren()) {
          child->setAttr(TreeNode::IS_ALWAYS_NULLABLE);
        }
      }
    }
  };
  tree.visitPostorder(markNullable);
}*/


void
flattenRecursion(testshrinker::Tree<const antlr4::tree::ParseTree*>& tree,
                 antlr4::Parser& parser) {
  auto makeNodeOfList = [&tree] (auto& kids, auto* parent) -> TreeNode* {
    TreeNode* node = nullptr;
    if (kids.size() == 1) {
      node = kids.front();
      node->setParent(parent);
    } else {
      node = tree.createNode(parent, nullptr, kids);
      node->setAttr(TreeNode::IS_RULE);
      setParent(node, kids);
    }
    node->setAttr(TreeNode::IS_ALWAYS_NULLABLE);
    return node;
  };
  auto isBase = [] (const auto& kids) -> bool {
    return kids.empty()
      || !(kids.front()->isAttr(TreeNode::IS_LIST)
        || kids.back()->isAttr(TreeNode::IS_LIST));
  };
  auto liftChildren = [&isBase,&makeNodeOfList] (auto& kids, auto* parent) {
    TreeNode::ChildList children;
    if (!isBase(kids)) {
      children.push_back(makeNodeOfList(kids, parent));
    } else if (kids.size() > 1) {
      children = kids;
    } else if (!kids.empty()) {
      kids.front()->setAttr(TreeNode::IS_ALWAYS_NULLABLE);
      children = kids;
    }
    return children;
  };
  auto visit = [&makeNodeOfList, &liftChildren] (auto* node) -> void {
    auto* element = node->getElement();
    auto* rule = asRuleContext(element);
    auto& children = node->getChildren();
    if (!rule || children.size() < 2) {
      return;
    }
    auto firstIsRule = getRuleIndex(children.front()->getElement()).first;
    auto firstIndex = getRuleIndex(children.front()->getElement()).second;
    auto secondIsRule = getRuleIndex(children.back()->getElement()).first;
    auto secondIndex = getRuleIndex(children.back()->getElement()).second;
    auto ruleID = getRuleIndex(rule);

    if (firstIsRule && firstIndex == ruleID) {
      TreeNode::ChildList kids(children.begin() + 1, children.end());
      auto* newNode = makeNodeOfList(kids, node);
      children = liftChildren(children.front()->getChildren(), node);
      children.push_back(newNode);
      setParent(newNode, kids);
      setParent(node, children);
      node->setAttr(TreeNode::IS_LIST);

    } else if (secondIsRule && secondIndex == ruleID) {
      TreeNode::ChildList kids(children.begin(), children.end() - 1);
      auto* newNode = makeNodeOfList(kids, node);
      children = liftChildren(children.back()->getChildren(), node);
      children.insert(children.begin(), newNode);
      setParent(newNode, kids);
      setParent(node, children);
      node->setAttr(TreeNode::IS_LIST);
    }
  };
  tree.visitPostorder(visit);

  auto ruleNames = getRuleNames(parser);
  llvm::StringRef prefix("arborist_synthetic_");
  llvm::StringRef nullables[] = {
    llvm::StringRef("optional__"),
    llvm::StringRef("kleene_star__"),
    llvm::StringRef("kleene_plus__"),
    llvm::StringRef("pnf_option_"),
    llvm::StringRef("pnf_plus_"),
    llvm::StringRef("pnf_star_"),
  };
  auto markNullable = [&ruleNames, prefix, nullables] (auto* node) -> void {
    auto& kids = node->getChildren();
    auto isNullable = [](auto* kid){ return kid->isNullable(); };
    if (!kids.empty() && !node->isAttr(TreeNode::IS_ALWAYS_NULLABLE)
      && std::all_of(kids.begin(), kids.end(), isNullable)) {
      node->setAttr(TreeNode::IS_ALWAYS_NULLABLE);
    }
    auto ruleIndex = getRuleIndex(node->getElement());
    if (ruleIndex.first) {
      llvm::StringRef name{ruleNames[ruleIndex.second]};
      if (std::any_of(std::begin(nullables), std::end(nullables),
                    [name](auto nullable) { return name.startswith(nullable); })
          || (name.startswith(prefix)
            && !name.drop_front(prefix.size()).startswith("block"))) {
        node->setAttr(TreeNode::IS_LIST);
        for (auto* child : node->getChildren()) {
          child->setAttr(TreeNode::IS_ALWAYS_NULLABLE);
        }
      }
    }
  };
  tree.visitPostorder(markNullable);
}


enum class DelimiterSide {
  LEFT,
  RIGHT,
};


static TreeNode*&
getDelimiterPointer(DelimiterSide side,
                    llvm::MutableArrayRef<TreeNode*> children) {
  return (DelimiterSide::LEFT == side) ? children.front() : children.back();
}


static TreeNode*
getDelimiter(TreeNode* node, DelimiterSide side) {
  if (!node || node->getChildren().size() < 2) {
    return nullptr;
  }
  auto* sep = (DelimiterSide::LEFT == side)
            ? node->getChildren().front()
            : node->getChildren().back();
  if (!sep || sep->isAttr(TreeNode::IS_RULE)) {
    return nullptr;
  }
  auto text = getText(getToken(sep->getElement()));
  auto blacklist = llvm::StringRef("()[]{}");
  bool isForbidden =
    std::any_of(text.begin(), text.end(), [blacklist] (auto c) {
      return std::isalnum(c) || blacklist.find(c) != llvm::StringRef::npos;
    });
  if (isForbidden) {
    return nullptr;
  }
  return sep;
}


static auto
hasDelimiter(TreeNode* sep, DelimiterSide side) {
  return [side, sepText=getText(getToken(sep->getElement()))] (auto* node) {
    auto* nodeSep = getDelimiter(node, side);
    return nodeSep
      && getToken(nodeSep->getElement())
      && getText(getToken(nodeSep->getElement())) == sepText;
  };
}


static bool
isElement(DelimiterSide side, TreeNode* candidate, TreeNode* element) {
  if (!candidate || element->getChildren().size() != 2) {
    return false;
  }
  auto* remnant = DelimiterSide::LEFT == side
                ? element->getChildren().back()
                : element->getChildren().front();
  return remnant
      && remnant->getElement()
      && candidate->getElement()
      && getRuleIndex(remnant->getElement()) == getRuleIndex(candidate->getElement());
}


static bool
isTriviallyRemovable(TreeNode* node) {
  return !node
    || (!(node->isAttr(TreeNode::LEFT_PRUNED)
        || node->isAttr(TreeNode::RIGHT_PRUNED))
      && (node->isAttr(TreeNode::IS_RULE) && node->getChildren().empty()));
};


static void
createNonredundantTree(TreeNode*& start) {
  if (!start->isAttr(TreeNode::IS_RULE)) {
    return;
  }

  llvm::SmallVector<TreeNode*,4> chain;
  chain.push_back(start);
  auto nontrivialCount = [] (auto* node) {
    auto& children = node->getChildren();
    return std::accumulate(children.begin(), children.end(), 0,
      [] (auto sofar, auto* child) {
      return sofar + (isTriviallyRemovable(child) ? 0 : 1);
    });
  };
  while (nontrivialCount(chain.back()) == 1) {
    auto& children = chain.back()->getChildren();
    auto next = std::find_if(children.begin(), children.end(),
      [] (auto* node) {return !isTriviallyRemovable(node); });
    chain.push_back(*next);
  }
  if (!chain.back()->isAttr(TreeNode::IS_RULE)) {
    chain.pop_back();
  }

  // First recursively fix the children to maintain the parent invariants
  auto& children = chain.back()->getChildren();
  for (auto& child : children) {
    if (child) {
      createNonredundantTree(child);
    }
  }

  if (chain.size() == 1) {
    return;
  }

  // Save the original parent of the chain.
  auto chainParent = chain.front()->getParent();
  auto isNullable = [] (auto* node) {
    return node->isAttr(TreeNode::IS_ALWAYS_NULLABLE)
      || node->isAttr(TreeNode::IS_LOCALLY_NULLABLE)
      || node->isAttr(TreeNode::IS_DATA_NULLABLE);
  };
  bool foundNullable = std::any_of(chain.begin(), chain.end(), isNullable);
  chain.erase(chain.begin(), chain.begin() + chain.size() - 1);

  // Update the relationship with the parent of the chain.
  chain.front()->setParent(chainParent);
  start = chain.front();
  if (foundNullable) {
    chain.back()->setAttr(TreeNode::IS_ALWAYS_NULLABLE);
  }
}


void
removeRedundantNodes(testshrinker::Tree<const antlr4::tree::ParseTree*>& tree) {
  auto removeTrivial = [] (auto* node) -> void {
    for (auto*& child : node->getChildren()) {
      const auto& grandKids = child->getChildren();
      if (child
          && child->isAttr(TreeNode::IS_RULE)
          && !child->isAttr(TreeNode::LEFT_PRUNED)
          && !child->isAttr(TreeNode::RIGHT_PRUNED)
          && std::all_of(grandKids.begin(), grandKids.end(), isTriviallyRemovable)) {
        child = nullptr;
      }
    }
  };
  tree.visitPostorder(removeTrivial);

  for (auto& child : tree.root->getChildren()) {
    if (child) {
      createNonredundantTree(child);
    }
  }
}

template<typename Node>
using KindToRangeMap = llvm::DenseMap<size_t, NodeRangeList<Node>>;

template<typename Node>
static void
appendRangeMap(KindToRangeMap<Node>& destination,
               const KindToRangeMap<Node>& source) {
  for (auto& kindRangePair : source) {
    const auto &rangeSource = kindRangePair.second;
    auto &rangeDest = destination[kindRangePair.first];
    rangeDest.second.reserve(rangeDest.second.size() + rangeSource.second.size());
    auto baseIndex = rangeDest.first.size();
    for (auto rangeStart : rangeSource.second) {
      rangeDest.second.append(1, rangeStart + baseIndex);
    }
    rangeDest.first.append(rangeSource.first.begin(), rangeSource.first.end());
  }
}


llvm::DenseMap<const TreeNode*,NodeRangeList<TreeNode>>
mapTreesToSimilarSubtrees(const testshrinker::Tree<const antlr4::tree::ParseTree*>& tree) {
  llvm::DenseMap<const TreeNode*,NodeRangeList<TreeNode>> replacementMap;

  auto& classifier = tree.getClassifier();
  std::unordered_map<const TreeNode*,KindToRangeMap<TreeNode>> progressMap;
  auto all = [] (auto*) { return true; };
  auto update = [&replacementMap, &progressMap, &classifier, all] (auto* node) -> auto {
    if (auto* rule = asRuleContext(node->getElement())) {
      // Update the progress based on the children
      auto& progress = progressMap[node];
      for (auto& child : node->getChildren()) {
        if (!child) {
          continue;
        }
        auto childProgress = progressMap.find(child);
        if (childProgress != progressMap.end()) {
          appendRangeMap(progress, childProgress->second);
          progressMap.erase(childProgress);
        }
      }
      auto kind = classifier.getClass(node);
      auto &ruleProgress = progress[kind];
      // Collect the replacements for this node
      replacementMap[node] = ruleProgress;
      // Reset the progress for this node
      ruleProgress.first.clear();
      ruleProgress.first.push_back(node);
      ruleProgress.second.clear();
      ruleProgress.second.push_back(0);
      return node->makeChildRange(all);
    }
    return node->makeEmptyChildRange(all);
  };
  tree.visitPostorder(update);

  return replacementMap;
}


llvm::DenseMap<const TreeNode*,llvm::SmallVector<TreeNode*,4>>
mapListElementsToSublists(const testshrinker::Tree<const antlr4::tree::ParseTree*>& tree) {
  llvm::DenseMap<const TreeNode*,llvm::SmallVector<TreeNode*,4>> sublistMap;
  auto& classifier = tree.getClassifier();
  std::unordered_map<const TreeNode*,llvm::DenseMap<unsigned, llvm::SmallVector<TreeNode*,4>>> progressMap;
  auto all = [] (auto*) { return true; };

  auto update = [&sublistMap, &progressMap, &classifier, all] (auto* node) -> auto {
    if (auto* rule = asRuleContext(node->getElement())) {
      // Update the progress based on the children
      auto& progress = progressMap[node];
      for (const auto* child : node->getChildren()) {
        if (!child) {
          continue;
        }
        auto childProgress = progressMap.find(child);
        if (childProgress != progressMap.end()) {
          for (auto& kvPair : childProgress->second) {
            auto& toUpdate = progress[kvPair.first];
            toUpdate.insert(toUpdate.end(), kvPair.second.begin(), kvPair.second.end());
          }
        }
      }

      if (node->isAttr(TreeNode::IS_LIST)) {
        auto kind = classifier.getClass(node);
        for (const auto* child : node->getChildren()) {
          auto& ruleProgress = progressMap[child][kind];
          // Collect the replacements for this child
          sublistMap[child] = ruleProgress;
        }
        // Reset the progress for this node
        auto& ruleProgress = progressMap[node][kind];
        ruleProgress.clear();
        ruleProgress.push_back(node);
      }
      return node->makeChildRange(all);
    }
    return node->makeEmptyChildRange(all);
  };
  tree.visitPostorder(update);

  return sublistMap;
}


testshrinker::TreeSize
getSize(const testshrinker::Tree<const antlr4::tree::ParseTree*>& tree) {
  auto tokenSize = [] (auto* node) {
    return getText(const_cast<antlr4::tree::ParseTree*>(node)).size();
  };
  return tree.getSize(tokenSize);
}
                              


std::vector<const antlr4::Token*>
getTokensReplacing(const testshrinker::Tree<const antlr4::tree::ParseTree*>& tree,
                   const llvm::DenseMap<const TreeNode*,
                                        antlr4::CommonToken*>& replacements) {
  std::vector<const antlr4::Token*> tokens;
  auto all = [] (auto*) { return true; };
  tree.root->visitPostorder([&tokens,&replacements,all] (auto* node) {
    auto found = replacements.find(node);
    if (found != replacements.end()) {
      tokens.push_back(found->second);
      return node->makeEmptyChildRange(all);
    } else if (!node->isAttr(TreeNode::IS_RULE)) {
      if (auto* token = getToken(node->getElement())) {
        tokens.push_back(token);
      }
      return node->makeEmptyChildRange(all);
    }
    return node->makeChildRange(all);
  });
  return tokens;
}


llvm::DenseMap<const antlr4::tree::ParseTree*,llvm::SparseBitVector<>>
mapTreesToTokens(const antlr4::tree::ParseTree& tree,
                 llvm::ArrayRef<std::string> tokens) {
  auto treeMap = llvm::DenseMap<const antlr4::tree::ParseTree*,llvm::SparseBitVector<>>{};

  auto onToken = [tokens, &treeMap] (auto& bitvector, const auto* token) {
    const auto& text = getText(token);
    auto pos = std::lower_bound(tokens.begin(), tokens.end(), text);
    if (pos != tokens.end() && *pos == text) {
      auto tokenIndex = std::distance(tokens.begin(), pos);
      bitvector.set(tokenIndex);
    }
  };

  auto onInternal = [&treeMap] (auto& bitvector, auto* node) {
    for (auto& child : getChildren(node)) {
      if (child) {
        bitvector |= treeMap[child];
      }
    }
  };

  traverseASTInPostorder(tree, [onToken, onInternal, &treeMap] (auto* node) {
    auto& bitvector = treeMap[node];
    if (auto* token = getToken(node)) {
      onToken(bitvector, token);
      return makeResult(VisitAction::SKIP_CHILDREN);
    } else {
      onInternal(bitvector, node);
      return makeResult(VisitAction::VISIT_CHILDREN);
    }
  });

  return treeMap;
}


std::vector<const antlr4::Token*>
getTokens(const antlr4::tree::ParseTree& tree) {
  std::vector<const antlr4::Token*> tokens;

  traverseASTInPreorder(tree, [&tokens] (auto* node) {
    if (auto* token = getToken(node)) {
      tokens.push_back(token);
      return makeResult(VisitAction::SKIP_CHILDREN);
    }
    return makeResult(VisitAction::VISIT_CHILDREN);
  });

  return tokens;
}


std::unordered_set<std::string>
getUniqueTokenStrings(const antlr4::tree::ParseTree& tree) {
  std::unordered_set<std::string> strings;

  traverseASTInPreorder(tree, [&strings] (auto* node) {
    if (auto* token = getToken(node)) {
      strings.emplace(getText(token));
      return makeResult(VisitAction::SKIP_CHILDREN);
    }
    return makeResult(VisitAction::VISIT_CHILDREN);
  });

  return strings;
}


