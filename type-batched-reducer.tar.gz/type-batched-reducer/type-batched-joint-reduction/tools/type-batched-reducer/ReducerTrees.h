#pragma once

#include "antlr-wrapper.h"

testshrinker::Tree<const antlr4::tree::ParseTree*>
createReducerTree(const antlr4::tree::ParseTree& tree,
                  AntlrGrammarInfo const& grammar,
                  RuleEquivalence equivalence);

void
flattenRecursion(testshrinker::Tree<const antlr4::tree::ParseTree*>& tree,
                 antlr4::Parser& parser);

void
coarseHDDFlattening(testshrinker::Tree<const antlr4::tree::ParseTree*>& tree,
                    antlr4::Parser& parser);

void
removeRedundantNodes(testshrinker::Tree<const antlr4::tree::ParseTree*>& tree);

testshrinker::TreeSize
getSize(const testshrinker::Tree<const antlr4::tree::ParseTree*>& tree);


using TreeNode = testshrinker::TreeNode<const antlr4::tree::ParseTree*>;

template<typename Node>
using NodeRangeList =
  std::pair<llvm::SmallVector<Node*,4>, llvm::SmallVector<size_t,4>>;

llvm::DenseMap<const TreeNode*,NodeRangeList<TreeNode>>
mapTreesToSimilarSubtrees(const testshrinker::Tree<const antlr4::tree::ParseTree*>& tree);

llvm::DenseMap<const TreeNode*,llvm::SmallVector<TreeNode*,4>>
mapListElementsToSublists(const testshrinker::Tree<const antlr4::tree::ParseTree*>& tree);


std::vector<const antlr4::Token*>
getTokensReplacing(const testshrinker::Tree<const antlr4::tree::ParseTree*>& tree,
                   const llvm::DenseMap<const TreeNode*,
                                        antlr4::CommonToken*>& replacements);

testshrinker::TreeSize
getSize(const antlr4::tree::ParseTree& tree);

llvm::DenseMap<const antlr4::tree::ParseTree*,llvm::SparseBitVector<>>
mapTreesToTokens(const antlr4::tree::ParseTree& tree,
                 llvm::ArrayRef<std::string> tokens);

llvm::DenseMap<const antlr4::tree::ParseTree*,antlr4::tree::ParseTree*>
mapTreesToParents(const antlr4::tree::ParseTree& tree);

using DenseRangeList =
  std::pair<llvm::SmallVector<antlr4::tree::ParseTree*,4>,
            llvm::SmallVector<size_t,4>>;

llvm::DenseMap<const antlr4::tree::ParseTree*,DenseRangeList>
mapTreesToSimilarSubtrees(const antlr4::tree::ParseTree& tree);


class ParseTreePrinter : public ASTOperation {
public:
  explicit ParseTreePrinter(Listener& listener, llvm::raw_ostream& out)
    : ASTOperation{listener},
      out{out}
      { }

private:
  llvm::raw_ostream& out;
  void visitTree(antlr4::tree::ParseTree& tree,
                 antlr4::Parser& parser,
                 AntlrGrammarInfo& info) override final;
};


