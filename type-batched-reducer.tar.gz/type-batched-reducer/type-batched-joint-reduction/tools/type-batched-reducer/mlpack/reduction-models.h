#ifndef REDUCTION_MODELS_H
#define REDUCTION_MODELS_H

#include <string>

class ReductionModel {
public:
  ReductionModel(const std::string& path);
  ~ReductionModel();
  
  double probabilityFromTime(double time, std::string const & path);

private:
  class ModelImpl;

  std::unique_ptr<ModelImpl> modelImpl;
};

#endif
