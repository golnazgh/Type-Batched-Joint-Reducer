
#include <mlpack/core.hpp>
#include <mlpack/methods/logistic_regression/logistic_regression.hpp>
#include <mlpack/core/cv/metrics/accuracy.hpp>

#include <iostream>
#include <string>
#include <memory>

#include "reduction-models.h"

// NOTE: In ubuntu, this requires:
//   libmlpack-dev
//   libensmallen-dev
//   libopenblas-dev

using namespace mlpack;
using namespace mlpack::regression;


class ReductionModel::ModelImpl {
public:
  ModelImpl(const std::string& inpath) {
    mlpack::data::Load(inpath, "logistic_regression_model", lr, true /* Fatal on errors */);
  }
  
  double
  probabilityFromTime(double time, std::string const & path) {
    LogisticRegression<> lr{};
    mlpack::data::Load(path, "logistic_regression_model", lr, true /* Fatal on errors */);
    std::vector<double> feature;
    feature.push_back(time);
    arma::mat A = arma::conv_to<arma::mat>::from(feature);
    arma::mat probabilities;
    lr.Classify(A, probabilities);
    arma::mat::const_row_col_iterator it     = probabilities.begin_row_col();
    arma::mat::const_row_col_iterator it_end = probabilities.end_row_col(); 
    for (; it != it_end; ++it) {
       if (it.row() == 1) {
          return (*it);
       }
    }
    return 0;
  }

private:
  LogisticRegression<> lr;
};


ReductionModel::ReductionModel(const std::string& path) {
  modelImpl = std::make_unique<ModelImpl>(path);
}
ReductionModel::~ReductionModel() = default;


double
ReductionModel::probabilityFromTime(double time, std::string const & path) {
  return modelImpl->probabilityFromTime(time, path);
}



void
processOneTrainingSet(const std::string& path) {
  arma::mat rows;
  data::Load(path, rows);
  
  // MLPack logistic regression prefers columns of data rather than rows.
  // This means we need to transpose everything.
  arma::mat regressors = rows.row(0);
  const arma::Row<long unsigned int> outcomes = arma::conv_to<arma::Row<long unsigned int>>::from(rows.row(1));
  
  // Notice that we are not training the model.
  // We are just loading it from the file.
  LogisticRegression<> lr{};
  std::string inpath = path + ".model.bin";
  mlpack::data::Load(inpath, "logistic_regression_model", lr, true /* Fatal on errors */);
  
  arma::Row<size_t> predictions;
  lr.Classify(regressors, predictions, 0.5);
  
  std::cout << "Training set: " << path << "\n";
  std::cout << "Accuracy " << mlpack::cv::Accuracy::Evaluate(lr, regressors, outcomes) << "\n";
}

