
#include "antlr-plugins.h"
#include "reducers.h"
#include "TestCaseShrinker.h"
#include "HierarchicalTestCaseShrinker.h"
#include "ReducerTrees.h"


#include <llvm/ADT/DenseSet.h>
#include <llvm/ADT/SmallPtrSet.h>
#include <llvm/ADT/StringSet.h>
#include <llvm/Support/CommandLine.h>
#include <llvm/Support/FileSystem.h>
#include <llvm/Support/Program.h>
#include <llvm/Support/Timer.h>
#include <llvm/Support/ToolOutputFile.h>

#include <mutex>
#include <queue>
#include "reduction-models.h"

using namespace llvm;
using antlr4::Token;


// Including command line options here is ugly, but we only want them so that
// we can collect stats comparing the different splitting strategies when all
// other variables are held constant.

extern cl::OptionCategory reducerCategory;
extern cl::opt<ReducerMode> reducerMode;

struct IntWrapper {
  int value;
};

class DefaultIntParser : public llvm::cl::parser<IntWrapper> {
public:
  DefaultIntParser(llvm::cl::Option& o)
    : llvm::cl::parser<IntWrapper>{o}
      { }

  bool
  parse(llvm::cl::Option &o,
        llvm::StringRef argName,
        llvm::StringRef arg,
        IntWrapper &value) {
    if (arg == "") {
      value.value = 0;
    } else if (arg.getAsInteger(0, value.value)) {
      return o.error("'" + arg + "' value invalid for integer argument!");
    }
    return false;
  }
};


enum Language {
  C,
  RUST,
  GO
};

static cl::opt<uint32_t> timeoutOpt {"timeout",
  cl::desc{"Number of seconds to run the reducer. (default infinite)"},
  cl::cat{reducerCategory},
  cl::init(0)};

static cl::opt<bool> nullabilityInferenceOpt {"nullability-inference",
  cl::desc{"Enables inference of more nullable nodes which could yield larger search space"},
  cl::cat{reducerCategory},
  cl::init(false)};

static cl::opt<Language> languageOpt {"language",
  cl::desc{"Select the programming language domain your program belongs to."},
  cl::values(
    clEnumValN(Language::C, "c",
      "C programming language domain."),
    clEnumValN(Language::RUST, "rust",
      "Rust programming language domain."),
    clEnumValN(Language::GO, "go",
      "Go programming language domain.")
  ),
  cl::cat{reducerCategory},
  cl::init(Language::C)};
  

static cl::opt<bool> nullabilityPruningOpt {"nullability-pruning",
  cl::desc{"Prunes the search space by tagging only the first nullable node in a chain as nullable"},
  cl::cat{reducerCategory},
  cl::init(true)};


enum class SplitMode {
  HALF,
};

static cl::opt<SplitMode> splitMode{
  cl::desc{"Select the splitting approach"},
  cl::values(
    clEnumValN(SplitMode::HALF, "half",
      "split partitions in half")
  ),
  cl::cat{reducerCategory},
  cl::init(SplitMode::HALF)};


enum class Ordering {
  SEQUENTIAL_FF,
  SEQUENTIAL_FR,
  SEQUENTIAL_RF,
  SEQUENTIAL_RR,
  LINEAGE
};

static cl::opt<Ordering> orderMode {
  cl::desc{"Select the order to consider subsets and complements"},
  cl::values(
    clEnumValN(Ordering::SEQUENTIAL_FF, "seq-ff",
      "subsets forward, complements forward"),
    clEnumValN(Ordering::SEQUENTIAL_FR, "seq-fr",
      "subsets forward, complements reversed"),
    clEnumValN(Ordering::SEQUENTIAL_RF, "seq-rf",
      "subsets reversed, complements forward"),
    clEnumValN(Ordering::SEQUENTIAL_RR, "seq-rr",
      "subsets reversed, complements reversed"),
    clEnumValN(Ordering::SEQUENTIAL_FR, "dependence",
      "an alias of seq-fr, this tried to reduce breaking dependences"),
    clEnumValN(Ordering::LINEAGE, "tree-dependence",
      "try to remove the last elements of trees first")
  ),
  cl::cat{reducerCategory},
  cl::init(Ordering::SEQUENTIAL_FR)};

static cl::opt<testshrink::RevisitPolicy> revisitPolicy {"revisit",
  cl::desc{"Select whether the reducer will revisit complements after one succeeds"},
  cl::values(
    clEnumValN(testshrink::RevisitPolicy::ORIGINAL_DD, "dd",
      "enable revisiting"),
    clEnumValN(testshrink::RevisitPolicy::ONE_PASS, "skip",
      "disable revisiting")
  ),
  cl::cat{reducerCategory},
  cl::init(testshrink::RevisitPolicy::ORIGINAL_DD)};

static cl::opt<bool> prefilterTreeOpt {"prefilter",
  cl::desc{"Prefilter the less useful nodes of the tree."},
  cl::cat{reducerCategory},
  cl::init(true)};


static cl::opt<bool> useTokenCache {"tokencache",
  cl::desc{"Cache test results across levels of the tree."},
  cl::cat{reducerCategory},
  cl::init(false)};


class TimeoutGuard {
public:
  TimeoutGuard()
    : seconds{timeoutOpt} {
    if (seconds) {
      timeout.startTimer();
    }
  }

  // We don't really care about preserving state, so moved timers are fresh.
  TimeoutGuard(TimeoutGuard&& other)
    : TimeoutGuard()
      { }

  ~TimeoutGuard() {
    if (seconds) {
      timeout.stopTimer();
    }
  }

  bool
  hasTimedOut() noexcept {
    if (seconds) {
      timeout.stopTimer();
      double elapsed = timeout.getTotalTime().getWallTime();
      timeout.startTimer();
      return seconds <= elapsed;
    }
    return false;
  }

private:
  uint32_t seconds;
  llvm::TimerGroup timerGroup{"Timeouts", "Timeouts"};
  llvm::Timer timeout{"Timeout", "Timeout", timerGroup};
};


static void
replaceWith(TreeNode& node, TreeNode& replacement) {
  auto getLinkTo = [] (auto& n) -> TreeNode*& {
    auto& siblings = n.getParent()->getChildren();
    auto pos = std::find_if(std::begin(siblings), std::end(siblings),
      [&n] (auto& child) { return child == &n; });
    return *pos;
  };
  auto &nodeLink = getLinkTo(node);

  replacement.setParent(node.getParent());
  node.setParent(nullptr);

  nodeLink = &replacement;
}


static int
runChecker(const std::string& checkerPath,
           llvm::SmallString<256>& filePath) {
  bool failed = false;
  std::string err;
  StringRef empty;
  llvm::Optional<llvm::StringRef> redirects[] = { llvm::None, empty, empty };
  llvm::StringRef args[] = { checkerPath, filePath };
  auto result = llvm::sys::ExecuteAndWait(
      static_cast<const char*>(checkerPath.c_str()),
      llvm::makeArrayRef<llvm::StringRef>(args),
      llvm::NoneType::None,
      redirects,
      0,
      0,
      &err,
      &failed
    );

  if (failed) {
    for (auto arg : args) {
      llvm::errs() << arg << "\n";
    }
    llvm::report_fatal_error("Unable to run checker:\n\n" + failed);
  }

  return result;
}


static std::pair<std::unique_ptr<llvm::ToolOutputFile>,SmallString<256>>
getTemporaryOutputFile() {
  auto outputPath = llvm::SmallString<256>{};
  auto error = llvm::sys::fs::createTemporaryFile("reduced", "", outputPath);
  if (error) {
    llvm::report_fatal_error("Unable to create temporary output file.");
  }

  auto outfile =
    std::make_unique<llvm::ToolOutputFile>(outputPath, error, sys::fs::F_Text);
  if (error) {
    llvm::report_fatal_error("Unable to open temporary output file.");
  }
  return make_pair(std::move(outfile), outputPath);
}


class PropertyChecker {
private:
  SourceReducer::Listener& listener;
  llvm::StringRef checkerPath;
  AntlrGrammarInfo const& grammar;
  testshrinker::Tree<const antlr4::tree::ParseTree*> const& tree;

public:
  PropertyChecker(SourceReducer::Listener& listener,
                  llvm::StringRef checkerPath,
                  AntlrGrammarInfo const& grammar,
                  testshrinker::Tree<const antlr4::tree::ParseTree*> const& tree)
    : listener{listener},
      checkerPath{checkerPath},
      grammar{grammar},
      tree{tree}
      { }

  bool
  operator()(llvm::ArrayRef<Token const*> tokens) {
    listener.beginTest();
    
    auto tempfile    = getTemporaryOutputFile();
    auto &outfile    = tempfile.first;
    auto &outputPath = tempfile.second;

    grammar.print(outfile->os(), tokens);
    outfile->os().close();

    auto propertyHolds = (1 == runChecker(checkerPath, outputPath));

    listener.endTest(propertyHolds, tree);
    return propertyHolds;
  }


   size_t
  operator()(const std::string & dummy, llvm::ArrayRef<Token const*> tokens) {
    listener.beginTest();
    

    auto tempfile    = getTemporaryOutputFile();
    auto &outfile    = tempfile.first;
    auto &outputPath = tempfile.second;
    grammar.print(outfile->os(), tokens);
    outfile->os().close();
    auto testOutCome = runChecker(checkerPath, outputPath);
    listener.endTestTypeAware(testOutCome, tree);
    return testOutCome;
  }

  void
  setStrategy(const char* strategy) const {
    listener.setTestStrategy(strategy);
  }

  void
  countRedundant(uint64_t numRedundant) {
    listener.countRedundant(numRedundant);
  }
};


static std::vector<const antlr4::Token*>
getTokensForChangeList(const testshrink::AtomSet& tokenIDs,
                       llvm::ArrayRef<const Token*> tokens) {
  auto results = std::vector<const antlr4::Token*>(tokenIDs.count());
  std::transform(tokenIDs.begin(), tokenIDs.end(), results.begin(),
    [=] (const auto id) { return tokens[id]; });
  return results;
}


class TokenCache : public testshrink::DefaultTestCache {
public:
  explicit TokenCache(antlr4::tree::ParseTree& tree)
    : tree{tree}
      { }

  void
  setLevelNodes(llvm::ArrayRef<antlr4::tree::ParseTree*> newLevelNodes) {
    levelNodes = newLevelNodes;
  }

private:
  antlr4::tree::ParseTree& tree;
  std::set<testshrink::AtomSet,testshrink::CompareAtomSets> failedTestsCache;
  llvm::ArrayRef<antlr4::tree::ParseTree*> levelNodes;

  testshrink::AtomSet
  getTokenSet(testshrink::AtomSet const& configuration) const noexcept {
    testshrink::AtomSet atomSet;
    llvm::SmallPtrSet<const antlr4::tree::ParseTree*,32> toSkip;
    auto& mutableNodeIDs = const_cast<testshrink::AtomSet&>(configuration);
    for (std::size_t i = 0; i < levelNodes.size(); ++i) {
      if (!mutableNodeIDs.test(i)) {
        toSkip.insert(levelNodes[i]);
      }
    }

    for (auto* token : getTokensSkipping(*asTree(&tree), toSkip)) {
      atomSet.set(getTokenIndex(token));
    }
    return atomSet;
  }

  bool
  containsImpl(testshrink::AtomSet const& configuration) const override {
    auto tokenSet = getTokenSet(configuration);
    return failedTestsCache.count(tokenSet);
  }

  bool
  addImpl(testshrink::AtomSet const& configuration) override {
    auto tokenSet = getTokenSet(configuration);
    return failedTestsCache.insert(tokenSet).second;
  }
};


template<typename Node>
std::unique_ptr<testshrink::Splitter>
getSplitPolicy(llvm::ArrayRef<Node> candidates) {
  switch (splitMode) {
    case SplitMode::HALF:
      return std::make_unique<testshrink::HalvingSplitter>();
  }
  llvm_unreachable("Invalid split mode in getSplitPolicy.");
}


std::unique_ptr<testshrink::GranularitySearcher>
getSearcher(testshrink::TestRunner& runner, testshrink::TestCache& cache) {
  return std::make_unique<testshrink::SearchExecutor>(runner, cache, revisitPolicy);
}


template<typename Node>
std::unique_ptr<testshrink::Prioritizer>
getPrioritizer(llvm::ArrayRef<Node> candidates) {
  bool reverseSubset = false, reverseComplement = false;
  switch (orderMode) {
    case Ordering::SEQUENTIAL_FF:
      break;
    case Ordering::SEQUENTIAL_FR:
      reverseComplement = true;
      break;
    case Ordering::SEQUENTIAL_RF:
      reverseSubset = true;
      break;
    case Ordering::SEQUENTIAL_RR:
      reverseSubset = reverseComplement = true;
      break;
    default:
      llvm_unreachable("Invalid ordering mode selected.");
  }
  using Prioritizer = testshrink::InSequencePrioritizer;
  return std::make_unique<Prioritizer>(reverseSubset, reverseComplement);
}


template<typename Node>
std::unique_ptr<testshrink::TestShrinker>
getShrinker(llvm::ArrayRef<Node> candidates,
            testshrink::TestRunner& runner,
            testshrink::TestCache& cache) {
  auto prioritizer = getPrioritizer(candidates);
  auto splitter    = getSplitPolicy(candidates);
  auto searcher    = getSearcher(runner, cache);
  return std::make_unique<testshrink::OwningHierarchicalShrinkerWrapper>(
      std::move(searcher), std::move(prioritizer), std::move(splitter)
    );
}


class AntlrDDTestRunner : public testshrink::TestRunner {
  using AtomSet = testshrink::AtomSet;
  using Token = antlr4::Token;
  llvm::ArrayRef<const Token*> tokens;
  PropertyChecker& propertyHolds;

  Outcome
  runImpl(AtomSet const& tokenIDs) override {
    auto resultTokens = getTokensForChangeList(tokenIDs, tokens);
    return propertyHolds(resultTokens) ? Outcome::FOUND : Outcome::NOT_FOUND;
  }

public:
  AntlrDDTestRunner(llvm::ArrayRef<const Token*> tokens,
                    PropertyChecker& propertyHolds)
    : tokens{tokens},
      propertyHolds{propertyHolds}
      { }
};


static std::vector<const antlr4::Token*>
getTokens(llvm::ArrayRef<const testshrinker::TreeNode<const antlr4::tree::ParseTree*>*> leaves) {
  std::vector<const antlr4::Token*> tokens;
  tokens.reserve(leaves.size());
  for (auto* leaf : leaves) {
    if (auto* token = getToken(leaf->getElement())) {
      tokens.push_back(token);
    }
  }
  return tokens;
}


static std::vector<const antlr4::Token*>
getTokensSkipping(testshrinker::Tree<const antlr4::tree::ParseTree*>& tree,
                  llvm::SmallPtrSetImpl<const testshrinker::TreeNode<const antlr4::tree::ParseTree*>*>& toSkip) {
  return getTokens(tree.root->getLeavesSkipping(toSkip));
}


static std::vector<const antlr4::Token*>
getTokens(testshrinker::Tree<const antlr4::tree::ParseTree*>& tree) {
  return getTokens(tree.root->getLeavesWhen([] (auto&, auto&) {return true; }));
}


template<typename Tree, typename Node>
class AntlrHDDTestRunner : public testshrink::TestRunner {
  using AtomSet = testshrink::AtomSet;
  PropertyChecker &checker;
  Tree& tree;
  llvm::ArrayRef<Node*> nodes;

  Outcome
  runImpl(AtomSet const& nodeIDs) override {
    llvm::SmallPtrSet<const Node*,32> toSkip;
    auto& mutableNodeIDs = const_cast<AtomSet&>(nodeIDs);
    for (std::size_t i = 0; i < nodes.size(); ++i) {
      if (!mutableNodeIDs.test(i)) {
        toSkip.insert(nodes[i]);
      }
    }

    auto tokens = getTokensSkipping(tree, toSkip);
    return checker(tokens) ? Outcome::FOUND : Outcome::NOT_FOUND;
  }

public:
  AntlrHDDTestRunner(PropertyChecker &checker,
                     Tree& tree,
                     llvm::ArrayRef<Node*> nodes)
    : checker{checker},
      tree{tree},
      nodes{nodes}
      { }
};


template<typename Tree, typename Node>
AntlrHDDTestRunner<Tree, Node>
makeAntlrHDDTestRunner(PropertyChecker &checker,
                       Tree& tree,
                       llvm::ArrayRef<Node*> nodes) {
  return AntlrHDDTestRunner<Tree, Node>(checker, tree, nodes);
}


static void
pruneTokenlessSubtrees(testshrinker::Tree<const antlr4::tree::ParseTree*>& tree) {
  using Node = testshrinker::Tree<const antlr4::tree::ParseTree*>::Node;
  // First collect the parents of all leaves that are rules
  auto leaves = tree.root->getLeaves();
  auto rules = std::partition(leaves.begin(), leaves.end(),
               [] (auto* node) { return node->isAttr(Node::IS_RULE); });
  std::deque<Node*> worklist(std::distance(leaves.begin(), rules));
  std::transform(leaves.begin(), rules, worklist.begin(),
                 [] (const auto* node) { return node->getParent(); });

  // Then prune their children recursively as possible.
  auto nodeIsRemovable = [] (auto* node) -> bool {
    assert(node && "Null node passed to nodeIsRemovable");
    auto& children = node->getChildren();
    return node->isAttr(TreeNode::IS_RULE)
      && (children.empty()
        || std::all_of(children.begin(), children.end(),
                       [] (auto* child) { return !child; }));
  };

  while (!worklist.empty()) {
    auto* node = worklist.front();
    worklist.pop_front();

    bool hasRemainingChildren = false;
    auto& children = node->getChildren();
    for (auto*& child : children) {
      if (!child) {
        continue;
      }
      if (nodeIsRemovable(child)) {
        child = nullptr;
      } else {
        hasRemainingChildren = true;
      }
    }

    if (!hasRemainingChildren && node->getParent()) {
      worklist.push_back(node->getParent());
    }
  }
}


static void
tagNullableNodes(testshrinker::Tree<const antlr4::tree::ParseTree*>& tree,
                 antlr4::Parser& parser) {
  using Node = testshrinker::Tree<const antlr4::tree::ParseTree*>::Node;
  auto ruleNames = getRuleNames(parser);
  auto option = llvm::StringRef("optional__");
  auto plus = llvm::StringRef("kleene_plus__");
  auto star = llvm::StringRef("kleene_star__");


  auto markNullable = [&ruleNames, option, plus, star] (auto* node) -> void {
    if (!node) {
      return;
    }
    auto& children = node->getChildren();

    auto ruleIndex = getRuleIndex(node->getElement());
    if (ruleIndex.first) {
      llvm::StringRef name{ruleNames[ruleIndex.second]};
      if (name.startswith(star) || name.startswith(plus)) {
        node->setAttr(Node::IS_LIST);
      }
      if (name.startswith(star)
          || name.startswith(plus)
          || name.startswith(option)) {
        node->setAttr(Node::IS_ALWAYS_NULLABLE);
        for (auto*& child : children) {
          if (child) {
            child->setAttr(Node::IS_ALWAYS_NULLABLE);
          }
        }
      }
    }

    bool nullable = node->isAttr(Node::IS_RULE)
      && std::all_of(children.begin(), children.end(),
           [] (auto* child) { return !child || child->isNullable(); });
    if (nullable && nullabilityInferenceOpt) {
      node->setAttr(Node::IS_ALWAYS_NULLABLE);
    }
  };
  Timer nullabilityTimer{"Nullability Time", "Nullability Time"};
  nullabilityTimer.startTimer();
  tree.visitPostorder(markNullable);
  nullabilityTimer.stopTimer();
}


static testshrinker::Tree<const antlr4::tree::ParseTree*>::Node::ChildList
getRemainingChildren(testshrinker::Tree<const antlr4::tree::ParseTree*>::Node* node) {
  auto childCopy = node->getChildren();
  auto firstNull = std::partition(childCopy.begin(), childCopy.end(),
    [] (auto* node) { return node != nullptr; });
  childCopy.erase(firstNull, childCopy.end());
  return childCopy;
}


static void
pruneExtraNulls(testshrinker::Tree<const antlr4::tree::ParseTree*>& tree) {
  using Node = testshrinker::Tree<const antlr4::tree::ParseTree*>::Node;
  size_t remaining = 0, list = 0, optional = 0;
  auto pruneChain = [&remaining, &list, &optional] (auto* start, auto& prune) {
    auto* node = start;
    bool clear = false;
    // Traverse one chain and strip nullability after the first nullable node
    while (node) {
      if (clear) {
        if (node->getParent()->isAttr(Node::IS_LIST)) {
          list += 1;
        } else {
          optional += 1;
        }
        node->clearAttr(Node::IS_ALWAYS_NULLABLE);
      } else if (node->isNullable()) {
        remaining += 1;
        clear = true;
      }
      auto remainingKids = getRemainingChildren(node);
      if (remainingKids.size() != 1) {
        break;
      }
      node = remainingKids.front();
    }

    if (!node) {
      return;
    }

    // Do the same to all children
    for (auto* child : node->getChildren()) {
      prune(child, prune);
    }
  };
  pruneChain(tree.root, pruneChain);
  llvm::outs() << "Pruning Stats >> Total: " << (remaining + list + optional)
               << " List: " << list
               << " Optional: " << optional
               << " Remaining: " << remaining
               << "\n";
}




void
SourceReducer::visitTree(antlr4::tree::ParseTree& tree,
                         antlr4::Parser& parser,
                         AntlrGrammarInfo& info) {
  auto shrinkerTree = createReducerTree(tree, info, RuleEquivalence::RULE_INDEX);
  pruneTokenlessSubtrees(shrinkerTree);
  tagNullableNodes(shrinkerTree, parser);
  if(nullabilityPruningOpt) {
    pruneExtraNulls(shrinkerTree);
  }

  auto size = getSize(shrinkerTree);
  llvm::outs() << "After filtering size (nodes): " << size.nodes << "\n";

  listener.beginReductionPhase(shrinkerTree);
  reduce(shrinkerTree, parser, info);
  listener.endReductionPhase(shrinkerTree);
}


static testshrink::AtomSet
createChangeIDSetOfSize(const size_t size) {
  auto changeIDs = testshrink::AtomSet{};
  for (testshrink::Atom id = 0; id < size; ++id) {
    changeIDs.set(id);
  }
  return changeIDs;
}



namespace {


struct Identity {
  template<typename T>
  constexpr auto
  operator()(T&& t) const noexcept -> decltype(std::forward<T>(t)) {
    return std::forward<T>(t);
  }
};


template<typename E>
static SmallPtrSet<testshrinker::TreeNode<E>*,32>
pruneTreeFrontier(PropertyChecker& checker,
                  testshrinker::Tree<E>& tree,
                  llvm::ArrayRef<testshrinker::TreeNode<E>*> candidates,
                  testshrink::TestCache* cache=nullptr) {
  auto toRemove  = SmallPtrSet<testshrinker::TreeNode<E>*,32>{};
  auto changes   = createChangeIDSetOfSize(candidates.size());

  auto runner       = makeAntlrHDDTestRunner(checker, tree, candidates);
  auto defaultCache = testshrink::DefaultTestCache{};
  auto shrinker     = getShrinker(candidates, runner, cache ? *cache : defaultCache);
  auto idsToKeep    = shrinker->shrinkTestCase(changes, runner);

  checker.countRedundant(shrinker->getRedundantTests());

  for (testshrink::Atom id = 0; id < candidates.size(); ++id) {
    if (idsToKeep.test(id)) {
      continue;
    }
    auto* node = candidates[id];
    node->eraseFromParent();
    toRemove.insert(node);
  }

  return toRemove;
}


class AntlrLevelOperation
  : public testshrinker::LevelOperation<const antlr4::tree::ParseTree*> {
public:
  AntlrLevelOperation(testshrinker::LevelListener& listener,
                      Tree& tree,
                      AntlrGrammarInfo const& grammar,
                      antlr4::Parser& parser,
                      PropertyChecker& checker)
    : testshrinker::LevelOperation<const antlr4::tree::ParseTree*>{listener},
      tree{tree},
      grammar{grammar},
      parser{parser},
      checker{checker}
      { }

protected:
  Tree& tree;
  AntlrGrammarInfo const& grammar;
  antlr4::Parser& parser;
  PropertyChecker& checker;
};


template<typename Sorter, typename Selector>
class HDDLevelOperation : public AntlrLevelOperation {
public:
  HDDLevelOperation(testshrinker::LevelListener& listener,
                    Tree& tree,
                    AntlrGrammarInfo const& grammar,
                    antlr4::Parser& parser,
                    PropertyChecker& checker,
                    Sorter& sort,
                    Selector& select)
    : AntlrLevelOperation{listener, tree, grammar, parser, checker},
      sort{sort},
      select{select}
      { }

private:
  Sorter& sort;
  Selector& select;

  bool
  applyImpl(std::vector<Node*>& nodes, size_t targetLevel) override {
    auto candidates = select(llvm::makeArrayRef(nodes));
    sort(candidates);
    auto toRemove = pruneTreeFrontier(checker, tree, llvm::makeArrayRef(candidates), nullptr);
    auto pos = std::remove_if(nodes.begin(), nodes.end(),
      [&toRemove] (auto* node) { return toRemove.count(node); });
    nodes.erase(pos, nodes.end());
    return !toRemove.empty();
  }

  llvm::StringRef getName() override { return "HDD"; }
};


class PropertyCheckingLevelListener : public testshrinker::LevelListener {
public:
  PropertyCheckingLevelListener(PropertyChecker& checker)
    : checker{checker}
      { }

  void
  beginOperation(llvm::StringRef name) override {
    checker.setStrategy(name.data());
  }

private:
  PropertyChecker& checker;
};


}


enum TraversalMode {
  PARDIS,
  PERSES
};


static cl::opt<TraversalMode> traversalModeOpt {"traversal-mode",
  cl::desc{"Select the mechanism for traversal based reduction"},
  cl::values(
    clEnumValN(TraversalMode::PARDIS, "pardis",
      "Pardis node by node reduction."),
    clEnumValN(TraversalMode::PERSES, "perses",
      "Perses list reduction")
  ),
  cl::cat{reducerCategory},
  cl::init(TraversalMode::PARDIS)};


template<class E>
static llvm::DenseMap<typename testshrinker::Tree<E>::Node*, uint32_t>
computeBFSPosition(testshrinker::Tree<E>& tree) {
  using Node = typename testshrinker::Tree<E>::Node;
  llvm::DenseMap<Node*, uint32_t> bfsPositions;
  std::vector<Node*> nodes;
  nodes.reserve(1024);
  nodes.push_back(tree.root);

  size_t next = 0;
  while (next < nodes.size()) {
    auto* node = nodes[next];
    ++next;

    auto& children = node->getChildren();
    for (auto* child : children) {
      if (child) {
        nodes.push_back(child);
      }
    }
  }

  for (unsigned i = 0, e = nodes.size(); i < e; ++i) {
    bfsPositions[nodes[i]] = i;
  }
  return bfsPositions;
}


template<class E>
static llvm::DenseMap<typename testshrinker::Tree<E>::Node*, uint32_t>
computeTokensBelowNodes(testshrinker::Tree<E>& tree) {
  using Node = typename testshrinker::Tree<E>::Node;
  llvm::DenseMap<Node*, uint32_t> tokenWeights;
  auto count = [&tokenWeights] (Node* node) -> void {
    if (!node->isAttr(Node::IS_RULE)) {
      tokenWeights[node] = 1;
    } else {
      uint32_t tokenCount = 0;
      for (auto* child : node->getChildren()) {
        if (child) {
          tokenCount += tokenWeights[child];
        }
      }
      tokenWeights[node] = tokenCount;
    }
  };
  tree.visitPostorder(count);
  return tokenWeights;
}

 using Node = testshrinker::TreeNode<const antlr4::tree::ParseTree*>;




struct TraversalBasedReducerImpl {
  AntlrGrammarInfo const& grammar;
  antlr4::Parser& parser;
  PropertyChecker& checker;
  TimeoutGuard timer;
  using Count = uint32_t;

  TraversalBasedReducerImpl(AntlrGrammarInfo const& grammar,
                           antlr4::Parser& parser,
                           PropertyChecker& checker)
    : grammar{grammar},
      parser{parser},
      checker{checker},
      timer{}
      { }

  template<typename E>
  size_t
  operator()(testshrinker::Tree<E>& tree, const size_t targetLevel = -1) {
    Worklist<E> worklist;
    Weight root_weight {0,0,0};
    worklist.push({tree.root, root_weight});
    auto subtreeMap = mapTreesToSimilarSubtrees(tree);
    auto processor = getTraversalProcessor(tree, checker);
    while (!worklist.empty()) {
      if (timer.hasTimedOut()) {
        llvm::errs() << "TIMED OUT!\n";
        break;
      }
      processor->processWork(worklist, subtreeMap);
    }

    return !processor->anyRemoved() ? -1 : 0;
  }

private:
  template <class E>
  using Node = typename testshrinker::Tree<E>::Node;

  using Weight = std::tuple<Count, Count, Count>;
  enum Phase { LIST = 3, NORMAL = 2, NAMED_LIST = 1 };
  
  template<typename E>
  struct Entry {
    Node<E>* node;
    Weight weight;
    bool operator<(Entry n2) const { return this->weight < n2.weight; }
  };

  template<typename E>
  using Worklist = std::priority_queue<Entry<E>>;

  template <typename E>
  class WorkPolicy {
  public:
    using ChildList = typename Node<E>::ChildList;
    const llvm::DenseMap<Node<E>*, Count> nodeOrder;
    const llvm::DenseMap<Node<E>*, Count> tokenWeight;

    explicit WorkPolicy(testshrinker::Tree<E>& tree, PropertyChecker& checker)
      : nodeOrder{computeBFSPosition(tree)},
        tokenWeight{computeTokensBelowNodes(tree)},
        tree{tree},
        checker{checker},
        removed{false}
        { }

    void
    remove(Node<E>* node) {
      node->eraseFromParent();
      removed = true;
    }

    void
    processWork(Worklist<E>& worklist, llvm::DenseMap<const TreeNode*,NodeRangeList<TreeNode>>& subtreeMap) {
      processWorkImpl(worklist, subtreeMap);
    }

  ChildList
   addNodeToWork(Node<E>* node) {
      ChildList newWork;
      newWork.push_back(node);
      return newWork;
   }

    bool
    removalSucceeds(Node<E>* node) {
      checker.setStrategy("Node");
      llvm::SmallPtrSet<const Node<E>*,32> toSkip;
      toSkip.insert(node);
      auto remaining = getTokensSkipping(tree, toSkip);
      return checker(remaining);
    }

      std::pair<bool, TreeNode*>
    replacementSucceeds(Node<E>* node, llvm::DenseMap<const TreeNode*,NodeRangeList<TreeNode>>& subtreeMap) {
         auto found = subtreeMap.find(node);
         if (found == subtreeMap.end()) {
          return std::make_pair(false, nullptr);
         }
         auto& replacements = found->second.first;
         auto replacement = std::find_if(replacements.begin(), replacements.end(),
         [&] (auto* descendent) {
             DenseMap<const TreeNode*,const TreeNode*> remap;
             remap[node] = descendent;
             auto leaves = tree.root->getLeavesReplacing(remap);
             auto tokens = getTokens(leaves);
             return checker(tokens);
           });
          if (replacement == replacements.end()) {
              return std::make_pair(false, nullptr);
          }
           return std::make_pair(true, *replacement);
    }

    SmallPtrSet<testshrinker::TreeNode<E>*,32>
    shrinkList(llvm::ArrayRef<Node<E>*> candidates) {
      checker.setStrategy("List");
      return pruneTreeFrontier(checker, tree, candidates);
    }

    bool anyRemoved() const noexcept { return removed; }

    bool
    isListElement(const Node<E>* node) const noexcept {
      auto* parent = node->getParent();
      return parent && parent->isAttr(Node<E>::IS_LIST);
    }

    void
    addWork(Worklist<E>& worklist, ChildList& newWork) {
      for (auto* node : newWork) {
        if (node) {
          worklist.push({node, this->makeWeight(node)});
        }
      }
    }

  private:
    testshrinker::Tree<E>& tree;
    PropertyChecker& checker;
    bool removed;

    virtual void processWorkImpl(Worklist<E>& worklist, llvm::DenseMap<const TreeNode*,NodeRangeList<TreeNode>>& subtreeMap) = 0;
    virtual Weight makeWeight(Node<E>* node) = 0;
  };

  template <typename E>
  class PardisPolicy : public WorkPolicy<E> {
  public:
    PardisPolicy(testshrinker::Tree<E>& tree, PropertyChecker& checker)
      : WorkPolicy<E>{tree, checker}
        { }

  private:
    void
    processWorkImpl(Worklist<E>& worklist, llvm::DenseMap<const TreeNode*,NodeRangeList<TreeNode>>& subtreeMap) override {
      auto work = worklist.top();
      worklist.pop();

      if (work.node->isNullable()) {
         if (this->removalSucceeds(work.node)) {
           this->remove(work.node);
         }
         else {
          this->addWork(worklist, work.node->getChildren());
        }
      }
       else {
          auto replacementTest = this->replacementSucceeds(work.node, subtreeMap);
          if (replacementTest.first) {
               auto replacement = replacementTest.second;
               replaceWith(*(work.node), *(replacement));
                auto new_node = this->addNodeToWork(replacement);
               this->addWork(worklist, new_node);

         }
          else {
           this->addWork(worklist, work.node->getChildren());
          }
      }

    }

    Weight
    makeWeight(Node<E>* node) override {
      return Weight{this->tokenWeight.lookup(node),
                    this->nodeOrder.lookup(node), 0};
    }
  };



  template <typename E>
  class PersesPolicy : public WorkPolicy<E> {
  public:
    PersesPolicy(testshrinker::Tree<E>& tree, PropertyChecker& checker)
      : WorkPolicy<E>{tree, checker}
        { }

  private:
    void
    processWorkImpl(Worklist<E>& worklist, llvm::DenseMap<const TreeNode*,NodeRangeList<TreeNode>>& subtreeMap) override {
      auto work = worklist.top();
      worklist.pop();

      if (work.node->isAttr(Node<E>::IS_LIST)) {
        auto children = work.node->getChildren();
        auto null = std::remove(children.begin(), children.end(), nullptr);
        children.erase(null, children.end());
        auto toRemove = this->shrinkList(children);
        for (auto* node : toRemove) {
          this->remove(node);
        }
        this->addWork(worklist, work.node->getChildren());

      } else if (work.node->isNullable()
                 && !this->isListElement(work.node)
                 && this->removalSucceeds(work.node)) {
        this->remove(work.node);

      } 
      else if  (!work.node->isNullable()) {
          auto replacementTest = this->replacementSucceeds(work.node, subtreeMap);
          if (replacementTest.first) {
               auto replacement = replacementTest.second;
               replaceWith(*(work.node), *(replacement));
              auto new_node = this->addNodeToWork(replacement);
               this->addWork(worklist, new_node);

          }
          else {
           this->addWork(worklist, work.node->getChildren());

          }
      }
        else {
            this->addWork(worklist, work.node->getChildren());

         }

    }

    Weight
    makeWeight(Node<E>* node) override {
      return Weight{this->tokenWeight.lookup(node),
                    this->nodeOrder.lookup(node), 0};
    }
  };

  template <class E>
  std::unique_ptr<WorkPolicy<E>>
  getTraversalProcessor(testshrinker::Tree<E>& tree, PropertyChecker& checker) {
    switch (traversalModeOpt) {
      case TraversalMode::PARDIS:
        return std::make_unique<PardisPolicy<E>>(tree, checker);
      case TraversalMode::PERSES:
        return std::make_unique<PersesPolicy<E>>(tree, checker);
    }
    llvm_unreachable("Invalid traversal besed reducer!");
  }
};

   void
  updateTypeProbs(llvm::DenseMap<int, double> & typesProbs, int current_tree_size, int initial_tree_size, llvm::DenseMap<int, bool> & checked) {
   for (auto& elem: typesProbs) {
       if (elem.second != 1 && elem.second != -2 && checked[elem.first] == false) {
         std::string type_id = std::to_string(elem.first);
         std::string path = "";
         std::string prefix = "../type-batched-joint-reduction/tools/type-batched-reducer/mlpack/";
         switch (languageOpt) {
           case Language::C:
              path = prefix+"/c-models/sc."+type_id+".csv.model.bin";
              break;
           case Language::RUST:
              path = prefix+"/rust-models/sc."+type_id+".csv.model.bin";   
              break;  
           case Language::GO:
              path = prefix+"/go-models/sc."+type_id+".csv.model.bin";
              break;
    }
         ReductionModel model(path);
         double time = (double)(current_tree_size)/initial_tree_size;
         double prob = model.probabilityFromTime(time, path);
         typesProbs[elem.first] = prob;
       }
   }
}

  
  bool
hasAncestorSameType(const Node* node, int ri) {
   while ((node = node->getParent())) {
      auto rule_index = getRuleIndex(node->getElement());
      if (rule_index.first) {
        if (rule_index.second == ri) {
           return true;
        }
      }
   }
   return false;
}

  template<class E>
static llvm::DenseMap<int, std::pair<double, double>>
collectTypeWeightsAndTests(testshrinker::Tree<E>& tree, llvm::DenseMap<int, double> & typesProbs) {
    using Node = typename testshrinker::Tree<E>::Node;
 llvm::DenseMap<int, std::pair<double, double>> type_weights_tests;
 for (auto& elem: typesProbs) {
     type_weights_tests[elem.first] = std::make_pair(0, 0);
 }
   auto compute = [&] (Node* node) -> void {
       if (node->isNullable()) {
          int ri = -1;
          auto ri_rule = getRuleIndex(node->getElement());
          if (ri_rule.first) {
            ri = ri_rule.second;
          }
          if (ri != -1 && type_weights_tests.find(ri) != type_weights_tests.end() && !hasAncestorSameType(node, ri)) {
             type_weights_tests[ri].first += getTokens(node->getLeavesWhen([] (auto&, auto&) {return true; })).size();
             type_weights_tests[ri].second += 1;
          }
        }
  };
  tree.visitPostorder(compute);
  return type_weights_tests;

}
      template<typename E>
llvm::DenseMap<int, double>
getPotentialRemoval(testshrinker::Tree<E>& tree, llvm::DenseMap<int, double> & typesProbs, llvm::DenseMap<int, bool> & checked) {
  auto benefits_costs = collectTypeWeightsAndTests(tree, typesProbs); 
  llvm::DenseMap<int, double> type_gain;
   for (auto & elem: typesProbs) {
      if (checked[elem.first]) {
        type_gain[elem.first] = 0;
        continue;
      }
      if (elem.second == -2) {
         continue;
      }
      auto type_benefit_cost = benefits_costs.lookup(elem.first);
      double benefit = type_benefit_cost.first;
      double cost = type_benefit_cost.second;
      if (benefit == 0 && cost == 0) {
        continue;
      }
      type_gain[elem.first] = typesProbs[elem.first] * benefit / cost;
   }
  return type_gain;
}

  
  template<class E>
static std::pair<double, double>
computeExpectedGainAndCostForPardis(testshrinker::Tree<E>& tree, llvm::DenseMap<int, double> & typesProbs) {
   using Node = typename testshrinker::Tree<E>::Node;
 
 llvm::DenseMap<Node*, double> costMap;
  auto computeCosts = [&] (Node* node) -> void {
    if (node->isAttr(Node::IS_RULE)) {
       double children_cost = 0;
       for (auto* child : node->getChildren()) {
          if (child) {
            children_cost += costMap[child];
         }
       }
       
       auto ri = getRuleIndex(node->getElement()).second;
       double probability = typesProbs.lookup(ri);
       if (-2.0 == probability) {
         probability = 0.0;
       }
       double weight = (node->isNullable()) ? 1 : 0;
       // NOTE: a nullable node is always expected to perform a test (locally)
       //   There is no need to multiple by the probability at this point.
       //   We only need to multiple by (1-p) over the children because
       //   That is the probability that we will fail to remove this node
       //   and proceed to run those tests.
       costMap[node] = weight + (1 - probability) * children_cost;
    } else {
      costMap[node] = 0;
    }
  };
  tree.visitPostorder(computeCosts);

  llvm::DenseMap<Node*, uint32_t> counts = computeTokensBelowNodes(tree);
  llvm::DenseMap<Node*, double> gainMap;
  auto computeGains = [&] (Node* node) -> void {
    if (node->isAttr(Node::IS_RULE)) {
       double children_gain = 0;
       for (auto* child : node->getChildren()) {
          if (child) {
            children_gain += gainMap[child];
         }
       }
       
       auto ri = getRuleIndex(node->getElement()).second;
       double probability = typesProbs.lookup(ri);
       if (-2.0 == probability) {
         probability = 0.0;
       }
       double weight = counts[node];
       // NOTE: Here, the benefit only happens `probability` amount of the time locally.
       gainMap[node] = probability * weight + (1 - probability) * children_gain;
    } else {
      gainMap[node] = 0;
    }
  };
  tree.visitPostorder(computeGains);

  return std::make_pair(gainMap[tree.root], costMap[tree.root]);
}


struct TypeBatchedReducerImpl {
  AntlrGrammarInfo const& grammar;
  antlr4::Parser& parser;
  PropertyChecker& checker;
  llvm::DenseMap<testshrinker::TreeNode<const antlr4::tree::ParseTree*>*, double> & nodesProbs;
  llvm::DenseMap<int, double> & typesProbs;
  llvm::DenseMap<int, bool> & checked;
  int initial_tree_size;
  bool& noTypesLeft;
  TimeoutGuard timer;
  using Count = uint32_t;

  TypeBatchedReducerImpl(AntlrGrammarInfo const& grammar,
                           antlr4::Parser& parser,
                           PropertyChecker& checker,
		           llvm::DenseMap<testshrinker::TreeNode<const antlr4::tree::ParseTree*>*, double> & nodesProbs,
		           llvm::DenseMap<int, double> & typesProbs,
                           llvm::DenseMap<int, bool> & checked,
                           int initial_tree_size,
                           bool & noTypesLeft)
: grammar{grammar},
parser{parser},
checker{checker},
nodesProbs{nodesProbs},
typesProbs{typesProbs},
checked{checked},
initial_tree_size{initial_tree_size},
noTypesLeft{noTypesLeft},
timer{}
{ }

template<typename E>
size_t
operator()(testshrinker::Tree<E>& tree, const size_t targetLevel = -1) {
    llvm::DenseMap<const TreeNode*,NodeRangeList<TreeNode>> subtreeMap;
    std::vector<int> next_types;
    // once you switch to Pardis, don't go back to types 
    auto current_tree_size = getSize(tree).nodes;
    if (!noTypesLeft) {
      updateTypeProbs(typesProbs, current_tree_size, initial_tree_size, checked);
      auto type_gain = getPotentialRemoval(tree, typesProbs, checked);
      std::vector<std::pair<double, int>> product_w_p;
      for (auto& elem: type_gain) {
        product_w_p.push_back(std::make_pair(elem.second, elem.first));
      }
      std::sort(product_w_p.begin(), product_w_p.end());
      std::reverse(product_w_p.begin(), product_w_p.end());

      auto pardis_benefit_cost = computeExpectedGainAndCostForPardis(tree, typesProbs);
      auto pardis_gain = pardis_benefit_cost.first/pardis_benefit_cost.second;
      if (!product_w_p.empty()) {
          if (product_w_p[0].first > pardis_gain) { 
            next_types.push_back(product_w_p[0].second);
            checked[product_w_p[0].second] = true;
         }
      }

   if (next_types.empty()) {
      subtreeMap = mapTreesToSimilarSubtrees(tree); 
      noTypesLeft = true;
    }
  }

    Worklist<E> worklist;
    Weight root_weight {0,0,0,0,0};
    worklist.push({tree.root, root_weight});
    auto processor = std::make_unique<ProbabilisticJointPolicy<E>>(tree, checker);
    while (!worklist.empty()) {
      if (timer.hasTimedOut()) {
        llvm::errs() << "TIMED OUT!\n";
        break;
      }
      processor->processWork(worklist, next_types, nodesProbs, subtreeMap);
    }
     return !processor->anyRemoved() ? -1 : 0;
  }

private:
  template <class E>
  using Node = typename testshrinker::Tree<E>::Node;

  using Weight = std::tuple<double, Count, Count, double, double>;
  
  template<typename E>
  struct Entry {
    Node<E>* node;
    Weight weight;
    bool operator<(Entry n2) const { return this->weight < n2.weight; }
  };

  template<typename E>
  using Worklist = std::priority_queue<Entry<E>>;

  template <typename E>
  class WorkPolicy {
  public:
    using ChildList = typename Node<E>::ChildList;
    const llvm::DenseMap<Node<E>*, Count> nodeOrder;
    const llvm::DenseMap<Node<E>*, Count> tokenWeight;

    explicit WorkPolicy(testshrinker::Tree<E>& tree, PropertyChecker& checker)
      : nodeOrder{computeBFSPosition(tree)},
        tokenWeight{computeTokensBelowNodes(tree)},
        tree{tree},
        checker{checker},
        removed{false}
        { }

    void
    remove(Node<E>* node) {
      node->eraseFromParent();
      removed = true;
    } 

    void
    processWork(Worklist<E>& worklist, std::vector<int> const & next_types, llvm::DenseMap<testshrinker::TreeNode<const antlr4::tree::ParseTree*>*, double> & nodesProbs, llvm::DenseMap<const TreeNode*,NodeRangeList<TreeNode>>& subtreeMap) {
      processWorkImpl(worklist, next_types, nodesProbs, subtreeMap);
    }


    bool anyRemoved() const noexcept { return removed; }

    void
    addWork(Worklist<E>& worklist, ChildList& newWork, llvm::DenseMap<testshrinker::TreeNode<const antlr4::tree::ParseTree*>*, double> & nodesProbs,  std::vector<int> const & next_types) {
      for (auto* node : newWork) {
        if (node) {
          worklist.push({node, this->makeWeight(node, nodesProbs, next_types)});
        }
      }
    }

   ChildList
   addNodeToWork(Node<E>* node) {
      ChildList newWork;
      newWork.push_back(node);
      return newWork;
   }

   int
   getTestOutcome(Node<E>* node) {
        llvm::SmallPtrSet<const Node<E>*,32> toSkip;
        toSkip.insert(node);
        auto remaining = getTokensSkipping(tree, toSkip);
        return checker("dummy", remaining);
    }

   int
   getTestOutcome(llvm::SmallVector<Node<E>*,12> nodes) {
          llvm::SmallPtrSet<const Node<E>*,32> toSkip;
          for (auto* node: nodes) {
             toSkip.insert(node);
          }
          auto remaining = getTokensSkipping(tree, toSkip);
          return checker("dummy", remaining);
   }

  bool
    removalSucceeds(Node<E>* node) {
      checker.setStrategy("Node");
      llvm::SmallPtrSet<const Node<E>*,32> toSkip;
      toSkip.insert(node);
      auto remaining = getTokensSkipping(tree, toSkip);
      return checker(remaining);
    }


      std::pair<bool, TreeNode*>
    replacementSucceeds(Node<E>* node, llvm::DenseMap<const TreeNode*,NodeRangeList<TreeNode>>& subtreeMap) {
         auto found = subtreeMap.find(node);
         if (found == subtreeMap.end()) {
          return std::make_pair(false, nullptr);
         }
         auto& replacements = found->second.first;
         auto replacement = std::find_if(replacements.begin(), replacements.end(),
         [&] (auto* descendent) {
             DenseMap<const TreeNode*,const TreeNode*> remap;
             remap[node] = descendent;
             auto leaves = tree.root->getLeavesReplacing(remap);
             auto tokens = getTokens(leaves);
             return checker(tokens);
           });
          if (replacement == replacements.end()) {
              return std::make_pair(false, nullptr);
          }
           return std::make_pair(true, *replacement);
    }



  private:
    testshrinker::Tree<E>& tree;
    PropertyChecker& checker;
    bool removed;

    virtual void processWorkImpl(Worklist<E>& worklist,  std::vector<int> const & next_types, llvm::DenseMap<testshrinker::TreeNode<const antlr4::tree::ParseTree*>*, double> & nodesProbs, llvm::DenseMap<const TreeNode*,NodeRangeList<TreeNode>>& subtreeMap) = 0;
    virtual Weight makeWeight(Node<E>* node, llvm::DenseMap<testshrinker::TreeNode<const antlr4::tree::ParseTree*>*, double> & nodesProbs,  std::vector<int> const & next_types) = 0;
  };

template <typename E>
  class ProbabilisticJointPolicy : public WorkPolicy<E> {
  public:
    ProbabilisticJointPolicy(testshrinker::Tree<E>& tree, PropertyChecker& checker)
      : WorkPolicy<E>{tree, checker},
        accum_weight{0},
        prob{1},
        gain{0}
        { }

  private:
    double accum_weight;
    double prob;
    double gain;

    void
    processWorkImpl(Worklist<E>& worklist,  std::vector<int> const & next_types, llvm::DenseMap<testshrinker::TreeNode<const antlr4::tree::ParseTree*>*, double> & nodesProbs, llvm::DenseMap<const TreeNode*,NodeRangeList<TreeNode>>& subtreeMap) override {
   if (!next_types.empty()) {
      llvm::SmallVector<Node<E>*,12>  nodes;
      while (true) {
        if (worklist.empty()) {
           break;
        }
        auto work = worklist.top();
        worklist.pop();
        if (!work.node->isNullable()) {
           this->addWork(worklist, work.node->getChildren(), nodesProbs, next_types);
        }
        else {
          auto leaves = work.node->getLeavesWhen([] (auto&, auto&) {return true; });
          auto tokens = getTokens(leaves);
          if (leaves.empty() || tokens.empty()) {
            continue;
          }
          if (!getRuleIndex(work.node->getElement()).first || std::find(next_types.begin(), next_types.end(), getRuleIndex(work.node->getElement()).second) == next_types.end()) {
            this->addWork(worklist, work.node->getChildren(), nodesProbs, next_types);
            continue;
          }
          auto success_prob = std::get<3>(work.weight);
          auto remain_prob = std::get<4>(work.weight);
          if (remain_prob == 0.99) {
            this->addWork(worklist, work.node->getChildren(), nodesProbs, next_types);
            continue;
          }
          auto node_weight = std::get<1>(work.weight);
          this->prob *= success_prob;
          this->accum_weight += node_weight;
          auto value = this->prob * this->accum_weight;
          if (value < this->gain) {
              worklist.push(work);
              this->gain = 0;
              this->prob = 1;
              this->accum_weight = 0;
              break;
           }
           this->gain = value;
           nodes.push_back(work.node);
        }
   }
   if (!nodes.empty()) {
        auto outcome = this->getTestOutcome(nodes);
        if (outcome == 1) {
           for (auto* node: nodes) {
             this->remove(node);
           }
        }
        else {
            if (nodes.size() == 1) {
                if (outcome == 3) {
                   nodesProbs[nodes.front()] = 0.99;
                }
                this->addWork(worklist, nodes.front()->getChildren(), nodesProbs, next_types);
            }
            else {
                llvm::DenseMap<Node<E>*, double> nodesProbsOriginal;
                for (auto* node: nodes) {
                   nodesProbsOriginal[node] = nodesProbs.lookup(node);
                }
                std::for_each(nodes.begin(), nodes.end(), [&] (auto* node) {
                                                                             auto other_nodes = nodes;
                                                                             double val = 1;
                                                                             std::for_each(other_nodes.begin(), other_nodes.end(), [&] (auto * other_node) {
                                                                               val *= (1 - nodesProbsOriginal.lookup(other_node));
                                                                              });
                                                                             auto new_prob = nodesProbs.lookup(node)/ (1 - val);
                                                                             nodesProbs[node] =  new_prob;
                });
                for (auto* node: nodes) {
                   auto newWork = this->addNodeToWork(node);
                   this->addWork(worklist, newWork, nodesProbs, next_types);
                }
            }
        }
    }
}
// clean-up phase
 else {
     auto work = worklist.top();
     worklist.pop();
     if (work.node->isNullable()) {
        auto outcome = this->getTestOutcome(work.node);
        if(outcome == 1) {
          this->remove(work.node);
        }
        else {
            this->addWork(worklist, work.node->getChildren(), nodesProbs, next_types);
        }
    }
    else {
          auto replacementTest = this->replacementSucceeds(work.node, subtreeMap);
          if (replacementTest.first) {
               auto replacement = replacementTest.second;
               replaceWith(*(work.node), *(replacement));
                auto new_node = this->addNodeToWork(replacement);
                this->addWork(worklist, new_node, nodesProbs, next_types);
           }
          else {
           this->addWork(worklist, work.node->getChildren(), nodesProbs, next_types);
          }
    }
}

}

 Weight
    makeWeight(Node<E>* node, llvm::DenseMap<testshrinker::TreeNode<const antlr4::tree::ParseTree*>*, double> & nodesProbs,  std::vector<int> const & next_types) override {
      if (next_types.empty()) {
         return Weight{this->tokenWeight.lookup(node), this->nodeOrder.lookup(node), 0, 0, 0};
     }
      else {
        auto remain_prob = nodesProbs.lookup(node);
        auto remove_prob = 1 - remain_prob;
        return Weight{remove_prob * this->tokenWeight.lookup(node), this->tokenWeight.lookup(node),
                    this->nodeOrder.lookup(node), remove_prob, remain_prob};
      }
    }
 };
};

template <typename Reducer, typename E>
size_t
runToFixedPoint(SourceReducer::Listener& listener,
                Reducer& reducer,
                testshrinker::Tree<E>& tree,
                size_t targetLevel = -1) {
  size_t lastLevelChanged = -1;
  size_t maxLevelChanged = -1;
  while (true) {
    lastLevelChanged = reducer(tree, lastLevelChanged);
    listener.printProgressReport(tree);
    if (lastLevelChanged == static_cast<size_t>(-1)) {
      break;
    } else if (lastLevelChanged > maxLevelChanged
        || maxLevelChanged == static_cast<size_t>(-1)) {
      maxLevelChanged = lastLevelChanged;
    }
  }
  return maxLevelChanged;
}

template <typename Reducer, typename E>
size_t
runToFixedPointTypeVersion(SourceReducer::Listener& listener,
                Reducer& reducer,
                testshrinker::Tree<E>& tree,
                bool & noTypesLeft,
                size_t targetLevel = -1) {
  size_t lastLevelChanged = -1;
  size_t maxLevelChanged = -1;
  while (true) {
    lastLevelChanged = reducer(tree, lastLevelChanged);
    listener.printProgressReport(tree);
    if (lastLevelChanged == static_cast<size_t>(-1) && noTypesLeft) {
      break;
    } else if (lastLevelChanged > maxLevelChanged
        || maxLevelChanged == static_cast<size_t>(-1)) {
      maxLevelChanged = lastLevelChanged;
    }
  }
  return maxLevelChanged;
}

void
TraversalBasedFixpointReducer::reduce(ShrinkerTree& tree,
                                          antlr4::Parser& parser,
                                          AntlrGrammarInfo const& grammar) {
  auto checker  = PropertyChecker{listener, propertyChecker, grammar, tree};

  using Reducer = TraversalBasedReducerImpl;
  auto reducer  = Reducer{grammar, parser, checker};

  runToFixedPoint(listener, reducer, tree);

  auto tokens = getTokens(tree);
  grammar.print(out, tokens);
  out << "\n";
}


template<class E>
static llvm::DenseMap<typename testshrinker::Tree<E>::Node*, double>
setNodeInitialProbabilities(testshrinker::Tree<E>& tree) {
  using Node = typename testshrinker::Tree<E>::Node;
  llvm::DenseMap<Node*, double> probs;
  auto compute = [&] (Node* node) -> void {
         probs[node] = 0.01;
};
  tree.visitPostorder(compute);
  return probs ;
}

llvm::DenseMap<int, double>
setPriorProbsC() {
  llvm::DenseMap<int, double> probs;
  probs[93] = 1;
  probs[92] = 1;
  probs[105] = 1;
  probs[111] = 1;
  probs[114] = 1;
  probs[117] = 1;
  probs[99] = 1;

  probs[200] = -1;
  probs[159] = -1;
  probs[201] = -1;
  probs[90] = -1;
  probs[145] = -1;
  probs[136] = -1;
  probs[197] = -1;
  probs[144] = -1;
  probs[120] = -1;
  probs[108] = -1;
  probs[157] = -1;
  probs[89] = -1;
  probs[84] = -1;
  probs[123] = -1;
  probs[135] = -1;
  probs[156] = -1;
  probs[125] = -1;
  probs[126] = -1;

return probs;

}

 llvm::DenseMap<int, double>
setPriorProbsRust() {
  llvm::DenseMap<int, double> probs;
   probs[457] = 1;
probs[298] = 1;
probs[187] = 1;
probs[344] = 1;
probs[364] = 1;
probs[251] = 1;
probs[294] = 1;
probs[397] = 1;
probs[179] = 1;
probs[400] = 1;
probs[537] = 1;
probs[388] = 1;
probs[415] = 1;
probs[418] = 1;
probs[444] = 1;
probs[336] = 1;
probs[365] = 1;
probs[259] = 1;
probs[335] = 1;
probs[396] = 1;


probs[127] = -1;
probs[562] = -1;
probs[333] = -1;
probs[4] = -1;
probs[232] = -1;
probs[182] = -1;
probs[254] = -1;
probs[228] = -1;
probs[391] = -1;
probs[224] = -1;
probs[317] = -1;
probs[350] = -1;
probs[190] = -1;
probs[268] = -1;
probs[332] = -1;
probs[539] = -1;
probs[194] = -1;
probs[222] = -1;
probs[197] = -1;
probs[301] = -1;
probs[245] = -1;
probs[242] = -1;
probs[334] = -1;
probs[227] = -1;
probs[175] = -1;
probs[178] = -1;
probs[279] = -1;
probs[191] = -1;
probs[300] = -1;
probs[62] = -1;
probs[343] = -1;
probs[64] = -1;
probs[270] = -1;
probs[349] = -1;
probs[63] = -1;
probs[176] = -1;
probs[258] = -1;
probs[195] = -1;
probs[183] = -1;
probs[543] = -1;
probs[469] = -1;
probs[363] = -1;
probs[331] = -1;
probs[60] = -1;
probs[185] = -1;
probs[330] = -1;
probs[208] = -1;
probs[196] = -1;
probs[465] = -1;
probs[210] = -1;
probs[249] = -1;
probs[233] = -1;
probs[237] = -1;
probs[248] = -1;
probs[199] = -1;
probs[275] = -1;
probs[221] = -1;
probs[374] = -1;
probs[184] = -1;
probs[453] = -1;
probs[394] = -1;
probs[231] = -1;
probs[255] = -1;
probs[296] = -1;
probs[262] = -1;
probs[273] = -1;
probs[305] = -1;
probs[455] = -1;
probs[373] = -1;
probs[56] = -1;
probs[220] = -1;
probs[209] = -1;
probs[352] = -1;
probs[181] = -1;
probs[186] = -1;
probs[449] = -1;
probs[240] = -1;
probs[238] = -1;

  return probs;
 }
  
llvm::DenseMap<int, double>
setPriorProbsGo() {
  llvm::DenseMap<int, double> probs;
 probs[146] = 1;
 probs[147] = 1;
 probs[148] = 1;
 probs[121] = 1;
 
 probs[133] = -1;
probs[112] = -1;
probs[131] = -1;
probs[158] = -1;
probs[160] = -1;
probs[122] = -1;
probs[141] = -1;
probs[142] = -1;
probs[134] = -1;
probs[102] = -1;
probs[103] = -1;
probs[162] = -1;
probs[89] = -1;
probs[143] = -1;
probs[115] = -1;
probs[184] = -1;
probs[163] = -1;
return probs;
 
}


  llvm::DenseMap<int, double> 
  setTypeProbs() {
      switch (languageOpt) {
        case Language::C:
           return setPriorProbsC();
        case Language::RUST:
          return setPriorProbsRust();
        case Language::GO:
          return setPriorProbsGo();
    }
    llvm_unreachable("Invalid language domain!");
  }



void
TypeBatchedFixpointReducer::reduce(ShrinkerTree& tree, antlr4::Parser& parser, AntlrGrammarInfo const& grammar) {
  
    auto checker  = PropertyChecker{listener, propertyChecker, grammar, tree};
    auto nodesProbs = setNodeInitialProbabilities(tree);
    auto typesProbs = setTypeProbs();
  llvm::DenseMap<int, bool> checked;
    for (auto& elem: typesProbs) {
       checked[elem.first] = false;
    }
    auto initial_tree_size = getSize(tree).nodes;
    bool noTypesLeft = false;
    using Reducer = TypeBatchedReducerImpl;
    auto reducer  = Reducer{grammar, parser, checker, nodesProbs, typesProbs, checked, initial_tree_size, noTypesLeft};
    runToFixedPointTypeVersion(listener, reducer, tree, noTypesLeft);
    auto tokens = getTokens(tree);
    grammar.print(out, tokens);
    out << "\n";
    
}

