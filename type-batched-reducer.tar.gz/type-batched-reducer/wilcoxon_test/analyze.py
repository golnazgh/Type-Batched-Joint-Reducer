#!/usr/bin/env python3

import scipy.stats as st
import pandas as pd

TARGET_ALPHA = 0.05
BONFERRONI_FACTOR = 8

# NOTE:
# The direction captures whether we are interested in the batched approach
# being 'greater' or 'less' than the existing approaches in the alternative
# hypothesis (or two-sided).
def analyze_column(filename: str, name: str, direction: str):
    df = pd.read_csv(filename)

    perses = df.loc[df['Reducer'] == 'Perses'][name].to_list()
    pardis = df.loc[df['Reducer'] == 'Pardis'][name].to_list()
    batched = df.loc[df['Reducer'] == 'Batched'][name].to_list()

    batched_v_perses = st.wilcoxon(x=batched, y=perses, alternative=direction)
    batched_v_pardis = st.wilcoxon(x=batched, y=pardis, alternative=direction)

    print('Results for', name)
    print('vs perses:', batched_v_perses)
    print('vs pardis:', batched_v_pardis)
    print()

if __name__ == '__main__':
    analyze_column('rates.csv', 'Rate', 'greater')
    analyze_column('size.csv', 'Tokens', 'two-sided')
    analyze_column('time.csv', 'Time', 'less')
    analyze_column('queries.csv', 'Queries', 'less')

    print('Original target alpha:', TARGET_ALPHA)
    print('Bonferroni correction yields alpha: ', TARGET_ALPHA / BONFERRONI_FACTOR)
