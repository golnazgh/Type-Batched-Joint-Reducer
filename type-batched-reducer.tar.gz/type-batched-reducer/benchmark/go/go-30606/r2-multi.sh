#!/usr/bin/env bash

set -o pipefail
set -o nounset
set -o errexit
GO_COMPILER=/home/LocalInstallations/go-versions/go1.12/go/bin/go

export GOCACHE=$(mktemp -d)
trap "{ rm ${GOCACHE} -rf; }" EXIT

OUTPUT=$($GO_COMPILER build $1 2>&1)
RES=$?
# compile time issue
if [[ $RES -ne 0 ]]; then
  exit 4;
fi

($GO_COMPILER run $1 || true) 2>&1 | grep -P "signal SIGSEGV"
