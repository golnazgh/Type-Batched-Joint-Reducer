#!/usr/bin/env bash
rm -f file.go
GO_COMPILER=/home/LocalInstallations/go-versions/go1.11/go/bin/go
value=`cat $1`
echo "$value" > file.go
($GO_COMPILER fmt file.go)
OUTPUT=$(/home/benchmark/go/go-29220/r2.sh file.go)
RESULT=$?

if [[ $RESULT -eq 4 ]]; then
  exit 0;
fi

if [[ $RESULT -eq 0 ]]; then
  exit 1;
fi

 exit 3;



