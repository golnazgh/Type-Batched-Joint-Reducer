#!/usr/bin/env bash

GO_COMPILER=/home/LocalInstallations/go-versions/go1.11/go/bin/go

set -o pipefail
set -o nounset
set -o errexit

export GOCACHE=$(mktemp -d)
trap "{ rm ${GOCACHE} -rf; }" EXIT

OUTPUT=$($GO_COMPILER build $1 2>&1)
RES=$?
# compile time issue
if [[ $RES -ne 0 ]]; then
  exit 4;
fi

($GO_COMPILER build -o /dev/null $1 || true) 2>&1 | grep "internal compiler error"
