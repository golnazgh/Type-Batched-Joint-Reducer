#!/usr/bin/env bash

set -o pipefail
set -o nounset
set -o errexit

export GOCACHE=$(mktemp -d)
trap "{ rm ${GOCACHE} -rf; }" EXIT
GO_COMPILER=/home/LocalInstallations/go-versions/go-a361ef36af/bin/go
$GO_COMPILER version | grep "+a361ef3"

OUTPUT=$($GO_COMPILER build $1 2>&1)
RES=$?
# compile time issue
if [[ $RES -ne 0 ]]; then
  exit 4;
fi

($GO_COMPILER run $1 || true) 2>&1 | grep "signal SIGSEGV"
