#!/usr/bin/env bash

set -o pipefail
set -o nounset
GCC_4_9=/home/LocalInstallations/gcc-4.9.0/bin/gcc
WHICH=0     # 0: gcc; 1: clang
GOODCOMP=0  # 0: doesn't compile; 1: compiles
BADCC=("$GCC_4_9 -O3 -x c")
GOODCC=("gcc -x c")
CFILE=$1
TIMEOUTCC=30

rm -f out*.txt


for cc in "${GOODCC[@]}" ; do
  rm -f ./t ./out1.txt
  
  (timeout -s 9 $TIMEOUTCC $cc $CFILE > out1.txt 2>&1) >& /dev/null
  ret=$?
  
  if [ $GOODCOMP -eq 1 ] ; then # does compile
    if [ $ret -ne 0 ] ; then
      exit 0;
    fi
  else # does not compile, so make sure it doesn't ICE
    if grep 'internal compiler error: ' out1.txt ||\
    grep 'PLEASE ATTACH THE FOLLOWING FILES TO THE BUG REPORT' out1.txt
    then
      exit 2;
    fi
  fi
done


for cc in "${BADCC[@]}" ; do
  rm -f ./t ./out2.txt
  
  (timeout -s 9 $TIMEOUTCC $cc $CFILE > out2.txt 2>&1) >& /dev/null
  
  if [ $WHICH -eq 1 ] ; then # clang
    if ! grep 'PLEASE ATTACH THE FOLLOWING FILES TO THE BUG REPORT' out2.txt ||\
    ! grep 'The annotation should be until the most recent cached token' out2.txt ||\
    grep ':[0-9]*: error: ' out2.txt | grep -E -v 'error: expected'  #conflicting|error: declaration|error: variable'
    then
      exit 3;
    fi
  else # gcc
    if ! grep 'internal compiler error: in output_constant_pool_2' out2.txt 
    then
      exit 3;
    fi
  fi
done

rm -f /tmp/*.c
rm -f /tmp/*.sh

exit 1;
