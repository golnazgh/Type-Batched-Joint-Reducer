#!/usr/bin/env bash

readonly WHICH=0
readonly GOODCOMP=0
GCC_5_1=/home/LocalInstallations/gcc-5.1.0/bin/gcc
BADCC=("$GCC_5_1 -c -O3 -x c")
GOODCC=("gcc-4.8 -x c")
CFILE=$1


set -o pipefail
set -o nounset

readonly TIMEOUTCC=5
readonly CFLAG=""
rm -f out*.txt

readonly INDENT_TEMP_OUTPUT="temp.indent.output.tmp"
if ! indent ${CFILE} -o ${INDENT_TEMP_OUTPUT} ; then 
  exit 2;
fi





for cc in "${GOODCC[@]}" ; do
  rm -f ./t ./out1.txt
  
  (timeout -s 9 $TIMEOUTCC $cc $CFLAG $CFILE > out1.txt 2>&1) >& /dev/null
  ret=$?
  
  if [ $GOODCOMP -eq 1 ] ; then # does compile
    if [ $ret -ne 0 ] ; then
      exit 0;
    fi
  else # does not compile, so make sure it doesn't ICE
    if grep 'internal compiler error: ' out1.txt ||\
    grep 'PLEASE ATTACH THE FOLLOWING FILES TO THE BUG REPORT' out1.txt
    then
      exit 2;
    fi
  fi
done


for cc in "${BADCC[@]}" ; do
  rm -f ./t ./out2.txt
  
  (timeout -s 9 $TIMEOUTCC $cc $CFILE > out2.txt 2>&1) >& /dev/null
  
  if [ $WHICH -eq 1 ] ; then # clang
    if ! grep 'PLEASE ATTACH THE FOLLOWING FILES TO THE BUG REPORT' out2.txt ||\
       ! grep "${ICE_MSG}" out2.txt 
    then
      exit 3;
    fi
  elif [ $WHICH -eq 0 ] ; then  # gcc
    if ! grep 'internal compiler error: ' out2.txt 

    then
      exit 3;
    fi
  elif [ $WHICH -eq 2 ] ; then # CompCert
    if ! grep "Fatal error: " out2.txt || \
       ! grep "${ICE_MSG}" out2.txt  
    then 
       exit 3;
    fi   
  else 
    echo "the variable WHICH is not defined"
    exit 2;
  fi
done
rm -f /tmp/*.c
rm -f /tmp/*.sh

exit 1;
