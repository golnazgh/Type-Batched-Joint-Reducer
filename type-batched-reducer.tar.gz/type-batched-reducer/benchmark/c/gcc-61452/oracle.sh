#!/bin/bash

GCC_4_9=/home/LocalInstallations/gcc-4.9.0/bin/gcc

BADCC1=("$GCC_4_9 -m64 -Os -x c")  # compilation failures
BADCC2=() # exec failures 
BADCC3=() # wrong results 
GOODCC=("$GCC_4_9 -m64 -O2 -x c")
TIMEOUTCCBAD=5
TIMEOUTCCGOOD=6
TIMEOUTEXE=2
CFILE=$1
CFLAG="-o t"
CLANGFC="clang -O0 -x c -Wall -fwrapv -ftrapv -fsanitize=undefined"

rm -f out*.txt 

if 
  clang -pedantic -Wall -Wsystem-headers -O0 -x c $CFILE  >out.txt 2>&1 &&\
  ! grep 'conversions than data arguments' out.txt &&\
  ! grep 'ordered comparison between pointer' out.txt &&\
  ! grep 'eliding middle term' out.txt &&\
  ! grep 'end of non-void function' out.txt &&\
  ! grep 'invalid in C99' out.txt &&\
  ! grep 'specifies type' out.txt &&\
  ! grep 'should return a value' out.txt &&\
  ! grep 'incompatible pointer to' out.txt &&\
  ! grep 'incompatible integer to' out.txt &&\
  ! grep 'type specifier missing' out.txt &&\
  gcc -Wall -Wextra -Wsystem-headers -O0 -x c $CFILE >outa.txt 2>&1 &&\
  ! grep 'division by zero' outa.txt &&\
  ! grep 'without a cast' outa.txt &&\
  ! grep 'control reaches end' outa.txt &&\
  ! grep 'return type defaults' outa.txt &&\
  ! grep 'cast from pointer to integer' outa.txt &&\
  ! grep 'useless type name in empty declaration' outa.txt &&\
  ! grep 'no semicolon at end' outa.txt &&\
  ! grep 'type defaults to' outa.txt &&\
  ! grep 'too few arguments for format' outa.txt &&\
  ! grep 'incompatible pointer' outa.txt &&\
  ! grep 'ordered comparison of pointer with integer' outa.txt &&\
  ! grep 'declaration does not declare anything' outa.txt &&\
  ! grep 'expects type' outa.txt &&\
  ! grep 'pointer from integer' outa.txt &&\
  ! grep 'incompatible implicit' outa.txt &&\
  ! grep 'excess elements in struct initializer' outa.txt &&\
  ! grep 'return type of \‘main\’ is not \‘int\’' outa.txt &&\
  ! grep 'comparison between pointer and integer' outa.txt #&&\
then 
    : # do nothing 
else 
    exit 0;
fi 


rm -f ./t ./out*.txt 
timeout -s 9 $TIMEOUTCCGOOD $CLANGFC $CFLAG $CFILE >& /dev/null
ret=$? 

if [ $ret != 0 ] ; then 
    exit 0; 
fi 

(timeout -s 9 $TIMEOUTEXE ./t >out0.txt 2>&1) >&/dev/null
ret=$? 

if [ $ret != 0 ] ; then 
    exit 2; 
fi 

if grep -q "runtime error" out0.txt ; then 
    exit 2;
fi 



for cc in "${GOODCC[@]}" ; do 
    rm -f ./t ./out1.txt 

    timeout -s 9 $TIMEOUTCCGOOD $cc $CFLAG $CFILE >& /dev/null
    ret=$? 
    if [ $ret != 0 ] ; then 
	exit 0; 
    fi

    (timeout -s 9 $TIMEOUTEXE ./t >out1.txt 2>&1) >&/dev/null
    ret=$? 
    if [ $ret != 0 ] ; then 
	exit 2; 
    fi 
    
    if ! diff -q out0.txt out1.txt >/dev/null ; then
	exit 2;
    fi    
done


for cc in "${BADCC1[@]}" ; do 
    rm -f ./t ./out2.txt 

    (timeout -s 9 $TIMEOUTCCBAD $cc $CFLAG $CFILE > out2.txt 2>&1) >& /dev/null
    ret=$? 
    if [ $ret -ne 137 ] ; then 
	exit 3;
    fi
done

for cc in "${BADCC2[@]}" ; do 
    rm -f ./t ./out2.txt 

    timeout -s 9 $TIMEOUTCC $cc $CFLAG $CFILE >& /dev/null
    ret=$? 
    if [ $ret -ne 0 ] ; then 
	exit 0;
    fi

    (timeout -s 9 $TIMEOUTEXE ./t >out2.txt 2>&1) >&/dev/null
    ret=$? 
    if [ $ret -ne 137 ] ; then 
	exit 3;
    fi 
done

for cc in "${BADCC3[@]}" ; do 
    rm -f ./t ./out2.txt 

    timeout -s 9 $TIMEOUTCC $cc $CFLAG $CFILE >& /dev/null
    ret=$? 
    if [ $ret != 0 ] ; then 
	exit 0;
    fi

    (timeout -s 9 $TIMEOUTEXE ./t >out2.txt 2>&1) >&/dev/null
    ret=$? 
    if [ $ret != 0 ] ; then 
	exit 2;
    fi 
    
    if diff -q out0.txt out2.txt >/dev/null ; then
	exit 3;
    fi    
done

rm -f /tmp/*.c
rm -f /tmp/*.sh

exit 1;
