#!/bin/bash

CLANG_3_8=/home/LocalInstallations/clang+llvm-3.8.0-x86_64-linux-gnu-ubuntu-16.04/bin/clang
BADCC1=()
BADCC2=()
BADCC3=("$CLANG_3_8 -Os -x c")
MODE=("-m32")


readonly GOODCC=("gcc -O0 -x c" "clang -m32 -O1 -x c")
readonly TIMEOUTCC=20
readonly TIMEOUTEXE=2
readonly CFILE=$1
readonly CFLAG="-o t"
readonly CLANGFC="clang -w -m64 -O0 -x c -Wall -fwrapv -ftrapv -fsanitize=undefined,address"
readonly CLANG_MEM_SANITIZER="clang -w -O0 -m64 -fsanitize=memory"


rm -f out*.txt

if
clang -Wfatal-errors -pedantic -Wall -Wsystem-headers -O0 -x c $CFILE  >out.txt 2>&1 &&\
! grep -q 'conversions than data arguments' out.txt &&\
! grep -q 'incompatible redeclaration' out.txt &&\
! grep -q 'ordered comparison between pointer' out.txt &&\
! grep -q 'eliding middle term' out.txt &&\
! grep -q 'invalid in C99' out.txt &&\
! grep -q 'specifies type' out.txt &&\
! grep -q 'should return a value' out.txt &&\
! grep -q 'incompatible pointer to' out.txt &&\
! grep -q 'incompatible integer to' out.txt &&\
! grep -q 'type specifier missing' out.txt &&\
gcc -Wfatal-errors -Wall -Wextra -Wsystem-headers -O0 -x c $CFILE >outa.txt 2>&1 &&\
! grep -q 'division by zero' outa.txt &&\
! grep -q 'without a cast' outa.txt &&\
! grep -q 'return type defaults' outa.txt &&\
! grep -q 'cast from pointer to integer' outa.txt &&\
! grep -q 'useless type name in empty declaration' outa.txt &&\
! grep -q 'no semicolon at end' outa.txt &&\
! grep -q 'type defaults to' outa.txt &&\
! grep -q 'too few arguments for format' outa.txt &&\
! grep -q 'incompatible pointer' outa.txt &&\
! grep -q 'ordered comparison of pointer with integer' outa.txt &&\
! grep -q 'declaration does not declare anything' outa.txt &&\
! grep -q 'expects type' outa.txt &&\
! grep -q 'pointer from integer' outa.txt &&\
! grep -q 'excess elements in struct initializer' outa.txt &&\
! grep -q 'return type of \‘main\’ is not \‘int\’' outa.txt &&\
! grep -q 'comparison between pointer and integer' outa.txt #&&\
then
  : # do nothing
else
  exit 0;
fi



rm -f ./t ./out*.txt
timeout -s 9 $TIMEOUTCC $CLANGFC $CFLAG -x c $CFILE > /dev/null
ret=$?

if [ $ret != 0 ] ; then
  exit 0;
fi

(timeout -s 9 $TIMEOUTEXE ./t >out0.txt 2>&1) >&/dev/null
ret=$?

if [ $ret != 0 ] ; then
  exit 2;
fi

if grep -q "runtime error" out0.txt ; then
  exit 2;
fi

for ((i=0; i < ${#GOODCC[@]} ; ++i )) ; do
  cc=${GOODCC[$i]}
  rm -f ./t ./out1.txt
  
  timeout -s 9 $TIMEOUTCC $cc $CFLAG -x c $CFILE >& /dev/null
  ret=$?
  if [ $ret != 0 ] ; then
    exit 0;
  fi
  
  (timeout -s 9 $TIMEOUTEXE ./t >out1.txt 2>&1) >&/dev/null
  ret=$?
  if [ $ret != 0 ] ; then
    exit 2;
  fi

  if [[ "$i" == 0 ]] ; then 
    mv out1.txt out0.txt
    continue
  fi
  
  if ! diff -q out0.txt out1.txt >/dev/null ; then
    exit 2;
  fi
done


for cc in "${BADCC1[@]}" ; do
  for mode in "${MODE[@]}" ; do
    rm -f ./t ./out2.txt
    
    (timeout -s 9 $TIMEOUTCC $cc $CFLAG $mode -x c $CFILE >out2.txt 2>&1) >& /dev/null
    if ! grep -q 'internal compiler error' out2.txt && \
    ! grep -q 'PLEASE ATTACH THE FOLLOWING FILES TO THE BUG REPORT' out2.txt && \
    ! grep -q 'clang: error: linker command failed with exit code 1 (use -v to see invocation)' out2.txt 
    then
      exit 3;
    fi
  done
done

for cc in "${BADCC2[@]}" ; do
  for mode in "${MODE[@]}" ; do
    rm -f ./t ./out2.txt
    
    timeout -s 9 $TIMEOUTCC $cc $CFLAG $mode -x c $CFILE >& /dev/null
    ret=$?
    if [ $ret -ne 0 ] ; then
      exit 0;
    fi
    
    (timeout -s 9 $TIMEOUTEXE ./t >out2.txt 2>&1) >&/dev/null
    ret=$?
    if [ $ret -ne 137 ] ; then
      exit 3;
    fi
  done
done

for cc in "${BADCC3[@]}" ; do
  for mode in "${MODE[@]}" ; do
    rm -f ./t ./out2.txt
    
    timeout -s 9 $TIMEOUTCC $cc $CFLAG $mode -x c $CFILE >& /dev/null
    ret=$?
    if [ $ret != 0 ] ; then
      exit 0;
    fi
    
    (timeout -s 9 $TIMEOUTEXE ./t >out2.txt 2>&1) >&/dev/null
    ret=$?
    if [ $ret != 0 ] ; then
      exit 2;
    fi
    
    if diff -q out0.txt out2.txt >/dev/null ; then
      exit 3;
    fi
  done
done

readonly TEMP_EXE="temp.exe"
timeout -s 9 $TIMEOUTCC $CLANG_MEM_SANITIZER -x c $CFILE -o $TEMP_EXE > /dev/null
if [[ $? != 0 ]] ; then
  rm -f /tmp/*.c
  rm -f /tmp/*.sh
  exit 0;
fi

readonly MEM_SANITIZER_OUTPUT="mem-sanitizer.output"
(timeout -s 9 $TIMEOUTEXE ./$TEMP_EXE &> $MEM_SANITIZER_OUTPUT ) &> /dev/null
if [[ $? != 0 ]] ; then
  rm -f /tmp/*.c
  rm -f /tmp/*.sh
  rm $MEM_SANITIZER_OUTPUT
  rm $TEMP_EXE
  exit 2;
fi
rm $MEM_SANITIZER_OUTPUT
rm $TEMP_EXE
rm -f /tmp/*.c
rm -f /tmp/*.sh

exit 1;
