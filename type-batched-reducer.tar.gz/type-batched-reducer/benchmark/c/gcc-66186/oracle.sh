#!/bin/bash

BADCC1=()
BADCC2=()
BADCC3=("gcc-4.9 -O3 -x c")
MODE=("-m64")
CLANG_3_6=/home/LocalInstallations/clang+llvm-3.6.0-x86_64-linux-gnu/bin/clang

GOODCC=("gcc -x c")
TIMEOUTCC=10
TIMEOUTEXE=2
CFILE=$1
CFLAG="-o t"
CLANGFC="$CLANG_3_6 -m64 -O0 -x c -Wall -fwrapv -ftrapv -fsanitize=undefined,address -fno-common"
readonly CLANG_MEM_SANITIZER="clang -w -O0 -fsanitize=memory"

rm -f out*.txt 

if 
  clang -pedantic -Wall -Wsystem-headers -O0 -x c $CFILE  >out.txt 2>&1 &&\
  ! grep 'conversions than data arguments' out.txt &&\
  ! grep 'incompatible redeclaration' out.txt &&\
  ! grep 'ordered comparison between pointer' out.txt &&\
  ! grep 'eliding middle term' out.txt &&\
  ! grep 'end of non-void function' out.txt &&\
  ! grep 'invalid in C99' out.txt &&\
  ! grep 'specifies type' out.txt &&\
  ! grep 'should return a value' out.txt &&\
  ! grep 'incompatible pointer to' out.txt &&\
  ! grep 'incompatible integer to' out.txt &&\
  ! grep 'type specifier missing' out.txt &&\
  ! grep 'will always evaluate to' out.txt &&\
  gcc -Wall -Wextra -Wsystem-headers -O0 -x c $CFILE >outa.txt 2>&1 &&\
  ! grep 'division by zero' outa.txt &&\
  ! grep 'without a cast' outa.txt &&\
  ! grep 'control reaches end' outa.txt &&\
  ! grep 'return type defaults' outa.txt &&\
  ! grep 'cast from pointer to integer' outa.txt &&\
  ! grep 'useless type name in empty declaration' outa.txt &&\
  ! grep 'no semicolon at end' outa.txt &&\
  ! grep 'type defaults to' outa.txt &&\
  ! grep 'too few arguments for format' outa.txt &&\
  ! grep 'incompatible pointer' outa.txt &&\
  ! grep 'ordered comparison of pointer with integer' outa.txt &&\
  ! grep 'declaration does not declare anything' outa.txt &&\
  ! grep 'expects type' outa.txt &&\
  ! grep 'pointer from integer' outa.txt &&\
  ! grep 'excess elements in struct initializer' outa.txt &&\
  ! grep 'return type of \‘main\’ is not \‘int\’' outa.txt &&\
  ! grep 'comparison between pointer and integer' outa.txt #&&\

then 
    : # do nothing 
else
   
    rm -f /tmp/*.c
    rm -f /tmp/*.sh
    exit 0;
fi 


rm -f ./t ./out*.txt 
OUTPUT=$(timeout -s 9 $TIMEOUTCC $CLANGFC $CFLAG -m64 -x c $CFILE >& /dev/null)
ret=$? 

if [ $ret != 0 ] ; then 
    rm -f /tmp/*.c
    rm -f /tmp/*.sh
    exit 0;
fi 

(timeout -s 9 $TIMEOUTEXE ./t >out0.txt 2>&1) >&/dev/null
ret=$? 

if [ $ret != 0 ] ; then 
    rm -f /tmp/*.c
    rm -f /tmp/*.sh
    exit 2;
fi 

if grep -q "runtime error" out0.txt ; then 
    rm -f /tmp/*.c
    rm -f /tmp/*.sh
    exit 2;
fi 


for cc in "${GOODCC[@]}" ; do 
    rm -f ./t ./out1.txt 

    timeout -s 9 $TIMEOUTCC $cc $CFLAG -x c $CFILE >& /dev/null
    ret=$? 
    if [ $ret != 0 ] ; then 
        rm -f /tmp/*.c
        rm -f /tmp/*.sh
	exit 0;
    fi

    (timeout -s 9 $TIMEOUTEXE ./t >out1.txt 2>&1) >&/dev/null
    ret=$? 
    if [ $ret != 0 ] ; then 
        rm -f /tmp/*.c
        rm -f /tmp/*.sh
	exit 2;
    fi 
    
   
    if ! diff -q out0.txt out1.txt >/dev/null ; then
        rm -f /tmp/*.c
        rm -f /tmp/*.sh
	exit 2;
    fi    
done


for cc in "${BADCC1[@]}" ; do
    for mode in "${MODE[@]}" ; do
        rm -f ./t ./out2.txt 

      
        (timeout -s 9 $TIMEOUTCC $cc $CFLAG $mode -x c $CFILE >out2.txt 2>&1) >& /dev/null
        if ! grep 'internal compiler error' out2.txt && \
           ! grep 'PLEASE ATTACH THE FOLLOWING FILES TO THE BUG REPORT' out2.txt
        then	
            rm -f /tmp/*.c
            rm -f /tmp/*.sh
            exit 3;
        fi
    done
done

for cc in "${BADCC2[@]}" ; do 
    for mode in "${MODE[@]}" ; do
        rm -f ./t ./out2.txt 

         
        timeout -s 9 $TIMEOUTCC $cc $CFLAG $mode -x c $CFILE >& /dev/null
        ret=$? 
        if [ $ret -ne 0 ] ; then 
           rm -f /tmp/*.c
           rm -f /tmp/*.sh
           exit 0;
        fi

         
        (timeout -s 9 $TIMEOUTEXE ./t >out2.txt 2>&1) >&/dev/null
        ret=$? 
        if [ $ret -ne 137 ] ; then 
            rm -f /tmp/*.c
            rm -f /tmp/*.sh
            exit 3;
        fi
    done
done

for cc in "${BADCC3[@]}" ; do 
    for mode in "${MODE[@]}" ; do
        rm -f ./t ./out2.txt 

         
        timeout -s 9 $TIMEOUTCC $cc $CFLAG $mode -x c $CFILE >& /dev/null
        ret=$? 
        if [ $ret != 0 ] ; then
          rm -f /tmp/*.c
          rm -f /tmp/*.sh
          exit 0;
        fi

         
        (timeout -s 9 $TIMEOUTEXE ./t >out2.txt 2>&1) >&/dev/null
        ret=$? 
        
        if [ $ret != 135 ] ; then 
          rm -f /tmp/*.c
          rm -f /tmp/*.sh
          exit 3;
        fi 
    done 
done

readonly TEMP_EXE="temp.exe"
timeout -s 9 $TIMEOUTCC $CLANG_MEM_SANITIZER -x c $CFILE -o $TEMP_EXE > /dev/null
if [[ $? != 0 ]] ; then
  rm -f /tmp/*.c
  rm -f /tmp/*.sh
  exit 0;
fi

readonly MEM_SANITIZER_OUTPUT="mem-sanitizer.output"
(timeout -s 9 $TIMEOUTEXE ./$TEMP_EXE &> $MEM_SANITIZER_OUTPUT ) &> /dev/null
if [[ $? != 0 ]] ; then
  rm -f /tmp/*.c
  rm -f /tmp/*.sh
  rm $MEM_SANITIZER_OUTPUT
  rm $TEMP_EXE
  exit 2;
fi
rm $MEM_SANITIZER_OUTPUT
rm $TEMP_EXE

rm -f /tmp/*.c
rm -f /tmp/*.sh
exit 1;
