#!/usr/bin/env bash
rm -f /home/benchmark/thesis/reduced-*

set -o nounset
set -o pipefail

readonly VERSION="nightly-2019-10-30"
rustup toolchain install "${VERSION}" --force || exit 0


readonly OUTPUT="temp_compilation_output.tmp.txt"

OUTPUT2=$(rustc $1 2>&1)
RESULT=$?
if [[ $RESULT -ne 0 ]]; then
  exit 0;
fi

if ! timeout -s 9 30 rustup run "${VERSION}" rustc -Z parse-only $1 ; then 
  exit 0;
fi	

if timeout -s 9 30 rustup run "${VERSION}" rustc --crate-type=staticlib -C debuginfo=2 -C opt-level=z -C target-cpu=skylake $1 &> "${OUTPUT}" ; then 
  exit 0;
fi

if ! grep --quiet --fixed-strings "error: internal compiler error:" "${OUTPUT}" ; then
  exit 3;
fi

if ! grep --quiet --fixed-strings "broken MIR in DefId" "${OUTPUT}" ; then
  exit 3;
fi

exit 1;
