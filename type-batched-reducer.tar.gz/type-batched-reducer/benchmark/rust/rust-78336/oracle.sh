#!/usr/bin/env bash
set -o nounset
set -o pipefail

readonly OUTPUT="temp_compilation_output.tmp.txt"
readonly RUSTC_VERSION="nightly-2020-02-10"
readonly BUGGY_RUSTC_VERSION="nightly-2020-10-20"

rustup toolchain install "${RUSTC_VERSION}" --force
rustup toolchain install "${BUGGY_RUSTC_VERSION}" --force

if ! timeout -s 9 30 rustup run "${RUSTC_VERSION}" rustc -Z parse-only $1 &> /dev/null ; then 
  # syntactically invalid.
  exit 0;
fi
if timeout -s 9 30 rustup run "${BUGGY_RUSTC_VERSION}" rustc --crate-type=staticlib -C debuginfo=2 -C opt-level=z -C target-cpu=skylake $1 &> "${OUTPUT}" ; then 
  exit 0;
fi

if ! grep --quiet --fixed-strings "thread 'rustc' panicked at 'assertion failed: body.yield_ty.is_some() && universal_regions.yield_ty.is_some() ||" "${OUTPUT}" ; then
  exit 3;
fi

if ! grep --quiet --fixed-strings "error: internal compiler error: unexpected panic" "${OUTPUT}" ; then
  exit 3;
fi

if ! grep --quiet --fixed-strings "note: the compiler unexpectedly panicked. this is a bug." "${OUTPUT}" ; then
  exit 3;
fi
exit 1;
