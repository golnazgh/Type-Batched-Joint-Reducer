package main

import "fmt"

func main() {

	if false {
		fmt.Println("first print statement")
	} else {
		fmt.Println("second print statement")
	}

}
