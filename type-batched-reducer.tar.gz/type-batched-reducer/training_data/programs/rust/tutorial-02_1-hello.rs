/**
 * 2.1 Compiling your first program
 * http://doc.rust-lang.org/tutorial.html#compiling-your-first-program
 *
 * Run `rustc hello.rs` to produce an executable called `hello` (or `hello.exe` on Windows).
 *
 * @license MIT license <http://www.opensource.org/licenses/mit-license.php>
 */
fn main() {
    println!("hello?");
}
