#!/usr/bin/env python3

import re as re
import numpy as np
import pandas as pd 

from collections import defaultdict

from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score

import mlpack

#import seaborn as sns
#import matplotlib.pyplot as plt



# Factored form
#
# Raw Files = ([Cases], File ID)
# Case = ([Iterations], Case ID, initial size)
# Iteration = ([Tests], iteration ID)
# Test = (Test ID, node type, outcome)
#
# Resulting tuples:
# (File ID, Case ID, Initial size, Iteration ID, iteration size, Test ID, test size, node type, outcome)


def extract_dataframe(files):
    # Single data line processing
    test_pattern = re.compile('(\d+) -?\d+ o: (\d+) size: (\d+)')
    def parse_line(line):
        result = test_pattern.match(line)
        return (int(result.group(1)),
                int(result.group(2)),
                int(result.group(3))) if result else None

    # Raw file processing
    def parse_file(file_id, file_name):
        with open(file_name) as infile:
            initial_size = None
            case_id = 0
            iteration_id = 0
            iteration_size = None
            test_id = 0
            
            for line in infile:
                element = parse_line(line)
                if element:
                    last_type, outcome, last_size = element

                    initial_size = last_size if not initial_size else initial_size
                    iteration_size = last_size if not iteration_size else iteration_size

                    yield (file_id, case_id, initial_size, iteration_id, iteration_size, test_id, last_size, last_type, outcome)
                    
                    test_id += 1

                # We are starting a new case, so reset all counters except the case ID.
                # The case ID needs to increase to keep cases separate.
                elif line == '***** new tree *****':
                    initial_size = None
                    iteration_size = None
                    iteration_id = 0
                    test_id = 0
                    case_id += 1

                # We are starting a new iteration, so increase the iteration counter and size
                elif line.startswith('Progress Report'):
                    iteration_id += 1
                    iteration_size = None


    all_data = (datum for file_id, file_name in enumerate(files)
                      for datum in parse_file(file_id, file_name))
    columns = ['file', 'case', 'startsize', 'iteration', 'iterationsize', 'test', 'size', 'nodetype', 'outcome']
    raw_frame = pd.DataFrame(all_data, columns = columns)

    print(len(raw_frame), 'Rows processed')
    return raw_frame


if __name__ == '__main__':
    print('Processing')
    
    import sys, os
    files = sys.argv[1:]
    if files == []:
        import glob
        files = list(glob.glob('./'))
    elif len(files) == 1 and os.path.isdir(files[0]):
        import glob
        files = list(glob.glob(os.path.join(files[0], '*')))
    files.sort()

    raw_frame = extract_dataframe(files)
    # Create a consistent location for all produced data sets
    out_directory = 'csvs'
    if not os.path.exists(out_directory):
        os.makedirs(out_directory)


    # Repartition the frame by node type so that we can analyze types independently.
    # Sorting the partitions by overall average allows us to consider types
    # with the most success independent of temporal effects first.
    # It also can allow us to prune types with no variation in behavior in the
    # training data.
    df_by_type = [(label, bucket) for label, bucket in raw_frame.groupby('nodetype')]
    df_by_type.sort(reverse=True, key=lambda x: x[1]["outcome"].mean())
    uniform_one = []
    uniform_zero = []
    modeled = defaultdict(list)
    
    for label, bucket in df_by_type:
        print("Node Type", label)
        print("  Overall average:", bucket["outcome"].mean(), 'of', len(bucket.index))
        
        bucket['scaled'] = np.divide(bucket['size'], bucket['startsize'])
        bucket['iterationsizescaled'] = np.divide(bucket['size'], bucket['iterationsize'])

        approaches = [
            #('t si sc i is', bucket[['test', 'size', 'scaled', 'iteration', 'iterationsizescaled', 'outcome']]),
            #('t si sc i',    bucket[['test', 'size', 'scaled', 'iteration', 'outcome']]),
            #('t si sc',      bucket[['test', 'size', 'scaled', 'outcome']]),
            #('t sc',         bucket[['test', 'scaled', 'outcome']]),
            #('t',            bucket[['test', 'outcome']]),
            ('sc',           bucket[['scaled', 'outcome']]),
            #('sc i', bucket[['scaled', 'iteration', 'outcome']]),
            #('sc i is', bucket[['scaled', 'iteration', 'iterationsizescaled', 'outcome']]),
            #('sc is', bucket[['scaled', 'iterationsizescaled', 'outcome']]),
          ]

        outcomes = bucket['outcome'].to_numpy()
        if (outcomes == outcomes[0]).all():
            if outcomes[0]:
                uniform_one.append(label)
            else:
                uniform_zero.append(label)
            continue

        for name, rows in approaches:
            try:
                data_name = "{}/{}.{}.csv".format(out_directory, name, label)
                rows.to_csv(data_name, index=False, header=False)
                modeled[name].append(data_name)
                
                # Drop the outcomes from the feature vectors if we want to actually play with models.
                # After all, the outcome predicts itself a little too well....
                rows.drop('outcome', inplace=True, axis=1)
                features = rows.to_numpy()
                
                # The lines below can be used to compare the models from MLPack and SciKit Learn.
                # They also allow plotting the logistic outcomes from different strategies.
                
                ## Using SciKit Learn
                #clf = LogisticRegression(random_state=0).fit(rows, outcomes)
                #predictions = clf.predict(rows)
                #print("    Accuracy", accuracy_score(predictions, outcomes) )
                #print("    Uniqueness", np.unique( predictions ))
                
                # Using MLPack
                model = mlpack.logistic_regression(labels=outcomes, training=features, test=features)
                print("    MLPack Accuracy", accuracy_score(model['output'], outcomes) )

                #try:
                    #probabilities = model['output_probabilities']                    
                    #plt.scatter(x=rows['scaled'], y=probabilities[:,1])
                    #plt.xlabel('scaled size (left is later)')
                    #plt.ylabel('P removal')
                    #plt.show()
                #except Exception as e:
                    #print(e)

            except ValueError as e:
                print(e)

            ## Statsmodels exceptions
            #except sme.PerfectSeparationError:
                #print('Perfect separation')
            except np.linalg.LinAlgError as e:
                print(e)

    print('Ones:', ', '.join(str(label) for label in uniform_one))
    print('Zeroes:', ', '.join(str(label) for label in uniform_zero))
    for approach, datasets in modeled.items():
        print(approach, len(datasets))
        for dataset in datasets:
            print(dataset)
    
# Serialization notes:
# Documentation:
#    https://pyarma.sourceforge.io/docs.html
# mlpack uses Armadillo matrices.
# pyArmadillo can save these
# numpy converts to Armadillo via pyArmadillo
# pandas converts to numpy
# process:
#  In python
#    mat(df.to_numpy()).save("filename", csv_ascii)
#  In C++
#    arma::mat dataset;
#    mlpack::data::Load("dataset.csv", dataset);
